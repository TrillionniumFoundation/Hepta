import HiaSyntaxResearch.CertPart05
namespace HiaCoreSyntaxSlice.WrongCondition
theorem mutated_kp29_3 (tail : List Nat) : parseStringTail (linear_k29_3 ++ (34 :: 58 :: tail)) [] = some (linear_k29_3, 58 :: tail) := by rfl
def linear_l29_3 : List (List Nat × Raw) := [(linear_k29_3, linear_r33)]
def linear_v29_3 : List Nat := linear_g83 ++ linear_b33
theorem mutated_sl29_3 : serializeFields 4079 27 linear_l29_3 = some linear_v29_3 := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4078 27 linear_k29_3 linear_r33 linear_b33 mutated_kd29_3 mutated_s33)
theorem mutated_pl29_3 (tail : List Nat) : parseFields 4079 27 (linear_v29_3 ++ (125 :: tail)) = some (linear_l29_3, tail) := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4078 27 (linear_k29_3 ++ (34 :: 58 :: (linear_b33 ++ (125 :: tail)))) linear_k29_3 (linear_b33 ++ (125 :: tail)) tail linear_r33 (mutated_kp29_3 (linear_b33 ++ (125 :: tail))) (mutated_p33 (125 :: tail)))
def linear_l29_2 : List (List Nat × Raw) := (linear_k29_2, linear_r32) :: linear_l29_3
def linear_v29_2 : List Nat := (linear_g80 ++ linear_b32) ++ (44 :: linear_v29_3)
theorem mutated_sl29_2 : serializeFields 4080 27 linear_l29_2 = some linear_v29_2 := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k29_2 linear_r32 (linear_k29_3, linear_r33) [] linear_b32 linear_v29_3 mutated_kd29_2 mutated_s32 mutated_sl29_3)
theorem mutated_pl29_2 (tail : List Nat) : parseFields 4080 27 (linear_v29_2 ++ (125 :: tail)) = some (linear_l29_2, tail) := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k29_2 ++ (34 :: 58 :: (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))))) linear_k29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))) (linear_v29_3 ++ (125 :: tail)) tail linear_r32 linear_l29_3 (mutated_kp29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail))))) (mutated_p32 (44 :: (linear_v29_3 ++ (125 :: tail)))) (mutated_pl29_3 tail))
def linear_l29_1 : List (List Nat × Raw) := (linear_k29_1, linear_r31) :: linear_l29_2
def linear_v29_1 : List Nat := (linear_g77 ++ linear_b31) ++ (44 :: linear_v29_2)
theorem mutated_sl29_1 : serializeFields 4081 27 linear_l29_1 = some linear_v29_1 := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k29_1 linear_r31 (linear_k29_2, linear_r32) linear_l29_3 linear_b31 linear_v29_2 mutated_kd29_1 mutated_s31 mutated_sl29_2)
theorem mutated_pl29_1 (tail : List Nat) : parseFields 4081 27 (linear_v29_1 ++ (125 :: tail)) = some (linear_l29_1, tail) := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k29_1 ++ (34 :: 58 :: (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))))) linear_k29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))) (linear_v29_2 ++ (125 :: tail)) tail linear_r31 linear_l29_2 (mutated_kp29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail))))) (mutated_p31 (44 :: (linear_v29_2 ++ (125 :: tail)))) (mutated_pl29_2 tail))
def linear_l29_0 : List (List Nat × Raw) := (linear_k29_0, linear_r30) :: linear_l29_1
def linear_v29_0 : List Nat := (linear_g74 ++ linear_b30) ++ (44 :: linear_v29_1)
theorem mutated_sl29_0 : serializeFields 4082 27 linear_l29_0 = some linear_v29_0 := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k29_0 linear_r30 (linear_k29_1, linear_r31) linear_l29_2 linear_b30 linear_v29_1 mutated_kd29_0 mutated_s30 mutated_sl29_1)
theorem mutated_pl29_0 (tail : List Nat) : parseFields 4082 27 (linear_v29_0 ++ (125 :: tail)) = some (linear_l29_0, tail) := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) linear_k29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))) (linear_v29_1 ++ (125 :: tail)) tail linear_r30 linear_l29_1 (mutated_kp29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail))))) (mutated_p30 (44 :: (linear_v29_1 ++ (125 :: tail)))) (mutated_pl29_1 tail))
def linear_r29 : Raw := (.obj linear_l29_0)
def linear_b29 : List Nat := linear_g73 ++ (linear_v29_0 ++ linear_g85)
theorem mutated_o29 : orderedFields linear_l29_0 = true := by decide +kernel
theorem mutated_s29 : serializeRaw 4083 28 linear_r29 = some linear_b29 := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4082 27 linear_l29_0 linear_v29_0 mutated_o29 mutated_sl29_0)
theorem mutated_p29 (tail : List Nat) : parseRaw 4083 28 (linear_b29 ++ tail) = some (linear_r29, tail) := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4082 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) tail linear_l29_0 mutated_o29 (by simpa only [linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl29_0 tail)))
def linear_r35 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,53])
def linear_b35 : List Nat := linear_g89
theorem mutated_s35 : serializeRaw 4080 27 linear_r35 = some linear_b35 := by decide +kernel
theorem mutated_p35 (tail : List Nat) : parseRaw 4080 27 (linear_b35 ++ tail) = some (linear_r35, tail) := by rfl
def linear_r36 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,51,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,49])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b36 : List Nat := linear_g92
theorem mutated_s36 : serializeRaw 4079 27 linear_r36 = some linear_b36 := by decide +kernel
theorem mutated_p36 (tail : List Nat) : parseRaw 4079 27 (linear_b36 ++ tail) = some (linear_r36, tail) := by rfl
def linear_r37 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b37 : List Nat := linear_g95
theorem mutated_s37 : serializeRaw 4078 27 linear_r37 = some linear_b37 := by decide +kernel
theorem mutated_p37 (tail : List Nat) : parseRaw 4078 27 (linear_b37 ++ tail) = some (linear_r37, tail) := by rfl
def linear_r38 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,52,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,54]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,49]))]))])
def linear_b38 : List Nat := linear_g98
theorem mutated_s38 : serializeRaw 4077 27 linear_r38 = some linear_b38 := by decide +kernel
theorem mutated_p38 (tail : List Nat) : parseRaw 4077 27 (linear_b38 ++ tail) = some (linear_r38, tail) := by rfl
def linear_k34_0 : List Nat := [105,100]
theorem mutated_kd34_0 : stringBytes linear_k34_0 = true := by decide +kernel
theorem mutated_kp34_0 (tail : List Nat) : parseStringTail (linear_k34_0 ++ (34 :: 58 :: tail)) [] = some (linear_k34_0, 58 :: tail) := by rfl
def linear_k34_1 : List Nat := [111,112,115]
theorem mutated_kd34_1 : stringBytes linear_k34_1 = true := by decide +kernel
theorem mutated_kp34_1 (tail : List Nat) : parseStringTail (linear_k34_1 ++ (34 :: 58 :: tail)) [] = some (linear_k34_1, 58 :: tail) := by rfl
def linear_k34_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd34_2 : stringBytes linear_k34_2 = true := by decide +kernel
theorem mutated_kp34_2 (tail : List Nat) : parseStringTail (linear_k34_2 ++ (34 :: 58 :: tail)) [] = some (linear_k34_2, 58 :: tail) := by rfl
def linear_k34_3 : List Nat := [116,101,114,109]
theorem mutated_kd34_3 : stringBytes linear_k34_3 = true := by decide +kernel
theorem mutated_kp34_3 (tail : List Nat) : parseStringTail (linear_k34_3 ++ (34 :: 58 :: tail)) [] = some (linear_k34_3, 58 :: tail) := by rfl
def linear_l34_3 : List (List Nat × Raw) := [(linear_k34_3, linear_r38)]
def linear_v34_3 : List Nat := linear_g97 ++ linear_b38
theorem mutated_sl34_3 : serializeFields 4078 27 linear_l34_3 = some linear_v34_3 := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4077 27 linear_k34_3 linear_r38 linear_b38 mutated_kd34_3 mutated_s38)
theorem mutated_pl34_3 (tail : List Nat) : parseFields 4078 27 (linear_v34_3 ++ (125 :: tail)) = some (linear_l34_3, tail) := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4077 27 (linear_k34_3 ++ (34 :: 58 :: (linear_b38 ++ (125 :: tail)))) linear_k34_3 (linear_b38 ++ (125 :: tail)) tail linear_r38 (mutated_kp34_3 (linear_b38 ++ (125 :: tail))) (mutated_p38 (125 :: tail)))
def linear_l34_2 : List (List Nat × Raw) := (linear_k34_2, linear_r37) :: linear_l34_3
def linear_v34_2 : List Nat := (linear_g94 ++ linear_b37) ++ (44 :: linear_v34_3)
theorem mutated_sl34_2 : serializeFields 4079 27 linear_l34_2 = some linear_v34_2 := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k34_2 linear_r37 (linear_k34_3, linear_r38) [] linear_b37 linear_v34_3 mutated_kd34_2 mutated_s37 mutated_sl34_3)
theorem mutated_pl34_2 (tail : List Nat) : parseFields 4079 27 (linear_v34_2 ++ (125 :: tail)) = some (linear_l34_2, tail) := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k34_2 ++ (34 :: 58 :: (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))))) linear_k34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))) (linear_v34_3 ++ (125 :: tail)) tail linear_r37 linear_l34_3 (mutated_kp34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail))))) (mutated_p37 (44 :: (linear_v34_3 ++ (125 :: tail)))) (mutated_pl34_3 tail))
def linear_l34_1 : List (List Nat × Raw) := (linear_k34_1, linear_r36) :: linear_l34_2
def linear_v34_1 : List Nat := (linear_g91 ++ linear_b36) ++ (44 :: linear_v34_2)
theorem mutated_sl34_1 : serializeFields 4080 27 linear_l34_1 = some linear_v34_1 := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k34_1 linear_r36 (linear_k34_2, linear_r37) linear_l34_3 linear_b36 linear_v34_2 mutated_kd34_1 mutated_s36 mutated_sl34_2)
theorem mutated_pl34_1 (tail : List Nat) : parseFields 4080 27 (linear_v34_1 ++ (125 :: tail)) = some (linear_l34_1, tail) := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k34_1 ++ (34 :: 58 :: (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))))) linear_k34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))) (linear_v34_2 ++ (125 :: tail)) tail linear_r36 linear_l34_2 (mutated_kp34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail))))) (mutated_p36 (44 :: (linear_v34_2 ++ (125 :: tail)))) (mutated_pl34_2 tail))
def linear_l34_0 : List (List Nat × Raw) := (linear_k34_0, linear_r35) :: linear_l34_1
def linear_v34_0 : List Nat := (linear_g88 ++ linear_b35) ++ (44 :: linear_v34_1)
theorem mutated_sl34_0 : serializeFields 4081 27 linear_l34_0 = some linear_v34_0 := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k34_0 linear_r35 (linear_k34_1, linear_r36) linear_l34_2 linear_b35 linear_v34_1 mutated_kd34_0 mutated_s35 mutated_sl34_1)
theorem mutated_pl34_0 (tail : List Nat) : parseFields 4081 27 (linear_v34_0 ++ (125 :: tail)) = some (linear_l34_0, tail) := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) linear_k34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))) (linear_v34_1 ++ (125 :: tail)) tail linear_r35 linear_l34_1 (mutated_kp34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail))))) (mutated_p35 (44 :: (linear_v34_1 ++ (125 :: tail)))) (mutated_pl34_1 tail))
def linear_r34 : Raw := (.obj linear_l34_0)
def linear_b34 : List Nat := linear_g87 ++ (linear_v34_0 ++ linear_g99)
theorem mutated_o34 : orderedFields linear_l34_0 = true := by decide +kernel
theorem mutated_s34 : serializeRaw 4082 28 linear_r34 = some linear_b34 := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4081 27 linear_l34_0 linear_v34_0 mutated_o34 mutated_sl34_0)
theorem mutated_p34 (tail : List Nat) : parseRaw 4082 28 (linear_b34 ++ tail) = some (linear_r34, tail) := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4081 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) tail linear_l34_0 mutated_o34 (by simpa only [linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl34_0 tail)))
def linear_r40 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,54])
def linear_b40 : List Nat := linear_g103
theorem mutated_s40 : serializeRaw 4079 27 linear_r40 = some linear_b40 := by decide +kernel
theorem mutated_p40 (tail : List Nat) : parseRaw 4079 27 (linear_b40 ++ tail) = some (linear_r40, tail) := by rfl
def linear_r41 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b41 : List Nat := linear_g106
theorem mutated_s41 : serializeRaw 4078 27 linear_r41 = some linear_b41 := by decide +kernel
theorem mutated_p41 (tail : List Nat) : parseRaw 4078 27 (linear_b41 ++ tail) = some (linear_r41, tail) := by rfl
def linear_r42 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,53])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,54])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b42 : List Nat := linear_g109
theorem mutated_s42 : serializeRaw 4077 27 linear_r42 = some linear_b42 := by decide +kernel
theorem mutated_p42 (tail : List Nat) : parseRaw 4077 27 (linear_b42 ++ tail) = some (linear_r42, tail) := by rfl
def linear_r43 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,52,54])]))])
def linear_b43 : List Nat := linear_g112
theorem mutated_s43 : serializeRaw 4076 27 linear_r43 = some linear_b43 := by decide +kernel
theorem mutated_p43 (tail : List Nat) : parseRaw 4076 27 (linear_b43 ++ tail) = some (linear_r43, tail) := by rfl
def linear_k39_0 : List Nat := [105,100]
theorem mutated_kd39_0 : stringBytes linear_k39_0 = true := by decide +kernel
theorem mutated_kp39_0 (tail : List Nat) : parseStringTail (linear_k39_0 ++ (34 :: 58 :: tail)) [] = some (linear_k39_0, 58 :: tail) := by rfl
def linear_k39_1 : List Nat := [111,112,115]
theorem mutated_kd39_1 : stringBytes linear_k39_1 = true := by decide +kernel
theorem mutated_kp39_1 (tail : List Nat) : parseStringTail (linear_k39_1 ++ (34 :: 58 :: tail)) [] = some (linear_k39_1, 58 :: tail) := by rfl
def linear_k39_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd39_2 : stringBytes linear_k39_2 = true := by decide +kernel
theorem mutated_kp39_2 (tail : List Nat) : parseStringTail (linear_k39_2 ++ (34 :: 58 :: tail)) [] = some (linear_k39_2, 58 :: tail) := by rfl
def linear_k39_3 : List Nat := [116,101,114,109]
theorem mutated_kd39_3 : stringBytes linear_k39_3 = true := by decide +kernel
theorem mutated_kp39_3 (tail : List Nat) : parseStringTail (linear_k39_3 ++ (34 :: 58 :: tail)) [] = some (linear_k39_3, 58 :: tail) := by rfl
def linear_l39_3 : List (List Nat × Raw) := [(linear_k39_3, linear_r43)]
def linear_v39_3 : List Nat := linear_g111 ++ linear_b43
theorem mutated_sl39_3 : serializeFields 4077 27 linear_l39_3 = some linear_v39_3 := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4076 27 linear_k39_3 linear_r43 linear_b43 mutated_kd39_3 mutated_s43)
theorem mutated_pl39_3 (tail : List Nat) : parseFields 4077 27 (linear_v39_3 ++ (125 :: tail)) = some (linear_l39_3, tail) := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4076 27 (linear_k39_3 ++ (34 :: 58 :: (linear_b43 ++ (125 :: tail)))) linear_k39_3 (linear_b43 ++ (125 :: tail)) tail linear_r43 (mutated_kp39_3 (linear_b43 ++ (125 :: tail))) (mutated_p43 (125 :: tail)))
def linear_l39_2 : List (List Nat × Raw) := (linear_k39_2, linear_r42) :: linear_l39_3
def linear_v39_2 : List Nat := (linear_g108 ++ linear_b42) ++ (44 :: linear_v39_3)
theorem mutated_sl39_2 : serializeFields 4078 27 linear_l39_2 = some linear_v39_2 := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k39_2 linear_r42 (linear_k39_3, linear_r43) [] linear_b42 linear_v39_3 mutated_kd39_2 mutated_s42 mutated_sl39_3)
theorem mutated_pl39_2 (tail : List Nat) : parseFields 4078 27 (linear_v39_2 ++ (125 :: tail)) = some (linear_l39_2, tail) := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k39_2 ++ (34 :: 58 :: (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))))) linear_k39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))) (linear_v39_3 ++ (125 :: tail)) tail linear_r42 linear_l39_3 (mutated_kp39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail))))) (mutated_p42 (44 :: (linear_v39_3 ++ (125 :: tail)))) (mutated_pl39_3 tail))
def linear_l39_1 : List (List Nat × Raw) := (linear_k39_1, linear_r41) :: linear_l39_2
def linear_v39_1 : List Nat := (linear_g105 ++ linear_b41) ++ (44 :: linear_v39_2)
theorem mutated_sl39_1 : serializeFields 4079 27 linear_l39_1 = some linear_v39_1 := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k39_1 linear_r41 (linear_k39_2, linear_r42) linear_l39_3 linear_b41 linear_v39_2 mutated_kd39_1 mutated_s41 mutated_sl39_2)
theorem mutated_pl39_1 (tail : List Nat) : parseFields 4079 27 (linear_v39_1 ++ (125 :: tail)) = some (linear_l39_1, tail) := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k39_1 ++ (34 :: 58 :: (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))))) linear_k39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))) (linear_v39_2 ++ (125 :: tail)) tail linear_r41 linear_l39_2 (mutated_kp39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail))))) (mutated_p41 (44 :: (linear_v39_2 ++ (125 :: tail)))) (mutated_pl39_2 tail))
def linear_l39_0 : List (List Nat × Raw) := (linear_k39_0, linear_r40) :: linear_l39_1
def linear_v39_0 : List Nat := (linear_g102 ++ linear_b40) ++ (44 :: linear_v39_1)
theorem mutated_sl39_0 : serializeFields 4080 27 linear_l39_0 = some linear_v39_0 := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k39_0 linear_r40 (linear_k39_1, linear_r41) linear_l39_2 linear_b40 linear_v39_1 mutated_kd39_0 mutated_s40 mutated_sl39_1)
theorem mutated_pl39_0 (tail : List Nat) : parseFields 4080 27 (linear_v39_0 ++ (125 :: tail)) = some (linear_l39_0, tail) := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) linear_k39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))) (linear_v39_1 ++ (125 :: tail)) tail linear_r40 linear_l39_1 (mutated_kp39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail))))) (mutated_p40 (44 :: (linear_v39_1 ++ (125 :: tail)))) (mutated_pl39_1 tail))
def linear_r39 : Raw := (.obj linear_l39_0)
def linear_b39 : List Nat := linear_g101 ++ (linear_v39_0 ++ linear_g113)
theorem mutated_o39 : orderedFields linear_l39_0 = true := by decide +kernel
theorem mutated_s39 : serializeRaw 4081 28 linear_r39 = some linear_b39 := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4080 27 linear_l39_0 linear_v39_0 mutated_o39 mutated_sl39_0)
theorem mutated_p39 (tail : List Nat) : parseRaw 4081 28 (linear_b39 ++ tail) = some (linear_r39, tail) := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4080 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) tail linear_l39_0 mutated_o39 (by simpa only [linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl39_0 tail)))
def linear_r45 : Raw := (.str [100,103,95,102,97,115,116,95,48])
def linear_b45 : List Nat := linear_g117
theorem mutated_s45 : serializeRaw 4078 27 linear_r45 = some linear_b45 := by decide +kernel
theorem mutated_p45 (tail : List Nat) : parseRaw 4078 27 (linear_b45 ++ tail) = some (linear_r45, tail) := by rfl
def linear_r46 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,53]),(.str [100,103,95,118,95,53,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,54])),([116,121,112,101],(.str [98,111,111,108]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,111,108,46,110,111,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [115,121,110,116,97,120,95,119,114,111,110,103,95,99,111,110,100,105,116,105,111,110])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b46 : List Nat := linear_g120
theorem mutated_s46 : serializeRaw 4077 27 linear_r46 = some linear_b46 := by decide +kernel
theorem mutated_p46 (tail : List Nat) : parseRaw 4077 27 (linear_b46 ++ tail) = some (linear_r46, tail) := by rfl
def linear_r47 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b47 : List Nat := linear_g123
theorem mutated_s47 : serializeRaw 4076 27 linear_r47 = some linear_b47 := by decide +kernel
theorem mutated_p47 (tail : List Nat) : parseRaw 4076 27 (linear_b47 ++ tail) = some (linear_r47, tail) := by rfl
def linear_r48 : Raw := (.obj [([99,111,110,100],(.str [115,121,110,116,97,120,95,119,114,111,110,103,95,99,111,110,100,105,116,105,111,110])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b48 : List Nat := linear_g126
theorem mutated_s48 : serializeRaw 4075 27 linear_r48 = some linear_b48 := by decide +kernel
theorem mutated_p48 (tail : List Nat) : parseRaw 4075 27 (linear_b48 ++ tail) = some (linear_r48, tail) := by rfl
def linear_k44_0 : List Nat := [105,100]
theorem mutated_kd44_0 : stringBytes linear_k44_0 = true := by decide +kernel
theorem mutated_kp44_0 (tail : List Nat) : parseStringTail (linear_k44_0 ++ (34 :: 58 :: tail)) [] = some (linear_k44_0, 58 :: tail) := by rfl
def linear_k44_1 : List Nat := [111,112,115]
theorem mutated_kd44_1 : stringBytes linear_k44_1 = true := by decide +kernel
theorem mutated_kp44_1 (tail : List Nat) : parseStringTail (linear_k44_1 ++ (34 :: 58 :: tail)) [] = some (linear_k44_1, 58 :: tail) := by rfl
def linear_k44_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd44_2 : stringBytes linear_k44_2 = true := by decide +kernel
theorem mutated_kp44_2 (tail : List Nat) : parseStringTail (linear_k44_2 ++ (34 :: 58 :: tail)) [] = some (linear_k44_2, 58 :: tail) := by rfl
def linear_k44_3 : List Nat := [116,101,114,109]
theorem mutated_kd44_3 : stringBytes linear_k44_3 = true := by decide +kernel
theorem mutated_kp44_3 (tail : List Nat) : parseStringTail (linear_k44_3 ++ (34 :: 58 :: tail)) [] = some (linear_k44_3, 58 :: tail) := by rfl
def linear_l44_3 : List (List Nat × Raw) := [(linear_k44_3, linear_r48)]
def linear_v44_3 : List Nat := linear_g125 ++ linear_b48
theorem mutated_sl44_3 : serializeFields 4076 27 linear_l44_3 = some linear_v44_3 := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4075 27 linear_k44_3 linear_r48 linear_b48 mutated_kd44_3 mutated_s48)
theorem mutated_pl44_3 (tail : List Nat) : parseFields 4076 27 (linear_v44_3 ++ (125 :: tail)) = some (linear_l44_3, tail) := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4075 27 (linear_k44_3 ++ (34 :: 58 :: (linear_b48 ++ (125 :: tail)))) linear_k44_3 (linear_b48 ++ (125 :: tail)) tail linear_r48 (mutated_kp44_3 (linear_b48 ++ (125 :: tail))) (mutated_p48 (125 :: tail)))
def linear_l44_2 : List (List Nat × Raw) := (linear_k44_2, linear_r47) :: linear_l44_3
def linear_v44_2 : List Nat := (linear_g122 ++ linear_b47) ++ (44 :: linear_v44_3)
theorem mutated_sl44_2 : serializeFields 4077 27 linear_l44_2 = some linear_v44_2 := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k44_2 linear_r47 (linear_k44_3, linear_r48) [] linear_b47 linear_v44_3 mutated_kd44_2 mutated_s47 mutated_sl44_3)
theorem mutated_pl44_2 (tail : List Nat) : parseFields 4077 27 (linear_v44_2 ++ (125 :: tail)) = some (linear_l44_2, tail) := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k44_2 ++ (34 :: 58 :: (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))))) linear_k44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))) (linear_v44_3 ++ (125 :: tail)) tail linear_r47 linear_l44_3 (mutated_kp44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail))))) (mutated_p47 (44 :: (linear_v44_3 ++ (125 :: tail)))) (mutated_pl44_3 tail))
def linear_l44_1 : List (List Nat × Raw) := (linear_k44_1, linear_r46) :: linear_l44_2
def linear_v44_1 : List Nat := (linear_g119 ++ linear_b46) ++ (44 :: linear_v44_2)
theorem mutated_sl44_1 : serializeFields 4078 27 linear_l44_1 = some linear_v44_1 := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k44_1 linear_r46 (linear_k44_2, linear_r47) linear_l44_3 linear_b46 linear_v44_2 mutated_kd44_1 mutated_s46 mutated_sl44_2)
theorem mutated_pl44_1 (tail : List Nat) : parseFields 4078 27 (linear_v44_1 ++ (125 :: tail)) = some (linear_l44_1, tail) := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k44_1 ++ (34 :: 58 :: (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))))) linear_k44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))) (linear_v44_2 ++ (125 :: tail)) tail linear_r46 linear_l44_2 (mutated_kp44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail))))) (mutated_p46 (44 :: (linear_v44_2 ++ (125 :: tail)))) (mutated_pl44_2 tail))
def linear_l44_0 : List (List Nat × Raw) := (linear_k44_0, linear_r45) :: linear_l44_1
def linear_v44_0 : List Nat := (linear_g116 ++ linear_b45) ++ (44 :: linear_v44_1)
theorem mutated_sl44_0 : serializeFields 4079 27 linear_l44_0 = some linear_v44_0 := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k44_0 linear_r45 (linear_k44_1, linear_r46) linear_l44_2 linear_b45 linear_v44_1 mutated_kd44_0 mutated_s45 mutated_sl44_1)
theorem mutated_pl44_0 (tail : List Nat) : parseFields 4079 27 (linear_v44_0 ++ (125 :: tail)) = some (linear_l44_0, tail) := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) linear_k44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))) (linear_v44_1 ++ (125 :: tail)) tail linear_r45 linear_l44_1 (mutated_kp44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail))))) (mutated_p45 (44 :: (linear_v44_1 ++ (125 :: tail)))) (mutated_pl44_1 tail))
def linear_r44 : Raw := (.obj linear_l44_0)
def linear_b44 : List Nat := linear_g115 ++ (linear_v44_0 ++ linear_g127)
theorem mutated_o44 : orderedFields linear_l44_0 = true := by decide +kernel
theorem mutated_s44 : serializeRaw 4080 28 linear_r44 = some linear_b44 := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4079 27 linear_l44_0 linear_v44_0 mutated_o44 mutated_sl44_0)
theorem mutated_p44 (tail : List Nat) : parseRaw 4080 28 (linear_b44 ++ tail) = some (linear_r44, tail) := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4079 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) tail linear_l44_0 mutated_o44 (by simpa only [linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl44_0 tail)))
def linear_r50 : Raw := (.str [100,103,95,102,97,115,116,95,49])
def linear_b50 : List Nat := linear_g131
theorem mutated_s50 : serializeRaw 4077 27 linear_r50 = some linear_b50 := by decide +kernel
theorem mutated_p50 (tail : List Nat) : parseRaw 4077 27 (linear_b50 ++ tail) = some (linear_r50, tail) := by rfl
def linear_r52 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,50])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b52 : List Nat := linear_g135
theorem mutated_s52 : serializeRaw 4074 26 linear_r52 = some linear_b52 := by decide +kernel
theorem mutated_p52 (tail : List Nat) : parseRaw 4074 26 (linear_b52 ++ tail) = some (linear_r52, tail) := by rfl
def linear_r53 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,50]),(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,51])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b53 : List Nat := linear_g137
theorem mutated_s53 : serializeRaw 4073 26 linear_r53 = some linear_b53 := by decide +kernel
theorem mutated_p53 (tail : List Nat) : parseRaw 4073 26 (linear_b53 ++ tail) = some (linear_r53, tail) := by rfl
def linear_r54 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,52])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b54 : List Nat := linear_g139
theorem mutated_s54 : serializeRaw 4072 26 linear_r54 = some linear_b54 := by decide +kernel
theorem mutated_p54 (tail : List Nat) : parseRaw 4072 26 (linear_b54 ++ tail) = some (linear_r54, tail) := by rfl
def linear_r55 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b55 : List Nat := linear_g141
theorem mutated_s55 : serializeRaw 4071 26 linear_r55 = some linear_b55 := by decide +kernel
theorem mutated_p55 (tail : List Nat) : parseRaw 4071 26 (linear_b55 ++ tail) = some (linear_r55, tail) := by rfl
def linear_r56 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,52]),(.str [100,103,95,118,95,54,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,54])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b56 : List Nat := linear_g143
theorem mutated_s56 : serializeRaw 4070 26 linear_r56 = some linear_b56 := by decide +kernel
theorem mutated_p56 (tail : List Nat) : parseRaw 4070 26 (linear_b56 ++ tail) = some (linear_r56, tail) := by rfl
def linear_r57 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,54])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b57 : List Nat := linear_g145
theorem mutated_s57 : serializeRaw 4069 26 linear_r57 = some linear_b57 := by decide +kernel
theorem mutated_p57 (tail : List Nat) : parseRaw 4069 26 (linear_b57 ++ tail) = some (linear_r57, tail) := by rfl
def linear_r58 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,56])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b58 : List Nat := linear_g147
theorem mutated_s58 : serializeRaw 4068 26 linear_r58 = some linear_b58 := by decide +kernel
theorem mutated_p58 (tail : List Nat) : parseRaw 4068 26 (linear_b58 ++ tail) = some (linear_r58, tail) := by rfl
def linear_r59 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56]),(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b59 : List Nat := linear_g149
theorem mutated_s59 : serializeRaw 4067 26 linear_r59 = some linear_b59 := by decide +kernel
theorem mutated_p59 (tail : List Nat) : parseRaw 4067 26 (linear_b59 ++ tail) = some (linear_r59, tail) := by rfl
def linear_r60 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b60 : List Nat := linear_g151
theorem mutated_s60 : serializeRaw 4066 26 linear_r60 = some linear_b60 := by decide +kernel
theorem mutated_p60 (tail : List Nat) : parseRaw 4066 26 (linear_b60 ++ tail) = some (linear_r60, tail) := by rfl
def linear_r61 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b61 : List Nat := linear_g153
theorem mutated_s61 : serializeRaw 4065 26 linear_r61 = some linear_b61 := by decide +kernel
theorem mutated_p61 (tail : List Nat) : parseRaw 4065 26 (linear_b61 ++ tail) = some (linear_r61, tail) := by rfl
def linear_r62 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b62 : List Nat := linear_g155
theorem mutated_s62 : serializeRaw 4064 26 linear_r62 = some linear_b62 := by decide +kernel
theorem mutated_p62 (tail : List Nat) : parseRaw 4064 26 (linear_b62 ++ tail) = some (linear_r62, tail) := by rfl
def linear_l51_10 : List Raw := [linear_r62]
def linear_v51_10 : List Nat := linear_b62
theorem mutated_sl51_10 : serializeItems 4065 26 linear_l51_10 = some linear_v51_10 := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4064 26 linear_r62 linear_b62 mutated_s62)
theorem mutated_pl51_10 (tail : List Nat) : parseItems 4065 26 (linear_v51_10 ++ (93 :: tail)) = some (linear_l51_10, tail) := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4064 26 (linear_b62 ++ (93 :: tail)) tail linear_r62 (mutated_p62 (93 :: tail)))
def linear_l51_9 : List Raw := linear_r61 :: linear_l51_10
def linear_v51_9 : List Nat := (linear_b61) ++ (44 :: linear_v51_10)
theorem mutated_sl51_9 : serializeItems 4066 26 linear_l51_9 = some linear_v51_9 := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r61 linear_r62 [] linear_b61 linear_v51_10 mutated_s61 mutated_sl51_10)
theorem mutated_pl51_9 (tail : List Nat) : parseItems 4066 26 (linear_v51_9 ++ (93 :: tail)) = some (linear_l51_9, tail) := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b61 ++ (44 :: (linear_v51_10 ++ (93 :: tail)))) (linear_v51_10 ++ (93 :: tail)) tail linear_r61 linear_l51_10 (mutated_p61 (44 :: (linear_v51_10 ++ (93 :: tail)))) (mutated_pl51_10 tail))
def linear_l51_8 : List Raw := linear_r60 :: linear_l51_9
def linear_v51_8 : List Nat := (linear_b60) ++ (44 :: linear_v51_9)
theorem mutated_sl51_8 : serializeItems 4067 26 linear_l51_8 = some linear_v51_8 := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r60 linear_r61 linear_l51_10 linear_b60 linear_v51_9 mutated_s60 mutated_sl51_9)
theorem mutated_pl51_8 (tail : List Nat) : parseItems 4067 26 (linear_v51_8 ++ (93 :: tail)) = some (linear_l51_8, tail) := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b60 ++ (44 :: (linear_v51_9 ++ (93 :: tail)))) (linear_v51_9 ++ (93 :: tail)) tail linear_r60 linear_l51_9 (mutated_p60 (44 :: (linear_v51_9 ++ (93 :: tail)))) (mutated_pl51_9 tail))
def linear_l51_7 : List Raw := linear_r59 :: linear_l51_8
def linear_v51_7 : List Nat := (linear_b59) ++ (44 :: linear_v51_8)
theorem mutated_sl51_7 : serializeItems 4068 26 linear_l51_7 = some linear_v51_7 := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r59 linear_r60 linear_l51_9 linear_b59 linear_v51_8 mutated_s59 mutated_sl51_8)
theorem mutated_pl51_7 (tail : List Nat) : parseItems 4068 26 (linear_v51_7 ++ (93 :: tail)) = some (linear_l51_7, tail) := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b59 ++ (44 :: (linear_v51_8 ++ (93 :: tail)))) (linear_v51_8 ++ (93 :: tail)) tail linear_r59 linear_l51_8 (mutated_p59 (44 :: (linear_v51_8 ++ (93 :: tail)))) (mutated_pl51_8 tail))
def linear_l51_6 : List Raw := linear_r58 :: linear_l51_7
def linear_v51_6 : List Nat := (linear_b58) ++ (44 :: linear_v51_7)
theorem mutated_sl51_6 : serializeItems 4069 26 linear_l51_6 = some linear_v51_6 := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r58 linear_r59 linear_l51_8 linear_b58 linear_v51_7 mutated_s58 mutated_sl51_7)
theorem mutated_pl51_6 (tail : List Nat) : parseItems 4069 26 (linear_v51_6 ++ (93 :: tail)) = some (linear_l51_6, tail) := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b58 ++ (44 :: (linear_v51_7 ++ (93 :: tail)))) (linear_v51_7 ++ (93 :: tail)) tail linear_r58 linear_l51_7 (mutated_p58 (44 :: (linear_v51_7 ++ (93 :: tail)))) (mutated_pl51_7 tail))
def linear_l51_5 : List Raw := linear_r57 :: linear_l51_6
def linear_v51_5 : List Nat := (linear_b57) ++ (44 :: linear_v51_6)
theorem mutated_sl51_5 : serializeItems 4070 26 linear_l51_5 = some linear_v51_5 := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r57 linear_r58 linear_l51_7 linear_b57 linear_v51_6 mutated_s57 mutated_sl51_6)
theorem mutated_pl51_5 (tail : List Nat) : parseItems 4070 26 (linear_v51_5 ++ (93 :: tail)) = some (linear_l51_5, tail) := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b57 ++ (44 :: (linear_v51_6 ++ (93 :: tail)))) (linear_v51_6 ++ (93 :: tail)) tail linear_r57 linear_l51_6 (mutated_p57 (44 :: (linear_v51_6 ++ (93 :: tail)))) (mutated_pl51_6 tail))
def linear_l51_4 : List Raw := linear_r56 :: linear_l51_5
def linear_v51_4 : List Nat := (linear_b56) ++ (44 :: linear_v51_5)
theorem mutated_sl51_4 : serializeItems 4071 26 linear_l51_4 = some linear_v51_4 := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r56 linear_r57 linear_l51_6 linear_b56 linear_v51_5 mutated_s56 mutated_sl51_5)
theorem mutated_pl51_4 (tail : List Nat) : parseItems 4071 26 (linear_v51_4 ++ (93 :: tail)) = some (linear_l51_4, tail) := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b56 ++ (44 :: (linear_v51_5 ++ (93 :: tail)))) (linear_v51_5 ++ (93 :: tail)) tail linear_r56 linear_l51_5 (mutated_p56 (44 :: (linear_v51_5 ++ (93 :: tail)))) (mutated_pl51_5 tail))
def linear_l51_3 : List Raw := linear_r55 :: linear_l51_4
def linear_v51_3 : List Nat := (linear_b55) ++ (44 :: linear_v51_4)
theorem mutated_sl51_3 : serializeItems 4072 26 linear_l51_3 = some linear_v51_3 := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r55 linear_r56 linear_l51_5 linear_b55 linear_v51_4 mutated_s55 mutated_sl51_4)
theorem mutated_pl51_3 (tail : List Nat) : parseItems 4072 26 (linear_v51_3 ++ (93 :: tail)) = some (linear_l51_3, tail) := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b55 ++ (44 :: (linear_v51_4 ++ (93 :: tail)))) (linear_v51_4 ++ (93 :: tail)) tail linear_r55 linear_l51_4 (mutated_p55 (44 :: (linear_v51_4 ++ (93 :: tail)))) (mutated_pl51_4 tail))
def linear_l51_2 : List Raw := linear_r54 :: linear_l51_3
def linear_v51_2 : List Nat := (linear_b54) ++ (44 :: linear_v51_3)
theorem mutated_sl51_2 : serializeItems 4073 26 linear_l51_2 = some linear_v51_2 := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 26 linear_r54 linear_r55 linear_l51_4 linear_b54 linear_v51_3 mutated_s54 mutated_sl51_3)
theorem mutated_pl51_2 (tail : List Nat) : parseItems 4073 26 (linear_v51_2 ++ (93 :: tail)) = some (linear_l51_2, tail) := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 26 (linear_b54 ++ (44 :: (linear_v51_3 ++ (93 :: tail)))) (linear_v51_3 ++ (93 :: tail)) tail linear_r54 linear_l51_3 (mutated_p54 (44 :: (linear_v51_3 ++ (93 :: tail)))) (mutated_pl51_3 tail))
def linear_l51_1 : List Raw := linear_r53 :: linear_l51_2
def linear_v51_1 : List Nat := (linear_b53) ++ (44 :: linear_v51_2)
theorem mutated_sl51_1 : serializeItems 4074 26 linear_l51_1 = some linear_v51_1 := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 26 linear_r53 linear_r54 linear_l51_3 linear_b53 linear_v51_2 mutated_s53 mutated_sl51_2)
theorem mutated_pl51_1 (tail : List Nat) : parseItems 4074 26 (linear_v51_1 ++ (93 :: tail)) = some (linear_l51_1, tail) := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 26 (linear_b53 ++ (44 :: (linear_v51_2 ++ (93 :: tail)))) (linear_v51_2 ++ (93 :: tail)) tail linear_r53 linear_l51_2 (mutated_p53 (44 :: (linear_v51_2 ++ (93 :: tail)))) (mutated_pl51_2 tail))
def linear_l51_0 : List Raw := linear_r52 :: linear_l51_1
def linear_v51_0 : List Nat := (linear_b52) ++ (44 :: linear_v51_1)
theorem mutated_sl51_0 : serializeItems 4075 26 linear_l51_0 = some linear_v51_0 := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 26 linear_r52 linear_r53 linear_l51_2 linear_b52 linear_v51_1 mutated_s52 mutated_sl51_1)
theorem mutated_pl51_0 (tail : List Nat) : parseItems 4075 26 (linear_v51_0 ++ (93 :: tail)) = some (linear_l51_0, tail) := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 26 (linear_b52 ++ (44 :: (linear_v51_1 ++ (93 :: tail)))) (linear_v51_1 ++ (93 :: tail)) tail linear_r52 linear_l51_1 (mutated_p52 (44 :: (linear_v51_1 ++ (93 :: tail)))) (mutated_pl51_1 tail))
def linear_r51 : Raw := (.arr linear_l51_0)
def linear_b51 : List Nat := linear_g134 ++ (linear_v51_0 ++ linear_g156)
theorem mutated_s51 : serializeRaw 4076 27 linear_r51 = some linear_b51 := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4075 26 linear_l51_0 linear_v51_0 mutated_sl51_0)
theorem mutated_p51 (tail : List Nat) : parseRaw 4076 27 (linear_b51 ++ tail) = some (linear_r51, tail) := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4075 26 (linear_v51_0 ++ (93 :: tail)) tail linear_l51_0 (by intro h; cases h) (mutated_pl51_0 tail))
def linear_r63 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b63 : List Nat := linear_g159
theorem mutated_s63 : serializeRaw 4075 27 linear_r63 = some linear_b63 := by decide +kernel
theorem mutated_p63 (tail : List Nat) : parseRaw 4075 27 (linear_b63 ++ tail) = some (linear_r63, tail) := by rfl
def linear_r64 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,55]),(.str [100,103,95,118,95,53,56]),(.str [100,103,95,118,95,53,57]),(.str [100,103,95,118,95,54,48]),(.str [100,103,95,118,95,55,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,48]))])
def linear_b64 : List Nat := linear_g162
theorem mutated_s64 : serializeRaw 4074 27 linear_r64 = some linear_b64 := by decide +kernel
theorem mutated_p64 (tail : List Nat) : parseRaw 4074 27 (linear_b64 ++ tail) = some (linear_r64, tail) := by rfl
def linear_k49_0 : List Nat := [105,100]
theorem mutated_kd49_0 : stringBytes linear_k49_0 = true := by decide +kernel
theorem mutated_kp49_0 (tail : List Nat) : parseStringTail (linear_k49_0 ++ (34 :: 58 :: tail)) [] = some (linear_k49_0, 58 :: tail) := by rfl
def linear_k49_1 : List Nat := [111,112,115]
theorem mutated_kd49_1 : stringBytes linear_k49_1 = true := by decide +kernel
theorem mutated_kp49_1 (tail : List Nat) : parseStringTail (linear_k49_1 ++ (34 :: 58 :: tail)) [] = some (linear_k49_1, 58 :: tail) := by rfl
def linear_k49_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd49_2 : stringBytes linear_k49_2 = true := by decide +kernel
theorem mutated_kp49_2 (tail : List Nat) : parseStringTail (linear_k49_2 ++ (34 :: 58 :: tail)) [] = some (linear_k49_2, 58 :: tail) := by rfl
def linear_k49_3 : List Nat := [116,101,114,109]
theorem mutated_kd49_3 : stringBytes linear_k49_3 = true := by decide +kernel
theorem mutated_kp49_3 (tail : List Nat) : parseStringTail (linear_k49_3 ++ (34 :: 58 :: tail)) [] = some (linear_k49_3, 58 :: tail) := by rfl
def linear_l49_3 : List (List Nat × Raw) := [(linear_k49_3, linear_r64)]
def linear_v49_3 : List Nat := linear_g161 ++ linear_b64
theorem mutated_sl49_3 : serializeFields 4075 27 linear_l49_3 = some linear_v49_3 := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4074 27 linear_k49_3 linear_r64 linear_b64 mutated_kd49_3 mutated_s64)
theorem mutated_pl49_3 (tail : List Nat) : parseFields 4075 27 (linear_v49_3 ++ (125 :: tail)) = some (linear_l49_3, tail) := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4074 27 (linear_k49_3 ++ (34 :: 58 :: (linear_b64 ++ (125 :: tail)))) linear_k49_3 (linear_b64 ++ (125 :: tail)) tail linear_r64 (mutated_kp49_3 (linear_b64 ++ (125 :: tail))) (mutated_p64 (125 :: tail)))
def linear_l49_2 : List (List Nat × Raw) := (linear_k49_2, linear_r63) :: linear_l49_3
def linear_v49_2 : List Nat := (linear_g158 ++ linear_b63) ++ (44 :: linear_v49_3)
theorem mutated_sl49_2 : serializeFields 4076 27 linear_l49_2 = some linear_v49_2 := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k49_2 linear_r63 (linear_k49_3, linear_r64) [] linear_b63 linear_v49_3 mutated_kd49_2 mutated_s63 mutated_sl49_3)
theorem mutated_pl49_2 (tail : List Nat) : parseFields 4076 27 (linear_v49_2 ++ (125 :: tail)) = some (linear_l49_2, tail) := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k49_2 ++ (34 :: 58 :: (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))))) linear_k49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))) (linear_v49_3 ++ (125 :: tail)) tail linear_r63 linear_l49_3 (mutated_kp49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail))))) (mutated_p63 (44 :: (linear_v49_3 ++ (125 :: tail)))) (mutated_pl49_3 tail))
def linear_l49_1 : List (List Nat × Raw) := (linear_k49_1, linear_r51) :: linear_l49_2
def linear_v49_1 : List Nat := (linear_g133 ++ linear_b51) ++ (44 :: linear_v49_2)
theorem mutated_sl49_1 : serializeFields 4077 27 linear_l49_1 = some linear_v49_1 := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k49_1 linear_r51 (linear_k49_2, linear_r63) linear_l49_3 linear_b51 linear_v49_2 mutated_kd49_1 mutated_s51 mutated_sl49_2)
theorem mutated_pl49_1 (tail : List Nat) : parseFields 4077 27 (linear_v49_1 ++ (125 :: tail)) = some (linear_l49_1, tail) := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k49_1 ++ (34 :: 58 :: (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))))) linear_k49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))) (linear_v49_2 ++ (125 :: tail)) tail linear_r51 linear_l49_2 (mutated_kp49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail))))) (mutated_p51 (44 :: (linear_v49_2 ++ (125 :: tail)))) (mutated_pl49_2 tail))
def linear_l49_0 : List (List Nat × Raw) := (linear_k49_0, linear_r50) :: linear_l49_1
def linear_v49_0 : List Nat := (linear_g130 ++ linear_b50) ++ (44 :: linear_v49_1)
theorem mutated_sl49_0 : serializeFields 4078 27 linear_l49_0 = some linear_v49_0 := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k49_0 linear_r50 (linear_k49_1, linear_r51) linear_l49_2 linear_b50 linear_v49_1 mutated_kd49_0 mutated_s50 mutated_sl49_1)
theorem mutated_pl49_0 (tail : List Nat) : parseFields 4078 27 (linear_v49_0 ++ (125 :: tail)) = some (linear_l49_0, tail) := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) linear_k49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))) (linear_v49_1 ++ (125 :: tail)) tail linear_r50 linear_l49_1 (mutated_kp49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail))))) (mutated_p50 (44 :: (linear_v49_1 ++ (125 :: tail)))) (mutated_pl49_1 tail))
def linear_r49 : Raw := (.obj linear_l49_0)
def linear_b49 : List Nat := linear_g129 ++ (linear_v49_0 ++ linear_g163)
theorem mutated_o49 : orderedFields linear_l49_0 = true := by decide +kernel
theorem mutated_s49 : serializeRaw 4079 28 linear_r49 = some linear_b49 := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4078 27 linear_l49_0 linear_v49_0 mutated_o49 mutated_sl49_0)
theorem mutated_p49 (tail : List Nat) : parseRaw 4079 28 (linear_b49 ++ tail) = some (linear_r49, tail) := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4078 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) tail linear_l49_0 mutated_o49 (by simpa only [linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl49_0 tail)))
def linear_r66 : Raw := (.str [100,103,95,102,97,115,116,95,50])
def linear_b66 : List Nat := linear_g167
theorem mutated_s66 : serializeRaw 4076 27 linear_r66 = some linear_b66 := by decide +kernel
theorem mutated_p66 (tail : List Nat) : parseRaw 4076 27 (linear_b66 ++ tail) = some (linear_r66, tail) := by rfl
def linear_r67 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,54])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,55])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b67 : List Nat := linear_g170
theorem mutated_s67 : serializeRaw 4075 27 linear_r67 = some linear_b67 := by decide +kernel
theorem mutated_p67 (tail : List Nat) : parseRaw 4075 27 (linear_b67 ++ tail) = some (linear_r67, tail) := by rfl
def linear_r68 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b68 : List Nat := linear_g173
theorem mutated_s68 : serializeRaw 4074 27 linear_r68 = some linear_b68 := by decide +kernel
theorem mutated_p68 (tail : List Nat) : parseRaw 4074 27 (linear_b68 ++ tail) = some (linear_r68, tail) := by rfl
def linear_r69 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,50]),(.str [100,103,95,118,95,55,51]),(.str [100,103,95,118,95,55,54]),(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,55])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b69 : List Nat := linear_g176
theorem mutated_s69 : serializeRaw 4073 27 linear_r69 = some linear_b69 := by decide +kernel
theorem mutated_p69 (tail : List Nat) : parseRaw 4073 27 (linear_b69 ++ tail) = some (linear_r69, tail) := by rfl
def linear_k65_0 : List Nat := [105,100]
theorem mutated_kd65_0 : stringBytes linear_k65_0 = true := by decide +kernel
theorem mutated_kp65_0 (tail : List Nat) : parseStringTail (linear_k65_0 ++ (34 :: 58 :: tail)) [] = some (linear_k65_0, 58 :: tail) := by rfl
def linear_k65_1 : List Nat := [111,112,115]
theorem mutated_kd65_1 : stringBytes linear_k65_1 = true := by decide +kernel
theorem mutated_kp65_1 (tail : List Nat) : parseStringTail (linear_k65_1 ++ (34 :: 58 :: tail)) [] = some (linear_k65_1, 58 :: tail) := by rfl
def linear_k65_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd65_2 : stringBytes linear_k65_2 = true := by decide +kernel
theorem mutated_kp65_2 (tail : List Nat) : parseStringTail (linear_k65_2 ++ (34 :: 58 :: tail)) [] = some (linear_k65_2, 58 :: tail) := by rfl
def linear_k65_3 : List Nat := [116,101,114,109]
theorem mutated_kd65_3 : stringBytes linear_k65_3 = true := by decide +kernel
theorem mutated_kp65_3 (tail : List Nat) : parseStringTail (linear_k65_3 ++ (34 :: 58 :: tail)) [] = some (linear_k65_3, 58 :: tail) := by rfl
def linear_l65_3 : List (List Nat × Raw) := [(linear_k65_3, linear_r69)]
def linear_v65_3 : List Nat := linear_g175 ++ linear_b69
theorem mutated_sl65_3 : serializeFields 4074 27 linear_l65_3 = some linear_v65_3 := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4073 27 linear_k65_3 linear_r69 linear_b69 mutated_kd65_3 mutated_s69)
theorem mutated_pl65_3 (tail : List Nat) : parseFields 4074 27 (linear_v65_3 ++ (125 :: tail)) = some (linear_l65_3, tail) := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4073 27 (linear_k65_3 ++ (34 :: 58 :: (linear_b69 ++ (125 :: tail)))) linear_k65_3 (linear_b69 ++ (125 :: tail)) tail linear_r69 (mutated_kp65_3 (linear_b69 ++ (125 :: tail))) (mutated_p69 (125 :: tail)))
def linear_l65_2 : List (List Nat × Raw) := (linear_k65_2, linear_r68) :: linear_l65_3
def linear_v65_2 : List Nat := (linear_g172 ++ linear_b68) ++ (44 :: linear_v65_3)
theorem mutated_sl65_2 : serializeFields 4075 27 linear_l65_2 = some linear_v65_2 := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k65_2 linear_r68 (linear_k65_3, linear_r69) [] linear_b68 linear_v65_3 mutated_kd65_2 mutated_s68 mutated_sl65_3)
theorem mutated_pl65_2 (tail : List Nat) : parseFields 4075 27 (linear_v65_2 ++ (125 :: tail)) = some (linear_l65_2, tail) := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k65_2 ++ (34 :: 58 :: (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))))) linear_k65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))) (linear_v65_3 ++ (125 :: tail)) tail linear_r68 linear_l65_3 (mutated_kp65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail))))) (mutated_p68 (44 :: (linear_v65_3 ++ (125 :: tail)))) (mutated_pl65_3 tail))
def linear_l65_1 : List (List Nat × Raw) := (linear_k65_1, linear_r67) :: linear_l65_2
def linear_v65_1 : List Nat := (linear_g169 ++ linear_b67) ++ (44 :: linear_v65_2)
theorem mutated_sl65_1 : serializeFields 4076 27 linear_l65_1 = some linear_v65_1 := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k65_1 linear_r67 (linear_k65_2, linear_r68) linear_l65_3 linear_b67 linear_v65_2 mutated_kd65_1 mutated_s67 mutated_sl65_2)
theorem mutated_pl65_1 (tail : List Nat) : parseFields 4076 27 (linear_v65_1 ++ (125 :: tail)) = some (linear_l65_1, tail) := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k65_1 ++ (34 :: 58 :: (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))))) linear_k65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))) (linear_v65_2 ++ (125 :: tail)) tail linear_r67 linear_l65_2 (mutated_kp65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail))))) (mutated_p67 (44 :: (linear_v65_2 ++ (125 :: tail)))) (mutated_pl65_2 tail))
def linear_l65_0 : List (List Nat × Raw) := (linear_k65_0, linear_r66) :: linear_l65_1
def linear_v65_0 : List Nat := (linear_g166 ++ linear_b66) ++ (44 :: linear_v65_1)
theorem mutated_sl65_0 : serializeFields 4077 27 linear_l65_0 = some linear_v65_0 := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k65_0 linear_r66 (linear_k65_1, linear_r67) linear_l65_2 linear_b66 linear_v65_1 mutated_kd65_0 mutated_s66 mutated_sl65_1)
theorem mutated_pl65_0 (tail : List Nat) : parseFields 4077 27 (linear_v65_0 ++ (125 :: tail)) = some (linear_l65_0, tail) := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) linear_k65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))) (linear_v65_1 ++ (125 :: tail)) tail linear_r66 linear_l65_1 (mutated_kp65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail))))) (mutated_p66 (44 :: (linear_v65_1 ++ (125 :: tail)))) (mutated_pl65_1 tail))
def linear_r65 : Raw := (.obj linear_l65_0)
def linear_b65 : List Nat := linear_g165 ++ (linear_v65_0 ++ linear_g177)
theorem mutated_o65 : orderedFields linear_l65_0 = true := by decide +kernel
theorem mutated_s65 : serializeRaw 4078 28 linear_r65 = some linear_b65 := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4077 27 linear_l65_0 linear_v65_0 mutated_o65 mutated_sl65_0)
theorem mutated_p65 (tail : List Nat) : parseRaw 4078 28 (linear_b65 ++ tail) = some (linear_r65, tail) := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4077 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) tail linear_l65_0 mutated_o65 (by simpa only [linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl65_0 tail)))
def linear_r71 : Raw := (.str [100,103,95,102,97,115,116,95,51])
def linear_b71 : List Nat := linear_g181
theorem mutated_s71 : serializeRaw 4075 27 linear_r71 = some linear_b71 := by decide +kernel
theorem mutated_p71 (tail : List Nat) : parseRaw 4075 27 (linear_b71 ++ tail) = some (linear_r71, tail) := by rfl
def linear_r72 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,51]),(.str [100,103,95,118,95,56,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b72 : List Nat := linear_g184
theorem mutated_s72 : serializeRaw 4074 27 linear_r72 = some linear_b72 := by decide +kernel
theorem mutated_p72 (tail : List Nat) : parseRaw 4074 27 (linear_b72 ++ tail) = some (linear_r72, tail) := by rfl
def linear_r73 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b73 : List Nat := linear_g187
theorem mutated_s73 : serializeRaw 4073 27 linear_r73 = some linear_b73 := by decide +kernel
theorem mutated_p73 (tail : List Nat) : parseRaw 4073 27 (linear_b73 ++ tail) = some (linear_r73, tail) := by rfl
def linear_r74 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,56,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b74 : List Nat := linear_g190
theorem mutated_s74 : serializeRaw 4072 27 linear_r74 = some linear_b74 := by decide +kernel
theorem mutated_p74 (tail : List Nat) : parseRaw 4072 27 (linear_b74 ++ tail) = some (linear_r74, tail) := by rfl
def linear_k70_0 : List Nat := [105,100]
theorem mutated_kd70_0 : stringBytes linear_k70_0 = true := by decide +kernel
theorem mutated_kp70_0 (tail : List Nat) : parseStringTail (linear_k70_0 ++ (34 :: 58 :: tail)) [] = some (linear_k70_0, 58 :: tail) := by rfl
def linear_k70_1 : List Nat := [111,112,115]
theorem mutated_kd70_1 : stringBytes linear_k70_1 = true := by decide +kernel
theorem mutated_kp70_1 (tail : List Nat) : parseStringTail (linear_k70_1 ++ (34 :: 58 :: tail)) [] = some (linear_k70_1, 58 :: tail) := by rfl
def linear_k70_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd70_2 : stringBytes linear_k70_2 = true := by decide +kernel
theorem mutated_kp70_2 (tail : List Nat) : parseStringTail (linear_k70_2 ++ (34 :: 58 :: tail)) [] = some (linear_k70_2, 58 :: tail) := by rfl
def linear_k70_3 : List Nat := [116,101,114,109]
theorem mutated_kd70_3 : stringBytes linear_k70_3 = true := by decide +kernel
theorem mutated_kp70_3 (tail : List Nat) : parseStringTail (linear_k70_3 ++ (34 :: 58 :: tail)) [] = some (linear_k70_3, 58 :: tail) := by rfl
def linear_l70_3 : List (List Nat × Raw) := [(linear_k70_3, linear_r74)]
def linear_v70_3 : List Nat := linear_g189 ++ linear_b74
theorem mutated_sl70_3 : serializeFields 4073 27 linear_l70_3 = some linear_v70_3 := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4072 27 linear_k70_3 linear_r74 linear_b74 mutated_kd70_3 mutated_s74)
theorem mutated_pl70_3 (tail : List Nat) : parseFields 4073 27 (linear_v70_3 ++ (125 :: tail)) = some (linear_l70_3, tail) := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4072 27 (linear_k70_3 ++ (34 :: 58 :: (linear_b74 ++ (125 :: tail)))) linear_k70_3 (linear_b74 ++ (125 :: tail)) tail linear_r74 (mutated_kp70_3 (linear_b74 ++ (125 :: tail))) (mutated_p74 (125 :: tail)))
def linear_l70_2 : List (List Nat × Raw) := (linear_k70_2, linear_r73) :: linear_l70_3
def linear_v70_2 : List Nat := (linear_g186 ++ linear_b73) ++ (44 :: linear_v70_3)
theorem mutated_sl70_2 : serializeFields 4074 27 linear_l70_2 = some linear_v70_2 := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k70_2 linear_r73 (linear_k70_3, linear_r74) [] linear_b73 linear_v70_3 mutated_kd70_2 mutated_s73 mutated_sl70_3)
theorem mutated_pl70_2 (tail : List Nat) : parseFields 4074 27 (linear_v70_2 ++ (125 :: tail)) = some (linear_l70_2, tail) := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k70_2 ++ (34 :: 58 :: (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))))) linear_k70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))) (linear_v70_3 ++ (125 :: tail)) tail linear_r73 linear_l70_3 (mutated_kp70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail))))) (mutated_p73 (44 :: (linear_v70_3 ++ (125 :: tail)))) (mutated_pl70_3 tail))
def linear_l70_1 : List (List Nat × Raw) := (linear_k70_1, linear_r72) :: linear_l70_2
def linear_v70_1 : List Nat := (linear_g183 ++ linear_b72) ++ (44 :: linear_v70_2)
theorem mutated_sl70_1 : serializeFields 4075 27 linear_l70_1 = some linear_v70_1 := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k70_1 linear_r72 (linear_k70_2, linear_r73) linear_l70_3 linear_b72 linear_v70_2 mutated_kd70_1 mutated_s72 mutated_sl70_2)
theorem mutated_pl70_1 (tail : List Nat) : parseFields 4075 27 (linear_v70_1 ++ (125 :: tail)) = some (linear_l70_1, tail) := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k70_1 ++ (34 :: 58 :: (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))))) linear_k70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))) (linear_v70_2 ++ (125 :: tail)) tail linear_r72 linear_l70_2 (mutated_kp70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail))))) (mutated_p72 (44 :: (linear_v70_2 ++ (125 :: tail)))) (mutated_pl70_2 tail))
def linear_l70_0 : List (List Nat × Raw) := (linear_k70_0, linear_r71) :: linear_l70_1
def linear_v70_0 : List Nat := (linear_g180 ++ linear_b71) ++ (44 :: linear_v70_1)
theorem mutated_sl70_0 : serializeFields 4076 27 linear_l70_0 = some linear_v70_0 := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k70_0 linear_r71 (linear_k70_1, linear_r72) linear_l70_2 linear_b71 linear_v70_1 mutated_kd70_0 mutated_s71 mutated_sl70_1)
theorem mutated_pl70_0 (tail : List Nat) : parseFields 4076 27 (linear_v70_0 ++ (125 :: tail)) = some (linear_l70_0, tail) := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) linear_k70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))) (linear_v70_1 ++ (125 :: tail)) tail linear_r71 linear_l70_1 (mutated_kp70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail))))) (mutated_p71 (44 :: (linear_v70_1 ++ (125 :: tail)))) (mutated_pl70_1 tail))
def linear_r70 : Raw := (.obj linear_l70_0)
def linear_b70 : List Nat := linear_g179 ++ (linear_v70_0 ++ linear_g191)
theorem mutated_o70 : orderedFields linear_l70_0 = true := by decide +kernel
theorem mutated_s70 : serializeRaw 4077 28 linear_r70 = some linear_b70 := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4076 27 linear_l70_0 linear_v70_0 mutated_o70 mutated_sl70_0)
theorem mutated_p70 (tail : List Nat) : parseRaw 4077 28 (linear_b70 ++ tail) = some (linear_r70, tail) := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4076 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) tail linear_l70_0 mutated_o70 (by simpa only [linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl70_0 tail)))
def linear_r76 : Raw := (.str [100,103,95,102,97,115,116,95,52])
def linear_b76 : List Nat := linear_g195
theorem mutated_s76 : serializeRaw 4074 27 linear_r76 = some linear_b76 := by decide +kernel
theorem mutated_p76 (tail : List Nat) : parseRaw 4074 27 (linear_b76 ++ tail) = some (linear_r76, tail) := by rfl
def linear_r78 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,49])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b78 : List Nat := linear_g199
theorem mutated_s78 : serializeRaw 4071 26 linear_r78 = some linear_b78 := by decide +kernel
theorem mutated_p78 (tail : List Nat) : parseRaw 4071 26 (linear_b78 ++ tail) = some (linear_r78, tail) := by rfl
def linear_r79 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49]),(.str [100,103,95,118,95,57,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,50])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b79 : List Nat := linear_g201
theorem mutated_s79 : serializeRaw 4070 26 linear_r79 = some linear_b79 := by decide +kernel
theorem mutated_p79 (tail : List Nat) : parseRaw 4070 26 (linear_b79 ++ tail) = some (linear_r79, tail) := by rfl
def linear_r80 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b80 : List Nat := linear_g203
theorem mutated_s80 : serializeRaw 4069 26 linear_r80 = some linear_b80 := by decide +kernel
theorem mutated_p80 (tail : List Nat) : parseRaw 4069 26 (linear_b80 ++ tail) = some (linear_r80, tail) := by rfl
def linear_r81 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,50])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,51])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b81 : List Nat := linear_g205
theorem mutated_s81 : serializeRaw 4068 26 linear_r81 = some linear_b81 := by decide +kernel
theorem mutated_p81 (tail : List Nat) : parseRaw 4068 26 (linear_b81 ++ tail) = some (linear_r81, tail) := by rfl
def linear_r82 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,56]),(.str [100,103,95,118,95,57,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,52])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b82 : List Nat := linear_g207
theorem mutated_s82 : serializeRaw 4067 26 linear_r82 = some linear_b82 := by decide +kernel
theorem mutated_p82 (tail : List Nat) : parseRaw 4067 26 (linear_b82 ++ tail) = some (linear_r82, tail) := by rfl
def linear_r83 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,53])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b83 : List Nat := linear_g209
theorem mutated_s83 : serializeRaw 4066 26 linear_r83 = some linear_b83 := by decide +kernel
theorem mutated_p83 (tail : List Nat) : parseRaw 4066 26 (linear_b83 ++ tail) = some (linear_r83, tail) := by rfl
def linear_r84 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,48]),(.str [100,103,95,118,95,57,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,54])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b84 : List Nat := linear_g211
theorem mutated_s84 : serializeRaw 4065 26 linear_r84 = some linear_b84 := by decide +kernel
theorem mutated_p84 (tail : List Nat) : parseRaw 4065 26 (linear_b84 ++ tail) = some (linear_r84, tail) := by rfl
def linear_l77_6 : List Raw := [linear_r84]
def linear_v77_6 : List Nat := linear_b84
theorem mutated_sl77_6 : serializeItems 4066 26 linear_l77_6 = some linear_v77_6 := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4065 26 linear_r84 linear_b84 mutated_s84)
theorem mutated_pl77_6 (tail : List Nat) : parseItems 4066 26 (linear_v77_6 ++ (93 :: tail)) = some (linear_l77_6, tail) := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4065 26 (linear_b84 ++ (93 :: tail)) tail linear_r84 (mutated_p84 (93 :: tail)))
def linear_l77_5 : List Raw := linear_r83 :: linear_l77_6
def linear_v77_5 : List Nat := (linear_b83) ++ (44 :: linear_v77_6)
theorem mutated_sl77_5 : serializeItems 4067 26 linear_l77_5 = some linear_v77_5 := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r83 linear_r84 [] linear_b83 linear_v77_6 mutated_s83 mutated_sl77_6)
theorem mutated_pl77_5 (tail : List Nat) : parseItems 4067 26 (linear_v77_5 ++ (93 :: tail)) = some (linear_l77_5, tail) := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b83 ++ (44 :: (linear_v77_6 ++ (93 :: tail)))) (linear_v77_6 ++ (93 :: tail)) tail linear_r83 linear_l77_6 (mutated_p83 (44 :: (linear_v77_6 ++ (93 :: tail)))) (mutated_pl77_6 tail))
def linear_l77_4 : List Raw := linear_r82 :: linear_l77_5
def linear_v77_4 : List Nat := (linear_b82) ++ (44 :: linear_v77_5)
theorem mutated_sl77_4 : serializeItems 4068 26 linear_l77_4 = some linear_v77_4 := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r82 linear_r83 linear_l77_6 linear_b82 linear_v77_5 mutated_s82 mutated_sl77_5)
theorem mutated_pl77_4 (tail : List Nat) : parseItems 4068 26 (linear_v77_4 ++ (93 :: tail)) = some (linear_l77_4, tail) := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b82 ++ (44 :: (linear_v77_5 ++ (93 :: tail)))) (linear_v77_5 ++ (93 :: tail)) tail linear_r82 linear_l77_5 (mutated_p82 (44 :: (linear_v77_5 ++ (93 :: tail)))) (mutated_pl77_5 tail))
def linear_l77_3 : List Raw := linear_r81 :: linear_l77_4
def linear_v77_3 : List Nat := (linear_b81) ++ (44 :: linear_v77_4)
theorem mutated_sl77_3 : serializeItems 4069 26 linear_l77_3 = some linear_v77_3 := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r81 linear_r82 linear_l77_5 linear_b81 linear_v77_4 mutated_s81 mutated_sl77_4)
theorem mutated_pl77_3 (tail : List Nat) : parseItems 4069 26 (linear_v77_3 ++ (93 :: tail)) = some (linear_l77_3, tail) := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b81 ++ (44 :: (linear_v77_4 ++ (93 :: tail)))) (linear_v77_4 ++ (93 :: tail)) tail linear_r81 linear_l77_4 (mutated_p81 (44 :: (linear_v77_4 ++ (93 :: tail)))) (mutated_pl77_4 tail))
def linear_l77_2 : List Raw := linear_r80 :: linear_l77_3
def linear_v77_2 : List Nat := (linear_b80) ++ (44 :: linear_v77_3)
theorem mutated_sl77_2 : serializeItems 4070 26 linear_l77_2 = some linear_v77_2 := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r80 linear_r81 linear_l77_4 linear_b80 linear_v77_3 mutated_s80 mutated_sl77_3)
theorem mutated_pl77_2 (tail : List Nat) : parseItems 4070 26 (linear_v77_2 ++ (93 :: tail)) = some (linear_l77_2, tail) := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b80 ++ (44 :: (linear_v77_3 ++ (93 :: tail)))) (linear_v77_3 ++ (93 :: tail)) tail linear_r80 linear_l77_3 (mutated_p80 (44 :: (linear_v77_3 ++ (93 :: tail)))) (mutated_pl77_3 tail))
def linear_l77_1 : List Raw := linear_r79 :: linear_l77_2
def linear_v77_1 : List Nat := (linear_b79) ++ (44 :: linear_v77_2)
theorem mutated_sl77_1 : serializeItems 4071 26 linear_l77_1 = some linear_v77_1 := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r79 linear_r80 linear_l77_3 linear_b79 linear_v77_2 mutated_s79 mutated_sl77_2)
theorem mutated_pl77_1 (tail : List Nat) : parseItems 4071 26 (linear_v77_1 ++ (93 :: tail)) = some (linear_l77_1, tail) := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b79 ++ (44 :: (linear_v77_2 ++ (93 :: tail)))) (linear_v77_2 ++ (93 :: tail)) tail linear_r79 linear_l77_2 (mutated_p79 (44 :: (linear_v77_2 ++ (93 :: tail)))) (mutated_pl77_2 tail))
def linear_l77_0 : List Raw := linear_r78 :: linear_l77_1
def linear_v77_0 : List Nat := (linear_b78) ++ (44 :: linear_v77_1)
theorem mutated_sl77_0 : serializeItems 4072 26 linear_l77_0 = some linear_v77_0 := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r78 linear_r79 linear_l77_2 linear_b78 linear_v77_1 mutated_s78 mutated_sl77_1)
theorem mutated_pl77_0 (tail : List Nat) : parseItems 4072 26 (linear_v77_0 ++ (93 :: tail)) = some (linear_l77_0, tail) := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b78 ++ (44 :: (linear_v77_1 ++ (93 :: tail)))) (linear_v77_1 ++ (93 :: tail)) tail linear_r78 linear_l77_1 (mutated_p78 (44 :: (linear_v77_1 ++ (93 :: tail)))) (mutated_pl77_1 tail))
def linear_r77 : Raw := (.arr linear_l77_0)
def linear_b77 : List Nat := linear_g198 ++ (linear_v77_0 ++ linear_g212)
theorem mutated_s77 : serializeRaw 4073 27 linear_r77 = some linear_b77 := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4072 26 linear_l77_0 linear_v77_0 mutated_sl77_0)
theorem mutated_p77 (tail : List Nat) : parseRaw 4073 27 (linear_b77 ++ tail) = some (linear_r77, tail) := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4072 26 (linear_v77_0 ++ (93 :: tail)) tail linear_l77_0 (by intro h; cases h) (mutated_pl77_0 tail))
def linear_r85 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b85 : List Nat := linear_g215
theorem mutated_s85 : serializeRaw 4072 27 linear_r85 = some linear_b85 := by decide +kernel
theorem mutated_p85 (tail : List Nat) : parseRaw 4072 27 (linear_b85 ++ tail) = some (linear_r85, tail) := by rfl
def linear_r86 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,53]),(.str [100,103,95,118,95,56,54]),(.str [100,103,95,118,95,56,55]),(.str [100,103,95,118,95,57,52]),(.str [100,103,95,118,95,56,57]),(.str [100,103,95,118,95,57,54])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b86 : List Nat := linear_g218
theorem mutated_s86 : serializeRaw 4071 27 linear_r86 = some linear_b86 := by decide +kernel
theorem mutated_p86 (tail : List Nat) : parseRaw 4071 27 (linear_b86 ++ tail) = some (linear_r86, tail) := by rfl
def linear_k75_0 : List Nat := [105,100]
theorem mutated_kd75_0 : stringBytes linear_k75_0 = true := by decide +kernel
theorem mutated_kp75_0 (tail : List Nat) : parseStringTail (linear_k75_0 ++ (34 :: 58 :: tail)) [] = some (linear_k75_0, 58 :: tail) := by rfl
def linear_k75_1 : List Nat := [111,112,115]
theorem mutated_kd75_1 : stringBytes linear_k75_1 = true := by decide +kernel
theorem mutated_kp75_1 (tail : List Nat) : parseStringTail (linear_k75_1 ++ (34 :: 58 :: tail)) [] = some (linear_k75_1, 58 :: tail) := by rfl
def linear_k75_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd75_2 : stringBytes linear_k75_2 = true := by decide +kernel
theorem mutated_kp75_2 (tail : List Nat) : parseStringTail (linear_k75_2 ++ (34 :: 58 :: tail)) [] = some (linear_k75_2, 58 :: tail) := by rfl
def linear_k75_3 : List Nat := [116,101,114,109]
theorem mutated_kd75_3 : stringBytes linear_k75_3 = true := by decide +kernel
theorem mutated_kp75_3 (tail : List Nat) : parseStringTail (linear_k75_3 ++ (34 :: 58 :: tail)) [] = some (linear_k75_3, 58 :: tail) := by rfl
def linear_l75_3 : List (List Nat × Raw) := [(linear_k75_3, linear_r86)]
def linear_v75_3 : List Nat := linear_g217 ++ linear_b86
theorem mutated_sl75_3 : serializeFields 4072 27 linear_l75_3 = some linear_v75_3 := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4071 27 linear_k75_3 linear_r86 linear_b86 mutated_kd75_3 mutated_s86)
theorem mutated_pl75_3 (tail : List Nat) : parseFields 4072 27 (linear_v75_3 ++ (125 :: tail)) = some (linear_l75_3, tail) := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4071 27 (linear_k75_3 ++ (34 :: 58 :: (linear_b86 ++ (125 :: tail)))) linear_k75_3 (linear_b86 ++ (125 :: tail)) tail linear_r86 (mutated_kp75_3 (linear_b86 ++ (125 :: tail))) (mutated_p86 (125 :: tail)))
def linear_l75_2 : List (List Nat × Raw) := (linear_k75_2, linear_r85) :: linear_l75_3
def linear_v75_2 : List Nat := (linear_g214 ++ linear_b85) ++ (44 :: linear_v75_3)
theorem mutated_sl75_2 : serializeFields 4073 27 linear_l75_2 = some linear_v75_2 := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k75_2 linear_r85 (linear_k75_3, linear_r86) [] linear_b85 linear_v75_3 mutated_kd75_2 mutated_s85 mutated_sl75_3)
theorem mutated_pl75_2 (tail : List Nat) : parseFields 4073 27 (linear_v75_2 ++ (125 :: tail)) = some (linear_l75_2, tail) := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k75_2 ++ (34 :: 58 :: (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))))) linear_k75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))) (linear_v75_3 ++ (125 :: tail)) tail linear_r85 linear_l75_3 (mutated_kp75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail))))) (mutated_p85 (44 :: (linear_v75_3 ++ (125 :: tail)))) (mutated_pl75_3 tail))
def linear_l75_1 : List (List Nat × Raw) := (linear_k75_1, linear_r77) :: linear_l75_2
def linear_v75_1 : List Nat := (linear_g197 ++ linear_b77) ++ (44 :: linear_v75_2)
theorem mutated_sl75_1 : serializeFields 4074 27 linear_l75_1 = some linear_v75_1 := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k75_1 linear_r77 (linear_k75_2, linear_r85) linear_l75_3 linear_b77 linear_v75_2 mutated_kd75_1 mutated_s77 mutated_sl75_2)
theorem mutated_pl75_1 (tail : List Nat) : parseFields 4074 27 (linear_v75_1 ++ (125 :: tail)) = some (linear_l75_1, tail) := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k75_1 ++ (34 :: 58 :: (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))))) linear_k75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))) (linear_v75_2 ++ (125 :: tail)) tail linear_r77 linear_l75_2 (mutated_kp75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail))))) (mutated_p77 (44 :: (linear_v75_2 ++ (125 :: tail)))) (mutated_pl75_2 tail))
def linear_l75_0 : List (List Nat × Raw) := (linear_k75_0, linear_r76) :: linear_l75_1
def linear_v75_0 : List Nat := (linear_g194 ++ linear_b76) ++ (44 :: linear_v75_1)
theorem mutated_sl75_0 : serializeFields 4075 27 linear_l75_0 = some linear_v75_0 := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k75_0 linear_r76 (linear_k75_1, linear_r77) linear_l75_2 linear_b76 linear_v75_1 mutated_kd75_0 mutated_s76 mutated_sl75_1)
theorem mutated_pl75_0 (tail : List Nat) : parseFields 4075 27 (linear_v75_0 ++ (125 :: tail)) = some (linear_l75_0, tail) := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) linear_k75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))) (linear_v75_1 ++ (125 :: tail)) tail linear_r76 linear_l75_1 (mutated_kp75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail))))) (mutated_p76 (44 :: (linear_v75_1 ++ (125 :: tail)))) (mutated_pl75_1 tail))
def linear_r75 : Raw := (.obj linear_l75_0)
def linear_b75 : List Nat := linear_g193 ++ (linear_v75_0 ++ linear_g219)
theorem mutated_o75 : orderedFields linear_l75_0 = true := by decide +kernel
theorem mutated_s75 : serializeRaw 4076 28 linear_r75 = some linear_b75 := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4075 27 linear_l75_0 linear_v75_0 mutated_o75 mutated_sl75_0)
theorem mutated_p75 (tail : List Nat) : parseRaw 4076 28 (linear_b75 ++ tail) = some (linear_r75, tail) := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4075 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) tail linear_l75_0 mutated_o75 (by simpa only [linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl75_0 tail)))
def linear_r88 : Raw := (.str [100,103,95,102,97,115,116,95,53])
def linear_b88 : List Nat := linear_g223
theorem mutated_s88 : serializeRaw 4073 27 linear_r88 = some linear_b88 := by decide +kernel
theorem mutated_p88 (tail : List Nat) : parseRaw 4073 27 (linear_b88 ++ tail) = some (linear_r88, tail) := by rfl
def linear_r89 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b89 : List Nat := linear_g226
theorem mutated_s89 : serializeRaw 4072 27 linear_r89 = some linear_b89 := by decide +kernel
theorem mutated_p89 (tail : List Nat) : parseRaw 4072 27 (linear_b89 ++ tail) = some (linear_r89, tail) := by rfl
def linear_r90 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,48])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b90 : List Nat := linear_g229
theorem mutated_s90 : serializeRaw 4071 27 linear_r90 = some linear_b90 := by decide +kernel
theorem mutated_p90 (tail : List Nat) : parseRaw 4071 27 (linear_b90 ++ tail) = some (linear_r90, tail) := by rfl
def linear_r91 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,48,48])]))])
def linear_b91 : List Nat := linear_g232
theorem mutated_s91 : serializeRaw 4070 27 linear_r91 = some linear_b91 := by decide +kernel
theorem mutated_p91 (tail : List Nat) : parseRaw 4070 27 (linear_b91 ++ tail) = some (linear_r91, tail) := by rfl
def linear_k87_0 : List Nat := [105,100]
theorem mutated_kd87_0 : stringBytes linear_k87_0 = true := by decide +kernel
theorem mutated_kp87_0 (tail : List Nat) : parseStringTail (linear_k87_0 ++ (34 :: 58 :: tail)) [] = some (linear_k87_0, 58 :: tail) := by rfl
def linear_k87_1 : List Nat := [111,112,115]
theorem mutated_kd87_1 : stringBytes linear_k87_1 = true := by decide +kernel
theorem mutated_kp87_1 (tail : List Nat) : parseStringTail (linear_k87_1 ++ (34 :: 58 :: tail)) [] = some (linear_k87_1, 58 :: tail) := by rfl
def linear_k87_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd87_2 : stringBytes linear_k87_2 = true := by decide +kernel
theorem mutated_kp87_2 (tail : List Nat) : parseStringTail (linear_k87_2 ++ (34 :: 58 :: tail)) [] = some (linear_k87_2, 58 :: tail) := by rfl
def linear_k87_3 : List Nat := [116,101,114,109]
theorem mutated_kd87_3 : stringBytes linear_k87_3 = true := by decide +kernel
theorem mutated_kp87_3 (tail : List Nat) : parseStringTail (linear_k87_3 ++ (34 :: 58 :: tail)) [] = some (linear_k87_3, 58 :: tail) := by rfl
def linear_l87_3 : List (List Nat × Raw) := [(linear_k87_3, linear_r91)]
def linear_v87_3 : List Nat := linear_g231 ++ linear_b91
theorem mutated_sl87_3 : serializeFields 4071 27 linear_l87_3 = some linear_v87_3 := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4070 27 linear_k87_3 linear_r91 linear_b91 mutated_kd87_3 mutated_s91)
theorem mutated_pl87_3 (tail : List Nat) : parseFields 4071 27 (linear_v87_3 ++ (125 :: tail)) = some (linear_l87_3, tail) := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4070 27 (linear_k87_3 ++ (34 :: 58 :: (linear_b91 ++ (125 :: tail)))) linear_k87_3 (linear_b91 ++ (125 :: tail)) tail linear_r91 (mutated_kp87_3 (linear_b91 ++ (125 :: tail))) (mutated_p91 (125 :: tail)))
def linear_l87_2 : List (List Nat × Raw) := (linear_k87_2, linear_r90) :: linear_l87_3
def linear_v87_2 : List Nat := (linear_g228 ++ linear_b90) ++ (44 :: linear_v87_3)
theorem mutated_sl87_2 : serializeFields 4072 27 linear_l87_2 = some linear_v87_2 := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k87_2 linear_r90 (linear_k87_3, linear_r91) [] linear_b90 linear_v87_3 mutated_kd87_2 mutated_s90 mutated_sl87_3)
theorem mutated_pl87_2 (tail : List Nat) : parseFields 4072 27 (linear_v87_2 ++ (125 :: tail)) = some (linear_l87_2, tail) := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k87_2 ++ (34 :: 58 :: (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))))) linear_k87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))) (linear_v87_3 ++ (125 :: tail)) tail linear_r90 linear_l87_3 (mutated_kp87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail))))) (mutated_p90 (44 :: (linear_v87_3 ++ (125 :: tail)))) (mutated_pl87_3 tail))
def linear_l87_1 : List (List Nat × Raw) := (linear_k87_1, linear_r89) :: linear_l87_2
def linear_v87_1 : List Nat := (linear_g225 ++ linear_b89) ++ (44 :: linear_v87_2)
theorem mutated_sl87_1 : serializeFields 4073 27 linear_l87_1 = some linear_v87_1 := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k87_1 linear_r89 (linear_k87_2, linear_r90) linear_l87_3 linear_b89 linear_v87_2 mutated_kd87_1 mutated_s89 mutated_sl87_2)
theorem mutated_pl87_1 (tail : List Nat) : parseFields 4073 27 (linear_v87_1 ++ (125 :: tail)) = some (linear_l87_1, tail) := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k87_1 ++ (34 :: 58 :: (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))))) linear_k87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))) (linear_v87_2 ++ (125 :: tail)) tail linear_r89 linear_l87_2 (mutated_kp87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail))))) (mutated_p89 (44 :: (linear_v87_2 ++ (125 :: tail)))) (mutated_pl87_2 tail))
def linear_l87_0 : List (List Nat × Raw) := (linear_k87_0, linear_r88) :: linear_l87_1
def linear_v87_0 : List Nat := (linear_g222 ++ linear_b88) ++ (44 :: linear_v87_1)
theorem mutated_sl87_0 : serializeFields 4074 27 linear_l87_0 = some linear_v87_0 := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k87_0 linear_r88 (linear_k87_1, linear_r89) linear_l87_2 linear_b88 linear_v87_1 mutated_kd87_0 mutated_s88 mutated_sl87_1)
theorem mutated_pl87_0 (tail : List Nat) : parseFields 4074 27 (linear_v87_0 ++ (125 :: tail)) = some (linear_l87_0, tail) := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) linear_k87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))) (linear_v87_1 ++ (125 :: tail)) tail linear_r88 linear_l87_1 (mutated_kp87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail))))) (mutated_p88 (44 :: (linear_v87_1 ++ (125 :: tail)))) (mutated_pl87_1 tail))
def linear_r87 : Raw := (.obj linear_l87_0)
def linear_b87 : List Nat := linear_g221 ++ (linear_v87_0 ++ linear_g233)
theorem mutated_o87 : orderedFields linear_l87_0 = true := by decide +kernel
theorem mutated_s87 : serializeRaw 4075 28 linear_r87 = some linear_b87 := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4074 27 linear_l87_0 linear_v87_0 mutated_o87 mutated_sl87_0)
theorem mutated_p87 (tail : List Nat) : parseRaw 4075 28 (linear_b87 ++ tail) = some (linear_r87, tail) := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4074 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) tail linear_l87_0 mutated_o87 (by simpa only [linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl87_0 tail)))
def linear_r93 : Raw := (.str [100,103,95,115,108,111,119,95,48])
def linear_b93 : List Nat := linear_g237
theorem mutated_s93 : serializeRaw 4072 27 linear_r93 = some linear_b93 := by decide +kernel
theorem mutated_p93 (tail : List Nat) : parseRaw 4072 27 (linear_b93 ++ tail) = some (linear_r93, tail) := by rfl
def linear_r94 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,56]),(.str [100,103,95,118,95,49,48,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,57])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b94 : List Nat := linear_g240
theorem mutated_s94 : serializeRaw 4071 27 linear_r94 = some linear_b94 := by decide +kernel
theorem mutated_p94 (tail : List Nat) : parseRaw 4071 27 (linear_b94 ++ tail) = some (linear_r94, tail) := by rfl
def linear_r95 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b95 : List Nat := linear_g243
theorem mutated_s95 : serializeRaw 4070 27 linear_r95 = some linear_b95 := by decide +kernel
theorem mutated_p95 (tail : List Nat) : parseRaw 4070 27 (linear_b95 ++ tail) = some (linear_r95, tail) := by rfl
def linear_r96 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,48,57])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))]))])
def linear_b96 : List Nat := linear_g246
theorem mutated_s96 : serializeRaw 4069 27 linear_r96 = some linear_b96 := by decide +kernel
theorem mutated_p96 (tail : List Nat) : parseRaw 4069 27 (linear_b96 ++ tail) = some (linear_r96, tail) := by rfl
def linear_k92_0 : List Nat := [105,100]
theorem mutated_kd92_0 : stringBytes linear_k92_0 = true := by decide +kernel
theorem mutated_kp92_0 (tail : List Nat) : parseStringTail (linear_k92_0 ++ (34 :: 58 :: tail)) [] = some (linear_k92_0, 58 :: tail) := by rfl
def linear_k92_1 : List Nat := [111,112,115]
theorem mutated_kd92_1 : stringBytes linear_k92_1 = true := by decide +kernel
theorem mutated_kp92_1 (tail : List Nat) : parseStringTail (linear_k92_1 ++ (34 :: 58 :: tail)) [] = some (linear_k92_1, 58 :: tail) := by rfl
def linear_k92_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd92_2 : stringBytes linear_k92_2 = true := by decide +kernel
theorem mutated_kp92_2 (tail : List Nat) : parseStringTail (linear_k92_2 ++ (34 :: 58 :: tail)) [] = some (linear_k92_2, 58 :: tail) := by rfl
def linear_k92_3 : List Nat := [116,101,114,109]
theorem mutated_kd92_3 : stringBytes linear_k92_3 = true := by decide +kernel
theorem mutated_kp92_3 (tail : List Nat) : parseStringTail (linear_k92_3 ++ (34 :: 58 :: tail)) [] = some (linear_k92_3, 58 :: tail) := by rfl
def linear_l92_3 : List (List Nat × Raw) := [(linear_k92_3, linear_r96)]
def linear_v92_3 : List Nat := linear_g245 ++ linear_b96
theorem mutated_sl92_3 : serializeFields 4070 27 linear_l92_3 = some linear_v92_3 := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4069 27 linear_k92_3 linear_r96 linear_b96 mutated_kd92_3 mutated_s96)
theorem mutated_pl92_3 (tail : List Nat) : parseFields 4070 27 (linear_v92_3 ++ (125 :: tail)) = some (linear_l92_3, tail) := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4069 27 (linear_k92_3 ++ (34 :: 58 :: (linear_b96 ++ (125 :: tail)))) linear_k92_3 (linear_b96 ++ (125 :: tail)) tail linear_r96 (mutated_kp92_3 (linear_b96 ++ (125 :: tail))) (mutated_p96 (125 :: tail)))
def linear_l92_2 : List (List Nat × Raw) := (linear_k92_2, linear_r95) :: linear_l92_3
def linear_v92_2 : List Nat := (linear_g242 ++ linear_b95) ++ (44 :: linear_v92_3)
theorem mutated_sl92_2 : serializeFields 4071 27 linear_l92_2 = some linear_v92_2 := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k92_2 linear_r95 (linear_k92_3, linear_r96) [] linear_b95 linear_v92_3 mutated_kd92_2 mutated_s95 mutated_sl92_3)
theorem mutated_pl92_2 (tail : List Nat) : parseFields 4071 27 (linear_v92_2 ++ (125 :: tail)) = some (linear_l92_2, tail) := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k92_2 ++ (34 :: 58 :: (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))))) linear_k92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))) (linear_v92_3 ++ (125 :: tail)) tail linear_r95 linear_l92_3 (mutated_kp92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail))))) (mutated_p95 (44 :: (linear_v92_3 ++ (125 :: tail)))) (mutated_pl92_3 tail))
def linear_l92_1 : List (List Nat × Raw) := (linear_k92_1, linear_r94) :: linear_l92_2
def linear_v92_1 : List Nat := (linear_g239 ++ linear_b94) ++ (44 :: linear_v92_2)
theorem mutated_sl92_1 : serializeFields 4072 27 linear_l92_1 = some linear_v92_1 := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k92_1 linear_r94 (linear_k92_2, linear_r95) linear_l92_3 linear_b94 linear_v92_2 mutated_kd92_1 mutated_s94 mutated_sl92_2)
theorem mutated_pl92_1 (tail : List Nat) : parseFields 4072 27 (linear_v92_1 ++ (125 :: tail)) = some (linear_l92_1, tail) := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k92_1 ++ (34 :: 58 :: (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))))) linear_k92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))) (linear_v92_2 ++ (125 :: tail)) tail linear_r94 linear_l92_2 (mutated_kp92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail))))) (mutated_p94 (44 :: (linear_v92_2 ++ (125 :: tail)))) (mutated_pl92_2 tail))
def linear_l92_0 : List (List Nat × Raw) := (linear_k92_0, linear_r93) :: linear_l92_1
def linear_v92_0 : List Nat := (linear_g236 ++ linear_b93) ++ (44 :: linear_v92_1)
theorem mutated_sl92_0 : serializeFields 4073 27 linear_l92_0 = some linear_v92_0 := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k92_0 linear_r93 (linear_k92_1, linear_r94) linear_l92_2 linear_b93 linear_v92_1 mutated_kd92_0 mutated_s93 mutated_sl92_1)
theorem mutated_pl92_0 (tail : List Nat) : parseFields 4073 27 (linear_v92_0 ++ (125 :: tail)) = some (linear_l92_0, tail) := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) linear_k92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))) (linear_v92_1 ++ (125 :: tail)) tail linear_r93 linear_l92_1 (mutated_kp92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail))))) (mutated_p93 (44 :: (linear_v92_1 ++ (125 :: tail)))) (mutated_pl92_1 tail))
def linear_r92 : Raw := (.obj linear_l92_0)
def linear_b92 : List Nat := linear_g235 ++ (linear_v92_0 ++ linear_g247)
theorem mutated_o92 : orderedFields linear_l92_0 = true := by decide +kernel
theorem mutated_s92 : serializeRaw 4074 28 linear_r92 = some linear_b92 := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4073 27 linear_l92_0 linear_v92_0 mutated_o92 mutated_sl92_0)
theorem mutated_p92 (tail : List Nat) : parseRaw 4074 28 (linear_b92 ++ tail) = some (linear_r92, tail) := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4073 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) tail linear_l92_0 mutated_o92 (by simpa only [linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl92_0 tail)))
def linear_r98 : Raw := (.str [100,103,95,115,108,111,119,95,49])
def linear_b98 : List Nat := linear_g251
theorem mutated_s98 : serializeRaw 4071 27 linear_r98 = some linear_b98 := by decide +kernel
theorem mutated_p98 (tail : List Nat) : parseRaw 4071 27 (linear_b98 ++ tail) = some (linear_r98, tail) := by rfl
def linear_r100 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,53])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b100 : List Nat := linear_g255
theorem mutated_s100 : serializeRaw 4068 26 linear_r100 = some linear_b100 := by decide +kernel
theorem mutated_p100 (tail : List Nat) : parseRaw 4068 26 (linear_b100 ++ tail) = some (linear_r100, tail) := by rfl
def linear_r101 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,53]),(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,54])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b101 : List Nat := linear_g257
theorem mutated_s101 : serializeRaw 4067 26 linear_r101 = some linear_b101 := by decide +kernel
theorem mutated_p101 (tail : List Nat) : parseRaw 4067 26 (linear_b101 ++ tail) = some (linear_r101, tail) := by rfl
def linear_r102 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b102 : List Nat := linear_g259
theorem mutated_s102 : serializeRaw 4066 26 linear_r102 = some linear_b102 := by decide +kernel
theorem mutated_p102 (tail : List Nat) : parseRaw 4066 26 (linear_b102 ++ tail) = some (linear_r102, tail) := by rfl
def linear_r103 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,56])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b103 : List Nat := linear_g261
theorem mutated_s103 : serializeRaw 4065 26 linear_r103 = some linear_b103 := by decide +kernel
theorem mutated_p103 (tail : List Nat) : parseRaw 4065 26 (linear_b103 ++ tail) = some (linear_r103, tail) := by rfl
def linear_r104 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,55]),(.str [100,103,95,118,95,49,49,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,57])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b104 : List Nat := linear_g263
theorem mutated_s104 : serializeRaw 4064 26 linear_r104 = some linear_b104 := by decide +kernel
theorem mutated_p104 (tail : List Nat) : parseRaw 4064 26 (linear_b104 ++ tail) = some (linear_r104, tail) := by rfl
def linear_r105 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,57])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,48])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b105 : List Nat := linear_g265
theorem mutated_s105 : serializeRaw 4063 26 linear_r105 = some linear_b105 := by decide +kernel
theorem mutated_p105 (tail : List Nat) : parseRaw 4063 26 (linear_b105 ++ tail) = some (linear_r105, tail) := by rfl
def linear_r106 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,49])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b106 : List Nat := linear_g267
theorem mutated_s106 : serializeRaw 4062 26 linear_r106 = some linear_b106 := by decide +kernel
theorem mutated_p106 (tail : List Nat) : parseRaw 4062 26 (linear_b106 ++ tail) = some (linear_r106, tail) := by rfl
def linear_r107 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49]),(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b107 : List Nat := linear_g269
theorem mutated_s107 : serializeRaw 4061 26 linear_r107 = some linear_b107 := by decide +kernel
theorem mutated_p107 (tail : List Nat) : parseRaw 4061 26 (linear_b107 ++ tail) = some (linear_r107, tail) := by rfl
def linear_r108 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b108 : List Nat := linear_g271
theorem mutated_s108 : serializeRaw 4060 26 linear_r108 = some linear_b108 := by decide +kernel
theorem mutated_p108 (tail : List Nat) : parseRaw 4060 26 (linear_b108 ++ tail) = some (linear_r108, tail) := by rfl
def linear_r109 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b109 : List Nat := linear_g273
theorem mutated_s109 : serializeRaw 4059 26 linear_r109 = some linear_b109 := by decide +kernel
theorem mutated_p109 (tail : List Nat) : parseRaw 4059 26 (linear_b109 ++ tail) = some (linear_r109, tail) := by rfl
def linear_r110 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b110 : List Nat := linear_g275
theorem mutated_s110 : serializeRaw 4058 26 linear_r110 = some linear_b110 := by decide +kernel
theorem mutated_p110 (tail : List Nat) : parseRaw 4058 26 (linear_b110 ++ tail) = some (linear_r110, tail) := by rfl
def linear_l99_10 : List Raw := [linear_r110]
def linear_v99_10 : List Nat := linear_b110
theorem mutated_sl99_10 : serializeItems 4059 26 linear_l99_10 = some linear_v99_10 := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4058 26 linear_r110 linear_b110 mutated_s110)
theorem mutated_pl99_10 (tail : List Nat) : parseItems 4059 26 (linear_v99_10 ++ (93 :: tail)) = some (linear_l99_10, tail) := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4058 26 (linear_b110 ++ (93 :: tail)) tail linear_r110 (mutated_p110 (93 :: tail)))
def linear_l99_9 : List Raw := linear_r109 :: linear_l99_10
def linear_v99_9 : List Nat := (linear_b109) ++ (44 :: linear_v99_10)
theorem mutated_sl99_9 : serializeItems 4060 26 linear_l99_9 = some linear_v99_9 := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4059 26 linear_r109 linear_r110 [] linear_b109 linear_v99_10 mutated_s109 mutated_sl99_10)
theorem mutated_pl99_9 (tail : List Nat) : parseItems 4060 26 (linear_v99_9 ++ (93 :: tail)) = some (linear_l99_9, tail) := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4059 26 (linear_b109 ++ (44 :: (linear_v99_10 ++ (93 :: tail)))) (linear_v99_10 ++ (93 :: tail)) tail linear_r109 linear_l99_10 (mutated_p109 (44 :: (linear_v99_10 ++ (93 :: tail)))) (mutated_pl99_10 tail))
def linear_l99_8 : List Raw := linear_r108 :: linear_l99_9
def linear_v99_8 : List Nat := (linear_b108) ++ (44 :: linear_v99_9)
theorem mutated_sl99_8 : serializeItems 4061 26 linear_l99_8 = some linear_v99_8 := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r108 linear_r109 linear_l99_10 linear_b108 linear_v99_9 mutated_s108 mutated_sl99_9)
theorem mutated_pl99_8 (tail : List Nat) : parseItems 4061 26 (linear_v99_8 ++ (93 :: tail)) = some (linear_l99_8, tail) := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b108 ++ (44 :: (linear_v99_9 ++ (93 :: tail)))) (linear_v99_9 ++ (93 :: tail)) tail linear_r108 linear_l99_9 (mutated_p108 (44 :: (linear_v99_9 ++ (93 :: tail)))) (mutated_pl99_9 tail))
def linear_l99_7 : List Raw := linear_r107 :: linear_l99_8
def linear_v99_7 : List Nat := (linear_b107) ++ (44 :: linear_v99_8)
theorem mutated_sl99_7 : serializeItems 4062 26 linear_l99_7 = some linear_v99_7 := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r107 linear_r108 linear_l99_9 linear_b107 linear_v99_8 mutated_s107 mutated_sl99_8)
theorem mutated_pl99_7 (tail : List Nat) : parseItems 4062 26 (linear_v99_7 ++ (93 :: tail)) = some (linear_l99_7, tail) := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b107 ++ (44 :: (linear_v99_8 ++ (93 :: tail)))) (linear_v99_8 ++ (93 :: tail)) tail linear_r107 linear_l99_8 (mutated_p107 (44 :: (linear_v99_8 ++ (93 :: tail)))) (mutated_pl99_8 tail))
def linear_l99_6 : List Raw := linear_r106 :: linear_l99_7
def linear_v99_6 : List Nat := (linear_b106) ++ (44 :: linear_v99_7)
theorem mutated_sl99_6 : serializeItems 4063 26 linear_l99_6 = some linear_v99_6 := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r106 linear_r107 linear_l99_8 linear_b106 linear_v99_7 mutated_s106 mutated_sl99_7)
theorem mutated_pl99_6 (tail : List Nat) : parseItems 4063 26 (linear_v99_6 ++ (93 :: tail)) = some (linear_l99_6, tail) := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b106 ++ (44 :: (linear_v99_7 ++ (93 :: tail)))) (linear_v99_7 ++ (93 :: tail)) tail linear_r106 linear_l99_7 (mutated_p106 (44 :: (linear_v99_7 ++ (93 :: tail)))) (mutated_pl99_7 tail))
def linear_l99_5 : List Raw := linear_r105 :: linear_l99_6
def linear_v99_5 : List Nat := (linear_b105) ++ (44 :: linear_v99_6)
theorem mutated_sl99_5 : serializeItems 4064 26 linear_l99_5 = some linear_v99_5 := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r105 linear_r106 linear_l99_7 linear_b105 linear_v99_6 mutated_s105 mutated_sl99_6)
theorem mutated_pl99_5 (tail : List Nat) : parseItems 4064 26 (linear_v99_5 ++ (93 :: tail)) = some (linear_l99_5, tail) := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b105 ++ (44 :: (linear_v99_6 ++ (93 :: tail)))) (linear_v99_6 ++ (93 :: tail)) tail linear_r105 linear_l99_6 (mutated_p105 (44 :: (linear_v99_6 ++ (93 :: tail)))) (mutated_pl99_6 tail))
def linear_l99_4 : List Raw := linear_r104 :: linear_l99_5
def linear_v99_4 : List Nat := (linear_b104) ++ (44 :: linear_v99_5)
theorem mutated_sl99_4 : serializeItems 4065 26 linear_l99_4 = some linear_v99_4 := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r104 linear_r105 linear_l99_6 linear_b104 linear_v99_5 mutated_s104 mutated_sl99_5)
theorem mutated_pl99_4 (tail : List Nat) : parseItems 4065 26 (linear_v99_4 ++ (93 :: tail)) = some (linear_l99_4, tail) := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b104 ++ (44 :: (linear_v99_5 ++ (93 :: tail)))) (linear_v99_5 ++ (93 :: tail)) tail linear_r104 linear_l99_5 (mutated_p104 (44 :: (linear_v99_5 ++ (93 :: tail)))) (mutated_pl99_5 tail))
def linear_l99_3 : List Raw := linear_r103 :: linear_l99_4
def linear_v99_3 : List Nat := (linear_b103) ++ (44 :: linear_v99_4)
theorem mutated_sl99_3 : serializeItems 4066 26 linear_l99_3 = some linear_v99_3 := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r103 linear_r104 linear_l99_5 linear_b103 linear_v99_4 mutated_s103 mutated_sl99_4)
theorem mutated_pl99_3 (tail : List Nat) : parseItems 4066 26 (linear_v99_3 ++ (93 :: tail)) = some (linear_l99_3, tail) := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b103 ++ (44 :: (linear_v99_4 ++ (93 :: tail)))) (linear_v99_4 ++ (93 :: tail)) tail linear_r103 linear_l99_4 (mutated_p103 (44 :: (linear_v99_4 ++ (93 :: tail)))) (mutated_pl99_4 tail))
def linear_l99_2 : List Raw := linear_r102 :: linear_l99_3
def linear_v99_2 : List Nat := (linear_b102) ++ (44 :: linear_v99_3)
theorem mutated_sl99_2 : serializeItems 4067 26 linear_l99_2 = some linear_v99_2 := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r102 linear_r103 linear_l99_4 linear_b102 linear_v99_3 mutated_s102 mutated_sl99_3)
theorem mutated_pl99_2 (tail : List Nat) : parseItems 4067 26 (linear_v99_2 ++ (93 :: tail)) = some (linear_l99_2, tail) := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b102 ++ (44 :: (linear_v99_3 ++ (93 :: tail)))) (linear_v99_3 ++ (93 :: tail)) tail linear_r102 linear_l99_3 (mutated_p102 (44 :: (linear_v99_3 ++ (93 :: tail)))) (mutated_pl99_3 tail))
def linear_l99_1 : List Raw := linear_r101 :: linear_l99_2
def linear_v99_1 : List Nat := (linear_b101) ++ (44 :: linear_v99_2)
theorem mutated_sl99_1 : serializeItems 4068 26 linear_l99_1 = some linear_v99_1 := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r101 linear_r102 linear_l99_3 linear_b101 linear_v99_2 mutated_s101 mutated_sl99_2)
theorem mutated_pl99_1 (tail : List Nat) : parseItems 4068 26 (linear_v99_1 ++ (93 :: tail)) = some (linear_l99_1, tail) := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b101 ++ (44 :: (linear_v99_2 ++ (93 :: tail)))) (linear_v99_2 ++ (93 :: tail)) tail linear_r101 linear_l99_2 (mutated_p101 (44 :: (linear_v99_2 ++ (93 :: tail)))) (mutated_pl99_2 tail))
def linear_l99_0 : List Raw := linear_r100 :: linear_l99_1
def linear_v99_0 : List Nat := (linear_b100) ++ (44 :: linear_v99_1)
theorem mutated_sl99_0 : serializeItems 4069 26 linear_l99_0 = some linear_v99_0 := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r100 linear_r101 linear_l99_2 linear_b100 linear_v99_1 mutated_s100 mutated_sl99_1)
theorem mutated_pl99_0 (tail : List Nat) : parseItems 4069 26 (linear_v99_0 ++ (93 :: tail)) = some (linear_l99_0, tail) := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b100 ++ (44 :: (linear_v99_1 ++ (93 :: tail)))) (linear_v99_1 ++ (93 :: tail)) tail linear_r100 linear_l99_1 (mutated_p100 (44 :: (linear_v99_1 ++ (93 :: tail)))) (mutated_pl99_1 tail))
def linear_r99 : Raw := (.arr linear_l99_0)
def linear_b99 : List Nat := linear_g254 ++ (linear_v99_0 ++ linear_g276)
theorem mutated_s99 : serializeRaw 4070 27 linear_r99 = some linear_b99 := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4069 26 linear_l99_0 linear_v99_0 mutated_sl99_0)
theorem mutated_p99 (tail : List Nat) : parseRaw 4070 27 (linear_b99 ++ tail) = some (linear_r99, tail) := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4069 26 (linear_v99_0 ++ (93 :: tail)) tail linear_l99_0 (by intro h; cases h) (mutated_pl99_0 tail))
def linear_r111 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b111 : List Nat := linear_g279
theorem mutated_s111 : serializeRaw 4069 27 linear_r111 = some linear_b111 := by decide +kernel
theorem mutated_p111 (tail : List Nat) : parseRaw 4069 27 (linear_b111 ++ tail) = some (linear_r111, tail) := by rfl
def linear_r112 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,48]),(.str [100,103,95,118,95,49,49,49]),(.str [100,103,95,118,95,49,49,50]),(.str [100,103,95,118,95,49,49,51]),(.str [100,103,95,118,95,49,50,51])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,48]))])
def linear_b112 : List Nat := linear_g282
theorem mutated_s112 : serializeRaw 4068 27 linear_r112 = some linear_b112 := by decide +kernel
theorem mutated_p112 (tail : List Nat) : parseRaw 4068 27 (linear_b112 ++ tail) = some (linear_r112, tail) := by rfl
def linear_k97_0 : List Nat := [105,100]
theorem mutated_kd97_0 : stringBytes linear_k97_0 = true := by decide +kernel
theorem mutated_kp97_0 (tail : List Nat) : parseStringTail (linear_k97_0 ++ (34 :: 58 :: tail)) [] = some (linear_k97_0, 58 :: tail) := by rfl
def linear_k97_1 : List Nat := [111,112,115]
theorem mutated_kd97_1 : stringBytes linear_k97_1 = true := by decide +kernel
theorem mutated_kp97_1 (tail : List Nat) : parseStringTail (linear_k97_1 ++ (34 :: 58 :: tail)) [] = some (linear_k97_1, 58 :: tail) := by rfl
def linear_k97_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd97_2 : stringBytes linear_k97_2 = true := by decide +kernel
theorem mutated_kp97_2 (tail : List Nat) : parseStringTail (linear_k97_2 ++ (34 :: 58 :: tail)) [] = some (linear_k97_2, 58 :: tail) := by rfl
def linear_k97_3 : List Nat := [116,101,114,109]
theorem mutated_kd97_3 : stringBytes linear_k97_3 = true := by decide +kernel
theorem mutated_kp97_3 (tail : List Nat) : parseStringTail (linear_k97_3 ++ (34 :: 58 :: tail)) [] = some (linear_k97_3, 58 :: tail) := by rfl
def linear_l97_3 : List (List Nat × Raw) := [(linear_k97_3, linear_r112)]
def linear_v97_3 : List Nat := linear_g281 ++ linear_b112
theorem mutated_sl97_3 : serializeFields 4069 27 linear_l97_3 = some linear_v97_3 := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4068 27 linear_k97_3 linear_r112 linear_b112 mutated_kd97_3 mutated_s112)
theorem mutated_pl97_3 (tail : List Nat) : parseFields 4069 27 (linear_v97_3 ++ (125 :: tail)) = some (linear_l97_3, tail) := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4068 27 (linear_k97_3 ++ (34 :: 58 :: (linear_b112 ++ (125 :: tail)))) linear_k97_3 (linear_b112 ++ (125 :: tail)) tail linear_r112 (mutated_kp97_3 (linear_b112 ++ (125 :: tail))) (mutated_p112 (125 :: tail)))
def linear_l97_2 : List (List Nat × Raw) := (linear_k97_2, linear_r111) :: linear_l97_3
def linear_v97_2 : List Nat := (linear_g278 ++ linear_b111) ++ (44 :: linear_v97_3)
theorem mutated_sl97_2 : serializeFields 4070 27 linear_l97_2 = some linear_v97_2 := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k97_2 linear_r111 (linear_k97_3, linear_r112) [] linear_b111 linear_v97_3 mutated_kd97_2 mutated_s111 mutated_sl97_3)
theorem mutated_pl97_2 (tail : List Nat) : parseFields 4070 27 (linear_v97_2 ++ (125 :: tail)) = some (linear_l97_2, tail) := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k97_2 ++ (34 :: 58 :: (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))))) linear_k97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))) (linear_v97_3 ++ (125 :: tail)) tail linear_r111 linear_l97_3 (mutated_kp97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail))))) (mutated_p111 (44 :: (linear_v97_3 ++ (125 :: tail)))) (mutated_pl97_3 tail))
def linear_l97_1 : List (List Nat × Raw) := (linear_k97_1, linear_r99) :: linear_l97_2
def linear_v97_1 : List Nat := (linear_g253 ++ linear_b99) ++ (44 :: linear_v97_2)
theorem mutated_sl97_1 : serializeFields 4071 27 linear_l97_1 = some linear_v97_1 := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k97_1 linear_r99 (linear_k97_2, linear_r111) linear_l97_3 linear_b99 linear_v97_2 mutated_kd97_1 mutated_s99 mutated_sl97_2)
theorem mutated_pl97_1 (tail : List Nat) : parseFields 4071 27 (linear_v97_1 ++ (125 :: tail)) = some (linear_l97_1, tail) := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k97_1 ++ (34 :: 58 :: (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))))) linear_k97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))) (linear_v97_2 ++ (125 :: tail)) tail linear_r99 linear_l97_2 (mutated_kp97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail))))) (mutated_p99 (44 :: (linear_v97_2 ++ (125 :: tail)))) (mutated_pl97_2 tail))
def linear_l97_0 : List (List Nat × Raw) := (linear_k97_0, linear_r98) :: linear_l97_1
def linear_v97_0 : List Nat := (linear_g250 ++ linear_b98) ++ (44 :: linear_v97_1)
theorem mutated_sl97_0 : serializeFields 4072 27 linear_l97_0 = some linear_v97_0 := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k97_0 linear_r98 (linear_k97_1, linear_r99) linear_l97_2 linear_b98 linear_v97_1 mutated_kd97_0 mutated_s98 mutated_sl97_1)
theorem mutated_pl97_0 (tail : List Nat) : parseFields 4072 27 (linear_v97_0 ++ (125 :: tail)) = some (linear_l97_0, tail) := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) linear_k97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))) (linear_v97_1 ++ (125 :: tail)) tail linear_r98 linear_l97_1 (mutated_kp97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail))))) (mutated_p98 (44 :: (linear_v97_1 ++ (125 :: tail)))) (mutated_pl97_1 tail))
def linear_r97 : Raw := (.obj linear_l97_0)
def linear_b97 : List Nat := linear_g249 ++ (linear_v97_0 ++ linear_g283)
theorem mutated_o97 : orderedFields linear_l97_0 = true := by decide +kernel
theorem mutated_s97 : serializeRaw 4073 28 linear_r97 = some linear_b97 := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4072 27 linear_l97_0 linear_v97_0 mutated_o97 mutated_sl97_0)
theorem mutated_p97 (tail : List Nat) : parseRaw 4073 28 (linear_b97 ++ tail) = some (linear_r97, tail) := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4072 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) tail linear_l97_0 mutated_o97 (by simpa only [linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl97_0 tail)))
def linear_r114 : Raw := (.str [100,103,95,115,108,111,119,95,50])
def linear_b114 : List Nat := linear_g287
theorem mutated_s114 : serializeRaw 4070 27 linear_r114 = some linear_b114 := by decide +kernel
theorem mutated_p114 (tail : List Nat) : parseRaw 4070 27 (linear_b114 ++ tail) = some (linear_r114, tail) := by rfl
def linear_r115 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,57])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b115 : List Nat := linear_g290
theorem mutated_s115 : serializeRaw 4069 27 linear_r115 = some linear_b115 := by decide +kernel
theorem mutated_p115 (tail : List Nat) : parseRaw 4069 27 (linear_b115 ++ tail) = some (linear_r115, tail) := by rfl
def linear_r116 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b116 : List Nat := linear_g293
theorem mutated_s116 : serializeRaw 4068 27 linear_r116 = some linear_b116 := by decide +kernel
theorem mutated_p116 (tail : List Nat) : parseRaw 4068 27 (linear_b116 ++ tail) = some (linear_r116, tail) := by rfl
def linear_r117 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,50,53]),(.str [100,103,95,118,95,49,50,54]),(.str [100,103,95,118,95,49,50,57]),(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,51,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b117 : List Nat := linear_g296
theorem mutated_s117 : serializeRaw 4067 27 linear_r117 = some linear_b117 := by decide +kernel
theorem mutated_p117 (tail : List Nat) : parseRaw 4067 27 (linear_b117 ++ tail) = some (linear_r117, tail) := by rfl
def linear_k113_0 : List Nat := [105,100]
theorem mutated_kd113_0 : stringBytes linear_k113_0 = true := by decide +kernel
theorem mutated_kp113_0 (tail : List Nat) : parseStringTail (linear_k113_0 ++ (34 :: 58 :: tail)) [] = some (linear_k113_0, 58 :: tail) := by rfl
def linear_k113_1 : List Nat := [111,112,115]
theorem mutated_kd113_1 : stringBytes linear_k113_1 = true := by decide +kernel
theorem mutated_kp113_1 (tail : List Nat) : parseStringTail (linear_k113_1 ++ (34 :: 58 :: tail)) [] = some (linear_k113_1, 58 :: tail) := by rfl
def linear_k113_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd113_2 : stringBytes linear_k113_2 = true := by decide +kernel
theorem mutated_kp113_2 (tail : List Nat) : parseStringTail (linear_k113_2 ++ (34 :: 58 :: tail)) [] = some (linear_k113_2, 58 :: tail) := by rfl
def linear_k113_3 : List Nat := [116,101,114,109]
theorem mutated_kd113_3 : stringBytes linear_k113_3 = true := by decide +kernel
theorem mutated_kp113_3 (tail : List Nat) : parseStringTail (linear_k113_3 ++ (34 :: 58 :: tail)) [] = some (linear_k113_3, 58 :: tail) := by rfl
def linear_l113_3 : List (List Nat × Raw) := [(linear_k113_3, linear_r117)]
def linear_v113_3 : List Nat := linear_g295 ++ linear_b117
theorem mutated_sl113_3 : serializeFields 4068 27 linear_l113_3 = some linear_v113_3 := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4067 27 linear_k113_3 linear_r117 linear_b117 mutated_kd113_3 mutated_s117)
theorem mutated_pl113_3 (tail : List Nat) : parseFields 4068 27 (linear_v113_3 ++ (125 :: tail)) = some (linear_l113_3, tail) := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4067 27 (linear_k113_3 ++ (34 :: 58 :: (linear_b117 ++ (125 :: tail)))) linear_k113_3 (linear_b117 ++ (125 :: tail)) tail linear_r117 (mutated_kp113_3 (linear_b117 ++ (125 :: tail))) (mutated_p117 (125 :: tail)))
def linear_l113_2 : List (List Nat × Raw) := (linear_k113_2, linear_r116) :: linear_l113_3
def linear_v113_2 : List Nat := (linear_g292 ++ linear_b116) ++ (44 :: linear_v113_3)
theorem mutated_sl113_2 : serializeFields 4069 27 linear_l113_2 = some linear_v113_2 := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k113_2 linear_r116 (linear_k113_3, linear_r117) [] linear_b116 linear_v113_3 mutated_kd113_2 mutated_s116 mutated_sl113_3)
theorem mutated_pl113_2 (tail : List Nat) : parseFields 4069 27 (linear_v113_2 ++ (125 :: tail)) = some (linear_l113_2, tail) := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k113_2 ++ (34 :: 58 :: (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))))) linear_k113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))) (linear_v113_3 ++ (125 :: tail)) tail linear_r116 linear_l113_3 (mutated_kp113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail))))) (mutated_p116 (44 :: (linear_v113_3 ++ (125 :: tail)))) (mutated_pl113_3 tail))
def linear_l113_1 : List (List Nat × Raw) := (linear_k113_1, linear_r115) :: linear_l113_2
def linear_v113_1 : List Nat := (linear_g289 ++ linear_b115) ++ (44 :: linear_v113_2)
theorem mutated_sl113_1 : serializeFields 4070 27 linear_l113_1 = some linear_v113_1 := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k113_1 linear_r115 (linear_k113_2, linear_r116) linear_l113_3 linear_b115 linear_v113_2 mutated_kd113_1 mutated_s115 mutated_sl113_2)
theorem mutated_pl113_1 (tail : List Nat) : parseFields 4070 27 (linear_v113_1 ++ (125 :: tail)) = some (linear_l113_1, tail) := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k113_1 ++ (34 :: 58 :: (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))))) linear_k113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))) (linear_v113_2 ++ (125 :: tail)) tail linear_r115 linear_l113_2 (mutated_kp113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail))))) (mutated_p115 (44 :: (linear_v113_2 ++ (125 :: tail)))) (mutated_pl113_2 tail))
def linear_l113_0 : List (List Nat × Raw) := (linear_k113_0, linear_r114) :: linear_l113_1
def linear_v113_0 : List Nat := (linear_g286 ++ linear_b114) ++ (44 :: linear_v113_1)
theorem mutated_sl113_0 : serializeFields 4071 27 linear_l113_0 = some linear_v113_0 := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k113_0 linear_r114 (linear_k113_1, linear_r115) linear_l113_2 linear_b114 linear_v113_1 mutated_kd113_0 mutated_s114 mutated_sl113_1)
theorem mutated_pl113_0 (tail : List Nat) : parseFields 4071 27 (linear_v113_0 ++ (125 :: tail)) = some (linear_l113_0, tail) := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) linear_k113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))) (linear_v113_1 ++ (125 :: tail)) tail linear_r114 linear_l113_1 (mutated_kp113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail))))) (mutated_p114 (44 :: (linear_v113_1 ++ (125 :: tail)))) (mutated_pl113_1 tail))
def linear_r113 : Raw := (.obj linear_l113_0)
def linear_b113 : List Nat := linear_g285 ++ (linear_v113_0 ++ linear_g297)
theorem mutated_o113 : orderedFields linear_l113_0 = true := by decide +kernel
theorem mutated_s113 : serializeRaw 4072 28 linear_r113 = some linear_b113 := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4071 27 linear_l113_0 linear_v113_0 mutated_o113 mutated_sl113_0)
theorem mutated_p113 (tail : List Nat) : parseRaw 4072 28 (linear_b113 ++ tail) = some (linear_r113, tail) := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4071 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) tail linear_l113_0 mutated_o113 (by simpa only [linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl113_0 tail)))
def linear_r119 : Raw := (.str [100,103,95,115,108,111,119,95,51])
def linear_b119 : List Nat := linear_g301
theorem mutated_s119 : serializeRaw 4069 27 linear_r119 = some linear_b119 := by decide +kernel
theorem mutated_p119 (tail : List Nat) : parseRaw 4069 27 (linear_b119 ++ tail) = some (linear_r119, tail) := by rfl
def linear_r120 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,54]),(.str [100,103,95,118,95,49,51,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,55])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b120 : List Nat := linear_g304
theorem mutated_s120 : serializeRaw 4068 27 linear_r120 = some linear_b120 := by decide +kernel
theorem mutated_p120 (tail : List Nat) : parseRaw 4068 27 (linear_b120 ++ tail) = some (linear_r120, tail) := by rfl
def linear_r121 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,52])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b121 : List Nat := linear_g307
theorem mutated_s121 : serializeRaw 4067 27 linear_r121 = some linear_b121 := by decide +kernel
theorem mutated_p121 (tail : List Nat) : parseRaw 4067 27 (linear_b121 ++ tail) = some (linear_r121, tail) := by rfl
def linear_r122 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,51,55])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))]))])
def linear_b122 : List Nat := linear_g310
theorem mutated_s122 : serializeRaw 4066 27 linear_r122 = some linear_b122 := by decide +kernel
theorem mutated_p122 (tail : List Nat) : parseRaw 4066 27 (linear_b122 ++ tail) = some (linear_r122, tail) := by rfl
def linear_k118_0 : List Nat := [105,100]
theorem mutated_kd118_0 : stringBytes linear_k118_0 = true := by decide +kernel
theorem mutated_kp118_0 (tail : List Nat) : parseStringTail (linear_k118_0 ++ (34 :: 58 :: tail)) [] = some (linear_k118_0, 58 :: tail) := by rfl
def linear_k118_1 : List Nat := [111,112,115]
theorem mutated_kd118_1 : stringBytes linear_k118_1 = true := by decide +kernel
theorem mutated_kp118_1 (tail : List Nat) : parseStringTail (linear_k118_1 ++ (34 :: 58 :: tail)) [] = some (linear_k118_1, 58 :: tail) := by rfl
def linear_k118_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd118_2 : stringBytes linear_k118_2 = true := by decide +kernel
theorem mutated_kp118_2 (tail : List Nat) : parseStringTail (linear_k118_2 ++ (34 :: 58 :: tail)) [] = some (linear_k118_2, 58 :: tail) := by rfl
def linear_k118_3 : List Nat := [116,101,114,109]
theorem mutated_kd118_3 : stringBytes linear_k118_3 = true := by decide +kernel
theorem mutated_kp118_3 (tail : List Nat) : parseStringTail (linear_k118_3 ++ (34 :: 58 :: tail)) [] = some (linear_k118_3, 58 :: tail) := by rfl
def linear_l118_3 : List (List Nat × Raw) := [(linear_k118_3, linear_r122)]
def linear_v118_3 : List Nat := linear_g309 ++ linear_b122
theorem mutated_sl118_3 : serializeFields 4067 27 linear_l118_3 = some linear_v118_3 := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4066 27 linear_k118_3 linear_r122 linear_b122 mutated_kd118_3 mutated_s122)
theorem mutated_pl118_3 (tail : List Nat) : parseFields 4067 27 (linear_v118_3 ++ (125 :: tail)) = some (linear_l118_3, tail) := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4066 27 (linear_k118_3 ++ (34 :: 58 :: (linear_b122 ++ (125 :: tail)))) linear_k118_3 (linear_b122 ++ (125 :: tail)) tail linear_r122 (mutated_kp118_3 (linear_b122 ++ (125 :: tail))) (mutated_p122 (125 :: tail)))
def linear_l118_2 : List (List Nat × Raw) := (linear_k118_2, linear_r121) :: linear_l118_3
def linear_v118_2 : List Nat := (linear_g306 ++ linear_b121) ++ (44 :: linear_v118_3)
theorem mutated_sl118_2 : serializeFields 4068 27 linear_l118_2 = some linear_v118_2 := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k118_2 linear_r121 (linear_k118_3, linear_r122) [] linear_b121 linear_v118_3 mutated_kd118_2 mutated_s121 mutated_sl118_3)
theorem mutated_pl118_2 (tail : List Nat) : parseFields 4068 27 (linear_v118_2 ++ (125 :: tail)) = some (linear_l118_2, tail) := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k118_2 ++ (34 :: 58 :: (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))))) linear_k118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))) (linear_v118_3 ++ (125 :: tail)) tail linear_r121 linear_l118_3 (mutated_kp118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail))))) (mutated_p121 (44 :: (linear_v118_3 ++ (125 :: tail)))) (mutated_pl118_3 tail))
def linear_l118_1 : List (List Nat × Raw) := (linear_k118_1, linear_r120) :: linear_l118_2
def linear_v118_1 : List Nat := (linear_g303 ++ linear_b120) ++ (44 :: linear_v118_2)
theorem mutated_sl118_1 : serializeFields 4069 27 linear_l118_1 = some linear_v118_1 := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k118_1 linear_r120 (linear_k118_2, linear_r121) linear_l118_3 linear_b120 linear_v118_2 mutated_kd118_1 mutated_s120 mutated_sl118_2)
theorem mutated_pl118_1 (tail : List Nat) : parseFields 4069 27 (linear_v118_1 ++ (125 :: tail)) = some (linear_l118_1, tail) := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k118_1 ++ (34 :: 58 :: (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))))) linear_k118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))) (linear_v118_2 ++ (125 :: tail)) tail linear_r120 linear_l118_2 (mutated_kp118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail))))) (mutated_p120 (44 :: (linear_v118_2 ++ (125 :: tail)))) (mutated_pl118_2 tail))
def linear_l118_0 : List (List Nat × Raw) := (linear_k118_0, linear_r119) :: linear_l118_1
def linear_v118_0 : List Nat := (linear_g300 ++ linear_b119) ++ (44 :: linear_v118_1)
theorem mutated_sl118_0 : serializeFields 4070 27 linear_l118_0 = some linear_v118_0 := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k118_0 linear_r119 (linear_k118_1, linear_r120) linear_l118_2 linear_b119 linear_v118_1 mutated_kd118_0 mutated_s119 mutated_sl118_1)
theorem mutated_pl118_0 (tail : List Nat) : parseFields 4070 27 (linear_v118_0 ++ (125 :: tail)) = some (linear_l118_0, tail) := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) linear_k118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))) (linear_v118_1 ++ (125 :: tail)) tail linear_r119 linear_l118_1 (mutated_kp118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail))))) (mutated_p119 (44 :: (linear_v118_1 ++ (125 :: tail)))) (mutated_pl118_1 tail))
def linear_r118 : Raw := (.obj linear_l118_0)
def linear_b118 : List Nat := linear_g299 ++ (linear_v118_0 ++ linear_g311)
theorem mutated_o118 : orderedFields linear_l118_0 = true := by decide +kernel
theorem mutated_s118 : serializeRaw 4071 28 linear_r118 = some linear_b118 := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4070 27 linear_l118_0 linear_v118_0 mutated_o118 mutated_sl118_0)
theorem mutated_p118 (tail : List Nat) : parseRaw 4071 28 (linear_b118 ++ tail) = some (linear_r118, tail) := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4070 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) tail linear_l118_0 mutated_o118 (by simpa only [linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl118_0 tail)))
def linear_r124 : Raw := (.str [100,103,95,115,108,111,119,95,52])
def linear_b124 : List Nat := linear_g315
theorem mutated_s124 : serializeRaw 4068 27 linear_r124 = some linear_b124 := by decide +kernel
theorem mutated_p124 (tail : List Nat) : parseRaw 4068 27 (linear_b124 ++ tail) = some (linear_r124, tail) := by rfl
def linear_r126 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,52])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b126 : List Nat := linear_g319
theorem mutated_s126 : serializeRaw 4065 26 linear_r126 = some linear_b126 := by decide +kernel
theorem mutated_p126 (tail : List Nat) : parseRaw 4065 26 (linear_b126 ++ tail) = some (linear_r126, tail) := by rfl
def linear_r127 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52]),(.str [100,103,95,118,95,49,52,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b127 : List Nat := linear_g321
theorem mutated_s127 : serializeRaw 4064 26 linear_r127 = some linear_b127 := by decide +kernel
theorem mutated_p127 (tail : List Nat) : parseRaw 4064 26 (linear_b127 ++ tail) = some (linear_r127, tail) := by rfl
def linear_r128 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b128 : List Nat := linear_g323
theorem mutated_s128 : serializeRaw 4063 26 linear_r128 = some linear_b128 := by decide +kernel
theorem mutated_p128 (tail : List Nat) : parseRaw 4063 26 (linear_b128 ++ tail) = some (linear_r128, tail) := by rfl
def linear_r129 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b129 : List Nat := linear_g325
theorem mutated_s129 : serializeRaw 4062 26 linear_r129 = some linear_b129 := by decide +kernel
theorem mutated_p129 (tail : List Nat) : parseRaw 4062 26 (linear_b129 ++ tail) = some (linear_r129, tail) := by rfl
def linear_r130 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,49]),(.str [100,103,95,118,95,49,52,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b130 : List Nat := linear_g327
theorem mutated_s130 : serializeRaw 4061 26 linear_r130 = some linear_b130 := by decide +kernel
theorem mutated_p130 (tail : List Nat) : parseRaw 4061 26 (linear_b130 ++ tail) = some (linear_r130, tail) := by rfl
def linear_r131 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b131 : List Nat := linear_g329
theorem mutated_s131 : serializeRaw 4060 26 linear_r131 = some linear_b131 := by decide +kernel
theorem mutated_p131 (tail : List Nat) : parseRaw 4060 26 (linear_b131 ++ tail) = some (linear_r131, tail) := by rfl
def linear_r132 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,51]),(.str [100,103,95,118,95,49,52,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b132 : List Nat := linear_g331
theorem mutated_s132 : serializeRaw 4059 26 linear_r132 = some linear_b132 := by decide +kernel
theorem mutated_p132 (tail : List Nat) : parseRaw 4059 26 (linear_b132 ++ tail) = some (linear_r132, tail) := by rfl
def linear_l125_6 : List Raw := [linear_r132]
def linear_v125_6 : List Nat := linear_b132
theorem mutated_sl125_6 : serializeItems 4060 26 linear_l125_6 = some linear_v125_6 := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4059 26 linear_r132 linear_b132 mutated_s132)
theorem mutated_pl125_6 (tail : List Nat) : parseItems 4060 26 (linear_v125_6 ++ (93 :: tail)) = some (linear_l125_6, tail) := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4059 26 (linear_b132 ++ (93 :: tail)) tail linear_r132 (mutated_p132 (93 :: tail)))
def linear_l125_5 : List Raw := linear_r131 :: linear_l125_6
def linear_v125_5 : List Nat := (linear_b131) ++ (44 :: linear_v125_6)
theorem mutated_sl125_5 : serializeItems 4061 26 linear_l125_5 = some linear_v125_5 := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r131 linear_r132 [] linear_b131 linear_v125_6 mutated_s131 mutated_sl125_6)
theorem mutated_pl125_5 (tail : List Nat) : parseItems 4061 26 (linear_v125_5 ++ (93 :: tail)) = some (linear_l125_5, tail) := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b131 ++ (44 :: (linear_v125_6 ++ (93 :: tail)))) (linear_v125_6 ++ (93 :: tail)) tail linear_r131 linear_l125_6 (mutated_p131 (44 :: (linear_v125_6 ++ (93 :: tail)))) (mutated_pl125_6 tail))
def linear_l125_4 : List Raw := linear_r130 :: linear_l125_5
def linear_v125_4 : List Nat := (linear_b130) ++ (44 :: linear_v125_5)
theorem mutated_sl125_4 : serializeItems 4062 26 linear_l125_4 = some linear_v125_4 := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r130 linear_r131 linear_l125_6 linear_b130 linear_v125_5 mutated_s130 mutated_sl125_5)
theorem mutated_pl125_4 (tail : List Nat) : parseItems 4062 26 (linear_v125_4 ++ (93 :: tail)) = some (linear_l125_4, tail) := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b130 ++ (44 :: (linear_v125_5 ++ (93 :: tail)))) (linear_v125_5 ++ (93 :: tail)) tail linear_r130 linear_l125_5 (mutated_p130 (44 :: (linear_v125_5 ++ (93 :: tail)))) (mutated_pl125_5 tail))
def linear_l125_3 : List Raw := linear_r129 :: linear_l125_4
def linear_v125_3 : List Nat := (linear_b129) ++ (44 :: linear_v125_4)
theorem mutated_sl125_3 : serializeItems 4063 26 linear_l125_3 = some linear_v125_3 := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r129 linear_r130 linear_l125_5 linear_b129 linear_v125_4 mutated_s129 mutated_sl125_4)
theorem mutated_pl125_3 (tail : List Nat) : parseItems 4063 26 (linear_v125_3 ++ (93 :: tail)) = some (linear_l125_3, tail) := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b129 ++ (44 :: (linear_v125_4 ++ (93 :: tail)))) (linear_v125_4 ++ (93 :: tail)) tail linear_r129 linear_l125_4 (mutated_p129 (44 :: (linear_v125_4 ++ (93 :: tail)))) (mutated_pl125_4 tail))
def linear_l125_2 : List Raw := linear_r128 :: linear_l125_3
def linear_v125_2 : List Nat := (linear_b128) ++ (44 :: linear_v125_3)
theorem mutated_sl125_2 : serializeItems 4064 26 linear_l125_2 = some linear_v125_2 := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r128 linear_r129 linear_l125_4 linear_b128 linear_v125_3 mutated_s128 mutated_sl125_3)
theorem mutated_pl125_2 (tail : List Nat) : parseItems 4064 26 (linear_v125_2 ++ (93 :: tail)) = some (linear_l125_2, tail) := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b128 ++ (44 :: (linear_v125_3 ++ (93 :: tail)))) (linear_v125_3 ++ (93 :: tail)) tail linear_r128 linear_l125_3 (mutated_p128 (44 :: (linear_v125_3 ++ (93 :: tail)))) (mutated_pl125_3 tail))
def linear_l125_1 : List Raw := linear_r127 :: linear_l125_2
def linear_v125_1 : List Nat := (linear_b127) ++ (44 :: linear_v125_2)
theorem mutated_sl125_1 : serializeItems 4065 26 linear_l125_1 = some linear_v125_1 := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r127 linear_r128 linear_l125_3 linear_b127 linear_v125_2 mutated_s127 mutated_sl125_2)
theorem mutated_pl125_1 (tail : List Nat) : parseItems 4065 26 (linear_v125_1 ++ (93 :: tail)) = some (linear_l125_1, tail) := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b127 ++ (44 :: (linear_v125_2 ++ (93 :: tail)))) (linear_v125_2 ++ (93 :: tail)) tail linear_r127 linear_l125_2 (mutated_p127 (44 :: (linear_v125_2 ++ (93 :: tail)))) (mutated_pl125_2 tail))
def linear_l125_0 : List Raw := linear_r126 :: linear_l125_1
def linear_v125_0 : List Nat := (linear_b126) ++ (44 :: linear_v125_1)
theorem mutated_sl125_0 : serializeItems 4066 26 linear_l125_0 = some linear_v125_0 := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r126 linear_r127 linear_l125_2 linear_b126 linear_v125_1 mutated_s126 mutated_sl125_1)
theorem mutated_pl125_0 (tail : List Nat) : parseItems 4066 26 (linear_v125_0 ++ (93 :: tail)) = some (linear_l125_0, tail) := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b126 ++ (44 :: (linear_v125_1 ++ (93 :: tail)))) (linear_v125_1 ++ (93 :: tail)) tail linear_r126 linear_l125_1 (mutated_p126 (44 :: (linear_v125_1 ++ (93 :: tail)))) (mutated_pl125_1 tail))
def linear_r125 : Raw := (.arr linear_l125_0)
def linear_b125 : List Nat := linear_g318 ++ (linear_v125_0 ++ linear_g332)
theorem mutated_s125 : serializeRaw 4067 27 linear_r125 = some linear_b125 := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4066 26 linear_l125_0 linear_v125_0 mutated_sl125_0)
theorem mutated_p125 (tail : List Nat) : parseRaw 4067 27 (linear_b125 ++ tail) = some (linear_r125, tail) := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4066 26 (linear_v125_0 ++ (93 :: tail)) tail linear_l125_0 (by intro h; cases h) (mutated_pl125_0 tail))
def linear_r133 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b133 : List Nat := linear_g335
theorem mutated_s133 : serializeRaw 4066 27 linear_r133 = some linear_b133 := by decide +kernel
theorem mutated_p133 (tail : List Nat) : parseRaw 4066 27 (linear_b133 ++ tail) = some (linear_r133, tail) := by rfl
def linear_r134 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,56]),(.str [100,103,95,118,95,49,51,57]),(.str [100,103,95,118,95,49,52,48]),(.str [100,103,95,118,95,49,52,55]),(.str [100,103,95,118,95,49,52,50]),(.str [100,103,95,118,95,49,52,57])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b134 : List Nat := linear_g338
theorem mutated_s134 : serializeRaw 4065 27 linear_r134 = some linear_b134 := by decide +kernel
theorem mutated_p134 (tail : List Nat) : parseRaw 4065 27 (linear_b134 ++ tail) = some (linear_r134, tail) := by rfl
def linear_k123_0 : List Nat := [105,100]
theorem mutated_kd123_0 : stringBytes linear_k123_0 = true := by decide +kernel
theorem mutated_kp123_0 (tail : List Nat) : parseStringTail (linear_k123_0 ++ (34 :: 58 :: tail)) [] = some (linear_k123_0, 58 :: tail) := by rfl
def linear_k123_1 : List Nat := [111,112,115]
theorem mutated_kd123_1 : stringBytes linear_k123_1 = true := by decide +kernel
theorem mutated_kp123_1 (tail : List Nat) : parseStringTail (linear_k123_1 ++ (34 :: 58 :: tail)) [] = some (linear_k123_1, 58 :: tail) := by rfl
def linear_k123_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd123_2 : stringBytes linear_k123_2 = true := by decide +kernel
theorem mutated_kp123_2 (tail : List Nat) : parseStringTail (linear_k123_2 ++ (34 :: 58 :: tail)) [] = some (linear_k123_2, 58 :: tail) := by rfl
def linear_k123_3 : List Nat := [116,101,114,109]
theorem mutated_kd123_3 : stringBytes linear_k123_3 = true := by decide +kernel
theorem mutated_kp123_3 (tail : List Nat) : parseStringTail (linear_k123_3 ++ (34 :: 58 :: tail)) [] = some (linear_k123_3, 58 :: tail) := by rfl
def linear_l123_3 : List (List Nat × Raw) := [(linear_k123_3, linear_r134)]
def linear_v123_3 : List Nat := linear_g337 ++ linear_b134
theorem mutated_sl123_3 : serializeFields 4066 27 linear_l123_3 = some linear_v123_3 := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4065 27 linear_k123_3 linear_r134 linear_b134 mutated_kd123_3 mutated_s134)
theorem mutated_pl123_3 (tail : List Nat) : parseFields 4066 27 (linear_v123_3 ++ (125 :: tail)) = some (linear_l123_3, tail) := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4065 27 (linear_k123_3 ++ (34 :: 58 :: (linear_b134 ++ (125 :: tail)))) linear_k123_3 (linear_b134 ++ (125 :: tail)) tail linear_r134 (mutated_kp123_3 (linear_b134 ++ (125 :: tail))) (mutated_p134 (125 :: tail)))
def linear_l123_2 : List (List Nat × Raw) := (linear_k123_2, linear_r133) :: linear_l123_3
def linear_v123_2 : List Nat := (linear_g334 ++ linear_b133) ++ (44 :: linear_v123_3)
theorem mutated_sl123_2 : serializeFields 4067 27 linear_l123_2 = some linear_v123_2 := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k123_2 linear_r133 (linear_k123_3, linear_r134) [] linear_b133 linear_v123_3 mutated_kd123_2 mutated_s133 mutated_sl123_3)
theorem mutated_pl123_2 (tail : List Nat) : parseFields 4067 27 (linear_v123_2 ++ (125 :: tail)) = some (linear_l123_2, tail) := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k123_2 ++ (34 :: 58 :: (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))))) linear_k123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))) (linear_v123_3 ++ (125 :: tail)) tail linear_r133 linear_l123_3 (mutated_kp123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail))))) (mutated_p133 (44 :: (linear_v123_3 ++ (125 :: tail)))) (mutated_pl123_3 tail))
def linear_l123_1 : List (List Nat × Raw) := (linear_k123_1, linear_r125) :: linear_l123_2
def linear_v123_1 : List Nat := (linear_g317 ++ linear_b125) ++ (44 :: linear_v123_2)
theorem mutated_sl123_1 : serializeFields 4068 27 linear_l123_1 = some linear_v123_1 := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k123_1 linear_r125 (linear_k123_2, linear_r133) linear_l123_3 linear_b125 linear_v123_2 mutated_kd123_1 mutated_s125 mutated_sl123_2)
theorem mutated_pl123_1 (tail : List Nat) : parseFields 4068 27 (linear_v123_1 ++ (125 :: tail)) = some (linear_l123_1, tail) := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k123_1 ++ (34 :: 58 :: (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))))) linear_k123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))) (linear_v123_2 ++ (125 :: tail)) tail linear_r125 linear_l123_2 (mutated_kp123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail))))) (mutated_p125 (44 :: (linear_v123_2 ++ (125 :: tail)))) (mutated_pl123_2 tail))
def linear_l123_0 : List (List Nat × Raw) := (linear_k123_0, linear_r124) :: linear_l123_1
def linear_v123_0 : List Nat := (linear_g314 ++ linear_b124) ++ (44 :: linear_v123_1)
theorem mutated_sl123_0 : serializeFields 4069 27 linear_l123_0 = some linear_v123_0 := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k123_0 linear_r124 (linear_k123_1, linear_r125) linear_l123_2 linear_b124 linear_v123_1 mutated_kd123_0 mutated_s124 mutated_sl123_1)
theorem mutated_pl123_0 (tail : List Nat) : parseFields 4069 27 (linear_v123_0 ++ (125 :: tail)) = some (linear_l123_0, tail) := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) linear_k123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))) (linear_v123_1 ++ (125 :: tail)) tail linear_r124 linear_l123_1 (mutated_kp123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail))))) (mutated_p124 (44 :: (linear_v123_1 ++ (125 :: tail)))) (mutated_pl123_1 tail))
def linear_r123 : Raw := (.obj linear_l123_0)
def linear_b123 : List Nat := linear_g313 ++ (linear_v123_0 ++ linear_g339)
theorem mutated_o123 : orderedFields linear_l123_0 = true := by decide +kernel
theorem mutated_s123 : serializeRaw 4070 28 linear_r123 = some linear_b123 := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4069 27 linear_l123_0 linear_v123_0 mutated_o123 mutated_sl123_0)
theorem mutated_p123 (tail : List Nat) : parseRaw 4070 28 (linear_b123 ++ tail) = some (linear_r123, tail) := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4069 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) tail linear_l123_0 mutated_o123 (by simpa only [linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl123_0 tail)))
def linear_r136 : Raw := (.str [100,103,95,115,108,111,119,95,53])
def linear_b136 : List Nat := linear_g343
theorem mutated_s136 : serializeRaw 4067 27 linear_r136 = some linear_b136 := by decide +kernel
theorem mutated_p136 (tail : List Nat) : parseRaw 4067 27 (linear_b136 ++ tail) = some (linear_r136, tail) := by rfl
def linear_r137 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b137 : List Nat := linear_g346
theorem mutated_s137 : serializeRaw 4066 27 linear_r137 = some linear_b137 := by decide +kernel
theorem mutated_p137 (tail : List Nat) : parseRaw 4066 27 (linear_b137 ++ tail) = some (linear_r137, tail) := by rfl
def linear_r138 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,51])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b138 : List Nat := linear_g349
theorem mutated_s138 : serializeRaw 4065 27 linear_r138 = some linear_b138 := by decide +kernel
theorem mutated_p138 (tail : List Nat) : parseRaw 4065 27 (linear_b138 ++ tail) = some (linear_r138, tail) := by rfl
def linear_r139 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,53,51])]))])
def linear_b139 : List Nat := linear_g352
theorem mutated_s139 : serializeRaw 4064 27 linear_r139 = some linear_b139 := by decide +kernel
theorem mutated_p139 (tail : List Nat) : parseRaw 4064 27 (linear_b139 ++ tail) = some (linear_r139, tail) := by rfl
def linear_k135_0 : List Nat := [105,100]
theorem mutated_kd135_0 : stringBytes linear_k135_0 = true := by decide +kernel
theorem mutated_kp135_0 (tail : List Nat) : parseStringTail (linear_k135_0 ++ (34 :: 58 :: tail)) [] = some (linear_k135_0, 58 :: tail) := by rfl
def linear_k135_1 : List Nat := [111,112,115]
theorem mutated_kd135_1 : stringBytes linear_k135_1 = true := by decide +kernel
theorem mutated_kp135_1 (tail : List Nat) : parseStringTail (linear_k135_1 ++ (34 :: 58 :: tail)) [] = some (linear_k135_1, 58 :: tail) := by rfl
def linear_k135_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd135_2 : stringBytes linear_k135_2 = true := by decide +kernel
theorem mutated_kp135_2 (tail : List Nat) : parseStringTail (linear_k135_2 ++ (34 :: 58 :: tail)) [] = some (linear_k135_2, 58 :: tail) := by rfl
def linear_k135_3 : List Nat := [116,101,114,109]
theorem mutated_kd135_3 : stringBytes linear_k135_3 = true := by decide +kernel
theorem mutated_kp135_3 (tail : List Nat) : parseStringTail (linear_k135_3 ++ (34 :: 58 :: tail)) [] = some (linear_k135_3, 58 :: tail) := by rfl
def linear_l135_3 : List (List Nat × Raw) := [(linear_k135_3, linear_r139)]
def linear_v135_3 : List Nat := linear_g351 ++ linear_b139
theorem mutated_sl135_3 : serializeFields 4065 27 linear_l135_3 = some linear_v135_3 := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4064 27 linear_k135_3 linear_r139 linear_b139 mutated_kd135_3 mutated_s139)
theorem mutated_pl135_3 (tail : List Nat) : parseFields 4065 27 (linear_v135_3 ++ (125 :: tail)) = some (linear_l135_3, tail) := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4064 27 (linear_k135_3 ++ (34 :: 58 :: (linear_b139 ++ (125 :: tail)))) linear_k135_3 (linear_b139 ++ (125 :: tail)) tail linear_r139 (mutated_kp135_3 (linear_b139 ++ (125 :: tail))) (mutated_p139 (125 :: tail)))
def linear_l135_2 : List (List Nat × Raw) := (linear_k135_2, linear_r138) :: linear_l135_3
def linear_v135_2 : List Nat := (linear_g348 ++ linear_b138) ++ (44 :: linear_v135_3)
theorem mutated_sl135_2 : serializeFields 4066 27 linear_l135_2 = some linear_v135_2 := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k135_2 linear_r138 (linear_k135_3, linear_r139) [] linear_b138 linear_v135_3 mutated_kd135_2 mutated_s138 mutated_sl135_3)
theorem mutated_pl135_2 (tail : List Nat) : parseFields 4066 27 (linear_v135_2 ++ (125 :: tail)) = some (linear_l135_2, tail) := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k135_2 ++ (34 :: 58 :: (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))))) linear_k135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))) (linear_v135_3 ++ (125 :: tail)) tail linear_r138 linear_l135_3 (mutated_kp135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail))))) (mutated_p138 (44 :: (linear_v135_3 ++ (125 :: tail)))) (mutated_pl135_3 tail))
def linear_l135_1 : List (List Nat × Raw) := (linear_k135_1, linear_r137) :: linear_l135_2
def linear_v135_1 : List Nat := (linear_g345 ++ linear_b137) ++ (44 :: linear_v135_2)
theorem mutated_sl135_1 : serializeFields 4067 27 linear_l135_1 = some linear_v135_1 := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k135_1 linear_r137 (linear_k135_2, linear_r138) linear_l135_3 linear_b137 linear_v135_2 mutated_kd135_1 mutated_s137 mutated_sl135_2)
theorem mutated_pl135_1 (tail : List Nat) : parseFields 4067 27 (linear_v135_1 ++ (125 :: tail)) = some (linear_l135_1, tail) := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k135_1 ++ (34 :: 58 :: (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))))) linear_k135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))) (linear_v135_2 ++ (125 :: tail)) tail linear_r137 linear_l135_2 (mutated_kp135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail))))) (mutated_p137 (44 :: (linear_v135_2 ++ (125 :: tail)))) (mutated_pl135_2 tail))
def linear_l135_0 : List (List Nat × Raw) := (linear_k135_0, linear_r136) :: linear_l135_1
def linear_v135_0 : List Nat := (linear_g342 ++ linear_b136) ++ (44 :: linear_v135_1)
theorem mutated_sl135_0 : serializeFields 4068 27 linear_l135_0 = some linear_v135_0 := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k135_0 linear_r136 (linear_k135_1, linear_r137) linear_l135_2 linear_b136 linear_v135_1 mutated_kd135_0 mutated_s136 mutated_sl135_1)
theorem mutated_pl135_0 (tail : List Nat) : parseFields 4068 27 (linear_v135_0 ++ (125 :: tail)) = some (linear_l135_0, tail) := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) linear_k135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))) (linear_v135_1 ++ (125 :: tail)) tail linear_r136 linear_l135_1 (mutated_kp135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail))))) (mutated_p136 (44 :: (linear_v135_1 ++ (125 :: tail)))) (mutated_pl135_1 tail))
def linear_r135 : Raw := (.obj linear_l135_0)
def linear_b135 : List Nat := linear_g341 ++ (linear_v135_0 ++ linear_g353)
theorem mutated_o135 : orderedFields linear_l135_0 = true := by decide +kernel
theorem mutated_s135 : serializeRaw 4069 28 linear_r135 = some linear_b135 := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4068 27 linear_l135_0 linear_v135_0 mutated_o135 mutated_sl135_0)
theorem mutated_p135 (tail : List Nat) : parseRaw 4069 28 (linear_b135 ++ tail) = some (linear_r135, tail) := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4068 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) tail linear_l135_0 mutated_o135 (by simpa only [linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl135_0 tail)))
def linear_r141 : Raw := (.str [100,103,95,103,117,97,114,100,95,48])
def linear_b141 : List Nat := linear_g357
theorem mutated_s141 : serializeRaw 4066 27 linear_r141 = some linear_b141 := by decide +kernel
theorem mutated_p141 (tail : List Nat) : parseRaw 4066 27 (linear_b141 ++ tail) = some (linear_r141, tail) := by rfl
def linear_r142 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,50]),(.str [100,103,95,118,95,49,54,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b142 : List Nat := linear_g360
theorem mutated_s142 : serializeRaw 4065 27 linear_r142 = some linear_b142 := by decide +kernel
theorem mutated_p142 (tail : List Nat) : parseRaw 4065 27 (linear_b142 ++ tail) = some (linear_r142, tail) := by rfl
def linear_r143 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b143 : List Nat := linear_g363
theorem mutated_s143 : serializeRaw 4064 27 linear_r143 = some linear_b143 := by decide +kernel
theorem mutated_p143 (tail : List Nat) : parseRaw 4064 27 (linear_b143 ++ tail) = some (linear_r143, tail) := by rfl
def linear_r144 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,54,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b144 : List Nat := linear_g366
theorem mutated_s144 : serializeRaw 4063 27 linear_r144 = some linear_b144 := by decide +kernel
theorem mutated_p144 (tail : List Nat) : parseRaw 4063 27 (linear_b144 ++ tail) = some (linear_r144, tail) := by rfl
def linear_k140_0 : List Nat := [105,100]
theorem mutated_kd140_0 : stringBytes linear_k140_0 = true := by decide +kernel
theorem mutated_kp140_0 (tail : List Nat) : parseStringTail (linear_k140_0 ++ (34 :: 58 :: tail)) [] = some (linear_k140_0, 58 :: tail) := by rfl
def linear_k140_1 : List Nat := [111,112,115]
theorem mutated_kd140_1 : stringBytes linear_k140_1 = true := by decide +kernel
theorem mutated_kp140_1 (tail : List Nat) : parseStringTail (linear_k140_1 ++ (34 :: 58 :: tail)) [] = some (linear_k140_1, 58 :: tail) := by rfl
def linear_k140_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd140_2 : stringBytes linear_k140_2 = true := by decide +kernel
theorem mutated_kp140_2 (tail : List Nat) : parseStringTail (linear_k140_2 ++ (34 :: 58 :: tail)) [] = some (linear_k140_2, 58 :: tail) := by rfl
def linear_k140_3 : List Nat := [116,101,114,109]
theorem mutated_kd140_3 : stringBytes linear_k140_3 = true := by decide +kernel
theorem mutated_kp140_3 (tail : List Nat) : parseStringTail (linear_k140_3 ++ (34 :: 58 :: tail)) [] = some (linear_k140_3, 58 :: tail) := by rfl
def linear_l140_3 : List (List Nat × Raw) := [(linear_k140_3, linear_r144)]
def linear_v140_3 : List Nat := linear_g365 ++ linear_b144
theorem mutated_sl140_3 : serializeFields 4064 27 linear_l140_3 = some linear_v140_3 := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4063 27 linear_k140_3 linear_r144 linear_b144 mutated_kd140_3 mutated_s144)
theorem mutated_pl140_3 (tail : List Nat) : parseFields 4064 27 (linear_v140_3 ++ (125 :: tail)) = some (linear_l140_3, tail) := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4063 27 (linear_k140_3 ++ (34 :: 58 :: (linear_b144 ++ (125 :: tail)))) linear_k140_3 (linear_b144 ++ (125 :: tail)) tail linear_r144 (mutated_kp140_3 (linear_b144 ++ (125 :: tail))) (mutated_p144 (125 :: tail)))
def linear_l140_2 : List (List Nat × Raw) := (linear_k140_2, linear_r143) :: linear_l140_3
def linear_v140_2 : List Nat := (linear_g362 ++ linear_b143) ++ (44 :: linear_v140_3)
theorem mutated_sl140_2 : serializeFields 4065 27 linear_l140_2 = some linear_v140_2 := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k140_2 linear_r143 (linear_k140_3, linear_r144) [] linear_b143 linear_v140_3 mutated_kd140_2 mutated_s143 mutated_sl140_3)
theorem mutated_pl140_2 (tail : List Nat) : parseFields 4065 27 (linear_v140_2 ++ (125 :: tail)) = some (linear_l140_2, tail) := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k140_2 ++ (34 :: 58 :: (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))))) linear_k140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))) (linear_v140_3 ++ (125 :: tail)) tail linear_r143 linear_l140_3 (mutated_kp140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail))))) (mutated_p143 (44 :: (linear_v140_3 ++ (125 :: tail)))) (mutated_pl140_3 tail))
def linear_l140_1 : List (List Nat × Raw) := (linear_k140_1, linear_r142) :: linear_l140_2
def linear_v140_1 : List Nat := (linear_g359 ++ linear_b142) ++ (44 :: linear_v140_2)
theorem mutated_sl140_1 : serializeFields 4066 27 linear_l140_1 = some linear_v140_1 := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k140_1 linear_r142 (linear_k140_2, linear_r143) linear_l140_3 linear_b142 linear_v140_2 mutated_kd140_1 mutated_s142 mutated_sl140_2)
theorem mutated_pl140_1 (tail : List Nat) : parseFields 4066 27 (linear_v140_1 ++ (125 :: tail)) = some (linear_l140_1, tail) := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k140_1 ++ (34 :: 58 :: (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))))) linear_k140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))) (linear_v140_2 ++ (125 :: tail)) tail linear_r142 linear_l140_2 (mutated_kp140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail))))) (mutated_p142 (44 :: (linear_v140_2 ++ (125 :: tail)))) (mutated_pl140_2 tail))
def linear_l140_0 : List (List Nat × Raw) := (linear_k140_0, linear_r141) :: linear_l140_1
def linear_v140_0 : List Nat := (linear_g356 ++ linear_b141) ++ (44 :: linear_v140_1)
theorem mutated_sl140_0 : serializeFields 4067 27 linear_l140_0 = some linear_v140_0 := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k140_0 linear_r141 (linear_k140_1, linear_r142) linear_l140_2 linear_b141 linear_v140_1 mutated_kd140_0 mutated_s141 mutated_sl140_1)
theorem mutated_pl140_0 (tail : List Nat) : parseFields 4067 27 (linear_v140_0 ++ (125 :: tail)) = some (linear_l140_0, tail) := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) linear_k140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))) (linear_v140_1 ++ (125 :: tail)) tail linear_r141 linear_l140_1 (mutated_kp140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail))))) (mutated_p141 (44 :: (linear_v140_1 ++ (125 :: tail)))) (mutated_pl140_1 tail))
def linear_r140 : Raw := (.obj linear_l140_0)
def linear_b140 : List Nat := linear_g355 ++ (linear_v140_0 ++ linear_g367)
theorem mutated_o140 : orderedFields linear_l140_0 = true := by decide +kernel
theorem mutated_s140 : serializeRaw 4068 28 linear_r140 = some linear_b140 := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4067 27 linear_l140_0 linear_v140_0 mutated_o140 mutated_sl140_0)
theorem mutated_p140 (tail : List Nat) : parseRaw 4068 28 (linear_b140 ++ tail) = some (linear_r140, tail) := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4067 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) tail linear_l140_0 mutated_o140 (by simpa only [linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl140_0 tail)))
def linear_r146 : Raw := (.str [100,103,95,103,117,97,114,100,95,49])
def linear_b146 : List Nat := linear_g371
theorem mutated_s146 : serializeRaw 4065 27 linear_r146 = some linear_b146 := by decide +kernel
theorem mutated_p146 (tail : List Nat) : parseRaw 4065 27 (linear_b146 ++ tail) = some (linear_r146, tail) := by rfl
def linear_r147 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,55,49]),(.str [100,103,95,118,95,49,55,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,51])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b147 : List Nat := linear_g374
theorem mutated_s147 : serializeRaw 4064 27 linear_r147 = some linear_b147 := by decide +kernel
theorem mutated_p147 (tail : List Nat) : parseRaw 4064 27 (linear_b147 ++ tail) = some (linear_r147, tail) := by rfl
def linear_r148 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b148 : List Nat := linear_g377
theorem mutated_s148 : serializeRaw 4063 27 linear_r148 = some linear_b148 := by decide +kernel
theorem mutated_p148 (tail : List Nat) : parseRaw 4063 27 (linear_b148 ++ tail) = some (linear_r148, tail) := by rfl
def linear_r149 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,55,51])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b149 : List Nat := linear_g380
theorem mutated_s149 : serializeRaw 4062 27 linear_r149 = some linear_b149 := by decide +kernel
theorem mutated_p149 (tail : List Nat) : parseRaw 4062 27 (linear_b149 ++ tail) = some (linear_r149, tail) := by rfl
def linear_k145_0 : List Nat := [105,100]
theorem mutated_kd145_0 : stringBytes linear_k145_0 = true := by decide +kernel
theorem mutated_kp145_0 (tail : List Nat) : parseStringTail (linear_k145_0 ++ (34 :: 58 :: tail)) [] = some (linear_k145_0, 58 :: tail) := by rfl
def linear_k145_1 : List Nat := [111,112,115]
theorem mutated_kd145_1 : stringBytes linear_k145_1 = true := by decide +kernel
theorem mutated_kp145_1 (tail : List Nat) : parseStringTail (linear_k145_1 ++ (34 :: 58 :: tail)) [] = some (linear_k145_1, 58 :: tail) := by rfl
def linear_k145_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd145_2 : stringBytes linear_k145_2 = true := by decide +kernel
theorem mutated_kp145_2 (tail : List Nat) : parseStringTail (linear_k145_2 ++ (34 :: 58 :: tail)) [] = some (linear_k145_2, 58 :: tail) := by rfl
def linear_k145_3 : List Nat := [116,101,114,109]
theorem mutated_kd145_3 : stringBytes linear_k145_3 = true := by decide +kernel
theorem mutated_kp145_3 (tail : List Nat) : parseStringTail (linear_k145_3 ++ (34 :: 58 :: tail)) [] = some (linear_k145_3, 58 :: tail) := by rfl
def linear_l145_3 : List (List Nat × Raw) := [(linear_k145_3, linear_r149)]
def linear_v145_3 : List Nat := linear_g379 ++ linear_b149
theorem mutated_sl145_3 : serializeFields 4063 27 linear_l145_3 = some linear_v145_3 := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4062 27 linear_k145_3 linear_r149 linear_b149 mutated_kd145_3 mutated_s149)
theorem mutated_pl145_3 (tail : List Nat) : parseFields 4063 27 (linear_v145_3 ++ (125 :: tail)) = some (linear_l145_3, tail) := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4062 27 (linear_k145_3 ++ (34 :: 58 :: (linear_b149 ++ (125 :: tail)))) linear_k145_3 (linear_b149 ++ (125 :: tail)) tail linear_r149 (mutated_kp145_3 (linear_b149 ++ (125 :: tail))) (mutated_p149 (125 :: tail)))
def linear_l145_2 : List (List Nat × Raw) := (linear_k145_2, linear_r148) :: linear_l145_3
def linear_v145_2 : List Nat := (linear_g376 ++ linear_b148) ++ (44 :: linear_v145_3)
theorem mutated_sl145_2 : serializeFields 4064 27 linear_l145_2 = some linear_v145_2 := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4063 27 linear_k145_2 linear_r148 (linear_k145_3, linear_r149) [] linear_b148 linear_v145_3 mutated_kd145_2 mutated_s148 mutated_sl145_3)
theorem mutated_pl145_2 (tail : List Nat) : parseFields 4064 27 (linear_v145_2 ++ (125 :: tail)) = some (linear_l145_2, tail) := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4063 27 (linear_k145_2 ++ (34 :: 58 :: (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))))) linear_k145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))) (linear_v145_3 ++ (125 :: tail)) tail linear_r148 linear_l145_3 (mutated_kp145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail))))) (mutated_p148 (44 :: (linear_v145_3 ++ (125 :: tail)))) (mutated_pl145_3 tail))
def linear_l145_1 : List (List Nat × Raw) := (linear_k145_1, linear_r147) :: linear_l145_2
def linear_v145_1 : List Nat := (linear_g373 ++ linear_b147) ++ (44 :: linear_v145_2)
theorem mutated_sl145_1 : serializeFields 4065 27 linear_l145_1 = some linear_v145_1 := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k145_1 linear_r147 (linear_k145_2, linear_r148) linear_l145_3 linear_b147 linear_v145_2 mutated_kd145_1 mutated_s147 mutated_sl145_2)
theorem mutated_pl145_1 (tail : List Nat) : parseFields 4065 27 (linear_v145_1 ++ (125 :: tail)) = some (linear_l145_1, tail) := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k145_1 ++ (34 :: 58 :: (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))))) linear_k145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))) (linear_v145_2 ++ (125 :: tail)) tail linear_r147 linear_l145_2 (mutated_kp145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail))))) (mutated_p147 (44 :: (linear_v145_2 ++ (125 :: tail)))) (mutated_pl145_2 tail))
def linear_l145_0 : List (List Nat × Raw) := (linear_k145_0, linear_r146) :: linear_l145_1
def linear_v145_0 : List Nat := (linear_g370 ++ linear_b146) ++ (44 :: linear_v145_1)
theorem mutated_sl145_0 : serializeFields 4066 27 linear_l145_0 = some linear_v145_0 := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k145_0 linear_r146 (linear_k145_1, linear_r147) linear_l145_2 linear_b146 linear_v145_1 mutated_kd145_0 mutated_s146 mutated_sl145_1)
theorem mutated_pl145_0 (tail : List Nat) : parseFields 4066 27 (linear_v145_0 ++ (125 :: tail)) = some (linear_l145_0, tail) := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) linear_k145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))) (linear_v145_1 ++ (125 :: tail)) tail linear_r146 linear_l145_1 (mutated_kp145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail))))) (mutated_p146 (44 :: (linear_v145_1 ++ (125 :: tail)))) (mutated_pl145_1 tail))
def linear_r145 : Raw := (.obj linear_l145_0)
def linear_b145 : List Nat := linear_g369 ++ (linear_v145_0 ++ linear_g381)
theorem mutated_o145 : orderedFields linear_l145_0 = true := by decide +kernel
theorem mutated_s145 : serializeRaw 4067 28 linear_r145 = some linear_b145 := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4066 27 linear_l145_0 linear_v145_0 mutated_o145 mutated_sl145_0)
theorem mutated_p145 (tail : List Nat) : parseRaw 4067 28 (linear_b145 ++ tail) = some (linear_r145, tail) := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4066 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) tail linear_l145_0 mutated_o145 (by simpa only [linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl145_0 tail)))
def linear_l4_20 : List Raw := [linear_r145]
def linear_v4_20 : List Nat := linear_b145
theorem mutated_sl4_20 : serializeItems 4068 28 linear_l4_20 = some linear_v4_20 := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4067 28 linear_r145 linear_b145 mutated_s145)
theorem mutated_pl4_20 (tail : List Nat) : parseItems 4068 28 (linear_v4_20 ++ (93 :: tail)) = some (linear_l4_20, tail) := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4067 28 (linear_b145 ++ (93 :: tail)) tail linear_r145 (mutated_p145 (93 :: tail)))
def linear_l4_19 : List Raw := linear_r140 :: linear_l4_20
def linear_v4_19 : List Nat := (linear_b140) ++ (44 :: linear_v4_20)
theorem mutated_sl4_19 : serializeItems 4069 28 linear_l4_19 = some linear_v4_19 := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 28 linear_r140 linear_r145 [] linear_b140 linear_v4_20 mutated_s140 mutated_sl4_20)
theorem mutated_pl4_19 (tail : List Nat) : parseItems 4069 28 (linear_v4_19 ++ (93 :: tail)) = some (linear_l4_19, tail) := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 28 (linear_b140 ++ (44 :: (linear_v4_20 ++ (93 :: tail)))) (linear_v4_20 ++ (93 :: tail)) tail linear_r140 linear_l4_20 (mutated_p140 (44 :: (linear_v4_20 ++ (93 :: tail)))) (mutated_pl4_20 tail))
def linear_l4_18 : List Raw := linear_r135 :: linear_l4_19
def linear_v4_18 : List Nat := (linear_b135) ++ (44 :: linear_v4_19)
theorem mutated_sl4_18 : serializeItems 4070 28 linear_l4_18 = some linear_v4_18 := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 28 linear_r135 linear_r140 linear_l4_20 linear_b135 linear_v4_19 mutated_s135 mutated_sl4_19)
theorem mutated_pl4_18 (tail : List Nat) : parseItems 4070 28 (linear_v4_18 ++ (93 :: tail)) = some (linear_l4_18, tail) := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 28 (linear_b135 ++ (44 :: (linear_v4_19 ++ (93 :: tail)))) (linear_v4_19 ++ (93 :: tail)) tail linear_r135 linear_l4_19 (mutated_p135 (44 :: (linear_v4_19 ++ (93 :: tail)))) (mutated_pl4_19 tail))
def linear_l4_17 : List Raw := linear_r123 :: linear_l4_18
def linear_v4_17 : List Nat := (linear_b123) ++ (44 :: linear_v4_18)
theorem mutated_sl4_17 : serializeItems 4071 28 linear_l4_17 = some linear_v4_17 := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 28 linear_r123 linear_r135 linear_l4_19 linear_b123 linear_v4_18 mutated_s123 mutated_sl4_18)
theorem mutated_pl4_17 (tail : List Nat) : parseItems 4071 28 (linear_v4_17 ++ (93 :: tail)) = some (linear_l4_17, tail) := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 28 (linear_b123 ++ (44 :: (linear_v4_18 ++ (93 :: tail)))) (linear_v4_18 ++ (93 :: tail)) tail linear_r123 linear_l4_18 (mutated_p123 (44 :: (linear_v4_18 ++ (93 :: tail)))) (mutated_pl4_18 tail))
def linear_l4_16 : List Raw := linear_r118 :: linear_l4_17
def linear_v4_16 : List Nat := (linear_b118) ++ (44 :: linear_v4_17)
theorem mutated_sl4_16 : serializeItems 4072 28 linear_l4_16 = some linear_v4_16 := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 28 linear_r118 linear_r123 linear_l4_18 linear_b118 linear_v4_17 mutated_s118 mutated_sl4_17)
theorem mutated_pl4_16 (tail : List Nat) : parseItems 4072 28 (linear_v4_16 ++ (93 :: tail)) = some (linear_l4_16, tail) := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 28 (linear_b118 ++ (44 :: (linear_v4_17 ++ (93 :: tail)))) (linear_v4_17 ++ (93 :: tail)) tail linear_r118 linear_l4_17 (mutated_p118 (44 :: (linear_v4_17 ++ (93 :: tail)))) (mutated_pl4_17 tail))
def linear_l4_15 : List Raw := linear_r113 :: linear_l4_16
def linear_v4_15 : List Nat := (linear_b113) ++ (44 :: linear_v4_16)
theorem mutated_sl4_15 : serializeItems 4073 28 linear_l4_15 = some linear_v4_15 := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 28 linear_r113 linear_r118 linear_l4_17 linear_b113 linear_v4_16 mutated_s113 mutated_sl4_16)
theorem mutated_pl4_15 (tail : List Nat) : parseItems 4073 28 (linear_v4_15 ++ (93 :: tail)) = some (linear_l4_15, tail) := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 28 (linear_b113 ++ (44 :: (linear_v4_16 ++ (93 :: tail)))) (linear_v4_16 ++ (93 :: tail)) tail linear_r113 linear_l4_16 (mutated_p113 (44 :: (linear_v4_16 ++ (93 :: tail)))) (mutated_pl4_16 tail))
def linear_l4_14 : List Raw := linear_r97 :: linear_l4_15
def linear_v4_14 : List Nat := (linear_b97) ++ (44 :: linear_v4_15)
theorem mutated_sl4_14 : serializeItems 4074 28 linear_l4_14 = some linear_v4_14 := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 28 linear_r97 linear_r113 linear_l4_16 linear_b97 linear_v4_15 mutated_s97 mutated_sl4_15)
theorem mutated_pl4_14 (tail : List Nat) : parseItems 4074 28 (linear_v4_14 ++ (93 :: tail)) = some (linear_l4_14, tail) := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 28 (linear_b97 ++ (44 :: (linear_v4_15 ++ (93 :: tail)))) (linear_v4_15 ++ (93 :: tail)) tail linear_r97 linear_l4_15 (mutated_p97 (44 :: (linear_v4_15 ++ (93 :: tail)))) (mutated_pl4_15 tail))
def linear_l4_13 : List Raw := linear_r92 :: linear_l4_14
def linear_v4_13 : List Nat := (linear_b92) ++ (44 :: linear_v4_14)
theorem mutated_sl4_13 : serializeItems 4075 28 linear_l4_13 = some linear_v4_13 := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 28 linear_r92 linear_r97 linear_l4_15 linear_b92 linear_v4_14 mutated_s92 mutated_sl4_14)
theorem mutated_pl4_13 (tail : List Nat) : parseItems 4075 28 (linear_v4_13 ++ (93 :: tail)) = some (linear_l4_13, tail) := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 28 (linear_b92 ++ (44 :: (linear_v4_14 ++ (93 :: tail)))) (linear_v4_14 ++ (93 :: tail)) tail linear_r92 linear_l4_14 (mutated_p92 (44 :: (linear_v4_14 ++ (93 :: tail)))) (mutated_pl4_14 tail))
def linear_l4_12 : List Raw := linear_r87 :: linear_l4_13
def linear_v4_12 : List Nat := (linear_b87) ++ (44 :: linear_v4_13)
theorem mutated_sl4_12 : serializeItems 4076 28 linear_l4_12 = some linear_v4_12 := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4075 28 linear_r87 linear_r92 linear_l4_14 linear_b87 linear_v4_13 mutated_s87 mutated_sl4_13)
theorem mutated_pl4_12 (tail : List Nat) : parseItems 4076 28 (linear_v4_12 ++ (93 :: tail)) = some (linear_l4_12, tail) := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4075 28 (linear_b87 ++ (44 :: (linear_v4_13 ++ (93 :: tail)))) (linear_v4_13 ++ (93 :: tail)) tail linear_r87 linear_l4_13 (mutated_p87 (44 :: (linear_v4_13 ++ (93 :: tail)))) (mutated_pl4_13 tail))
def linear_l4_11 : List Raw := linear_r75 :: linear_l4_12
def linear_v4_11 : List Nat := (linear_b75) ++ (44 :: linear_v4_12)
theorem mutated_sl4_11 : serializeItems 4077 28 linear_l4_11 = some linear_v4_11 := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4076 28 linear_r75 linear_r87 linear_l4_13 linear_b75 linear_v4_12 mutated_s75 mutated_sl4_12)
theorem mutated_pl4_11 (tail : List Nat) : parseItems 4077 28 (linear_v4_11 ++ (93 :: tail)) = some (linear_l4_11, tail) := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4076 28 (linear_b75 ++ (44 :: (linear_v4_12 ++ (93 :: tail)))) (linear_v4_12 ++ (93 :: tail)) tail linear_r75 linear_l4_12 (mutated_p75 (44 :: (linear_v4_12 ++ (93 :: tail)))) (mutated_pl4_12 tail))
def linear_l4_10 : List Raw := linear_r70 :: linear_l4_11
def linear_v4_10 : List Nat := (linear_b70) ++ (44 :: linear_v4_11)
theorem mutated_sl4_10 : serializeItems 4078 28 linear_l4_10 = some linear_v4_10 := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4077 28 linear_r70 linear_r75 linear_l4_12 linear_b70 linear_v4_11 mutated_s70 mutated_sl4_11)
theorem mutated_pl4_10 (tail : List Nat) : parseItems 4078 28 (linear_v4_10 ++ (93 :: tail)) = some (linear_l4_10, tail) := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4077 28 (linear_b70 ++ (44 :: (linear_v4_11 ++ (93 :: tail)))) (linear_v4_11 ++ (93 :: tail)) tail linear_r70 linear_l4_11 (mutated_p70 (44 :: (linear_v4_11 ++ (93 :: tail)))) (mutated_pl4_11 tail))
def linear_l4_9 : List Raw := linear_r65 :: linear_l4_10
def linear_v4_9 : List Nat := (linear_b65) ++ (44 :: linear_v4_10)
theorem mutated_sl4_9 : serializeItems 4079 28 linear_l4_9 = some linear_v4_9 := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 28 linear_r65 linear_r70 linear_l4_11 linear_b65 linear_v4_10 mutated_s65 mutated_sl4_10)
theorem mutated_pl4_9 (tail : List Nat) : parseItems 4079 28 (linear_v4_9 ++ (93 :: tail)) = some (linear_l4_9, tail) := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 28 (linear_b65 ++ (44 :: (linear_v4_10 ++ (93 :: tail)))) (linear_v4_10 ++ (93 :: tail)) tail linear_r65 linear_l4_10 (mutated_p65 (44 :: (linear_v4_10 ++ (93 :: tail)))) (mutated_pl4_10 tail))
def linear_l4_8 : List Raw := linear_r49 :: linear_l4_9
def linear_v4_8 : List Nat := (linear_b49) ++ (44 :: linear_v4_9)
theorem mutated_sl4_8 : serializeItems 4080 28 linear_l4_8 = some linear_v4_8 := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 28 linear_r49 linear_r65 linear_l4_10 linear_b49 linear_v4_9 mutated_s49 mutated_sl4_9)
theorem mutated_pl4_8 (tail : List Nat) : parseItems 4080 28 (linear_v4_8 ++ (93 :: tail)) = some (linear_l4_8, tail) := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 28 (linear_b49 ++ (44 :: (linear_v4_9 ++ (93 :: tail)))) (linear_v4_9 ++ (93 :: tail)) tail linear_r49 linear_l4_9 (mutated_p49 (44 :: (linear_v4_9 ++ (93 :: tail)))) (mutated_pl4_9 tail))
def linear_l4_7 : List Raw := linear_r44 :: linear_l4_8
def linear_v4_7 : List Nat := (linear_b44) ++ (44 :: linear_v4_8)
theorem mutated_sl4_7 : serializeItems 4081 28 linear_l4_7 = some linear_v4_7 := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 28 linear_r44 linear_r49 linear_l4_9 linear_b44 linear_v4_8 mutated_s44 mutated_sl4_8)
theorem mutated_pl4_7 (tail : List Nat) : parseItems 4081 28 (linear_v4_7 ++ (93 :: tail)) = some (linear_l4_7, tail) := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 28 (linear_b44 ++ (44 :: (linear_v4_8 ++ (93 :: tail)))) (linear_v4_8 ++ (93 :: tail)) tail linear_r44 linear_l4_8 (mutated_p44 (44 :: (linear_v4_8 ++ (93 :: tail)))) (mutated_pl4_8 tail))
def linear_l4_6 : List Raw := linear_r39 :: linear_l4_7
def linear_v4_6 : List Nat := (linear_b39) ++ (44 :: linear_v4_7)
theorem mutated_sl4_6 : serializeItems 4082 28 linear_l4_6 = some linear_v4_6 := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4081 28 linear_r39 linear_r44 linear_l4_8 linear_b39 linear_v4_7 mutated_s39 mutated_sl4_7)
theorem mutated_pl4_6 (tail : List Nat) : parseItems 4082 28 (linear_v4_6 ++ (93 :: tail)) = some (linear_l4_6, tail) := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4081 28 (linear_b39 ++ (44 :: (linear_v4_7 ++ (93 :: tail)))) (linear_v4_7 ++ (93 :: tail)) tail linear_r39 linear_l4_7 (mutated_p39 (44 :: (linear_v4_7 ++ (93 :: tail)))) (mutated_pl4_7 tail))
def linear_l4_5 : List Raw := linear_r34 :: linear_l4_6
def linear_v4_5 : List Nat := (linear_b34) ++ (44 :: linear_v4_6)
theorem mutated_sl4_5 : serializeItems 4083 28 linear_l4_5 = some linear_v4_5 := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4082 28 linear_r34 linear_r39 linear_l4_7 linear_b34 linear_v4_6 mutated_s34 mutated_sl4_6)
theorem mutated_pl4_5 (tail : List Nat) : parseItems 4083 28 (linear_v4_5 ++ (93 :: tail)) = some (linear_l4_5, tail) := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4082 28 (linear_b34 ++ (44 :: (linear_v4_6 ++ (93 :: tail)))) (linear_v4_6 ++ (93 :: tail)) tail linear_r34 linear_l4_6 (mutated_p34 (44 :: (linear_v4_6 ++ (93 :: tail)))) (mutated_pl4_6 tail))
def linear_l4_4 : List Raw := linear_r29 :: linear_l4_5
def linear_v4_4 : List Nat := (linear_b29) ++ (44 :: linear_v4_5)
theorem mutated_sl4_4 : serializeItems 4084 28 linear_l4_4 = some linear_v4_4 := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4083 28 linear_r29 linear_r34 linear_l4_6 linear_b29 linear_v4_5 mutated_s29 mutated_sl4_5)
theorem mutated_pl4_4 (tail : List Nat) : parseItems 4084 28 (linear_v4_4 ++ (93 :: tail)) = some (linear_l4_4, tail) := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4083 28 (linear_b29 ++ (44 :: (linear_v4_5 ++ (93 :: tail)))) (linear_v4_5 ++ (93 :: tail)) tail linear_r29 linear_l4_5 (mutated_p29 (44 :: (linear_v4_5 ++ (93 :: tail)))) (mutated_pl4_5 tail))
def linear_l4_3 : List Raw := linear_r24 :: linear_l4_4
def linear_v4_3 : List Nat := (linear_b24) ++ (44 :: linear_v4_4)
theorem mutated_sl4_3 : serializeItems 4085 28 linear_l4_3 = some linear_v4_3 := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4084 28 linear_r24 linear_r29 linear_l4_5 linear_b24 linear_v4_4 mutated_s24 mutated_sl4_4)
theorem mutated_pl4_3 (tail : List Nat) : parseItems 4085 28 (linear_v4_3 ++ (93 :: tail)) = some (linear_l4_3, tail) := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4084 28 (linear_b24 ++ (44 :: (linear_v4_4 ++ (93 :: tail)))) (linear_v4_4 ++ (93 :: tail)) tail linear_r24 linear_l4_4 (mutated_p24 (44 :: (linear_v4_4 ++ (93 :: tail)))) (mutated_pl4_4 tail))
def linear_l4_2 : List Raw := linear_r15 :: linear_l4_3
def linear_v4_2 : List Nat := (linear_b15) ++ (44 :: linear_v4_3)
theorem mutated_sl4_2 : serializeItems 4086 28 linear_l4_2 = some linear_v4_2 := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4085 28 linear_r15 linear_r24 linear_l4_4 linear_b15 linear_v4_3 mutated_s15 mutated_sl4_3)
theorem mutated_pl4_2 (tail : List Nat) : parseItems 4086 28 (linear_v4_2 ++ (93 :: tail)) = some (linear_l4_2, tail) := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4085 28 (linear_b15 ++ (44 :: (linear_v4_3 ++ (93 :: tail)))) (linear_v4_3 ++ (93 :: tail)) tail linear_r15 linear_l4_3 (mutated_p15 (44 :: (linear_v4_3 ++ (93 :: tail)))) (mutated_pl4_3 tail))
def linear_l4_1 : List Raw := linear_r10 :: linear_l4_2
def linear_v4_1 : List Nat := (linear_b10) ++ (44 :: linear_v4_2)
theorem mutated_sl4_1 : serializeItems 4087 28 linear_l4_1 = some linear_v4_1 := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4086 28 linear_r10 linear_r15 linear_l4_3 linear_b10 linear_v4_2 mutated_s10 mutated_sl4_2)
theorem mutated_pl4_1 (tail : List Nat) : parseItems 4087 28 (linear_v4_1 ++ (93 :: tail)) = some (linear_l4_1, tail) := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4086 28 (linear_b10 ++ (44 :: (linear_v4_2 ++ (93 :: tail)))) (linear_v4_2 ++ (93 :: tail)) tail linear_r10 linear_l4_2 (mutated_p10 (44 :: (linear_v4_2 ++ (93 :: tail)))) (mutated_pl4_2 tail))
def linear_l4_0 : List Raw := linear_r5 :: linear_l4_1
def linear_v4_0 : List Nat := (linear_b5) ++ (44 :: linear_v4_1)
theorem mutated_sl4_0 : serializeItems 4088 28 linear_l4_0 = some linear_v4_0 := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4087 28 linear_r5 linear_r10 linear_l4_2 linear_b5 linear_v4_1 mutated_s5 mutated_sl4_1)
theorem mutated_pl4_0 (tail : List Nat) : parseItems 4088 28 (linear_v4_0 ++ (93 :: tail)) = some (linear_l4_0, tail) := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4087 28 (linear_b5 ++ (44 :: (linear_v4_1 ++ (93 :: tail)))) (linear_v4_1 ++ (93 :: tail)) tail linear_r5 linear_l4_1 (mutated_p5 (44 :: (linear_v4_1 ++ (93 :: tail)))) (mutated_pl4_1 tail))
def linear_r4 : Raw := (.arr linear_l4_0)
def linear_b4 : List Nat := linear_g8 ++ (linear_v4_0 ++ linear_g382)
theorem mutated_s4 : serializeRaw 4089 29 linear_r4 = some linear_b4 := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4088 28 linear_l4_0 linear_v4_0 mutated_sl4_0)
theorem mutated_p4 (tail : List Nat) : parseRaw 4089 29 (linear_b4 ++ tail) = some (linear_r4, tail) := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4088 28 (linear_v4_0 ++ (93 :: tail)) tail linear_l4_0 (by intro h; cases h) (mutated_pl4_0 tail))
def linear_r150 : Raw := (.arr [(.str [97,108,108,111,99]),(.str [114,101,97,100]),(.str [116,114,97,112]),(.str [119,114,105,116,101])])
def linear_b150 : List Nat := linear_g385
theorem mutated_s150 : serializeRaw 4088 29 linear_r150 = some linear_b150 := by decide +kernel
theorem mutated_p150 (tail : List Nat) : parseRaw 4088 29 (linear_b150 ++ tail) = some (linear_r150, tail) := by rfl
def linear_r151 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b151 : List Nat := linear_g388
theorem mutated_s151 : serializeRaw 4087 29 linear_r151 = some linear_b151 := by decide +kernel
theorem mutated_p151 (tail : List Nat) : parseRaw 4087 29 (linear_b151 ++ tail) = some (linear_r151, tail) := by rfl
def linear_r152 : Raw := (.str [99,97,108,99,117,108,97,116,101])
def linear_b152 : List Nat := linear_g391
theorem mutated_s152 : serializeRaw 4086 29 linear_r152 = some linear_b152 := by decide +kernel
theorem mutated_p152 (tail : List Nat) : parseRaw 4086 29 (linear_b152 ++ tail) = some (linear_r152, tail) := by rfl
def linear_r153 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b153 : List Nat := linear_g394
theorem mutated_s153 : serializeRaw 4085 29 linear_r153 = some linear_b153 := by decide +kernel
theorem mutated_p153 (tail : List Nat) : parseRaw 4085 29 (linear_b153 ++ tail) = some (linear_r153, tail) := by rfl
def linear_r154 : Raw := (.arr [(.str [117,54,52])])
def linear_b154 : List Nat := linear_g397
theorem mutated_s154 : serializeRaw 4084 29 linear_r154 = some linear_b154 := by decide +kernel
theorem mutated_p154 (tail : List Nat) : parseRaw 4084 29 (linear_b154 ++ tail) = some (linear_r154, tail) := by rfl
def linear_k3_0 : List Nat := [98,108,111,99,107,115]
theorem mutated_kd3_0 : stringBytes linear_k3_0 = true := by decide +kernel
theorem mutated_kp3_0 (tail : List Nat) : parseStringTail (linear_k3_0 ++ (34 :: 58 :: tail)) [] = some (linear_k3_0, 58 :: tail) := by rfl
def linear_k3_1 : List Nat := [101,102,102,101,99,116,115]
theorem mutated_kd3_1 : stringBytes linear_k3_1 = true := by decide +kernel
theorem mutated_kp3_1 (tail : List Nat) : parseStringTail (linear_k3_1 ++ (34 :: 58 :: tail)) [] = some (linear_k3_1, 58 :: tail) := by rfl
def linear_k3_2 : List Nat := [101,110,116,114,121]
theorem mutated_kd3_2 : stringBytes linear_k3_2 = true := by decide +kernel
theorem mutated_kp3_2 (tail : List Nat) : parseStringTail (linear_k3_2 ++ (34 :: 58 :: tail)) [] = some (linear_k3_2, 58 :: tail) := by rfl
def linear_k3_3 : List Nat := [110,97,109,101]
theorem mutated_kd3_3 : stringBytes linear_k3_3 = true := by decide +kernel
theorem mutated_kp3_3 (tail : List Nat) : parseStringTail (linear_k3_3 ++ (34 :: 58 :: tail)) [] = some (linear_k3_3, 58 :: tail) := by rfl
def linear_k3_4 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd3_4 : stringBytes linear_k3_4 = true := by decide +kernel
theorem mutated_kp3_4 (tail : List Nat) : parseStringTail (linear_k3_4 ++ (34 :: 58 :: tail)) [] = some (linear_k3_4, 58 :: tail) := by rfl
def linear_k3_5 : List Nat := [114,101,116,117,114,110,115]
theorem mutated_kd3_5 : stringBytes linear_k3_5 = true := by decide +kernel
theorem mutated_kp3_5 (tail : List Nat) : parseStringTail (linear_k3_5 ++ (34 :: 58 :: tail)) [] = some (linear_k3_5, 58 :: tail) := by rfl
def linear_l3_5 : List (List Nat × Raw) := [(linear_k3_5, linear_r154)]
def linear_v3_5 : List Nat := linear_g396 ++ linear_b154
theorem mutated_sl3_5 : serializeFields 4085 29 linear_l3_5 = some linear_v3_5 := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4084 29 linear_k3_5 linear_r154 linear_b154 mutated_kd3_5 mutated_s154)
theorem mutated_pl3_5 (tail : List Nat) : parseFields 4085 29 (linear_v3_5 ++ (125 :: tail)) = some (linear_l3_5, tail) := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4084 29 (linear_k3_5 ++ (34 :: 58 :: (linear_b154 ++ (125 :: tail)))) linear_k3_5 (linear_b154 ++ (125 :: tail)) tail linear_r154 (mutated_kp3_5 (linear_b154 ++ (125 :: tail))) (mutated_p154 (125 :: tail)))
def linear_l3_4 : List (List Nat × Raw) := (linear_k3_4, linear_r153) :: linear_l3_5
def linear_v3_4 : List Nat := (linear_g393 ++ linear_b153) ++ (44 :: linear_v3_5)
theorem mutated_sl3_4 : serializeFields 4086 29 linear_l3_4 = some linear_v3_4 := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 29 linear_k3_4 linear_r153 (linear_k3_5, linear_r154) [] linear_b153 linear_v3_5 mutated_kd3_4 mutated_s153 mutated_sl3_5)
theorem mutated_pl3_4 (tail : List Nat) : parseFields 4086 29 (linear_v3_4 ++ (125 :: tail)) = some (linear_l3_4, tail) := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 29 (linear_k3_4 ++ (34 :: 58 :: (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))))) linear_k3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))) (linear_v3_5 ++ (125 :: tail)) tail linear_r153 linear_l3_5 (mutated_kp3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail))))) (mutated_p153 (44 :: (linear_v3_5 ++ (125 :: tail)))) (mutated_pl3_5 tail))
def linear_l3_3 : List (List Nat × Raw) := (linear_k3_3, linear_r152) :: linear_l3_4
def linear_v3_3 : List Nat := (linear_g390 ++ linear_b152) ++ (44 :: linear_v3_4)
theorem mutated_sl3_3 : serializeFields 4087 29 linear_l3_3 = some linear_v3_3 := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4086 29 linear_k3_3 linear_r152 (linear_k3_4, linear_r153) linear_l3_5 linear_b152 linear_v3_4 mutated_kd3_3 mutated_s152 mutated_sl3_4)
theorem mutated_pl3_3 (tail : List Nat) : parseFields 4087 29 (linear_v3_3 ++ (125 :: tail)) = some (linear_l3_3, tail) := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4086 29 (linear_k3_3 ++ (34 :: 58 :: (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))))) linear_k3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))) (linear_v3_4 ++ (125 :: tail)) tail linear_r152 linear_l3_4 (mutated_kp3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail))))) (mutated_p152 (44 :: (linear_v3_4 ++ (125 :: tail)))) (mutated_pl3_4 tail))
def linear_l3_2 : List (List Nat × Raw) := (linear_k3_2, linear_r151) :: linear_l3_3
def linear_v3_2 : List Nat := (linear_g387 ++ linear_b151) ++ (44 :: linear_v3_3)
theorem mutated_sl3_2 : serializeFields 4088 29 linear_l3_2 = some linear_v3_2 := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4087 29 linear_k3_2 linear_r151 (linear_k3_3, linear_r152) linear_l3_4 linear_b151 linear_v3_3 mutated_kd3_2 mutated_s151 mutated_sl3_3)
theorem mutated_pl3_2 (tail : List Nat) : parseFields 4088 29 (linear_v3_2 ++ (125 :: tail)) = some (linear_l3_2, tail) := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4087 29 (linear_k3_2 ++ (34 :: 58 :: (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))))) linear_k3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))) (linear_v3_3 ++ (125 :: tail)) tail linear_r151 linear_l3_3 (mutated_kp3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail))))) (mutated_p151 (44 :: (linear_v3_3 ++ (125 :: tail)))) (mutated_pl3_3 tail))
def linear_l3_1 : List (List Nat × Raw) := (linear_k3_1, linear_r150) :: linear_l3_2
def linear_v3_1 : List Nat := (linear_g384 ++ linear_b150) ++ (44 :: linear_v3_2)
theorem mutated_sl3_1 : serializeFields 4089 29 linear_l3_1 = some linear_v3_1 := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4088 29 linear_k3_1 linear_r150 (linear_k3_2, linear_r151) linear_l3_3 linear_b150 linear_v3_2 mutated_kd3_1 mutated_s150 mutated_sl3_2)
theorem mutated_pl3_1 (tail : List Nat) : parseFields 4089 29 (linear_v3_1 ++ (125 :: tail)) = some (linear_l3_1, tail) := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4088 29 (linear_k3_1 ++ (34 :: 58 :: (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))))) linear_k3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))) (linear_v3_2 ++ (125 :: tail)) tail linear_r150 linear_l3_2 (mutated_kp3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail))))) (mutated_p150 (44 :: (linear_v3_2 ++ (125 :: tail)))) (mutated_pl3_2 tail))
def linear_l3_0 : List (List Nat × Raw) := (linear_k3_0, linear_r4) :: linear_l3_1
def linear_v3_0 : List Nat := (linear_g7 ++ linear_b4) ++ (44 :: linear_v3_1)
theorem mutated_sl3_0 : serializeFields 4090 29 linear_l3_0 = some linear_v3_0 := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4089 29 linear_k3_0 linear_r4 (linear_k3_1, linear_r150) linear_l3_2 linear_b4 linear_v3_1 mutated_kd3_0 mutated_s4 mutated_sl3_1)
theorem mutated_pl3_0 (tail : List Nat) : parseFields 4090 29 (linear_v3_0 ++ (125 :: tail)) = some (linear_l3_0, tail) := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4089 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) linear_k3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))) (linear_v3_1 ++ (125 :: tail)) tail linear_r4 linear_l3_1 (mutated_kp3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail))))) (mutated_p4 (44 :: (linear_v3_1 ++ (125 :: tail)))) (mutated_pl3_1 tail))
def linear_r3 : Raw := (.obj linear_l3_0)
def linear_b3 : List Nat := linear_g6 ++ (linear_v3_0 ++ linear_g398)
theorem mutated_o3 : orderedFields linear_l3_0 = true := by decide +kernel
theorem mutated_s3 : serializeRaw 4091 30 linear_r3 = some linear_b3 := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4090 29 linear_l3_0 linear_v3_0 mutated_o3 mutated_sl3_0)
theorem mutated_p3 (tail : List Nat) : parseRaw 4091 30 (linear_b3 ++ tail) = some (linear_r3, tail) := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4090 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) tail linear_l3_0 mutated_o3 (by simpa only [linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl3_0 tail)))
def linear_l2_0 : List Raw := [linear_r3]
def linear_v2_0 : List Nat := linear_b3
theorem mutated_sl2_0 : serializeItems 4092 30 linear_l2_0 = some linear_v2_0 := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4091 30 linear_r3 linear_b3 mutated_s3)
theorem mutated_pl2_0 (tail : List Nat) : parseItems 4092 30 (linear_v2_0 ++ (93 :: tail)) = some (linear_l2_0, tail) := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4091 30 (linear_b3 ++ (93 :: tail)) tail linear_r3 (mutated_p3 (93 :: tail)))
def linear_r2 : Raw := (.arr linear_l2_0)
def linear_b2 : List Nat := linear_g5 ++ (linear_v2_0 ++ linear_g399)
theorem mutated_s2 : serializeRaw 4093 31 linear_r2 = some linear_b2 := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4092 30 linear_l2_0 linear_v2_0 mutated_sl2_0)
theorem mutated_p2 (tail : List Nat) : parseRaw 4093 31 (linear_b2 ++ tail) = some (linear_r2, tail) := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4092 30 (linear_v2_0 ++ (93 :: tail)) tail linear_l2_0 (by intro h; cases h) (mutated_pl2_0 tail))
def linear_r155 : Raw := (.str [114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114])
def linear_b155 : List Nat := linear_g402
theorem mutated_s155 : serializeRaw 4092 31 linear_r155 = some linear_b155 := by decide +kernel
theorem mutated_p155 (tail : List Nat) : parseRaw 4092 31 (linear_b155 ++ tail) = some (linear_r155, tail) := by rfl
def linear_r156 : Raw := (.str [104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49])
def linear_b156 : List Nat := linear_g405
theorem mutated_s156 : serializeRaw 4091 31 linear_r156 = some linear_b156 := by decide +kernel
theorem mutated_p156 (tail : List Nat) : parseRaw 4091 31 (linear_b156 ++ tail) = some (linear_r156, tail) := by rfl
def linear_k0_0 : List Nat := [101,120,112,111,114,116,115]
theorem mutated_kd0_0 : stringBytes linear_k0_0 = true := by decide +kernel
theorem mutated_kp0_0 (tail : List Nat) : parseStringTail (linear_k0_0 ++ (34 :: 58 :: tail)) [] = some (linear_k0_0, 58 :: tail) := by rfl
def linear_k0_1 : List Nat := [102,117,110,99,116,105,111,110,115]
theorem mutated_kd0_1 : stringBytes linear_k0_1 = true := by decide +kernel
theorem mutated_kp0_1 (tail : List Nat) : parseStringTail (linear_k0_1 ++ (34 :: 58 :: tail)) [] = some (linear_k0_1, 58 :: tail) := by rfl
def linear_k0_2 : List Nat := [109,111,100,117,108,101]
theorem mutated_kd0_2 : stringBytes linear_k0_2 = true := by decide +kernel
theorem mutated_kp0_2 (tail : List Nat) : parseStringTail (linear_k0_2 ++ (34 :: 58 :: tail)) [] = some (linear_k0_2, 58 :: tail) := by rfl
def linear_k0_3 : List Nat := [115,99,104,101,109,97]
theorem mutated_kd0_3 : stringBytes linear_k0_3 = true := by decide +kernel
theorem mutated_kp0_3 (tail : List Nat) : parseStringTail (linear_k0_3 ++ (34 :: 58 :: tail)) [] = some (linear_k0_3, 58 :: tail) := by rfl
def linear_l0_3 : List (List Nat × Raw) := [(linear_k0_3, linear_r156)]
def linear_v0_3 : List Nat := linear_g404 ++ linear_b156
theorem mutated_sl0_3 : serializeFields 4092 31 linear_l0_3 = some linear_v0_3 := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4091 31 linear_k0_3 linear_r156 linear_b156 mutated_kd0_3 mutated_s156)
theorem mutated_pl0_3 (tail : List Nat) : parseFields 4092 31 (linear_v0_3 ++ (125 :: tail)) = some (linear_l0_3, tail) := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4091 31 (linear_k0_3 ++ (34 :: 58 :: (linear_b156 ++ (125 :: tail)))) linear_k0_3 (linear_b156 ++ (125 :: tail)) tail linear_r156 (mutated_kp0_3 (linear_b156 ++ (125 :: tail))) (mutated_p156 (125 :: tail)))
def linear_l0_2 : List (List Nat × Raw) := (linear_k0_2, linear_r155) :: linear_l0_3
def linear_v0_2 : List Nat := (linear_g401 ++ linear_b155) ++ (44 :: linear_v0_3)
theorem mutated_sl0_2 : serializeFields 4093 31 linear_l0_2 = some linear_v0_2 := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4092 31 linear_k0_2 linear_r155 (linear_k0_3, linear_r156) [] linear_b155 linear_v0_3 mutated_kd0_2 mutated_s155 mutated_sl0_3)
theorem mutated_pl0_2 (tail : List Nat) : parseFields 4093 31 (linear_v0_2 ++ (125 :: tail)) = some (linear_l0_2, tail) := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4092 31 (linear_k0_2 ++ (34 :: 58 :: (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))))) linear_k0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))) (linear_v0_3 ++ (125 :: tail)) tail linear_r155 linear_l0_3 (mutated_kp0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail))))) (mutated_p155 (44 :: (linear_v0_3 ++ (125 :: tail)))) (mutated_pl0_3 tail))
def linear_l0_1 : List (List Nat × Raw) := (linear_k0_1, linear_r2) :: linear_l0_2
def linear_v0_1 : List Nat := (linear_g4 ++ linear_b2) ++ (44 :: linear_v0_2)
theorem mutated_sl0_1 : serializeFields 4094 31 linear_l0_1 = some linear_v0_1 := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4093 31 linear_k0_1 linear_r2 (linear_k0_2, linear_r155) linear_l0_3 linear_b2 linear_v0_2 mutated_kd0_1 mutated_s2 mutated_sl0_2)
theorem mutated_pl0_1 (tail : List Nat) : parseFields 4094 31 (linear_v0_1 ++ (125 :: tail)) = some (linear_l0_1, tail) := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4093 31 (linear_k0_1 ++ (34 :: 58 :: (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))))) linear_k0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))) (linear_v0_2 ++ (125 :: tail)) tail linear_r2 linear_l0_2 (mutated_kp0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail))))) (mutated_p2 (44 :: (linear_v0_2 ++ (125 :: tail)))) (mutated_pl0_2 tail))
def linear_l0_0 : List (List Nat × Raw) := (linear_k0_0, linear_r1) :: linear_l0_1
def linear_v0_0 : List Nat := (linear_g1 ++ linear_b1) ++ (44 :: linear_v0_1)
theorem mutated_sl0_0 : serializeFields 4095 31 linear_l0_0 = some linear_v0_0 := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4094 31 linear_k0_0 linear_r1 (linear_k0_1, linear_r2) linear_l0_2 linear_b1 linear_v0_1 mutated_kd0_0 mutated_s1 mutated_sl0_1)
theorem mutated_pl0_0 (tail : List Nat) : parseFields 4095 31 (linear_v0_0 ++ (125 :: tail)) = some (linear_l0_0, tail) := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4094 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) linear_k0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))) (linear_v0_1 ++ (125 :: tail)) tail linear_r1 linear_l0_1 (mutated_kp0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail))))) (mutated_p1 (44 :: (linear_v0_1 ++ (125 :: tail)))) (mutated_pl0_1 tail))
def linear_r0 : Raw := (.obj linear_l0_0)
def linear_b0 : List Nat := linear_g0 ++ (linear_v0_0 ++ linear_g406)
theorem mutated_o0 : orderedFields linear_l0_0 = true := by decide +kernel
theorem mutated_s0 : serializeRaw 4096 32 linear_r0 = some linear_b0 := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4095 31 linear_l0_0 linear_v0_0 mutated_o0 mutated_sl0_0)
theorem mutated_p0 (tail : List Nat) : parseRaw 4096 32 (linear_b0 ++ tail) = some (linear_r0, tail) := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4095 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) tail linear_l0_0 mutated_o0 (by simpa only [linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl0_0 tail)))
def linearRaw : Raw := linear_r0
def linearBytes : List Nat := linear_b0
theorem mutated_bounds : withinBounds linearRaw = true := by decide +kernel
theorem mutated_serialized : serializeRaw transportFuel transportDepth linearRaw = some linearBytes := by exact mutated_s0
theorem mutated_parsed : parseRaw transportFuel transportDepth linearBytes = some (linearRaw, []) := by
  simpa only [List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_p0 [])
theorem mutated_length : linearBytes.length ≤ transportByteLimit := by decide +kernel
theorem mutated_byte_range : linearBytes.all (fun byte => decide (byte ≤ 255)) = true := by decide +kernel
theorem mutated_transport : checkedEncode linearRaw = some linearBytes := checkedEncode_of_parts linearRaw linearBytes mutated_bounds mutated_serialized mutated_parsed mutated_length mutated_byte_range
end HiaCoreSyntaxSlice.WrongCondition
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_bounds
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_byte_range
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd0_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd0_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd0_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd0_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd113_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd113_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd113_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd113_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd118_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd118_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd118_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd118_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd123_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd123_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd123_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd123_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd135_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd135_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd135_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd135_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd140_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd140_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd140_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd140_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd145_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd145_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd145_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd145_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd34_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd34_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd34_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd34_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd39_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd39_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd39_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd39_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd3_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd3_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd3_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd3_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd3_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd3_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd44_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd44_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd44_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd44_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd49_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd49_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd49_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd49_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd65_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd65_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd65_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd65_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd70_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd70_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd70_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd70_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd75_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd75_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd75_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd75_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd87_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd87_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd87_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd87_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd92_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd92_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd92_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd92_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd97_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd97_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd97_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd97_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp0_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp0_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp0_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp0_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp113_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp113_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp113_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp113_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp118_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp118_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp118_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp118_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp123_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp123_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp123_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp123_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp135_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp135_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp135_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp135_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp140_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp140_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp140_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp140_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp145_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp145_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp145_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp145_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp29_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp34_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp34_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp34_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp34_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp39_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp39_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp39_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp39_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp3_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp3_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp3_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp3_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp3_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp3_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp44_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp44_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp44_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp44_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp49_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp49_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp49_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp49_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp65_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp65_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp65_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp65_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp70_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp70_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp70_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp70_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp75_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp75_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp75_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp75_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp87_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp87_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp87_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp87_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp92_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp92_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp92_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp92_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp97_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp97_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp97_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp97_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_length
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o113
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o118
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o123
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o135
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o140
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o145
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o29
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o34
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o39
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o44
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o49
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o65
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o70
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o75
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o87
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o92
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o97
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p100
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p101
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p102
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p103
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p104
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p105
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p106
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p107
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p108
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p109
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p110
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p111
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p112
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p113
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p114
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p115
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p116
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p117
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p118
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p119
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p120
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p121
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p122
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p123
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p124
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p125
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p126
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p127
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p128
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p129
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p130
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p131
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p132
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p133
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p134
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p135
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p136
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p137
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p138
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p139
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p140
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p141
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p142
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p143
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p144
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p145
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p146
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p147
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p148
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p149
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p150
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p151
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p152
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p153
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p154
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p155
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p156
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p29
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p34
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p35
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p36
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p37
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p38
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p39
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p40
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p41
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p42
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p43
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p44
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p45
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p46
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p47
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p48
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p49
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p50
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p51
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p52
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p53
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p54
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p55
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p56
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p57
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p58
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p59
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p60
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p61
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p62
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p63
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p64
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p65
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p66
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p67
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p68
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p69
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p70
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p71
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p72
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p73
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p74
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p75
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p76
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p77
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p78
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p79
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p80
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p81
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p82
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p83
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p84
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p85
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p86
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p87
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p88
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p89
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p90
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p91
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p92
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p93
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p94
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p95
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p96
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p97
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p98
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p99
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_parsed
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl0_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl0_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl0_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl0_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl113_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl113_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl113_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl113_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl118_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl118_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl118_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl118_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl123_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl123_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl123_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl123_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl125_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl135_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl135_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl135_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl135_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl140_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl140_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl140_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl140_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl145_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl145_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl145_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl145_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl29_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl29_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl29_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl29_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl2_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl34_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl34_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl34_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl34_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl39_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl39_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl39_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl39_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl3_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl3_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl3_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl3_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl3_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl3_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl44_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl44_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl44_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl44_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl49_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl49_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl49_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl49_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_11
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_12
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_13
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_14
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_15
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_16
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_17
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_18
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_19
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_20
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl4_9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl51_9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl65_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl65_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl65_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl65_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl70_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl70_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl70_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl70_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl75_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl75_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl75_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl75_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl77_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl87_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl87_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl87_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl87_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl92_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl92_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl92_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl92_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl97_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl97_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl97_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl97_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl99_9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s100
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s101
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s102
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s103
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s104
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s105
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s106
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s107
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s108
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s109
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s110
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s111
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s112
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s113
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s114
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s115
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s116
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s117
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s118
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s119
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s120
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s121
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s122
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s123
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s124
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s125
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s126
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s127
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s128
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s129
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s130
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s131
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s132
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s133
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s134
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s135
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s136
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s137
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s138
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s139
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s140
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s141
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s142
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s143
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s144
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s145
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s146
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s147
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s148
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s149
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s150
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s151
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s152
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s153
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s154
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s155
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s156
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s29
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s34
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s35
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s36
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s37
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s38
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s39
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s40
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s41
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s42
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s43
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s44
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s45
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s46
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s47
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s48
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s49
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s50
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s51
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s52
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s53
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s54
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s55
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s56
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s57
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s58
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s59
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s60
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s61
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s62
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s63
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s64
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s65
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s66
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s67
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s68
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s69
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s70
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s71
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s72
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s73
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s74
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s75
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s76
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s77
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s78
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s79
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s80
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s81
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s82
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s83
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s84
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s85
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s86
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s87
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s88
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s89
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s90
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s91
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s92
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s93
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s94
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s95
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s96
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s97
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s98
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s99
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_serialized
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl0_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl0_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl0_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl0_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl113_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl113_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl113_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl113_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl118_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl118_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl118_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl118_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl123_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl123_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl123_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl123_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl125_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl135_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl135_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl135_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl135_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl140_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl140_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl140_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl140_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl145_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl145_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl145_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl145_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl29_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl29_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl29_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl29_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl2_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl34_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl34_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl34_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl34_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl39_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl39_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl39_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl39_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl3_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl3_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl3_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl3_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl3_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl3_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl44_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl44_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl44_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl44_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl49_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl49_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl49_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl49_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_11
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_12
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_13
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_14
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_15
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_16
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_17
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_18
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_19
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_20
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl4_9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl51_9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl65_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl65_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl65_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl65_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl70_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl70_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl70_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl70_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl75_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl75_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl75_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl75_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl77_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl87_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl87_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl87_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl87_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl92_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl92_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl92_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl92_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl97_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl97_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl97_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl97_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_4
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl99_9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_transport
