import HiaSyntaxResearch.CertPart03
namespace HiaCoreSyntaxSlice.WrongPhi
theorem mutated_kp87_0 (tail : List Nat) : parseStringTail (linear_k87_0 ++ (34 :: 58 :: tail)) [] = some (linear_k87_0, 58 :: tail) := by rfl
def linear_k87_1 : List Nat := [111,112,115]
theorem mutated_kd87_1 : stringBytes linear_k87_1 = true := by decide +kernel
theorem mutated_kp87_1 (tail : List Nat) : parseStringTail (linear_k87_1 ++ (34 :: 58 :: tail)) [] = some (linear_k87_1, 58 :: tail) := by rfl
def linear_k87_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd87_2 : stringBytes linear_k87_2 = true := by decide +kernel
theorem mutated_kp87_2 (tail : List Nat) : parseStringTail (linear_k87_2 ++ (34 :: 58 :: tail)) [] = some (linear_k87_2, 58 :: tail) := by rfl
def linear_k87_3 : List Nat := [116,101,114,109]
theorem mutated_kd87_3 : stringBytes linear_k87_3 = true := by decide +kernel
theorem mutated_kp87_3 (tail : List Nat) : parseStringTail (linear_k87_3 ++ (34 :: 58 :: tail)) [] = some (linear_k87_3, 58 :: tail) := by rfl
def linear_l87_3 : List (List Nat × Raw) := [(linear_k87_3, linear_r91)]
def linear_v87_3 : List Nat := linear_g231 ++ linear_b91
theorem mutated_sl87_3 : serializeFields 4071 27 linear_l87_3 = some linear_v87_3 := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4070 27 linear_k87_3 linear_r91 linear_b91 mutated_kd87_3 mutated_s91)
theorem mutated_pl87_3 (tail : List Nat) : parseFields 4071 27 (linear_v87_3 ++ (125 :: tail)) = some (linear_l87_3, tail) := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4070 27 (linear_k87_3 ++ (34 :: 58 :: (linear_b91 ++ (125 :: tail)))) linear_k87_3 (linear_b91 ++ (125 :: tail)) tail linear_r91 (mutated_kp87_3 (linear_b91 ++ (125 :: tail))) (mutated_p91 (125 :: tail)))
def linear_l87_2 : List (List Nat × Raw) := (linear_k87_2, linear_r90) :: linear_l87_3
def linear_v87_2 : List Nat := (linear_g228 ++ linear_b90) ++ (44 :: linear_v87_3)
theorem mutated_sl87_2 : serializeFields 4072 27 linear_l87_2 = some linear_v87_2 := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k87_2 linear_r90 (linear_k87_3, linear_r91) [] linear_b90 linear_v87_3 mutated_kd87_2 mutated_s90 mutated_sl87_3)
theorem mutated_pl87_2 (tail : List Nat) : parseFields 4072 27 (linear_v87_2 ++ (125 :: tail)) = some (linear_l87_2, tail) := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k87_2 ++ (34 :: 58 :: (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))))) linear_k87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))) (linear_v87_3 ++ (125 :: tail)) tail linear_r90 linear_l87_3 (mutated_kp87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail))))) (mutated_p90 (44 :: (linear_v87_3 ++ (125 :: tail)))) (mutated_pl87_3 tail))
def linear_l87_1 : List (List Nat × Raw) := (linear_k87_1, linear_r89) :: linear_l87_2
def linear_v87_1 : List Nat := (linear_g225 ++ linear_b89) ++ (44 :: linear_v87_2)
theorem mutated_sl87_1 : serializeFields 4073 27 linear_l87_1 = some linear_v87_1 := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k87_1 linear_r89 (linear_k87_2, linear_r90) linear_l87_3 linear_b89 linear_v87_2 mutated_kd87_1 mutated_s89 mutated_sl87_2)
theorem mutated_pl87_1 (tail : List Nat) : parseFields 4073 27 (linear_v87_1 ++ (125 :: tail)) = some (linear_l87_1, tail) := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k87_1 ++ (34 :: 58 :: (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))))) linear_k87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))) (linear_v87_2 ++ (125 :: tail)) tail linear_r89 linear_l87_2 (mutated_kp87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail))))) (mutated_p89 (44 :: (linear_v87_2 ++ (125 :: tail)))) (mutated_pl87_2 tail))
def linear_l87_0 : List (List Nat × Raw) := (linear_k87_0, linear_r88) :: linear_l87_1
def linear_v87_0 : List Nat := (linear_g222 ++ linear_b88) ++ (44 :: linear_v87_1)
theorem mutated_sl87_0 : serializeFields 4074 27 linear_l87_0 = some linear_v87_0 := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k87_0 linear_r88 (linear_k87_1, linear_r89) linear_l87_2 linear_b88 linear_v87_1 mutated_kd87_0 mutated_s88 mutated_sl87_1)
theorem mutated_pl87_0 (tail : List Nat) : parseFields 4074 27 (linear_v87_0 ++ (125 :: tail)) = some (linear_l87_0, tail) := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) linear_k87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))) (linear_v87_1 ++ (125 :: tail)) tail linear_r88 linear_l87_1 (mutated_kp87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail))))) (mutated_p88 (44 :: (linear_v87_1 ++ (125 :: tail)))) (mutated_pl87_1 tail))
def linear_r87 : Raw := (.obj linear_l87_0)
def linear_b87 : List Nat := linear_g221 ++ (linear_v87_0 ++ linear_g233)
theorem mutated_o87 : orderedFields linear_l87_0 = true := by decide +kernel
theorem mutated_s87 : serializeRaw 4075 28 linear_r87 = some linear_b87 := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4074 27 linear_l87_0 linear_v87_0 mutated_o87 mutated_sl87_0)
theorem mutated_p87 (tail : List Nat) : parseRaw 4075 28 (linear_b87 ++ tail) = some (linear_r87, tail) := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4074 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) tail linear_l87_0 mutated_o87 (by simpa only [linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl87_0 tail)))
def linear_r93 : Raw := (.str [100,103,95,115,108,111,119,95,48])
def linear_b93 : List Nat := linear_g237
theorem mutated_s93 : serializeRaw 4072 27 linear_r93 = some linear_b93 := by decide +kernel
theorem mutated_p93 (tail : List Nat) : parseRaw 4072 27 (linear_b93 ++ tail) = some (linear_r93, tail) := by rfl
def linear_r94 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,56]),(.str [100,103,95,118,95,49,48,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,57])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b94 : List Nat := linear_g240
theorem mutated_s94 : serializeRaw 4071 27 linear_r94 = some linear_b94 := by decide +kernel
theorem mutated_p94 (tail : List Nat) : parseRaw 4071 27 (linear_b94 ++ tail) = some (linear_r94, tail) := by rfl
def linear_r95 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b95 : List Nat := linear_g243
theorem mutated_s95 : serializeRaw 4070 27 linear_r95 = some linear_b95 := by decide +kernel
theorem mutated_p95 (tail : List Nat) : parseRaw 4070 27 (linear_b95 ++ tail) = some (linear_r95, tail) := by rfl
def linear_r96 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,48,57])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))]))])
def linear_b96 : List Nat := linear_g246
theorem mutated_s96 : serializeRaw 4069 27 linear_r96 = some linear_b96 := by decide +kernel
theorem mutated_p96 (tail : List Nat) : parseRaw 4069 27 (linear_b96 ++ tail) = some (linear_r96, tail) := by rfl
def linear_k92_0 : List Nat := [105,100]
theorem mutated_kd92_0 : stringBytes linear_k92_0 = true := by decide +kernel
theorem mutated_kp92_0 (tail : List Nat) : parseStringTail (linear_k92_0 ++ (34 :: 58 :: tail)) [] = some (linear_k92_0, 58 :: tail) := by rfl
def linear_k92_1 : List Nat := [111,112,115]
theorem mutated_kd92_1 : stringBytes linear_k92_1 = true := by decide +kernel
theorem mutated_kp92_1 (tail : List Nat) : parseStringTail (linear_k92_1 ++ (34 :: 58 :: tail)) [] = some (linear_k92_1, 58 :: tail) := by rfl
def linear_k92_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd92_2 : stringBytes linear_k92_2 = true := by decide +kernel
theorem mutated_kp92_2 (tail : List Nat) : parseStringTail (linear_k92_2 ++ (34 :: 58 :: tail)) [] = some (linear_k92_2, 58 :: tail) := by rfl
def linear_k92_3 : List Nat := [116,101,114,109]
theorem mutated_kd92_3 : stringBytes linear_k92_3 = true := by decide +kernel
theorem mutated_kp92_3 (tail : List Nat) : parseStringTail (linear_k92_3 ++ (34 :: 58 :: tail)) [] = some (linear_k92_3, 58 :: tail) := by rfl
def linear_l92_3 : List (List Nat × Raw) := [(linear_k92_3, linear_r96)]
def linear_v92_3 : List Nat := linear_g245 ++ linear_b96
theorem mutated_sl92_3 : serializeFields 4070 27 linear_l92_3 = some linear_v92_3 := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4069 27 linear_k92_3 linear_r96 linear_b96 mutated_kd92_3 mutated_s96)
theorem mutated_pl92_3 (tail : List Nat) : parseFields 4070 27 (linear_v92_3 ++ (125 :: tail)) = some (linear_l92_3, tail) := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4069 27 (linear_k92_3 ++ (34 :: 58 :: (linear_b96 ++ (125 :: tail)))) linear_k92_3 (linear_b96 ++ (125 :: tail)) tail linear_r96 (mutated_kp92_3 (linear_b96 ++ (125 :: tail))) (mutated_p96 (125 :: tail)))
def linear_l92_2 : List (List Nat × Raw) := (linear_k92_2, linear_r95) :: linear_l92_3
def linear_v92_2 : List Nat := (linear_g242 ++ linear_b95) ++ (44 :: linear_v92_3)
theorem mutated_sl92_2 : serializeFields 4071 27 linear_l92_2 = some linear_v92_2 := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k92_2 linear_r95 (linear_k92_3, linear_r96) [] linear_b95 linear_v92_3 mutated_kd92_2 mutated_s95 mutated_sl92_3)
theorem mutated_pl92_2 (tail : List Nat) : parseFields 4071 27 (linear_v92_2 ++ (125 :: tail)) = some (linear_l92_2, tail) := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k92_2 ++ (34 :: 58 :: (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))))) linear_k92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))) (linear_v92_3 ++ (125 :: tail)) tail linear_r95 linear_l92_3 (mutated_kp92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail))))) (mutated_p95 (44 :: (linear_v92_3 ++ (125 :: tail)))) (mutated_pl92_3 tail))
def linear_l92_1 : List (List Nat × Raw) := (linear_k92_1, linear_r94) :: linear_l92_2
def linear_v92_1 : List Nat := (linear_g239 ++ linear_b94) ++ (44 :: linear_v92_2)
theorem mutated_sl92_1 : serializeFields 4072 27 linear_l92_1 = some linear_v92_1 := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k92_1 linear_r94 (linear_k92_2, linear_r95) linear_l92_3 linear_b94 linear_v92_2 mutated_kd92_1 mutated_s94 mutated_sl92_2)
theorem mutated_pl92_1 (tail : List Nat) : parseFields 4072 27 (linear_v92_1 ++ (125 :: tail)) = some (linear_l92_1, tail) := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k92_1 ++ (34 :: 58 :: (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))))) linear_k92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))) (linear_v92_2 ++ (125 :: tail)) tail linear_r94 linear_l92_2 (mutated_kp92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail))))) (mutated_p94 (44 :: (linear_v92_2 ++ (125 :: tail)))) (mutated_pl92_2 tail))
def linear_l92_0 : List (List Nat × Raw) := (linear_k92_0, linear_r93) :: linear_l92_1
def linear_v92_0 : List Nat := (linear_g236 ++ linear_b93) ++ (44 :: linear_v92_1)
theorem mutated_sl92_0 : serializeFields 4073 27 linear_l92_0 = some linear_v92_0 := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k92_0 linear_r93 (linear_k92_1, linear_r94) linear_l92_2 linear_b93 linear_v92_1 mutated_kd92_0 mutated_s93 mutated_sl92_1)
theorem mutated_pl92_0 (tail : List Nat) : parseFields 4073 27 (linear_v92_0 ++ (125 :: tail)) = some (linear_l92_0, tail) := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) linear_k92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))) (linear_v92_1 ++ (125 :: tail)) tail linear_r93 linear_l92_1 (mutated_kp92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail))))) (mutated_p93 (44 :: (linear_v92_1 ++ (125 :: tail)))) (mutated_pl92_1 tail))
def linear_r92 : Raw := (.obj linear_l92_0)
def linear_b92 : List Nat := linear_g235 ++ (linear_v92_0 ++ linear_g247)
theorem mutated_o92 : orderedFields linear_l92_0 = true := by decide +kernel
theorem mutated_s92 : serializeRaw 4074 28 linear_r92 = some linear_b92 := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4073 27 linear_l92_0 linear_v92_0 mutated_o92 mutated_sl92_0)
theorem mutated_p92 (tail : List Nat) : parseRaw 4074 28 (linear_b92 ++ tail) = some (linear_r92, tail) := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4073 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) tail linear_l92_0 mutated_o92 (by simpa only [linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl92_0 tail)))
def linear_r98 : Raw := (.str [100,103,95,115,108,111,119,95,49])
def linear_b98 : List Nat := linear_g251
theorem mutated_s98 : serializeRaw 4071 27 linear_r98 = some linear_b98 := by decide +kernel
theorem mutated_p98 (tail : List Nat) : parseRaw 4071 27 (linear_b98 ++ tail) = some (linear_r98, tail) := by rfl
def linear_r100 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,53])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b100 : List Nat := linear_g255
theorem mutated_s100 : serializeRaw 4068 26 linear_r100 = some linear_b100 := by decide +kernel
theorem mutated_p100 (tail : List Nat) : parseRaw 4068 26 (linear_b100 ++ tail) = some (linear_r100, tail) := by rfl
def linear_r101 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,53]),(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,54])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b101 : List Nat := linear_g257
theorem mutated_s101 : serializeRaw 4067 26 linear_r101 = some linear_b101 := by decide +kernel
theorem mutated_p101 (tail : List Nat) : parseRaw 4067 26 (linear_b101 ++ tail) = some (linear_r101, tail) := by rfl
def linear_r102 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b102 : List Nat := linear_g259
theorem mutated_s102 : serializeRaw 4066 26 linear_r102 = some linear_b102 := by decide +kernel
theorem mutated_p102 (tail : List Nat) : parseRaw 4066 26 (linear_b102 ++ tail) = some (linear_r102, tail) := by rfl
def linear_r103 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,56])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b103 : List Nat := linear_g261
theorem mutated_s103 : serializeRaw 4065 26 linear_r103 = some linear_b103 := by decide +kernel
theorem mutated_p103 (tail : List Nat) : parseRaw 4065 26 (linear_b103 ++ tail) = some (linear_r103, tail) := by rfl
def linear_r104 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,55]),(.str [100,103,95,118,95,49,49,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,57])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b104 : List Nat := linear_g263
theorem mutated_s104 : serializeRaw 4064 26 linear_r104 = some linear_b104 := by decide +kernel
theorem mutated_p104 (tail : List Nat) : parseRaw 4064 26 (linear_b104 ++ tail) = some (linear_r104, tail) := by rfl
def linear_r105 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,57])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,48])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b105 : List Nat := linear_g265
theorem mutated_s105 : serializeRaw 4063 26 linear_r105 = some linear_b105 := by decide +kernel
theorem mutated_p105 (tail : List Nat) : parseRaw 4063 26 (linear_b105 ++ tail) = some (linear_r105, tail) := by rfl
def linear_r106 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,49])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b106 : List Nat := linear_g267
theorem mutated_s106 : serializeRaw 4062 26 linear_r106 = some linear_b106 := by decide +kernel
theorem mutated_p106 (tail : List Nat) : parseRaw 4062 26 (linear_b106 ++ tail) = some (linear_r106, tail) := by rfl
def linear_r107 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49]),(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b107 : List Nat := linear_g269
theorem mutated_s107 : serializeRaw 4061 26 linear_r107 = some linear_b107 := by decide +kernel
theorem mutated_p107 (tail : List Nat) : parseRaw 4061 26 (linear_b107 ++ tail) = some (linear_r107, tail) := by rfl
def linear_r108 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b108 : List Nat := linear_g271
theorem mutated_s108 : serializeRaw 4060 26 linear_r108 = some linear_b108 := by decide +kernel
theorem mutated_p108 (tail : List Nat) : parseRaw 4060 26 (linear_b108 ++ tail) = some (linear_r108, tail) := by rfl
def linear_r109 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b109 : List Nat := linear_g273
theorem mutated_s109 : serializeRaw 4059 26 linear_r109 = some linear_b109 := by decide +kernel
theorem mutated_p109 (tail : List Nat) : parseRaw 4059 26 (linear_b109 ++ tail) = some (linear_r109, tail) := by rfl
def linear_r110 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b110 : List Nat := linear_g275
theorem mutated_s110 : serializeRaw 4058 26 linear_r110 = some linear_b110 := by decide +kernel
theorem mutated_p110 (tail : List Nat) : parseRaw 4058 26 (linear_b110 ++ tail) = some (linear_r110, tail) := by rfl
def linear_l99_10 : List Raw := [linear_r110]
def linear_v99_10 : List Nat := linear_b110
theorem mutated_sl99_10 : serializeItems 4059 26 linear_l99_10 = some linear_v99_10 := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4058 26 linear_r110 linear_b110 mutated_s110)
theorem mutated_pl99_10 (tail : List Nat) : parseItems 4059 26 (linear_v99_10 ++ (93 :: tail)) = some (linear_l99_10, tail) := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4058 26 (linear_b110 ++ (93 :: tail)) tail linear_r110 (mutated_p110 (93 :: tail)))
def linear_l99_9 : List Raw := linear_r109 :: linear_l99_10
def linear_v99_9 : List Nat := (linear_b109) ++ (44 :: linear_v99_10)
theorem mutated_sl99_9 : serializeItems 4060 26 linear_l99_9 = some linear_v99_9 := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4059 26 linear_r109 linear_r110 [] linear_b109 linear_v99_10 mutated_s109 mutated_sl99_10)
theorem mutated_pl99_9 (tail : List Nat) : parseItems 4060 26 (linear_v99_9 ++ (93 :: tail)) = some (linear_l99_9, tail) := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4059 26 (linear_b109 ++ (44 :: (linear_v99_10 ++ (93 :: tail)))) (linear_v99_10 ++ (93 :: tail)) tail linear_r109 linear_l99_10 (mutated_p109 (44 :: (linear_v99_10 ++ (93 :: tail)))) (mutated_pl99_10 tail))
def linear_l99_8 : List Raw := linear_r108 :: linear_l99_9
def linear_v99_8 : List Nat := (linear_b108) ++ (44 :: linear_v99_9)
theorem mutated_sl99_8 : serializeItems 4061 26 linear_l99_8 = some linear_v99_8 := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r108 linear_r109 linear_l99_10 linear_b108 linear_v99_9 mutated_s108 mutated_sl99_9)
theorem mutated_pl99_8 (tail : List Nat) : parseItems 4061 26 (linear_v99_8 ++ (93 :: tail)) = some (linear_l99_8, tail) := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b108 ++ (44 :: (linear_v99_9 ++ (93 :: tail)))) (linear_v99_9 ++ (93 :: tail)) tail linear_r108 linear_l99_9 (mutated_p108 (44 :: (linear_v99_9 ++ (93 :: tail)))) (mutated_pl99_9 tail))
def linear_l99_7 : List Raw := linear_r107 :: linear_l99_8
def linear_v99_7 : List Nat := (linear_b107) ++ (44 :: linear_v99_8)
theorem mutated_sl99_7 : serializeItems 4062 26 linear_l99_7 = some linear_v99_7 := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r107 linear_r108 linear_l99_9 linear_b107 linear_v99_8 mutated_s107 mutated_sl99_8)
theorem mutated_pl99_7 (tail : List Nat) : parseItems 4062 26 (linear_v99_7 ++ (93 :: tail)) = some (linear_l99_7, tail) := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b107 ++ (44 :: (linear_v99_8 ++ (93 :: tail)))) (linear_v99_8 ++ (93 :: tail)) tail linear_r107 linear_l99_8 (mutated_p107 (44 :: (linear_v99_8 ++ (93 :: tail)))) (mutated_pl99_8 tail))
def linear_l99_6 : List Raw := linear_r106 :: linear_l99_7
def linear_v99_6 : List Nat := (linear_b106) ++ (44 :: linear_v99_7)
theorem mutated_sl99_6 : serializeItems 4063 26 linear_l99_6 = some linear_v99_6 := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r106 linear_r107 linear_l99_8 linear_b106 linear_v99_7 mutated_s106 mutated_sl99_7)
theorem mutated_pl99_6 (tail : List Nat) : parseItems 4063 26 (linear_v99_6 ++ (93 :: tail)) = some (linear_l99_6, tail) := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b106 ++ (44 :: (linear_v99_7 ++ (93 :: tail)))) (linear_v99_7 ++ (93 :: tail)) tail linear_r106 linear_l99_7 (mutated_p106 (44 :: (linear_v99_7 ++ (93 :: tail)))) (mutated_pl99_7 tail))
def linear_l99_5 : List Raw := linear_r105 :: linear_l99_6
def linear_v99_5 : List Nat := (linear_b105) ++ (44 :: linear_v99_6)
theorem mutated_sl99_5 : serializeItems 4064 26 linear_l99_5 = some linear_v99_5 := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r105 linear_r106 linear_l99_7 linear_b105 linear_v99_6 mutated_s105 mutated_sl99_6)
theorem mutated_pl99_5 (tail : List Nat) : parseItems 4064 26 (linear_v99_5 ++ (93 :: tail)) = some (linear_l99_5, tail) := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b105 ++ (44 :: (linear_v99_6 ++ (93 :: tail)))) (linear_v99_6 ++ (93 :: tail)) tail linear_r105 linear_l99_6 (mutated_p105 (44 :: (linear_v99_6 ++ (93 :: tail)))) (mutated_pl99_6 tail))
def linear_l99_4 : List Raw := linear_r104 :: linear_l99_5
def linear_v99_4 : List Nat := (linear_b104) ++ (44 :: linear_v99_5)
theorem mutated_sl99_4 : serializeItems 4065 26 linear_l99_4 = some linear_v99_4 := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r104 linear_r105 linear_l99_6 linear_b104 linear_v99_5 mutated_s104 mutated_sl99_5)
theorem mutated_pl99_4 (tail : List Nat) : parseItems 4065 26 (linear_v99_4 ++ (93 :: tail)) = some (linear_l99_4, tail) := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b104 ++ (44 :: (linear_v99_5 ++ (93 :: tail)))) (linear_v99_5 ++ (93 :: tail)) tail linear_r104 linear_l99_5 (mutated_p104 (44 :: (linear_v99_5 ++ (93 :: tail)))) (mutated_pl99_5 tail))
def linear_l99_3 : List Raw := linear_r103 :: linear_l99_4
def linear_v99_3 : List Nat := (linear_b103) ++ (44 :: linear_v99_4)
theorem mutated_sl99_3 : serializeItems 4066 26 linear_l99_3 = some linear_v99_3 := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r103 linear_r104 linear_l99_5 linear_b103 linear_v99_4 mutated_s103 mutated_sl99_4)
theorem mutated_pl99_3 (tail : List Nat) : parseItems 4066 26 (linear_v99_3 ++ (93 :: tail)) = some (linear_l99_3, tail) := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b103 ++ (44 :: (linear_v99_4 ++ (93 :: tail)))) (linear_v99_4 ++ (93 :: tail)) tail linear_r103 linear_l99_4 (mutated_p103 (44 :: (linear_v99_4 ++ (93 :: tail)))) (mutated_pl99_4 tail))
def linear_l99_2 : List Raw := linear_r102 :: linear_l99_3
def linear_v99_2 : List Nat := (linear_b102) ++ (44 :: linear_v99_3)
theorem mutated_sl99_2 : serializeItems 4067 26 linear_l99_2 = some linear_v99_2 := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r102 linear_r103 linear_l99_4 linear_b102 linear_v99_3 mutated_s102 mutated_sl99_3)
theorem mutated_pl99_2 (tail : List Nat) : parseItems 4067 26 (linear_v99_2 ++ (93 :: tail)) = some (linear_l99_2, tail) := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b102 ++ (44 :: (linear_v99_3 ++ (93 :: tail)))) (linear_v99_3 ++ (93 :: tail)) tail linear_r102 linear_l99_3 (mutated_p102 (44 :: (linear_v99_3 ++ (93 :: tail)))) (mutated_pl99_3 tail))
def linear_l99_1 : List Raw := linear_r101 :: linear_l99_2
def linear_v99_1 : List Nat := (linear_b101) ++ (44 :: linear_v99_2)
theorem mutated_sl99_1 : serializeItems 4068 26 linear_l99_1 = some linear_v99_1 := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r101 linear_r102 linear_l99_3 linear_b101 linear_v99_2 mutated_s101 mutated_sl99_2)
theorem mutated_pl99_1 (tail : List Nat) : parseItems 4068 26 (linear_v99_1 ++ (93 :: tail)) = some (linear_l99_1, tail) := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b101 ++ (44 :: (linear_v99_2 ++ (93 :: tail)))) (linear_v99_2 ++ (93 :: tail)) tail linear_r101 linear_l99_2 (mutated_p101 (44 :: (linear_v99_2 ++ (93 :: tail)))) (mutated_pl99_2 tail))
def linear_l99_0 : List Raw := linear_r100 :: linear_l99_1
def linear_v99_0 : List Nat := (linear_b100) ++ (44 :: linear_v99_1)
theorem mutated_sl99_0 : serializeItems 4069 26 linear_l99_0 = some linear_v99_0 := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r100 linear_r101 linear_l99_2 linear_b100 linear_v99_1 mutated_s100 mutated_sl99_1)
theorem mutated_pl99_0 (tail : List Nat) : parseItems 4069 26 (linear_v99_0 ++ (93 :: tail)) = some (linear_l99_0, tail) := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b100 ++ (44 :: (linear_v99_1 ++ (93 :: tail)))) (linear_v99_1 ++ (93 :: tail)) tail linear_r100 linear_l99_1 (mutated_p100 (44 :: (linear_v99_1 ++ (93 :: tail)))) (mutated_pl99_1 tail))
def linear_r99 : Raw := (.arr linear_l99_0)
def linear_b99 : List Nat := linear_g254 ++ (linear_v99_0 ++ linear_g276)
theorem mutated_s99 : serializeRaw 4070 27 linear_r99 = some linear_b99 := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4069 26 linear_l99_0 linear_v99_0 mutated_sl99_0)
theorem mutated_p99 (tail : List Nat) : parseRaw 4070 27 (linear_b99 ++ tail) = some (linear_r99, tail) := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4069 26 (linear_v99_0 ++ (93 :: tail)) tail linear_l99_0 (by intro h; cases h) (mutated_pl99_0 tail))
def linear_r111 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b111 : List Nat := linear_g279
theorem mutated_s111 : serializeRaw 4069 27 linear_r111 = some linear_b111 := by decide +kernel
theorem mutated_p111 (tail : List Nat) : parseRaw 4069 27 (linear_b111 ++ tail) = some (linear_r111, tail) := by rfl
def linear_r112 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,48]),(.str [100,103,95,118,95,49,49,49]),(.str [100,103,95,118,95,49,49,50]),(.str [100,103,95,118,95,49,49,51]),(.str [100,103,95,118,95,49,50,51])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,48]))])
def linear_b112 : List Nat := linear_g282
theorem mutated_s112 : serializeRaw 4068 27 linear_r112 = some linear_b112 := by decide +kernel
theorem mutated_p112 (tail : List Nat) : parseRaw 4068 27 (linear_b112 ++ tail) = some (linear_r112, tail) := by rfl
def linear_k97_0 : List Nat := [105,100]
theorem mutated_kd97_0 : stringBytes linear_k97_0 = true := by decide +kernel
theorem mutated_kp97_0 (tail : List Nat) : parseStringTail (linear_k97_0 ++ (34 :: 58 :: tail)) [] = some (linear_k97_0, 58 :: tail) := by rfl
def linear_k97_1 : List Nat := [111,112,115]
theorem mutated_kd97_1 : stringBytes linear_k97_1 = true := by decide +kernel
theorem mutated_kp97_1 (tail : List Nat) : parseStringTail (linear_k97_1 ++ (34 :: 58 :: tail)) [] = some (linear_k97_1, 58 :: tail) := by rfl
def linear_k97_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd97_2 : stringBytes linear_k97_2 = true := by decide +kernel
theorem mutated_kp97_2 (tail : List Nat) : parseStringTail (linear_k97_2 ++ (34 :: 58 :: tail)) [] = some (linear_k97_2, 58 :: tail) := by rfl
def linear_k97_3 : List Nat := [116,101,114,109]
theorem mutated_kd97_3 : stringBytes linear_k97_3 = true := by decide +kernel
theorem mutated_kp97_3 (tail : List Nat) : parseStringTail (linear_k97_3 ++ (34 :: 58 :: tail)) [] = some (linear_k97_3, 58 :: tail) := by rfl
def linear_l97_3 : List (List Nat × Raw) := [(linear_k97_3, linear_r112)]
def linear_v97_3 : List Nat := linear_g281 ++ linear_b112
theorem mutated_sl97_3 : serializeFields 4069 27 linear_l97_3 = some linear_v97_3 := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4068 27 linear_k97_3 linear_r112 linear_b112 mutated_kd97_3 mutated_s112)
theorem mutated_pl97_3 (tail : List Nat) : parseFields 4069 27 (linear_v97_3 ++ (125 :: tail)) = some (linear_l97_3, tail) := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4068 27 (linear_k97_3 ++ (34 :: 58 :: (linear_b112 ++ (125 :: tail)))) linear_k97_3 (linear_b112 ++ (125 :: tail)) tail linear_r112 (mutated_kp97_3 (linear_b112 ++ (125 :: tail))) (mutated_p112 (125 :: tail)))
def linear_l97_2 : List (List Nat × Raw) := (linear_k97_2, linear_r111) :: linear_l97_3
def linear_v97_2 : List Nat := (linear_g278 ++ linear_b111) ++ (44 :: linear_v97_3)
theorem mutated_sl97_2 : serializeFields 4070 27 linear_l97_2 = some linear_v97_2 := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k97_2 linear_r111 (linear_k97_3, linear_r112) [] linear_b111 linear_v97_3 mutated_kd97_2 mutated_s111 mutated_sl97_3)
theorem mutated_pl97_2 (tail : List Nat) : parseFields 4070 27 (linear_v97_2 ++ (125 :: tail)) = some (linear_l97_2, tail) := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k97_2 ++ (34 :: 58 :: (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))))) linear_k97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))) (linear_v97_3 ++ (125 :: tail)) tail linear_r111 linear_l97_3 (mutated_kp97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail))))) (mutated_p111 (44 :: (linear_v97_3 ++ (125 :: tail)))) (mutated_pl97_3 tail))
def linear_l97_1 : List (List Nat × Raw) := (linear_k97_1, linear_r99) :: linear_l97_2
def linear_v97_1 : List Nat := (linear_g253 ++ linear_b99) ++ (44 :: linear_v97_2)
theorem mutated_sl97_1 : serializeFields 4071 27 linear_l97_1 = some linear_v97_1 := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k97_1 linear_r99 (linear_k97_2, linear_r111) linear_l97_3 linear_b99 linear_v97_2 mutated_kd97_1 mutated_s99 mutated_sl97_2)
theorem mutated_pl97_1 (tail : List Nat) : parseFields 4071 27 (linear_v97_1 ++ (125 :: tail)) = some (linear_l97_1, tail) := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k97_1 ++ (34 :: 58 :: (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))))) linear_k97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))) (linear_v97_2 ++ (125 :: tail)) tail linear_r99 linear_l97_2 (mutated_kp97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail))))) (mutated_p99 (44 :: (linear_v97_2 ++ (125 :: tail)))) (mutated_pl97_2 tail))
def linear_l97_0 : List (List Nat × Raw) := (linear_k97_0, linear_r98) :: linear_l97_1
def linear_v97_0 : List Nat := (linear_g250 ++ linear_b98) ++ (44 :: linear_v97_1)
theorem mutated_sl97_0 : serializeFields 4072 27 linear_l97_0 = some linear_v97_0 := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k97_0 linear_r98 (linear_k97_1, linear_r99) linear_l97_2 linear_b98 linear_v97_1 mutated_kd97_0 mutated_s98 mutated_sl97_1)
theorem mutated_pl97_0 (tail : List Nat) : parseFields 4072 27 (linear_v97_0 ++ (125 :: tail)) = some (linear_l97_0, tail) := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) linear_k97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))) (linear_v97_1 ++ (125 :: tail)) tail linear_r98 linear_l97_1 (mutated_kp97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail))))) (mutated_p98 (44 :: (linear_v97_1 ++ (125 :: tail)))) (mutated_pl97_1 tail))
def linear_r97 : Raw := (.obj linear_l97_0)
def linear_b97 : List Nat := linear_g249 ++ (linear_v97_0 ++ linear_g283)
theorem mutated_o97 : orderedFields linear_l97_0 = true := by decide +kernel
theorem mutated_s97 : serializeRaw 4073 28 linear_r97 = some linear_b97 := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4072 27 linear_l97_0 linear_v97_0 mutated_o97 mutated_sl97_0)
theorem mutated_p97 (tail : List Nat) : parseRaw 4073 28 (linear_b97 ++ tail) = some (linear_r97, tail) := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4072 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) tail linear_l97_0 mutated_o97 (by simpa only [linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl97_0 tail)))
def linear_r114 : Raw := (.str [100,103,95,115,108,111,119,95,50])
def linear_b114 : List Nat := linear_g287
theorem mutated_s114 : serializeRaw 4070 27 linear_r114 = some linear_b114 := by decide +kernel
theorem mutated_p114 (tail : List Nat) : parseRaw 4070 27 (linear_b114 ++ tail) = some (linear_r114, tail) := by rfl
def linear_r115 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,57])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b115 : List Nat := linear_g290
theorem mutated_s115 : serializeRaw 4069 27 linear_r115 = some linear_b115 := by decide +kernel
theorem mutated_p115 (tail : List Nat) : parseRaw 4069 27 (linear_b115 ++ tail) = some (linear_r115, tail) := by rfl
def linear_r116 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b116 : List Nat := linear_g293
theorem mutated_s116 : serializeRaw 4068 27 linear_r116 = some linear_b116 := by decide +kernel
theorem mutated_p116 (tail : List Nat) : parseRaw 4068 27 (linear_b116 ++ tail) = some (linear_r116, tail) := by rfl
def linear_r117 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,50,53]),(.str [100,103,95,118,95,49,50,54]),(.str [100,103,95,118,95,49,50,57]),(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,51,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b117 : List Nat := linear_g296
theorem mutated_s117 : serializeRaw 4067 27 linear_r117 = some linear_b117 := by decide +kernel
theorem mutated_p117 (tail : List Nat) : parseRaw 4067 27 (linear_b117 ++ tail) = some (linear_r117, tail) := by rfl
def linear_k113_0 : List Nat := [105,100]
theorem mutated_kd113_0 : stringBytes linear_k113_0 = true := by decide +kernel
theorem mutated_kp113_0 (tail : List Nat) : parseStringTail (linear_k113_0 ++ (34 :: 58 :: tail)) [] = some (linear_k113_0, 58 :: tail) := by rfl
def linear_k113_1 : List Nat := [111,112,115]
theorem mutated_kd113_1 : stringBytes linear_k113_1 = true := by decide +kernel
theorem mutated_kp113_1 (tail : List Nat) : parseStringTail (linear_k113_1 ++ (34 :: 58 :: tail)) [] = some (linear_k113_1, 58 :: tail) := by rfl
def linear_k113_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd113_2 : stringBytes linear_k113_2 = true := by decide +kernel
theorem mutated_kp113_2 (tail : List Nat) : parseStringTail (linear_k113_2 ++ (34 :: 58 :: tail)) [] = some (linear_k113_2, 58 :: tail) := by rfl
def linear_k113_3 : List Nat := [116,101,114,109]
theorem mutated_kd113_3 : stringBytes linear_k113_3 = true := by decide +kernel
theorem mutated_kp113_3 (tail : List Nat) : parseStringTail (linear_k113_3 ++ (34 :: 58 :: tail)) [] = some (linear_k113_3, 58 :: tail) := by rfl
def linear_l113_3 : List (List Nat × Raw) := [(linear_k113_3, linear_r117)]
def linear_v113_3 : List Nat := linear_g295 ++ linear_b117
theorem mutated_sl113_3 : serializeFields 4068 27 linear_l113_3 = some linear_v113_3 := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4067 27 linear_k113_3 linear_r117 linear_b117 mutated_kd113_3 mutated_s117)
theorem mutated_pl113_3 (tail : List Nat) : parseFields 4068 27 (linear_v113_3 ++ (125 :: tail)) = some (linear_l113_3, tail) := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4067 27 (linear_k113_3 ++ (34 :: 58 :: (linear_b117 ++ (125 :: tail)))) linear_k113_3 (linear_b117 ++ (125 :: tail)) tail linear_r117 (mutated_kp113_3 (linear_b117 ++ (125 :: tail))) (mutated_p117 (125 :: tail)))
def linear_l113_2 : List (List Nat × Raw) := (linear_k113_2, linear_r116) :: linear_l113_3
def linear_v113_2 : List Nat := (linear_g292 ++ linear_b116) ++ (44 :: linear_v113_3)
theorem mutated_sl113_2 : serializeFields 4069 27 linear_l113_2 = some linear_v113_2 := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k113_2 linear_r116 (linear_k113_3, linear_r117) [] linear_b116 linear_v113_3 mutated_kd113_2 mutated_s116 mutated_sl113_3)
theorem mutated_pl113_2 (tail : List Nat) : parseFields 4069 27 (linear_v113_2 ++ (125 :: tail)) = some (linear_l113_2, tail) := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k113_2 ++ (34 :: 58 :: (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))))) linear_k113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))) (linear_v113_3 ++ (125 :: tail)) tail linear_r116 linear_l113_3 (mutated_kp113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail))))) (mutated_p116 (44 :: (linear_v113_3 ++ (125 :: tail)))) (mutated_pl113_3 tail))
def linear_l113_1 : List (List Nat × Raw) := (linear_k113_1, linear_r115) :: linear_l113_2
def linear_v113_1 : List Nat := (linear_g289 ++ linear_b115) ++ (44 :: linear_v113_2)
theorem mutated_sl113_1 : serializeFields 4070 27 linear_l113_1 = some linear_v113_1 := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k113_1 linear_r115 (linear_k113_2, linear_r116) linear_l113_3 linear_b115 linear_v113_2 mutated_kd113_1 mutated_s115 mutated_sl113_2)
theorem mutated_pl113_1 (tail : List Nat) : parseFields 4070 27 (linear_v113_1 ++ (125 :: tail)) = some (linear_l113_1, tail) := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k113_1 ++ (34 :: 58 :: (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))))) linear_k113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))) (linear_v113_2 ++ (125 :: tail)) tail linear_r115 linear_l113_2 (mutated_kp113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail))))) (mutated_p115 (44 :: (linear_v113_2 ++ (125 :: tail)))) (mutated_pl113_2 tail))
def linear_l113_0 : List (List Nat × Raw) := (linear_k113_0, linear_r114) :: linear_l113_1
def linear_v113_0 : List Nat := (linear_g286 ++ linear_b114) ++ (44 :: linear_v113_1)
theorem mutated_sl113_0 : serializeFields 4071 27 linear_l113_0 = some linear_v113_0 := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k113_0 linear_r114 (linear_k113_1, linear_r115) linear_l113_2 linear_b114 linear_v113_1 mutated_kd113_0 mutated_s114 mutated_sl113_1)
theorem mutated_pl113_0 (tail : List Nat) : parseFields 4071 27 (linear_v113_0 ++ (125 :: tail)) = some (linear_l113_0, tail) := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) linear_k113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))) (linear_v113_1 ++ (125 :: tail)) tail linear_r114 linear_l113_1 (mutated_kp113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail))))) (mutated_p114 (44 :: (linear_v113_1 ++ (125 :: tail)))) (mutated_pl113_1 tail))
def linear_r113 : Raw := (.obj linear_l113_0)
def linear_b113 : List Nat := linear_g285 ++ (linear_v113_0 ++ linear_g297)
theorem mutated_o113 : orderedFields linear_l113_0 = true := by decide +kernel
theorem mutated_s113 : serializeRaw 4072 28 linear_r113 = some linear_b113 := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4071 27 linear_l113_0 linear_v113_0 mutated_o113 mutated_sl113_0)
theorem mutated_p113 (tail : List Nat) : parseRaw 4072 28 (linear_b113 ++ tail) = some (linear_r113, tail) := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4071 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) tail linear_l113_0 mutated_o113 (by simpa only [linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl113_0 tail)))
def linear_r119 : Raw := (.str [100,103,95,115,108,111,119,95,51])
def linear_b119 : List Nat := linear_g301
theorem mutated_s119 : serializeRaw 4069 27 linear_r119 = some linear_b119 := by decide +kernel
theorem mutated_p119 (tail : List Nat) : parseRaw 4069 27 (linear_b119 ++ tail) = some (linear_r119, tail) := by rfl
def linear_r120 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,54]),(.str [100,103,95,118,95,49,51,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,55])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b120 : List Nat := linear_g304
theorem mutated_s120 : serializeRaw 4068 27 linear_r120 = some linear_b120 := by decide +kernel
theorem mutated_p120 (tail : List Nat) : parseRaw 4068 27 (linear_b120 ++ tail) = some (linear_r120, tail) := by rfl
def linear_r121 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,52])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b121 : List Nat := linear_g307
theorem mutated_s121 : serializeRaw 4067 27 linear_r121 = some linear_b121 := by decide +kernel
theorem mutated_p121 (tail : List Nat) : parseRaw 4067 27 (linear_b121 ++ tail) = some (linear_r121, tail) := by rfl
def linear_r122 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,51,55])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))]))])
def linear_b122 : List Nat := linear_g310
theorem mutated_s122 : serializeRaw 4066 27 linear_r122 = some linear_b122 := by decide +kernel
theorem mutated_p122 (tail : List Nat) : parseRaw 4066 27 (linear_b122 ++ tail) = some (linear_r122, tail) := by rfl
def linear_k118_0 : List Nat := [105,100]
theorem mutated_kd118_0 : stringBytes linear_k118_0 = true := by decide +kernel
theorem mutated_kp118_0 (tail : List Nat) : parseStringTail (linear_k118_0 ++ (34 :: 58 :: tail)) [] = some (linear_k118_0, 58 :: tail) := by rfl
def linear_k118_1 : List Nat := [111,112,115]
theorem mutated_kd118_1 : stringBytes linear_k118_1 = true := by decide +kernel
theorem mutated_kp118_1 (tail : List Nat) : parseStringTail (linear_k118_1 ++ (34 :: 58 :: tail)) [] = some (linear_k118_1, 58 :: tail) := by rfl
def linear_k118_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd118_2 : stringBytes linear_k118_2 = true := by decide +kernel
theorem mutated_kp118_2 (tail : List Nat) : parseStringTail (linear_k118_2 ++ (34 :: 58 :: tail)) [] = some (linear_k118_2, 58 :: tail) := by rfl
def linear_k118_3 : List Nat := [116,101,114,109]
theorem mutated_kd118_3 : stringBytes linear_k118_3 = true := by decide +kernel
theorem mutated_kp118_3 (tail : List Nat) : parseStringTail (linear_k118_3 ++ (34 :: 58 :: tail)) [] = some (linear_k118_3, 58 :: tail) := by rfl
def linear_l118_3 : List (List Nat × Raw) := [(linear_k118_3, linear_r122)]
def linear_v118_3 : List Nat := linear_g309 ++ linear_b122
theorem mutated_sl118_3 : serializeFields 4067 27 linear_l118_3 = some linear_v118_3 := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4066 27 linear_k118_3 linear_r122 linear_b122 mutated_kd118_3 mutated_s122)
theorem mutated_pl118_3 (tail : List Nat) : parseFields 4067 27 (linear_v118_3 ++ (125 :: tail)) = some (linear_l118_3, tail) := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4066 27 (linear_k118_3 ++ (34 :: 58 :: (linear_b122 ++ (125 :: tail)))) linear_k118_3 (linear_b122 ++ (125 :: tail)) tail linear_r122 (mutated_kp118_3 (linear_b122 ++ (125 :: tail))) (mutated_p122 (125 :: tail)))
def linear_l118_2 : List (List Nat × Raw) := (linear_k118_2, linear_r121) :: linear_l118_3
def linear_v118_2 : List Nat := (linear_g306 ++ linear_b121) ++ (44 :: linear_v118_3)
theorem mutated_sl118_2 : serializeFields 4068 27 linear_l118_2 = some linear_v118_2 := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k118_2 linear_r121 (linear_k118_3, linear_r122) [] linear_b121 linear_v118_3 mutated_kd118_2 mutated_s121 mutated_sl118_3)
theorem mutated_pl118_2 (tail : List Nat) : parseFields 4068 27 (linear_v118_2 ++ (125 :: tail)) = some (linear_l118_2, tail) := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k118_2 ++ (34 :: 58 :: (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))))) linear_k118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))) (linear_v118_3 ++ (125 :: tail)) tail linear_r121 linear_l118_3 (mutated_kp118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail))))) (mutated_p121 (44 :: (linear_v118_3 ++ (125 :: tail)))) (mutated_pl118_3 tail))
def linear_l118_1 : List (List Nat × Raw) := (linear_k118_1, linear_r120) :: linear_l118_2
def linear_v118_1 : List Nat := (linear_g303 ++ linear_b120) ++ (44 :: linear_v118_2)
theorem mutated_sl118_1 : serializeFields 4069 27 linear_l118_1 = some linear_v118_1 := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k118_1 linear_r120 (linear_k118_2, linear_r121) linear_l118_3 linear_b120 linear_v118_2 mutated_kd118_1 mutated_s120 mutated_sl118_2)
theorem mutated_pl118_1 (tail : List Nat) : parseFields 4069 27 (linear_v118_1 ++ (125 :: tail)) = some (linear_l118_1, tail) := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k118_1 ++ (34 :: 58 :: (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))))) linear_k118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))) (linear_v118_2 ++ (125 :: tail)) tail linear_r120 linear_l118_2 (mutated_kp118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail))))) (mutated_p120 (44 :: (linear_v118_2 ++ (125 :: tail)))) (mutated_pl118_2 tail))
def linear_l118_0 : List (List Nat × Raw) := (linear_k118_0, linear_r119) :: linear_l118_1
def linear_v118_0 : List Nat := (linear_g300 ++ linear_b119) ++ (44 :: linear_v118_1)
theorem mutated_sl118_0 : serializeFields 4070 27 linear_l118_0 = some linear_v118_0 := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k118_0 linear_r119 (linear_k118_1, linear_r120) linear_l118_2 linear_b119 linear_v118_1 mutated_kd118_0 mutated_s119 mutated_sl118_1)
theorem mutated_pl118_0 (tail : List Nat) : parseFields 4070 27 (linear_v118_0 ++ (125 :: tail)) = some (linear_l118_0, tail) := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) linear_k118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))) (linear_v118_1 ++ (125 :: tail)) tail linear_r119 linear_l118_1 (mutated_kp118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail))))) (mutated_p119 (44 :: (linear_v118_1 ++ (125 :: tail)))) (mutated_pl118_1 tail))
def linear_r118 : Raw := (.obj linear_l118_0)
def linear_b118 : List Nat := linear_g299 ++ (linear_v118_0 ++ linear_g311)
theorem mutated_o118 : orderedFields linear_l118_0 = true := by decide +kernel
theorem mutated_s118 : serializeRaw 4071 28 linear_r118 = some linear_b118 := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4070 27 linear_l118_0 linear_v118_0 mutated_o118 mutated_sl118_0)
theorem mutated_p118 (tail : List Nat) : parseRaw 4071 28 (linear_b118 ++ tail) = some (linear_r118, tail) := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4070 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) tail linear_l118_0 mutated_o118 (by simpa only [linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl118_0 tail)))
def linear_r124 : Raw := (.str [100,103,95,115,108,111,119,95,52])
def linear_b124 : List Nat := linear_g315
theorem mutated_s124 : serializeRaw 4068 27 linear_r124 = some linear_b124 := by decide +kernel
theorem mutated_p124 (tail : List Nat) : parseRaw 4068 27 (linear_b124 ++ tail) = some (linear_r124, tail) := by rfl
def linear_r126 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,52])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b126 : List Nat := linear_g319
theorem mutated_s126 : serializeRaw 4065 26 linear_r126 = some linear_b126 := by decide +kernel
theorem mutated_p126 (tail : List Nat) : parseRaw 4065 26 (linear_b126 ++ tail) = some (linear_r126, tail) := by rfl
def linear_r127 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52]),(.str [100,103,95,118,95,49,52,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b127 : List Nat := linear_g321
theorem mutated_s127 : serializeRaw 4064 26 linear_r127 = some linear_b127 := by decide +kernel
theorem mutated_p127 (tail : List Nat) : parseRaw 4064 26 (linear_b127 ++ tail) = some (linear_r127, tail) := by rfl
def linear_r128 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b128 : List Nat := linear_g323
theorem mutated_s128 : serializeRaw 4063 26 linear_r128 = some linear_b128 := by decide +kernel
theorem mutated_p128 (tail : List Nat) : parseRaw 4063 26 (linear_b128 ++ tail) = some (linear_r128, tail) := by rfl
def linear_r129 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b129 : List Nat := linear_g325
theorem mutated_s129 : serializeRaw 4062 26 linear_r129 = some linear_b129 := by decide +kernel
theorem mutated_p129 (tail : List Nat) : parseRaw 4062 26 (linear_b129 ++ tail) = some (linear_r129, tail) := by rfl
def linear_r130 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,49]),(.str [100,103,95,118,95,49,52,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b130 : List Nat := linear_g327
theorem mutated_s130 : serializeRaw 4061 26 linear_r130 = some linear_b130 := by decide +kernel
theorem mutated_p130 (tail : List Nat) : parseRaw 4061 26 (linear_b130 ++ tail) = some (linear_r130, tail) := by rfl
def linear_r131 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b131 : List Nat := linear_g329
theorem mutated_s131 : serializeRaw 4060 26 linear_r131 = some linear_b131 := by decide +kernel
theorem mutated_p131 (tail : List Nat) : parseRaw 4060 26 (linear_b131 ++ tail) = some (linear_r131, tail) := by rfl
def linear_r132 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,51]),(.str [100,103,95,118,95,49,52,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b132 : List Nat := linear_g331
theorem mutated_s132 : serializeRaw 4059 26 linear_r132 = some linear_b132 := by decide +kernel
theorem mutated_p132 (tail : List Nat) : parseRaw 4059 26 (linear_b132 ++ tail) = some (linear_r132, tail) := by rfl
def linear_l125_6 : List Raw := [linear_r132]
def linear_v125_6 : List Nat := linear_b132
theorem mutated_sl125_6 : serializeItems 4060 26 linear_l125_6 = some linear_v125_6 := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4059 26 linear_r132 linear_b132 mutated_s132)
theorem mutated_pl125_6 (tail : List Nat) : parseItems 4060 26 (linear_v125_6 ++ (93 :: tail)) = some (linear_l125_6, tail) := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4059 26 (linear_b132 ++ (93 :: tail)) tail linear_r132 (mutated_p132 (93 :: tail)))
def linear_l125_5 : List Raw := linear_r131 :: linear_l125_6
def linear_v125_5 : List Nat := (linear_b131) ++ (44 :: linear_v125_6)
theorem mutated_sl125_5 : serializeItems 4061 26 linear_l125_5 = some linear_v125_5 := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r131 linear_r132 [] linear_b131 linear_v125_6 mutated_s131 mutated_sl125_6)
theorem mutated_pl125_5 (tail : List Nat) : parseItems 4061 26 (linear_v125_5 ++ (93 :: tail)) = some (linear_l125_5, tail) := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b131 ++ (44 :: (linear_v125_6 ++ (93 :: tail)))) (linear_v125_6 ++ (93 :: tail)) tail linear_r131 linear_l125_6 (mutated_p131 (44 :: (linear_v125_6 ++ (93 :: tail)))) (mutated_pl125_6 tail))
def linear_l125_4 : List Raw := linear_r130 :: linear_l125_5
def linear_v125_4 : List Nat := (linear_b130) ++ (44 :: linear_v125_5)
theorem mutated_sl125_4 : serializeItems 4062 26 linear_l125_4 = some linear_v125_4 := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r130 linear_r131 linear_l125_6 linear_b130 linear_v125_5 mutated_s130 mutated_sl125_5)
theorem mutated_pl125_4 (tail : List Nat) : parseItems 4062 26 (linear_v125_4 ++ (93 :: tail)) = some (linear_l125_4, tail) := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b130 ++ (44 :: (linear_v125_5 ++ (93 :: tail)))) (linear_v125_5 ++ (93 :: tail)) tail linear_r130 linear_l125_5 (mutated_p130 (44 :: (linear_v125_5 ++ (93 :: tail)))) (mutated_pl125_5 tail))
def linear_l125_3 : List Raw := linear_r129 :: linear_l125_4
def linear_v125_3 : List Nat := (linear_b129) ++ (44 :: linear_v125_4)
theorem mutated_sl125_3 : serializeItems 4063 26 linear_l125_3 = some linear_v125_3 := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r129 linear_r130 linear_l125_5 linear_b129 linear_v125_4 mutated_s129 mutated_sl125_4)
theorem mutated_pl125_3 (tail : List Nat) : parseItems 4063 26 (linear_v125_3 ++ (93 :: tail)) = some (linear_l125_3, tail) := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b129 ++ (44 :: (linear_v125_4 ++ (93 :: tail)))) (linear_v125_4 ++ (93 :: tail)) tail linear_r129 linear_l125_4 (mutated_p129 (44 :: (linear_v125_4 ++ (93 :: tail)))) (mutated_pl125_4 tail))
def linear_l125_2 : List Raw := linear_r128 :: linear_l125_3
def linear_v125_2 : List Nat := (linear_b128) ++ (44 :: linear_v125_3)
theorem mutated_sl125_2 : serializeItems 4064 26 linear_l125_2 = some linear_v125_2 := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r128 linear_r129 linear_l125_4 linear_b128 linear_v125_3 mutated_s128 mutated_sl125_3)
theorem mutated_pl125_2 (tail : List Nat) : parseItems 4064 26 (linear_v125_2 ++ (93 :: tail)) = some (linear_l125_2, tail) := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b128 ++ (44 :: (linear_v125_3 ++ (93 :: tail)))) (linear_v125_3 ++ (93 :: tail)) tail linear_r128 linear_l125_3 (mutated_p128 (44 :: (linear_v125_3 ++ (93 :: tail)))) (mutated_pl125_3 tail))
def linear_l125_1 : List Raw := linear_r127 :: linear_l125_2
def linear_v125_1 : List Nat := (linear_b127) ++ (44 :: linear_v125_2)
theorem mutated_sl125_1 : serializeItems 4065 26 linear_l125_1 = some linear_v125_1 := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r127 linear_r128 linear_l125_3 linear_b127 linear_v125_2 mutated_s127 mutated_sl125_2)
theorem mutated_pl125_1 (tail : List Nat) : parseItems 4065 26 (linear_v125_1 ++ (93 :: tail)) = some (linear_l125_1, tail) := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b127 ++ (44 :: (linear_v125_2 ++ (93 :: tail)))) (linear_v125_2 ++ (93 :: tail)) tail linear_r127 linear_l125_2 (mutated_p127 (44 :: (linear_v125_2 ++ (93 :: tail)))) (mutated_pl125_2 tail))
def linear_l125_0 : List Raw := linear_r126 :: linear_l125_1
def linear_v125_0 : List Nat := (linear_b126) ++ (44 :: linear_v125_1)
theorem mutated_sl125_0 : serializeItems 4066 26 linear_l125_0 = some linear_v125_0 := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r126 linear_r127 linear_l125_2 linear_b126 linear_v125_1 mutated_s126 mutated_sl125_1)
theorem mutated_pl125_0 (tail : List Nat) : parseItems 4066 26 (linear_v125_0 ++ (93 :: tail)) = some (linear_l125_0, tail) := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b126 ++ (44 :: (linear_v125_1 ++ (93 :: tail)))) (linear_v125_1 ++ (93 :: tail)) tail linear_r126 linear_l125_1 (mutated_p126 (44 :: (linear_v125_1 ++ (93 :: tail)))) (mutated_pl125_1 tail))
def linear_r125 : Raw := (.arr linear_l125_0)
def linear_b125 : List Nat := linear_g318 ++ (linear_v125_0 ++ linear_g332)
theorem mutated_s125 : serializeRaw 4067 27 linear_r125 = some linear_b125 := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4066 26 linear_l125_0 linear_v125_0 mutated_sl125_0)
theorem mutated_p125 (tail : List Nat) : parseRaw 4067 27 (linear_b125 ++ tail) = some (linear_r125, tail) := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4066 26 (linear_v125_0 ++ (93 :: tail)) tail linear_l125_0 (by intro h; cases h) (mutated_pl125_0 tail))
def linear_r133 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b133 : List Nat := linear_g335
theorem mutated_s133 : serializeRaw 4066 27 linear_r133 = some linear_b133 := by decide +kernel
theorem mutated_p133 (tail : List Nat) : parseRaw 4066 27 (linear_b133 ++ tail) = some (linear_r133, tail) := by rfl
def linear_r134 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,56]),(.str [100,103,95,118,95,49,51,57]),(.str [100,103,95,118,95,49,52,48]),(.str [100,103,95,118,95,49,52,55]),(.str [100,103,95,118,95,49,52,50]),(.str [100,103,95,118,95,49,52,57])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b134 : List Nat := linear_g338
theorem mutated_s134 : serializeRaw 4065 27 linear_r134 = some linear_b134 := by decide +kernel
theorem mutated_p134 (tail : List Nat) : parseRaw 4065 27 (linear_b134 ++ tail) = some (linear_r134, tail) := by rfl
def linear_k123_0 : List Nat := [105,100]
theorem mutated_kd123_0 : stringBytes linear_k123_0 = true := by decide +kernel
theorem mutated_kp123_0 (tail : List Nat) : parseStringTail (linear_k123_0 ++ (34 :: 58 :: tail)) [] = some (linear_k123_0, 58 :: tail) := by rfl
def linear_k123_1 : List Nat := [111,112,115]
theorem mutated_kd123_1 : stringBytes linear_k123_1 = true := by decide +kernel
theorem mutated_kp123_1 (tail : List Nat) : parseStringTail (linear_k123_1 ++ (34 :: 58 :: tail)) [] = some (linear_k123_1, 58 :: tail) := by rfl
def linear_k123_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd123_2 : stringBytes linear_k123_2 = true := by decide +kernel
theorem mutated_kp123_2 (tail : List Nat) : parseStringTail (linear_k123_2 ++ (34 :: 58 :: tail)) [] = some (linear_k123_2, 58 :: tail) := by rfl
def linear_k123_3 : List Nat := [116,101,114,109]
theorem mutated_kd123_3 : stringBytes linear_k123_3 = true := by decide +kernel
theorem mutated_kp123_3 (tail : List Nat) : parseStringTail (linear_k123_3 ++ (34 :: 58 :: tail)) [] = some (linear_k123_3, 58 :: tail) := by rfl
def linear_l123_3 : List (List Nat × Raw) := [(linear_k123_3, linear_r134)]
def linear_v123_3 : List Nat := linear_g337 ++ linear_b134
theorem mutated_sl123_3 : serializeFields 4066 27 linear_l123_3 = some linear_v123_3 := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4065 27 linear_k123_3 linear_r134 linear_b134 mutated_kd123_3 mutated_s134)
theorem mutated_pl123_3 (tail : List Nat) : parseFields 4066 27 (linear_v123_3 ++ (125 :: tail)) = some (linear_l123_3, tail) := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4065 27 (linear_k123_3 ++ (34 :: 58 :: (linear_b134 ++ (125 :: tail)))) linear_k123_3 (linear_b134 ++ (125 :: tail)) tail linear_r134 (mutated_kp123_3 (linear_b134 ++ (125 :: tail))) (mutated_p134 (125 :: tail)))
def linear_l123_2 : List (List Nat × Raw) := (linear_k123_2, linear_r133) :: linear_l123_3
def linear_v123_2 : List Nat := (linear_g334 ++ linear_b133) ++ (44 :: linear_v123_3)
theorem mutated_sl123_2 : serializeFields 4067 27 linear_l123_2 = some linear_v123_2 := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k123_2 linear_r133 (linear_k123_3, linear_r134) [] linear_b133 linear_v123_3 mutated_kd123_2 mutated_s133 mutated_sl123_3)
theorem mutated_pl123_2 (tail : List Nat) : parseFields 4067 27 (linear_v123_2 ++ (125 :: tail)) = some (linear_l123_2, tail) := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k123_2 ++ (34 :: 58 :: (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))))) linear_k123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))) (linear_v123_3 ++ (125 :: tail)) tail linear_r133 linear_l123_3 (mutated_kp123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail))))) (mutated_p133 (44 :: (linear_v123_3 ++ (125 :: tail)))) (mutated_pl123_3 tail))
def linear_l123_1 : List (List Nat × Raw) := (linear_k123_1, linear_r125) :: linear_l123_2
def linear_v123_1 : List Nat := (linear_g317 ++ linear_b125) ++ (44 :: linear_v123_2)
theorem mutated_sl123_1 : serializeFields 4068 27 linear_l123_1 = some linear_v123_1 := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k123_1 linear_r125 (linear_k123_2, linear_r133) linear_l123_3 linear_b125 linear_v123_2 mutated_kd123_1 mutated_s125 mutated_sl123_2)
theorem mutated_pl123_1 (tail : List Nat) : parseFields 4068 27 (linear_v123_1 ++ (125 :: tail)) = some (linear_l123_1, tail) := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k123_1 ++ (34 :: 58 :: (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))))) linear_k123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))) (linear_v123_2 ++ (125 :: tail)) tail linear_r125 linear_l123_2 (mutated_kp123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail))))) (mutated_p125 (44 :: (linear_v123_2 ++ (125 :: tail)))) (mutated_pl123_2 tail))
def linear_l123_0 : List (List Nat × Raw) := (linear_k123_0, linear_r124) :: linear_l123_1
def linear_v123_0 : List Nat := (linear_g314 ++ linear_b124) ++ (44 :: linear_v123_1)
theorem mutated_sl123_0 : serializeFields 4069 27 linear_l123_0 = some linear_v123_0 := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k123_0 linear_r124 (linear_k123_1, linear_r125) linear_l123_2 linear_b124 linear_v123_1 mutated_kd123_0 mutated_s124 mutated_sl123_1)
theorem mutated_pl123_0 (tail : List Nat) : parseFields 4069 27 (linear_v123_0 ++ (125 :: tail)) = some (linear_l123_0, tail) := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) linear_k123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))) (linear_v123_1 ++ (125 :: tail)) tail linear_r124 linear_l123_1 (mutated_kp123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail))))) (mutated_p124 (44 :: (linear_v123_1 ++ (125 :: tail)))) (mutated_pl123_1 tail))
def linear_r123 : Raw := (.obj linear_l123_0)
def linear_b123 : List Nat := linear_g313 ++ (linear_v123_0 ++ linear_g339)
theorem mutated_o123 : orderedFields linear_l123_0 = true := by decide +kernel
theorem mutated_s123 : serializeRaw 4070 28 linear_r123 = some linear_b123 := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4069 27 linear_l123_0 linear_v123_0 mutated_o123 mutated_sl123_0)
theorem mutated_p123 (tail : List Nat) : parseRaw 4070 28 (linear_b123 ++ tail) = some (linear_r123, tail) := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4069 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) tail linear_l123_0 mutated_o123 (by simpa only [linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl123_0 tail)))
def linear_r136 : Raw := (.str [100,103,95,115,108,111,119,95,53])
def linear_b136 : List Nat := linear_g343
theorem mutated_s136 : serializeRaw 4067 27 linear_r136 = some linear_b136 := by decide +kernel
theorem mutated_p136 (tail : List Nat) : parseRaw 4067 27 (linear_b136 ++ tail) = some (linear_r136, tail) := by rfl
def linear_r137 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b137 : List Nat := linear_g346
theorem mutated_s137 : serializeRaw 4066 27 linear_r137 = some linear_b137 := by decide +kernel
theorem mutated_p137 (tail : List Nat) : parseRaw 4066 27 (linear_b137 ++ tail) = some (linear_r137, tail) := by rfl
def linear_r138 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,51])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b138 : List Nat := linear_g349
theorem mutated_s138 : serializeRaw 4065 27 linear_r138 = some linear_b138 := by decide +kernel
theorem mutated_p138 (tail : List Nat) : parseRaw 4065 27 (linear_b138 ++ tail) = some (linear_r138, tail) := by rfl
def linear_r139 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,53,51])]))])
def linear_b139 : List Nat := linear_g352
theorem mutated_s139 : serializeRaw 4064 27 linear_r139 = some linear_b139 := by decide +kernel
theorem mutated_p139 (tail : List Nat) : parseRaw 4064 27 (linear_b139 ++ tail) = some (linear_r139, tail) := by rfl
def linear_k135_0 : List Nat := [105,100]
theorem mutated_kd135_0 : stringBytes linear_k135_0 = true := by decide +kernel
theorem mutated_kp135_0 (tail : List Nat) : parseStringTail (linear_k135_0 ++ (34 :: 58 :: tail)) [] = some (linear_k135_0, 58 :: tail) := by rfl
def linear_k135_1 : List Nat := [111,112,115]
theorem mutated_kd135_1 : stringBytes linear_k135_1 = true := by decide +kernel
theorem mutated_kp135_1 (tail : List Nat) : parseStringTail (linear_k135_1 ++ (34 :: 58 :: tail)) [] = some (linear_k135_1, 58 :: tail) := by rfl
def linear_k135_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd135_2 : stringBytes linear_k135_2 = true := by decide +kernel
theorem mutated_kp135_2 (tail : List Nat) : parseStringTail (linear_k135_2 ++ (34 :: 58 :: tail)) [] = some (linear_k135_2, 58 :: tail) := by rfl
def linear_k135_3 : List Nat := [116,101,114,109]
theorem mutated_kd135_3 : stringBytes linear_k135_3 = true := by decide +kernel
theorem mutated_kp135_3 (tail : List Nat) : parseStringTail (linear_k135_3 ++ (34 :: 58 :: tail)) [] = some (linear_k135_3, 58 :: tail) := by rfl
def linear_l135_3 : List (List Nat × Raw) := [(linear_k135_3, linear_r139)]
def linear_v135_3 : List Nat := linear_g351 ++ linear_b139
theorem mutated_sl135_3 : serializeFields 4065 27 linear_l135_3 = some linear_v135_3 := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4064 27 linear_k135_3 linear_r139 linear_b139 mutated_kd135_3 mutated_s139)
theorem mutated_pl135_3 (tail : List Nat) : parseFields 4065 27 (linear_v135_3 ++ (125 :: tail)) = some (linear_l135_3, tail) := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4064 27 (linear_k135_3 ++ (34 :: 58 :: (linear_b139 ++ (125 :: tail)))) linear_k135_3 (linear_b139 ++ (125 :: tail)) tail linear_r139 (mutated_kp135_3 (linear_b139 ++ (125 :: tail))) (mutated_p139 (125 :: tail)))
def linear_l135_2 : List (List Nat × Raw) := (linear_k135_2, linear_r138) :: linear_l135_3
def linear_v135_2 : List Nat := (linear_g348 ++ linear_b138) ++ (44 :: linear_v135_3)
theorem mutated_sl135_2 : serializeFields 4066 27 linear_l135_2 = some linear_v135_2 := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k135_2 linear_r138 (linear_k135_3, linear_r139) [] linear_b138 linear_v135_3 mutated_kd135_2 mutated_s138 mutated_sl135_3)
theorem mutated_pl135_2 (tail : List Nat) : parseFields 4066 27 (linear_v135_2 ++ (125 :: tail)) = some (linear_l135_2, tail) := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k135_2 ++ (34 :: 58 :: (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))))) linear_k135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))) (linear_v135_3 ++ (125 :: tail)) tail linear_r138 linear_l135_3 (mutated_kp135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail))))) (mutated_p138 (44 :: (linear_v135_3 ++ (125 :: tail)))) (mutated_pl135_3 tail))
def linear_l135_1 : List (List Nat × Raw) := (linear_k135_1, linear_r137) :: linear_l135_2
def linear_v135_1 : List Nat := (linear_g345 ++ linear_b137) ++ (44 :: linear_v135_2)
theorem mutated_sl135_1 : serializeFields 4067 27 linear_l135_1 = some linear_v135_1 := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k135_1 linear_r137 (linear_k135_2, linear_r138) linear_l135_3 linear_b137 linear_v135_2 mutated_kd135_1 mutated_s137 mutated_sl135_2)
theorem mutated_pl135_1 (tail : List Nat) : parseFields 4067 27 (linear_v135_1 ++ (125 :: tail)) = some (linear_l135_1, tail) := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k135_1 ++ (34 :: 58 :: (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))))) linear_k135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))) (linear_v135_2 ++ (125 :: tail)) tail linear_r137 linear_l135_2 (mutated_kp135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail))))) (mutated_p137 (44 :: (linear_v135_2 ++ (125 :: tail)))) (mutated_pl135_2 tail))
def linear_l135_0 : List (List Nat × Raw) := (linear_k135_0, linear_r136) :: linear_l135_1
def linear_v135_0 : List Nat := (linear_g342 ++ linear_b136) ++ (44 :: linear_v135_1)
theorem mutated_sl135_0 : serializeFields 4068 27 linear_l135_0 = some linear_v135_0 := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k135_0 linear_r136 (linear_k135_1, linear_r137) linear_l135_2 linear_b136 linear_v135_1 mutated_kd135_0 mutated_s136 mutated_sl135_1)
theorem mutated_pl135_0 (tail : List Nat) : parseFields 4068 27 (linear_v135_0 ++ (125 :: tail)) = some (linear_l135_0, tail) := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) linear_k135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))) (linear_v135_1 ++ (125 :: tail)) tail linear_r136 linear_l135_1 (mutated_kp135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail))))) (mutated_p136 (44 :: (linear_v135_1 ++ (125 :: tail)))) (mutated_pl135_1 tail))
def linear_r135 : Raw := (.obj linear_l135_0)
def linear_b135 : List Nat := linear_g341 ++ (linear_v135_0 ++ linear_g353)
theorem mutated_o135 : orderedFields linear_l135_0 = true := by decide +kernel
theorem mutated_s135 : serializeRaw 4069 28 linear_r135 = some linear_b135 := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4068 27 linear_l135_0 linear_v135_0 mutated_o135 mutated_sl135_0)
theorem mutated_p135 (tail : List Nat) : parseRaw 4069 28 (linear_b135 ++ tail) = some (linear_r135, tail) := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4068 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) tail linear_l135_0 mutated_o135 (by simpa only [linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl135_0 tail)))
def linear_r141 : Raw := (.str [100,103,95,103,117,97,114,100,95,48])
def linear_b141 : List Nat := linear_g357
theorem mutated_s141 : serializeRaw 4066 27 linear_r141 = some linear_b141 := by decide +kernel
theorem mutated_p141 (tail : List Nat) : parseRaw 4066 27 (linear_b141 ++ tail) = some (linear_r141, tail) := by rfl
def linear_r142 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,50]),(.str [100,103,95,118,95,49,54,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b142 : List Nat := linear_g360
theorem mutated_s142 : serializeRaw 4065 27 linear_r142 = some linear_b142 := by decide +kernel
theorem mutated_p142 (tail : List Nat) : parseRaw 4065 27 (linear_b142 ++ tail) = some (linear_r142, tail) := by rfl
def linear_r143 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b143 : List Nat := linear_g363
theorem mutated_s143 : serializeRaw 4064 27 linear_r143 = some linear_b143 := by decide +kernel
theorem mutated_p143 (tail : List Nat) : parseRaw 4064 27 (linear_b143 ++ tail) = some (linear_r143, tail) := by rfl
def linear_r144 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,54,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b144 : List Nat := linear_g366
theorem mutated_s144 : serializeRaw 4063 27 linear_r144 = some linear_b144 := by decide +kernel
theorem mutated_p144 (tail : List Nat) : parseRaw 4063 27 (linear_b144 ++ tail) = some (linear_r144, tail) := by rfl
def linear_k140_0 : List Nat := [105,100]
theorem mutated_kd140_0 : stringBytes linear_k140_0 = true := by decide +kernel
theorem mutated_kp140_0 (tail : List Nat) : parseStringTail (linear_k140_0 ++ (34 :: 58 :: tail)) [] = some (linear_k140_0, 58 :: tail) := by rfl
def linear_k140_1 : List Nat := [111,112,115]
theorem mutated_kd140_1 : stringBytes linear_k140_1 = true := by decide +kernel
theorem mutated_kp140_1 (tail : List Nat) : parseStringTail (linear_k140_1 ++ (34 :: 58 :: tail)) [] = some (linear_k140_1, 58 :: tail) := by rfl
def linear_k140_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd140_2 : stringBytes linear_k140_2 = true := by decide +kernel
theorem mutated_kp140_2 (tail : List Nat) : parseStringTail (linear_k140_2 ++ (34 :: 58 :: tail)) [] = some (linear_k140_2, 58 :: tail) := by rfl
def linear_k140_3 : List Nat := [116,101,114,109]
theorem mutated_kd140_3 : stringBytes linear_k140_3 = true := by decide +kernel
theorem mutated_kp140_3 (tail : List Nat) : parseStringTail (linear_k140_3 ++ (34 :: 58 :: tail)) [] = some (linear_k140_3, 58 :: tail) := by rfl
def linear_l140_3 : List (List Nat × Raw) := [(linear_k140_3, linear_r144)]
def linear_v140_3 : List Nat := linear_g365 ++ linear_b144
theorem mutated_sl140_3 : serializeFields 4064 27 linear_l140_3 = some linear_v140_3 := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4063 27 linear_k140_3 linear_r144 linear_b144 mutated_kd140_3 mutated_s144)
theorem mutated_pl140_3 (tail : List Nat) : parseFields 4064 27 (linear_v140_3 ++ (125 :: tail)) = some (linear_l140_3, tail) := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4063 27 (linear_k140_3 ++ (34 :: 58 :: (linear_b144 ++ (125 :: tail)))) linear_k140_3 (linear_b144 ++ (125 :: tail)) tail linear_r144 (mutated_kp140_3 (linear_b144 ++ (125 :: tail))) (mutated_p144 (125 :: tail)))
def linear_l140_2 : List (List Nat × Raw) := (linear_k140_2, linear_r143) :: linear_l140_3
def linear_v140_2 : List Nat := (linear_g362 ++ linear_b143) ++ (44 :: linear_v140_3)
theorem mutated_sl140_2 : serializeFields 4065 27 linear_l140_2 = some linear_v140_2 := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k140_2 linear_r143 (linear_k140_3, linear_r144) [] linear_b143 linear_v140_3 mutated_kd140_2 mutated_s143 mutated_sl140_3)
theorem mutated_pl140_2 (tail : List Nat) : parseFields 4065 27 (linear_v140_2 ++ (125 :: tail)) = some (linear_l140_2, tail) := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k140_2 ++ (34 :: 58 :: (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))))) linear_k140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))) (linear_v140_3 ++ (125 :: tail)) tail linear_r143 linear_l140_3 (mutated_kp140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail))))) (mutated_p143 (44 :: (linear_v140_3 ++ (125 :: tail)))) (mutated_pl140_3 tail))
def linear_l140_1 : List (List Nat × Raw) := (linear_k140_1, linear_r142) :: linear_l140_2
def linear_v140_1 : List Nat := (linear_g359 ++ linear_b142) ++ (44 :: linear_v140_2)
theorem mutated_sl140_1 : serializeFields 4066 27 linear_l140_1 = some linear_v140_1 := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k140_1 linear_r142 (linear_k140_2, linear_r143) linear_l140_3 linear_b142 linear_v140_2 mutated_kd140_1 mutated_s142 mutated_sl140_2)
theorem mutated_pl140_1 (tail : List Nat) : parseFields 4066 27 (linear_v140_1 ++ (125 :: tail)) = some (linear_l140_1, tail) := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k140_1 ++ (34 :: 58 :: (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))))) linear_k140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))) (linear_v140_2 ++ (125 :: tail)) tail linear_r142 linear_l140_2 (mutated_kp140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail))))) (mutated_p142 (44 :: (linear_v140_2 ++ (125 :: tail)))) (mutated_pl140_2 tail))
def linear_l140_0 : List (List Nat × Raw) := (linear_k140_0, linear_r141) :: linear_l140_1
def linear_v140_0 : List Nat := (linear_g356 ++ linear_b141) ++ (44 :: linear_v140_1)
theorem mutated_sl140_0 : serializeFields 4067 27 linear_l140_0 = some linear_v140_0 := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k140_0 linear_r141 (linear_k140_1, linear_r142) linear_l140_2 linear_b141 linear_v140_1 mutated_kd140_0 mutated_s141 mutated_sl140_1)
theorem mutated_pl140_0 (tail : List Nat) : parseFields 4067 27 (linear_v140_0 ++ (125 :: tail)) = some (linear_l140_0, tail) := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) linear_k140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))) (linear_v140_1 ++ (125 :: tail)) tail linear_r141 linear_l140_1 (mutated_kp140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail))))) (mutated_p141 (44 :: (linear_v140_1 ++ (125 :: tail)))) (mutated_pl140_1 tail))
def linear_r140 : Raw := (.obj linear_l140_0)
def linear_b140 : List Nat := linear_g355 ++ (linear_v140_0 ++ linear_g367)
theorem mutated_o140 : orderedFields linear_l140_0 = true := by decide +kernel
theorem mutated_s140 : serializeRaw 4068 28 linear_r140 = some linear_b140 := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4067 27 linear_l140_0 linear_v140_0 mutated_o140 mutated_sl140_0)
theorem mutated_p140 (tail : List Nat) : parseRaw 4068 28 (linear_b140 ++ tail) = some (linear_r140, tail) := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4067 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) tail linear_l140_0 mutated_o140 (by simpa only [linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl140_0 tail)))
def linear_r146 : Raw := (.str [100,103,95,103,117,97,114,100,95,49])
def linear_b146 : List Nat := linear_g371
theorem mutated_s146 : serializeRaw 4065 27 linear_r146 = some linear_b146 := by decide +kernel
theorem mutated_p146 (tail : List Nat) : parseRaw 4065 27 (linear_b146 ++ tail) = some (linear_r146, tail) := by rfl
def linear_r147 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,55,49]),(.str [100,103,95,118,95,49,55,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,51])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b147 : List Nat := linear_g374
theorem mutated_s147 : serializeRaw 4064 27 linear_r147 = some linear_b147 := by decide +kernel
theorem mutated_p147 (tail : List Nat) : parseRaw 4064 27 (linear_b147 ++ tail) = some (linear_r147, tail) := by rfl
def linear_r148 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b148 : List Nat := linear_g377
theorem mutated_s148 : serializeRaw 4063 27 linear_r148 = some linear_b148 := by decide +kernel
theorem mutated_p148 (tail : List Nat) : parseRaw 4063 27 (linear_b148 ++ tail) = some (linear_r148, tail) := by rfl
def linear_r149 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,55,51])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b149 : List Nat := linear_g380
theorem mutated_s149 : serializeRaw 4062 27 linear_r149 = some linear_b149 := by decide +kernel
theorem mutated_p149 (tail : List Nat) : parseRaw 4062 27 (linear_b149 ++ tail) = some (linear_r149, tail) := by rfl
def linear_k145_0 : List Nat := [105,100]
theorem mutated_kd145_0 : stringBytes linear_k145_0 = true := by decide +kernel
theorem mutated_kp145_0 (tail : List Nat) : parseStringTail (linear_k145_0 ++ (34 :: 58 :: tail)) [] = some (linear_k145_0, 58 :: tail) := by rfl
def linear_k145_1 : List Nat := [111,112,115]
theorem mutated_kd145_1 : stringBytes linear_k145_1 = true := by decide +kernel
theorem mutated_kp145_1 (tail : List Nat) : parseStringTail (linear_k145_1 ++ (34 :: 58 :: tail)) [] = some (linear_k145_1, 58 :: tail) := by rfl
def linear_k145_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd145_2 : stringBytes linear_k145_2 = true := by decide +kernel
theorem mutated_kp145_2 (tail : List Nat) : parseStringTail (linear_k145_2 ++ (34 :: 58 :: tail)) [] = some (linear_k145_2, 58 :: tail) := by rfl
def linear_k145_3 : List Nat := [116,101,114,109]
theorem mutated_kd145_3 : stringBytes linear_k145_3 = true := by decide +kernel
theorem mutated_kp145_3 (tail : List Nat) : parseStringTail (linear_k145_3 ++ (34 :: 58 :: tail)) [] = some (linear_k145_3, 58 :: tail) := by rfl
def linear_l145_3 : List (List Nat × Raw) := [(linear_k145_3, linear_r149)]
def linear_v145_3 : List Nat := linear_g379 ++ linear_b149
theorem mutated_sl145_3 : serializeFields 4063 27 linear_l145_3 = some linear_v145_3 := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4062 27 linear_k145_3 linear_r149 linear_b149 mutated_kd145_3 mutated_s149)
theorem mutated_pl145_3 (tail : List Nat) : parseFields 4063 27 (linear_v145_3 ++ (125 :: tail)) = some (linear_l145_3, tail) := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4062 27 (linear_k145_3 ++ (34 :: 58 :: (linear_b149 ++ (125 :: tail)))) linear_k145_3 (linear_b149 ++ (125 :: tail)) tail linear_r149 (mutated_kp145_3 (linear_b149 ++ (125 :: tail))) (mutated_p149 (125 :: tail)))
def linear_l145_2 : List (List Nat × Raw) := (linear_k145_2, linear_r148) :: linear_l145_3
def linear_v145_2 : List Nat := (linear_g376 ++ linear_b148) ++ (44 :: linear_v145_3)
theorem mutated_sl145_2 : serializeFields 4064 27 linear_l145_2 = some linear_v145_2 := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4063 27 linear_k145_2 linear_r148 (linear_k145_3, linear_r149) [] linear_b148 linear_v145_3 mutated_kd145_2 mutated_s148 mutated_sl145_3)
theorem mutated_pl145_2 (tail : List Nat) : parseFields 4064 27 (linear_v145_2 ++ (125 :: tail)) = some (linear_l145_2, tail) := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4063 27 (linear_k145_2 ++ (34 :: 58 :: (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))))) linear_k145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))) (linear_v145_3 ++ (125 :: tail)) tail linear_r148 linear_l145_3 (mutated_kp145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail))))) (mutated_p148 (44 :: (linear_v145_3 ++ (125 :: tail)))) (mutated_pl145_3 tail))
def linear_l145_1 : List (List Nat × Raw) := (linear_k145_1, linear_r147) :: linear_l145_2
def linear_v145_1 : List Nat := (linear_g373 ++ linear_b147) ++ (44 :: linear_v145_2)
theorem mutated_sl145_1 : serializeFields 4065 27 linear_l145_1 = some linear_v145_1 := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k145_1 linear_r147 (linear_k145_2, linear_r148) linear_l145_3 linear_b147 linear_v145_2 mutated_kd145_1 mutated_s147 mutated_sl145_2)
theorem mutated_pl145_1 (tail : List Nat) : parseFields 4065 27 (linear_v145_1 ++ (125 :: tail)) = some (linear_l145_1, tail) := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k145_1 ++ (34 :: 58 :: (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))))) linear_k145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))) (linear_v145_2 ++ (125 :: tail)) tail linear_r147 linear_l145_2 (mutated_kp145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail))))) (mutated_p147 (44 :: (linear_v145_2 ++ (125 :: tail)))) (mutated_pl145_2 tail))
def linear_l145_0 : List (List Nat × Raw) := (linear_k145_0, linear_r146) :: linear_l145_1
def linear_v145_0 : List Nat := (linear_g370 ++ linear_b146) ++ (44 :: linear_v145_1)
theorem mutated_sl145_0 : serializeFields 4066 27 linear_l145_0 = some linear_v145_0 := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k145_0 linear_r146 (linear_k145_1, linear_r147) linear_l145_2 linear_b146 linear_v145_1 mutated_kd145_0 mutated_s146 mutated_sl145_1)
theorem mutated_pl145_0 (tail : List Nat) : parseFields 4066 27 (linear_v145_0 ++ (125 :: tail)) = some (linear_l145_0, tail) := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) linear_k145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))) (linear_v145_1 ++ (125 :: tail)) tail linear_r146 linear_l145_1 (mutated_kp145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail))))) (mutated_p146 (44 :: (linear_v145_1 ++ (125 :: tail)))) (mutated_pl145_1 tail))
def linear_r145 : Raw := (.obj linear_l145_0)
def linear_b145 : List Nat := linear_g369 ++ (linear_v145_0 ++ linear_g381)
theorem mutated_o145 : orderedFields linear_l145_0 = true := by decide +kernel
theorem mutated_s145 : serializeRaw 4067 28 linear_r145 = some linear_b145 := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4066 27 linear_l145_0 linear_v145_0 mutated_o145 mutated_sl145_0)
theorem mutated_p145 (tail : List Nat) : parseRaw 4067 28 (linear_b145 ++ tail) = some (linear_r145, tail) := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4066 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) tail linear_l145_0 mutated_o145 (by simpa only [linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl145_0 tail)))
def linear_l4_20 : List Raw := [linear_r145]
def linear_v4_20 : List Nat := linear_b145
theorem mutated_sl4_20 : serializeItems 4068 28 linear_l4_20 = some linear_v4_20 := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4067 28 linear_r145 linear_b145 mutated_s145)
theorem mutated_pl4_20 (tail : List Nat) : parseItems 4068 28 (linear_v4_20 ++ (93 :: tail)) = some (linear_l4_20, tail) := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4067 28 (linear_b145 ++ (93 :: tail)) tail linear_r145 (mutated_p145 (93 :: tail)))
def linear_l4_19 : List Raw := linear_r140 :: linear_l4_20
def linear_v4_19 : List Nat := (linear_b140) ++ (44 :: linear_v4_20)
theorem mutated_sl4_19 : serializeItems 4069 28 linear_l4_19 = some linear_v4_19 := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 28 linear_r140 linear_r145 [] linear_b140 linear_v4_20 mutated_s140 mutated_sl4_20)
theorem mutated_pl4_19 (tail : List Nat) : parseItems 4069 28 (linear_v4_19 ++ (93 :: tail)) = some (linear_l4_19, tail) := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 28 (linear_b140 ++ (44 :: (linear_v4_20 ++ (93 :: tail)))) (linear_v4_20 ++ (93 :: tail)) tail linear_r140 linear_l4_20 (mutated_p140 (44 :: (linear_v4_20 ++ (93 :: tail)))) (mutated_pl4_20 tail))
def linear_l4_18 : List Raw := linear_r135 :: linear_l4_19
def linear_v4_18 : List Nat := (linear_b135) ++ (44 :: linear_v4_19)
theorem mutated_sl4_18 : serializeItems 4070 28 linear_l4_18 = some linear_v4_18 := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 28 linear_r135 linear_r140 linear_l4_20 linear_b135 linear_v4_19 mutated_s135 mutated_sl4_19)
theorem mutated_pl4_18 (tail : List Nat) : parseItems 4070 28 (linear_v4_18 ++ (93 :: tail)) = some (linear_l4_18, tail) := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 28 (linear_b135 ++ (44 :: (linear_v4_19 ++ (93 :: tail)))) (linear_v4_19 ++ (93 :: tail)) tail linear_r135 linear_l4_19 (mutated_p135 (44 :: (linear_v4_19 ++ (93 :: tail)))) (mutated_pl4_19 tail))
def linear_l4_17 : List Raw := linear_r123 :: linear_l4_18
def linear_v4_17 : List Nat := (linear_b123) ++ (44 :: linear_v4_18)
theorem mutated_sl4_17 : serializeItems 4071 28 linear_l4_17 = some linear_v4_17 := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 28 linear_r123 linear_r135 linear_l4_19 linear_b123 linear_v4_18 mutated_s123 mutated_sl4_18)
theorem mutated_pl4_17 (tail : List Nat) : parseItems 4071 28 (linear_v4_17 ++ (93 :: tail)) = some (linear_l4_17, tail) := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 28 (linear_b123 ++ (44 :: (linear_v4_18 ++ (93 :: tail)))) (linear_v4_18 ++ (93 :: tail)) tail linear_r123 linear_l4_18 (mutated_p123 (44 :: (linear_v4_18 ++ (93 :: tail)))) (mutated_pl4_18 tail))
def linear_l4_16 : List Raw := linear_r118 :: linear_l4_17
def linear_v4_16 : List Nat := (linear_b118) ++ (44 :: linear_v4_17)
theorem mutated_sl4_16 : serializeItems 4072 28 linear_l4_16 = some linear_v4_16 := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 28 linear_r118 linear_r123 linear_l4_18 linear_b118 linear_v4_17 mutated_s118 mutated_sl4_17)
theorem mutated_pl4_16 (tail : List Nat) : parseItems 4072 28 (linear_v4_16 ++ (93 :: tail)) = some (linear_l4_16, tail) := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 28 (linear_b118 ++ (44 :: (linear_v4_17 ++ (93 :: tail)))) (linear_v4_17 ++ (93 :: tail)) tail linear_r118 linear_l4_17 (mutated_p118 (44 :: (linear_v4_17 ++ (93 :: tail)))) (mutated_pl4_17 tail))
def linear_l4_15 : List Raw := linear_r113 :: linear_l4_16
def linear_v4_15 : List Nat := (linear_b113) ++ (44 :: linear_v4_16)
theorem mutated_sl4_15 : serializeItems 4073 28 linear_l4_15 = some linear_v4_15 := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 28 linear_r113 linear_r118 linear_l4_17 linear_b113 linear_v4_16 mutated_s113 mutated_sl4_16)
theorem mutated_pl4_15 (tail : List Nat) : parseItems 4073 28 (linear_v4_15 ++ (93 :: tail)) = some (linear_l4_15, tail) := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 28 (linear_b113 ++ (44 :: (linear_v4_16 ++ (93 :: tail)))) (linear_v4_16 ++ (93 :: tail)) tail linear_r113 linear_l4_16 (mutated_p113 (44 :: (linear_v4_16 ++ (93 :: tail)))) (mutated_pl4_16 tail))
def linear_l4_14 : List Raw := linear_r97 :: linear_l4_15
def linear_v4_14 : List Nat := (linear_b97) ++ (44 :: linear_v4_15)
theorem mutated_sl4_14 : serializeItems 4074 28 linear_l4_14 = some linear_v4_14 := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 28 linear_r97 linear_r113 linear_l4_16 linear_b97 linear_v4_15 mutated_s97 mutated_sl4_15)
theorem mutated_pl4_14 (tail : List Nat) : parseItems 4074 28 (linear_v4_14 ++ (93 :: tail)) = some (linear_l4_14, tail) := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 28 (linear_b97 ++ (44 :: (linear_v4_15 ++ (93 :: tail)))) (linear_v4_15 ++ (93 :: tail)) tail linear_r97 linear_l4_15 (mutated_p97 (44 :: (linear_v4_15 ++ (93 :: tail)))) (mutated_pl4_15 tail))
def linear_l4_13 : List Raw := linear_r92 :: linear_l4_14
def linear_v4_13 : List Nat := (linear_b92) ++ (44 :: linear_v4_14)
theorem mutated_sl4_13 : serializeItems 4075 28 linear_l4_13 = some linear_v4_13 := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 28 linear_r92 linear_r97 linear_l4_15 linear_b92 linear_v4_14 mutated_s92 mutated_sl4_14)
theorem mutated_pl4_13 (tail : List Nat) : parseItems 4075 28 (linear_v4_13 ++ (93 :: tail)) = some (linear_l4_13, tail) := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 28 (linear_b92 ++ (44 :: (linear_v4_14 ++ (93 :: tail)))) (linear_v4_14 ++ (93 :: tail)) tail linear_r92 linear_l4_14 (mutated_p92 (44 :: (linear_v4_14 ++ (93 :: tail)))) (mutated_pl4_14 tail))
def linear_l4_12 : List Raw := linear_r87 :: linear_l4_13
def linear_v4_12 : List Nat := (linear_b87) ++ (44 :: linear_v4_13)
theorem mutated_sl4_12 : serializeItems 4076 28 linear_l4_12 = some linear_v4_12 := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4075 28 linear_r87 linear_r92 linear_l4_14 linear_b87 linear_v4_13 mutated_s87 mutated_sl4_13)
theorem mutated_pl4_12 (tail : List Nat) : parseItems 4076 28 (linear_v4_12 ++ (93 :: tail)) = some (linear_l4_12, tail) := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4075 28 (linear_b87 ++ (44 :: (linear_v4_13 ++ (93 :: tail)))) (linear_v4_13 ++ (93 :: tail)) tail linear_r87 linear_l4_13 (mutated_p87 (44 :: (linear_v4_13 ++ (93 :: tail)))) (mutated_pl4_13 tail))
def linear_l4_11 : List Raw := linear_r75 :: linear_l4_12
def linear_v4_11 : List Nat := (linear_b75) ++ (44 :: linear_v4_12)
theorem mutated_sl4_11 : serializeItems 4077 28 linear_l4_11 = some linear_v4_11 := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4076 28 linear_r75 linear_r87 linear_l4_13 linear_b75 linear_v4_12 mutated_s75 mutated_sl4_12)
theorem mutated_pl4_11 (tail : List Nat) : parseItems 4077 28 (linear_v4_11 ++ (93 :: tail)) = some (linear_l4_11, tail) := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4076 28 (linear_b75 ++ (44 :: (linear_v4_12 ++ (93 :: tail)))) (linear_v4_12 ++ (93 :: tail)) tail linear_r75 linear_l4_12 (mutated_p75 (44 :: (linear_v4_12 ++ (93 :: tail)))) (mutated_pl4_12 tail))
def linear_l4_10 : List Raw := linear_r70 :: linear_l4_11
def linear_v4_10 : List Nat := (linear_b70) ++ (44 :: linear_v4_11)
theorem mutated_sl4_10 : serializeItems 4078 28 linear_l4_10 = some linear_v4_10 := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4077 28 linear_r70 linear_r75 linear_l4_12 linear_b70 linear_v4_11 mutated_s70 mutated_sl4_11)
theorem mutated_pl4_10 (tail : List Nat) : parseItems 4078 28 (linear_v4_10 ++ (93 :: tail)) = some (linear_l4_10, tail) := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4077 28 (linear_b70 ++ (44 :: (linear_v4_11 ++ (93 :: tail)))) (linear_v4_11 ++ (93 :: tail)) tail linear_r70 linear_l4_11 (mutated_p70 (44 :: (linear_v4_11 ++ (93 :: tail)))) (mutated_pl4_11 tail))
def linear_l4_9 : List Raw := linear_r65 :: linear_l4_10
def linear_v4_9 : List Nat := (linear_b65) ++ (44 :: linear_v4_10)
theorem mutated_sl4_9 : serializeItems 4079 28 linear_l4_9 = some linear_v4_9 := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 28 linear_r65 linear_r70 linear_l4_11 linear_b65 linear_v4_10 mutated_s65 mutated_sl4_10)
theorem mutated_pl4_9 (tail : List Nat) : parseItems 4079 28 (linear_v4_9 ++ (93 :: tail)) = some (linear_l4_9, tail) := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 28 (linear_b65 ++ (44 :: (linear_v4_10 ++ (93 :: tail)))) (linear_v4_10 ++ (93 :: tail)) tail linear_r65 linear_l4_10 (mutated_p65 (44 :: (linear_v4_10 ++ (93 :: tail)))) (mutated_pl4_10 tail))
def linear_l4_8 : List Raw := linear_r49 :: linear_l4_9
def linear_v4_8 : List Nat := (linear_b49) ++ (44 :: linear_v4_9)
theorem mutated_sl4_8 : serializeItems 4080 28 linear_l4_8 = some linear_v4_8 := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 28 linear_r49 linear_r65 linear_l4_10 linear_b49 linear_v4_9 mutated_s49 mutated_sl4_9)
theorem mutated_pl4_8 (tail : List Nat) : parseItems 4080 28 (linear_v4_8 ++ (93 :: tail)) = some (linear_l4_8, tail) := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 28 (linear_b49 ++ (44 :: (linear_v4_9 ++ (93 :: tail)))) (linear_v4_9 ++ (93 :: tail)) tail linear_r49 linear_l4_9 (mutated_p49 (44 :: (linear_v4_9 ++ (93 :: tail)))) (mutated_pl4_9 tail))
def linear_l4_7 : List Raw := linear_r44 :: linear_l4_8
def linear_v4_7 : List Nat := (linear_b44) ++ (44 :: linear_v4_8)
theorem mutated_sl4_7 : serializeItems 4081 28 linear_l4_7 = some linear_v4_7 := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 28 linear_r44 linear_r49 linear_l4_9 linear_b44 linear_v4_8 mutated_s44 mutated_sl4_8)
theorem mutated_pl4_7 (tail : List Nat) : parseItems 4081 28 (linear_v4_7 ++ (93 :: tail)) = some (linear_l4_7, tail) := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 28 (linear_b44 ++ (44 :: (linear_v4_8 ++ (93 :: tail)))) (linear_v4_8 ++ (93 :: tail)) tail linear_r44 linear_l4_8 (mutated_p44 (44 :: (linear_v4_8 ++ (93 :: tail)))) (mutated_pl4_8 tail))
def linear_l4_6 : List Raw := linear_r39 :: linear_l4_7
def linear_v4_6 : List Nat := (linear_b39) ++ (44 :: linear_v4_7)
theorem mutated_sl4_6 : serializeItems 4082 28 linear_l4_6 = some linear_v4_6 := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4081 28 linear_r39 linear_r44 linear_l4_8 linear_b39 linear_v4_7 mutated_s39 mutated_sl4_7)
theorem mutated_pl4_6 (tail : List Nat) : parseItems 4082 28 (linear_v4_6 ++ (93 :: tail)) = some (linear_l4_6, tail) := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4081 28 (linear_b39 ++ (44 :: (linear_v4_7 ++ (93 :: tail)))) (linear_v4_7 ++ (93 :: tail)) tail linear_r39 linear_l4_7 (mutated_p39 (44 :: (linear_v4_7 ++ (93 :: tail)))) (mutated_pl4_7 tail))
def linear_l4_5 : List Raw := linear_r34 :: linear_l4_6
def linear_v4_5 : List Nat := (linear_b34) ++ (44 :: linear_v4_6)
theorem mutated_sl4_5 : serializeItems 4083 28 linear_l4_5 = some linear_v4_5 := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4082 28 linear_r34 linear_r39 linear_l4_7 linear_b34 linear_v4_6 mutated_s34 mutated_sl4_6)
theorem mutated_pl4_5 (tail : List Nat) : parseItems 4083 28 (linear_v4_5 ++ (93 :: tail)) = some (linear_l4_5, tail) := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4082 28 (linear_b34 ++ (44 :: (linear_v4_6 ++ (93 :: tail)))) (linear_v4_6 ++ (93 :: tail)) tail linear_r34 linear_l4_6 (mutated_p34 (44 :: (linear_v4_6 ++ (93 :: tail)))) (mutated_pl4_6 tail))
def linear_l4_4 : List Raw := linear_r29 :: linear_l4_5
def linear_v4_4 : List Nat := (linear_b29) ++ (44 :: linear_v4_5)
theorem mutated_sl4_4 : serializeItems 4084 28 linear_l4_4 = some linear_v4_4 := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4083 28 linear_r29 linear_r34 linear_l4_6 linear_b29 linear_v4_5 mutated_s29 mutated_sl4_5)
theorem mutated_pl4_4 (tail : List Nat) : parseItems 4084 28 (linear_v4_4 ++ (93 :: tail)) = some (linear_l4_4, tail) := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4083 28 (linear_b29 ++ (44 :: (linear_v4_5 ++ (93 :: tail)))) (linear_v4_5 ++ (93 :: tail)) tail linear_r29 linear_l4_5 (mutated_p29 (44 :: (linear_v4_5 ++ (93 :: tail)))) (mutated_pl4_5 tail))
def linear_l4_3 : List Raw := linear_r24 :: linear_l4_4
def linear_v4_3 : List Nat := (linear_b24) ++ (44 :: linear_v4_4)
theorem mutated_sl4_3 : serializeItems 4085 28 linear_l4_3 = some linear_v4_3 := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4084 28 linear_r24 linear_r29 linear_l4_5 linear_b24 linear_v4_4 mutated_s24 mutated_sl4_4)
theorem mutated_pl4_3 (tail : List Nat) : parseItems 4085 28 (linear_v4_3 ++ (93 :: tail)) = some (linear_l4_3, tail) := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4084 28 (linear_b24 ++ (44 :: (linear_v4_4 ++ (93 :: tail)))) (linear_v4_4 ++ (93 :: tail)) tail linear_r24 linear_l4_4 (mutated_p24 (44 :: (linear_v4_4 ++ (93 :: tail)))) (mutated_pl4_4 tail))
def linear_l4_2 : List Raw := linear_r15 :: linear_l4_3
def linear_v4_2 : List Nat := (linear_b15) ++ (44 :: linear_v4_3)
theorem mutated_sl4_2 : serializeItems 4086 28 linear_l4_2 = some linear_v4_2 := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4085 28 linear_r15 linear_r24 linear_l4_4 linear_b15 linear_v4_3 mutated_s15 mutated_sl4_3)
theorem mutated_pl4_2 (tail : List Nat) : parseItems 4086 28 (linear_v4_2 ++ (93 :: tail)) = some (linear_l4_2, tail) := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4085 28 (linear_b15 ++ (44 :: (linear_v4_3 ++ (93 :: tail)))) (linear_v4_3 ++ (93 :: tail)) tail linear_r15 linear_l4_3 (mutated_p15 (44 :: (linear_v4_3 ++ (93 :: tail)))) (mutated_pl4_3 tail))
def linear_l4_1 : List Raw := linear_r10 :: linear_l4_2
def linear_v4_1 : List Nat := (linear_b10) ++ (44 :: linear_v4_2)
theorem mutated_sl4_1 : serializeItems 4087 28 linear_l4_1 = some linear_v4_1 := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4086 28 linear_r10 linear_r15 linear_l4_3 linear_b10 linear_v4_2 mutated_s10 mutated_sl4_2)
theorem mutated_pl4_1 (tail : List Nat) : parseItems 4087 28 (linear_v4_1 ++ (93 :: tail)) = some (linear_l4_1, tail) := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4086 28 (linear_b10 ++ (44 :: (linear_v4_2 ++ (93 :: tail)))) (linear_v4_2 ++ (93 :: tail)) tail linear_r10 linear_l4_2 (mutated_p10 (44 :: (linear_v4_2 ++ (93 :: tail)))) (mutated_pl4_2 tail))
def linear_l4_0 : List Raw := linear_r5 :: linear_l4_1
def linear_v4_0 : List Nat := (linear_b5) ++ (44 :: linear_v4_1)
theorem mutated_sl4_0 : serializeItems 4088 28 linear_l4_0 = some linear_v4_0 := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4087 28 linear_r5 linear_r10 linear_l4_2 linear_b5 linear_v4_1 mutated_s5 mutated_sl4_1)
theorem mutated_pl4_0 (tail : List Nat) : parseItems 4088 28 (linear_v4_0 ++ (93 :: tail)) = some (linear_l4_0, tail) := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4087 28 (linear_b5 ++ (44 :: (linear_v4_1 ++ (93 :: tail)))) (linear_v4_1 ++ (93 :: tail)) tail linear_r5 linear_l4_1 (mutated_p5 (44 :: (linear_v4_1 ++ (93 :: tail)))) (mutated_pl4_1 tail))
def linear_r4 : Raw := (.arr linear_l4_0)
def linear_b4 : List Nat := linear_g8 ++ (linear_v4_0 ++ linear_g382)
theorem mutated_s4 : serializeRaw 4089 29 linear_r4 = some linear_b4 := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4088 28 linear_l4_0 linear_v4_0 mutated_sl4_0)
theorem mutated_p4 (tail : List Nat) : parseRaw 4089 29 (linear_b4 ++ tail) = some (linear_r4, tail) := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4088 28 (linear_v4_0 ++ (93 :: tail)) tail linear_l4_0 (by intro h; cases h) (mutated_pl4_0 tail))
def linear_r150 : Raw := (.arr [(.str [97,108,108,111,99]),(.str [114,101,97,100]),(.str [116,114,97,112]),(.str [119,114,105,116,101])])
def linear_b150 : List Nat := linear_g385
theorem mutated_s150 : serializeRaw 4088 29 linear_r150 = some linear_b150 := by decide +kernel
theorem mutated_p150 (tail : List Nat) : parseRaw 4088 29 (linear_b150 ++ tail) = some (linear_r150, tail) := by rfl
def linear_r151 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b151 : List Nat := linear_g388
theorem mutated_s151 : serializeRaw 4087 29 linear_r151 = some linear_b151 := by decide +kernel
theorem mutated_p151 (tail : List Nat) : parseRaw 4087 29 (linear_b151 ++ tail) = some (linear_r151, tail) := by rfl
def linear_r152 : Raw := (.str [99,97,108,99,117,108,97,116,101])
def linear_b152 : List Nat := linear_g391
theorem mutated_s152 : serializeRaw 4086 29 linear_r152 = some linear_b152 := by decide +kernel
theorem mutated_p152 (tail : List Nat) : parseRaw 4086 29 (linear_b152 ++ tail) = some (linear_r152, tail) := by rfl
def linear_r153 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b153 : List Nat := linear_g394
theorem mutated_s153 : serializeRaw 4085 29 linear_r153 = some linear_b153 := by decide +kernel
theorem mutated_p153 (tail : List Nat) : parseRaw 4085 29 (linear_b153 ++ tail) = some (linear_r153, tail) := by rfl
def linear_r154 : Raw := (.arr [(.str [117,54,52])])
def linear_b154 : List Nat := linear_g397
theorem mutated_s154 : serializeRaw 4084 29 linear_r154 = some linear_b154 := by decide +kernel
theorem mutated_p154 (tail : List Nat) : parseRaw 4084 29 (linear_b154 ++ tail) = some (linear_r154, tail) := by rfl
def linear_k3_0 : List Nat := [98,108,111,99,107,115]
theorem mutated_kd3_0 : stringBytes linear_k3_0 = true := by decide +kernel
theorem mutated_kp3_0 (tail : List Nat) : parseStringTail (linear_k3_0 ++ (34 :: 58 :: tail)) [] = some (linear_k3_0, 58 :: tail) := by rfl
def linear_k3_1 : List Nat := [101,102,102,101,99,116,115]
theorem mutated_kd3_1 : stringBytes linear_k3_1 = true := by decide +kernel
theorem mutated_kp3_1 (tail : List Nat) : parseStringTail (linear_k3_1 ++ (34 :: 58 :: tail)) [] = some (linear_k3_1, 58 :: tail) := by rfl
def linear_k3_2 : List Nat := [101,110,116,114,121]
theorem mutated_kd3_2 : stringBytes linear_k3_2 = true := by decide +kernel
theorem mutated_kp3_2 (tail : List Nat) : parseStringTail (linear_k3_2 ++ (34 :: 58 :: tail)) [] = some (linear_k3_2, 58 :: tail) := by rfl
def linear_k3_3 : List Nat := [110,97,109,101]
theorem mutated_kd3_3 : stringBytes linear_k3_3 = true := by decide +kernel
theorem mutated_kp3_3 (tail : List Nat) : parseStringTail (linear_k3_3 ++ (34 :: 58 :: tail)) [] = some (linear_k3_3, 58 :: tail) := by rfl
def linear_k3_4 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd3_4 : stringBytes linear_k3_4 = true := by decide +kernel
theorem mutated_kp3_4 (tail : List Nat) : parseStringTail (linear_k3_4 ++ (34 :: 58 :: tail)) [] = some (linear_k3_4, 58 :: tail) := by rfl
def linear_k3_5 : List Nat := [114,101,116,117,114,110,115]
theorem mutated_kd3_5 : stringBytes linear_k3_5 = true := by decide +kernel
theorem mutated_kp3_5 (tail : List Nat) : parseStringTail (linear_k3_5 ++ (34 :: 58 :: tail)) [] = some (linear_k3_5, 58 :: tail) := by rfl
def linear_l3_5 : List (List Nat × Raw) := [(linear_k3_5, linear_r154)]
def linear_v3_5 : List Nat := linear_g396 ++ linear_b154
theorem mutated_sl3_5 : serializeFields 4085 29 linear_l3_5 = some linear_v3_5 := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4084 29 linear_k3_5 linear_r154 linear_b154 mutated_kd3_5 mutated_s154)
theorem mutated_pl3_5 (tail : List Nat) : parseFields 4085 29 (linear_v3_5 ++ (125 :: tail)) = some (linear_l3_5, tail) := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4084 29 (linear_k3_5 ++ (34 :: 58 :: (linear_b154 ++ (125 :: tail)))) linear_k3_5 (linear_b154 ++ (125 :: tail)) tail linear_r154 (mutated_kp3_5 (linear_b154 ++ (125 :: tail))) (mutated_p154 (125 :: tail)))
def linear_l3_4 : List (List Nat × Raw) := (linear_k3_4, linear_r153) :: linear_l3_5
def linear_v3_4 : List Nat := (linear_g393 ++ linear_b153) ++ (44 :: linear_v3_5)
theorem mutated_sl3_4 : serializeFields 4086 29 linear_l3_4 = some linear_v3_4 := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 29 linear_k3_4 linear_r153 (linear_k3_5, linear_r154) [] linear_b153 linear_v3_5 mutated_kd3_4 mutated_s153 mutated_sl3_5)
theorem mutated_pl3_4 (tail : List Nat) : parseFields 4086 29 (linear_v3_4 ++ (125 :: tail)) = some (linear_l3_4, tail) := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 29 (linear_k3_4 ++ (34 :: 58 :: (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))))) linear_k3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))) (linear_v3_5 ++ (125 :: tail)) tail linear_r153 linear_l3_5 (mutated_kp3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail))))) (mutated_p153 (44 :: (linear_v3_5 ++ (125 :: tail)))) (mutated_pl3_5 tail))
def linear_l3_3 : List (List Nat × Raw) := (linear_k3_3, linear_r152) :: linear_l3_4
def linear_v3_3 : List Nat := (linear_g390 ++ linear_b152) ++ (44 :: linear_v3_4)
theorem mutated_sl3_3 : serializeFields 4087 29 linear_l3_3 = some linear_v3_3 := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4086 29 linear_k3_3 linear_r152 (linear_k3_4, linear_r153) linear_l3_5 linear_b152 linear_v3_4 mutated_kd3_3 mutated_s152 mutated_sl3_4)
theorem mutated_pl3_3 (tail : List Nat) : parseFields 4087 29 (linear_v3_3 ++ (125 :: tail)) = some (linear_l3_3, tail) := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4086 29 (linear_k3_3 ++ (34 :: 58 :: (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))))) linear_k3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))) (linear_v3_4 ++ (125 :: tail)) tail linear_r152 linear_l3_4 (mutated_kp3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail))))) (mutated_p152 (44 :: (linear_v3_4 ++ (125 :: tail)))) (mutated_pl3_4 tail))
def linear_l3_2 : List (List Nat × Raw) := (linear_k3_2, linear_r151) :: linear_l3_3
def linear_v3_2 : List Nat := (linear_g387 ++ linear_b151) ++ (44 :: linear_v3_3)
theorem mutated_sl3_2 : serializeFields 4088 29 linear_l3_2 = some linear_v3_2 := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4087 29 linear_k3_2 linear_r151 (linear_k3_3, linear_r152) linear_l3_4 linear_b151 linear_v3_3 mutated_kd3_2 mutated_s151 mutated_sl3_3)
theorem mutated_pl3_2 (tail : List Nat) : parseFields 4088 29 (linear_v3_2 ++ (125 :: tail)) = some (linear_l3_2, tail) := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4087 29 (linear_k3_2 ++ (34 :: 58 :: (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))))) linear_k3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))) (linear_v3_3 ++ (125 :: tail)) tail linear_r151 linear_l3_3 (mutated_kp3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail))))) (mutated_p151 (44 :: (linear_v3_3 ++ (125 :: tail)))) (mutated_pl3_3 tail))
def linear_l3_1 : List (List Nat × Raw) := (linear_k3_1, linear_r150) :: linear_l3_2
def linear_v3_1 : List Nat := (linear_g384 ++ linear_b150) ++ (44 :: linear_v3_2)
theorem mutated_sl3_1 : serializeFields 4089 29 linear_l3_1 = some linear_v3_1 := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4088 29 linear_k3_1 linear_r150 (linear_k3_2, linear_r151) linear_l3_3 linear_b150 linear_v3_2 mutated_kd3_1 mutated_s150 mutated_sl3_2)
theorem mutated_pl3_1 (tail : List Nat) : parseFields 4089 29 (linear_v3_1 ++ (125 :: tail)) = some (linear_l3_1, tail) := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4088 29 (linear_k3_1 ++ (34 :: 58 :: (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))))) linear_k3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))) (linear_v3_2 ++ (125 :: tail)) tail linear_r150 linear_l3_2 (mutated_kp3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail))))) (mutated_p150 (44 :: (linear_v3_2 ++ (125 :: tail)))) (mutated_pl3_2 tail))
def linear_l3_0 : List (List Nat × Raw) := (linear_k3_0, linear_r4) :: linear_l3_1
def linear_v3_0 : List Nat := (linear_g7 ++ linear_b4) ++ (44 :: linear_v3_1)
theorem mutated_sl3_0 : serializeFields 4090 29 linear_l3_0 = some linear_v3_0 := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4089 29 linear_k3_0 linear_r4 (linear_k3_1, linear_r150) linear_l3_2 linear_b4 linear_v3_1 mutated_kd3_0 mutated_s4 mutated_sl3_1)
theorem mutated_pl3_0 (tail : List Nat) : parseFields 4090 29 (linear_v3_0 ++ (125 :: tail)) = some (linear_l3_0, tail) := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4089 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) linear_k3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))) (linear_v3_1 ++ (125 :: tail)) tail linear_r4 linear_l3_1 (mutated_kp3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail))))) (mutated_p4 (44 :: (linear_v3_1 ++ (125 :: tail)))) (mutated_pl3_1 tail))
def linear_r3 : Raw := (.obj linear_l3_0)
def linear_b3 : List Nat := linear_g6 ++ (linear_v3_0 ++ linear_g398)
theorem mutated_o3 : orderedFields linear_l3_0 = true := by decide +kernel
theorem mutated_s3 : serializeRaw 4091 30 linear_r3 = some linear_b3 := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4090 29 linear_l3_0 linear_v3_0 mutated_o3 mutated_sl3_0)
theorem mutated_p3 (tail : List Nat) : parseRaw 4091 30 (linear_b3 ++ tail) = some (linear_r3, tail) := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4090 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) tail linear_l3_0 mutated_o3 (by simpa only [linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl3_0 tail)))
def linear_l2_0 : List Raw := [linear_r3]
def linear_v2_0 : List Nat := linear_b3
theorem mutated_sl2_0 : serializeItems 4092 30 linear_l2_0 = some linear_v2_0 := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4091 30 linear_r3 linear_b3 mutated_s3)
theorem mutated_pl2_0 (tail : List Nat) : parseItems 4092 30 (linear_v2_0 ++ (93 :: tail)) = some (linear_l2_0, tail) := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4091 30 (linear_b3 ++ (93 :: tail)) tail linear_r3 (mutated_p3 (93 :: tail)))
def linear_r2 : Raw := (.arr linear_l2_0)
def linear_b2 : List Nat := linear_g5 ++ (linear_v2_0 ++ linear_g399)
theorem mutated_s2 : serializeRaw 4093 31 linear_r2 = some linear_b2 := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4092 30 linear_l2_0 linear_v2_0 mutated_sl2_0)
theorem mutated_p2 (tail : List Nat) : parseRaw 4093 31 (linear_b2 ++ tail) = some (linear_r2, tail) := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4092 30 (linear_v2_0 ++ (93 :: tail)) tail linear_l2_0 (by intro h; cases h) (mutated_pl2_0 tail))
def linear_r155 : Raw := (.str [114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114])
def linear_b155 : List Nat := linear_g402
theorem mutated_s155 : serializeRaw 4092 31 linear_r155 = some linear_b155 := by decide +kernel
theorem mutated_p155 (tail : List Nat) : parseRaw 4092 31 (linear_b155 ++ tail) = some (linear_r155, tail) := by rfl
def linear_r156 : Raw := (.str [104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49])
def linear_b156 : List Nat := linear_g405
theorem mutated_s156 : serializeRaw 4091 31 linear_r156 = some linear_b156 := by decide +kernel
theorem mutated_p156 (tail : List Nat) : parseRaw 4091 31 (linear_b156 ++ tail) = some (linear_r156, tail) := by rfl
def linear_k0_0 : List Nat := [101,120,112,111,114,116,115]
theorem mutated_kd0_0 : stringBytes linear_k0_0 = true := by decide +kernel
theorem mutated_kp0_0 (tail : List Nat) : parseStringTail (linear_k0_0 ++ (34 :: 58 :: tail)) [] = some (linear_k0_0, 58 :: tail) := by rfl
def linear_k0_1 : List Nat := [102,117,110,99,116,105,111,110,115]
theorem mutated_kd0_1 : stringBytes linear_k0_1 = true := by decide +kernel
theorem mutated_kp0_1 (tail : List Nat) : parseStringTail (linear_k0_1 ++ (34 :: 58 :: tail)) [] = some (linear_k0_1, 58 :: tail) := by rfl
def linear_k0_2 : List Nat := [109,111,100,117,108,101]
theorem mutated_kd0_2 : stringBytes linear_k0_2 = true := by decide +kernel
theorem mutated_kp0_2 (tail : List Nat) : parseStringTail (linear_k0_2 ++ (34 :: 58 :: tail)) [] = some (linear_k0_2, 58 :: tail) := by rfl
def linear_k0_3 : List Nat := [115,99,104,101,109,97]
theorem mutated_kd0_3 : stringBytes linear_k0_3 = true := by decide +kernel
theorem mutated_kp0_3 (tail : List Nat) : parseStringTail (linear_k0_3 ++ (34 :: 58 :: tail)) [] = some (linear_k0_3, 58 :: tail) := by rfl
def linear_l0_3 : List (List Nat × Raw) := [(linear_k0_3, linear_r156)]
def linear_v0_3 : List Nat := linear_g404 ++ linear_b156
theorem mutated_sl0_3 : serializeFields 4092 31 linear_l0_3 = some linear_v0_3 := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4091 31 linear_k0_3 linear_r156 linear_b156 mutated_kd0_3 mutated_s156)
theorem mutated_pl0_3 (tail : List Nat) : parseFields 4092 31 (linear_v0_3 ++ (125 :: tail)) = some (linear_l0_3, tail) := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4091 31 (linear_k0_3 ++ (34 :: 58 :: (linear_b156 ++ (125 :: tail)))) linear_k0_3 (linear_b156 ++ (125 :: tail)) tail linear_r156 (mutated_kp0_3 (linear_b156 ++ (125 :: tail))) (mutated_p156 (125 :: tail)))
def linear_l0_2 : List (List Nat × Raw) := (linear_k0_2, linear_r155) :: linear_l0_3
def linear_v0_2 : List Nat := (linear_g401 ++ linear_b155) ++ (44 :: linear_v0_3)
theorem mutated_sl0_2 : serializeFields 4093 31 linear_l0_2 = some linear_v0_2 := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4092 31 linear_k0_2 linear_r155 (linear_k0_3, linear_r156) [] linear_b155 linear_v0_3 mutated_kd0_2 mutated_s155 mutated_sl0_3)
theorem mutated_pl0_2 (tail : List Nat) : parseFields 4093 31 (linear_v0_2 ++ (125 :: tail)) = some (linear_l0_2, tail) := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4092 31 (linear_k0_2 ++ (34 :: 58 :: (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))))) linear_k0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))) (linear_v0_3 ++ (125 :: tail)) tail linear_r155 linear_l0_3 (mutated_kp0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail))))) (mutated_p155 (44 :: (linear_v0_3 ++ (125 :: tail)))) (mutated_pl0_3 tail))
def linear_l0_1 : List (List Nat × Raw) := (linear_k0_1, linear_r2) :: linear_l0_2
def linear_v0_1 : List Nat := (linear_g4 ++ linear_b2) ++ (44 :: linear_v0_2)
theorem mutated_sl0_1 : serializeFields 4094 31 linear_l0_1 = some linear_v0_1 := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4093 31 linear_k0_1 linear_r2 (linear_k0_2, linear_r155) linear_l0_3 linear_b2 linear_v0_2 mutated_kd0_1 mutated_s2 mutated_sl0_2)
theorem mutated_pl0_1 (tail : List Nat) : parseFields 4094 31 (linear_v0_1 ++ (125 :: tail)) = some (linear_l0_1, tail) := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4093 31 (linear_k0_1 ++ (34 :: 58 :: (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))))) linear_k0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))) (linear_v0_2 ++ (125 :: tail)) tail linear_r2 linear_l0_2 (mutated_kp0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail))))) (mutated_p2 (44 :: (linear_v0_2 ++ (125 :: tail)))) (mutated_pl0_2 tail))
def linear_l0_0 : List (List Nat × Raw) := (linear_k0_0, linear_r1) :: linear_l0_1
def linear_v0_0 : List Nat := (linear_g1 ++ linear_b1) ++ (44 :: linear_v0_1)
theorem mutated_sl0_0 : serializeFields 4095 31 linear_l0_0 = some linear_v0_0 := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4094 31 linear_k0_0 linear_r1 (linear_k0_1, linear_r2) linear_l0_2 linear_b1 linear_v0_1 mutated_kd0_0 mutated_s1 mutated_sl0_1)
theorem mutated_pl0_0 (tail : List Nat) : parseFields 4095 31 (linear_v0_0 ++ (125 :: tail)) = some (linear_l0_0, tail) := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4094 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) linear_k0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))) (linear_v0_1 ++ (125 :: tail)) tail linear_r1 linear_l0_1 (mutated_kp0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail))))) (mutated_p1 (44 :: (linear_v0_1 ++ (125 :: tail)))) (mutated_pl0_1 tail))
def linear_r0 : Raw := (.obj linear_l0_0)
def linear_b0 : List Nat := linear_g0 ++ (linear_v0_0 ++ linear_g406)
theorem mutated_o0 : orderedFields linear_l0_0 = true := by decide +kernel
theorem mutated_s0 : serializeRaw 4096 32 linear_r0 = some linear_b0 := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4095 31 linear_l0_0 linear_v0_0 mutated_o0 mutated_sl0_0)
theorem mutated_p0 (tail : List Nat) : parseRaw 4096 32 (linear_b0 ++ tail) = some (linear_r0, tail) := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4095 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) tail linear_l0_0 mutated_o0 (by simpa only [linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl0_0 tail)))
def linearRaw : Raw := linear_r0
def linearBytes : List Nat := linear_b0
theorem mutated_bounds : withinBounds linearRaw = true := by decide +kernel
theorem mutated_serialized : serializeRaw transportFuel transportDepth linearRaw = some linearBytes := by exact mutated_s0
theorem mutated_parsed : parseRaw transportFuel transportDepth linearBytes = some (linearRaw, []) := by
  simpa only [List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_p0 [])
theorem mutated_length : linearBytes.length ≤ transportByteLimit := by decide +kernel
theorem mutated_byte_range : linearBytes.all (fun byte => decide (byte ≤ 255)) = true := by decide +kernel
theorem mutated_transport : checkedEncode linearRaw = some linearBytes := checkedEncode_of_parts linearRaw linearBytes mutated_bounds mutated_serialized mutated_parsed mutated_length mutated_byte_range
end HiaCoreSyntaxSlice.WrongPhi
namespace HiaCoreSyntaxSlice.LiteralTwo
def linear_g0 : List Nat := [123]
def linear_g1 : List Nat := [34,101,120,112,111,114,116,115,34,58]
def linear_g2 : List Nat := [91,34,99,97,108,99,117,108,97,116,101,34,93]
def linear_g3 : List Nat := [44]
def linear_g4 : List Nat := [34,102,117,110,99,116,105,111,110,115,34,58]
def linear_g5 : List Nat := [91]
def linear_g6 : List Nat := [123]
def linear_g7 : List Nat := [34,98,108,111,99,107,115,34,58]
def linear_g8 : List Nat := [91]
def linear_g9 : List Nat := [123]
def linear_g10 : List Nat := [34,105,100,34,58]
def linear_g11 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g12 : List Nat := [44]
def linear_g13 : List Nat := [34,111,112,115,34,58]
def linear_g14 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,116,114,121,95,110,101,119,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,93]
def linear_g15 : List Nat := [44]
def linear_g16 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g17 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g18 : List Nat := [44]
def linear_g19 : List Nat := [34,116,101,114,109,34,58]
def linear_g20 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,125,125]
def linear_g21 : List Nat := [125]
def linear_g22 : List Nat := [44]
def linear_g23 : List Nat := [123]
def linear_g24 : List Nat := [34,105,100,34,58]
def linear_g25 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,49,34]
def linear_g26 : List Nat := [44]
def linear_g27 : List Nat := [34,111,112,115,34,58]
def linear_g28 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g29 : List Nat := [44]
def linear_g30 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g31 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g32 : List Nat := [44]
def linear_g33 : List Nat := [34,116,101,114,109,34,58]
def linear_g34 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,52,34,44,34,100,103,95,118,95,56,34,44,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,57,34,44,34,100,103,95,118,95,49,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,125]
def linear_g35 : List Nat := [125]
def linear_g36 : List Nat := [44]
def linear_g37 : List Nat := [123]
def linear_g38 : List Nat := [34,105,100,34,58]
def linear_g39 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,50,34]
def linear_g40 : List Nat := [44]
def linear_g41 : List Nat := [34,111,112,115,34,58]
def linear_g42 : List Nat := [91]
def linear_g43 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125]
def linear_g44 : List Nat := [44]
def linear_g45 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,48,48,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g46 : List Nat := [44]
def linear_g47 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g48 : List Nat := [44]
def linear_g49 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,34,44,34,100,103,95,118,95,49,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g50 : List Nat := [93]
def linear_g51 : List Nat := [44]
def linear_g52 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g53 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g54 : List Nat := [44]
def linear_g55 : List Nat := [34,116,101,114,109,34,58]
def linear_g56 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,56,34,93,125]
def linear_g57 : List Nat := [125]
def linear_g58 : List Nat := [44]
def linear_g59 : List Nat := [123]
def linear_g60 : List Nat := [34,105,100,34,58]
def linear_g61 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,51,34]
def linear_g62 : List Nat := [44]
def linear_g63 : List Nat := [34,111,112,115,34,58]
def linear_g64 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g65 : List Nat := [44]
def linear_g66 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g67 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g68 : List Nat := [44]
def linear_g69 : List Nat := [34,116,101,114,109,34,58]
def linear_g70 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,50,53,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,48,34,125,125]
def linear_g71 : List Nat := [125]
def linear_g72 : List Nat := [44]
def linear_g73 : List Nat := [123]
def linear_g74 : List Nat := [34,105,100,34,58]
def linear_g75 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,52,34]
def linear_g76 : List Nat := [44]
def linear_g77 : List Nat := [34,111,112,115,34,58]
def linear_g78 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,50,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g79 : List Nat := [44]
def linear_g80 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g81 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g82 : List Nat := [44]
def linear_g83 : List Nat := [34,116,101,114,109,34,58]
def linear_g84 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,50,56,34,44,34,100,103,95,118,95,50,57,34,44,34,100,103,95,118,95,51,50,34,44,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,51,51,34,44,34,100,103,95,118,95,51,52,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,125]
def linear_g85 : List Nat := [125]
def linear_g86 : List Nat := [44]
def linear_g87 : List Nat := [123]
def linear_g88 : List Nat := [34,105,100,34,58]
def linear_g89 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,53,34]
def linear_g90 : List Nat := [44]
def linear_g91 : List Nat := [34,111,112,115,34,58]
def linear_g92 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,51,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g93 : List Nat := [44]
def linear_g94 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g95 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g96 : List Nat := [44]
def linear_g97 : List Nat := [34,116,101,114,109,34,58]
def linear_g98 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,52,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,49,34,125,125]
def linear_g99 : List Nat := [125]
def linear_g100 : List Nat := [44]
def linear_g101 : List Nat := [123]
def linear_g102 : List Nat := [34,105,100,34,58]
def linear_g103 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,54,34]
def linear_g104 : List Nat := [44]
def linear_g105 : List Nat := [34,111,112,115,34,58]
def linear_g106 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g107 : List Nat := [44]
def linear_g108 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g109 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,53,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g110 : List Nat := [44]
def linear_g111 : List Nat := [34,116,101,114,109,34,58]
def linear_g112 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,52,54,34,93,125]
def linear_g113 : List Nat := [125]
def linear_g114 : List Nat := [44]
def linear_g115 : List Nat := [123]
def linear_g116 : List Nat := [34,105,100,34,58]
def linear_g117 : List Nat := [34,100,103,95,102,97,115,116,95,48,34]
def linear_g118 : List Nat := [44]
def linear_g119 : List Nat := [34,111,112,115,34,58]
def linear_g120 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,54,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g121 : List Nat := [44]
def linear_g122 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g123 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g124 : List Nat := [44]
def linear_g125 : List Nat := [34,116,101,114,109,34,58]
def linear_g126 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,53,54,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g127 : List Nat := [125]
def linear_g128 : List Nat := [44]
def linear_g129 : List Nat := [123]
def linear_g130 : List Nat := [34,105,100,34,58]
def linear_g131 : List Nat := [34,100,103,95,102,97,115,116,95,49,34]
def linear_g132 : List Nat := [44]
def linear_g133 : List Nat := [34,111,112,115,34,58]
def linear_g134 : List Nat := [91]
def linear_g135 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g136 : List Nat := [44]
def linear_g137 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,50,34,44,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,51,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g138 : List Nat := [44]
def linear_g139 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,52,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g140 : List Nat := [44]
def linear_g141 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g142 : List Nat := [44]
def linear_g143 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,52,34,44,34,100,103,95,118,95,54,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,54,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g144 : List Nat := [44]
def linear_g145 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,54,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g146 : List Nat := [44]
def linear_g147 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,56,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g148 : List Nat := [44]
def linear_g149 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,44,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g150 : List Nat := [44]
def linear_g151 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g152 : List Nat := [44]
def linear_g153 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,50,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g154 : List Nat := [44]
def linear_g155 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g156 : List Nat := [93]
def linear_g157 : List Nat := [44]
def linear_g158 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g159 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g160 : List Nat := [44]
def linear_g161 : List Nat := [34,116,101,114,109,34,58]
def linear_g162 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,55,34,44,34,100,103,95,118,95,53,56,34,44,34,100,103,95,118,95,53,57,34,44,34,100,103,95,118,95,54,48,34,44,34,100,103,95,118,95,55,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,48,34,125]
def linear_g163 : List Nat := [125]
def linear_g164 : List Nat := [44]
def linear_g165 : List Nat := [123]
def linear_g166 : List Nat := [34,105,100,34,58]
def linear_g167 : List Nat := [34,100,103,95,102,97,115,116,95,50,34]
def linear_g168 : List Nat := [44]
def linear_g169 : List Nat := [34,111,112,115,34,58]
def linear_g170 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g171 : List Nat := [44]
def linear_g172 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g173 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g174 : List Nat := [44]
def linear_g175 : List Nat := [34,116,101,114,109,34,58]
def linear_g176 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,50,34,44,34,100,103,95,118,95,55,51,34,44,34,100,103,95,118,95,55,54,34,44,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,55,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g177 : List Nat := [125]
def linear_g178 : List Nat := [44]
def linear_g179 : List Nat := [123]
def linear_g180 : List Nat := [34,105,100,34,58]
def linear_g181 : List Nat := [34,100,103,95,102,97,115,116,95,51,34]
def linear_g182 : List Nat := [44]
def linear_g183 : List Nat := [34,111,112,115,34,58]
def linear_g184 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,51,34,44,34,100,103,95,118,95,56,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g185 : List Nat := [44]
def linear_g186 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g187 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g188 : List Nat := [44]
def linear_g189 : List Nat := [34,116,101,114,109,34,58]
def linear_g190 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,56,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g191 : List Nat := [125]
def linear_g192 : List Nat := [44]
def linear_g193 : List Nat := [123]
def linear_g194 : List Nat := [34,105,100,34,58]
def linear_g195 : List Nat := [34,100,103,95,102,97,115,116,95,52,34]
def linear_g196 : List Nat := [44]
def linear_g197 : List Nat := [34,111,112,115,34,58]
def linear_g198 : List Nat := [91]
def linear_g199 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,49,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g200 : List Nat := [44]
def linear_g201 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,44,34,100,103,95,118,95,57,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g202 : List Nat := [44]
def linear_g203 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g204 : List Nat := [44]
def linear_g205 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,50,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g206 : List Nat := [44]
def linear_g207 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,56,34,44,34,100,103,95,118,95,57,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g208 : List Nat := [44]
def linear_g209 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g210 : List Nat := [44]
def linear_g211 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,48,34,44,34,100,103,95,118,95,57,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g212 : List Nat := [93]
def linear_g213 : List Nat := [44]
def linear_g214 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g215 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g216 : List Nat := [44]
def linear_g217 : List Nat := [34,116,101,114,109,34,58]
def linear_g218 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,53,34,44,34,100,103,95,118,95,56,54,34,44,34,100,103,95,118,95,56,55,34,44,34,100,103,95,118,95,57,52,34,44,34,100,103,95,118,95,56,57,34,44,34,100,103,95,118,95,57,54,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g219 : List Nat := [125]
def linear_g220 : List Nat := [44]
def linear_g221 : List Nat := [123]
def linear_g222 : List Nat := [34,105,100,34,58]
def linear_g223 : List Nat := [34,100,103,95,102,97,115,116,95,53,34]
def linear_g224 : List Nat := [44]
def linear_g225 : List Nat := [34,111,112,115,34,58]
def linear_g226 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g227 : List Nat := [44]
def linear_g228 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g229 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,48,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g230 : List Nat := [44]
def linear_g231 : List Nat := [34,116,101,114,109,34,58]
def linear_g232 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,48,48,34,93,125]
def linear_g233 : List Nat := [125]
def linear_g234 : List Nat := [44]
def linear_g235 : List Nat := [123]
def linear_g236 : List Nat := [34,105,100,34,58]
def linear_g237 : List Nat := [34,100,103,95,115,108,111,119,95,48,34]
def linear_g238 : List Nat := [44]
def linear_g239 : List Nat := [34,111,112,115,34,58]
def linear_g240 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,56,34,44,34,100,103,95,118,95,49,48,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,57,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g241 : List Nat := [44]
def linear_g242 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g243 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g244 : List Nat := [44]
def linear_g245 : List Nat := [34,116,101,114,109,34,58]
def linear_g246 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,48,57,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,125]
def linear_g247 : List Nat := [125]
def linear_g248 : List Nat := [44]
def linear_g249 : List Nat := [123]
def linear_g250 : List Nat := [34,105,100,34,58]
def linear_g251 : List Nat := [34,100,103,95,115,108,111,119,95,49,34]
def linear_g252 : List Nat := [44]
def linear_g253 : List Nat := [34,111,112,115,34,58]
def linear_g254 : List Nat := [91]
def linear_g255 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g256 : List Nat := [44]
def linear_g257 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,53,34,44,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g258 : List Nat := [44]
def linear_g259 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g260 : List Nat := [44]
def linear_g261 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,56,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g262 : List Nat := [44]
def linear_g263 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,55,34,44,34,100,103,95,118,95,49,49,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,57,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g264 : List Nat := [44]
def linear_g265 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,57,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,48,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g266 : List Nat := [44]
def linear_g267 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,49,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g268 : List Nat := [44]
def linear_g269 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,44,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g270 : List Nat := [44]
def linear_g271 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g272 : List Nat := [44]
def linear_g273 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g274 : List Nat := [44]
def linear_g275 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g276 : List Nat := [93]
def linear_g277 : List Nat := [44]
def linear_g278 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g279 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g280 : List Nat := [44]
def linear_g281 : List Nat := [34,116,101,114,109,34,58]
def linear_g282 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,48,34,44,34,100,103,95,118,95,49,49,49,34,44,34,100,103,95,118,95,49,49,50,34,44,34,100,103,95,118,95,49,49,51,34,44,34,100,103,95,118,95,49,50,51,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,48,34,125]
def linear_g283 : List Nat := [125]
def linear_g284 : List Nat := [44]
def linear_g285 : List Nat := [123]
def linear_g286 : List Nat := [34,105,100,34,58]
def linear_g287 : List Nat := [34,100,103,95,115,108,111,119,95,50,34]
def linear_g288 : List Nat := [44]
def linear_g289 : List Nat := [34,111,112,115,34,58]
def linear_g290 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,57,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g291 : List Nat := [44]
def linear_g292 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g293 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g294 : List Nat := [44]
def linear_g295 : List Nat := [34,116,101,114,109,34,58]
def linear_g296 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,50,53,34,44,34,100,103,95,118,95,49,50,54,34,44,34,100,103,95,118,95,49,50,57,34,44,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,51,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g297 : List Nat := [125]
def linear_g298 : List Nat := [44]
def linear_g299 : List Nat := [123]
def linear_g300 : List Nat := [34,105,100,34,58]
def linear_g301 : List Nat := [34,100,103,95,115,108,111,119,95,51,34]
def linear_g302 : List Nat := [44]
def linear_g303 : List Nat := [34,111,112,115,34,58]
def linear_g304 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,54,34,44,34,100,103,95,118,95,49,51,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,55,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g305 : List Nat := [44]
def linear_g306 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g307 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g308 : List Nat := [44]
def linear_g309 : List Nat := [34,116,101,114,109,34,58]
def linear_g310 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,51,55,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,125]
def linear_g311 : List Nat := [125]
def linear_g312 : List Nat := [44]
def linear_g313 : List Nat := [123]
def linear_g314 : List Nat := [34,105,100,34,58]
def linear_g315 : List Nat := [34,100,103,95,115,108,111,119,95,52,34]
def linear_g316 : List Nat := [44]
def linear_g317 : List Nat := [34,111,112,115,34,58]
def linear_g318 : List Nat := [91]
def linear_g319 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,52,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g320 : List Nat := [44]
def linear_g321 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,44,34,100,103,95,118,95,49,52,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g322 : List Nat := [44]
def linear_g323 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g324 : List Nat := [44]
def linear_g325 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g326 : List Nat := [44]
def linear_g327 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,49,34,44,34,100,103,95,118,95,49,52,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g328 : List Nat := [44]
def linear_g329 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g330 : List Nat := [44]
def linear_g331 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,51,34,44,34,100,103,95,118,95,49,52,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g332 : List Nat := [93]
def linear_g333 : List Nat := [44]
def linear_g334 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g335 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g336 : List Nat := [44]
def linear_g337 : List Nat := [34,116,101,114,109,34,58]
def linear_g338 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,56,34,44,34,100,103,95,118,95,49,51,57,34,44,34,100,103,95,118,95,49,52,48,34,44,34,100,103,95,118,95,49,52,55,34,44,34,100,103,95,118,95,49,52,50,34,44,34,100,103,95,118,95,49,52,57,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g339 : List Nat := [125]
def linear_g340 : List Nat := [44]
def linear_g341 : List Nat := [123]
def linear_g342 : List Nat := [34,105,100,34,58]
def linear_g343 : List Nat := [34,100,103,95,115,108,111,119,95,53,34]
def linear_g344 : List Nat := [44]
def linear_g345 : List Nat := [34,111,112,115,34,58]
def linear_g346 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g347 : List Nat := [44]
def linear_g348 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g349 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g350 : List Nat := [44]
def linear_g351 : List Nat := [34,116,101,114,109,34,58]
def linear_g352 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,53,51,34,93,125]
def linear_g353 : List Nat := [125]
def linear_g354 : List Nat := [44]
def linear_g355 : List Nat := [123]
def linear_g356 : List Nat := [34,105,100,34,58]
def linear_g357 : List Nat := [34,100,103,95,103,117,97,114,100,95,48,34]
def linear_g358 : List Nat := [44]
def linear_g359 : List Nat := [34,111,112,115,34,58]
def linear_g360 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,50,34,44,34,100,103,95,118,95,49,54,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g361 : List Nat := [44]
def linear_g362 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g363 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g364 : List Nat := [44]
def linear_g365 : List Nat := [34,116,101,114,109,34,58]
def linear_g366 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,54,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g367 : List Nat := [125]
def linear_g368 : List Nat := [44]
def linear_g369 : List Nat := [123]
def linear_g370 : List Nat := [34,105,100,34,58]
def linear_g371 : List Nat := [34,100,103,95,103,117,97,114,100,95,49,34]
def linear_g372 : List Nat := [44]
def linear_g373 : List Nat := [34,111,112,115,34,58]
def linear_g374 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,55,49,34,44,34,100,103,95,118,95,49,55,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g375 : List Nat := [44]
def linear_g376 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g377 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g378 : List Nat := [44]
def linear_g379 : List Nat := [34,116,101,114,109,34,58]
def linear_g380 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,55,51,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g381 : List Nat := [125]
def linear_g382 : List Nat := [93]
def linear_g383 : List Nat := [44]
def linear_g384 : List Nat := [34,101,102,102,101,99,116,115,34,58]
def linear_g385 : List Nat := [91,34,97,108,108,111,99,34,44,34,114,101,97,100,34,44,34,116,114,97,112,34,44,34,119,114,105,116,101,34,93]
def linear_g386 : List Nat := [44]
def linear_g387 : List Nat := [34,101,110,116,114,121,34,58]
def linear_g388 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g389 : List Nat := [44]
def linear_g390 : List Nat := [34,110,97,109,101,34,58]
def linear_g391 : List Nat := [34,99,97,108,99,117,108,97,116,101,34]
def linear_g392 : List Nat := [44]
def linear_g393 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g394 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g395 : List Nat := [44]
def linear_g396 : List Nat := [34,114,101,116,117,114,110,115,34,58]
def linear_g397 : List Nat := [91,34,117,54,52,34,93]
def linear_g398 : List Nat := [125]
def linear_g399 : List Nat := [93]
def linear_g400 : List Nat := [44]
def linear_g401 : List Nat := [34,109,111,100,117,108,101,34,58]
def linear_g402 : List Nat := [34,114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114,34]
def linear_g403 : List Nat := [44]
def linear_g404 : List Nat := [34,115,99,104,101,109,97,34,58]
def linear_g405 : List Nat := [34,104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49,34]
def linear_g406 : List Nat := [125]
def linear_t407 : List Nat := []
def linear_t406 : List Nat := linear_g406 ++ linear_t407
def linear_t405 : List Nat := linear_g405 ++ linear_t406
def linear_t404 : List Nat := linear_g404 ++ linear_t405
def linear_t403 : List Nat := linear_g403 ++ linear_t404
def linear_t402 : List Nat := linear_g402 ++ linear_t403
def linear_t401 : List Nat := linear_g401 ++ linear_t402
def linear_t400 : List Nat := linear_g400 ++ linear_t401
def linear_t399 : List Nat := linear_g399 ++ linear_t400
def linear_t398 : List Nat := linear_g398 ++ linear_t399
def linear_t397 : List Nat := linear_g397 ++ linear_t398
def linear_t396 : List Nat := linear_g396 ++ linear_t397
def linear_t395 : List Nat := linear_g395 ++ linear_t396
def linear_t394 : List Nat := linear_g394 ++ linear_t395
def linear_t393 : List Nat := linear_g393 ++ linear_t394
def linear_t392 : List Nat := linear_g392 ++ linear_t393
def linear_t391 : List Nat := linear_g391 ++ linear_t392
def linear_t390 : List Nat := linear_g390 ++ linear_t391
def linear_t389 : List Nat := linear_g389 ++ linear_t390
def linear_t388 : List Nat := linear_g388 ++ linear_t389
def linear_t387 : List Nat := linear_g387 ++ linear_t388
def linear_t386 : List Nat := linear_g386 ++ linear_t387
def linear_t385 : List Nat := linear_g385 ++ linear_t386
def linear_t384 : List Nat := linear_g384 ++ linear_t385
def linear_t383 : List Nat := linear_g383 ++ linear_t384
def linear_t382 : List Nat := linear_g382 ++ linear_t383
def linear_t381 : List Nat := linear_g381 ++ linear_t382
def linear_t380 : List Nat := linear_g380 ++ linear_t381
def linear_t379 : List Nat := linear_g379 ++ linear_t380
def linear_t378 : List Nat := linear_g378 ++ linear_t379
def linear_t377 : List Nat := linear_g377 ++ linear_t378
def linear_t376 : List Nat := linear_g376 ++ linear_t377
def linear_t375 : List Nat := linear_g375 ++ linear_t376
def linear_t374 : List Nat := linear_g374 ++ linear_t375
def linear_t373 : List Nat := linear_g373 ++ linear_t374
def linear_t372 : List Nat := linear_g372 ++ linear_t373
def linear_t371 : List Nat := linear_g371 ++ linear_t372
def linear_t370 : List Nat := linear_g370 ++ linear_t371
def linear_t369 : List Nat := linear_g369 ++ linear_t370
def linear_t368 : List Nat := linear_g368 ++ linear_t369
def linear_t367 : List Nat := linear_g367 ++ linear_t368
def linear_t366 : List Nat := linear_g366 ++ linear_t367
def linear_t365 : List Nat := linear_g365 ++ linear_t366
def linear_t364 : List Nat := linear_g364 ++ linear_t365
def linear_t363 : List Nat := linear_g363 ++ linear_t364
def linear_t362 : List Nat := linear_g362 ++ linear_t363
def linear_t361 : List Nat := linear_g361 ++ linear_t362
def linear_t360 : List Nat := linear_g360 ++ linear_t361
def linear_t359 : List Nat := linear_g359 ++ linear_t360
def linear_t358 : List Nat := linear_g358 ++ linear_t359
def linear_t357 : List Nat := linear_g357 ++ linear_t358
def linear_t356 : List Nat := linear_g356 ++ linear_t357
def linear_t355 : List Nat := linear_g355 ++ linear_t356
def linear_t354 : List Nat := linear_g354 ++ linear_t355
def linear_t353 : List Nat := linear_g353 ++ linear_t354
def linear_t352 : List Nat := linear_g352 ++ linear_t353
def linear_t351 : List Nat := linear_g351 ++ linear_t352
def linear_t350 : List Nat := linear_g350 ++ linear_t351
def linear_t349 : List Nat := linear_g349 ++ linear_t350
def linear_t348 : List Nat := linear_g348 ++ linear_t349
def linear_t347 : List Nat := linear_g347 ++ linear_t348
def linear_t346 : List Nat := linear_g346 ++ linear_t347
def linear_t345 : List Nat := linear_g345 ++ linear_t346
def linear_t344 : List Nat := linear_g344 ++ linear_t345
def linear_t343 : List Nat := linear_g343 ++ linear_t344
def linear_t342 : List Nat := linear_g342 ++ linear_t343
def linear_t341 : List Nat := linear_g341 ++ linear_t342
def linear_t340 : List Nat := linear_g340 ++ linear_t341
def linear_t339 : List Nat := linear_g339 ++ linear_t340
def linear_t338 : List Nat := linear_g338 ++ linear_t339
def linear_t337 : List Nat := linear_g337 ++ linear_t338
def linear_t336 : List Nat := linear_g336 ++ linear_t337
def linear_t335 : List Nat := linear_g335 ++ linear_t336
def linear_t334 : List Nat := linear_g334 ++ linear_t335
def linear_t333 : List Nat := linear_g333 ++ linear_t334
def linear_t332 : List Nat := linear_g332 ++ linear_t333
def linear_t331 : List Nat := linear_g331 ++ linear_t332
def linear_t330 : List Nat := linear_g330 ++ linear_t331
def linear_t329 : List Nat := linear_g329 ++ linear_t330
def linear_t328 : List Nat := linear_g328 ++ linear_t329
def linear_t327 : List Nat := linear_g327 ++ linear_t328
def linear_t326 : List Nat := linear_g326 ++ linear_t327
def linear_t325 : List Nat := linear_g325 ++ linear_t326
def linear_t324 : List Nat := linear_g324 ++ linear_t325
def linear_t323 : List Nat := linear_g323 ++ linear_t324
def linear_t322 : List Nat := linear_g322 ++ linear_t323
def linear_t321 : List Nat := linear_g321 ++ linear_t322
def linear_t320 : List Nat := linear_g320 ++ linear_t321
def linear_t319 : List Nat := linear_g319 ++ linear_t320
def linear_t318 : List Nat := linear_g318 ++ linear_t319
def linear_t317 : List Nat := linear_g317 ++ linear_t318
def linear_t316 : List Nat := linear_g316 ++ linear_t317
def linear_t315 : List Nat := linear_g315 ++ linear_t316
def linear_t314 : List Nat := linear_g314 ++ linear_t315
def linear_t313 : List Nat := linear_g313 ++ linear_t314
def linear_t312 : List Nat := linear_g312 ++ linear_t313
def linear_t311 : List Nat := linear_g311 ++ linear_t312
def linear_t310 : List Nat := linear_g310 ++ linear_t311
def linear_t309 : List Nat := linear_g309 ++ linear_t310
def linear_t308 : List Nat := linear_g308 ++ linear_t309
def linear_t307 : List Nat := linear_g307 ++ linear_t308
def linear_t306 : List Nat := linear_g306 ++ linear_t307
def linear_t305 : List Nat := linear_g305 ++ linear_t306
def linear_t304 : List Nat := linear_g304 ++ linear_t305
def linear_t303 : List Nat := linear_g303 ++ linear_t304
def linear_t302 : List Nat := linear_g302 ++ linear_t303
def linear_t301 : List Nat := linear_g301 ++ linear_t302
def linear_t300 : List Nat := linear_g300 ++ linear_t301
def linear_t299 : List Nat := linear_g299 ++ linear_t300
def linear_t298 : List Nat := linear_g298 ++ linear_t299
def linear_t297 : List Nat := linear_g297 ++ linear_t298
def linear_t296 : List Nat := linear_g296 ++ linear_t297
def linear_t295 : List Nat := linear_g295 ++ linear_t296
def linear_t294 : List Nat := linear_g294 ++ linear_t295
def linear_t293 : List Nat := linear_g293 ++ linear_t294
def linear_t292 : List Nat := linear_g292 ++ linear_t293
def linear_t291 : List Nat := linear_g291 ++ linear_t292
def linear_t290 : List Nat := linear_g290 ++ linear_t291
def linear_t289 : List Nat := linear_g289 ++ linear_t290
def linear_t288 : List Nat := linear_g288 ++ linear_t289
def linear_t287 : List Nat := linear_g287 ++ linear_t288
def linear_t286 : List Nat := linear_g286 ++ linear_t287
def linear_t285 : List Nat := linear_g285 ++ linear_t286
def linear_t284 : List Nat := linear_g284 ++ linear_t285
def linear_t283 : List Nat := linear_g283 ++ linear_t284
def linear_t282 : List Nat := linear_g282 ++ linear_t283
def linear_t281 : List Nat := linear_g281 ++ linear_t282
def linear_t280 : List Nat := linear_g280 ++ linear_t281
def linear_t279 : List Nat := linear_g279 ++ linear_t280
def linear_t278 : List Nat := linear_g278 ++ linear_t279
def linear_t277 : List Nat := linear_g277 ++ linear_t278
def linear_t276 : List Nat := linear_g276 ++ linear_t277
def linear_t275 : List Nat := linear_g275 ++ linear_t276
def linear_t274 : List Nat := linear_g274 ++ linear_t275
def linear_t273 : List Nat := linear_g273 ++ linear_t274
def linear_t272 : List Nat := linear_g272 ++ linear_t273
def linear_t271 : List Nat := linear_g271 ++ linear_t272
def linear_t270 : List Nat := linear_g270 ++ linear_t271
def linear_t269 : List Nat := linear_g269 ++ linear_t270
def linear_t268 : List Nat := linear_g268 ++ linear_t269
def linear_t267 : List Nat := linear_g267 ++ linear_t268
def linear_t266 : List Nat := linear_g266 ++ linear_t267
def linear_t265 : List Nat := linear_g265 ++ linear_t266
def linear_t264 : List Nat := linear_g264 ++ linear_t265
def linear_t263 : List Nat := linear_g263 ++ linear_t264
def linear_t262 : List Nat := linear_g262 ++ linear_t263
def linear_t261 : List Nat := linear_g261 ++ linear_t262
def linear_t260 : List Nat := linear_g260 ++ linear_t261
def linear_t259 : List Nat := linear_g259 ++ linear_t260
def linear_t258 : List Nat := linear_g258 ++ linear_t259
def linear_t257 : List Nat := linear_g257 ++ linear_t258
def linear_t256 : List Nat := linear_g256 ++ linear_t257
def linear_t255 : List Nat := linear_g255 ++ linear_t256
def linear_t254 : List Nat := linear_g254 ++ linear_t255
def linear_t253 : List Nat := linear_g253 ++ linear_t254
def linear_t252 : List Nat := linear_g252 ++ linear_t253
def linear_t251 : List Nat := linear_g251 ++ linear_t252
def linear_t250 : List Nat := linear_g250 ++ linear_t251
def linear_t249 : List Nat := linear_g249 ++ linear_t250
def linear_t248 : List Nat := linear_g248 ++ linear_t249
def linear_t247 : List Nat := linear_g247 ++ linear_t248
def linear_t246 : List Nat := linear_g246 ++ linear_t247
def linear_t245 : List Nat := linear_g245 ++ linear_t246
def linear_t244 : List Nat := linear_g244 ++ linear_t245
def linear_t243 : List Nat := linear_g243 ++ linear_t244
def linear_t242 : List Nat := linear_g242 ++ linear_t243
def linear_t241 : List Nat := linear_g241 ++ linear_t242
def linear_t240 : List Nat := linear_g240 ++ linear_t241
def linear_t239 : List Nat := linear_g239 ++ linear_t240
def linear_t238 : List Nat := linear_g238 ++ linear_t239
def linear_t237 : List Nat := linear_g237 ++ linear_t238
def linear_t236 : List Nat := linear_g236 ++ linear_t237
def linear_t235 : List Nat := linear_g235 ++ linear_t236
def linear_t234 : List Nat := linear_g234 ++ linear_t235
def linear_t233 : List Nat := linear_g233 ++ linear_t234
def linear_t232 : List Nat := linear_g232 ++ linear_t233
def linear_t231 : List Nat := linear_g231 ++ linear_t232
def linear_t230 : List Nat := linear_g230 ++ linear_t231
def linear_t229 : List Nat := linear_g229 ++ linear_t230
def linear_t228 : List Nat := linear_g228 ++ linear_t229
def linear_t227 : List Nat := linear_g227 ++ linear_t228
def linear_t226 : List Nat := linear_g226 ++ linear_t227
def linear_t225 : List Nat := linear_g225 ++ linear_t226
def linear_t224 : List Nat := linear_g224 ++ linear_t225
def linear_t223 : List Nat := linear_g223 ++ linear_t224
def linear_t222 : List Nat := linear_g222 ++ linear_t223
def linear_t221 : List Nat := linear_g221 ++ linear_t222
def linear_t220 : List Nat := linear_g220 ++ linear_t221
def linear_t219 : List Nat := linear_g219 ++ linear_t220
def linear_t218 : List Nat := linear_g218 ++ linear_t219
def linear_t217 : List Nat := linear_g217 ++ linear_t218
def linear_t216 : List Nat := linear_g216 ++ linear_t217
def linear_t215 : List Nat := linear_g215 ++ linear_t216
def linear_t214 : List Nat := linear_g214 ++ linear_t215
def linear_t213 : List Nat := linear_g213 ++ linear_t214
def linear_t212 : List Nat := linear_g212 ++ linear_t213
def linear_t211 : List Nat := linear_g211 ++ linear_t212
def linear_t210 : List Nat := linear_g210 ++ linear_t211
def linear_t209 : List Nat := linear_g209 ++ linear_t210
def linear_t208 : List Nat := linear_g208 ++ linear_t209
def linear_t207 : List Nat := linear_g207 ++ linear_t208
def linear_t206 : List Nat := linear_g206 ++ linear_t207
def linear_t205 : List Nat := linear_g205 ++ linear_t206
def linear_t204 : List Nat := linear_g204 ++ linear_t205
def linear_t203 : List Nat := linear_g203 ++ linear_t204
def linear_t202 : List Nat := linear_g202 ++ linear_t203
def linear_t201 : List Nat := linear_g201 ++ linear_t202
def linear_t200 : List Nat := linear_g200 ++ linear_t201
def linear_t199 : List Nat := linear_g199 ++ linear_t200
def linear_t198 : List Nat := linear_g198 ++ linear_t199
def linear_t197 : List Nat := linear_g197 ++ linear_t198
def linear_t196 : List Nat := linear_g196 ++ linear_t197
def linear_t195 : List Nat := linear_g195 ++ linear_t196
def linear_t194 : List Nat := linear_g194 ++ linear_t195
def linear_t193 : List Nat := linear_g193 ++ linear_t194
def linear_t192 : List Nat := linear_g192 ++ linear_t193
def linear_t191 : List Nat := linear_g191 ++ linear_t192
def linear_t190 : List Nat := linear_g190 ++ linear_t191
def linear_t189 : List Nat := linear_g189 ++ linear_t190
def linear_t188 : List Nat := linear_g188 ++ linear_t189
def linear_t187 : List Nat := linear_g187 ++ linear_t188
def linear_t186 : List Nat := linear_g186 ++ linear_t187
def linear_t185 : List Nat := linear_g185 ++ linear_t186
def linear_t184 : List Nat := linear_g184 ++ linear_t185
def linear_t183 : List Nat := linear_g183 ++ linear_t184
def linear_t182 : List Nat := linear_g182 ++ linear_t183
def linear_t181 : List Nat := linear_g181 ++ linear_t182
def linear_t180 : List Nat := linear_g180 ++ linear_t181
def linear_t179 : List Nat := linear_g179 ++ linear_t180
def linear_t178 : List Nat := linear_g178 ++ linear_t179
def linear_t177 : List Nat := linear_g177 ++ linear_t178
def linear_t176 : List Nat := linear_g176 ++ linear_t177
def linear_t175 : List Nat := linear_g175 ++ linear_t176
def linear_t174 : List Nat := linear_g174 ++ linear_t175
def linear_t173 : List Nat := linear_g173 ++ linear_t174
def linear_t172 : List Nat := linear_g172 ++ linear_t173
def linear_t171 : List Nat := linear_g171 ++ linear_t172
def linear_t170 : List Nat := linear_g170 ++ linear_t171
def linear_t169 : List Nat := linear_g169 ++ linear_t170
def linear_t168 : List Nat := linear_g168 ++ linear_t169
def linear_t167 : List Nat := linear_g167 ++ linear_t168
def linear_t166 : List Nat := linear_g166 ++ linear_t167
def linear_t165 : List Nat := linear_g165 ++ linear_t166
def linear_t164 : List Nat := linear_g164 ++ linear_t165
def linear_t163 : List Nat := linear_g163 ++ linear_t164
def linear_t162 : List Nat := linear_g162 ++ linear_t163
def linear_t161 : List Nat := linear_g161 ++ linear_t162
def linear_t160 : List Nat := linear_g160 ++ linear_t161
def linear_t159 : List Nat := linear_g159 ++ linear_t160
def linear_t158 : List Nat := linear_g158 ++ linear_t159
def linear_t157 : List Nat := linear_g157 ++ linear_t158
def linear_t156 : List Nat := linear_g156 ++ linear_t157
def linear_t155 : List Nat := linear_g155 ++ linear_t156
def linear_t154 : List Nat := linear_g154 ++ linear_t155
def linear_t153 : List Nat := linear_g153 ++ linear_t154
def linear_t152 : List Nat := linear_g152 ++ linear_t153
def linear_t151 : List Nat := linear_g151 ++ linear_t152
def linear_t150 : List Nat := linear_g150 ++ linear_t151
def linear_t149 : List Nat := linear_g149 ++ linear_t150
def linear_t148 : List Nat := linear_g148 ++ linear_t149
def linear_t147 : List Nat := linear_g147 ++ linear_t148
def linear_t146 : List Nat := linear_g146 ++ linear_t147
def linear_t145 : List Nat := linear_g145 ++ linear_t146
def linear_t144 : List Nat := linear_g144 ++ linear_t145
def linear_t143 : List Nat := linear_g143 ++ linear_t144
def linear_t142 : List Nat := linear_g142 ++ linear_t143
def linear_t141 : List Nat := linear_g141 ++ linear_t142
def linear_t140 : List Nat := linear_g140 ++ linear_t141
def linear_t139 : List Nat := linear_g139 ++ linear_t140
def linear_t138 : List Nat := linear_g138 ++ linear_t139
def linear_t137 : List Nat := linear_g137 ++ linear_t138
def linear_t136 : List Nat := linear_g136 ++ linear_t137
def linear_t135 : List Nat := linear_g135 ++ linear_t136
def linear_t134 : List Nat := linear_g134 ++ linear_t135
def linear_t133 : List Nat := linear_g133 ++ linear_t134
def linear_t132 : List Nat := linear_g132 ++ linear_t133
def linear_t131 : List Nat := linear_g131 ++ linear_t132
def linear_t130 : List Nat := linear_g130 ++ linear_t131
def linear_t129 : List Nat := linear_g129 ++ linear_t130
def linear_t128 : List Nat := linear_g128 ++ linear_t129
def linear_t127 : List Nat := linear_g127 ++ linear_t128
def linear_t126 : List Nat := linear_g126 ++ linear_t127
def linear_t125 : List Nat := linear_g125 ++ linear_t126
def linear_t124 : List Nat := linear_g124 ++ linear_t125
def linear_t123 : List Nat := linear_g123 ++ linear_t124
def linear_t122 : List Nat := linear_g122 ++ linear_t123
def linear_t121 : List Nat := linear_g121 ++ linear_t122
def linear_t120 : List Nat := linear_g120 ++ linear_t121
def linear_t119 : List Nat := linear_g119 ++ linear_t120
def linear_t118 : List Nat := linear_g118 ++ linear_t119
def linear_t117 : List Nat := linear_g117 ++ linear_t118
def linear_t116 : List Nat := linear_g116 ++ linear_t117
def linear_t115 : List Nat := linear_g115 ++ linear_t116
def linear_t114 : List Nat := linear_g114 ++ linear_t115
def linear_t113 : List Nat := linear_g113 ++ linear_t114
def linear_t112 : List Nat := linear_g112 ++ linear_t113
def linear_t111 : List Nat := linear_g111 ++ linear_t112
def linear_t110 : List Nat := linear_g110 ++ linear_t111
def linear_t109 : List Nat := linear_g109 ++ linear_t110
def linear_t108 : List Nat := linear_g108 ++ linear_t109
def linear_t107 : List Nat := linear_g107 ++ linear_t108
def linear_t106 : List Nat := linear_g106 ++ linear_t107
def linear_t105 : List Nat := linear_g105 ++ linear_t106
def linear_t104 : List Nat := linear_g104 ++ linear_t105
def linear_t103 : List Nat := linear_g103 ++ linear_t104
def linear_t102 : List Nat := linear_g102 ++ linear_t103
def linear_t101 : List Nat := linear_g101 ++ linear_t102
def linear_t100 : List Nat := linear_g100 ++ linear_t101
def linear_t99 : List Nat := linear_g99 ++ linear_t100
def linear_t98 : List Nat := linear_g98 ++ linear_t99
def linear_t97 : List Nat := linear_g97 ++ linear_t98
def linear_t96 : List Nat := linear_g96 ++ linear_t97
def linear_t95 : List Nat := linear_g95 ++ linear_t96
def linear_t94 : List Nat := linear_g94 ++ linear_t95
def linear_t93 : List Nat := linear_g93 ++ linear_t94
def linear_t92 : List Nat := linear_g92 ++ linear_t93
def linear_t91 : List Nat := linear_g91 ++ linear_t92
def linear_t90 : List Nat := linear_g90 ++ linear_t91
def linear_t89 : List Nat := linear_g89 ++ linear_t90
def linear_t88 : List Nat := linear_g88 ++ linear_t89
def linear_t87 : List Nat := linear_g87 ++ linear_t88
def linear_t86 : List Nat := linear_g86 ++ linear_t87
def linear_t85 : List Nat := linear_g85 ++ linear_t86
def linear_t84 : List Nat := linear_g84 ++ linear_t85
def linear_t83 : List Nat := linear_g83 ++ linear_t84
def linear_t82 : List Nat := linear_g82 ++ linear_t83
def linear_t81 : List Nat := linear_g81 ++ linear_t82
def linear_t80 : List Nat := linear_g80 ++ linear_t81
def linear_t79 : List Nat := linear_g79 ++ linear_t80
def linear_t78 : List Nat := linear_g78 ++ linear_t79
def linear_t77 : List Nat := linear_g77 ++ linear_t78
def linear_t76 : List Nat := linear_g76 ++ linear_t77
def linear_t75 : List Nat := linear_g75 ++ linear_t76
def linear_t74 : List Nat := linear_g74 ++ linear_t75
def linear_t73 : List Nat := linear_g73 ++ linear_t74
def linear_t72 : List Nat := linear_g72 ++ linear_t73
def linear_t71 : List Nat := linear_g71 ++ linear_t72
def linear_t70 : List Nat := linear_g70 ++ linear_t71
def linear_t69 : List Nat := linear_g69 ++ linear_t70
def linear_t68 : List Nat := linear_g68 ++ linear_t69
def linear_t67 : List Nat := linear_g67 ++ linear_t68
def linear_t66 : List Nat := linear_g66 ++ linear_t67
def linear_t65 : List Nat := linear_g65 ++ linear_t66
def linear_t64 : List Nat := linear_g64 ++ linear_t65
def linear_t63 : List Nat := linear_g63 ++ linear_t64
def linear_t62 : List Nat := linear_g62 ++ linear_t63
def linear_t61 : List Nat := linear_g61 ++ linear_t62
def linear_t60 : List Nat := linear_g60 ++ linear_t61
def linear_t59 : List Nat := linear_g59 ++ linear_t60
def linear_t58 : List Nat := linear_g58 ++ linear_t59
def linear_t57 : List Nat := linear_g57 ++ linear_t58
def linear_t56 : List Nat := linear_g56 ++ linear_t57
def linear_t55 : List Nat := linear_g55 ++ linear_t56
def linear_t54 : List Nat := linear_g54 ++ linear_t55
def linear_t53 : List Nat := linear_g53 ++ linear_t54
def linear_t52 : List Nat := linear_g52 ++ linear_t53
def linear_t51 : List Nat := linear_g51 ++ linear_t52
def linear_t50 : List Nat := linear_g50 ++ linear_t51
def linear_t49 : List Nat := linear_g49 ++ linear_t50
def linear_t48 : List Nat := linear_g48 ++ linear_t49
def linear_t47 : List Nat := linear_g47 ++ linear_t48
def linear_t46 : List Nat := linear_g46 ++ linear_t47
def linear_t45 : List Nat := linear_g45 ++ linear_t46
def linear_t44 : List Nat := linear_g44 ++ linear_t45
def linear_t43 : List Nat := linear_g43 ++ linear_t44
def linear_t42 : List Nat := linear_g42 ++ linear_t43
def linear_t41 : List Nat := linear_g41 ++ linear_t42
def linear_t40 : List Nat := linear_g40 ++ linear_t41
def linear_t39 : List Nat := linear_g39 ++ linear_t40
def linear_t38 : List Nat := linear_g38 ++ linear_t39
def linear_t37 : List Nat := linear_g37 ++ linear_t38
def linear_t36 : List Nat := linear_g36 ++ linear_t37
def linear_t35 : List Nat := linear_g35 ++ linear_t36
def linear_t34 : List Nat := linear_g34 ++ linear_t35
def linear_t33 : List Nat := linear_g33 ++ linear_t34
def linear_t32 : List Nat := linear_g32 ++ linear_t33
def linear_t31 : List Nat := linear_g31 ++ linear_t32
def linear_t30 : List Nat := linear_g30 ++ linear_t31
def linear_t29 : List Nat := linear_g29 ++ linear_t30
def linear_t28 : List Nat := linear_g28 ++ linear_t29
def linear_t27 : List Nat := linear_g27 ++ linear_t28
def linear_t26 : List Nat := linear_g26 ++ linear_t27
def linear_t25 : List Nat := linear_g25 ++ linear_t26
def linear_t24 : List Nat := linear_g24 ++ linear_t25
def linear_t23 : List Nat := linear_g23 ++ linear_t24
def linear_t22 : List Nat := linear_g22 ++ linear_t23
def linear_t21 : List Nat := linear_g21 ++ linear_t22
def linear_t20 : List Nat := linear_g20 ++ linear_t21
def linear_t19 : List Nat := linear_g19 ++ linear_t20
def linear_t18 : List Nat := linear_g18 ++ linear_t19
def linear_t17 : List Nat := linear_g17 ++ linear_t18
def linear_t16 : List Nat := linear_g16 ++ linear_t17
def linear_t15 : List Nat := linear_g15 ++ linear_t16
def linear_t14 : List Nat := linear_g14 ++ linear_t15
def linear_t13 : List Nat := linear_g13 ++ linear_t14
def linear_t12 : List Nat := linear_g12 ++ linear_t13
def linear_t11 : List Nat := linear_g11 ++ linear_t12
def linear_t10 : List Nat := linear_g10 ++ linear_t11
def linear_t9 : List Nat := linear_g9 ++ linear_t10
def linear_t8 : List Nat := linear_g8 ++ linear_t9
def linear_t7 : List Nat := linear_g7 ++ linear_t8
def linear_t6 : List Nat := linear_g6 ++ linear_t7
def linear_t5 : List Nat := linear_g5 ++ linear_t6
def linear_t4 : List Nat := linear_g4 ++ linear_t5
def linear_t3 : List Nat := linear_g3 ++ linear_t4
def linear_t2 : List Nat := linear_g2 ++ linear_t3
def linear_t1 : List Nat := linear_g1 ++ linear_t2
def linear_t0 : List Nat := linear_g0 ++ linear_t1
def linear_r1 : Raw := (.arr [(.str [99,97,108,99,117,108,97,116,101])])
def linear_b1 : List Nat := linear_g2
theorem mutated_s1 : serializeRaw 4094 31 linear_r1 = some linear_b1 := by decide +kernel
theorem mutated_p1 (tail : List Nat) : parseRaw 4094 31 (linear_b1 ++ tail) = some (linear_r1, tail) := by rfl
def linear_r6 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b6 : List Nat := linear_g11
theorem mutated_s6 : serializeRaw 4085 27 linear_r6 = some linear_b6 := by decide +kernel
theorem mutated_p6 (tail : List Nat) : parseRaw 4085 27 (linear_b6 ++ tail) = some (linear_r6, tail) := by rfl
def linear_r7 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,116,114,121,95,110,101,119])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49])),([116,121,112,101],(.str [98,111,111,108]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50])),([116,121,112,101],(.str [117,56]))])]))])])
def linear_b7 : List Nat := linear_g14
theorem mutated_s7 : serializeRaw 4084 27 linear_r7 = some linear_b7 := by decide +kernel
theorem mutated_p7 (tail : List Nat) : parseRaw 4084 27 (linear_b7 ++ tail) = some (linear_r7, tail) := by rfl
def linear_r8 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b8 : List Nat := linear_g17
theorem mutated_s8 : serializeRaw 4083 27 linear_r8 = some linear_b8 := by decide +kernel
theorem mutated_p8 (tail : List Nat) : parseRaw 4083 27 (linear_b8 ++ tail) = some (linear_r8, tail) := by rfl
def linear_r9 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,49]))]))])
def linear_b9 : List Nat := linear_g20
theorem mutated_s9 : serializeRaw 4082 27 linear_r9 = some linear_b9 := by decide +kernel
theorem mutated_p9 (tail : List Nat) : parseRaw 4082 27 (linear_b9 ++ tail) = some (linear_r9, tail) := by rfl
def linear_k5_0 : List Nat := [105,100]
theorem mutated_kd5_0 : stringBytes linear_k5_0 = true := by decide +kernel
theorem mutated_kp5_0 (tail : List Nat) : parseStringTail (linear_k5_0 ++ (34 :: 58 :: tail)) [] = some (linear_k5_0, 58 :: tail) := by rfl
def linear_k5_1 : List Nat := [111,112,115]
theorem mutated_kd5_1 : stringBytes linear_k5_1 = true := by decide +kernel
theorem mutated_kp5_1 (tail : List Nat) : parseStringTail (linear_k5_1 ++ (34 :: 58 :: tail)) [] = some (linear_k5_1, 58 :: tail) := by rfl
def linear_k5_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd5_2 : stringBytes linear_k5_2 = true := by decide +kernel
theorem mutated_kp5_2 (tail : List Nat) : parseStringTail (linear_k5_2 ++ (34 :: 58 :: tail)) [] = some (linear_k5_2, 58 :: tail) := by rfl
def linear_k5_3 : List Nat := [116,101,114,109]
theorem mutated_kd5_3 : stringBytes linear_k5_3 = true := by decide +kernel
theorem mutated_kp5_3 (tail : List Nat) : parseStringTail (linear_k5_3 ++ (34 :: 58 :: tail)) [] = some (linear_k5_3, 58 :: tail) := by rfl
def linear_l5_3 : List (List Nat × Raw) := [(linear_k5_3, linear_r9)]
def linear_v5_3 : List Nat := linear_g19 ++ linear_b9
theorem mutated_sl5_3 : serializeFields 4083 27 linear_l5_3 = some linear_v5_3 := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4082 27 linear_k5_3 linear_r9 linear_b9 mutated_kd5_3 mutated_s9)
theorem mutated_pl5_3 (tail : List Nat) : parseFields 4083 27 (linear_v5_3 ++ (125 :: tail)) = some (linear_l5_3, tail) := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4082 27 (linear_k5_3 ++ (34 :: 58 :: (linear_b9 ++ (125 :: tail)))) linear_k5_3 (linear_b9 ++ (125 :: tail)) tail linear_r9 (mutated_kp5_3 (linear_b9 ++ (125 :: tail))) (mutated_p9 (125 :: tail)))
def linear_l5_2 : List (List Nat × Raw) := (linear_k5_2, linear_r8) :: linear_l5_3
def linear_v5_2 : List Nat := (linear_g16 ++ linear_b8) ++ (44 :: linear_v5_3)
theorem mutated_sl5_2 : serializeFields 4084 27 linear_l5_2 = some linear_v5_2 := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k5_2 linear_r8 (linear_k5_3, linear_r9) [] linear_b8 linear_v5_3 mutated_kd5_2 mutated_s8 mutated_sl5_3)
theorem mutated_pl5_2 (tail : List Nat) : parseFields 4084 27 (linear_v5_2 ++ (125 :: tail)) = some (linear_l5_2, tail) := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k5_2 ++ (34 :: 58 :: (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))))) linear_k5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))) (linear_v5_3 ++ (125 :: tail)) tail linear_r8 linear_l5_3 (mutated_kp5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail))))) (mutated_p8 (44 :: (linear_v5_3 ++ (125 :: tail)))) (mutated_pl5_3 tail))
def linear_l5_1 : List (List Nat × Raw) := (linear_k5_1, linear_r7) :: linear_l5_2
def linear_v5_1 : List Nat := (linear_g13 ++ linear_b7) ++ (44 :: linear_v5_2)
theorem mutated_sl5_1 : serializeFields 4085 27 linear_l5_1 = some linear_v5_1 := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k5_1 linear_r7 (linear_k5_2, linear_r8) linear_l5_3 linear_b7 linear_v5_2 mutated_kd5_1 mutated_s7 mutated_sl5_2)
theorem mutated_pl5_1 (tail : List Nat) : parseFields 4085 27 (linear_v5_1 ++ (125 :: tail)) = some (linear_l5_1, tail) := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k5_1 ++ (34 :: 58 :: (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))))) linear_k5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))) (linear_v5_2 ++ (125 :: tail)) tail linear_r7 linear_l5_2 (mutated_kp5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail))))) (mutated_p7 (44 :: (linear_v5_2 ++ (125 :: tail)))) (mutated_pl5_2 tail))
def linear_l5_0 : List (List Nat × Raw) := (linear_k5_0, linear_r6) :: linear_l5_1
def linear_v5_0 : List Nat := (linear_g10 ++ linear_b6) ++ (44 :: linear_v5_1)
theorem mutated_sl5_0 : serializeFields 4086 27 linear_l5_0 = some linear_v5_0 := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 27 linear_k5_0 linear_r6 (linear_k5_1, linear_r7) linear_l5_2 linear_b6 linear_v5_1 mutated_kd5_0 mutated_s6 mutated_sl5_1)
theorem mutated_pl5_0 (tail : List Nat) : parseFields 4086 27 (linear_v5_0 ++ (125 :: tail)) = some (linear_l5_0, tail) := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) linear_k5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))) (linear_v5_1 ++ (125 :: tail)) tail linear_r6 linear_l5_1 (mutated_kp5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail))))) (mutated_p6 (44 :: (linear_v5_1 ++ (125 :: tail)))) (mutated_pl5_1 tail))
def linear_r5 : Raw := (.obj linear_l5_0)
def linear_b5 : List Nat := linear_g9 ++ (linear_v5_0 ++ linear_g21)
theorem mutated_o5 : orderedFields linear_l5_0 = true := by decide +kernel
theorem mutated_s5 : serializeRaw 4087 28 linear_r5 = some linear_b5 := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4086 27 linear_l5_0 linear_v5_0 mutated_o5 mutated_sl5_0)
theorem mutated_p5 (tail : List Nat) : parseRaw 4087 28 (linear_b5 ++ tail) = some (linear_r5, tail) := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4086 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) tail linear_l5_0 mutated_o5 (by simpa only [linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl5_0 tail)))
def linear_r11 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,49])
def linear_b11 : List Nat := linear_g25
theorem mutated_s11 : serializeRaw 4084 27 linear_r11 = some linear_b11 := by decide +kernel
theorem mutated_p11 (tail : List Nat) : parseRaw 4084 27 (linear_b11 ++ tail) = some (linear_r11, tail) := by rfl
def linear_r12 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b12 : List Nat := linear_g28
theorem mutated_s12 : serializeRaw 4083 27 linear_r12 = some linear_b12 := by decide +kernel
theorem mutated_p12 (tail : List Nat) : parseRaw 4083 27 (linear_b12 ++ tail) = some (linear_r12, tail) := by rfl
def linear_r13 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b13 : List Nat := linear_g31
theorem mutated_s13 : serializeRaw 4082 27 linear_r13 = some linear_b13 := by decide +kernel
theorem mutated_p13 (tail : List Nat) : parseRaw 4082 27 (linear_b13 ++ tail) = some (linear_r13, tail) := by rfl
def linear_r14 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,52]),(.str [100,103,95,118,95,56]),(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,57]),(.str [100,103,95,118,95,49,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,51]))])
def linear_b14 : List Nat := linear_g34
theorem mutated_s14 : serializeRaw 4081 27 linear_r14 = some linear_b14 := by decide +kernel
theorem mutated_p14 (tail : List Nat) : parseRaw 4081 27 (linear_b14 ++ tail) = some (linear_r14, tail) := by rfl
def linear_k10_0 : List Nat := [105,100]
theorem mutated_kd10_0 : stringBytes linear_k10_0 = true := by decide +kernel
theorem mutated_kp10_0 (tail : List Nat) : parseStringTail (linear_k10_0 ++ (34 :: 58 :: tail)) [] = some (linear_k10_0, 58 :: tail) := by rfl
def linear_k10_1 : List Nat := [111,112,115]
theorem mutated_kd10_1 : stringBytes linear_k10_1 = true := by decide +kernel
theorem mutated_kp10_1 (tail : List Nat) : parseStringTail (linear_k10_1 ++ (34 :: 58 :: tail)) [] = some (linear_k10_1, 58 :: tail) := by rfl
def linear_k10_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd10_2 : stringBytes linear_k10_2 = true := by decide +kernel
theorem mutated_kp10_2 (tail : List Nat) : parseStringTail (linear_k10_2 ++ (34 :: 58 :: tail)) [] = some (linear_k10_2, 58 :: tail) := by rfl
def linear_k10_3 : List Nat := [116,101,114,109]
theorem mutated_kd10_3 : stringBytes linear_k10_3 = true := by decide +kernel
theorem mutated_kp10_3 (tail : List Nat) : parseStringTail (linear_k10_3 ++ (34 :: 58 :: tail)) [] = some (linear_k10_3, 58 :: tail) := by rfl
def linear_l10_3 : List (List Nat × Raw) := [(linear_k10_3, linear_r14)]
def linear_v10_3 : List Nat := linear_g33 ++ linear_b14
theorem mutated_sl10_3 : serializeFields 4082 27 linear_l10_3 = some linear_v10_3 := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4081 27 linear_k10_3 linear_r14 linear_b14 mutated_kd10_3 mutated_s14)
theorem mutated_pl10_3 (tail : List Nat) : parseFields 4082 27 (linear_v10_3 ++ (125 :: tail)) = some (linear_l10_3, tail) := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4081 27 (linear_k10_3 ++ (34 :: 58 :: (linear_b14 ++ (125 :: tail)))) linear_k10_3 (linear_b14 ++ (125 :: tail)) tail linear_r14 (mutated_kp10_3 (linear_b14 ++ (125 :: tail))) (mutated_p14 (125 :: tail)))
def linear_l10_2 : List (List Nat × Raw) := (linear_k10_2, linear_r13) :: linear_l10_3
def linear_v10_2 : List Nat := (linear_g30 ++ linear_b13) ++ (44 :: linear_v10_3)
theorem mutated_sl10_2 : serializeFields 4083 27 linear_l10_2 = some linear_v10_2 := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k10_2 linear_r13 (linear_k10_3, linear_r14) [] linear_b13 linear_v10_3 mutated_kd10_2 mutated_s13 mutated_sl10_3)
theorem mutated_pl10_2 (tail : List Nat) : parseFields 4083 27 (linear_v10_2 ++ (125 :: tail)) = some (linear_l10_2, tail) := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k10_2 ++ (34 :: 58 :: (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))))) linear_k10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))) (linear_v10_3 ++ (125 :: tail)) tail linear_r13 linear_l10_3 (mutated_kp10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail))))) (mutated_p13 (44 :: (linear_v10_3 ++ (125 :: tail)))) (mutated_pl10_3 tail))
def linear_l10_1 : List (List Nat × Raw) := (linear_k10_1, linear_r12) :: linear_l10_2
def linear_v10_1 : List Nat := (linear_g27 ++ linear_b12) ++ (44 :: linear_v10_2)
theorem mutated_sl10_1 : serializeFields 4084 27 linear_l10_1 = some linear_v10_1 := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k10_1 linear_r12 (linear_k10_2, linear_r13) linear_l10_3 linear_b12 linear_v10_2 mutated_kd10_1 mutated_s12 mutated_sl10_2)
theorem mutated_pl10_1 (tail : List Nat) : parseFields 4084 27 (linear_v10_1 ++ (125 :: tail)) = some (linear_l10_1, tail) := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k10_1 ++ (34 :: 58 :: (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))))) linear_k10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))) (linear_v10_2 ++ (125 :: tail)) tail linear_r12 linear_l10_2 (mutated_kp10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail))))) (mutated_p12 (44 :: (linear_v10_2 ++ (125 :: tail)))) (mutated_pl10_2 tail))
def linear_l10_0 : List (List Nat × Raw) := (linear_k10_0, linear_r11) :: linear_l10_1
def linear_v10_0 : List Nat := (linear_g24 ++ linear_b11) ++ (44 :: linear_v10_1)
theorem mutated_sl10_0 : serializeFields 4085 27 linear_l10_0 = some linear_v10_0 := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k10_0 linear_r11 (linear_k10_1, linear_r12) linear_l10_2 linear_b11 linear_v10_1 mutated_kd10_0 mutated_s11 mutated_sl10_1)
theorem mutated_pl10_0 (tail : List Nat) : parseFields 4085 27 (linear_v10_0 ++ (125 :: tail)) = some (linear_l10_0, tail) := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) linear_k10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))) (linear_v10_1 ++ (125 :: tail)) tail linear_r11 linear_l10_1 (mutated_kp10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail))))) (mutated_p11 (44 :: (linear_v10_1 ++ (125 :: tail)))) (mutated_pl10_1 tail))
def linear_r10 : Raw := (.obj linear_l10_0)
def linear_b10 : List Nat := linear_g23 ++ (linear_v10_0 ++ linear_g35)
theorem mutated_o10 : orderedFields linear_l10_0 = true := by decide +kernel
theorem mutated_s10 : serializeRaw 4086 28 linear_r10 = some linear_b10 := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4085 27 linear_l10_0 linear_v10_0 mutated_o10 mutated_sl10_0)
theorem mutated_p10 (tail : List Nat) : parseRaw 4086 28 (linear_b10 ++ tail) = some (linear_r10, tail) := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4085 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) tail linear_l10_0 mutated_o10 (by simpa only [linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl10_0 tail)))
def linear_r16 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,50])
def linear_b16 : List Nat := linear_g39
theorem mutated_s16 : serializeRaw 4083 27 linear_r16 = some linear_b16 := by decide +kernel
theorem mutated_p16 (tail : List Nat) : parseRaw 4083 27 (linear_b16 ++ tail) = some (linear_r16, tail) := by rfl
def linear_r18 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])
def linear_b18 : List Nat := linear_g43
theorem mutated_s18 : serializeRaw 4080 26 linear_r18 = some linear_b18 := by decide +kernel
theorem mutated_p18 (tail : List Nat) : parseRaw 4080 26 (linear_b18 ++ tail) = some (linear_r18, tail) := by rfl
def linear_r19 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1000))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b19 : List Nat := linear_g45
theorem mutated_s19 : serializeRaw 4079 26 linear_r19 = some linear_b19 := by decide +kernel
theorem mutated_p19 (tail : List Nat) : parseRaw 4079 26 (linear_b19 ++ tail) = some (linear_r19, tail) := by rfl
def linear_r20 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b20 : List Nat := linear_g47
theorem mutated_s20 : serializeRaw 4078 26 linear_r20 = some linear_b20 := by decide +kernel
theorem mutated_p20 (tail : List Nat) : parseRaw 4078 26 (linear_b20 ++ tail) = some (linear_r20, tail) := by rfl
def linear_r21 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54]),(.str [100,103,95,118,95,49,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,56])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b21 : List Nat := linear_g49
theorem mutated_s21 : serializeRaw 4077 26 linear_r21 = some linear_b21 := by decide +kernel
theorem mutated_p21 (tail : List Nat) : parseRaw 4077 26 (linear_b21 ++ tail) = some (linear_r21, tail) := by rfl
def linear_l17_3 : List Raw := [linear_r21]
def linear_v17_3 : List Nat := linear_b21
theorem mutated_sl17_3 : serializeItems 4078 26 linear_l17_3 = some linear_v17_3 := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4077 26 linear_r21 linear_b21 mutated_s21)
theorem mutated_pl17_3 (tail : List Nat) : parseItems 4078 26 (linear_v17_3 ++ (93 :: tail)) = some (linear_l17_3, tail) := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4077 26 (linear_b21 ++ (93 :: tail)) tail linear_r21 (mutated_p21 (93 :: tail)))
def linear_l17_2 : List Raw := linear_r20 :: linear_l17_3
def linear_v17_2 : List Nat := (linear_b20) ++ (44 :: linear_v17_3)
theorem mutated_sl17_2 : serializeItems 4079 26 linear_l17_2 = some linear_v17_2 := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 26 linear_r20 linear_r21 [] linear_b20 linear_v17_3 mutated_s20 mutated_sl17_3)
theorem mutated_pl17_2 (tail : List Nat) : parseItems 4079 26 (linear_v17_2 ++ (93 :: tail)) = some (linear_l17_2, tail) := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 26 (linear_b20 ++ (44 :: (linear_v17_3 ++ (93 :: tail)))) (linear_v17_3 ++ (93 :: tail)) tail linear_r20 linear_l17_3 (mutated_p20 (44 :: (linear_v17_3 ++ (93 :: tail)))) (mutated_pl17_3 tail))
def linear_l17_1 : List Raw := linear_r19 :: linear_l17_2
def linear_v17_1 : List Nat := (linear_b19) ++ (44 :: linear_v17_2)
theorem mutated_sl17_1 : serializeItems 4080 26 linear_l17_1 = some linear_v17_1 := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 26 linear_r19 linear_r20 linear_l17_3 linear_b19 linear_v17_2 mutated_s19 mutated_sl17_2)
theorem mutated_pl17_1 (tail : List Nat) : parseItems 4080 26 (linear_v17_1 ++ (93 :: tail)) = some (linear_l17_1, tail) := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 26 (linear_b19 ++ (44 :: (linear_v17_2 ++ (93 :: tail)))) (linear_v17_2 ++ (93 :: tail)) tail linear_r19 linear_l17_2 (mutated_p19 (44 :: (linear_v17_2 ++ (93 :: tail)))) (mutated_pl17_2 tail))
def linear_l17_0 : List Raw := linear_r18 :: linear_l17_1
def linear_v17_0 : List Nat := (linear_b18) ++ (44 :: linear_v17_1)
theorem mutated_sl17_0 : serializeItems 4081 26 linear_l17_0 = some linear_v17_0 := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 26 linear_r18 linear_r19 linear_l17_2 linear_b18 linear_v17_1 mutated_s18 mutated_sl17_1)
theorem mutated_pl17_0 (tail : List Nat) : parseItems 4081 26 (linear_v17_0 ++ (93 :: tail)) = some (linear_l17_0, tail) := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 26 (linear_b18 ++ (44 :: (linear_v17_1 ++ (93 :: tail)))) (linear_v17_1 ++ (93 :: tail)) tail linear_r18 linear_l17_1 (mutated_p18 (44 :: (linear_v17_1 ++ (93 :: tail)))) (mutated_pl17_1 tail))
def linear_r17 : Raw := (.arr linear_l17_0)
def linear_b17 : List Nat := linear_g42 ++ (linear_v17_0 ++ linear_g50)
theorem mutated_s17 : serializeRaw 4082 27 linear_r17 = some linear_b17 := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4081 26 linear_l17_0 linear_v17_0 mutated_sl17_0)
theorem mutated_p17 (tail : List Nat) : parseRaw 4082 27 (linear_b17 ++ tail) = some (linear_r17, tail) := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4081 26 (linear_v17_0 ++ (93 :: tail)) tail linear_l17_0 (by intro h; cases h) (mutated_pl17_0 tail))
def linear_r22 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,57])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b22 : List Nat := linear_g53
theorem mutated_s22 : serializeRaw 4081 27 linear_r22 = some linear_b22 := by decide +kernel
theorem mutated_p22 (tail : List Nat) : parseRaw 4081 27 (linear_b22 ++ tail) = some (linear_r22, tail) := by rfl
def linear_r23 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,56])]))])
def linear_b23 : List Nat := linear_g56
theorem mutated_s23 : serializeRaw 4080 27 linear_r23 = some linear_b23 := by decide +kernel
theorem mutated_p23 (tail : List Nat) : parseRaw 4080 27 (linear_b23 ++ tail) = some (linear_r23, tail) := by rfl
def linear_k15_0 : List Nat := [105,100]
theorem mutated_kd15_0 : stringBytes linear_k15_0 = true := by decide +kernel
theorem mutated_kp15_0 (tail : List Nat) : parseStringTail (linear_k15_0 ++ (34 :: 58 :: tail)) [] = some (linear_k15_0, 58 :: tail) := by rfl
def linear_k15_1 : List Nat := [111,112,115]
theorem mutated_kd15_1 : stringBytes linear_k15_1 = true := by decide +kernel
theorem mutated_kp15_1 (tail : List Nat) : parseStringTail (linear_k15_1 ++ (34 :: 58 :: tail)) [] = some (linear_k15_1, 58 :: tail) := by rfl
def linear_k15_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd15_2 : stringBytes linear_k15_2 = true := by decide +kernel
theorem mutated_kp15_2 (tail : List Nat) : parseStringTail (linear_k15_2 ++ (34 :: 58 :: tail)) [] = some (linear_k15_2, 58 :: tail) := by rfl
def linear_k15_3 : List Nat := [116,101,114,109]
theorem mutated_kd15_3 : stringBytes linear_k15_3 = true := by decide +kernel
theorem mutated_kp15_3 (tail : List Nat) : parseStringTail (linear_k15_3 ++ (34 :: 58 :: tail)) [] = some (linear_k15_3, 58 :: tail) := by rfl
def linear_l15_3 : List (List Nat × Raw) := [(linear_k15_3, linear_r23)]
def linear_v15_3 : List Nat := linear_g55 ++ linear_b23
theorem mutated_sl15_3 : serializeFields 4081 27 linear_l15_3 = some linear_v15_3 := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4080 27 linear_k15_3 linear_r23 linear_b23 mutated_kd15_3 mutated_s23)
theorem mutated_pl15_3 (tail : List Nat) : parseFields 4081 27 (linear_v15_3 ++ (125 :: tail)) = some (linear_l15_3, tail) := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4080 27 (linear_k15_3 ++ (34 :: 58 :: (linear_b23 ++ (125 :: tail)))) linear_k15_3 (linear_b23 ++ (125 :: tail)) tail linear_r23 (mutated_kp15_3 (linear_b23 ++ (125 :: tail))) (mutated_p23 (125 :: tail)))
def linear_l15_2 : List (List Nat × Raw) := (linear_k15_2, linear_r22) :: linear_l15_3
def linear_v15_2 : List Nat := (linear_g52 ++ linear_b22) ++ (44 :: linear_v15_3)
theorem mutated_sl15_2 : serializeFields 4082 27 linear_l15_2 = some linear_v15_2 := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k15_2 linear_r22 (linear_k15_3, linear_r23) [] linear_b22 linear_v15_3 mutated_kd15_2 mutated_s22 mutated_sl15_3)
theorem mutated_pl15_2 (tail : List Nat) : parseFields 4082 27 (linear_v15_2 ++ (125 :: tail)) = some (linear_l15_2, tail) := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k15_2 ++ (34 :: 58 :: (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))))) linear_k15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))) (linear_v15_3 ++ (125 :: tail)) tail linear_r22 linear_l15_3 (mutated_kp15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail))))) (mutated_p22 (44 :: (linear_v15_3 ++ (125 :: tail)))) (mutated_pl15_3 tail))
def linear_l15_1 : List (List Nat × Raw) := (linear_k15_1, linear_r17) :: linear_l15_2
def linear_v15_1 : List Nat := (linear_g41 ++ linear_b17) ++ (44 :: linear_v15_2)
theorem mutated_sl15_1 : serializeFields 4083 27 linear_l15_1 = some linear_v15_1 := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k15_1 linear_r17 (linear_k15_2, linear_r22) linear_l15_3 linear_b17 linear_v15_2 mutated_kd15_1 mutated_s17 mutated_sl15_2)
theorem mutated_pl15_1 (tail : List Nat) : parseFields 4083 27 (linear_v15_1 ++ (125 :: tail)) = some (linear_l15_1, tail) := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k15_1 ++ (34 :: 58 :: (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))))) linear_k15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))) (linear_v15_2 ++ (125 :: tail)) tail linear_r17 linear_l15_2 (mutated_kp15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail))))) (mutated_p17 (44 :: (linear_v15_2 ++ (125 :: tail)))) (mutated_pl15_2 tail))
def linear_l15_0 : List (List Nat × Raw) := (linear_k15_0, linear_r16) :: linear_l15_1
def linear_v15_0 : List Nat := (linear_g38 ++ linear_b16) ++ (44 :: linear_v15_1)
theorem mutated_sl15_0 : serializeFields 4084 27 linear_l15_0 = some linear_v15_0 := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k15_0 linear_r16 (linear_k15_1, linear_r17) linear_l15_2 linear_b16 linear_v15_1 mutated_kd15_0 mutated_s16 mutated_sl15_1)
theorem mutated_pl15_0 (tail : List Nat) : parseFields 4084 27 (linear_v15_0 ++ (125 :: tail)) = some (linear_l15_0, tail) := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) linear_k15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))) (linear_v15_1 ++ (125 :: tail)) tail linear_r16 linear_l15_1 (mutated_kp15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail))))) (mutated_p16 (44 :: (linear_v15_1 ++ (125 :: tail)))) (mutated_pl15_1 tail))
def linear_r15 : Raw := (.obj linear_l15_0)
def linear_b15 : List Nat := linear_g37 ++ (linear_v15_0 ++ linear_g57)
theorem mutated_o15 : orderedFields linear_l15_0 = true := by decide +kernel
theorem mutated_s15 : serializeRaw 4085 28 linear_r15 = some linear_b15 := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4084 27 linear_l15_0 linear_v15_0 mutated_o15 mutated_sl15_0)
theorem mutated_p15 (tail : List Nat) : parseRaw 4085 28 (linear_b15 ++ tail) = some (linear_r15, tail) := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4084 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) tail linear_l15_0 mutated_o15 (by simpa only [linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl15_0 tail)))
def linear_r25 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,51])
def linear_b25 : List Nat := linear_g61
theorem mutated_s25 : serializeRaw 4082 27 linear_r25 = some linear_b25 := by decide +kernel
theorem mutated_p25 (tail : List Nat) : parseRaw 4082 27 (linear_b25 ++ tail) = some (linear_r25, tail) := by rfl
def linear_r26 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,53])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b26 : List Nat := linear_g64
theorem mutated_s26 : serializeRaw 4081 27 linear_r26 = some linear_b26 := by decide +kernel
theorem mutated_p26 (tail : List Nat) : parseRaw 4081 27 (linear_b26 ++ tail) = some (linear_r26, tail) := by rfl
def linear_r27 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b27 : List Nat := linear_g67
theorem mutated_s27 : serializeRaw 4080 27 linear_r27 = some linear_b27 := by decide +kernel
theorem mutated_p27 (tail : List Nat) : parseRaw 4080 27 (linear_b27 ++ tail) = some (linear_r27, tail) := by rfl
def linear_r28 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,50,53])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,48]))]))])
def linear_b28 : List Nat := linear_g70
theorem mutated_s28 : serializeRaw 4079 27 linear_r28 = some linear_b28 := by decide +kernel
theorem mutated_p28 (tail : List Nat) : parseRaw 4079 27 (linear_b28 ++ tail) = some (linear_r28, tail) := by rfl
def linear_k24_0 : List Nat := [105,100]
theorem mutated_kd24_0 : stringBytes linear_k24_0 = true := by decide +kernel
theorem mutated_kp24_0 (tail : List Nat) : parseStringTail (linear_k24_0 ++ (34 :: 58 :: tail)) [] = some (linear_k24_0, 58 :: tail) := by rfl
def linear_k24_1 : List Nat := [111,112,115]
theorem mutated_kd24_1 : stringBytes linear_k24_1 = true := by decide +kernel
theorem mutated_kp24_1 (tail : List Nat) : parseStringTail (linear_k24_1 ++ (34 :: 58 :: tail)) [] = some (linear_k24_1, 58 :: tail) := by rfl
def linear_k24_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd24_2 : stringBytes linear_k24_2 = true := by decide +kernel
theorem mutated_kp24_2 (tail : List Nat) : parseStringTail (linear_k24_2 ++ (34 :: 58 :: tail)) [] = some (linear_k24_2, 58 :: tail) := by rfl
def linear_k24_3 : List Nat := [116,101,114,109]
theorem mutated_kd24_3 : stringBytes linear_k24_3 = true := by decide +kernel
theorem mutated_kp24_3 (tail : List Nat) : parseStringTail (linear_k24_3 ++ (34 :: 58 :: tail)) [] = some (linear_k24_3, 58 :: tail) := by rfl
def linear_l24_3 : List (List Nat × Raw) := [(linear_k24_3, linear_r28)]
def linear_v24_3 : List Nat := linear_g69 ++ linear_b28
theorem mutated_sl24_3 : serializeFields 4080 27 linear_l24_3 = some linear_v24_3 := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4079 27 linear_k24_3 linear_r28 linear_b28 mutated_kd24_3 mutated_s28)
theorem mutated_pl24_3 (tail : List Nat) : parseFields 4080 27 (linear_v24_3 ++ (125 :: tail)) = some (linear_l24_3, tail) := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4079 27 (linear_k24_3 ++ (34 :: 58 :: (linear_b28 ++ (125 :: tail)))) linear_k24_3 (linear_b28 ++ (125 :: tail)) tail linear_r28 (mutated_kp24_3 (linear_b28 ++ (125 :: tail))) (mutated_p28 (125 :: tail)))
def linear_l24_2 : List (List Nat × Raw) := (linear_k24_2, linear_r27) :: linear_l24_3
def linear_v24_2 : List Nat := (linear_g66 ++ linear_b27) ++ (44 :: linear_v24_3)
theorem mutated_sl24_2 : serializeFields 4081 27 linear_l24_2 = some linear_v24_2 := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k24_2 linear_r27 (linear_k24_3, linear_r28) [] linear_b27 linear_v24_3 mutated_kd24_2 mutated_s27 mutated_sl24_3)
theorem mutated_pl24_2 (tail : List Nat) : parseFields 4081 27 (linear_v24_2 ++ (125 :: tail)) = some (linear_l24_2, tail) := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k24_2 ++ (34 :: 58 :: (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))))) linear_k24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))) (linear_v24_3 ++ (125 :: tail)) tail linear_r27 linear_l24_3 (mutated_kp24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail))))) (mutated_p27 (44 :: (linear_v24_3 ++ (125 :: tail)))) (mutated_pl24_3 tail))
def linear_l24_1 : List (List Nat × Raw) := (linear_k24_1, linear_r26) :: linear_l24_2
def linear_v24_1 : List Nat := (linear_g63 ++ linear_b26) ++ (44 :: linear_v24_2)
theorem mutated_sl24_1 : serializeFields 4082 27 linear_l24_1 = some linear_v24_1 := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k24_1 linear_r26 (linear_k24_2, linear_r27) linear_l24_3 linear_b26 linear_v24_2 mutated_kd24_1 mutated_s26 mutated_sl24_2)
theorem mutated_pl24_1 (tail : List Nat) : parseFields 4082 27 (linear_v24_1 ++ (125 :: tail)) = some (linear_l24_1, tail) := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k24_1 ++ (34 :: 58 :: (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))))) linear_k24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))) (linear_v24_2 ++ (125 :: tail)) tail linear_r26 linear_l24_2 (mutated_kp24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail))))) (mutated_p26 (44 :: (linear_v24_2 ++ (125 :: tail)))) (mutated_pl24_2 tail))
def linear_l24_0 : List (List Nat × Raw) := (linear_k24_0, linear_r25) :: linear_l24_1
def linear_v24_0 : List Nat := (linear_g60 ++ linear_b25) ++ (44 :: linear_v24_1)
theorem mutated_sl24_0 : serializeFields 4083 27 linear_l24_0 = some linear_v24_0 := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k24_0 linear_r25 (linear_k24_1, linear_r26) linear_l24_2 linear_b25 linear_v24_1 mutated_kd24_0 mutated_s25 mutated_sl24_1)
theorem mutated_pl24_0 (tail : List Nat) : parseFields 4083 27 (linear_v24_0 ++ (125 :: tail)) = some (linear_l24_0, tail) := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) linear_k24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))) (linear_v24_1 ++ (125 :: tail)) tail linear_r25 linear_l24_1 (mutated_kp24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail))))) (mutated_p25 (44 :: (linear_v24_1 ++ (125 :: tail)))) (mutated_pl24_1 tail))
def linear_r24 : Raw := (.obj linear_l24_0)
def linear_b24 : List Nat := linear_g59 ++ (linear_v24_0 ++ linear_g71)
theorem mutated_o24 : orderedFields linear_l24_0 = true := by decide +kernel
theorem mutated_s24 : serializeRaw 4084 28 linear_r24 = some linear_b24 := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4083 27 linear_l24_0 linear_v24_0 mutated_o24 mutated_sl24_0)
theorem mutated_p24 (tail : List Nat) : parseRaw 4084 28 (linear_b24 ++ tail) = some (linear_r24, tail) := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4083 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) tail linear_l24_0 mutated_o24 (by simpa only [linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl24_0 tail)))
def linear_r30 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,52])
def linear_b30 : List Nat := linear_g75
theorem mutated_s30 : serializeRaw 4081 27 linear_r30 = some linear_b30 := by decide +kernel
theorem mutated_p30 (tail : List Nat) : parseRaw 4081 27 (linear_b30 ++ tail) = some (linear_r30, tail) := by rfl
def linear_r31 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,50])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b31 : List Nat := linear_g78
theorem mutated_s31 : serializeRaw 4080 27 linear_r31 = some linear_b31 := by decide +kernel
theorem mutated_p31 (tail : List Nat) : parseRaw 4080 27 (linear_b31 ++ tail) = some (linear_r31, tail) := by rfl
def linear_r32 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b32 : List Nat := linear_g81
theorem mutated_s32 : serializeRaw 4079 27 linear_r32 = some linear_b32 := by decide +kernel
theorem mutated_p32 (tail : List Nat) : parseRaw 4079 27 (linear_b32 ++ tail) = some (linear_r32, tail) := by rfl
def linear_r33 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,50,56]),(.str [100,103,95,118,95,50,57]),(.str [100,103,95,118,95,51,50]),(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,51,51]),(.str [100,103,95,118,95,51,52])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,53]))])
def linear_b33 : List Nat := linear_g84
theorem mutated_s33 : serializeRaw 4078 27 linear_r33 = some linear_b33 := by decide +kernel
theorem mutated_p33 (tail : List Nat) : parseRaw 4078 27 (linear_b33 ++ tail) = some (linear_r33, tail) := by rfl
def linear_k29_0 : List Nat := [105,100]
theorem mutated_kd29_0 : stringBytes linear_k29_0 = true := by decide +kernel
theorem mutated_kp29_0 (tail : List Nat) : parseStringTail (linear_k29_0 ++ (34 :: 58 :: tail)) [] = some (linear_k29_0, 58 :: tail) := by rfl
def linear_k29_1 : List Nat := [111,112,115]
theorem mutated_kd29_1 : stringBytes linear_k29_1 = true := by decide +kernel
theorem mutated_kp29_1 (tail : List Nat) : parseStringTail (linear_k29_1 ++ (34 :: 58 :: tail)) [] = some (linear_k29_1, 58 :: tail) := by rfl
def linear_k29_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd29_2 : stringBytes linear_k29_2 = true := by decide +kernel
theorem mutated_kp29_2 (tail : List Nat) : parseStringTail (linear_k29_2 ++ (34 :: 58 :: tail)) [] = some (linear_k29_2, 58 :: tail) := by rfl
def linear_k29_3 : List Nat := [116,101,114,109]
theorem mutated_kd29_3 : stringBytes linear_k29_3 = true := by decide +kernel
theorem mutated_kp29_3 (tail : List Nat) : parseStringTail (linear_k29_3 ++ (34 :: 58 :: tail)) [] = some (linear_k29_3, 58 :: tail) := by rfl
def linear_l29_3 : List (List Nat × Raw) := [(linear_k29_3, linear_r33)]
def linear_v29_3 : List Nat := linear_g83 ++ linear_b33
theorem mutated_sl29_3 : serializeFields 4079 27 linear_l29_3 = some linear_v29_3 := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4078 27 linear_k29_3 linear_r33 linear_b33 mutated_kd29_3 mutated_s33)
theorem mutated_pl29_3 (tail : List Nat) : parseFields 4079 27 (linear_v29_3 ++ (125 :: tail)) = some (linear_l29_3, tail) := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4078 27 (linear_k29_3 ++ (34 :: 58 :: (linear_b33 ++ (125 :: tail)))) linear_k29_3 (linear_b33 ++ (125 :: tail)) tail linear_r33 (mutated_kp29_3 (linear_b33 ++ (125 :: tail))) (mutated_p33 (125 :: tail)))
def linear_l29_2 : List (List Nat × Raw) := (linear_k29_2, linear_r32) :: linear_l29_3
def linear_v29_2 : List Nat := (linear_g80 ++ linear_b32) ++ (44 :: linear_v29_3)
theorem mutated_sl29_2 : serializeFields 4080 27 linear_l29_2 = some linear_v29_2 := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k29_2 linear_r32 (linear_k29_3, linear_r33) [] linear_b32 linear_v29_3 mutated_kd29_2 mutated_s32 mutated_sl29_3)
theorem mutated_pl29_2 (tail : List Nat) : parseFields 4080 27 (linear_v29_2 ++ (125 :: tail)) = some (linear_l29_2, tail) := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k29_2 ++ (34 :: 58 :: (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))))) linear_k29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))) (linear_v29_3 ++ (125 :: tail)) tail linear_r32 linear_l29_3 (mutated_kp29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail))))) (mutated_p32 (44 :: (linear_v29_3 ++ (125 :: tail)))) (mutated_pl29_3 tail))
def linear_l29_1 : List (List Nat × Raw) := (linear_k29_1, linear_r31) :: linear_l29_2
def linear_v29_1 : List Nat := (linear_g77 ++ linear_b31) ++ (44 :: linear_v29_2)
theorem mutated_sl29_1 : serializeFields 4081 27 linear_l29_1 = some linear_v29_1 := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k29_1 linear_r31 (linear_k29_2, linear_r32) linear_l29_3 linear_b31 linear_v29_2 mutated_kd29_1 mutated_s31 mutated_sl29_2)
theorem mutated_pl29_1 (tail : List Nat) : parseFields 4081 27 (linear_v29_1 ++ (125 :: tail)) = some (linear_l29_1, tail) := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k29_1 ++ (34 :: 58 :: (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))))) linear_k29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))) (linear_v29_2 ++ (125 :: tail)) tail linear_r31 linear_l29_2 (mutated_kp29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail))))) (mutated_p31 (44 :: (linear_v29_2 ++ (125 :: tail)))) (mutated_pl29_2 tail))
def linear_l29_0 : List (List Nat × Raw) := (linear_k29_0, linear_r30) :: linear_l29_1
def linear_v29_0 : List Nat := (linear_g74 ++ linear_b30) ++ (44 :: linear_v29_1)
theorem mutated_sl29_0 : serializeFields 4082 27 linear_l29_0 = some linear_v29_0 := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k29_0 linear_r30 (linear_k29_1, linear_r31) linear_l29_2 linear_b30 linear_v29_1 mutated_kd29_0 mutated_s30 mutated_sl29_1)
theorem mutated_pl29_0 (tail : List Nat) : parseFields 4082 27 (linear_v29_0 ++ (125 :: tail)) = some (linear_l29_0, tail) := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) linear_k29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))) (linear_v29_1 ++ (125 :: tail)) tail linear_r30 linear_l29_1 (mutated_kp29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail))))) (mutated_p30 (44 :: (linear_v29_1 ++ (125 :: tail)))) (mutated_pl29_1 tail))
def linear_r29 : Raw := (.obj linear_l29_0)
def linear_b29 : List Nat := linear_g73 ++ (linear_v29_0 ++ linear_g85)
theorem mutated_o29 : orderedFields linear_l29_0 = true := by decide +kernel
theorem mutated_s29 : serializeRaw 4083 28 linear_r29 = some linear_b29 := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4082 27 linear_l29_0 linear_v29_0 mutated_o29 mutated_sl29_0)
theorem mutated_p29 (tail : List Nat) : parseRaw 4083 28 (linear_b29 ++ tail) = some (linear_r29, tail) := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4082 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) tail linear_l29_0 mutated_o29 (by simpa only [linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl29_0 tail)))
def linear_r35 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,53])
def linear_b35 : List Nat := linear_g89
theorem mutated_s35 : serializeRaw 4080 27 linear_r35 = some linear_b35 := by decide +kernel
theorem mutated_p35 (tail : List Nat) : parseRaw 4080 27 (linear_b35 ++ tail) = some (linear_r35, tail) := by rfl
def linear_r36 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,51,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,49])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b36 : List Nat := linear_g92
theorem mutated_s36 : serializeRaw 4079 27 linear_r36 = some linear_b36 := by decide +kernel
theorem mutated_p36 (tail : List Nat) : parseRaw 4079 27 (linear_b36 ++ tail) = some (linear_r36, tail) := by rfl
def linear_r37 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b37 : List Nat := linear_g95
theorem mutated_s37 : serializeRaw 4078 27 linear_r37 = some linear_b37 := by decide +kernel
theorem mutated_p37 (tail : List Nat) : parseRaw 4078 27 (linear_b37 ++ tail) = some (linear_r37, tail) := by rfl
def linear_r38 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,52,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,54]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,49]))]))])
def linear_b38 : List Nat := linear_g98
theorem mutated_s38 : serializeRaw 4077 27 linear_r38 = some linear_b38 := by decide +kernel
theorem mutated_p38 (tail : List Nat) : parseRaw 4077 27 (linear_b38 ++ tail) = some (linear_r38, tail) := by rfl
def linear_k34_0 : List Nat := [105,100]
theorem mutated_kd34_0 : stringBytes linear_k34_0 = true := by decide +kernel
theorem mutated_kp34_0 (tail : List Nat) : parseStringTail (linear_k34_0 ++ (34 :: 58 :: tail)) [] = some (linear_k34_0, 58 :: tail) := by rfl
def linear_k34_1 : List Nat := [111,112,115]
theorem mutated_kd34_1 : stringBytes linear_k34_1 = true := by decide +kernel
theorem mutated_kp34_1 (tail : List Nat) : parseStringTail (linear_k34_1 ++ (34 :: 58 :: tail)) [] = some (linear_k34_1, 58 :: tail) := by rfl
def linear_k34_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd34_2 : stringBytes linear_k34_2 = true := by decide +kernel
theorem mutated_kp34_2 (tail : List Nat) : parseStringTail (linear_k34_2 ++ (34 :: 58 :: tail)) [] = some (linear_k34_2, 58 :: tail) := by rfl
def linear_k34_3 : List Nat := [116,101,114,109]
theorem mutated_kd34_3 : stringBytes linear_k34_3 = true := by decide +kernel
theorem mutated_kp34_3 (tail : List Nat) : parseStringTail (linear_k34_3 ++ (34 :: 58 :: tail)) [] = some (linear_k34_3, 58 :: tail) := by rfl
def linear_l34_3 : List (List Nat × Raw) := [(linear_k34_3, linear_r38)]
def linear_v34_3 : List Nat := linear_g97 ++ linear_b38
theorem mutated_sl34_3 : serializeFields 4078 27 linear_l34_3 = some linear_v34_3 := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4077 27 linear_k34_3 linear_r38 linear_b38 mutated_kd34_3 mutated_s38)
theorem mutated_pl34_3 (tail : List Nat) : parseFields 4078 27 (linear_v34_3 ++ (125 :: tail)) = some (linear_l34_3, tail) := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4077 27 (linear_k34_3 ++ (34 :: 58 :: (linear_b38 ++ (125 :: tail)))) linear_k34_3 (linear_b38 ++ (125 :: tail)) tail linear_r38 (mutated_kp34_3 (linear_b38 ++ (125 :: tail))) (mutated_p38 (125 :: tail)))
def linear_l34_2 : List (List Nat × Raw) := (linear_k34_2, linear_r37) :: linear_l34_3
def linear_v34_2 : List Nat := (linear_g94 ++ linear_b37) ++ (44 :: linear_v34_3)
theorem mutated_sl34_2 : serializeFields 4079 27 linear_l34_2 = some linear_v34_2 := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k34_2 linear_r37 (linear_k34_3, linear_r38) [] linear_b37 linear_v34_3 mutated_kd34_2 mutated_s37 mutated_sl34_3)
theorem mutated_pl34_2 (tail : List Nat) : parseFields 4079 27 (linear_v34_2 ++ (125 :: tail)) = some (linear_l34_2, tail) := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k34_2 ++ (34 :: 58 :: (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))))) linear_k34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))) (linear_v34_3 ++ (125 :: tail)) tail linear_r37 linear_l34_3 (mutated_kp34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail))))) (mutated_p37 (44 :: (linear_v34_3 ++ (125 :: tail)))) (mutated_pl34_3 tail))
def linear_l34_1 : List (List Nat × Raw) := (linear_k34_1, linear_r36) :: linear_l34_2
def linear_v34_1 : List Nat := (linear_g91 ++ linear_b36) ++ (44 :: linear_v34_2)
theorem mutated_sl34_1 : serializeFields 4080 27 linear_l34_1 = some linear_v34_1 := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k34_1 linear_r36 (linear_k34_2, linear_r37) linear_l34_3 linear_b36 linear_v34_2 mutated_kd34_1 mutated_s36 mutated_sl34_2)
theorem mutated_pl34_1 (tail : List Nat) : parseFields 4080 27 (linear_v34_1 ++ (125 :: tail)) = some (linear_l34_1, tail) := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k34_1 ++ (34 :: 58 :: (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))))) linear_k34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))) (linear_v34_2 ++ (125 :: tail)) tail linear_r36 linear_l34_2 (mutated_kp34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail))))) (mutated_p36 (44 :: (linear_v34_2 ++ (125 :: tail)))) (mutated_pl34_2 tail))
def linear_l34_0 : List (List Nat × Raw) := (linear_k34_0, linear_r35) :: linear_l34_1
def linear_v34_0 : List Nat := (linear_g88 ++ linear_b35) ++ (44 :: linear_v34_1)
theorem mutated_sl34_0 : serializeFields 4081 27 linear_l34_0 = some linear_v34_0 := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k34_0 linear_r35 (linear_k34_1, linear_r36) linear_l34_2 linear_b35 linear_v34_1 mutated_kd34_0 mutated_s35 mutated_sl34_1)
theorem mutated_pl34_0 (tail : List Nat) : parseFields 4081 27 (linear_v34_0 ++ (125 :: tail)) = some (linear_l34_0, tail) := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) linear_k34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))) (linear_v34_1 ++ (125 :: tail)) tail linear_r35 linear_l34_1 (mutated_kp34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail))))) (mutated_p35 (44 :: (linear_v34_1 ++ (125 :: tail)))) (mutated_pl34_1 tail))
def linear_r34 : Raw := (.obj linear_l34_0)
def linear_b34 : List Nat := linear_g87 ++ (linear_v34_0 ++ linear_g99)
theorem mutated_o34 : orderedFields linear_l34_0 = true := by decide +kernel
theorem mutated_s34 : serializeRaw 4082 28 linear_r34 = some linear_b34 := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4081 27 linear_l34_0 linear_v34_0 mutated_o34 mutated_sl34_0)
theorem mutated_p34 (tail : List Nat) : parseRaw 4082 28 (linear_b34 ++ tail) = some (linear_r34, tail) := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4081 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) tail linear_l34_0 mutated_o34 (by simpa only [linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl34_0 tail)))
def linear_r40 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,54])
def linear_b40 : List Nat := linear_g103
theorem mutated_s40 : serializeRaw 4079 27 linear_r40 = some linear_b40 := by decide +kernel
theorem mutated_p40 (tail : List Nat) : parseRaw 4079 27 (linear_b40 ++ tail) = some (linear_r40, tail) := by rfl
def linear_r41 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b41 : List Nat := linear_g106
theorem mutated_s41 : serializeRaw 4078 27 linear_r41 = some linear_b41 := by decide +kernel
theorem mutated_p41 (tail : List Nat) : parseRaw 4078 27 (linear_b41 ++ tail) = some (linear_r41, tail) := by rfl
def linear_r42 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,53])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,54])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b42 : List Nat := linear_g109
theorem mutated_s42 : serializeRaw 4077 27 linear_r42 = some linear_b42 := by decide +kernel
theorem mutated_p42 (tail : List Nat) : parseRaw 4077 27 (linear_b42 ++ tail) = some (linear_r42, tail) := by rfl
def linear_r43 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,52,54])]))])
def linear_b43 : List Nat := linear_g112
theorem mutated_s43 : serializeRaw 4076 27 linear_r43 = some linear_b43 := by decide +kernel
theorem mutated_p43 (tail : List Nat) : parseRaw 4076 27 (linear_b43 ++ tail) = some (linear_r43, tail) := by rfl
def linear_k39_0 : List Nat := [105,100]
theorem mutated_kd39_0 : stringBytes linear_k39_0 = true := by decide +kernel
theorem mutated_kp39_0 (tail : List Nat) : parseStringTail (linear_k39_0 ++ (34 :: 58 :: tail)) [] = some (linear_k39_0, 58 :: tail) := by rfl
def linear_k39_1 : List Nat := [111,112,115]
theorem mutated_kd39_1 : stringBytes linear_k39_1 = true := by decide +kernel
theorem mutated_kp39_1 (tail : List Nat) : parseStringTail (linear_k39_1 ++ (34 :: 58 :: tail)) [] = some (linear_k39_1, 58 :: tail) := by rfl
def linear_k39_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd39_2 : stringBytes linear_k39_2 = true := by decide +kernel
theorem mutated_kp39_2 (tail : List Nat) : parseStringTail (linear_k39_2 ++ (34 :: 58 :: tail)) [] = some (linear_k39_2, 58 :: tail) := by rfl
def linear_k39_3 : List Nat := [116,101,114,109]
theorem mutated_kd39_3 : stringBytes linear_k39_3 = true := by decide +kernel
theorem mutated_kp39_3 (tail : List Nat) : parseStringTail (linear_k39_3 ++ (34 :: 58 :: tail)) [] = some (linear_k39_3, 58 :: tail) := by rfl
def linear_l39_3 : List (List Nat × Raw) := [(linear_k39_3, linear_r43)]
def linear_v39_3 : List Nat := linear_g111 ++ linear_b43
theorem mutated_sl39_3 : serializeFields 4077 27 linear_l39_3 = some linear_v39_3 := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4076 27 linear_k39_3 linear_r43 linear_b43 mutated_kd39_3 mutated_s43)
theorem mutated_pl39_3 (tail : List Nat) : parseFields 4077 27 (linear_v39_3 ++ (125 :: tail)) = some (linear_l39_3, tail) := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4076 27 (linear_k39_3 ++ (34 :: 58 :: (linear_b43 ++ (125 :: tail)))) linear_k39_3 (linear_b43 ++ (125 :: tail)) tail linear_r43 (mutated_kp39_3 (linear_b43 ++ (125 :: tail))) (mutated_p43 (125 :: tail)))
def linear_l39_2 : List (List Nat × Raw) := (linear_k39_2, linear_r42) :: linear_l39_3
def linear_v39_2 : List Nat := (linear_g108 ++ linear_b42) ++ (44 :: linear_v39_3)
theorem mutated_sl39_2 : serializeFields 4078 27 linear_l39_2 = some linear_v39_2 := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k39_2 linear_r42 (linear_k39_3, linear_r43) [] linear_b42 linear_v39_3 mutated_kd39_2 mutated_s42 mutated_sl39_3)
theorem mutated_pl39_2 (tail : List Nat) : parseFields 4078 27 (linear_v39_2 ++ (125 :: tail)) = some (linear_l39_2, tail) := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k39_2 ++ (34 :: 58 :: (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))))) linear_k39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))) (linear_v39_3 ++ (125 :: tail)) tail linear_r42 linear_l39_3 (mutated_kp39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail))))) (mutated_p42 (44 :: (linear_v39_3 ++ (125 :: tail)))) (mutated_pl39_3 tail))
def linear_l39_1 : List (List Nat × Raw) := (linear_k39_1, linear_r41) :: linear_l39_2
def linear_v39_1 : List Nat := (linear_g105 ++ linear_b41) ++ (44 :: linear_v39_2)
theorem mutated_sl39_1 : serializeFields 4079 27 linear_l39_1 = some linear_v39_1 := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k39_1 linear_r41 (linear_k39_2, linear_r42) linear_l39_3 linear_b41 linear_v39_2 mutated_kd39_1 mutated_s41 mutated_sl39_2)
theorem mutated_pl39_1 (tail : List Nat) : parseFields 4079 27 (linear_v39_1 ++ (125 :: tail)) = some (linear_l39_1, tail) := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k39_1 ++ (34 :: 58 :: (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))))) linear_k39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))) (linear_v39_2 ++ (125 :: tail)) tail linear_r41 linear_l39_2 (mutated_kp39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail))))) (mutated_p41 (44 :: (linear_v39_2 ++ (125 :: tail)))) (mutated_pl39_2 tail))
def linear_l39_0 : List (List Nat × Raw) := (linear_k39_0, linear_r40) :: linear_l39_1
def linear_v39_0 : List Nat := (linear_g102 ++ linear_b40) ++ (44 :: linear_v39_1)
theorem mutated_sl39_0 : serializeFields 4080 27 linear_l39_0 = some linear_v39_0 := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k39_0 linear_r40 (linear_k39_1, linear_r41) linear_l39_2 linear_b40 linear_v39_1 mutated_kd39_0 mutated_s40 mutated_sl39_1)
theorem mutated_pl39_0 (tail : List Nat) : parseFields 4080 27 (linear_v39_0 ++ (125 :: tail)) = some (linear_l39_0, tail) := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) linear_k39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))) (linear_v39_1 ++ (125 :: tail)) tail linear_r40 linear_l39_1 (mutated_kp39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail))))) (mutated_p40 (44 :: (linear_v39_1 ++ (125 :: tail)))) (mutated_pl39_1 tail))
def linear_r39 : Raw := (.obj linear_l39_0)
def linear_b39 : List Nat := linear_g101 ++ (linear_v39_0 ++ linear_g113)
theorem mutated_o39 : orderedFields linear_l39_0 = true := by decide +kernel
theorem mutated_s39 : serializeRaw 4081 28 linear_r39 = some linear_b39 := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4080 27 linear_l39_0 linear_v39_0 mutated_o39 mutated_sl39_0)
theorem mutated_p39 (tail : List Nat) : parseRaw 4081 28 (linear_b39 ++ tail) = some (linear_r39, tail) := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4080 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) tail linear_l39_0 mutated_o39 (by simpa only [linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl39_0 tail)))
def linear_r45 : Raw := (.str [100,103,95,102,97,115,116,95,48])
def linear_b45 : List Nat := linear_g117
theorem mutated_s45 : serializeRaw 4078 27 linear_r45 = some linear_b45 := by decide +kernel
theorem mutated_p45 (tail : List Nat) : parseRaw 4078 27 (linear_b45 ++ tail) = some (linear_r45, tail) := by rfl
def linear_r46 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,53]),(.str [100,103,95,118,95,53,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,54])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b46 : List Nat := linear_g120
theorem mutated_s46 : serializeRaw 4077 27 linear_r46 = some linear_b46 := by decide +kernel
theorem mutated_p46 (tail : List Nat) : parseRaw 4077 27 (linear_b46 ++ tail) = some (linear_r46, tail) := by rfl
def linear_r47 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b47 : List Nat := linear_g123
theorem mutated_s47 : serializeRaw 4076 27 linear_r47 = some linear_b47 := by decide +kernel
theorem mutated_p47 (tail : List Nat) : parseRaw 4076 27 (linear_b47 ++ tail) = some (linear_r47, tail) := by rfl
def linear_r48 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,53,54])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b48 : List Nat := linear_g126
theorem mutated_s48 : serializeRaw 4075 27 linear_r48 = some linear_b48 := by decide +kernel
theorem mutated_p48 (tail : List Nat) : parseRaw 4075 27 (linear_b48 ++ tail) = some (linear_r48, tail) := by rfl
def linear_k44_0 : List Nat := [105,100]
theorem mutated_kd44_0 : stringBytes linear_k44_0 = true := by decide +kernel
theorem mutated_kp44_0 (tail : List Nat) : parseStringTail (linear_k44_0 ++ (34 :: 58 :: tail)) [] = some (linear_k44_0, 58 :: tail) := by rfl
def linear_k44_1 : List Nat := [111,112,115]
theorem mutated_kd44_1 : stringBytes linear_k44_1 = true := by decide +kernel
theorem mutated_kp44_1 (tail : List Nat) : parseStringTail (linear_k44_1 ++ (34 :: 58 :: tail)) [] = some (linear_k44_1, 58 :: tail) := by rfl
def linear_k44_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd44_2 : stringBytes linear_k44_2 = true := by decide +kernel
theorem mutated_kp44_2 (tail : List Nat) : parseStringTail (linear_k44_2 ++ (34 :: 58 :: tail)) [] = some (linear_k44_2, 58 :: tail) := by rfl
def linear_k44_3 : List Nat := [116,101,114,109]
theorem mutated_kd44_3 : stringBytes linear_k44_3 = true := by decide +kernel
theorem mutated_kp44_3 (tail : List Nat) : parseStringTail (linear_k44_3 ++ (34 :: 58 :: tail)) [] = some (linear_k44_3, 58 :: tail) := by rfl
def linear_l44_3 : List (List Nat × Raw) := [(linear_k44_3, linear_r48)]
def linear_v44_3 : List Nat := linear_g125 ++ linear_b48
theorem mutated_sl44_3 : serializeFields 4076 27 linear_l44_3 = some linear_v44_3 := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4075 27 linear_k44_3 linear_r48 linear_b48 mutated_kd44_3 mutated_s48)
theorem mutated_pl44_3 (tail : List Nat) : parseFields 4076 27 (linear_v44_3 ++ (125 :: tail)) = some (linear_l44_3, tail) := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4075 27 (linear_k44_3 ++ (34 :: 58 :: (linear_b48 ++ (125 :: tail)))) linear_k44_3 (linear_b48 ++ (125 :: tail)) tail linear_r48 (mutated_kp44_3 (linear_b48 ++ (125 :: tail))) (mutated_p48 (125 :: tail)))
def linear_l44_2 : List (List Nat × Raw) := (linear_k44_2, linear_r47) :: linear_l44_3
def linear_v44_2 : List Nat := (linear_g122 ++ linear_b47) ++ (44 :: linear_v44_3)
theorem mutated_sl44_2 : serializeFields 4077 27 linear_l44_2 = some linear_v44_2 := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k44_2 linear_r47 (linear_k44_3, linear_r48) [] linear_b47 linear_v44_3 mutated_kd44_2 mutated_s47 mutated_sl44_3)
theorem mutated_pl44_2 (tail : List Nat) : parseFields 4077 27 (linear_v44_2 ++ (125 :: tail)) = some (linear_l44_2, tail) := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k44_2 ++ (34 :: 58 :: (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))))) linear_k44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))) (linear_v44_3 ++ (125 :: tail)) tail linear_r47 linear_l44_3 (mutated_kp44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail))))) (mutated_p47 (44 :: (linear_v44_3 ++ (125 :: tail)))) (mutated_pl44_3 tail))
def linear_l44_1 : List (List Nat × Raw) := (linear_k44_1, linear_r46) :: linear_l44_2
def linear_v44_1 : List Nat := (linear_g119 ++ linear_b46) ++ (44 :: linear_v44_2)
theorem mutated_sl44_1 : serializeFields 4078 27 linear_l44_1 = some linear_v44_1 := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k44_1 linear_r46 (linear_k44_2, linear_r47) linear_l44_3 linear_b46 linear_v44_2 mutated_kd44_1 mutated_s46 mutated_sl44_2)
theorem mutated_pl44_1 (tail : List Nat) : parseFields 4078 27 (linear_v44_1 ++ (125 :: tail)) = some (linear_l44_1, tail) := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k44_1 ++ (34 :: 58 :: (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))))) linear_k44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))) (linear_v44_2 ++ (125 :: tail)) tail linear_r46 linear_l44_2 (mutated_kp44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail))))) (mutated_p46 (44 :: (linear_v44_2 ++ (125 :: tail)))) (mutated_pl44_2 tail))
def linear_l44_0 : List (List Nat × Raw) := (linear_k44_0, linear_r45) :: linear_l44_1
def linear_v44_0 : List Nat := (linear_g116 ++ linear_b45) ++ (44 :: linear_v44_1)
theorem mutated_sl44_0 : serializeFields 4079 27 linear_l44_0 = some linear_v44_0 := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k44_0 linear_r45 (linear_k44_1, linear_r46) linear_l44_2 linear_b45 linear_v44_1 mutated_kd44_0 mutated_s45 mutated_sl44_1)
theorem mutated_pl44_0 (tail : List Nat) : parseFields 4079 27 (linear_v44_0 ++ (125 :: tail)) = some (linear_l44_0, tail) := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) linear_k44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))) (linear_v44_1 ++ (125 :: tail)) tail linear_r45 linear_l44_1 (mutated_kp44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail))))) (mutated_p45 (44 :: (linear_v44_1 ++ (125 :: tail)))) (mutated_pl44_1 tail))
def linear_r44 : Raw := (.obj linear_l44_0)
def linear_b44 : List Nat := linear_g115 ++ (linear_v44_0 ++ linear_g127)
theorem mutated_o44 : orderedFields linear_l44_0 = true := by decide +kernel
theorem mutated_s44 : serializeRaw 4080 28 linear_r44 = some linear_b44 := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4079 27 linear_l44_0 linear_v44_0 mutated_o44 mutated_sl44_0)
theorem mutated_p44 (tail : List Nat) : parseRaw 4080 28 (linear_b44 ++ tail) = some (linear_r44, tail) := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4079 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) tail linear_l44_0 mutated_o44 (by simpa only [linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl44_0 tail)))
def linear_r50 : Raw := (.str [100,103,95,102,97,115,116,95,49])
def linear_b50 : List Nat := linear_g131
theorem mutated_s50 : serializeRaw 4077 27 linear_r50 = some linear_b50 := by decide +kernel
theorem mutated_p50 (tail : List Nat) : parseRaw 4077 27 (linear_b50 ++ tail) = some (linear_r50, tail) := by rfl
def linear_r52 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,50])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b52 : List Nat := linear_g135
theorem mutated_s52 : serializeRaw 4074 26 linear_r52 = some linear_b52 := by decide +kernel
theorem mutated_p52 (tail : List Nat) : parseRaw 4074 26 (linear_b52 ++ tail) = some (linear_r52, tail) := by rfl
def linear_r53 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,50]),(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,51])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b53 : List Nat := linear_g137
theorem mutated_s53 : serializeRaw 4073 26 linear_r53 = some linear_b53 := by decide +kernel
theorem mutated_p53 (tail : List Nat) : parseRaw 4073 26 (linear_b53 ++ tail) = some (linear_r53, tail) := by rfl
def linear_r54 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,52])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b54 : List Nat := linear_g139
theorem mutated_s54 : serializeRaw 4072 26 linear_r54 = some linear_b54 := by decide +kernel
theorem mutated_p54 (tail : List Nat) : parseRaw 4072 26 (linear_b54 ++ tail) = some (linear_r54, tail) := by rfl
def linear_r55 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b55 : List Nat := linear_g141
theorem mutated_s55 : serializeRaw 4071 26 linear_r55 = some linear_b55 := by decide +kernel
theorem mutated_p55 (tail : List Nat) : parseRaw 4071 26 (linear_b55 ++ tail) = some (linear_r55, tail) := by rfl
def linear_r56 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,52]),(.str [100,103,95,118,95,54,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,54])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b56 : List Nat := linear_g143
theorem mutated_s56 : serializeRaw 4070 26 linear_r56 = some linear_b56 := by decide +kernel
theorem mutated_p56 (tail : List Nat) : parseRaw 4070 26 (linear_b56 ++ tail) = some (linear_r56, tail) := by rfl
def linear_r57 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,54])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b57 : List Nat := linear_g145
theorem mutated_s57 : serializeRaw 4069 26 linear_r57 = some linear_b57 := by decide +kernel
theorem mutated_p57 (tail : List Nat) : parseRaw 4069 26 (linear_b57 ++ tail) = some (linear_r57, tail) := by rfl
def linear_r58 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,56])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b58 : List Nat := linear_g147
theorem mutated_s58 : serializeRaw 4068 26 linear_r58 = some linear_b58 := by decide +kernel
theorem mutated_p58 (tail : List Nat) : parseRaw 4068 26 (linear_b58 ++ tail) = some (linear_r58, tail) := by rfl
def linear_r59 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56]),(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b59 : List Nat := linear_g149
theorem mutated_s59 : serializeRaw 4067 26 linear_r59 = some linear_b59 := by decide +kernel
theorem mutated_p59 (tail : List Nat) : parseRaw 4067 26 (linear_b59 ++ tail) = some (linear_r59, tail) := by rfl
def linear_r60 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b60 : List Nat := linear_g151
theorem mutated_s60 : serializeRaw 4066 26 linear_r60 = some linear_b60 := by decide +kernel
theorem mutated_p60 (tail : List Nat) : parseRaw 4066 26 (linear_b60 ++ tail) = some (linear_r60, tail) := by rfl
def linear_r61 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 2))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b61 : List Nat := linear_g153
theorem mutated_s61 : serializeRaw 4065 26 linear_r61 = some linear_b61 := by decide +kernel
theorem mutated_p61 (tail : List Nat) : parseRaw 4065 26 (linear_b61 ++ tail) = some (linear_r61, tail) := by rfl
def linear_r62 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b62 : List Nat := linear_g155
theorem mutated_s62 : serializeRaw 4064 26 linear_r62 = some linear_b62 := by decide +kernel
theorem mutated_p62 (tail : List Nat) : parseRaw 4064 26 (linear_b62 ++ tail) = some (linear_r62, tail) := by rfl
def linear_l51_10 : List Raw := [linear_r62]
def linear_v51_10 : List Nat := linear_b62
theorem mutated_sl51_10 : serializeItems 4065 26 linear_l51_10 = some linear_v51_10 := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4064 26 linear_r62 linear_b62 mutated_s62)
theorem mutated_pl51_10 (tail : List Nat) : parseItems 4065 26 (linear_v51_10 ++ (93 :: tail)) = some (linear_l51_10, tail) := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4064 26 (linear_b62 ++ (93 :: tail)) tail linear_r62 (mutated_p62 (93 :: tail)))
def linear_l51_9 : List Raw := linear_r61 :: linear_l51_10
def linear_v51_9 : List Nat := (linear_b61) ++ (44 :: linear_v51_10)
theorem mutated_sl51_9 : serializeItems 4066 26 linear_l51_9 = some linear_v51_9 := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r61 linear_r62 [] linear_b61 linear_v51_10 mutated_s61 mutated_sl51_10)
theorem mutated_pl51_9 (tail : List Nat) : parseItems 4066 26 (linear_v51_9 ++ (93 :: tail)) = some (linear_l51_9, tail) := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b61 ++ (44 :: (linear_v51_10 ++ (93 :: tail)))) (linear_v51_10 ++ (93 :: tail)) tail linear_r61 linear_l51_10 (mutated_p61 (44 :: (linear_v51_10 ++ (93 :: tail)))) (mutated_pl51_10 tail))
def linear_l51_8 : List Raw := linear_r60 :: linear_l51_9
def linear_v51_8 : List Nat := (linear_b60) ++ (44 :: linear_v51_9)
theorem mutated_sl51_8 : serializeItems 4067 26 linear_l51_8 = some linear_v51_8 := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r60 linear_r61 linear_l51_10 linear_b60 linear_v51_9 mutated_s60 mutated_sl51_9)
theorem mutated_pl51_8 (tail : List Nat) : parseItems 4067 26 (linear_v51_8 ++ (93 :: tail)) = some (linear_l51_8, tail) := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b60 ++ (44 :: (linear_v51_9 ++ (93 :: tail)))) (linear_v51_9 ++ (93 :: tail)) tail linear_r60 linear_l51_9 (mutated_p60 (44 :: (linear_v51_9 ++ (93 :: tail)))) (mutated_pl51_9 tail))
def linear_l51_7 : List Raw := linear_r59 :: linear_l51_8
def linear_v51_7 : List Nat := (linear_b59) ++ (44 :: linear_v51_8)
theorem mutated_sl51_7 : serializeItems 4068 26 linear_l51_7 = some linear_v51_7 := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r59 linear_r60 linear_l51_9 linear_b59 linear_v51_8 mutated_s59 mutated_sl51_8)
theorem mutated_pl51_7 (tail : List Nat) : parseItems 4068 26 (linear_v51_7 ++ (93 :: tail)) = some (linear_l51_7, tail) := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b59 ++ (44 :: (linear_v51_8 ++ (93 :: tail)))) (linear_v51_8 ++ (93 :: tail)) tail linear_r59 linear_l51_8 (mutated_p59 (44 :: (linear_v51_8 ++ (93 :: tail)))) (mutated_pl51_8 tail))
def linear_l51_6 : List Raw := linear_r58 :: linear_l51_7
def linear_v51_6 : List Nat := (linear_b58) ++ (44 :: linear_v51_7)
theorem mutated_sl51_6 : serializeItems 4069 26 linear_l51_6 = some linear_v51_6 := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r58 linear_r59 linear_l51_8 linear_b58 linear_v51_7 mutated_s58 mutated_sl51_7)
theorem mutated_pl51_6 (tail : List Nat) : parseItems 4069 26 (linear_v51_6 ++ (93 :: tail)) = some (linear_l51_6, tail) := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b58 ++ (44 :: (linear_v51_7 ++ (93 :: tail)))) (linear_v51_7 ++ (93 :: tail)) tail linear_r58 linear_l51_7 (mutated_p58 (44 :: (linear_v51_7 ++ (93 :: tail)))) (mutated_pl51_7 tail))
def linear_l51_5 : List Raw := linear_r57 :: linear_l51_6
def linear_v51_5 : List Nat := (linear_b57) ++ (44 :: linear_v51_6)
theorem mutated_sl51_5 : serializeItems 4070 26 linear_l51_5 = some linear_v51_5 := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r57 linear_r58 linear_l51_7 linear_b57 linear_v51_6 mutated_s57 mutated_sl51_6)
theorem mutated_pl51_5 (tail : List Nat) : parseItems 4070 26 (linear_v51_5 ++ (93 :: tail)) = some (linear_l51_5, tail) := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b57 ++ (44 :: (linear_v51_6 ++ (93 :: tail)))) (linear_v51_6 ++ (93 :: tail)) tail linear_r57 linear_l51_6 (mutated_p57 (44 :: (linear_v51_6 ++ (93 :: tail)))) (mutated_pl51_6 tail))
def linear_l51_4 : List Raw := linear_r56 :: linear_l51_5
def linear_v51_4 : List Nat := (linear_b56) ++ (44 :: linear_v51_5)
theorem mutated_sl51_4 : serializeItems 4071 26 linear_l51_4 = some linear_v51_4 := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r56 linear_r57 linear_l51_6 linear_b56 linear_v51_5 mutated_s56 mutated_sl51_5)
theorem mutated_pl51_4 (tail : List Nat) : parseItems 4071 26 (linear_v51_4 ++ (93 :: tail)) = some (linear_l51_4, tail) := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b56 ++ (44 :: (linear_v51_5 ++ (93 :: tail)))) (linear_v51_5 ++ (93 :: tail)) tail linear_r56 linear_l51_5 (mutated_p56 (44 :: (linear_v51_5 ++ (93 :: tail)))) (mutated_pl51_5 tail))
def linear_l51_3 : List Raw := linear_r55 :: linear_l51_4
def linear_v51_3 : List Nat := (linear_b55) ++ (44 :: linear_v51_4)
theorem mutated_sl51_3 : serializeItems 4072 26 linear_l51_3 = some linear_v51_3 := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r55 linear_r56 linear_l51_5 linear_b55 linear_v51_4 mutated_s55 mutated_sl51_4)
theorem mutated_pl51_3 (tail : List Nat) : parseItems 4072 26 (linear_v51_3 ++ (93 :: tail)) = some (linear_l51_3, tail) := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b55 ++ (44 :: (linear_v51_4 ++ (93 :: tail)))) (linear_v51_4 ++ (93 :: tail)) tail linear_r55 linear_l51_4 (mutated_p55 (44 :: (linear_v51_4 ++ (93 :: tail)))) (mutated_pl51_4 tail))
def linear_l51_2 : List Raw := linear_r54 :: linear_l51_3
def linear_v51_2 : List Nat := (linear_b54) ++ (44 :: linear_v51_3)
theorem mutated_sl51_2 : serializeItems 4073 26 linear_l51_2 = some linear_v51_2 := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 26 linear_r54 linear_r55 linear_l51_4 linear_b54 linear_v51_3 mutated_s54 mutated_sl51_3)
theorem mutated_pl51_2 (tail : List Nat) : parseItems 4073 26 (linear_v51_2 ++ (93 :: tail)) = some (linear_l51_2, tail) := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 26 (linear_b54 ++ (44 :: (linear_v51_3 ++ (93 :: tail)))) (linear_v51_3 ++ (93 :: tail)) tail linear_r54 linear_l51_3 (mutated_p54 (44 :: (linear_v51_3 ++ (93 :: tail)))) (mutated_pl51_3 tail))
def linear_l51_1 : List Raw := linear_r53 :: linear_l51_2
def linear_v51_1 : List Nat := (linear_b53) ++ (44 :: linear_v51_2)
theorem mutated_sl51_1 : serializeItems 4074 26 linear_l51_1 = some linear_v51_1 := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 26 linear_r53 linear_r54 linear_l51_3 linear_b53 linear_v51_2 mutated_s53 mutated_sl51_2)
theorem mutated_pl51_1 (tail : List Nat) : parseItems 4074 26 (linear_v51_1 ++ (93 :: tail)) = some (linear_l51_1, tail) := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 26 (linear_b53 ++ (44 :: (linear_v51_2 ++ (93 :: tail)))) (linear_v51_2 ++ (93 :: tail)) tail linear_r53 linear_l51_2 (mutated_p53 (44 :: (linear_v51_2 ++ (93 :: tail)))) (mutated_pl51_2 tail))
def linear_l51_0 : List Raw := linear_r52 :: linear_l51_1
def linear_v51_0 : List Nat := (linear_b52) ++ (44 :: linear_v51_1)
theorem mutated_sl51_0 : serializeItems 4075 26 linear_l51_0 = some linear_v51_0 := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 26 linear_r52 linear_r53 linear_l51_2 linear_b52 linear_v51_1 mutated_s52 mutated_sl51_1)
theorem mutated_pl51_0 (tail : List Nat) : parseItems 4075 26 (linear_v51_0 ++ (93 :: tail)) = some (linear_l51_0, tail) := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 26 (linear_b52 ++ (44 :: (linear_v51_1 ++ (93 :: tail)))) (linear_v51_1 ++ (93 :: tail)) tail linear_r52 linear_l51_1 (mutated_p52 (44 :: (linear_v51_1 ++ (93 :: tail)))) (mutated_pl51_1 tail))
def linear_r51 : Raw := (.arr linear_l51_0)
def linear_b51 : List Nat := linear_g134 ++ (linear_v51_0 ++ linear_g156)
theorem mutated_s51 : serializeRaw 4076 27 linear_r51 = some linear_b51 := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4075 26 linear_l51_0 linear_v51_0 mutated_sl51_0)
theorem mutated_p51 (tail : List Nat) : parseRaw 4076 27 (linear_b51 ++ tail) = some (linear_r51, tail) := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4075 26 (linear_v51_0 ++ (93 :: tail)) tail linear_l51_0 (by intro h; cases h) (mutated_pl51_0 tail))
end HiaCoreSyntaxSlice.LiteralTwo
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd10_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd10_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd10_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd10_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd15_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd15_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd15_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd15_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd24_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd24_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd24_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd24_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd29_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd29_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd29_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd29_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd34_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd34_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd34_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd34_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd39_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd39_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd39_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd39_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd44_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd44_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd44_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd44_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd5_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd5_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd5_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd5_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp10_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp10_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp10_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp10_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp15_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp15_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp15_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp15_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp24_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp24_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp24_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp24_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp29_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp29_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp29_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp29_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp34_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp34_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp34_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp34_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp39_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp39_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp39_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp39_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp44_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp44_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp44_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp44_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp5_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp5_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp5_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp5_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o15
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o24
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o29
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o34
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o39
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o44
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p11
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p12
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p13
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p14
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p15
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p16
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p17
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p18
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p19
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p20
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p21
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p22
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p23
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p24
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p25
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p26
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p27
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p28
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p29
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p30
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p31
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p32
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p33
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p34
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p35
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p36
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p37
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p38
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p39
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p40
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p41
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p42
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p43
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p44
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p45
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p46
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p47
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p48
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p50
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p51
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p52
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p53
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p54
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p55
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p56
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p57
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p58
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p59
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p60
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p61
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p62
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl10_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl10_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl10_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl10_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl15_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl15_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl15_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl15_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl17_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl17_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl17_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl17_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl24_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl24_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl24_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl24_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl29_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl29_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl29_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl29_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl34_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl34_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl34_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl34_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl39_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl39_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl39_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl39_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl44_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl44_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl44_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl44_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl51_9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl5_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl5_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl5_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl5_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s11
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s12
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s13
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s14
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s15
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s16
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s17
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s18
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s19
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s20
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s21
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s22
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s23
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s24
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s25
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s26
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s27
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s28
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s29
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s30
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s31
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s32
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s33
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s34
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s35
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s36
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s37
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s38
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s39
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s40
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s41
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s42
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s43
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s44
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s45
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s46
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s47
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s48
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s50
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s51
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s52
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s53
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s54
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s55
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s56
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s57
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s58
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s59
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s60
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s61
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s62
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl10_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl10_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl10_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl10_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl15_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl15_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl15_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl15_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl17_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl17_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl17_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl17_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl24_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl24_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl24_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl24_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl29_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl29_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl29_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl29_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl34_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl34_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl34_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl34_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl39_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl39_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl39_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl39_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl44_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl44_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl44_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl44_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl51_9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl5_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl5_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl5_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl5_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_bounds
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_byte_range
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd0_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd0_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd0_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd0_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd113_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd113_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd113_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd113_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd118_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd118_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd118_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd118_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd123_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd123_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd123_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd123_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd135_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd135_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd135_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd135_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd140_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd140_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd140_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd140_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd145_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd145_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd145_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd145_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd3_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd3_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd3_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd3_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd3_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd3_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd87_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd87_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd87_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd92_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd92_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd92_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd92_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd97_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd97_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd97_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd97_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp0_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp0_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp0_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp0_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp113_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp113_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp113_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp113_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp118_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp118_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp118_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp118_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp123_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp123_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp123_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp123_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp135_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp135_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp135_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp135_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp140_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp140_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp140_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp140_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp145_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp145_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp145_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp145_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp3_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp3_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp3_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp3_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp3_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp3_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp87_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp87_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp87_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp87_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp92_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp92_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp92_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp92_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp97_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp97_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp97_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp97_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_length
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o113
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o118
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o123
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o135
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o140
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o145
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o87
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o92
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o97
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p100
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p101
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p102
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p103
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p104
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p105
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p106
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p107
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p108
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p109
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p110
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p111
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p112
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p113
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p114
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p115
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p116
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p117
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p118
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p119
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p120
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p121
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p122
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p123
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p124
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p125
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p126
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p127
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p128
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p129
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p130
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p131
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p132
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p133
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p134
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p135
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p136
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p137
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p138
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p139
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p140
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p141
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p142
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p143
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p144
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p145
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p146
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p147
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p148
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p149
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p150
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p151
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p152
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p153
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p154
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p155
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p156
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p87
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p92
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p93
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p94
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p95
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p96
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p97
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p98
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p99
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_parsed
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl0_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl0_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl0_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl0_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl113_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl113_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl113_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl113_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl118_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl118_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl118_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl118_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl123_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl123_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl123_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl123_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl125_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl135_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl135_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl135_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl135_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl140_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl140_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl140_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl140_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl145_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl145_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl145_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl145_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl2_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl3_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl3_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl3_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl3_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl3_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl3_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_11
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_12
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_13
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_14
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_15
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_16
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_17
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_18
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_19
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_20
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl4_9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl87_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl87_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl87_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl87_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl92_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl92_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl92_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl92_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl97_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl97_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl97_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl97_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl99_9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s100
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s101
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s102
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s103
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s104
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s105
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s106
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s107
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s108
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s109
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s110
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s111
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s112
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s113
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s114
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s115
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s116
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s117
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s118
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s119
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s120
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s121
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s122
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s123
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s124
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s125
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s126
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s127
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s128
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s129
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s130
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s131
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s132
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s133
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s134
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s135
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s136
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s137
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s138
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s139
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s140
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s141
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s142
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s143
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s144
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s145
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s146
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s147
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s148
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s149
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s150
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s151
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s152
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s153
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s154
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s155
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s156
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s87
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s92
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s93
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s94
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s95
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s96
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s97
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s98
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s99
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_serialized
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl0_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl0_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl0_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl0_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl113_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl113_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl113_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl113_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl118_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl118_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl118_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl118_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl123_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl123_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl123_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl123_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl125_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl135_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl135_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl135_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl135_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl140_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl140_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl140_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl140_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl145_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl145_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl145_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl145_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl2_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl3_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl3_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl3_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl3_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl3_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl3_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_11
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_12
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_13
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_14
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_15
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_16
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_17
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_18
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_19
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_20
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl4_9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl87_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl87_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl87_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl87_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl92_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl92_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl92_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl92_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl97_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl97_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl97_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl97_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl99_9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_transport
