"""Reproduce a delayed, transiently unavailable real stderr EOF during cleanup."""
from pathlib import Path
import errno
import json
import shutil
import subprocess
import sys
import time
from unittest.mock import patch
from contextlib import ExitStack

sys.path.insert(0, str(Path.cwd()))
from tests.test_core_seven_relocation_runner import Part04RunnerTests, collector

destination = Path(sys.argv[1])
destination.mkdir(parents=True, exist_ok=False)
Part04RunnerTests.setUpClass()
case = Part04RunnerTests("test_complete_failure_replay_and_spawn_semantics")
real_killpg, real_read, real_popen = collector.os.killpg, collector.os.read, subprocess.Popen
state = {"signals": [], "paused": False}

def popen(argv, **kwargs):
    child = real_popen(argv, **kwargs)
    state["stderr_fd"] = child.stderr.fileno()
    return child

def killpg(pid, sig):
    real_killpg(pid, sig)
    state["signals"].append([pid, int(sig)])

def read(fd, size):
    if state["signals"] and fd == state.get("stderr_fd") and not state["paused"]:
        state["paused"] = True
        time.sleep(0.04)
        raise BlockingIOError(errno.EAGAIN, "controlled transient cleanup readiness")
    return real_read(fd, size)

def inspect(path, report, identity, support):
    shutil.copytree(path, destination / "capture")
    verified = case.replay(path, identity, support)
    observation = {
        "validated_markers": verified["validated_markers"],
        "validated_parent_count": verified["validated_parent_count"],
        "status": report["status"],
        "process": report["stages"][-1]["process"],
        "controlled_cleanup_read_delay_seconds": 0.04,
        "fault": state,
    }
    (destination / "observation.json").write_text(json.dumps(observation, indent=2) + "\n")
    print(json.dumps(observation, indent=2), flush=True)
    case.assertTrue(state["paused"])
    case.assertTrue(verified["validated_markers"])

started = time.monotonic()
with ExitStack() as stack:
    stack.enter_context(patch.object(collector.subprocess, "Popen", side_effect=popen))
    stack.enter_context(patch.object(collector.os, "killpg", side_effect=killpg))
    stack.enter_context(patch.object(collector.os, "read", side_effect=read))
    case.exercise("target_timeout", inspect)
print(json.dumps({"elapsed_seconds": time.monotonic() - started}), flush=True)
