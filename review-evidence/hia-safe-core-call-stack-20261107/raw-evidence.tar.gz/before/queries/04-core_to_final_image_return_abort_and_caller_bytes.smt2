(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (not (bvule ((_ extract 31 0) abi_word_0)
                       (bvadd ((_ extract 31 0) abi_word_0)
                              ((_ extract 31 0) abi_word_1)))))
      (a!2 ((_ extract 63 32)
             (bvadd (concat #x00000000 ((_ extract 31 0) abi_word_0))
                    (concat #x00000000 ((_ extract 31 0) abi_word_1)))))
      (a!4 (= ((_ extract 31 0) abi_word_0)
              (bvadd #xffffffff
                     (bvmul #xffffffff ((_ extract 31 0) abi_word_1)))))
      (a!5 (bvadd #x00000000ffffffff
                  (bvmul #xffffffffffffffff
                         (concat #x00000000 ((_ extract 31 0) abi_word_1))))))
(let ((a!3 (or (not (= a!2 #x00000000))
               (bvule ((_ extract 31 0) abi_word_0)
                      (bvadd ((_ extract 31 0) abi_word_0)
                             ((_ extract 31 0) abi_word_1)))))
      (a!6 (not (= (concat #x00000000 ((_ extract 31 0) abi_word_0)) a!5)))
      (a!8 (ite (bvule ((_ extract 31 0) abi_word_0)
                       (bvadd ((_ extract 31 0) abi_word_0)
                              ((_ extract 31 0) abi_word_1)))
                (concat #x00000000
                        (bvadd ((_ extract 31 0) abi_word_0)
                               ((_ extract 31 0) abi_word_1)))
                (ite a!1 #x0000000000000000 #x0000000000000000)))
      (a!12 (ite (bvule ((_ extract 31 0) abi_word_0)
                        (bvadd ((_ extract 31 0) abi_word_0)
                               ((_ extract 31 0) abi_word_1)))
                 initial_caller_bytes
                 (ite a!1 initial_caller_bytes initial_caller_bytes))))
(let ((a!7 (and a!3 (or (not (= a!2 #x00000000)) a!4) a!6))
      (a!9 (and (or (not (= a!2 #x00000000)) a!4) a!6)))
(let ((a!10 (ite (and a!3 (not a!9))
                 (concat #x00000000
                         (bvadd ((_ extract 31 0) abi_word_0)
                                ((_ extract 31 0) abi_word_1)))
                 #x0000000000000000))
      (a!13 (ite a!7
                 initial_caller_bytes
                 (ite (and a!3 (not a!9))
                      initial_caller_bytes
                      initial_caller_bytes))))
(let ((a!11 (and (not (or a!1 false))
                 (distinct a!8
                           (ite (not a!3)
                                #x0000000000000000
                                (ite a!7 #x0000000000000000 a!10))))))
  (or (distinct (or a!1 false) (or a!7 (not a!3) false))
      a!11
      (distinct a!12 (ite (not a!3) initial_caller_bytes a!13)))))))))

(check-sat)
