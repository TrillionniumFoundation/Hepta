(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 ((_ extract 63 32)
             (bvadd (concat #x00000000 ((_ extract 31 0) abi_word_0))
                    (concat #x00000000 ((_ extract 31 0) abi_word_1)))))
      (a!3 (= ((_ extract 31 0) abi_word_0)
              (bvadd #xffffffff
                     (bvmul #xffffffff ((_ extract 31 0) abi_word_1)))))
      (a!4 (bvadd #x00000000ffffffff
                  (bvmul #xffffffffffffffff
                         (concat #x00000000 ((_ extract 31 0) abi_word_1))))))
(let ((a!2 (or (not (= a!1 #x00000000))
               (bvule ((_ extract 31 0) abi_word_0)
                      (bvadd ((_ extract 31 0) abi_word_0)
                             ((_ extract 31 0) abi_word_1)))))
      (a!5 (not (= (concat #x00000000 ((_ extract 31 0) abi_word_0)) a!4))))
(let ((a!6 (and a!2 (or (not (= a!1 #x00000000)) a!3) a!5)))
  (or a!6 (not a!2) false)))))

(check-sat)
