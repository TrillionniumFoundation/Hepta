import pathlib,hashlib,json,tarfile,sys,io,os
base=pathlib.Path('/home/qian-qi/hia-core-three-ad419-development-20261127-2ac5')
names=('manifest-owner-native-v2','worker-framer-native-v1')
files=[]
for name in names:
 for p in sorted((base/name).rglob('*')):
  if p.is_symlink():raise ValueError('unexpected symlink')
  if p.is_file():
   raw=p.read_bytes();files.append((p,raw,{'path':str(p.relative_to(base)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':p.stat().st_mode&0o777}))
index=json.dumps({'schema':'hepta.hia.core-companion-development-custody.v1','scope':'DEVELOPMENT_ONLY','matching_cold_qualified':False,'files':[v[2] for v in files]},sort_keys=True,indent=2).encode()+b'\n'
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as tar:
 info=tarfile.TarInfo('custody-index.json');info.size=len(index);info.mode=0o600;tar.addfile(info,io.BytesIO(index))
 for p,raw,row in files:
  if p.read_bytes()!=raw:raise ValueError('source evidence changed')
  info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=row['mode'];tar.addfile(info,io.BytesIO(raw))
for p,raw,row in files:
 if p.read_bytes()!=raw:raise ValueError('evidence changed after archive')
