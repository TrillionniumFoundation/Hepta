import pathlib,subprocess,hashlib,json,gzip,os,stat
os.umask(0o022)
r=pathlib.Path('/Users/qianqi/work/hepta-core-three-native-20261127-2ac5/source');q=r.parent/'qualification'
def git(*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=r)
assert git('rev-parse','HEAD').decode().strip()=='69a7a0c0db9978d81f98b5a626ed09822159fc44'
source_control=json.loads((q/'core-native-release-source-controls-v1/terminal.json').read_bytes());assert source_control['returncode']==0 and source_control['source_unchanged'] is True
for name in ('core-companion-native-custody-v1','core-companion-native-custody-v2'):
 row=json.loads((q/name/'readback.json').read_bytes());assert row['verified'] is True and row['returncode']==0
source_paths=[
'tools/generate_hia_core_companion_manifest.py','tools/generate_hia_core_companion_stage.py',
'tools/hia_core_companion_release.py','tools/generate_hia_core_companion_recipe.py',
'tools/hia_core_companion_worker_recipe.py','tools/generate_hia_core_companion_worker_manifest.py',
'tools/build_hia_core_companion_worker.py','tools/build_hia_native_store_release.py',
'tools/build_hia_worker_release.py','tools/generate_hia_release_owner.py',
'tools/generate_hia_worker_install_recipes.py','tools/generate_hia_worker_install_bind.py',
'examples/hia_bootstrap/source_core_companion_manifest.hepta',
'examples/hia_bootstrap/source_core_companion_stage.hepta',
'examples/hia_bootstrap/source_core_companion_worker_manifest.hepta',
'examples/hia_bootstrap/core_companion_worker_manifest_tables.hiastd',
'examples/hia_bootstrap/release_stage_core_companions.hiastd',
'examples/hia_bootstrap/source_worker_install_bind.hepta',
'examples/hia_bootstrap/worker_install_report.hiastd',
'examples/hia_bootstrap/worker_install_profile.hiastd',
'docs/HIA_CORE_COMPANION_WORKER_MANIFEST_RECORDS.json',
'tests/test_hia_core_companion_release_source.py']
for name in source_paths:
 p=r/name;assert p.is_file() and not p.is_symlink();assert p.stat().st_mode&0o777==0o644,(name,oct(p.stat().st_mode))
dest=r/'review-evidence/hia-core-companion-native-release-20261127-2ac5';dest.mkdir(parents=True)
folders=('core3-native-manifest-author-v1','core3-native-manifest-author-v2','core3-native-manifest-author-v3',
'core-companion-checker-author-v1','core3-root7c-and-checker-v2',
'core-companion-manifest-native-v1','core-companion-manifest-native-v2',
'core-companion-checker-native-v1','core-worker-framer-native-v1',
'core-companion-native-custody-v1','core-companion-native-custody-v2',
'core-native-release-wiring-v1','core-native-release-generation-v1',
'core-native-release-source-controls-v1')
index=[]
for folder in folders:
 base=q/folder;assert base.is_dir()
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file() or p.name.startswith('.hepta-lock'):continue
  raw=p.read_bytes();assert len(raw)<32*1024*1024,(p,len(raw))
  relative=p.relative_to(q);compressed=not p.name.endswith(('.tar.gz','.gz'))
  stored=gzip.compress(raw,mtime=0) if compressed else raw
  target=dest/'raw'/str(relative)
  if compressed:target=target.with_name(target.name+'.gz')
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored)
  assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes())==raw
  index.append({'original':str(relative),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stored':str(target.relative_to(dest)),'stored_bytes':len(stored),'stored_sha256':hashlib.sha256(stored).hexdigest(),'gzip':compressed})
source={name:{'bytes':(r/name).stat().st_size,'sha256':hashlib.sha256((r/name).read_bytes()).hexdigest()} for name in source_paths}
record={'schema':'hepta.hia.core-companion-native-release-evidence.v1','base':'69a7a0c0db9978d81f98b5a626ed09822159fc44','root_base':'7c60c268c58371e1bf82490d83ee4a3e2bc573b2','source_controls':{'methods':12,'passed':True,'elapsed_s':source_control['elapsed_s'],'scope':'SOURCE_ONLY'},'development_only':{'owner_roles':3,'owner_reject_controls':6,'owner_elapsed_s':1.939731980994111,'independent_checker_controls':61,'checker_elapsed_s':14.20477901698905,'worker_framer_controls':25,'worker_framer_elapsed_s':1.5583964300167281,'compiler_sha256':'acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9','matching_cold_qualified':False},'full_release_install_rebuild_passed':False,'core39_original_emitter_semantics_closed':False,'release_dag':'core_companions','native_profile_order':['Store','Core3','Page','v3'],'source_paths':source,'files':index}
(dest/'qualification.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
(dest/'README.md').write_text('# Native Core companion release candidate\n\nThe three Core value companions retain their complete eight-field manifests. A separate HIA owner recompiles and compares the actual compiler and each image before hashing the source, ABI, bridge, selection and image bytes. A different HIA JSON checker independently validates all eight fields against the six supplied physical inputs. The original global release planner remains byte-for-byte unchanged; a new core_companions HIASTD01 DAG uses the existing length, concatenate, execute and compare operations.\n\nWorker report construction recompiles all three companions and requires exact equality with the installed release manifests and images. A separately pinned HIA table owner binds the complete three-child Core wrapper to the existing Page wrapper. The default order is Store → Core → Page → v3. Original generic helper records and Page records retain their owners.\n\nTwelve source controls passed. Actual Linux DEVELOPMENT_ONLY execution passed the complete three-role owner protocol plus six refusal controls, 61 independent checker controls, and 25 native Worker framer controls. The earlier compact JSON owner and authoring failures remain in the complete raw evidence. The final owner emits the existing component builder\'s exact formatted JSON bytes. The two complete native archives have been independently read back on Mac with every member SHA and mode.\n\nThese component controls do not grant matching-current-cold or complete release/install/rebuild qualification. The unified native authority, extension catalog, fresh cold build and actual final installed suite remain required. The distinct Core39 emitter/UNPACK/CALL_EX work is not marked closed by this release wiring.\n')
git('switch','-c','codex/hia-core-companion-native-release-20261127-2ac5')
git('add','--',*source_paths,'review-evidence/hia-core-companion-native-release-20261127-2ac5')
git('diff','--cached','--check')
p=subprocess.run(['/usr/bin/git','commit','-m','Add native Core companion release and Worker composition recipes'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
pub=q/'core-native-release-publication-v1';pub.mkdir(mode=0o700);(pub/'commit.stdout').write_bytes(p.stdout);(pub/'commit.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
out={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'parent':git('rev-parse','HEAD^').decode().strip(),'source_files':len(source_paths),'evidence_files':len(index)+2,'source_paths':source_paths}
(pub/'commit.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out),flush=True)
