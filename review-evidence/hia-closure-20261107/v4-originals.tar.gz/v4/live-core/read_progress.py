"""Read one bounded snapshot of original core journals; no remote file writes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path('/Users/qianqi/work/hia-release-faa85-v4-c81-r1/http-v4-live-flow-r1')

def read(name):
    try:
        fd = os.open(ROOT / name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except FileNotFoundError:
        return None, {'exists': False}
    with os.fdopen(fd, 'rb') as stream:
        a = os.fstat(stream.fileno())
        if not stat.S_ISREG(a.st_mode) or a.st_uid != os.getuid() or a.st_nlink != 1 or a.st_size > 16 * 1024 * 1024:
            raise ValueError('unsafe or oversized original journal')
        raw = stream.read(16 * 1024 * 1024 + 1)
        b = os.fstat(stream.fileno())
    fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    stable = fields(a) == fields(b) and len(raw) == a.st_size
    meta = {'exists': True, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'stable_during_read': stable, 'mtime_ns': a.st_mtime_ns}
    if not stable:
        return None, meta
    return raw, meta

report = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'directory': str(ROOT), 'remote_writes': False, 'HIA_requests': 0}
for name in ['application-events.jsonl', 'http-events.jsonl']:
    raw, meta = read(name)
    if raw is not None:
        events = [json.loads(line) for line in raw.splitlines()]
        meta['event_count'] = len(events)
        if name.startswith('application'):
            done = [e for e in events if e.get('phase') == 'response']
            meta['completed_application_responses'] = len(done)
            meta['expected_application_responses'] = 39
            meta['last_response'] = ({k: done[-1].get(k) for k in ['sequence', 'tool']} if done else None)
            meta['last_event'] = ({k: events[-1].get(k) for k in ['phase', 'sequence', 'tool']} if events else None)
        else:
            meta['last_events'] = []
            for event in events[-4:]:
                item = {k: event[k] for k in ['stage', 'wire_id', 'http_status', 'read_complete', 'body', 'error_type'] if k in event}
                if 'request' in event:
                    item['method'] = event['request'].get('method')
                    item['tool'] = event['request'].get('params', {}).get('name')
                meta['last_events'].append(item)
    report[name] = meta
raw, meta = read('result.json')
if raw is not None:
    result = json.loads(raw)
    meta.update({k: result[k] for k in ['status', 'tool_call_count', 'tool_names_observed', 'coverage', 'failure', 'elapsed_ns'] if k in result})
report['result.json'] = meta
print(json.dumps(report, sort_keys=True), flush=True)
