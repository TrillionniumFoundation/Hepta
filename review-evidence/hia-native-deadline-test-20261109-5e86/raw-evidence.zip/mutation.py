"""Read-only in-memory fault injection for the repaired deadline test."""
import inspect
import io
import json
import textwrap
import unittest
from unittest.mock import patch

from hepta.hia_agent_service import HIAAgentService

source = textwrap.dedent(inspect.getsource(HIAAgentService._hia_evaluate))
old = 'reference = run_reference_batch(program, workload["cases"], timeout_ms=remaining_total_ms(),'
new = 'reference = run_reference_batch(program, workload["cases"], timeout_ms=context["budget"]["max_total_wall_ms"],'
assert source.count(old) == 1
namespace = {}
exec(compile(source.replace(old, new), '<in-memory-fresh-budget-fault>', 'exec'),
     HIAAgentService._hia_evaluate.__globals__, namespace)
stream = io.StringIO()
with patch.object(HIAAgentService, '_hia_evaluate', namespace['_hia_evaluate']):
    suite = unittest.defaultTestLoader.loadTestsFromName(
        'tests.test_hia_agent_native_tools.NativeLifecycleTests.test_reference_loop_cannot_restart_or_overrun_frozen_context_deadline')
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
print(stream.getvalue())
assert result.testsRun == 1 and len(result.failures) == 1 and not result.errors and not result.skipped
assert '3000 !=' in result.failures[0][1]
print(json.dumps({'status': 'FAULT_REJECTED', 'fault': 'fresh_3000ms_reference_grant',
                  'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
                  'production_source_modified': False}))
