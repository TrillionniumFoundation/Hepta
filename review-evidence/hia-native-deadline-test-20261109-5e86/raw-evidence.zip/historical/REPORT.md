# Current installation recovery and preserved HOLD

Recorded 2026-11-08 in America/New_York. The final controller preparation was recorded at Unix time 1794191902.043349.

The missing interpreter environment for the published Hepta 321daf28 / runtime 4cd85c99 release was restored at its existing path. The stable restore operation finished with native terminal status succeeded, exit 0, complete durable output. All 292 Hepta files in the exact public lock were checked. The six packages were restored to the versions retained in the original dependency installation log. The independent direct worker manifest matches all three locked installation digests. The 32 pre-existing Python cache files were inventoried and retained; this is not a source-only loading claim.

Formal connector discovery and artifact read completed after the repair, but the existing readback checker returns HOLD_INSTALLATION_MISMATCH. The observed worker digest is 7f767953145e722f4cf62cbb4e3617fa2f9b388f3940ad926b5bb9a7309ae642; the public lock requires 1183286165c276737e1d25acb47b982134db2a7150df23887186bac34ca53c4f. Backend and catalog digests match. Actual durable worker request metadata establishes the cause: the interpreter points to the restored 321 environment, while the working directory and expected worker pin still select source 2598f430. The earlier v9 change plan explicitly records that transition. This is a configuration mismatch, not evidence of a content-addressed manifest-cache bug.

The two earlier request identities still resolve to their original failed launches with exit 127. Their original UNKNOWN connector results are preserved. Different valid read pagination arguments were used only after observing those terminal failures. No business operation was replayed.

A create-only configuration plan and both private configuration snapshots are retained on the controller. The plan finished succeeded/exit 0. The proposed bytes equal the previously retained 321 configuration exactly. Only hia_worker.working_directory and hia_worker.worker_sha256 differ from the current configuration. State roots, host policy, artifact roots, runtime binary and plist are preserved. The actual controller configuration was independently rechecked after preparation and remains 0e74611087fd297c5f1e4631656573242107b3d9d38e924762cc97e6b2e6ff2d. No configuration replacement or service restart was performed, and no such mutation is pending.

Activation remains HOLD. The existing guarded preflight requires authenticated admission freezing; a read inventory is explicitly insufficient. The native inventory API still refuses its total source-byte bound, including an eight-item requested page, so a complete current inventory has not been established. The independent e5ee environment requalification also retained one failure among 69 native tests: the evaluation was rejected E_HIA_BUDGET before the intended deadline exercise. The other 68 results do not replace a full qualification PASS, and no requirement was waived.

The private target is concrete and reviewable: current configuration 0e74611087fd297c5f1e4631656573242107b3d9d38e924762cc97e6b2e6ff2d, proposed configuration b202312c4b15cdf4b8af3d5023142736b0d8a574c6f6c579c9340d690c11f112, plan c02686bbc26ac09551580c519de36af240f164902d7c653a8663367e060c7f00. Future activation must use a fresh exact compare-and-swap and preserve the original jobs, PTYs, journals and artifacts. Current formal installation identity remains HOLD.

## Reproduce the retained readback

Run the unchanged public checker:

```sh
python3 check_hia_online_readback.py --lock public-release-lock.json --lock-sha256 1c4b747721bfc215549512287d62febbadfaf7bce3cd2b6baafeed3d67a10c18 --describe describe.json --read read.json
```

Expected: exit 1 and HOLD_INSTALLATION_MISMATCH. The exact manifest bytes are bound to the server-issued artifact digest d05cf5c78bed8da1cb9486f307097e4a2303780dd76da1c7ee44bafbee08969c. The captures are retained tool response objects, not signed transport attestations or runtime-binary proofs. Local JSON serialization hashes do not claim transport-framing hashes.
