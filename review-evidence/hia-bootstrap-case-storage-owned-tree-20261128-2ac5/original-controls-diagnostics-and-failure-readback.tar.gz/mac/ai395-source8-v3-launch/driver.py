from pathlib import Path
import subprocess,os,time,json,hashlib,platform,stat,sys
R=Path("/home/qq/hia-bootstrap-case-terminal-source8-20261128-2ac5")
S=R/"source";Q=R/"qualification-v3";Q.mkdir(mode=0o700)
tmp=R/"tmp-v3";tmp.mkdir(mode=0o700)
python="/usr/bin/python3"
head="0ccf777c71473bca0e3adc02731c62c98e26ac42"
env={k:v for k,v in os.environ.items() if not k.startswith(("HEPTA_HIA_","PYTHON"))}
env["TMPDIR"]=str(tmp)
def git(*args):
 p=subprocess.run(["git","-C",str(S),*args],capture_output=True,check=True)
 return p.stdout
assert git("rev-parse","HEAD").decode().strip()==head
assert not git("status","--porcelain").strip()
material=json.loads((R/"materialization-result.json").read_bytes())
assert material["head"]==head and material["borrowed_alternates"] is False
check=subprocess.run([python,"-I","-B","-c","import sys,json,platform,gc;print(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'gc_enabled':gc.isenabled(),'gc_threshold':gc.get_threshold()}))"],capture_output=True,check=True,env=env)
(Q/"interpreter.json").write_bytes(check.stdout)
cmd=[python,"-I","-B",str(S/"tools/qualify_hia_service_bootstrap.py"),"--suite","source","--output",str(Q/"source8")]
beg=time.monotonic()
with (Q/"source8.stdout").open("xb") as out,(Q/"source8.stderr").open("xb") as err:
 p=subprocess.Popen(cmd,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
 intent={"source":head,"tree":git("rev-parse","HEAD^{tree}").decode().strip(),"pid":p.pid,"pgid":os.getpgid(p.pid),"command":cmd,"original_outer_seconds":1800,"cleanup_seconds":3,"TMPDIR":str(tmp),"all_original_source_methods":8,"observer_protocol":"CASE_LOCAL_COLLECTION_THEN_NATURAL_PROCESS_EXIT","original_test_bodies_unchanged":True,"original_input_records":232,"native_execution":False,"actual_host":"ai395"}
 (Q/"source8.start.json").write_text(json.dumps(intent,sort_keys=True,indent=2)+"\n")
 print(json.dumps(intent,sort_keys=True),flush=True)
 rc=p.wait()
terminal={**intent,"returncode":rc,"elapsed_seconds":time.monotonic()-beg,"source_unchanged":not git("status","--porcelain").strip()}
for name in ("stdout","stderr"):
 raw=(Q/("source8."+name)).read_bytes()
 terminal[name]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
# Recheck all actual source files against the independently materialized Git tree.
manifest=json.loads((R/"complete-source-manifest.json").read_bytes())
changed=[]
for row in manifest:
 path=S/row["path"];st=path.lstat();raw=path.read_bytes()
 if (not stat.S_ISREG(st.st_mode) or stat.S_IMODE(st.st_mode)!=row["mode"]
     or len(raw)!=row["bytes"] or hashlib.sha256(raw).hexdigest()!=row["sha256"]):
  changed.append(row["path"])
terminal["complete_source_files"]=len(manifest);terminal["changed_source_files"]=changed
(Q/"source8.terminal.json").write_text(json.dumps(terminal,sort_keys=True,indent=2)+"\n")
print(json.dumps(terminal,sort_keys=True),flush=True)
report=Q/"source8/suite/report.json"
if report.exists():
 value=json.loads(report.read_bytes())
 print(json.dumps({"suite":{k:value.get(k) for k in ("status","run","failures","errors","skips","method_statuses","component_evidence")}},sort_keys=True),flush=True)
raise SystemExit(rc or bool(changed) or not terminal["source_unchanged"])
