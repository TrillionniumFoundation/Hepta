from pathlib import Path
import os,json,time,signal,select,hashlib
R=Path("/home/qq/hia-bootstrap-case-terminal-source8-20261128-2ac5")
D=R/"qualification-v3-orphan-cleanup-v1";D.mkdir(exist_ok=False)
pid=3843709;P=Path("/proc")/str(pid);expected=286170971
fd=os.pidfd_open(pid)
stat=P.joinpath("stat").read_text();fields=stat[stat.rfind(")")+2:].split()
assert int(fields[19])==expected,(fields[19],expected)
cmd=P.joinpath("cmdline").read_bytes()
assert b"tests/hia_service_bootstrap_observer.py" in cmd and b"--lane"+bytes([0])+b"vm" in cmd and str(R/"qualification-v3").encode() in cmd
assert os.readlink(P/"cwd")==str(R/"source")
assert P.stat().st_uid==os.getuid()
before={"pid":pid,"stat":stat,"cmdline_base64":__import__("base64").b64encode(cmd).decode(),"cwd":os.readlink(P/"cwd"),"status":P.joinpath("status").read_text(),"time_ns":time.time_ns(),"reason":"The original suite exceeded its unchanged 1800 second limit and was killed; its independently sessioned VM observer remained orphaned under PPid 1. Terminate only this positively identified owned process, without replaying the suite."}
(D/"before.json").write_text(json.dumps(before,sort_keys=True,indent=2)+"\n")
poll=select.poll();poll.register(fd,select.POLLIN)
signal.pidfd_send_signal(fd,signal.SIGTERM)
events=poll.poll(10000);forced=False
if not events:
 signal.pidfd_send_signal(fd,signal.SIGKILL);forced=True;events=poll.poll(10000)
assert events,"owned child not terminal"
after={"pid":pid,"time_ns":time.time_ns(),"pidfd_exited":True,"sigterm":True,"sigkill":forced,"original_suite_status":"FAIL_TIMEOUT","natural_child_terminal_qualified":False}
if P.exists():
 after["remaining_proc_stat"]=P.joinpath("stat").read_text()
(D/"after.json").write_text(json.dumps(after,sort_keys=True,indent=2)+"\n")
os.close(fd)
print(json.dumps({"before":before,"after":after}))
