"""Forbid ambient /proc status reads in the existing real-child test."""
from contextlib import redirect_stdout, redirect_stderr
import gc
from hashlib import sha256
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import warnings

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(root))
paths = ['tests/test_c2hepta_process_group.py', 'tools/c2hepta.py',
         'hepta/clang_capture.py', 'hepta/darwin_capture.py']
before = {}
for name in paths:
    raw = (root / name).read_bytes()
    before[name] = sha256(raw).hexdigest()
    saved = output / 'source' / name
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(raw)
selector = 'tests.test_c2hepta_process_group.ClangProcessGroupTermination.test_exited_wrapper_cannot_leave_descendant_holding_capture_pipes'
real_read = Path.read_text
injections = []

def disappear(path, *args, **kwargs):
    if path.name == 'status' and path.parent.parent == Path('/proc'):
        injections.append(str(path))
        raise ProcessLookupError(3, 'injected observed process-disappearance race')
    return real_read(path, *args, **kwargs)

suite = unittest.defaultTestLoader.loadTestsFromName(selector)
with (output / 'stdout.log').open('w') as stdout, (output / 'stderr.log').open('w') as stderr:
    with redirect_stdout(stdout), redirect_stderr(stderr), warnings.catch_warnings(record=True) as observed:
        warnings.simplefilter('always')
        with patch.object(Path, 'read_text', disappear):
            result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
        gc.collect()
after = {name: sha256((root / name).read_bytes()).hexdigest() for name in paths}
record = dict(schema='hepta.proc-status-race.reproduction.v1', selector=selector,
              tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skips=len(result.skipped), passed=result.wasSuccessful(),
              source_before=before, source_after=after, source_unchanged=before == after,
              injections=injections,
              warnings=[dict(category=w.category.__name__, message=str(w.message)) for w in observed],
              scope='Actual existing Linux private-child/barrier test with forbidden ambient /proc status reads. The historical CI ESRCH is separate; the first local attempt failed its earlier numeric-PID assertion before this seam. No native Clang execution or statistical race claim.')
(output / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() and not injections and before == after else 1)
