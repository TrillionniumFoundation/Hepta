#!/usr/bin/env python3
"""Record finite repair regressions on one clean committed source tree.

This driver does not qualify unavailable native tools or infer remote CI.
The reviewed selection is a separate input; no test is silently skipped.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import gc
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import traceback
import unittest
import warnings


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--selection', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(root))
    from tools.qualify_hia_integrated import _source_state, CRITICAL_MODULES

    selected_bytes = args.selection.read_bytes()
    selected = json.loads(selected_bytes)
    ids = selected['unique_selectors']
    if ids != sorted(set(ids)) or not ids:
        raise ValueError('Selection must be a sorted nonempty unique list')
    before = _source_state()
    if before['head'] != args.expected_head or before['status']:
        raise ValueError('Expected clean committed source head does not match')
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromNames(ids)
    actual = [test.id() for test in flatten(suite)]
    if loader.errors or sorted(actual) != ids or len(actual) != len(set(actual)):
        raise ValueError('Selection did not resolve exactly once: ' + repr(loader.errors))
    plan = dict(schema='hepta.round6.repair-focused-plan.v1', source=before,
                selection_sha256=sha256(selected_bytes).hexdigest(),
                selection=selected, expected_head=args.expected_head,
                critical_groups=len(CRITICAL_MODULES),
                unique_critical_modules=len({name for group in CRITICAL_MODULES.values() for name in group}),
                native_toolchain_qualification=False, remote_ci_executed=False)
    (output / 'PLAN.json').write_text(json.dumps(plan, indent=2) + '\n')
    start = time.monotonic()
    with (output / 'stdout.log').open('w') as stdout, (output / 'stderr.log').open('w') as stderr:
        with redirect_stdout(stdout), redirect_stderr(stderr), warnings.catch_warnings(record=True) as observed:
            warnings.simplefilter('always')
            result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
            gc.collect()
        warning_records = [dict(category=type(w.message).__name__, message=str(w.message),
                                filename=w.filename, lineno=w.lineno) for w in observed]
    after = _source_state()
    streams = {}
    for name in ('stdout.log', 'stderr.log'):
        raw = (output / name).read_bytes()
        streams[name] = dict(bytes=len(raw), sha256=sha256(raw).hexdigest())
    report = dict(schema='hepta.round6.repair-focused-result.v1',
                  source_head=before['head'], source_tree=before['tree'],
                  source_unchanged=before == after,
                  tests=result.testsRun, unique_methods=len(actual),
                  failures=len(result.failures), errors=len(result.errors), skips=len(result.skipped),
                  warnings=warning_records, seconds=time.monotonic() - start,
                  passed=(result.wasSuccessful() and not result.skipped and not warning_records
                          and before == after and result.testsRun == len(ids)),
                  failure_details=[(test.id(), detail) for test, detail in result.failures],
                  error_details=[(test.id(), detail) for test, detail in result.errors],
                  skip_details=[(test.id(), reason) for test, reason in result.skipped],
                  streams=streams, full_regression_executed=False,
                  native_toolchain_qualification=False, remote_ci_executed=False,
                  finished_utc=datetime.now(timezone.utc).isoformat())
    (output / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items()
                      if k not in {'failure_details', 'error_details', 'skip_details'}}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise
