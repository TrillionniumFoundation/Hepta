"""Retain scoped stream-owner tests; no native qualification or benchmark."""
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import gc
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest
from unittest.mock import patch
import warnings

ROOT = Path('/workspace/scratch/bf7d454bbc83/hepta-round6-integration')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
WATCHED = (
    'hepta/cpp_unique_capture.py', 'tests/test_cpp_unique_capture.py',
    'hepta/clang_capture.py', 'hepta/darwin_capture.py',
    'tests/test_cpp_unique_project.py',
)


def snapshot():
    return {name: {'sha256': hashlib.sha256((ROOT / name).read_bytes()).hexdigest(),
                   'bytes': (ROOT / name).stat().st_size} for name in WATCHED}


def identifiers(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from identifiers(item)
        else:
            yield item.id()


def run(name, selection, forced_guardian):
    before = snapshot()
    suite = unittest.defaultTestLoader.loadTestsFromName(selection)
    ids = list(identifiers(suite))
    started = datetime.now(timezone.utc).isoformat()
    start = time.perf_counter_ns()
    with (OUT / (name + '.stdout.log')).open('w') as stdout, (OUT / (name + '.stderr.log')).open('w') as stderr:
        with redirect_stdout(stdout), redirect_stderr(stderr), warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter('always')
            if forced_guardian:
                with patch('hepta.clang_capture._DARWIN', True):
                    result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
            else:
                result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
            gc.collect()
            warning_rows = [{'category': row.category.__name__, 'message': str(row.message),
                             'filename': row.filename, 'lineno': row.lineno} for row in captured]
    elapsed = time.perf_counter_ns() - start
    after = snapshot()
    record = {
        'name': name, 'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(),
        'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'working_tree': str(ROOT), 'python': sys.version, 'host_platform': sys.platform,
        'forced_guardian_route': forced_guardian,
        'scope': 'POSIX process-ownership mechanism on this host; no claim of native C++ or actual macOS qualification.',
        'methods': ids, 'methods_run': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
        'warnings': warning_rows, 'elapsed_wall_ns': elapsed,
        'source_before': before, 'source_after': after, 'source_unchanged': before == after,
        'passed': result.wasSuccessful() and not result.skipped and not warning_rows and before == after,
        'raw_logs': {},
    }
    for kind in ('stdout', 'stderr'):
        path = OUT / (name + '.' + kind + '.log')
        payload = path.read_bytes()
        record['raw_logs'][kind] = {'path': str(path), 'bytes': len(payload),
                                    'sha256': hashlib.sha256(payload).hexdigest()}
    (OUT / (name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: record[k] for k in ('name', 'methods_run', 'failures', 'errors', 'skips',
                                           'warnings', 'source_unchanged', 'passed')}, sort_keys=True))
    return record


normal = run('capture-final-normal', 'tests.test_cpp_unique_capture', False)
guardian = run('capture-final-forced-guardian', 'tests.test_cpp_unique_capture.UniqueCaptureResourceTests', True)
combined = {
    'distinct_methods': len(set(normal['methods']) | set(guardian['methods'])),
    'overlap_methods': len(set(normal['methods']) & set(guardian['methods'])),
    'normal_report': 'capture-final-normal.result.json',
    'forced_route_report': 'capture-final-forced-guardian.result.json',
    'native_project_qualification': 'NOT RUN: missing Clang20+, see NATIVE_PREFLIGHT.json',
    'passed_scoped_mechanism_checks': normal['passed'] and guardian['passed'],
}
(OUT / 'FOCUSED_RESULTS.json').write_text(json.dumps(combined, indent=2) + '\n')
raise SystemExit(0 if combined['passed_scoped_mechanism_checks'] else 1)
