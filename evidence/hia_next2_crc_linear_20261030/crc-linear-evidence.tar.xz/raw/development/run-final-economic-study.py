#!/usr/bin/env python3
"""External one-shot launcher and pure JSON outer-cost audit; no repository imports."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import subprocess
import time

BASE = Path('/workspace/scratch/f0c12f106c89')
ROOT = BASE / 'hepta-integration'
PYTHON = BASE / 'hepta-native-venv/bin/python'
CLANG = BASE / 'toolchains/llvm20/usr/lib/llvm-20/bin/clang'
PROTOCOL_SHA = '19b46aafdccf573cecd19311e7f2767026274bc180b002a4cb119d0a05716038'


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def read(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or not 0 <= info.st_size <= limit:
            raise ValueError('nonregular/oversized evidence input')
        with os.fdopen(fd, 'rb', closefd=False) as source:
            raw = source.read(limit + 1)
        if len(raw) != info.st_size or len(raw) > limit:
            raise ValueError('evidence grew/changed length')
        return raw
    finally:
        os.close(fd)


def source():
    git = lambda *args: subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT).decode().strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


def host():
    result = {'utc': datetime.now(timezone.utc).isoformat(), 'loadavg': list(os.getloadavg()),
              'free_bytes': os.statvfs(BASE).f_bavail * os.statvfs(BASE).f_frsize}
    for item in ('/proc/loadavg', '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current'):
        path = Path(item)
        if path.exists():
            result[item] = path.read_text()[:4096]
    return result


def outer_audit(report, receipt, expected_head):
    if not __debug__:
        raise RuntimeError('outer audit requires active assertions; optimized interpreter refused')
    p = report['protocol']
    assert receipt['returncode'] == 0 and receipt['timeout'] is False
    assert report['qualified'] is True and report['status'] == 'completed' and report['errors'] == []
    assert report['release']['complete'] is True
    assert report['source_before'] == report['source_after']
    assert report['source_before']['head'] == expected_head
    assert report['tools_before'] == report['tools_after'] and p == report['protocol_after']
    assert receipt['source_before'] == receipt['source_after']
    assert not receipt['source_after']['status'] and receipt['source_after']['head'] == expected_head
    assert report['protocol_sha256'] == PROTOCOL_SHA
    assert all(r['status'] == 'completed' and type(r['wall_ns']) is int and r['wall_ns'] >= 0 for r in report['ledger'])
    labels = [row['label'] for row in report['ledger']]
    assert len(labels) == len(set(labels))
    assert all(f'sample.{i:03d}' in labels for i in range(96))
    required = {'source.before', 'tools.before', 'source.capture-and-bridge', 'proposal.generate', 'bank.prepare',
                'code.inspect', 'data.prepare', 'reference.prime', 'bank.close', 'source.after', 'tools.after',
                'protocol.after', 'analysis'}
    assert set(labels) == required | {f'sample.{i:03d}' for i in range(96)}
    pre_analysis = [row for row in report['ledger'] if row['label'] != 'analysis']
    closed = json.dumps(pre_analysis, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    assert sha256(closed).hexdigest() == report['closed_pre_analysis_ledger_sha256']
    samples = report['samples']
    assert len(samples) == p['expected_observations'] == 96
    keys = [(r['phase'], r['trial'], r['workload'], r['arm']) for r in samples]
    expected = {(ph, trial, workload, arm) for ph in ('training', 'validation')
                for trial in range(2) for workload in p['workloads'] for arm in p['arms']}
    assert len(keys) == len(set(keys)) and set(keys) == expected
    assert all(r['status'] == 'completed' and not r.get('unknown_native_measurements')
               and not r.get('native_persistence_errors') for r in samples)
    assert sum(r['calls'] for r in samples) == 393216
    assert sum(r['completed_requests'] for r in samples) == 1536
    assert sum(len(r['contexts']) for r in samples) == 276
    assert report['actual_counts'] == {'original_C_reference_cases': 48,
        'native_preparation_differential_cases': 384, 'delivered_requests': 1536,
        'delivered_kernel_calls': 393216, 'native_contexts': 276, 'ndu_decisions': 0}
    economics = copy.deepcopy(report['economics'])
    total = sum(r['arm_host_wall_ns'] for r in samples)
    assert total == economics['delivered_host_sum_ns']
    wall = receipt['outer_wall_ns']
    assert type(wall) is int and wall >= total
    charge = wall - total
    economics.update(charged_whole_wall_ns=wall, shared_non_delivery_charge_ns=charge,
                     actual_outer_execution_cost_verified=True,
                     actual_outer_within_study_budget=wall <= p['max_study_wall_ns'])
    for group in economics['groups']:
        group['cold_dispatch_net_over_all_six_fixed_ns'] = group['dispatch_host_increment_over_all_six_fixed_ns'] - charge
        for contrast in group['new_candidate_contrasts'].values():
            saving = contrast['kernel_saving_vs_fastest_legacy_ns']
            contrast['cold_candidate_net_vs_fastest_legacy_ns'] = contrast['full_host_saving_vs_fastest_legacy_ns'] - charge
            contrast['conditional_break_even_calls_full_charge'] = ((charge * 4096 + saving - 1) // saving if saving > 0 else None)
    passed = economics['new_exports_differ_from_every_legacy'] and all(
        row['cold_dispatch_net_over_all_six_fixed_ns'] > 0 for row in economics['groups'])
    economics['inner_cold_gate_passed'] = passed
    economics['complete_cost_cold_gate_passed'] = passed and economics['actual_outer_within_study_budget']
    return {'audit_passed': True, 'original_inner_result_rewritten': False,
            'inner_execution_qualified': True, 'outer_economics': economics,
            'execution_qualified_with_outer_budget': economics['actual_outer_within_study_budget'],
            'timing_is_statistical_qualification': False,
            'complete_human_effort_and_historical_acquisition_cost_known': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_directory.resolve()
    out.mkdir(parents=True, exist_ok=False)
    before = source()
    if before['head'] != args.expected_head or before['status']:
        raise RuntimeError('exact clean integrated source required before launch')
    raw_protocol = read(ROOT / 'experiments/hia_crc_linear_20261030/PROTOCOL.json', 1 << 20)
    if sha256(raw_protocol).hexdigest() != PROTOCOL_SHA:
        raise RuntimeError('frozen protocol differs')
    command = [str(PYTHON), 'tools/qualify_hia_crc_linear_economics.py', '--output-directory', str(out / 'run'),
               '--expected-head', args.expected_head, '--clang', str(CLANG), '--cc', '/usr/bin/gcc', '--objdump', '/usr/bin/objdump']
    environment = dict(os.environ)
    environment.pop('CPATH', None)
    fixed = {'PATH': str(PYTHON.parent) + ':' + str(CLANG.parent) + ':/usr/bin:/bin',
             'LD_LIBRARY_PATH': str(BASE / 'toolchains/llvm20/usr/lib/x86_64-linux-gnu'),
             'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(ROOT), 'PYTHONNOUSERSITE': '1', 'PYTHONOPTIMIZE': '0'}
    environment.update(fixed)
    plan = {'schema': 'hepta.hia.crc-linear.outer-plan.v1', 'argv': command, 'cwd': str(ROOT),
            'source_before': before, 'environment': fixed, 'host_before': host(),
            'protocol_sha256': PROTOCOL_SHA, 'launcher_sha256': sha256(read(Path(__file__), 1 << 20)).hexdigest(),
            'one_attempt_no_retry': True, 'coordinated_native_window': True,
            'other_host_tenants_excluded': False, 'performance_timing_qualified': False}
    save(out / 'PLAN.json', plan)
    started = time.monotonic_ns()
    receipt = dict(plan, timeout=False, returncode=None)
    try:
        with (out / 'stdout.txt').open('xb') as stdout, (out / 'stderr.txt').open('xb') as stderr:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr, timeout=360)
        receipt['returncode'] = result.returncode
    except BaseException as error:
        receipt.update(timeout=isinstance(error, subprocess.TimeoutExpired),
                       error={'type': type(error).__name__, 'message': str(error)})
    finally:
        receipt['outer_wall_ns'] = time.monotonic_ns() - started
        receipt['source_after'] = source()
        receipt['host_after'] = host()
        save(out / 'EXECUTION.json', receipt)
    try:
        raw = read(out / 'run/RESULT.json', 64 << 20)
        frozen = read(out / 'run/FROZEN_PROTOCOL.json', 1 << 20)
        assert sha256(frozen).hexdigest() == PROTOCOL_SHA
        report = json.loads(raw)
        audit = outer_audit(report, receipt, args.expected_head)
        audit['result_sha256'] = sha256(raw).hexdigest()
        audit['execution_receipt_sha256'] = sha256(read(out / 'EXECUTION.json', 1 << 20)).hexdigest()
        save(out / 'OUTER_ECONOMICS.json', audit)
    except BaseException as error:
        audit = {'audit_passed': False, 'error': {'type': type(error).__name__, 'message': str(error)},
                 'original_inner_result_rewritten': False, 'no_retry': True}
        save(out / 'OUTER_AUDIT_FAILURE.json', audit)
    print(json.dumps({'returncode': receipt['returncode'], 'outer_wall_ns': receipt['outer_wall_ns'],
                      'audit_passed': audit['audit_passed'],
                      'execution_qualified_with_outer_budget': audit.get('execution_qualified_with_outer_budget', False),
                      'output': str(out)}, sort_keys=True))
    return 0 if audit['audit_passed'] and audit['execution_qualified_with_outer_budget'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
