; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i32 %p_0_1, 2197175160
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = and i32 %p_1_0, 1
  %t3 = icmp ne i32 %t2, 0
  %t4 = icmp ult i32 1, 32
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = lshr i32 %p_1_0, 1
  %t7 = xor i32 %t6, %p_1_1
  %t8 = select i1 %t3, i32 %t7, i32 %t6
  %t9 = and i32 %t8, 1
  %t10 = icmp ne i32 %t9, 0
  %t11 = icmp ult i32 1, 32
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = lshr i32 %t8, 1
  %t14 = xor i32 %t13, %p_1_1
  %t15 = select i1 %t10, i32 %t14, i32 %t13
  %t16 = and i32 %t15, 1
  %t17 = icmp ne i32 %t16, 0
  %t18 = icmp ult i32 1, 32
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = lshr i32 %t15, 1
  %t21 = xor i32 %t20, %p_1_1
  %t22 = select i1 %t17, i32 %t21, i32 %t20
  %t23 = and i32 %t22, 1
  %t24 = icmp ne i32 %t23, 0
  %t25 = icmp ult i32 1, 32
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = lshr i32 %t22, 1
  %t28 = xor i32 %t27, %p_1_1
  %t29 = select i1 %t24, i32 %t28, i32 %t27
  %t30 = and i32 %t29, 1
  %t31 = icmp ne i32 %t30, 0
  %t32 = icmp ult i32 1, 32
  br i1 %t32, label %ok_33, label %trap_33
trap_33:
  call void @abort()
  unreachable
ok_33:
  %t34 = lshr i32 %t29, 1
  %t35 = xor i32 %t34, %p_1_1
  %t36 = select i1 %t31, i32 %t35, i32 %t34
  %t37 = and i32 %t36, 1
  %t38 = icmp ne i32 %t37, 0
  %t39 = icmp ult i32 1, 32
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = lshr i32 %t36, 1
  %t42 = xor i32 %t41, %p_1_1
  %t43 = select i1 %t38, i32 %t42, i32 %t41
  %t44 = and i32 %t43, 1
  %t45 = icmp ne i32 %t44, 0
  %t46 = icmp ult i32 1, 32
  br i1 %t46, label %ok_47, label %trap_47
trap_47:
  call void @abort()
  unreachable
ok_47:
  %t48 = lshr i32 %t43, 1
  %t49 = xor i32 %t48, %p_1_1
  %t50 = select i1 %t45, i32 %t49, i32 %t48
  %t51 = and i32 %t50, 1
  %t52 = icmp ne i32 %t51, 0
  %t53 = icmp ult i32 1, 32
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  %t55 = lshr i32 %t50, 1
  %t56 = xor i32 %t55, %p_1_1
  %t57 = select i1 %t52, i32 %t56, i32 %t55
  ret i32 %t57
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_2_1 = phi i32 [ 2197175160, %edge_0 ]
  %t58 = icmp ult i32 8, 32
  br i1 %t58, label %ok_59, label %trap_59
trap_59:
  call void @abort()
  unreachable
ok_59:
  %t60 = lshr i32 %p_2_0, 8
  %t61 = and i32 %p_2_0, 1
  %t62 = icmp ne i32 %t61, 0
  %t63 = select i1 %t62, i32 4067132163, i32 0
  %t64 = and i32 %p_2_0, 2
  %t65 = icmp ne i32 %t64, 0
  %t66 = select i1 %t65, i32 3778769143, i32 0
  %t67 = and i32 %p_2_0, 4
  %t68 = icmp ne i32 %t67, 0
  %t69 = select i1 %t68, i32 3348797215, i32 0
  %t70 = and i32 %p_2_0, 8
  %t71 = icmp ne i32 %t70, 0
  %t72 = select i1 %t71, i32 2329499855, i32 0
  %t73 = and i32 %p_2_0, 16
  %t74 = icmp ne i32 %t73, 0
  %t75 = select i1 %t74, i32 274646895, i32 0
  %t76 = and i32 %p_2_0, 32
  %t77 = icmp ne i32 %t76, 0
  %t78 = select i1 %t77, i32 549293790, i32 0
  %t79 = and i32 %p_2_0, 64
  %t80 = icmp ne i32 %t79, 0
  %t81 = select i1 %t80, i32 1098587580, i32 0
  %t82 = and i32 %p_2_0, 128
  %t83 = icmp ne i32 %t82, 0
  %t84 = select i1 %t83, i32 2197175160, i32 0
  %t85 = xor i32 %t60, %t63
  %t86 = xor i32 %t66, %t69
  %t87 = xor i32 %t72, %t75
  %t88 = xor i32 %t78, %t81
  %t89 = xor i32 %t85, %t86
  %t90 = xor i32 %t87, %t88
  %t91 = xor i32 %t89, %t90
  %t92 = xor i32 %t91, %t84
  ret i32 %t92
edge_0:
  br label %b2
edge_1:
  br label %b1
}

define i32 @calculate(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_0(i32 %a0, i32 %a1)
  ret i32 %result
}
