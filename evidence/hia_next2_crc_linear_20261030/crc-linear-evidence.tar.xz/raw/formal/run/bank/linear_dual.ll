; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i32 %p_0_1, 3988292384
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = icmp eq i32 %p_1_1, 2197175160
  br i1 %t2, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i32 [ %p_1_0, %edge_3 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_3 ]
  %t3 = and i32 %p_2_0, 1
  %t4 = icmp ne i32 %t3, 0
  %t5 = icmp ult i32 1, 32
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = lshr i32 %p_2_0, 1
  %t8 = xor i32 %t7, %p_2_1
  %t9 = select i1 %t4, i32 %t8, i32 %t7
  %t10 = and i32 %t9, 1
  %t11 = icmp ne i32 %t10, 0
  %t12 = icmp ult i32 1, 32
  br i1 %t12, label %ok_13, label %trap_13
trap_13:
  call void @abort()
  unreachable
ok_13:
  %t14 = lshr i32 %t9, 1
  %t15 = xor i32 %t14, %p_2_1
  %t16 = select i1 %t11, i32 %t15, i32 %t14
  %t17 = and i32 %t16, 1
  %t18 = icmp ne i32 %t17, 0
  %t19 = icmp ult i32 1, 32
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = lshr i32 %t16, 1
  %t22 = xor i32 %t21, %p_2_1
  %t23 = select i1 %t18, i32 %t22, i32 %t21
  %t24 = and i32 %t23, 1
  %t25 = icmp ne i32 %t24, 0
  %t26 = icmp ult i32 1, 32
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  %t28 = lshr i32 %t23, 1
  %t29 = xor i32 %t28, %p_2_1
  %t30 = select i1 %t25, i32 %t29, i32 %t28
  %t31 = and i32 %t30, 1
  %t32 = icmp ne i32 %t31, 0
  %t33 = icmp ult i32 1, 32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = lshr i32 %t30, 1
  %t36 = xor i32 %t35, %p_2_1
  %t37 = select i1 %t32, i32 %t36, i32 %t35
  %t38 = and i32 %t37, 1
  %t39 = icmp ne i32 %t38, 0
  %t40 = icmp ult i32 1, 32
  br i1 %t40, label %ok_41, label %trap_41
trap_41:
  call void @abort()
  unreachable
ok_41:
  %t42 = lshr i32 %t37, 1
  %t43 = xor i32 %t42, %p_2_1
  %t44 = select i1 %t39, i32 %t43, i32 %t42
  %t45 = and i32 %t44, 1
  %t46 = icmp ne i32 %t45, 0
  %t47 = icmp ult i32 1, 32
  br i1 %t47, label %ok_48, label %trap_48
trap_48:
  call void @abort()
  unreachable
ok_48:
  %t49 = lshr i32 %t44, 1
  %t50 = xor i32 %t49, %p_2_1
  %t51 = select i1 %t46, i32 %t50, i32 %t49
  %t52 = and i32 %t51, 1
  %t53 = icmp ne i32 %t52, 0
  %t54 = icmp ult i32 1, 32
  br i1 %t54, label %ok_55, label %trap_55
trap_55:
  call void @abort()
  unreachable
ok_55:
  %t56 = lshr i32 %t51, 1
  %t57 = xor i32 %t56, %p_2_1
  %t58 = select i1 %t53, i32 %t57, i32 %t56
  ret i32 %t58
b3:
  %p_3_0 = phi i32 [ %p_0_0, %edge_0 ], [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ 1996959894, %edge_0 ], [ 4067132163, %edge_2 ]
  %p_3_2 = phi i32 [ 3993919788, %edge_0 ], [ 3778769143, %edge_2 ]
  %p_3_3 = phi i32 [ 124634137, %edge_0 ], [ 3348797215, %edge_2 ]
  %p_3_4 = phi i32 [ 249268274, %edge_0 ], [ 2329499855, %edge_2 ]
  %p_3_5 = phi i32 [ 498536548, %edge_0 ], [ 274646895, %edge_2 ]
  %p_3_6 = phi i32 [ 997073096, %edge_0 ], [ 549293790, %edge_2 ]
  %p_3_7 = phi i32 [ 1994146192, %edge_0 ], [ 1098587580, %edge_2 ]
  %p_3_8 = phi i32 [ 3988292384, %edge_0 ], [ 2197175160, %edge_2 ]
  %t59 = icmp ult i32 8, 32
  br i1 %t59, label %ok_60, label %trap_60
trap_60:
  call void @abort()
  unreachable
ok_60:
  %t61 = lshr i32 %p_3_0, 8
  %t62 = and i32 %p_3_0, 1
  %t63 = icmp ne i32 %t62, 0
  %t64 = select i1 %t63, i32 %p_3_1, i32 0
  %t65 = and i32 %p_3_0, 2
  %t66 = icmp ne i32 %t65, 0
  %t67 = select i1 %t66, i32 %p_3_2, i32 0
  %t68 = and i32 %p_3_0, 4
  %t69 = icmp ne i32 %t68, 0
  %t70 = select i1 %t69, i32 %p_3_3, i32 0
  %t71 = and i32 %p_3_0, 8
  %t72 = icmp ne i32 %t71, 0
  %t73 = select i1 %t72, i32 %p_3_4, i32 0
  %t74 = and i32 %p_3_0, 16
  %t75 = icmp ne i32 %t74, 0
  %t76 = select i1 %t75, i32 %p_3_5, i32 0
  %t77 = and i32 %p_3_0, 32
  %t78 = icmp ne i32 %t77, 0
  %t79 = select i1 %t78, i32 %p_3_6, i32 0
  %t80 = and i32 %p_3_0, 64
  %t81 = icmp ne i32 %t80, 0
  %t82 = select i1 %t81, i32 %p_3_7, i32 0
  %t83 = and i32 %p_3_0, 128
  %t84 = icmp ne i32 %t83, 0
  %t85 = select i1 %t84, i32 %p_3_8, i32 0
  %t86 = xor i32 %t61, %t64
  %t87 = xor i32 %t67, %t70
  %t88 = xor i32 %t73, %t76
  %t89 = xor i32 %t79, %t82
  %t90 = xor i32 %t86, %t87
  %t91 = xor i32 %t88, %t89
  %t92 = xor i32 %t90, %t91
  %t93 = xor i32 %t92, %t85
  ret i32 %t93
edge_0:
  br label %b3
edge_1:
  br label %b1
edge_2:
  br label %b3
edge_3:
  br label %b2
}

define i32 @calculate(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_0(i32 %a0, i32 %a1)
  ret i32 %result
}
