import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/f0c12f106c89/hepta-next-migration')
out = Path(__file__).resolve().parent
python = '/workspace/scratch/f0c12f106c89/hepta-native-venv/bin/python'
clang = '/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/llvm-20/bin/clang'
env = dict(os.environ)
overrides = {
    'PYTHONDONTWRITEBYTECODE': '1', 'CLANG': clang, 'HEPTA_CLANG': clang,
    'HEPTA_LLD': '/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/llvm-20/bin/ld.lld',
    'LD_LIBRARY_PATH': '/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/x86_64-linux-gnu:/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/llvm-20/lib',
}
env.update(overrides)
argv = [python, 'tools/qualify_hia_stb_divide_update.py', '--output', str(out / 'qualification'),
        '--clang', clang, '--gcc', '/usr/bin/gcc', '--source-sha', 'ffe4a1271098973692a049e3a58de9246a008680']
started = time.monotonic_ns()
report = {'argv': argv, 'cwd': str(root), 'environment_overrides': overrides,
          'launcher_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'started_utc_ns': time.time_ns(), 'returncode': None, 'status': 'started'}
(out / 'launch.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    with (out / 'stdout.txt').open('xb') as stdout, (out / 'stderr.txt').open('xb') as stderr:
        process = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=180)
    report.update(returncode=process.returncode, status='completed')
except BaseException as error:
    report.update(status='failed', error={'type': type(error).__name__, 'message': str(error)})
finally:
    report['outer_wall_ns'] = time.monotonic_ns() - started
    report['streams'] = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                         for name in ('stdout.txt', 'stderr.txt') if (data := (out / name).read_bytes()) is not None}
    (out / 'launch.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
raise SystemExit(0 if report['returncode'] == 0 else 1)
