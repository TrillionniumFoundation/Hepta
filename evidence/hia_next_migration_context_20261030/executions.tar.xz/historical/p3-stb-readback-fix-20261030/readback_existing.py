import copy
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import time
from unittest.mock import patch

root = Path('/workspace/scratch/f0c12f106c89/hepta-next-migration')
sys.path.insert(0, str(root))
from tools import qualify_hia_stb_divide_update as q

source = Path('/workspace/scratch/f0c12f106c89/p3-stb-exact-ffe4a127/qualification')
out = Path(__file__).resolve().parent
original_bytes = (source / 'qualification.json').read_bytes()
original = json.loads(original_bytes)
started = time.monotonic_ns()
results = []
def rejected(label, directory, report):
    try:
        q.validate_qualification(directory, report)
    except ValueError as error:
        results.append({'mutation': label, 'rejected': True, 'message': str(error)})
    else:
        raise AssertionError('accepted mutation: ' + label)

with patch.object(q, 'execute_program', side_effect=AssertionError('no VM execution in readback')), \
     patch.object(q, 'run_bounded', side_effect=AssertionError('no native launch in readback')), \
     patch.object(q, 'build_program_native', side_effect=AssertionError('no build in readback')):
    positive = q.validate_qualification(source)
    for vi in (0, 1):
        for collection in ('witnesses', 'invalid_target_inputs'):
            for field, value in (('program_sha256', '0' * 64), ('input_sha256', '0' * 64),
                                 ('function', 'other'), ('status', 'unknown')):
                changed = copy.deepcopy(original)
                changed['versions'][vi][collection][0]['vm']['observation'][field] = value
                rejected(f'{vi}/{collection}/inner-{field}', source, changed)
            changed = copy.deepcopy(original)
            changed['versions'][vi][collection][0]['vm']['wall_ns'] = -1
            rejected(f'{vi}/{collection}/negative-wall', source, changed)
    for label in ('source_tree', 'source_file_digest'):
        changed = copy.deepcopy(original)
        for key in ('source_before', 'source_after'):
            if label == 'source_tree':
                changed[key]['tree'] = '0' * 40
            else:
                changed[key]['files']['hepta/hia_program.py']['sha256'] = '0' * 64
        rejected(label, source, changed)
    with tempfile.TemporaryDirectory(prefix='stb-pure-readback-', dir=out) as temporary:
        moved = Path(temporary) / 'copy'
        shutil.copytree(source, moved)
        q.validate_qualification(moved)
        for version, label in (('0.93', 'common'), ('0.94', 'common'), ('0.94', 'successor-only')):
            name = version + '/' + label + '-vm.jsonl'
            path = moved / name
            before = path.read_bytes()
            for mutation in ('program_sha256', 'function', 'values', 'typed_arguments', 'typed_expected'):
                rows = [json.loads(line) for line in before.splitlines()]
                row = rows[0]
                if mutation == 'program_sha256': row['observation'][mutation] = '0' * 64
                elif mutation == 'function': row['observation'][mutation] = 'other'
                elif mutation == 'values': row['observation'][mutation] = [123]
                elif mutation == 'typed_arguments': row['arguments'] = [True, 1]
                else: row['expected'] = True
                path.write_text(''.join(q.wire(item) + '\n' for item in rows))
                changed = copy.deepcopy(original)
                changed['retained_files'][name] = q.identity(path)
                rejected(name + '/rehashed-' + mutation, moved, changed)
            path.write_bytes(before)

assert (source / 'qualification.json').read_bytes() == original_bytes
assert q.validate_qualification(source)['verified']
report = {'historical_source_commit': 'ffe4a1271098973692a049e3a58de9246a008680',
          'historical_qualification_sha256': hashlib.sha256(original_bytes).hexdigest(),
          'original_report_unchanged': True, 'positive_readback': positive,
          'mutations': results, 'rejected_mutations': len(results),
          'new_native_executions': 0, 'new_vm_executions': 0, 'new_native_builds': 0,
          'current_source_state': q.source_state(), 'wall_ns': time.monotonic_ns() - started,
          'scope': 'pure retained-observation regression; not a new execution qualification'}
destination = out / (sys.argv[1] if len(sys.argv) == 2 else 'readback-result.json')
with destination.open('x') as stream:
    stream.write(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: report[key] for key in ('original_report_unchanged', 'rejected_mutations',
    'new_native_executions', 'new_vm_executions', 'new_native_builds', 'wall_ns')}, sort_keys=True))
