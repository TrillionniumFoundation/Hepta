"""Actual native-bank reproduction; does not patch source, limits or launch."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

REPO = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(REPO))
from hepta import hia_finite_context as fc
from tests.test_hia_finite_context import request, shift_oracle, shift_program

started = time.monotonic_ns()
report = {"schema": "hepta.finite-context-reentrancy-reproduction.v1",
          "source_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
          "source_file_sha256": hashlib.sha256((REPO / "hepta/hia_finite_context.py").read_bytes()).hexdigest(),
          "actual_native_factory": True, "limit_or_launch_patches": False, "observations": []}

for reuse in (False, True):
    holder = {"armed": False}
    def oracle(x, y):
        if holder["armed"]:
            holder["armed"] = False
            holder["callback_close"] = holder["bank"].close()
        return shift_oracle(x, y)
    with tempfile.TemporaryDirectory(prefix="hia-reentrant-close-before-") as directory:
        preparation = {}
        bank = fc.build_bank(shift_program(), {"baseline": shift_program()}, Path(directory),
                             clang=os.environ["CLANG"], cases=[[1, 0], [1, 4], [2, 1]],
                             oracle=oracle, report=preparation, reuse_oracle=reuse)
        holder["bank"] = bank
        initial = bank.run(bank.prepare_trace([request(seed=2, values=[1])]))
        holder["armed"] = True
        trace = bank.prepare_trace([request(seed=7, values=[2])])
        row = {"scenario": "oracle_closes_bank", "reuse_oracle": reuse,
               "preparation": preparation, "initial_native_run": initial,
               "callback_close": holder["callback_close"], "after_prepare": bank.state(),
               "references_after_prepare": bank.oracle_reference_statistics()}
        try:
            bank.run(trace)
        except fc.FiniteContextRejected as error:
            row["later_run_rejection"] = str(error)
        else:
            raise AssertionError("closed bank unexpectedly executed")
        row["repeated_close"] = bank.close()
        assert row["after_prepare"]["closed"] and row["after_prepare"]["pending_traces"] == 1
        assert row["callback_close"]["pending_input_bytes"] == 0 < row["after_prepare"]["pending_input_bytes"]
        report["observations"].append(row)

holder = {"armed": False}
huge = [fc.MASK32] * fc.MAX_CALLS
def oracle(x, y):
    if holder["armed"]:
        holder["armed"] = False
        holder["inner"] = holder["bank"].prepare_trace([request(ident=2, seed=1, values=huge)])
    return shift_oracle(x, y)
with tempfile.TemporaryDirectory(prefix="hia-reentrant-quota-before-") as directory:
    preparation = {}
    bank = fc.build_bank(shift_program(), {"baseline": shift_program()}, Path(directory),
                         clang=os.environ["CLANG"], cases=[[1, 0], [1, 4]], oracle=oracle, report=preparation)
    holder["bank"] = bank
    holder["armed"] = True
    bank.prepare_trace([request(ident=1, seed=1, values=huge)])
    state = bank.state()
    assert state["pending_input_bytes"] > fc.MAX_PENDING_INPUT_BYTES
    report["observations"].append({"scenario": "nested_preparation_exceeds_real_byte_quota",
        "preparation": preparation, "after_prepare": state,
        "production_quota_bytes": fc.MAX_PENDING_INPUT_BYTES,
        "native_trace_started": False, "release": bank.close()})
report["outer_wall_ns"] = time.monotonic_ns() - started
report["reproduced"] = True
print(json.dumps(report, indent=2, sort_keys=True))
