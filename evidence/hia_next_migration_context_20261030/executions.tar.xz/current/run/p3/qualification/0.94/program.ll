; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i1 %p_0_0) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  ret i32 1
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  ret i32 0
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_1(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = trunc i64 0 to i32
  %t3 = icmp ne i32 %p_0_1, 0
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = icmp eq i32 %p_0_0, -2147483648
  %t6 = icmp eq i32 %p_0_1, -1
  %t7 = and i1 %t5, %t6
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = sdiv i32 %p_0_0, %p_0_1
  %t11 = icmp ne i32 %p_0_1, 0
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = icmp eq i32 %p_0_0, -2147483648
  %t14 = icmp eq i32 %p_0_1, -1
  %t15 = and i1 %t13, %t14
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = srem i32 %p_0_0, %p_0_1
  %t19 = trunc i64 0 to i32
  %t20 = icmp sge i32 %t18, %t19
  br i1 %t20, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_4 = phi i32 [ %t10, %edge_0 ]
  %p_1_5 = phi i32 [ %t18, %edge_0 ]
  ret i32 %p_1_4
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_4 = phi i32 [ %t10, %edge_1 ]
  %p_2_5 = phi i32 [ %t18, %edge_1 ]
  %t21 = call i32 @__hia_fn_7(i32 %p_2_3)
  %t22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_2_4, i32 %t21)
  %t23 = extractvalue { i32, i1 } %t22, 0
  %t24 = extractvalue { i32, i1 } %t22, 1
  %t25 = xor i1 %t24, true
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  ret i32 %t23
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_2(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sge i32 %p_0_0, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_4 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_5 = phi i64 [ 0, %edge_0 ]
  %p_1_6 = phi i32 [ %t1, %edge_0 ]
  %p_1_7 = phi i1 [ %t2, %edge_0 ]
  %p_1_8 = phi i1 [ %t2, %edge_0 ]
  %t3 = trunc i64 0 to i32
  %t4 = icmp slt i32 %p_1_3, %t3
  br label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_4 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_5 = phi i64 [ 0, %edge_1 ]
  %p_2_6 = phi i32 [ %t1, %edge_1 ]
  %p_2_7 = phi i1 [ %t2, %edge_1 ]
  %p_2_8 = phi i1 [ %t2, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i32 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i32 [ %p_1_4, %edge_2 ], [ %p_2_4, %edge_3 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ], [ %p_2_5, %edge_3 ]
  %p_3_6 = phi i32 [ %p_1_6, %edge_2 ], [ %p_2_6, %edge_3 ]
  %p_3_7 = phi i1 [ %p_1_7, %edge_2 ], [ %p_2_7, %edge_3 ]
  %p_3_8 = phi i1 [ %t4, %edge_2 ], [ %p_2_7, %edge_3 ]
  br i1 %p_3_8, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i32 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i32 [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_3_3, %edge_4 ]
  %t5 = trunc i64 1 to i32
  %t6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_4_3, i32 %t5)
  %t7 = extractvalue { i32, i1 } %t6, 0
  %t8 = extractvalue { i32, i1 } %t6, 1
  %t9 = xor i1 %t8, true
  br i1 %t9, label %ok_10, label %trap_10
trap_10:
  call void @abort()
  unreachable
ok_10:
  %t11 = trunc i64 2147483647 to i32
  %t12 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t11)
  %t13 = extractvalue { i32, i1 } %t12, 0
  %t14 = extractvalue { i32, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  %t17 = trunc i64 1 to i32
  %t18 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t13, i32 %t17)
  %t19 = extractvalue { i32, i1 } %t18, 0
  %t20 = extractvalue { i32, i1 } %t18, 1
  %t21 = xor i1 %t20, true
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  %t23 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t19, i32 %p_4_2)
  %t24 = extractvalue { i32, i1 } %t23, 0
  %t25 = extractvalue { i32, i1 } %t23, 1
  %t26 = xor i1 %t25, true
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  %t28 = icmp sge i32 %t7, %t24
  br i1 %t28, label %edge_6, label %edge_7
b5:
  %p_5_0 = phi i32 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_5 ]
  %p_5_2 = phi i32 [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i32 [ %p_3_3, %edge_5 ]
  %t29 = trunc i64 0 to i32
  %t30 = icmp slt i32 %p_5_2, %t29
  br i1 %t30, label %edge_8, label %edge_9
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_6 ]
  %p_6_2 = phi i32 [ %p_4_2, %edge_6 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_6 ]
  %t31 = trunc i64 1 to i32
  %t32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_6_3, i32 %t31)
  %t33 = extractvalue { i32, i1 } %t32, 0
  %t34 = extractvalue { i32, i1 } %t32, 1
  %t35 = xor i1 %t34, true
  br i1 %t35, label %ok_36, label %trap_36
trap_36:
  call void @abort()
  unreachable
ok_36:
  %t37 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t33, i32 %p_6_2)
  %t38 = extractvalue { i32, i1 } %t37, 0
  %t39 = extractvalue { i32, i1 } %t37, 1
  %t40 = xor i1 %t39, true
  br i1 %t40, label %ok_41, label %trap_41
trap_41:
  call void @abort()
  unreachable
ok_41:
  %t42 = icmp ne i32 %p_6_3, 0
  br i1 %t42, label %ok_43, label %trap_43
trap_43:
  call void @abort()
  unreachable
ok_43:
  %t44 = icmp eq i32 %t38, -2147483648
  %t45 = icmp eq i32 %p_6_3, -1
  %t46 = and i1 %t44, %t45
  %t47 = xor i1 %t46, true
  br i1 %t47, label %ok_48, label %trap_48
trap_48:
  call void @abort()
  unreachable
ok_48:
  %t49 = sdiv i32 %t38, %p_6_3
  %t50 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t49)
  %t51 = extractvalue { i32, i1 } %t50, 0
  %t52 = extractvalue { i32, i1 } %t50, 1
  %t53 = xor i1 %t52, true
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  ret i32 %t51
b7:
  %p_7_0 = phi i32 [ %p_4_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_4_1, %edge_7 ]
  %p_7_2 = phi i32 [ %p_4_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_4_3, %edge_7 ]
  %t55 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_7_2)
  %t56 = extractvalue { i32, i1 } %t55, 0
  %t57 = extractvalue { i32, i1 } %t55, 1
  %t58 = xor i1 %t57, true
  br i1 %t58, label %ok_59, label %trap_59
trap_59:
  call void @abort()
  unreachable
ok_59:
  %t60 = icmp ne i32 %p_7_3, 0
  br i1 %t60, label %ok_61, label %trap_61
trap_61:
  call void @abort()
  unreachable
ok_61:
  %t62 = icmp eq i32 %t56, -2147483648
  %t63 = icmp eq i32 %p_7_3, -1
  %t64 = and i1 %t62, %t63
  %t65 = xor i1 %t64, true
  br i1 %t65, label %ok_66, label %trap_66
trap_66:
  call void @abort()
  unreachable
ok_66:
  %t67 = sdiv i32 %t56, %p_7_3
  %t68 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t67)
  %t69 = extractvalue { i32, i1 } %t68, 0
  %t70 = extractvalue { i32, i1 } %t68, 1
  %t71 = xor i1 %t70, true
  br i1 %t71, label %ok_72, label %trap_72
trap_72:
  call void @abort()
  unreachable
ok_72:
  %t73 = call i32 @__hia_fn_8(i32 %p_7_2, i32 %p_7_3)
  %t74 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t69, i32 %t73)
  %t75 = extractvalue { i32, i1 } %t74, 0
  %t76 = extractvalue { i32, i1 } %t74, 1
  %t77 = xor i1 %t76, true
  br i1 %t77, label %ok_78, label %trap_78
trap_78:
  call void @abort()
  unreachable
ok_78:
  ret i32 %t75
b8:
  %p_8_0 = phi i32 [ %p_5_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_5_1, %edge_8 ]
  %p_8_2 = phi i32 [ %p_5_2, %edge_8 ]
  %p_8_3 = phi i32 [ %p_5_3, %edge_8 ]
  %p_8_4 = phi i32 [ %p_5_2, %edge_8 ]
  %p_8_5 = phi i64 [ 0, %edge_8 ]
  %p_8_6 = phi i32 [ %t29, %edge_8 ]
  %p_8_7 = phi i1 [ %t30, %edge_8 ]
  %p_8_8 = phi i1 [ %t30, %edge_8 ]
  %t79 = trunc i64 0 to i32
  %t80 = icmp sge i32 %p_8_3, %t79
  br label %edge_10
b9:
  %p_9_0 = phi i32 [ %p_5_0, %edge_9 ]
  %p_9_1 = phi i32 [ %p_5_1, %edge_9 ]
  %p_9_2 = phi i32 [ %p_5_2, %edge_9 ]
  %p_9_3 = phi i32 [ %p_5_3, %edge_9 ]
  %p_9_4 = phi i32 [ %p_5_2, %edge_9 ]
  %p_9_5 = phi i64 [ 0, %edge_9 ]
  %p_9_6 = phi i32 [ %t29, %edge_9 ]
  %p_9_7 = phi i1 [ %t30, %edge_9 ]
  %p_9_8 = phi i1 [ %t30, %edge_9 ]
  br label %edge_11
b10:
  %p_10_0 = phi i32 [ %p_8_0, %edge_10 ], [ %p_9_0, %edge_11 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_10 ], [ %p_9_1, %edge_11 ]
  %p_10_2 = phi i32 [ %p_8_2, %edge_10 ], [ %p_9_2, %edge_11 ]
  %p_10_3 = phi i32 [ %p_8_3, %edge_10 ], [ %p_9_3, %edge_11 ]
  %p_10_4 = phi i32 [ %p_8_4, %edge_10 ], [ %p_9_4, %edge_11 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ], [ %p_9_5, %edge_11 ]
  %p_10_6 = phi i32 [ %p_8_6, %edge_10 ], [ %p_9_6, %edge_11 ]
  %p_10_7 = phi i1 [ %p_8_7, %edge_10 ], [ %p_9_7, %edge_11 ]
  %p_10_8 = phi i1 [ %t80, %edge_10 ], [ %p_9_7, %edge_11 ]
  br i1 %p_10_8, label %edge_12, label %edge_13
b11:
  %p_11_0 = phi i32 [ %p_10_0, %edge_12 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ]
  %p_11_2 = phi i32 [ %p_10_2, %edge_12 ]
  %p_11_3 = phi i32 [ %p_10_3, %edge_12 ]
  %t81 = trunc i64 2147483647 to i32
  %t82 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t81)
  %t83 = extractvalue { i32, i1 } %t82, 0
  %t84 = extractvalue { i32, i1 } %t82, 1
  %t85 = xor i1 %t84, true
  br i1 %t85, label %ok_86, label %trap_86
trap_86:
  call void @abort()
  unreachable
ok_86:
  %t87 = trunc i64 1 to i32
  %t88 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t83, i32 %t87)
  %t89 = extractvalue { i32, i1 } %t88, 0
  %t90 = extractvalue { i32, i1 } %t88, 1
  %t91 = xor i1 %t90, true
  br i1 %t91, label %ok_92, label %trap_92
trap_92:
  call void @abort()
  unreachable
ok_92:
  %t93 = icmp ne i32 %p_11_2, %t89
  br i1 %t93, label %edge_14, label %edge_15
b12:
  %p_12_0 = phi i32 [ %p_10_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_10_1, %edge_13 ]
  %p_12_2 = phi i32 [ %p_10_2, %edge_13 ]
  %p_12_3 = phi i32 [ %p_10_3, %edge_13 ]
  %t94 = icmp ne i32 %p_12_3, 0
  br i1 %t94, label %ok_95, label %trap_95
trap_95:
  call void @abort()
  unreachable
ok_95:
  %t96 = icmp eq i32 %p_12_2, -2147483648
  %t97 = icmp eq i32 %p_12_3, -1
  %t98 = and i1 %t96, %t97
  %t99 = xor i1 %t98, true
  br i1 %t99, label %ok_100, label %trap_100
trap_100:
  call void @abort()
  unreachable
ok_100:
  %t101 = sdiv i32 %p_12_2, %p_12_3
  ret i32 %t101
b13:
  %p_13_0 = phi i32 [ %p_11_0, %edge_14 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_13_2 = phi i32 [ %p_11_2, %edge_14 ]
  %p_13_3 = phi i32 [ %p_11_3, %edge_14 ]
  %t102 = trunc i64 1 to i32
  %t103 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_13_2, i32 %t102)
  %t104 = extractvalue { i32, i1 } %t103, 0
  %t105 = extractvalue { i32, i1 } %t103, 1
  %t106 = xor i1 %t105, true
  br i1 %t106, label %ok_107, label %trap_107
trap_107:
  call void @abort()
  unreachable
ok_107:
  %t108 = trunc i64 2147483647 to i32
  %t109 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t108)
  %t110 = extractvalue { i32, i1 } %t109, 0
  %t111 = extractvalue { i32, i1 } %t109, 1
  %t112 = xor i1 %t111, true
  br i1 %t112, label %ok_113, label %trap_113
trap_113:
  call void @abort()
  unreachable
ok_113:
  %t114 = trunc i64 1 to i32
  %t115 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t110, i32 %t114)
  %t116 = extractvalue { i32, i1 } %t115, 0
  %t117 = extractvalue { i32, i1 } %t115, 1
  %t118 = xor i1 %t117, true
  br i1 %t118, label %ok_119, label %trap_119
trap_119:
  call void @abort()
  unreachable
ok_119:
  %t120 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t116, i32 %p_13_3)
  %t121 = extractvalue { i32, i1 } %t120, 0
  %t122 = extractvalue { i32, i1 } %t120, 1
  %t123 = xor i1 %t122, true
  br i1 %t123, label %ok_124, label %trap_124
trap_124:
  call void @abort()
  unreachable
ok_124:
  %t125 = icmp sge i32 %t104, %t121
  br i1 %t125, label %edge_16, label %edge_17
b14:
  %p_14_0 = phi i32 [ %p_11_0, %edge_15 ]
  %p_14_1 = phi i32 [ %p_11_1, %edge_15 ]
  %p_14_2 = phi i32 [ %p_11_2, %edge_15 ]
  %p_14_3 = phi i32 [ %p_11_3, %edge_15 ]
  %t126 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_14_2, i32 %p_14_3)
  %t127 = extractvalue { i32, i1 } %t126, 0
  %t128 = extractvalue { i32, i1 } %t126, 1
  %t129 = xor i1 %t128, true
  br i1 %t129, label %ok_130, label %trap_130
trap_130:
  call void @abort()
  unreachable
ok_130:
  %t131 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t127)
  %t132 = extractvalue { i32, i1 } %t131, 0
  %t133 = extractvalue { i32, i1 } %t131, 1
  %t134 = xor i1 %t133, true
  br i1 %t134, label %ok_135, label %trap_135
trap_135:
  call void @abort()
  unreachable
ok_135:
  %t136 = icmp ne i32 %p_14_3, 0
  br i1 %t136, label %ok_137, label %trap_137
trap_137:
  call void @abort()
  unreachable
ok_137:
  %t138 = icmp eq i32 %t132, -2147483648
  %t139 = icmp eq i32 %p_14_3, -1
  %t140 = and i1 %t138, %t139
  %t141 = xor i1 %t140, true
  br i1 %t141, label %ok_142, label %trap_142
trap_142:
  call void @abort()
  unreachable
ok_142:
  %t143 = sdiv i32 %t132, %p_14_3
  %t144 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t143)
  %t145 = extractvalue { i32, i1 } %t144, 0
  %t146 = extractvalue { i32, i1 } %t144, 1
  %t147 = xor i1 %t146, true
  br i1 %t147, label %ok_148, label %trap_148
trap_148:
  call void @abort()
  unreachable
ok_148:
  %t149 = call i32 @__hia_fn_10(i32 %p_14_2, i32 %p_14_3)
  %t150 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t145, i32 %t149)
  %t151 = extractvalue { i32, i1 } %t150, 0
  %t152 = extractvalue { i32, i1 } %t150, 1
  %t153 = xor i1 %t152, true
  br i1 %t153, label %ok_154, label %trap_154
trap_154:
  call void @abort()
  unreachable
ok_154:
  ret i32 %t151
b15:
  %p_15_0 = phi i32 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i32 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi i32 [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i32 [ %p_13_3, %edge_16 ]
  %t155 = trunc i64 1 to i32
  %t156 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_15_2, i32 %t155)
  %t157 = extractvalue { i32, i1 } %t156, 0
  %t158 = extractvalue { i32, i1 } %t156, 1
  %t159 = xor i1 %t158, true
  br i1 %t159, label %ok_160, label %trap_160
trap_160:
  call void @abort()
  unreachable
ok_160:
  %t161 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t157, i32 %p_15_3)
  %t162 = extractvalue { i32, i1 } %t161, 0
  %t163 = extractvalue { i32, i1 } %t161, 1
  %t164 = xor i1 %t163, true
  br i1 %t164, label %ok_165, label %trap_165
trap_165:
  call void @abort()
  unreachable
ok_165:
  %t166 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_15_3)
  %t167 = extractvalue { i32, i1 } %t166, 0
  %t168 = extractvalue { i32, i1 } %t166, 1
  %t169 = xor i1 %t168, true
  br i1 %t169, label %ok_170, label %trap_170
trap_170:
  call void @abort()
  unreachable
ok_170:
  %t171 = icmp ne i32 %t167, 0
  br i1 %t171, label %ok_172, label %trap_172
trap_172:
  call void @abort()
  unreachable
ok_172:
  %t173 = icmp eq i32 %t162, -2147483648
  %t174 = icmp eq i32 %t167, -1
  %t175 = and i1 %t173, %t174
  %t176 = xor i1 %t175, true
  br i1 %t176, label %ok_177, label %trap_177
trap_177:
  call void @abort()
  unreachable
ok_177:
  %t178 = sdiv i32 %t162, %t167
  %t179 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t178)
  %t180 = extractvalue { i32, i1 } %t179, 0
  %t181 = extractvalue { i32, i1 } %t179, 1
  %t182 = xor i1 %t181, true
  br i1 %t182, label %ok_183, label %trap_183
trap_183:
  call void @abort()
  unreachable
ok_183:
  ret i32 %t180
b16:
  %p_16_0 = phi i32 [ %p_13_0, %edge_17 ]
  %p_16_1 = phi i32 [ %p_13_1, %edge_17 ]
  %p_16_2 = phi i32 [ %p_13_2, %edge_17 ]
  %p_16_3 = phi i32 [ %p_13_3, %edge_17 ]
  %t184 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_16_2)
  %t185 = extractvalue { i32, i1 } %t184, 0
  %t186 = extractvalue { i32, i1 } %t184, 1
  %t187 = xor i1 %t186, true
  br i1 %t187, label %ok_188, label %trap_188
trap_188:
  call void @abort()
  unreachable
ok_188:
  %t189 = icmp ne i32 %p_16_3, 0
  br i1 %t189, label %ok_190, label %trap_190
trap_190:
  call void @abort()
  unreachable
ok_190:
  %t191 = icmp eq i32 %t185, -2147483648
  %t192 = icmp eq i32 %p_16_3, -1
  %t193 = and i1 %t191, %t192
  %t194 = xor i1 %t193, true
  br i1 %t194, label %ok_195, label %trap_195
trap_195:
  call void @abort()
  unreachable
ok_195:
  %t196 = sdiv i32 %t185, %p_16_3
  %t197 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t196)
  %t198 = extractvalue { i32, i1 } %t197, 0
  %t199 = extractvalue { i32, i1 } %t197, 1
  %t200 = xor i1 %t199, true
  br i1 %t200, label %ok_201, label %trap_201
trap_201:
  call void @abort()
  unreachable
ok_201:
  %t202 = call i32 @__hia_fn_9(i32 %p_16_2, i32 %p_16_3)
  %t203 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t198, i32 %t202)
  %t204 = extractvalue { i32, i1 } %t203, 0
  %t205 = extractvalue { i32, i1 } %t203, 1
  %t206 = xor i1 %t205, true
  br i1 %t206, label %ok_207, label %trap_207
trap_207:
  call void @abort()
  unreachable
ok_207:
  ret i32 %t204
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b10
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b16
}

define internal i32 @__hia_fn_3(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ne i32 %p_0_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_0_0, -2147483648
  %t4 = icmp eq i32 %p_0_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = sdiv i32 %p_0_0, %p_0_1
  ret i32 %t8
}

define internal i32 @__hia_fn_4(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ne i32 %p_0_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_0_0, -2147483648
  %t4 = icmp eq i32 %p_0_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = srem i32 %p_0_0, %p_0_1
  %t9 = trunc i64 0 to i32
  %t10 = icmp sge i32 %t8, %t9
  br i1 %t10, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_4 = phi i32 [ %t8, %edge_0 ]
  ret i32 %p_1_4
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_4 = phi i32 [ %t8, %edge_1 ]
  %t11 = call i32 @__hia_fn_11(i32 %p_2_3)
  %t12 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_2_4, i32 %t11)
  %t13 = extractvalue { i32, i1 } %t12, 0
  %t14 = extractvalue { i32, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  ret i32 %t13
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_5(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sge i32 %p_0_1, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %t3 = icmp ne i32 %p_1_3, 0
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = icmp eq i32 %p_1_2, -2147483648
  %t6 = icmp eq i32 %p_1_3, -1
  %t7 = and i1 %t5, %t6
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = srem i32 %p_1_2, %p_1_3
  %t11 = trunc i64 0 to i32
  %t12 = icmp sge i32 %t10, %t11
  br i1 %t12, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %t13 = icmp ne i32 %p_2_3, 0
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = icmp eq i32 %p_2_2, -2147483648
  %t16 = icmp eq i32 %p_2_3, -1
  %t17 = and i1 %t15, %t16
  %t18 = xor i1 %t17, true
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = srem i32 %p_2_2, %p_2_3
  %t21 = trunc i64 0 to i32
  %t22 = icmp sle i32 %t20, %t21
  br i1 %t22, label %edge_4, label %edge_5
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i32 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i32 [ %t10, %edge_2 ]
  ret i32 %p_3_4
b4:
  %p_4_0 = phi i32 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i32 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i32 [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i32 [ %t10, %edge_3 ]
  %t23 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_4_4, i32 %p_4_3)
  %t24 = extractvalue { i32, i1 } %t23, 0
  %t25 = extractvalue { i32, i1 } %t23, 1
  %t26 = xor i1 %t25, true
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  ret i32 %t24
b5:
  %p_5_0 = phi i32 [ %p_2_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_5_2 = phi i32 [ %p_2_2, %edge_4 ]
  %p_5_3 = phi i32 [ %p_2_3, %edge_4 ]
  %p_5_4 = phi i32 [ %t20, %edge_4 ]
  ret i32 %p_5_4
b6:
  %p_6_0 = phi i32 [ %p_2_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_2_1, %edge_5 ]
  %p_6_2 = phi i32 [ %p_2_2, %edge_5 ]
  %p_6_3 = phi i32 [ %p_2_3, %edge_5 ]
  %p_6_4 = phi i32 [ %t20, %edge_5 ]
  %t28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_6_4, i32 %p_6_3)
  %t29 = extractvalue { i32, i1 } %t28, 0
  %t30 = extractvalue { i32, i1 } %t28, 1
  %t31 = xor i1 %t30, true
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  ret i32 %t29
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define internal i32 @__hia_fn_6(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ne i32 %p_0_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_0_0, -2147483648
  %t4 = icmp eq i32 %p_0_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = srem i32 %p_0_0, %p_0_1
  ret i32 %t8
}

define internal i32 @__hia_fn_7(i32 %p_0_0) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sgt i32 %p_0_0, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %t3 = trunc i64 1 to i32
  %t4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t3)
  %t5 = extractvalue { i32, i1 } %t4, 0
  %t6 = extractvalue { i32, i1 } %t4, 1
  %t7 = xor i1 %t6, true
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  ret i32 %t5
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %t9 = trunc i64 1 to i32
  ret i32 %t9
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_8(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_0_0)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = icmp ne i32 %p_0_1, 0
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = icmp eq i32 %t2, -2147483648
  %t9 = icmp eq i32 %p_0_1, -1
  %t10 = and i1 %t8, %t9
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = srem i32 %t2, %p_0_1
  %t14 = trunc i64 0 to i32
  %t15 = icmp ne i32 %t13, %t14
  br i1 %t15, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t16 = trunc i64 1 to i32
  %t17 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t16)
  %t18 = extractvalue { i32, i1 } %t17, 0
  %t19 = extractvalue { i32, i1 } %t17, 1
  %t20 = xor i1 %t19, true
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  ret i32 %t18
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t22 = trunc i64 0 to i32
  ret i32 %t22
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_9(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_0_1)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = icmp ne i32 %t2, 0
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = icmp eq i32 %p_0_0, -2147483648
  %t9 = icmp eq i32 %t2, -1
  %t10 = and i1 %t8, %t9
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = srem i32 %p_0_0, %t2
  %t14 = trunc i64 0 to i32
  %t15 = icmp ne i32 %t13, %t14
  br i1 %t15, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t16 = trunc i64 1 to i32
  %t17 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t16)
  %t18 = extractvalue { i32, i1 } %t17, 0
  %t19 = extractvalue { i32, i1 } %t17, 1
  %t20 = xor i1 %t19, true
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  ret i32 %t18
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t22 = trunc i64 0 to i32
  ret i32 %t22
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_10(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_0_0, i32 %p_0_1)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t2)
  %t7 = extractvalue { i32, i1 } %t6, 0
  %t8 = extractvalue { i32, i1 } %t6, 1
  %t9 = xor i1 %t8, true
  br i1 %t9, label %ok_10, label %trap_10
trap_10:
  call void @abort()
  unreachable
ok_10:
  %t11 = icmp ne i32 %p_0_1, 0
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = icmp eq i32 %t7, -2147483648
  %t14 = icmp eq i32 %p_0_1, -1
  %t15 = and i1 %t13, %t14
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = srem i32 %t7, %p_0_1
  %t19 = trunc i64 0 to i32
  %t20 = icmp ne i32 %t18, %t19
  br i1 %t20, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t21 = trunc i64 2 to i32
  %t22 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t21)
  %t23 = extractvalue { i32, i1 } %t22, 0
  %t24 = extractvalue { i32, i1 } %t22, 1
  %t25 = xor i1 %t24, true
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  ret i32 %t23
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t27 = trunc i64 1 to i32
  %t28 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t27)
  %t29 = extractvalue { i32, i1 } %t28, 0
  %t30 = extractvalue { i32, i1 } %t28, 1
  %t31 = xor i1 %t30, true
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  ret i32 %t29
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_11(i32 %p_0_0) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp slt i32 %p_0_0, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  ret i32 %p_1_0
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %t3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_2_0)
  %t4 = extractvalue { i32, i1 } %t3, 0
  %t5 = extractvalue { i32, i1 } %t3, 1
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  ret i32 %t4
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_12(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_3(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_13(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_2(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_14(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_1(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_15(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_6(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_16(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_5(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_17(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_4(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define i32 @c_bool_to_int(i1 zeroext %a0) {
entry:
  %result = call i32 @__hia_fn_0(i1 %a0)
  ret i32 %result
}

define i32 @c_stb_div_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_1(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_div_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_2(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_div_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_3(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_mod_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_4(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_mod_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_5(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_mod_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_6(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_1(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_7(i32 %a0)
  ret i32 %result
}

define i32 @migration_conditional_2(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_8(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_3(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_9(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_4(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_10(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_5(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_11(i32 %a0)
  ret i32 %result
}

define i32 @stb_div_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_12(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_div_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_13(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_div_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_14(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_mod_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_15(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_mod_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_16(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_mod_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_17(i32 %a0, i32 %a1)
  ret i32 %result
}
