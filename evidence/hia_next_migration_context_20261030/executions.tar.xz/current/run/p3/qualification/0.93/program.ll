; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i1 %p_0_0) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  ret i32 1
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  ret i32 0
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_1(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = trunc i64 0 to i32
  %t3 = icmp ne i32 %p_0_1, 0
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = icmp eq i32 %p_0_0, -2147483648
  %t6 = icmp eq i32 %p_0_1, -1
  %t7 = and i1 %t5, %t6
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = sdiv i32 %p_0_0, %p_0_1
  %t11 = icmp ne i32 %p_0_1, 0
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = icmp eq i32 %p_0_0, -2147483648
  %t14 = icmp eq i32 %p_0_1, -1
  %t15 = and i1 %t13, %t14
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = srem i32 %p_0_0, %p_0_1
  %t19 = trunc i64 0 to i32
  %t20 = icmp sge i32 %t18, %t19
  br i1 %t20, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_4 = phi i32 [ %t10, %edge_0 ]
  %p_1_5 = phi i32 [ %t18, %edge_0 ]
  ret i32 %p_1_4
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_4 = phi i32 [ %t10, %edge_1 ]
  %p_2_5 = phi i32 [ %t18, %edge_1 ]
  %t21 = call i32 @__hia_fn_7(i32 %p_2_3)
  %t22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_2_4, i32 %t21)
  %t23 = extractvalue { i32, i1 } %t22, 0
  %t24 = extractvalue { i32, i1 } %t22, 1
  %t25 = xor i1 %t24, true
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  ret i32 %t23
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_2(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sge i32 %p_0_0, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_4 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_5 = phi i64 [ 0, %edge_0 ]
  %p_1_6 = phi i32 [ %t1, %edge_0 ]
  %p_1_7 = phi i1 [ %t2, %edge_0 ]
  %p_1_8 = phi i1 [ %t2, %edge_0 ]
  %t3 = trunc i64 0 to i32
  %t4 = icmp slt i32 %p_1_3, %t3
  br label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_4 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_5 = phi i64 [ 0, %edge_1 ]
  %p_2_6 = phi i32 [ %t1, %edge_1 ]
  %p_2_7 = phi i1 [ %t2, %edge_1 ]
  %p_2_8 = phi i1 [ %t2, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i32 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i32 [ %p_1_4, %edge_2 ], [ %p_2_4, %edge_3 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ], [ %p_2_5, %edge_3 ]
  %p_3_6 = phi i32 [ %p_1_6, %edge_2 ], [ %p_2_6, %edge_3 ]
  %p_3_7 = phi i1 [ %p_1_7, %edge_2 ], [ %p_2_7, %edge_3 ]
  %p_3_8 = phi i1 [ %t4, %edge_2 ], [ %p_2_7, %edge_3 ]
  br i1 %p_3_8, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i32 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i32 [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_3_3, %edge_4 ]
  %t5 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_4_2)
  %t6 = extractvalue { i32, i1 } %t5, 0
  %t7 = extractvalue { i32, i1 } %t5, 1
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t6, i32 %p_4_3)
  %t11 = extractvalue { i32, i1 } %t10, 0
  %t12 = extractvalue { i32, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = trunc i64 1 to i32
  %t16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t11, i32 %t15)
  %t17 = extractvalue { i32, i1 } %t16, 0
  %t18 = extractvalue { i32, i1 } %t16, 1
  %t19 = xor i1 %t18, true
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = trunc i64 0 to i32
  %t22 = icmp slt i32 %t17, %t21
  br i1 %t22, label %edge_6, label %edge_7
b5:
  %p_5_0 = phi i32 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_5 ]
  %p_5_2 = phi i32 [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i32 [ %p_3_3, %edge_5 ]
  %t23 = trunc i64 0 to i32
  %t24 = icmp slt i32 %p_5_2, %t23
  br i1 %t24, label %edge_8, label %edge_9
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_6 ]
  %p_6_2 = phi i32 [ %p_4_2, %edge_6 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_6 ]
  %t25 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_6_2)
  %t26 = extractvalue { i32, i1 } %t25, 0
  %t27 = extractvalue { i32, i1 } %t25, 1
  %t28 = xor i1 %t27, true
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  %t30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t26, i32 %p_6_3)
  %t31 = extractvalue { i32, i1 } %t30, 0
  %t32 = extractvalue { i32, i1 } %t30, 1
  %t33 = xor i1 %t32, true
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = trunc i64 1 to i32
  %t36 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t31, i32 %t35)
  %t37 = extractvalue { i32, i1 } %t36, 0
  %t38 = extractvalue { i32, i1 } %t36, 1
  %t39 = xor i1 %t38, true
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = icmp ne i32 %p_6_3, 0
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = icmp eq i32 %t37, -2147483648
  %t44 = icmp eq i32 %p_6_3, -1
  %t45 = and i1 %t43, %t44
  %t46 = xor i1 %t45, true
  br i1 %t46, label %ok_47, label %trap_47
trap_47:
  call void @abort()
  unreachable
ok_47:
  %t48 = sdiv i32 %t37, %p_6_3
  %t49 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t48)
  %t50 = extractvalue { i32, i1 } %t49, 0
  %t51 = extractvalue { i32, i1 } %t49, 1
  %t52 = xor i1 %t51, true
  br i1 %t52, label %ok_53, label %trap_53
trap_53:
  call void @abort()
  unreachable
ok_53:
  ret i32 %t50
b7:
  %p_7_0 = phi i32 [ %p_4_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_4_1, %edge_7 ]
  %p_7_2 = phi i32 [ %p_4_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_4_3, %edge_7 ]
  %t54 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_7_2)
  %t55 = extractvalue { i32, i1 } %t54, 0
  %t56 = extractvalue { i32, i1 } %t54, 1
  %t57 = xor i1 %t56, true
  br i1 %t57, label %ok_58, label %trap_58
trap_58:
  call void @abort()
  unreachable
ok_58:
  %t59 = icmp ne i32 %p_7_3, 0
  br i1 %t59, label %ok_60, label %trap_60
trap_60:
  call void @abort()
  unreachable
ok_60:
  %t61 = icmp eq i32 %t55, -2147483648
  %t62 = icmp eq i32 %p_7_3, -1
  %t63 = and i1 %t61, %t62
  %t64 = xor i1 %t63, true
  br i1 %t64, label %ok_65, label %trap_65
trap_65:
  call void @abort()
  unreachable
ok_65:
  %t66 = sdiv i32 %t55, %p_7_3
  %t67 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t66)
  %t68 = extractvalue { i32, i1 } %t67, 0
  %t69 = extractvalue { i32, i1 } %t67, 1
  %t70 = xor i1 %t69, true
  br i1 %t70, label %ok_71, label %trap_71
trap_71:
  call void @abort()
  unreachable
ok_71:
  %t72 = call i32 @__hia_fn_8(i32 %p_7_2, i32 %p_7_3)
  %t73 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t68, i32 %t72)
  %t74 = extractvalue { i32, i1 } %t73, 0
  %t75 = extractvalue { i32, i1 } %t73, 1
  %t76 = xor i1 %t75, true
  br i1 %t76, label %ok_77, label %trap_77
trap_77:
  call void @abort()
  unreachable
ok_77:
  ret i32 %t74
b8:
  %p_8_0 = phi i32 [ %p_5_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_5_1, %edge_8 ]
  %p_8_2 = phi i32 [ %p_5_2, %edge_8 ]
  %p_8_3 = phi i32 [ %p_5_3, %edge_8 ]
  %p_8_4 = phi i32 [ %p_5_2, %edge_8 ]
  %p_8_5 = phi i64 [ 0, %edge_8 ]
  %p_8_6 = phi i32 [ %t23, %edge_8 ]
  %p_8_7 = phi i1 [ %t24, %edge_8 ]
  %p_8_8 = phi i1 [ %t24, %edge_8 ]
  %t78 = trunc i64 0 to i32
  %t79 = icmp sge i32 %p_8_3, %t78
  br label %edge_10
b9:
  %p_9_0 = phi i32 [ %p_5_0, %edge_9 ]
  %p_9_1 = phi i32 [ %p_5_1, %edge_9 ]
  %p_9_2 = phi i32 [ %p_5_2, %edge_9 ]
  %p_9_3 = phi i32 [ %p_5_3, %edge_9 ]
  %p_9_4 = phi i32 [ %p_5_2, %edge_9 ]
  %p_9_5 = phi i64 [ 0, %edge_9 ]
  %p_9_6 = phi i32 [ %t23, %edge_9 ]
  %p_9_7 = phi i1 [ %t24, %edge_9 ]
  %p_9_8 = phi i1 [ %t24, %edge_9 ]
  br label %edge_11
b10:
  %p_10_0 = phi i32 [ %p_8_0, %edge_10 ], [ %p_9_0, %edge_11 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_10 ], [ %p_9_1, %edge_11 ]
  %p_10_2 = phi i32 [ %p_8_2, %edge_10 ], [ %p_9_2, %edge_11 ]
  %p_10_3 = phi i32 [ %p_8_3, %edge_10 ], [ %p_9_3, %edge_11 ]
  %p_10_4 = phi i32 [ %p_8_4, %edge_10 ], [ %p_9_4, %edge_11 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ], [ %p_9_5, %edge_11 ]
  %p_10_6 = phi i32 [ %p_8_6, %edge_10 ], [ %p_9_6, %edge_11 ]
  %p_10_7 = phi i1 [ %p_8_7, %edge_10 ], [ %p_9_7, %edge_11 ]
  %p_10_8 = phi i1 [ %t79, %edge_10 ], [ %p_9_7, %edge_11 ]
  br i1 %p_10_8, label %edge_12, label %edge_13
b11:
  %p_11_0 = phi i32 [ %p_10_0, %edge_12 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ]
  %p_11_2 = phi i32 [ %p_10_2, %edge_12 ]
  %p_11_3 = phi i32 [ %p_10_3, %edge_12 ]
  %t80 = trunc i64 2147483647 to i32
  %t81 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t80)
  %t82 = extractvalue { i32, i1 } %t81, 0
  %t83 = extractvalue { i32, i1 } %t81, 1
  %t84 = xor i1 %t83, true
  br i1 %t84, label %ok_85, label %trap_85
trap_85:
  call void @abort()
  unreachable
ok_85:
  %t86 = trunc i64 1 to i32
  %t87 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t82, i32 %t86)
  %t88 = extractvalue { i32, i1 } %t87, 0
  %t89 = extractvalue { i32, i1 } %t87, 1
  %t90 = xor i1 %t89, true
  br i1 %t90, label %ok_91, label %trap_91
trap_91:
  call void @abort()
  unreachable
ok_91:
  %t92 = icmp ne i32 %p_11_2, %t88
  br i1 %t92, label %edge_14, label %edge_15
b12:
  %p_12_0 = phi i32 [ %p_10_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_10_1, %edge_13 ]
  %p_12_2 = phi i32 [ %p_10_2, %edge_13 ]
  %p_12_3 = phi i32 [ %p_10_3, %edge_13 ]
  %t93 = icmp ne i32 %p_12_3, 0
  br i1 %t93, label %ok_94, label %trap_94
trap_94:
  call void @abort()
  unreachable
ok_94:
  %t95 = icmp eq i32 %p_12_2, -2147483648
  %t96 = icmp eq i32 %p_12_3, -1
  %t97 = and i1 %t95, %t96
  %t98 = xor i1 %t97, true
  br i1 %t98, label %ok_99, label %trap_99
trap_99:
  call void @abort()
  unreachable
ok_99:
  %t100 = sdiv i32 %p_12_2, %p_12_3
  ret i32 %t100
b13:
  %p_13_0 = phi i32 [ %p_11_0, %edge_14 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_13_2 = phi i32 [ %p_11_2, %edge_14 ]
  %p_13_3 = phi i32 [ %p_11_3, %edge_14 ]
  %t101 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_13_2, i32 %p_13_3)
  %t102 = extractvalue { i32, i1 } %t101, 0
  %t103 = extractvalue { i32, i1 } %t101, 1
  %t104 = xor i1 %t103, true
  br i1 %t104, label %ok_105, label %trap_105
trap_105:
  call void @abort()
  unreachable
ok_105:
  %t106 = trunc i64 1 to i32
  %t107 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t102, i32 %t106)
  %t108 = extractvalue { i32, i1 } %t107, 0
  %t109 = extractvalue { i32, i1 } %t107, 1
  %t110 = xor i1 %t109, true
  br i1 %t110, label %ok_111, label %trap_111
trap_111:
  call void @abort()
  unreachable
ok_111:
  %t112 = trunc i64 0 to i32
  %t113 = icmp slt i32 %t108, %t112
  br i1 %t113, label %edge_16, label %edge_17
b14:
  %p_14_0 = phi i32 [ %p_11_0, %edge_15 ]
  %p_14_1 = phi i32 [ %p_11_1, %edge_15 ]
  %p_14_2 = phi i32 [ %p_11_2, %edge_15 ]
  %p_14_3 = phi i32 [ %p_11_3, %edge_15 ]
  %t114 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_14_2, i32 %p_14_3)
  %t115 = extractvalue { i32, i1 } %t114, 0
  %t116 = extractvalue { i32, i1 } %t114, 1
  %t117 = xor i1 %t116, true
  br i1 %t117, label %ok_118, label %trap_118
trap_118:
  call void @abort()
  unreachable
ok_118:
  %t119 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t115)
  %t120 = extractvalue { i32, i1 } %t119, 0
  %t121 = extractvalue { i32, i1 } %t119, 1
  %t122 = xor i1 %t121, true
  br i1 %t122, label %ok_123, label %trap_123
trap_123:
  call void @abort()
  unreachable
ok_123:
  %t124 = icmp ne i32 %p_14_3, 0
  br i1 %t124, label %ok_125, label %trap_125
trap_125:
  call void @abort()
  unreachable
ok_125:
  %t126 = icmp eq i32 %t120, -2147483648
  %t127 = icmp eq i32 %p_14_3, -1
  %t128 = and i1 %t126, %t127
  %t129 = xor i1 %t128, true
  br i1 %t129, label %ok_130, label %trap_130
trap_130:
  call void @abort()
  unreachable
ok_130:
  %t131 = sdiv i32 %t120, %p_14_3
  %t132 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t131)
  %t133 = extractvalue { i32, i1 } %t132, 0
  %t134 = extractvalue { i32, i1 } %t132, 1
  %t135 = xor i1 %t134, true
  br i1 %t135, label %ok_136, label %trap_136
trap_136:
  call void @abort()
  unreachable
ok_136:
  %t137 = call i32 @__hia_fn_10(i32 %p_14_2, i32 %p_14_3)
  %t138 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t133, i32 %t137)
  %t139 = extractvalue { i32, i1 } %t138, 0
  %t140 = extractvalue { i32, i1 } %t138, 1
  %t141 = xor i1 %t140, true
  br i1 %t141, label %ok_142, label %trap_142
trap_142:
  call void @abort()
  unreachable
ok_142:
  ret i32 %t139
b15:
  %p_15_0 = phi i32 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i32 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi i32 [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i32 [ %p_13_3, %edge_16 ]
  %t143 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_15_2, i32 %p_15_3)
  %t144 = extractvalue { i32, i1 } %t143, 0
  %t145 = extractvalue { i32, i1 } %t143, 1
  %t146 = xor i1 %t145, true
  br i1 %t146, label %ok_147, label %trap_147
trap_147:
  call void @abort()
  unreachable
ok_147:
  %t148 = trunc i64 1 to i32
  %t149 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t144, i32 %t148)
  %t150 = extractvalue { i32, i1 } %t149, 0
  %t151 = extractvalue { i32, i1 } %t149, 1
  %t152 = xor i1 %t151, true
  br i1 %t152, label %ok_153, label %trap_153
trap_153:
  call void @abort()
  unreachable
ok_153:
  %t154 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_15_3)
  %t155 = extractvalue { i32, i1 } %t154, 0
  %t156 = extractvalue { i32, i1 } %t154, 1
  %t157 = xor i1 %t156, true
  br i1 %t157, label %ok_158, label %trap_158
trap_158:
  call void @abort()
  unreachable
ok_158:
  %t159 = icmp ne i32 %t155, 0
  br i1 %t159, label %ok_160, label %trap_160
trap_160:
  call void @abort()
  unreachable
ok_160:
  %t161 = icmp eq i32 %t150, -2147483648
  %t162 = icmp eq i32 %t155, -1
  %t163 = and i1 %t161, %t162
  %t164 = xor i1 %t163, true
  br i1 %t164, label %ok_165, label %trap_165
trap_165:
  call void @abort()
  unreachable
ok_165:
  %t166 = sdiv i32 %t150, %t155
  %t167 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t166)
  %t168 = extractvalue { i32, i1 } %t167, 0
  %t169 = extractvalue { i32, i1 } %t167, 1
  %t170 = xor i1 %t169, true
  br i1 %t170, label %ok_171, label %trap_171
trap_171:
  call void @abort()
  unreachable
ok_171:
  ret i32 %t168
b16:
  %p_16_0 = phi i32 [ %p_13_0, %edge_17 ]
  %p_16_1 = phi i32 [ %p_13_1, %edge_17 ]
  %p_16_2 = phi i32 [ %p_13_2, %edge_17 ]
  %p_16_3 = phi i32 [ %p_13_3, %edge_17 ]
  %t172 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_16_2)
  %t173 = extractvalue { i32, i1 } %t172, 0
  %t174 = extractvalue { i32, i1 } %t172, 1
  %t175 = xor i1 %t174, true
  br i1 %t175, label %ok_176, label %trap_176
trap_176:
  call void @abort()
  unreachable
ok_176:
  %t177 = icmp ne i32 %p_16_3, 0
  br i1 %t177, label %ok_178, label %trap_178
trap_178:
  call void @abort()
  unreachable
ok_178:
  %t179 = icmp eq i32 %t173, -2147483648
  %t180 = icmp eq i32 %p_16_3, -1
  %t181 = and i1 %t179, %t180
  %t182 = xor i1 %t181, true
  br i1 %t182, label %ok_183, label %trap_183
trap_183:
  call void @abort()
  unreachable
ok_183:
  %t184 = sdiv i32 %t173, %p_16_3
  %t185 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t184)
  %t186 = extractvalue { i32, i1 } %t185, 0
  %t187 = extractvalue { i32, i1 } %t185, 1
  %t188 = xor i1 %t187, true
  br i1 %t188, label %ok_189, label %trap_189
trap_189:
  call void @abort()
  unreachable
ok_189:
  %t190 = call i32 @__hia_fn_9(i32 %p_16_2, i32 %p_16_3)
  %t191 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %t186, i32 %t190)
  %t192 = extractvalue { i32, i1 } %t191, 0
  %t193 = extractvalue { i32, i1 } %t191, 1
  %t194 = xor i1 %t193, true
  br i1 %t194, label %ok_195, label %trap_195
trap_195:
  call void @abort()
  unreachable
ok_195:
  ret i32 %t192
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b10
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b16
}

define internal i32 @__hia_fn_3(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ne i32 %p_0_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_0_0, -2147483648
  %t4 = icmp eq i32 %p_0_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = sdiv i32 %p_0_0, %p_0_1
  ret i32 %t8
}

define internal i32 @__hia_fn_4(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ne i32 %p_0_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_0_0, -2147483648
  %t4 = icmp eq i32 %p_0_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = srem i32 %p_0_0, %p_0_1
  %t9 = trunc i64 0 to i32
  %t10 = icmp sge i32 %t8, %t9
  br i1 %t10, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_4 = phi i32 [ %t8, %edge_0 ]
  ret i32 %p_1_4
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_4 = phi i32 [ %t8, %edge_1 ]
  %t11 = call i32 @__hia_fn_11(i32 %p_2_3)
  %t12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_2_4, i32 %t11)
  %t13 = extractvalue { i32, i1 } %t12, 0
  %t14 = extractvalue { i32, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  ret i32 %t13
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_5(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sge i32 %p_0_1, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ]
  %t3 = icmp ne i32 %p_1_3, 0
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = icmp eq i32 %p_1_2, -2147483648
  %t6 = icmp eq i32 %p_1_3, -1
  %t7 = and i1 %t5, %t6
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = srem i32 %p_1_2, %p_1_3
  %t11 = trunc i64 0 to i32
  %t12 = icmp sge i32 %t10, %t11
  br i1 %t12, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_1, %edge_1 ]
  %t13 = icmp ne i32 %p_2_3, 0
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = icmp eq i32 %p_2_2, -2147483648
  %t16 = icmp eq i32 %p_2_3, -1
  %t17 = and i1 %t15, %t16
  %t18 = xor i1 %t17, true
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = srem i32 %p_2_2, %p_2_3
  %t21 = trunc i64 0 to i32
  %t22 = icmp sle i32 %t20, %t21
  br i1 %t22, label %edge_4, label %edge_5
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i32 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i32 [ %t10, %edge_2 ]
  ret i32 %p_3_4
b4:
  %p_4_0 = phi i32 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i32 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i32 [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i32 [ %t10, %edge_3 ]
  %t23 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_4_4, i32 %p_4_3)
  %t24 = extractvalue { i32, i1 } %t23, 0
  %t25 = extractvalue { i32, i1 } %t23, 1
  %t26 = xor i1 %t25, true
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  ret i32 %t24
b5:
  %p_5_0 = phi i32 [ %p_2_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_5_2 = phi i32 [ %p_2_2, %edge_4 ]
  %p_5_3 = phi i32 [ %p_2_3, %edge_4 ]
  %p_5_4 = phi i32 [ %t20, %edge_4 ]
  ret i32 %p_5_4
b6:
  %p_6_0 = phi i32 [ %p_2_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_2_1, %edge_5 ]
  %p_6_2 = phi i32 [ %p_2_2, %edge_5 ]
  %p_6_3 = phi i32 [ %p_2_3, %edge_5 ]
  %p_6_4 = phi i32 [ %t20, %edge_5 ]
  %t28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_6_4, i32 %p_6_3)
  %t29 = extractvalue { i32, i1 } %t28, 0
  %t30 = extractvalue { i32, i1 } %t28, 1
  %t31 = xor i1 %t30, true
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  ret i32 %t29
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define internal i32 @__hia_fn_6(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ne i32 %p_0_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_0_0, -2147483648
  %t4 = icmp eq i32 %p_0_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = srem i32 %p_0_0, %p_0_1
  ret i32 %t8
}

define internal i32 @__hia_fn_7(i32 %p_0_0) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sgt i32 %p_0_0, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %t3 = trunc i64 1 to i32
  %t4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t3)
  %t5 = extractvalue { i32, i1 } %t4, 0
  %t6 = extractvalue { i32, i1 } %t4, 1
  %t7 = xor i1 %t6, true
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  ret i32 %t5
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %t9 = trunc i64 1 to i32
  ret i32 %t9
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_8(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_0_0)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = icmp ne i32 %p_0_1, 0
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = icmp eq i32 %t2, -2147483648
  %t9 = icmp eq i32 %p_0_1, -1
  %t10 = and i1 %t8, %t9
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = srem i32 %t2, %p_0_1
  %t14 = trunc i64 0 to i32
  %t15 = icmp ne i32 %t13, %t14
  br i1 %t15, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t16 = trunc i64 1 to i32
  %t17 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t16)
  %t18 = extractvalue { i32, i1 } %t17, 0
  %t19 = extractvalue { i32, i1 } %t17, 1
  %t20 = xor i1 %t19, true
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  ret i32 %t18
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t22 = trunc i64 0 to i32
  ret i32 %t22
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_9(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_0_1)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = icmp ne i32 %t2, 0
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = icmp eq i32 %p_0_0, -2147483648
  %t9 = icmp eq i32 %t2, -1
  %t10 = and i1 %t8, %t9
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = srem i32 %p_0_0, %t2
  %t14 = trunc i64 0 to i32
  %t15 = icmp ne i32 %t13, %t14
  br i1 %t15, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t16 = trunc i64 1 to i32
  %t17 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t16)
  %t18 = extractvalue { i32, i1 } %t17, 0
  %t19 = extractvalue { i32, i1 } %t17, 1
  %t20 = xor i1 %t19, true
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  ret i32 %t18
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t22 = trunc i64 0 to i32
  ret i32 %t22
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_10(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_0_0, i32 %p_0_1)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t2)
  %t7 = extractvalue { i32, i1 } %t6, 0
  %t8 = extractvalue { i32, i1 } %t6, 1
  %t9 = xor i1 %t8, true
  br i1 %t9, label %ok_10, label %trap_10
trap_10:
  call void @abort()
  unreachable
ok_10:
  %t11 = icmp ne i32 %p_0_1, 0
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = icmp eq i32 %t7, -2147483648
  %t14 = icmp eq i32 %p_0_1, -1
  %t15 = and i1 %t13, %t14
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = srem i32 %t7, %p_0_1
  %t19 = trunc i64 0 to i32
  %t20 = icmp ne i32 %t18, %t19
  br i1 %t20, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t21 = trunc i64 2 to i32
  %t22 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t21)
  %t23 = extractvalue { i32, i1 } %t22, 0
  %t24 = extractvalue { i32, i1 } %t22, 1
  %t25 = xor i1 %t24, true
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  ret i32 %t23
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t27 = trunc i64 1 to i32
  %t28 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %t27)
  %t29 = extractvalue { i32, i1 } %t28, 0
  %t30 = extractvalue { i32, i1 } %t28, 1
  %t31 = xor i1 %t30, true
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  ret i32 %t29
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_11(i32 %p_0_0) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = icmp sgt i32 %p_0_0, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  ret i32 %p_1_0
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %t3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_2_0)
  %t4 = extractvalue { i32, i1 } %t3, 0
  %t5 = extractvalue { i32, i1 } %t3, 1
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  ret i32 %t4
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_12(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_3(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_13(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_2(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_14(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_1(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_15(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_6(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_16(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_5(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define internal i32 @__hia_fn_17(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_4(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define i32 @c_bool_to_int(i1 zeroext %a0) {
entry:
  %result = call i32 @__hia_fn_0(i1 %a0)
  ret i32 %result
}

define i32 @c_stb_div_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_1(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_div_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_2(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_div_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_3(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_mod_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_4(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_mod_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_5(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @c_stb_mod_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_6(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_1(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_7(i32 %a0)
  ret i32 %result
}

define i32 @migration_conditional_2(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_8(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_3(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_9(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_4(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_10(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @migration_conditional_5(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_11(i32 %a0)
  ret i32 %result
}

define i32 @stb_div_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_12(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_div_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_13(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_div_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_14(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_mod_trunc(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_15(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_mod_floor(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_16(i32 %a0, i32 %a1)
  ret i32 %result
}

define i32 @stb_mod_eucl(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_17(i32 %a0, i32 %a1)
  ret i32 %result
}
