#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <sys/resource.h>
#define STB_DIVIDE_IMPLEMENTATION
#include "stb_divide.h"
_Static_assert(sizeof(int)==4 && INT_MIN==(-2147483647-1), "int32 required");
typedef int (*function_t)(int,int);
static function_t functions[6] = {stb_div_trunc,stb_div_floor,stb_div_eucl,
                                 stb_mod_trunc,stb_mod_floor,stb_mod_eucl};
static int number(const char *s, int *out) {
    char *end; long value; errno=0; value=strtol(s,&end,10);
    if(errno || end==s || *end || value<INT_MIN || value>INT_MAX)return 0;
    *out=(int)value; return 1;
}
int main(int argc,char **argv) {
    int index,a,b,value; struct rlimit limit={0,0};
    if(setrlimit(RLIMIT_CORE,&limit) || argc!=4 || !number(argv[1],&index)
       || index<0 || index>=6 || !number(argv[2],&a) || !number(argv[3],&b))return 2;
    puts("ENTERED_ORIGINAL_C"); fflush(stdout);
    value=functions[index](a,b);
    printf("{\"value\":%d}\n",value); return 0;
}
