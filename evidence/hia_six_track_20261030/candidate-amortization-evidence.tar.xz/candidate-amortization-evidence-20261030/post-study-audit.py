"""Post-study arithmetic and retained-file verification, not new measurement."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

BASE = Path('/workspace/scratch/cd43ab608057/hia-run-evidence')
RUN = BASE / 'candidate-amortization-20261030'
SOURCE = Path('/workspace/scratch/cd43ab608057/hia-amortization')
ARMS = ('base', 'guarded', 'guarded-narrowed')


def main():
    result_raw = (RUN / 'RESULT.json').read_bytes()
    result = json.loads(result_raw)
    registration = json.loads((RUN / 'REGISTRATION.json').read_bytes())
    review_raw = (BASE / 'candidate-amortization-prerun-review.json').read_bytes()
    review = json.loads(review_raw)
    p, rows = registration['protocol'], result['episodes']
    checks = {}
    cells = {(r['group'], r['target']): r for r in rows}
    checks['nine_unique_registered_cells'] = len(rows) == len(cells) == 9 and set(cells) == {
        (g, a) for g in range(3) for a in ARMS}
    checks['all_admitted'] = all(r['admitted'] for r in rows)
    checks['source_files_still_match_registration'] = all(
        sha256((SOURCE / name).read_bytes()).hexdigest() == digest
        for name, digest in registration['source_sha256'].items())
    checks['source_head_still_matches'] = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == result['source_commit']
    checks['source_clean'] = not bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE))
    checks['tool_files_still_match_registration'] = all(sha256(Path(row['path']).read_bytes()).hexdigest()
        == row['sha256'] for row in registration['tools'].values())
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=SOURCE, text=True).strip()
    checks['local_public_and_reviewed_trees_equal'] = (tree == review['reviewed_tree']
        == review['public_registration']['tree'] == '428629c489284830bb852b6c85f671afcb8e0f0c')
    all_samples, image_checks, text_checks, oracle_checks, resources, tokens = [], [], [], [], [], []
    breakdown = {}

    # Independent byte_sum arithmetic. Every complete 256-byte period sums
    # to 32640 for any starting seed, then only a short remainder is needed.
    expected = {}
    for n in set(p['trace_unit']):
        cycles, remainder = divmod(n, 256)
        values = [cycles * 32640 + sum((index + seed) & 255 for index in range(remainder))
            for seed in range(256)]
        calls, tail = divmod(p['calls'], 256)
        expected[n] = (calls * n * 32640 + sum(values[(p['holdout_seed'] + i) & 255]
            for i in range(tail))) & ((1 << 64) - 1)
    for row in rows:
        folder = RUN / f"group-{row['group']}-{row['target']}"
        samples = sorted(folder.glob('sample-*.json'))
        all_samples.append(len(samples) == 256 and [json.loads(f.read_bytes()) for f in samples] == row['observations'])
        observed = row['observations']
        all_samples.append([o['n'] for o in observed] == p['trace_unit'] * 32)
        oracle_checks.append(all(o['calls'] == 65535 and o['seed'] == 197 and o['status'] == 'measured'
            and o['expected_checksum'] == o['output']['checksum'] == expected[o['n']]
            and o['output']['loaded_mapping_verified'] is True and o['new_solver_call'] is False
            and o['artifact_sha256'] == row['admissions'][-1]['entry']['artifact_sha256'] for o in observed))
        state = row['session_closed']
        admissions = 1 if row['target'] == 'base' else 2
        resources.append(state['execution_attempts'] == 256 and state['proof_attempts'] == admissions
            and state['successful_admissions'] == admissions and state['owned_native_release_complete']
            and state['charged_retained_bytes'] == state['reserved_bytes'] == state['outstanding_leases'] == 0
            and not state['pending_release_debt'] and row['external_proof_imported'] is False)
        for admission in row['admissions']:
            receipt = admission['receipt']
            image_checks.append(receipt['verification']['status'] == 'verified'
                and sha256(Path(receipt['native']['output']).read_bytes()).hexdigest()
                    == receipt['native']['artifact_sha256'] == admission['entry']['artifact_sha256'])
            text_checks.append(sha256((folder / (admission['target'] + '.text')).read_bytes()).hexdigest()
                == admission['native_text']['sha256'])
            tokens.append(admission['entry']['token'])
        checks[f"component_sum_group_{row['group']}_{row['target']}"] = sum(row['components_ns'].values()) == row['wall_ns']
        checks[f"delivery_sum_group_{row['group']}_{row['target']}"] = sum(o['delivery_cost_ns'] for o in observed) == row['nested_execution_ns']['delivery_observation_ns']
    checks['all_2304_raw_samples_and_trace_positions_match'] = sum(len(r['observations']) for r in rows) == 2304 and all(all_samples)
    checks['independent_byte_period_oracle_all_outputs'] = all(oracle_checks)
    checks['all_nine_fresh_proof_counts_and_complete_releases'] = all(resources)
    checks['all_15_native_image_hashes_still_match'] = len(image_checks) == 15 and all(image_checks)
    checks['all_15_native_text_hashes_still_match'] = len(text_checks) == 15 and all(text_checks)
    checks['all_15_admission_tokens_distinct'] = len(tokens) == len(set(tokens)) == 15
    for arm in ARMS:
        subset = [r for r in rows if r['target'] == arm]
        complete = result['common_setup_ns'] + result['shared_dispatch_and_final_identity_ns'] + sum(r['wall_ns'] for r in subset)
        checks['standalone_recomputed_' + arm] = complete == result['standalone_complete_ns'][arm]
        breakdown[arm] = {'standalone_complete_ns': complete,
            'episode_wall_ns': sum(r['wall_ns'] for r in subset),
            'components_ns': {key: sum(r['components_ns'][key] for r in subset) for key in subset[0]['components_ns']},
            'delivery_observation_ns': sum(o['delivery_cost_ns'] for r in subset for o in r['observations']),
            'native_driver_elapsed_ns': sum(o['output']['elapsed_ns'] for r in subset for o in r['observations'])}
    pairs = []
    for g in range(3):
        baseline = cells[g, 'base']
        for target in ARMS[1:]:
            candidate = cells[g, target]
            pairs.append({'group': g, 'target': target,
                'base_complete_ns': baseline['wall_ns'], 'candidate_complete_ns': candidate['wall_ns'],
                'complete_saving_ns': baseline['wall_ns'] - candidate['wall_ns'],
                'complete_saving_percent_of_baseline': 100 * (baseline['wall_ns'] - candidate['wall_ns']) / baseline['wall_ns'],
                'delivery_saving_ns': sum(o['delivery_cost_ns'] for o in baseline['observations'])
                    - sum(o['delivery_cost_ns'] for o in candidate['observations'])})
    by_candidate = {target: all(x['complete_saving_ns'] > 0 for x in pairs if x['target'] == target) for target in ARMS[1:]}
    checks['registered_candidate_gates_recomputed'] = by_candidate == result['all_pairs_positive_by_candidate']
    checks['overall_gate_not_rescued_by_mean'] = (all(by_candidate.values()) == result['observed_complete_cost_gate'])
    checks['study_cost_recomposes'] = result['new_study_ns_before_final_analysis_and_encoding'] == result['common_setup_ns'] + result['shared_dispatch_and_final_identity_ns'] + sum(r['wall_ns'] for r in rows)
    checks['prior_cost_and_cumulative_preserved'] = (result['prior_tracked_cost_ns'] == 199343918199
        and result['prior_plus_new_tracked_cost_ns'] == 199343918199 + result['new_study_ns_before_final_analysis_and_encoding'])
    baseline_total = result['standalone_complete_ns']['base']
    audit = {'schema': 'hepta.hia.candidate-amortization.independent-audit.v1',
        'result_sha256': sha256(result_raw).hexdigest(), 'audit_script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_commit': result['source_commit'], 'public_source_commit': review['public_registration']['commit'],
        'source_tree': tree, 'public_tree_verification_source': 'independent pre-run review via GitHub API',
        'pre_run_review_sha256': sha256(review_raw).hexdigest(), 'checks': checks, 'checks_pass': all(checks.values()),
        'paired_complete_and_delivery_costs': pairs, 'arm_breakdown_ns': breakdown,
        'aggregate_observed_savings': {target: {'complete_saving_ns': baseline_total - result['standalone_complete_ns'][target],
            'percent_of_baseline': 100 * (baseline_total - result['standalone_complete_ns'][target]) / baseline_total,
            'all_registered_pairs_pass': by_candidate[target]} for target in ARMS[1:]},
        'prior_plus_new_tracked_cost_ns': result['prior_plus_new_tracked_cost_ns'],
        'post_study_accounting_test_cost_not_in_performance_total': True,
        'adaptive_follow_up': True, 'statistical_superiority_established': False,
        'ndu_incremental_value_established': False, 'legacy_application_win_established': False,
        'authority': 'DENY_ALL', 'safety_certificate': False}
    output = BASE / 'candidate-amortization-20261030.INDEPENDENT_AUDIT.json'
    with output.open('x') as stream:
        json.dump(audit, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(audit, sort_keys=True, indent=2))
    if not audit['checks_pass']:
        raise SystemExit('independent audit failed')


if __name__ == '__main__':
    main()
