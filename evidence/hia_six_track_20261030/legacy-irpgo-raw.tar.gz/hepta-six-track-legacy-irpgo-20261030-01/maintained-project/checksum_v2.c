#include "checksum.h"
unsigned int checksum_byte_v2(unsigned int state,unsigned char byte,unsigned int algorithm) {
 if(algorithm==1)return checksum_byte(state,byte,0xedb88320U);
 if(algorithm==2)return checksum_byte(state,byte,0x82f63b78U);
 return state;
}
