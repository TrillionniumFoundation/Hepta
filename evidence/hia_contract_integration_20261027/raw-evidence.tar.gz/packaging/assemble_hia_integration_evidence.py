#!/usr/bin/env python3
"""Package completed 817713b evidence and all prior attempts; never run tests."""
from __future__ import annotations
import argparse
import gzip
from hashlib import sha256
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

BASE = Path("/workspace/scratch/bf7d454bbc83")
ROOT = BASE / "hepta-integrated"
RUN = BASE / "hia-integrated-qualification-run2"
CI = BASE / "hia-integrated-fixed-source-ci"
AUDIT = BASE / "hia-integrated-evidence-audit-run2"
PRIOR_RUN = BASE / "hia-integrated-qualification-run1"
PRIOR_CI = BASE / "hia-integrated-source-ci"
PRIOR_AUDIT = BASE / "hia-integrated-evidence-audit"
OLD = BASE / "hia-source-release-ci/portable"
OUT = BASE / "hia-integration-delivery"
HEAD = "817713b163b6812a6516179951412b4a6c93ae2b"
TREE = "6a034a0ed5d001823dc26683e1677520d4b510e2"
PARENTS = ["a4ab87889616925306b84f9699316d1a850c183d"]
BUNDLE = BASE / "hia-integrated-tested-source-run2.bundle"
BUNDLE_SHA = "4c836863f4fd76687a396edae8503e511095b0a9f8d27f284acf4db825f397b8"
PRIOR_BUNDLE = BASE / "hia-integrated-tested-source.bundle"
PRIOR_BUNDLE_SHA = "4c17210a02d8e322bc36eb20e10c8992aa1870cf188387f3d9d4f8ba62233f77"
PUBLICATION = BASE / "integration-repair-publication-provenance.json"

def require(ok, why):
    if not ok:
        raise ValueError(why)

def regular(path, keep=True):
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), "not a regular file: " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    chunks, digest = [], sha256()
    with os.fdopen(fd, "rb") as stream:
        opened = os.fstat(stream.fileno())
        require(stat.S_ISREG(opened.st_mode), "opened input is not regular")
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
            if keep:
                chunks.append(chunk)
        final_fd = os.fstat(stream.fileno())
    after = path.lstat()
    signatures = {(v.st_dev, v.st_ino, v.st_size, v.st_mtime_ns, v.st_ctime_ns, v.st_mode)
                  for v in (before, opened, final_fd, after)}
    require(len(signatures) == 1, "input changed while reading: " + str(path))
    return b"".join(chunks), {"bytes": after.st_size, "sha256": digest.hexdigest(),
                             "mode": stat.S_IMODE(after.st_mode)}

def load(path):
    return json.loads(regular(path)[0])

def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd)

def source_clean():
    require(git("rev-parse", "HEAD").decode().strip() == HEAD, "wrong source HEAD")
    require(git("rev-parse", "HEAD^{tree}").decode().strip() == TREE, "wrong source tree")
    require(not git("status", "--porcelain", "--untracked-files=all"), "source tree is not clean")

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n")

def walk_dicts(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_dicts(child)

def current_ci_summary(schema):
    matches = [(path, load(path)) for path in CI.rglob("summary.json")]
    matches = [(p, d) for p, d in matches if d.get("schema") == schema and d.get("source_sha") == HEAD]
    require(matches, "completed source-bound CI summary not available: " + schema)
    # Select the earliest retained push run, then PR if there is no push.
    # No result/cost criterion selects among attempts; all raw runs are retained.
    return min(matches, key=lambda pair: (pair[1].get("event") != "push", pair[1]["run_id"]))

def prepare():
    source_clean()
    require((RUN / "qualification.json").is_file(),
            "final local qualification.json is not available; no polling or partial success")
    require((AUDIT / "audit.json").is_file(),
            "final independent audit.json is not available; run the audit after qualification")
    q, audit = load(RUN / "qualification.json"), load(AUDIT / "audit.json")
    require(q.get("finished_utc") and "source_after" in q and "external_inventory_after" in q,
            "qualification is incomplete")
    require(q["source_before"]["head"] == q["source_after"]["head"] == HEAD
            and q["source_before"]["tree"] == q["source_after"]["tree"] == TREE,
            "qualification source binding differs")
    require(audit["source_head"] == HEAD and audit["source_tree"] == TREE
            and audit["evidence_sha256"]["qualification.json"] == regular(RUN / "qualification.json", False)[1]["sha256"],
            "independent audit does not bind this exact report")
    publication = load(PUBLICATION)
    require(publication["remote_commit"] == HEAD and publication["remote_tree"] == TREE
            and publication["exact_tree_match"] is True, "publication provenance differs")
    host_path, host = current_ci_summary("hepta.integrated-host-ci-summary.v1")
    verified_path, verified = current_ci_summary("hepta.integrated-verified-ci-summary.v1")
    require(host["source_sha"] == verified["source_sha"] == HEAD, "CI summaries concern another source")
    selected_paths = list(verified_path.parent.glob("selected/**/artifacts/verified-optimization"))
    require(len(selected_paths) == 1, "one retained verified CI report root is required")
    selected = selected_paths[0]
    regression = load(selected / "regression/result.json")
    require(regression["git_base"] == HEAD and all(regression[k] == verified["regression"][k]
            for k in ("tests", "errors", "failures", "skipped", "passed", "source_unchanged")),
            "CI selected regression summary differs from its raw result")
    cpp, ndu = load(selected / "cpp-scoped/qualification.json"), load(selected / "ndu-loop/RESULT.json")
    require(cpp["case_count"] == verified["cpp_scoped"]["case_count"]
            and cpp["ok"] == verified["cpp_scoped"]["ok"], "C++ summary differs")
    require(all(ndu[k] == v for k, v in verified["recursive_ndu"].items()), "NDU summary differs")
    for label, source_map in (("selected regression", regression["source_sha256"]),
                              ("recursive NDU", ndu["source_identity"])):
        require(source_map and all(q["source_before"]["files"].get(name) == digest
                                  for name, digest in source_map.items()),
                label + " source bytes do not match the currently qualified tree")
    downloads = load(host_path.parent / "downloads.json")
    require(len(downloads) == len(host["jobs"]) == 7, "all seven actual host reports/ZIPs are required")
    for download in downloads:
        actual = regular(Path(download["path"]), False)[1]
        require(download["github_digest_verified"] is True and actual["sha256"] == download["sha256"]
                and actual["bytes"] == download["bytes"], "actual host ZIP differs from its receipt")
    download = load(verified_path.parent / "download-receipt.json")
    actual = regular(verified_path.parent / (str(download["artifact_id"]) + ".zip"), False)[1]
    require(download["source_sha"] == HEAD and download["github_digest_verified"] is True
            and actual["sha256"] == download["sha256"] and actual["bytes"] == download["bytes"],
            "actual verified CI ZIP differs from its receipt")
    require(regular(BUNDLE, False)[1]["sha256"] == BUNDLE_SHA, "tested source bundle differs")
    require(regular(PRIOR_BUNDLE, False)[1]["sha256"] == PRIOR_BUNDLE_SHA, "prior source bundle differs")
    return q, audit, publication, host, verified, regression, cpp, ndu

def assemble(check_only=False):
    q, audit, publication, host, verified, regression, cpp, ndu = prepare()
    if check_only:
        return {"ready": True, "source_head": HEAD, "output_not_created": True}
    require(not OUT.exists(), "delivery directory already exists; retain it instead of overwriting")
    entries, omitted = {}, []

    def add(path, name, category, expected=None, data=None, mode=None, origin=None):
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and ".." not in relative.parts and name not in entries,
                "unsafe or duplicate archive member")
        if data is None:
            data, info = regular(path)
        else:
            info = {"bytes": len(data), "sha256": sha256(data).hexdigest(), "mode": mode}
        require(expected is None or info["sha256"] == expected, "input hash differs: " + name)
        if Path(name).suffix in {".json", ".log", ".md", ".py", ".rs", ".toml"}:
            require(not re.search(rb"https?://[^\s\"<>]*(?:[?&](?:sig|signature|token|access_token|X-Amz-Signature|X-Amz-Security-Token)=)", data, re.I),
                    "signed URL found in input; preserve original separately: " + name)
        entries[name] = {"source_path": str(path) if path else None, "origin": origin,
                         "classification": category, **info, "_data": data if path is None else None}

    def add_tree(directory, prefix, category, skip=()):
        for path in sorted(directory.rglob("*")):
            relative = path.relative_to(directory)
            if any(part in skip for part in relative.parts):
                continue
            require(not path.is_symlink(), "symlink in evidence tree: " + str(path))
            if path.is_dir():
                continue
            if path.suffix == ".zip" and path.stat().st_size > 32 * 1024 * 1024:
                omitted.append({"path": str(path), **regular(path, False)[1],
                                "reason": "large original CI archive retained separately; selected evidence is packaged"})
                continue
            require(path.stat().st_size <= 32 * 1024 * 1024, "unexpected large evidence member: " + str(path))
            add(path, prefix + "/" + relative.as_posix(), category)

    add_tree(RUN, "local/run2", "fresh_local_qualification", skip=("rust-target", "__pycache__"))
    for path in (Path(str(RUN) + "-invocation.json"), Path(str(RUN) + ".log"),
                 BASE / "run_integrated_qualification.py"):
        add(path, "execution/" + path.name, "actual_qualification_invocation_and_transcript")
    add(RUN / "rust-target/debug/hia-core-shadow", "native/rust-oracle/hia-core-shadow",
        "actual_executable_retained_after_qualified_run")
    add_tree(CI, "ci/integrated", "same_published_source_ci")
    add_tree(PRIOR_RUN, "historical/a4ab/run1", "failed_prior_source_qualification", skip=("rust-target", "__pycache__"))
    add_tree(PRIOR_AUDIT, "historical/a4ab/audit", "failed_prior_source_independent_audit", skip=("__pycache__",))
    add_tree(PRIOR_CI, "historical/a4ab/ci", "prior_source_ci_not_current")
    for path in (Path(str(PRIOR_RUN) + "-invocation.json"), Path(str(PRIOR_RUN) + ".log"),
                 BASE / "hia-run1-rust-cache-cleanup.json"):
        add(path, "historical/a4ab/execution/" + path.name, "retained_prior_attempt_invocation_or_cleanup")
    add(PRIOR_RUN / "rust-target/debug/hia-core-shadow", "historical/a4ab/native/hia-core-shadow",
        "actual_oracle_retained_from_failed_run1")
    add(PRIOR_BUNDLE, "historical/a4ab/tested-source.bundle", "actual_prior_source_bundle", PRIOR_BUNDLE_SHA)
    add_tree(BASE / "hia-wire-key-repair", "historical/wire-repair", "focused_dirty_tree_repair_not_full_qualification")
    add_tree(OLD, "ci/historical-e147", "historical_failed_source_ci_not_current")
    add_tree(AUDIT, "audit", "independent_read_only_recount", skip=("__pycache__",))
    add(PUBLICATION, "publication/current-source-publication.json", "prequalification_repair_publication_record")
    add(BASE / "integration-publication-provenance.json", "publication/initial-source-publication.json",
        "historical_initial_publication_record")
    add(Path(__file__), "packaging/assemble_hia_integration_evidence.py", "evidence_packager")
    for name in ("integrated-proof-initial.log", "integrated-profile-controls.log",
                 "integrated-proof-native-controls.log", "ndu-integration-handoff.json",
                 "hia-integrated-collector-review.json"):
        add(BASE / name, "historical-controls/" + name, "pre_freeze_controls_not_current_qualification")

    ranking_path = BASE / "ndu-build-final/build-receipt.json"
    ranking = load(ranking_path)
    require(regular(ranking_path, False)[1]["sha256"] == q["external_inventory_after"][str(ranking_path)]
            and ranking["binary_sha256"] == q["external_inventory_after"][ranking["binary"]],
            "ranking executable or receipt differs from the final qualification identity")
    add(ranking_path, "native/ranking/build-receipt.json", "qualified_native_bridge")
    add(Path(ranking["binary"]), "native/ranking/hia-ndu-bridge", "qualified_native_bridge", ranking["binary_sha256"])
    for name, digest in ranking["build_inputs"].items():
        add(ranking_path.parent / name, "native/ranking/build-inputs/" + name, "isolated_native_build_input", digest)
    commit, expected = ranking["upstream"]["commit"], ranking["original_source_files"]
    original = git("archive", commit, "--", *sorted(expected), cwd=BASE / "ndu-upstream")
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(original)) as package:
        for member in package:
            if member.isdir():
                continue
            require(member.isfile() and member.name in expected, "invalid original NDU source archive member")
            data = package.extractfile(member).read()
            add(None, "native/ranking/original-source/" + member.name, "exact_upstream_git_source",
                expected[member.name], data=data, mode=member.mode,
                origin={"repository": ranking["upstream"]["repository"], "commit": commit, "path": member.name})
            seen.add(member.name)
    require(seen == set(expected), "original ranking source inventory incomplete")
    recursive_path = BASE / "ndu-recursive-build-integrated/identity.json"
    recursive = load(recursive_path)
    require(regular(recursive_path, False)[1]["sha256"] == q["external_inventory_after"][str(recursive_path)]
            and recursive["binary_sha256"] == q["external_inventory_after"][recursive["binary"]],
            "recursive executable or receipt differs from the final qualification identity")
    add(recursive_path, "native/recursive/identity.json", "qualified_native_bridge")
    add(Path(recursive["binary"]), "native/recursive/hepta-hia-ndu-bridge", "qualified_native_bridge", recursive["binary_sha256"])
    for name, digest in {**recursive["native_sources"], **recursive["bridge_sources"]}.items():
        add(BASE / "ndu-recursive-upstream" / name, "native/recursive/original-source/" + name,
            "exact_upstream_source_checked_against_qualification", digest)
    for name, digest in (("build_hia_ndu_bridge.py", ranking["builder_sha256"]),
                         ("build_hia_recursive_ndu_bridge.py", recursive["build_tools"]["builder_sha256"])):
        add(ROOT / "tools" / name, "native/builders/" + name, "receipt_bound_builder", digest)
    add(BASE / "ndu-recursive-source-receipt.json", "native/recursive/source-receipt.json", "upstream_source_receipt")

    old_download = load(OLD / "download-receipt.json")
    old_info = regular(Path(old_download["path"]), False)[1]
    require(old_info["sha256"] == old_download["sha256"] == old_download["expected_sha256"]
            and old_info["bytes"] == old_download["bytes"], "retained old CI ZIP differs")
    omitted.append({**old_download, "workflow_url": "https://github.com/TrillionniumFoundation/Hepta/actions/runs/40551242912",
                    "artifact_api_url": "https://api.github.com/repos/TrillionniumFoundation/Hepta/actions/artifacts/12757506188/zip",
                    "reason": "original 274 MB ZIP remains separately retained; exact selected portable bytes are packaged"})
    snapshots = {}
    for path in sorted(CI.rglob("*.json")):
        for row in walk_dicts(load(path)):
            if row.get("head_sha") == HEAD and "workflow_id" in row and "status" in row:
                observation = {k: row.get(k) for k in ("id", "name", "path", "head_sha", "event", "status", "conclusion", "updated_at", "html_url")}
                observation["snapshot_file"] = "ci/integrated/" + path.relative_to(CI).as_posix()
                previous = snapshots.get(row["id"])
                if previous is None or (row.get("updated_at", ""), row["status"] == "completed") > (previous.get("updated_at", ""), previous["status"] == "completed"):
                    snapshots[row["id"]] = observation
    full_snapshots = [v for v in snapshots.values() if v["path"] == ".github/workflows/hepta-qualification.yml"]
    gates = {row["name"]: row for row in q["gates"]}
    prior = load(PRIOR_RUN / "qualification.json")
    prior_full = next(row for row in prior["gates"] if row["name"] == "full_regression")
    prior_audit = load(PRIOR_AUDIT / "run1-audit.json")
    require(prior["source_before"]["head"] == PARENTS[0] and prior["ok"] is False,
            "retained run1 does not describe the failed parent source")
    local_counts = {name: {k: row[k] for k in ("passed", "tests_run", "failures", "errors", "skipped", "test_binaries") if k in row}
                    for name, row in gates.items() if name in {"full_regression", "rust_resource_crate"}}
    source_clean()
    OUT.mkdir()
    archive = OUT / "raw-evidence.tar.gz"
    with archive.open("xb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode="w|", format=tarfile.PAX_FORMAT) as package:
            for name, row in sorted(entries.items()):
                data = row["_data"] if row["source_path"] is None else regular(Path(row["source_path"]))[0]
                require(len(data) == row["bytes"] and sha256(data).hexdigest() == row["sha256"], "input drift before archive: " + name)
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), row["mode"], 0
                member.uid = member.gid = 0
                member.uname = member.gname = ""
                package.addfile(member, io.BytesIO(data))
    reopened = set()
    with tarfile.open(archive, "r:gz") as package:
        for member in package:
            require(member.isfile() and member.name in entries and member.name not in reopened, "archive member mismatch")
            row = entries[member.name]
            data = package.extractfile(member).read()
            require(member.mode == row["mode"] and member.size == row["bytes"]
                    and sha256(data).hexdigest() == row["sha256"], "archive bytes or mode differ")
            if row["source_path"] is not None:
                current, info = regular(Path(row["source_path"]))
                require(current == data and all(info[k] == row[k] for k in ("bytes", "sha256", "mode")),
                        "original input changed during packaging: " + member.name)
            else:
                require(data == row["_data"], "archived Git blob differs")
            reopened.add(member.name)
    require(reopened == set(entries), "archive inventory incomplete")
    archive_info = regular(archive, False)[1]
    manifest = {"schema": "hepta.hia.integrated-raw-evidence-manifest.v1", "source_head": HEAD,
                "archive": {"filename": archive.name, **archive_info}, "members": [
                    {"path": name, **{k: v for k, v in row.items() if k != "_data"}} for name, row in sorted(entries.items())],
                "member_count": len(entries), "uncompressed_bytes": sum(row["bytes"] for row in entries.values()),
                "every_member_reopened_and_compared_byte_for_byte_and_mode": True,
                "deterministic_metadata": "lexical order; gzip mtime 0 and empty name; tar mtime/uid/gid 0, empty owner names",
                "excluded_large_original_archives": omitted,
                "exclusions": ["Rust build caches except final oracle executable", "installed external toolchain payloads",
                               "already committed Phase A and PR325 historical evidence", "destroyed transient runtime generations"]}
    acceptance = {"schema": "hepta.hia.integrated-acceptance.v1", "source_head": HEAD, "source_tree": TREE,
                  "local_qualification_passed": q["ok"], "independent_audit_passed": audit["ok"],
                  "source_unchanged": q["source_unchanged"], "external_inputs_unchanged": q["external_inputs_unchanged"],
                  "local_gates": local_counts, "all_local_gate_results": {n: v["passed"] for n, v in gates.items()},
                  "actual_source_host_abi": host, "actual_source_selected_ci": verified,
                  "recursive_ndu": {k: ndu[k] for k in ("median_net_cost_ns", "median_amortized_net_cost_ns", "setup_accounting",
                      "interpretation", "statistical_superiority_established", "ndu_descriptive_cost_lower_than_light",
                      "ndu_descriptive_cost_lower_than_selected_fixed", "all_episodes_completed", "all_actual_outputs_correct")},
                  "remote_full_qualification_snapshots": full_snapshots, "remote_status_is_only_as_captured": True,
                  "coverage_and_ci_counts_must_not_be_added": True, "historical_performance_remeasured": False,
                  "prior_failed_attempt": {"source_head": PARENTS[0], "qualification_passed": prior["ok"],
                      "tests_run": prior_full["tests_run"], "failures": prior_full["failures"],
                      "errors": prior_full["errors"], "skipped": prior_full["skipped"],
                      "failed_unique_methods": prior_audit["failed_unique_method_count"],
                      "retained_under": "historical/a4ab", "failure_entries_are_not_independent_defects": True},
                  "pr325_contracts_consolidated": True, "six_stages_closed": False,
                  "scientific_incremental_advantage_established": False, "whole_language_soundness_proved": False,
                  "general_rust_performance_superiority_established": False, "global_optimality_established": False,
                  "retained_source_bundle_sha256": BUNDLE_SHA, "raw_evidence_archive_sha256": archive_info["sha256"]}
    provenance = {"schema": "hepta.hia.integrated-publication-and-qualification.v1", "actual_tested_commit": HEAD,
                  "published_source_commit": HEAD, "tree": TREE, "same_published_commit_actually_checked_out_and_tested": True,
                  "source_parents": PARENTS, "repair_publication": publication,
                  "initial_qualification_pending_field_is_historical": True,
                  "initial_publication": load(BASE / "integration-publication-provenance.json"),
                  "prior_tested_source_bundle": {"archive_path": "historical/a4ab/tested-source.bundle",
                                                "sha256": PRIOR_BUNDLE_SHA, "head": PARENTS[0]},
                  "source_pull_request": "https://github.com/TrillionniumFoundation/Hepta/pull/329",
                  "evidence_delivery_branch": "codex/hia-contract-evidence-20261027",
                  "evidence_commit_sha_is_not_self_embedded": True,
                  "local_qualification_sha256": regular(RUN / "qualification.json", False)[1]["sha256"],
                  "independent_audit_sha256": regular(AUDIT / "audit.json", False)[1]["sha256"],
                  "source_bundle": {"file": "tested-source.bundle", "sha256": BUNDLE_SHA, "head": HEAD,
                                    "prerequisites": PARENTS, "self_contained_repository": False},
                  "workflow_snapshots": list(snapshots.values()),
                  "evidence_only_delivery_does_not_relabel_source_execution": True}
    for src, name in ((RUN / "qualification.json", "qualification.json"), (AUDIT / "audit.json", "audit.json"),
                      (BUNDLE, "tested-source.bundle")):
        data, info = regular(src)
        (OUT / name).write_bytes(data)
        os.chmod(OUT / name, info["mode"])
        require(regular(OUT / name)[0] == data, "top-level copy differs")
    write_json(OUT / "acceptance.json", acceptance)
    write_json(OUT / "publication-provenance.json", provenance)
    write_json(OUT / "raw-evidence-manifest.json", manifest)
    status = "; ".join(f'{r["id"]}: {r["status"]}/{r["conclusion"]}' for r in full_snapshots) or "No completed full-workflow status inferred"
    costs = "\n".join(f'| {arm} | {ndu["median_net_cost_ns"][arm]/1e6:.3f} | {ndu["median_amortized_net_cost_ns"][arm]/1e6:.3f} |'
                      for arm in ("fixed-stop", "fixed-fold", "fixed-selected", "light", "ndu"))
    readme = f"""# HIA 契约整合：实际源码与完整证据

**有限实现已经整合；六项广义目标没有全部关闭。** 本包的本地资格结果为 {q["ok"]}，独立审计结果为 {audit["ok"]}。旧性能和 Agent 实验没有作为当前版本重新测量。

## 实际执行身份与分母

本地实际检出并执行的 GitHub 提交为 {HEAD}，tree 为 {TREE}；本地结果没有重标成另一提交。源码与外部输入前后不变分别为 {q["source_unchanged"]}、{q["external_inputs_unchanged"]}。

源码交付在 [PR #329](https://github.com/TrillionniumFoundation/Hepta/pull/329)，该源码分支保持冻结。本证据目录由基于此源码的独立分支 codex/hia-contract-evidence-20261027 作数据提交；证据提交没有自包含自己的 SHA，也没有声称对数据提交重新运行完整测试。实际受测身份始终是上述源码提交。

本地完整 Python 回归 {gates["full_regression"]["tests_run"]} 项，Rust crate {gates["rust_resource_crate"]["tests_run"]} 项；完整原始结果和日志在 qualification.json。六个门禁及关键模块覆盖属于这一轮；覆盖清单不是额外测试分母。

同一源码的 verified CI 跑了 {regression["tests"]} 项选择性测试，失败 {regression["failures"]}、错误 {regression["errors"]}、跳过 {len(regression["skipped"])}。不能与完整回归相加。C++ scope 在 {cpp["case_count"]} 个输入上分别执行 C++ reference、Hepta→Rust、Hepta→C、源程序直接 LLVM，共 {cpp["case_count"] * 4} 次正向调用；每路径 {cpp["expected"]["allocations"]} 次分配/释放、{cpp["expected"]["refusals"]} 次拒绝。第四条路径不是 standalone HIA refinement 证明。

七主机 C ABI 记录 {host["foreign_calls"]} 次 foreign calls、{host["ill_typed_controls_rejected"]} 个类型负例和 {host["compiled_wrong_echo_controls_rejected"]} 个错误结果负例。七个原始 ZIP 都保留；其中只有报告与日志，没有七平台的 native binary。Windows 的 CRLF 文件身份差异另有真实对照记录。范围是既有有限 C ABI，不是新 HIA runtime 在所有平台通过。

完整远程资格状态仅按已捕获的 API 快照记录：{status}。其状态与本地全量、{regression["tests"]} 项选择性 CI、七主机结果分别记录；运行中或失败不转换为通过。

## 新的递归 NDU 对照仍没有收益优势

| 策略 | 总净成本中位数 ms | 加入共同 setup 与自身 native 构建的摊销中位数 ms |
| --- | ---: | ---: |
{costs}

这次实际闭环的 statistical_superiority_established={ndu["statistical_superiority_established"]}，NDU 比 light/selected-fixed 成本低的描述性标志分别为 {ndu["ndu_descriptive_cost_lower_than_light"]}/{ndu["ndu_descriptive_cost_lower_than_selected_fixed"]}。这些是当前源码新 RESULT 的数值，旧 a4ab CI 成本只在历史目录保留。完整 RESULT/PROTOCOL、episode 账本、失败控制及源码身份在原始 ZIP 和 ci/integrated 内保留。NDU 只是 advisory；安全与发布权限独立。成本包含实际记录的编译、提案、证明、拒绝和执行；明确排除项原文为 {json.dumps(ndu["setup_accounting"]["excluded"], ensure_ascii=False)}。不能称整机冷启动或完整开发成本。

## 六项范围

| 项目 | 已落实的有限能力 | 仍待关闭 |
| --- | --- | --- |
| 1 语义收敛 | 同一 Core 准入；两种明确证明 profile；fold-constants 与 optimize 分离；两种 NDU 桥独立 | 通用源语言前端、源/后端 refinement 仍非本次证明 |
| 2 资源/Rust | byte-owner CFG/内部调用、owner 返回、调用内借用、失败/停止账本；C++ 词法清理 | 返回/逃逸借用、通用组合、完整取消/展开等价性 |
| 3 优化验证 | 无环整函数值/首次 trap 证明；保持 CFG/资源/调用骨架的分段证明 | 一般资源、循环 CFG、并发/内存变换及后端证明 |
| 4 NDU | 原始固定版本算法、有限动作、相同预算对照、实际成本 | 增量收益未建立；不代表全局最优 |
| 5 迁移/ABI | 有限完整 C/C++ fixture；库复用契约；实际主机 C ABI | 大型任意项目低成本迁移、任意 C++ ABI/foreign 安全 |
| 6 运行时/指令 | 封存代码、lease、回滚、有界取消；空状态切换；独立有限 x86 搜索 | 真实净收益、活资源状态迁移、ISA 搜索在线发布 |

Adaptive 的自动收益、自动盈利选择和一般活 owner/state 迁移标志均为 false。历史后台正向发布用合成成本检查生命周期，不能当作真实加速。历史有限 x86 字节最小也不是运行时间或全局最优。

## 保留失败与历史边界

第一次整合源码 a4ab878 的 run1 实际运行 {prior_full["tests_run"]} 项，产生 {prior_full["failures"]} 个 failure 条目、{prior_full["errors"]} 个 error、{prior_full["skipped"]} 个 skip，整轮失败。{prior_audit["failed_unique_method_count"]} 个测试方法揭露了同一键预检缺陷：预检用 json.dumps 转换字典键，提前进入完整 encoder。修复使用经过预算和有限值检查的精确内建键转换，保留原拒绝断言，并补上实际 wire 字节/极端键对照；39 项修复相关测试单独记录。历史目录完整保留失败 run1 的非缓存文件、调用/日志、独立审计、a4ab CI、原 source bundle/发布记录及修复日志。a4ab 上通过的选择性 CI/host 结果不重标为817，也不抹去其全量失败。

ci/historical-e147 保存旧源码 e1473a4 的完整 job log、选取报告、API、ZIP 成员清单与诊断：50/50 子门禁和 2640 项测试通过，但最终源码快照变化使整轮失败。前后可得清单显示新增 Cargo target 文件，原 checker 自己未保留最终清单的限制亦保留。当前整合已将 Cargo 输出放到仓库外，并保留严格快照检查。旧 274 MB 原始 ZIP 不重复装包；其路径、GitHub artifact ID、稳定 API URL、大小和已复验哈希列于 raw-evidence-manifest.json。

historical-controls 保留冻结前缺少显式 Clang 配置导致跳过的尝试、签名不匹配的 fixture 失败及修正后通过日志。这些不是当前完整回归的额外测试。仓库已有 evidence/hia_ndu_pipeline_20261027 和 experiments 中 PR325 的历史压缩证据保持原样；不重复打包或重标其性能、Agent 结果。

## 包内容与重建

qualification.json 是逐字节原始本地最终报告；audit.json 是独立重计数/哈希审计。acceptance.json 与 publication-provenance.json 分别说明验收范围和身份。raw-evidence.tar.gz 保留 {len(entries)} 个普通文件，解压前字节总量 {manifest["uncompressed_bytes"]}；每成员重开并核对实际字节、SHA-256 和模式。构建缓存及大型已安装工具链未打包；实际 Linux Rust oracle、两种实际 NDU executable、原始源码/锁文件/构建输入和身份收据保留。瞬时 runtime generations 已按生命周期销毁，不能声称其字节在包中。

tested-source.bundle 的 SHA-256 为 {BUNDLE_SHA}，包含实际受测 HEAD，要求现有仓库先有父提交 {", ".join(PARENTS)}。它不是整个仓库的自包含备份。旧 a4ab bundle 也在历史目录保留，仍要求它原来的两个父提交。先 git bundle verify，再从 bundle fetch HEAD，可检出 {HEAD}。完整实际 argv、环境和工具身份在 frozen-plan/qualification 记录中。

raw-evidence.tar.gz SHA-256：{archive_info["sha256"]}。打包不执行测试、基准或模型推理；哈希证明本地文件一致性，不能认证恶意宿主自造观测。验证器、SMT 编码/Z3、编译器、loader、硬件与可信测量仍是明确边界；全语言 soundness、普遍 Rust 性能优势、绝对 foreign 安全和全局最优均未建立。
"""
    (OUT / "README.md").write_text(readme)
    source_clean()
    return {"output": str(OUT), "members": len(entries), "raw_bytes": manifest["uncompressed_bytes"],
            "archive_bytes": archive_info["bytes"], "archive_sha256": archive_info["sha256"],
            "source_head": HEAD, "local_qualification_passed": q["ok"], "audit_passed": audit["ok"]}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-inputs", action="store_true", help="read-only readiness check; never poll")
    arguments = parser.parse_args()
    try:
        print(json.dumps(assemble(arguments.check_inputs), indent=2))
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False))
        raise SystemExit(1)
