"""Task runner; the repository collector owns the actual qualification result."""
from pathlib import Path
from datetime import datetime, timezone
import json
import os
import subprocess
import sys

workspace = Path('/workspace/scratch/bf7d454bbc83')
source = workspace / 'hepta-integrated'
if len(sys.argv) != 3:
    raise SystemExit('usage: run_integrated_qualification.py EXPECTED_HEAD NEW_OUTPUT_DIRECTORY')
head, output_argument = sys.argv[1:]
output = Path(output_argument).resolve()
if output.exists():
    raise SystemExit('qualification output must be new')
clang_root = workspace / 'toolchains/clang-20/usr/lib/llvm-20/bin'
rust_root = workspace / 'toolchains/rust-1.90.0/bin'
environment = dict(os.environ)
environment.update({
    'PATH': os.pathsep.join(map(str, [clang_root, rust_root,
        workspace / 'gdb-prerequisite/root/usr/bin', workspace / 'toolchains/qemu-8.2.2',
        workspace / 'toolchains/lean-4.19.0/bin'])) + os.pathsep + os.environ['PATH'],
    'LD_LIBRARY_PATH': os.pathsep.join(map(str, [
        workspace / 'toolchains/clang-20/usr/lib/x86_64-linux-gnu',
        workspace / 'gdb-prerequisite/root/usr/lib/x86_64-linux-gnu',
        workspace / 'qemu-system-prerequisite/root/usr/lib/x86_64-linux-gnu'])),
    'PYTHONPATH': str(workspace / 'python-deps') + os.pathsep + str(source),
    'PYTHONDONTWRITEBYTECODE': '1',
    'CARGO_HOME': str(workspace / 'cargo-cache'),
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'RUSTC': str(rust_root / 'rustc'),
    'LEAN': str(workspace / 'toolchains/lean-4.19.0/bin/lean'),
    'CPATH': str(workspace / 'boost-prerequisite/root/usr/include'),
    'CLANG': str(clang_root / 'clang'),
    'CLANGXX': str(clang_root / 'clang++'),
    'HEPTA_LLD': str(clang_root / 'ld.lld'),
    'HEPTA_LLVM_READOBJ': str(clang_root / 'llvm-readobj'),
    'HEPTA_QEMU_AARCH64': str(workspace / 'toolchains/qemu-8.2.2/qemu-aarch64-static'),
    'HEPTA_QEMU_RISCV64': str(workspace / 'toolchains/qemu-8.2.2/qemu-riscv64-static'),
})
argv = [sys.executable, 'tools/qualify_hia_integrated.py',
    '--expected-head', head, '--output-directory', str(output),
    '--clang', str(clang_root / 'clang'), '--cargo', str(rust_root / 'cargo'),
    '--rustc', str(rust_root / 'rustc'),
    '--ranking-bridge', '/tmp/hepta-hia-ndu-target/debug/hia-ndu-bridge',
    '--ranking-build-receipt', str(workspace / 'ndu-build-final/build-receipt.json'),
    '--ranking-upstream', str(workspace / 'ndu-upstream'),
    '--recursive-bridge', str(workspace / 'ndu-recursive-build-integrated/target/release/hepta-hia-ndu-bridge'),
    '--recursive-identity', str(workspace / 'ndu-recursive-build-integrated/identity.json'),
    '--recursive-upstream', str(workspace / 'ndu-recursive-upstream'),
    '--timeout', '2400',
]
receipt_path = Path(str(output) + '-invocation.json')
receipt = {'argv': argv, 'cwd': str(source), 'expected_head': head,
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'qualification_claim': False,
    'environment': {key: environment[key] for key in (
        'PATH', 'LD_LIBRARY_PATH', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
        'CARGO_HOME', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
        'RUSTC', 'LEAN', 'CPATH', 'CLANG', 'CLANGXX', 'HEPTA_LLD', 'HEPTA_LLVM_READOBJ',
        'HEPTA_QEMU_AARCH64', 'HEPTA_QEMU_RISCV64')}}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
with Path(str(output) + '.log').open('x') as transcript:
    process = subprocess.Popen(argv, cwd=source, env=environment, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1)
    for line in process.stdout:
        transcript.write(line)
        transcript.flush()
        print(line, end='', flush=True)
    returncode = process.wait()
receipt.update(returncode=returncode, finished_utc=datetime.now(timezone.utc).isoformat())
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(returncode)
