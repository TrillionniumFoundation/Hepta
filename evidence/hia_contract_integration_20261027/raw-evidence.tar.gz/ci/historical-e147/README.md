# Source CI failure diagnosis

Tested source: `e1473a42f6b9a50a42f8cca8fadff47e709cf4d4`.
Run: https://github.com/TrillionniumFoundation/Hepta/actions/runs/40551242912
Job: `122355254709`.

The workflow ended with failure. Its release checker ran **50/50 gates successfully**, including **2,640 Python tests, zero skips, 525.989 seconds**, but the final `snapshot_unchanged` check was false. This is a failed qualification; passing subgates do not convert the whole gate into a pass.

The release checker did not retain its own final file inventory. Its initial inventory is preserved in `artifacts/candidate/release-validation.json`. The immediately following standalone qualification retained its initial inventory in `artifacts/hia-unified/qualification.json`. Comparing these two concrete inventories finds **319 added files, zero modified files, zero removed files**; every addition is below `rust/hia-core-shadow/target/`. The full unittest build used Cargo's default in-repository target directory, which the release snapshot enumerates. See `source-drift-diagnosis.json` for every path and the limitation of this comparison.

A narrow prospective fix is to export `CARGO_TARGET_DIR` to a task-scoped location outside the repository (or an already excluded artifacts directory) before running the release checker. Keep the source snapshot rejection unchanged. This diagnostic task did not edit source, rerun CI, or mark the failed run successful.

The later standalone qualification passed 35/35 scoped gates and retained unchanged source. The bounded NDU pipeline passed 9/9 gates with unchanged source and all broad scientific closure flags false. Their reports are preserved separately; their test counts are not added to 2,640.

The original GitHub ZIP is retained beside this portable directory as `source-release-e1473a4.zip`: 273,984,799 bytes; SHA-256 `2967a99c10a9d3416989324c487f901b78695b07e50327791b9e0f6ed8f9592f`, matching GitHub's artifact digest. Its complete member inventory is `zip-members.json`. This portable directory contains exact selected report/log bytes, complete downloaded job logs, API metadata, and a hash manifest. It is not a replacement claim that every ZIP member is included here.

Evidence-only commit `e1d83e4cce5b2fd20292538d081b3d06e0407c3a` has its own runs. At the timestamp in `final-status.json`, its host ABI run `40554188084` succeeded on all seven matrix jobs; its full gate run `40554188058` remained in progress at native dependency installation. Do not attribute its status to source commit e147 or claim its release gates passed.
