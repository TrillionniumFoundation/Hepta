# Corrected integration source CI evidence

Source: `817713b163b6812a6516179951412b4a6c93ae2b`.
Tree: `6a034a0ed5d001823dc26683e1677520d4b510e2`.
Parent: `a4ab87889616925306b84f9699316d1a850c183d`.

The GitHub commit response and API run/job/artifact metadata are retained beside the evidence subdirectories. This directory contains fresh observations for 817713b; old a4ab and Phase A results remain in separate directories.

## Host ABI push run 40559493041

All seven actual host/compiler jobs succeeded. The seven original ZIPs total 58,751 bytes and each matches its GitHub artifact SHA-256. The actual JSON reports were checked: 7 jobs × 2 profiles × 181 foreign calls = 2,534 calls, 21 ill-typed declaration controls rejected, and 7 compiled wrong-echo controls rejected. Each ZIP contains native-host.json and two logs, without the platform binaries. Scope is the existing finite Hepta C ABI matrix, not qualification of the whole HIA runtime on every platform.

Compiler hashes in all reports match the corresponding 817713b source bytes: LF on Unix hosts and the exact CRLF transformation on Windows. This line-ending check is recorded explicitly; byte-identical compiler files across operating systems are not claimed.

## Verified integration push run 40559493137

The push run and separate pull-request run 40559504265 completed successfully. This directory retains the push run original ZIP (2,480,104 bytes, SHA-256 6d1842944220d0c8cc07e7c1c7a8a235ba68b1a82cd0332bc500e03af32dce65), complete job log, all ZIP member descriptors, and selected exact JSON/log bytes with hashes.

The expanded selected regression executed **219 tests with zero errors, failures or skips**, git_base equal to 817713b, and unchanged measured source. It includes the newly selected wire and proof integration checks. This is a separate execution and is not added to the full regression denominator.

The scoped C++ migration qualifier ran 1,121 cases through C++ reference, Rust, C and source LLVM paths. The expected per-path aggregate has 3,180 allocations, 3,180 frees, 398 refusals and zero live allocations. Its claims explicitly leave whole-C++ support, source equivalence proof and general performance superiority unestablished.

The finite recursive NDU run reports actual budgets and outputs passing, but both descriptive cost-improvement flags and statistical_superiority_established remain false. Its fresh median net cost is 358.105 ms for NDU, 276.214 ms for light search and 276.814 ms for the selected fixed policy. Full accounting, including amortized setup costs, is retained in the original result. Adaptive runtime continues to report automatic benefit, automatic profitable selection, and general live-state/owner migration false.

## Full qualification status

Push run 40559493121 is running; same-head pull-request run 40559504509 is a separate queued run. A completed qualification must be backed by its actual final API state, logs and report. The completed host and selected native results above do not imply the full qualification has passed. This evidence collector has not cancelled or rerun any workflow.
