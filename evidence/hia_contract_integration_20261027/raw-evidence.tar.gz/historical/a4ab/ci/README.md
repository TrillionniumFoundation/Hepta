# Exact integration source CI evidence

Source commit: `a4ab87889616925306b84f9699316d1a850c183d`.
Tree: `5a434dc0d8d6544dad76ad53caff24c412691574`.

`source-commit.json` is the GitHub Git-data response for this exact commit. These files concern this integration source, not older Phase A or PR325 counts.

## Host ABI push run 40556426884

All seven actual host/compiler jobs passed. Seven original ZIP archives were downloaded and matched each GitHub digest. Reports independently contain 2 profiles × 181 foreign calls each: 2,534 calls total, 21 ill-typed declaration controls rejected, and 7 compiled wrong-echo controls rejected. Scope remains the existing finite Hepta C ABI matrix, not whole HIA runtime cross-platform qualification. Each ZIP contains a JSON report and two logs, not platform native binaries. `host-push-40556426884/summary.json` and manifests retain the per-host observations.

The Windows reports' Python compiler hash differs from LF hosts. `line-ending-comparison.json` verifies that its value exactly matches transforming the same committed Python files to CRLF. This is the same Git commit with platform checkout line endings; byte-identical compiler files across OSes are not asserted.

## Verified optimization push run 40556427482

This run and the separate PR run 40556598751 completed successfully. The push run's original 2,478,862-byte ZIP, digest verification, complete job log, all 298 member descriptors and exact selected report/log bytes are retained in `verified-push-40556427482/`.

Its selected regression ran 207 tests with zero errors, failures or skips, git_base equal to this source SHA, and unchanged measured source. Do not add these tests to the full regression denominator. C++ scoped migration ran 1,121 cases via C++ reference, Rust, C and source LLVM routes, with 3,180 allocations/frees, 398 refusals, and no live allocation in the expected aggregate. This is a finite source migration profile, not general C++ support or an automatically proved HIA refinement.

Recursive NDU results still do not establish incremental advantage: both descriptive-lower flags and statistical_superiority_established are false. Actual median net cost is 252.879 ms for NDU, 197.751 ms for the light search, and 202.282 ms for selected fixed policy. The recorded amortized figures and full protocol remain in the original report. Adaptive runtime reports automatic benefit and automatic profitable selection false. No broad closure or automatic deployment claim follows from successful mechanism checks.

## Full qualification

The exact-source full push run 40556426840 is still executing at the status captured so far; a PR event for the same head created run 40556598703, queued behind the same concurrency group. Later status and logs must be consulted before a completed result is claimed. No workflow was rerun or cancelled by this evidence collection.
