#!/usr/bin/env python3
"""Independent read-only audit of the frozen integrated qualification report."""
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess

BASE = Path('/workspace/scratch/bf7d454bbc83')
ROOT = BASE / 'hepta-integrated'
RUN = BASE / 'hia-integrated-qualification-run1'
OUTPUT = BASE / 'hia-integrated-evidence-audit'
HEAD = 'a4ab87889616925306b84f9699316d1a850c183d'
TREE = '5a434dc0d8d6544dad76ad53caff24c412691574'


def digest(path):
    value = sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def load(name):
    return json.loads((RUN / name).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode()


def frozen_git_inventory():
    entries = {}
    for row in git('ls-tree', '-rz', '--full-tree', HEAD).split('\0'):
        if not row:
            continue
        metadata, name = row.split('\t', 1)
        mode, kind, blob = metadata.split()
        if kind != 'blob' or mode not in ('100644', '100755'):
            raise ValueError('Unexpected nonregular frozen source entry: ' + name)
        entries[name] = blob
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    cache = {}
    try:
        for blob in sorted(set(entries.values())):
            process.stdin.write((blob + '\n').encode())
            process.stdin.flush()
            observed, kind, size = process.stdout.readline().decode().strip().split()
            if observed != blob or kind != 'blob':
                raise ValueError('Frozen Git object read differs')
            remaining = int(size)
            value = sha256()
            while remaining:
                chunk = process.stdout.read(min(remaining, 1024 * 1024))
                if not chunk:
                    raise ValueError('Truncated frozen Git object')
                value.update(chunk)
                remaining -= len(chunk)
            if process.stdout.read(1) != b'\n':
                raise ValueError('Git object boundary differs')
            cache[blob] = value.hexdigest()
    finally:
        process.stdin.close()
        process.stdout.close()
        process.wait()
    if process.returncode:
        raise ValueError('Frozen Git object reader failed')
    return {name: cache[blob] for name, blob in entries.items()}


def main():
    report = load('qualification.json')
    plan = load('frozen-plan.json')
    checks = {}
    def check(name, condition):
        checks[name] = bool(condition)
    current_worktree = {'head': git('rev-parse', 'HEAD').strip(),
                       'status': git('status', '--porcelain', '--untracked-files=all'),
                       'qualification_authority': False}
    check('published_frozen_source_head_and_tree',
          git('rev-parse', HEAD + '^{commit}').strip() == HEAD and git('rev-parse', HEAD + '^{tree}').strip() == TREE)
    check('frozen_plan_exact_source', plan['source_head'] == HEAD and plan['source_tree'] == TREE)
    before, after = report['source_before'], report['source_after']
    check('reported_source_snapshot_identical', before == after and report['source_unchanged'] is True)
    check('reported_source_exact_and_clean', before['head'] == HEAD and before['tree'] == TREE and not before['status'])
    git_inventory = frozen_git_inventory()
    tracked = set(git_inventory)
    check('source_inventory_is_all_tracked_files', tracked == set(before['files']))
    source_mismatches = [name for name, value in before['files'].items() if git_inventory.get(name) != value]
    check('frozen_git_object_hashes_match_source_snapshot', not source_mismatches)
    external_before, external_after = report['external_inventory_before'], report['external_inventory_after']
    check('reported_external_snapshots_identical', external_before == external_after and report['external_inputs_unchanged'] is True)
    external_mismatches = [name for name, value in external_before.items() if digest(Path(name)) != value]
    check('actual_external_hashes_match', not external_mismatches)
    gates = report['gates']
    names = [row['name'] for row in gates]
    expected = ['actual_tools_and_linux_seals', 'ranking_bridge_identity', 'recursive_bridge_identity',
                'rust_resource_crate', 'full_regression', 'merge_and_profile_coverage']
    check('exactly_six_distinct_gates', names == expected and len(names) == len(set(names)))
    by_name = {row['name']: row for row in gates}
    acceptance = {'all_six_reported_pass': all(row['passed'] is True for row in gates)}
    sidecars = {
        'actual_tools_and_linux_seals': 'actual_tools_and_linux_seals.json',
        'ranking_bridge_identity': 'ranking_bridge_identity.json',
        'recursive_bridge_identity': 'recursive_bridge_identity.json',
        'rust_resource_crate': 'rust_resource_crate-execution.json',
        'full_regression': 'full_regression-execution.json',
        'merge_and_profile_coverage': 'merge-and-profile-coverage.json',
    }
    check('individual_gate_records_match_final_report', all(by_name[name] == load(path) for name, path in sidecars.items()))
    full = by_name['full_regression']
    log = full['execution']['stderr']
    footer = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', log, re.MULTILINE)
    check('one_unittest_footer', len(footer) == 1)
    tests_run = int(footer[0][0])
    identifiers = []
    for line in log.splitlines():
        if line.startswith('test') and ' (' in line and ')' in line:
            identifier = line.partition(' (')[2].partition(')')[0]
            if identifier.startswith('tests.'):
                identifier = identifier[len('tests.'):]
            if identifier.startswith('test_'):
                identifiers.append(identifier)
    check('one_record_per_full_test', len(identifiers) == len(set(identifiers)) == tests_run == full['tests_run'])
    acceptance['full_run_actual_success_zero_skips'] = (
          full['execution']['returncode'] == 0 and re.search(r'^OK$', log, re.MULTILINE) is not None
          and all(full.get(field, 0) == 0 for field in ('failures', 'errors', 'skipped'))
          and re.search(r'\b(?:FAIL|ERROR|skipped|expected failure|unexpected success)\b', log) is None)
    failure_entries = re.findall(r'^FAIL: (.+)$', log, re.MULTILINE)
    error_entries = re.findall(r'^ERROR: (.+)$', log, re.MULTILINE)
    failed_methods = sorted({entry.partition(' (')[2].partition(')')[0] for entry in failure_entries})
    check('raw_failure_and_error_entries_match_report', len(failure_entries) == full['failures']
          and len(error_entries) == full['errors'])
    check('no_skipped_full_tests', full['skipped'] == 0 and re.search(r'\.\.\. skipped\b', log) is None)
    check('failed_run_is_explicit_and_preserved', full['failures'] == 10 and len(failed_methods) == 3
          and full['errors'] == 0 and 'FAILED (failures=10)' in log and full['execution']['returncode'] != 0)
    check('extracted_raw_logs_match_embedded_execution',
          (RUN / 'full-regression-stdout.log').read_text() == full['execution']['stdout']
          and (RUN / 'full-regression-stderr.log').read_text() == log)
    check('one_full_discovery_command', sum(row['name'] == 'full_regression' for row in plan['commands']) == 1
          and full['execution']['argv'] == [row['argv'] for row in plan['commands'] if row['name'] == 'full_regression'][0]
          and full['execution']['argv'][1:] == ['-m', 'unittest', 'discover', '-s', 'tests', '-v'])
    coverage = by_name['merge_and_profile_coverage']
    expected_groups = {group: {module: sorted(name for name in identifiers if name.startswith(module + '.'))
                              for module in modules} for group, modules in plan['critical_modules'].items()}
    check('coverage_exactly_rederived_from_same_full_run', coverage['groups'] == expected_groups
          and coverage['verbose_method_records'] == coverage['unique_method_records'] == tests_run
          and coverage['subsets_of_full_regression_only'] is True
          and not coverage['missing_modules']
          and all(methods for modules in expected_groups.values() for methods in modules.values()))
    rust = by_name['rust_resource_crate']
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
                           rust['execution']['stdout'], re.MULTILINE)
    rust_total = sum(int(row[0]) for row in summaries)
    check('rust_counts_rederived_from_raw_summaries', rust_total == rust['tests_run'] == 54
          and len(summaries) == rust['test_binaries'] and all(all(int(value) == 0 for value in row[1:]) for row in summaries)
          and rust['execution']['returncode'] == 0)
    tool_gate = by_name['actual_tools_and_linux_seals']
    check('thirteen_actual_tool_probes', len(tool_gate['tools']) == 13
          and all(row['execution']['returncode'] == 0 and row['execution']['argv'][0] == row['invocation_path']
                  and str(Path(row['invocation_path']).resolve()) == row['path']
                  and external_before[row['path']] == row['sha256'] for row in tool_gate['tools'].values()))
    check('actual_required_kernel_seals', tool_gate['linux_seals'] == {
        'required_bits': 15, 'actual_bits': 15, 'actual_write_rejected_errno': 1, 'exact_readback': True})
    solver = tool_gate['solver']
    package = Path(solver['library_path']).parent.parent
    binding = sha256()
    for path in sorted(package.glob('*.py')):
        binding.update(path.name.encode() + b'\0' + path.read_bytes() + b'\0')
    check('actual_solver_binding_and_library_hashes', solver['version'] == '4.15.4'
          and binding.hexdigest() == solver['binding_sha256']
          and external_before[solver['library_path']] == solver['library_sha256'])
    ranking = by_name['ranking_bridge_identity']
    recursive = by_name['recursive_bridge_identity']
    check('native_bridges_keep_distinct_pins_protocols_and_denied_authority',
          ranking['identity']['upstream_commit'] == 'd3c2d760eca5065fc966820379c35c6e8d56e855'
          and recursive['identity']['source_commit'] == '2590c0c94c5bf9a9004caeeb7b75edd6faf3eb8b'
          and ranking['response']['authority'] == 'ADVISORY_ONLY'
          and ranking['response']['proves_program_safety'] is False
          and recursive['response']['authority'] == 'DENY_ALL' and recursive['response']['safety_certificate'] is False
          and ranking['request']['schema'] != recursive['request']['schema'])
    false_claims = ['historical_evidence_reused_as_current', 'standalone_performance_campaigns_replayed',
                    'scientific_incremental_advantage_established', 'whole_language_soundness_proved',
                    'global_optimality_established', 'six_stages_closed']
    check('historical_and_scientific_boundaries_retained', all(report[name] is False for name in false_claims)
          and plan['historical_performance_denominators_combined'] is False)
    acceptance['final_success'] = report['ok'] is True and report['status'] == 'bounded_integrated_contracts_passed'
    check('final_failure_state_consistent_with_gates', report['ok'] is False
          and report['status'] == 'integration_qualification_failed'
          and by_name['full_regression']['passed'] is False and by_name['merge_and_profile_coverage']['passed'] is False)
    artifact_hashes = {path.name: digest(path) for path in sorted(RUN.iterdir()) if path.is_file()}
    result = {'schema': 'hepta.hia.integrated-independent-audit.v1',
              'ok': all(checks.values()) and all(acceptance.values()),
              'audit_integrity_ok': all(checks.values()), 'qualification_passed': report['ok'],
              'checks': checks, 'acceptance_checks': acceptance, 'source_head': HEAD, 'source_tree': TREE,
              'current_worktree_observation_not_used_as_frozen_source': current_worktree,
              'tracked_files': len(tracked), 'external_inventory_files': len(external_before),
              'full_python_tests': tests_run, 'full_python_seconds_from_raw_footer': float(footer[0][1]),
              'full_python_method_records': len(identifiers), 'rust_tests': rust_total,
              'failure_entries': failure_entries, 'failure_entry_count': len(failure_entries),
              'failed_unique_methods': failed_methods, 'failed_unique_method_count': len(failed_methods),
              'failure_entry_count_is_not_bug_count': True, 'error_entry_count': len(error_entries),
              'source_mismatches': source_mismatches, 'external_mismatches': external_mismatches,
              'coverage_counts_are_subsets_not_extra_tests': True,
              'coverage_module_test_counts': {group: {module: len(methods) for module, methods in modules.items()}
                                              for group, modules in expected_groups.items()},
              'evidence_sha256': artifact_hashes,
              'scope': 'read-only independent recount/hash audit of one local integrated qualification; no additional tests or performance campaigns executed'}
    (OUTPUT / 'audit.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('ok', 'audit_integrity_ok', 'qualification_passed', 'source_head',
                    'tracked_files', 'external_inventory_files', 'full_python_tests', 'rust_tests',
                    'failure_entry_count', 'failed_unique_method_count')}, indent=2))
    print(json.dumps({'failed_checks': [name for name, passed in checks.items() if not passed]}))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
