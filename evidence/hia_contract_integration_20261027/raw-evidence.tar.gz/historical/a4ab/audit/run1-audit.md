# Independent audit of integrated qualification run 1

**The qualification failed. The retained evidence passed its independent integrity audit.**

- Frozen source commit: `a4ab87889616925306b84f9699316d1a850c183d`.
- Frozen tree: `5a434dc0d8d6544dad76ad53caff24c412691574`.
- Original report SHA-256: `e54263a9da2f93a2ece5c3b96a88cfa530a3b53cbe0e49b005abae01acf5d200`.
- Independent integrity checks: **25/25 passed**. Qualification acceptance remains false.
- Exactly one full Python discovery: **2,716 tests**, **10 failure entries**, **0 errors**, **0 skips**, raw footer **786.617 seconds**.
- The 10 failure entries belong to **3 distinct test methods**, including eight subtest entries from one method. This is not a count of 10 separate defects.
- Separate Rust crate execution: **54 tests**, zero failed/ignored/measured/filtered, recounted from ten binary/doc-test summary records (some have zero tests).
- Gate results: actual tools/kernel, ranking NDU, recursive NDU and Rust passed; full regression and its dependent coverage acceptance failed.

## Source and evidence integrity

All **3,512 frozen tracked-file hashes** were independently recomputed from Git blob objects at the exact source commit and matched the report inventory. The audit did not substitute the current worktree for frozen evidence; subsequent fixes can make that worktree dirty without changing this source attribution.

All **244 external input hashes** were independently checked against actual files and matched both recorded external snapshots. The original before/after source snapshots and external snapshots are equal. The individual gate JSON records match the aggregate report. Extracted stdout/stderr logs exactly match the strings inside the full-regression execution record. Original reports and raw logs were read only.

Both complete source and external inventories remained unchanged during the qualification, according to the preserved collector snapshots. A separate current-worktree observation is recorded in the audit JSON and carries no qualification authority.

## Failure localization

All ten raw traceback entries reach `hepta/hia_program_tools.py` line 202 in this frozen revision: `wire_key = json.dumps(key, allow_nan=False)`. That call invokes the JSON encoder while the in-memory boundary is still supposed to reject collisions or nonfinite keys before encoding. The three affected methods install an encoder refusal control and detect this premature call:

1. `test_nested_collision_is_also_refused_before_encoding` — one entry.
2. `test_nonfinite_numeric_key_remains_rejected` — one entry.
3. `test_numeric_boolean_null_and_float_key_aliases_refuse_before_encoder` — eight subtest entries covering integer, Boolean, null and float key aliases with both sort settings.

The new boundary test failures must be fixed in a later source revision and verified with a fresh full run. They do not invalidate the evidence identity audit, and successful unrelated gates do not override this failed qualification.

## Counting and claim limits

The full raw log has exactly **2,716 unique test-method records** and one matching unittest footer. All critical-module coverage rows were reconstructed from those same records; no module is missing. Those rows are subsets of the full run, never additional tests. Because the full run failed, the coverage gate correctly reports failure even though its inventory is complete.

Both native NDU protocols preserve their separate upstream pins and advisory/denied authority. The actual solver identity remains Z3 4.15.4 with matching Python bindings and loaded library. The run explicitly makes no claim of historical benchmark reuse, new standalone performance campaigns, NDU incremental advantage, whole-language soundness, global optimality or closure of all six stages.

## Files

- `run1-audit.json`: independent recount, integrity checks, failure entries and hashes for every top-level raw evidence file.
- `audit_integrated.py`: the read-only audit procedure for this exact failed run.
- `preflight.json`: earlier partial observations, explicitly not a qualification result.
