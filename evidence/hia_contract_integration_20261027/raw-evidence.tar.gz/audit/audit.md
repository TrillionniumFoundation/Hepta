# Independent audit of integrated qualification run 2

**PASS: all six qualification gates passed, and the independent evidence audit passed.**

| Item | Verified result |
| --- | --- |
| Frozen source commit | `817713b163b6812a6516179951412b4a6c93ae2b` |
| Frozen source tree | `6a034a0ed5d001823dc26683e1677520d4b510e2` |
| Independent integrity checks | **27/27 passed** |
| Independent acceptance checks | **3/3 passed** |
| Full Python discovery | **2,718 tests; 0 failures; 0 errors; 0 skips** |
| Raw method count | **2,718 unique methods**, matching one unittest footer |
| Full Python duration | **778.428 seconds** in unittest footer; **779.827747 seconds** including subprocess overhead |
| Separate Rust crate | **54 tests**, zero failed/ignored/measured/filtered |
| Frozen tracked-file inventory | **3,512 hashes**, independently checked against Git blob objects |
| External input inventory | **244 hashes**, independently checked against actual bytes |
| Actual tool probes | **13**, all successful |
| Native NDU protocols | **2**, distinct source pins and requests; advisory/denied authority retained |

Original `qualification.json` SHA-256:

`e362a5c272c0afe3f2e25e0d0d24cab5be0cc486a9bb085c51aa298981523139`

## What was independently checked

The frozen plan contains exactly one full Python discovery and a separate Rust command. The full raw stderr has one unittest count footer, one successful outcome, and exactly 2,718 unique method records. The reported counts agree with those records, with no failure or error traceback entries and no skipped tests. Rust's 54-test total was recomputed from ten binary/doc-test summary records, some of which have zero tests.

All 3,512 reported source hashes match immutable Git blobs at the exact published source commit. Both recorded source snapshots are identical, contain the expected commit/tree and have an empty status. All 244 external hashes match actual files and both recorded external snapshots. The current worktree was also observed clean at audit time; that separate observation does not replace the frozen source attribution.

Each individual gate JSON exactly matches its entry in the aggregate report. Extracted raw stdout and stderr exactly match the strings in the full-regression execution record. All top-level evidence files were hashed. Original reports and logs were read only.

The actual Z3 identity is version 4.15.4. Its Python binding digest and loaded library hash match the actual bytes. All 13 tool invocation paths, resolved executables, hashes and version-command outcomes agree with the external inventory. The kernel seal check retains actual seal bits 15, rejected write errno 1 and exact readback.

The ranking NDU bridge remains pinned to `d3c2d760eca5065fc966820379c35c6e8d56e855`. The recursive NDU bridge remains pinned to `2590c0c94c5bf9a9004caeeb7b75edd6faf3eb8b`. Their request schemas remain distinct, and their responses claim advisory/denied authority rather than code admission or safety certification.

## Coverage is a subset of the same run

Every critical module was found in the raw full-discovery records. The module groups were independently reconstructed and exactly match the collector's coverage view. The following counts are subsets of the 2,718 Python tests, never additional tests or independent qualification campaigns.

| Critical group | Methods in this full run |
| --- | --- |
| acyclic_scalar_smt | 21 |
| cli_and_route_contracts | 15 |
| compositional_barrier_smt | 18 |
| cpp_lexical_ownership | 20 |
| finite_actions_and_instruction_grammar | 26 |
| llvm_allocation_and_native_observables | 26 |
| native_runtime_lifecycles | 43 |
| ndu_protocol_isolation | 5 |
| proof_profile_integration | 3 |
| ranking_ndu | 32 |
| recursive_ndu | 16 |
| rust_resource_execution | 25 |
| wire_rejection | 17 |

The wire-key collision module now contributes six test methods to this run. Run 1's 2,716-test failure evidence remains a separate result at source `a4ab87889616925306b84f9699316d1a850c183d`; it is not overwritten, added to this denominator or reassigned to the fixed source.

## Qualification boundary

This audit establishes consistency and integrity of the recorded bounded local qualification. It adds no test executions and no standalone performance campaign. Existing native timing controls inside the full regression retain their narrower scope.

The report explicitly keeps historical-performance reuse, new standalone performance campaigns, NDU incremental advantage, whole-language soundness, global optimality and closure of all six requested stages false. Local qualification does not substitute for source-matched remote CI or physical hardware measurements.

## Retained audit files

- `audit.json`: independent recount, 27 integrity checks, 3 acceptance checks, complete critical-module counts and original evidence hashes.
- `audit_integrated.py`: read-only audit procedure for this frozen source and run.
- `prepared.json`: preparation receipt created before the final report existed.
- `SHA256SUMS`: hashes of those audit files and this report.
