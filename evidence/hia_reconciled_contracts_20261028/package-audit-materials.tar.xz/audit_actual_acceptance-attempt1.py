#!/usr/bin/env python3
"""Read-only independent archive/actual-acceptance reconciliation; runs no tests."""
import collections
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import tarfile

BASE = pathlib.Path('/workspace/scratch/bf7d454bbc83')
OUT = BASE / 'hia-round3-reconciled-package-audit'
DELIVERY = BASE / 'hepta-next-evidence/evidence/hia_reconciled_contracts_20261028'
ARCHIVE = BASE / 'hia-round3-reconciled-delivery-final/raw-evidence.tar.xz'
SOURCE = 'efb210e994c151c1161acfe8d50d5d48716d2755'
TREE = '560cbea19f5cdebdd1659c0408183594e43ed4da'
PARENT = '739e84a402a800d51abefc6007118c887db7d91a'
NDU_SOURCE = '8b0fd11dde9f13ac784b3579ec9930ae4832784d'
SHA = '88da2a1560adf6763d57a1e5780ead3dd6fb9e7bb4f7f9b0c7a1d22aa6ec5bd2'
COUNTS = collections.Counter()
FAILURES = []
DETAILS = {}


def check(group, condition, detail):
    COUNTS[group] += 1
    if not condition:
        FAILURES.append({'group': group, 'detail': detail})


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        while block := f.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(pathlib.Path(path).read_text())


CONFIG = load(BASE / 'hia-round3-reconciled-package-config.json')
MANIFEST = load(DELIVERY / 'raw-evidence-manifest.json')
MAPPING = load(OUT / 'ARCHIVE-PATH-MAPPING.json')
ACCEPTANCE = load(DELIVERY / 'acceptance.json')
GENERIC = load(OUT / 'ARCHIVE-AUDIT.json')
OBSERVED = {}
TEXT = {}
ORIGINS = collections.defaultdict(list)


def origin_key(path):
    p = pathlib.Path(path)
    return str(p.relative_to(BASE)) if p.is_absolute() else str(p)


def member_for(path):
    return MAPPING[origin_key(path)]


def raw(path):
    return TEXT[member_for(path)]


def obj(path):
    return json.loads(raw(path))


def bind(path, expected_hash=None, expected_size=None, group='required_origins'):
    name = member_for(path)
    row = OBSERVED[name]
    check(group, expected_hash is None or row['sha256'] == expected_hash, str(path) + ': sha256')
    check(group, expected_size is None or row['bytes'] == expected_size, str(path) + ': bytes')
    return row


def inventory(before, after, group):
    check(group, before == after, 'before/after exact inventory')
    check(group, before['head'] == SOURCE and before['tree'] == TREE, 'actual source head/tree')
    check(group, before['status'] == '', 'local source status clean')
    return before['files']


def python_footer(text, expected, group, verbose=False):
    text = text.decode() if isinstance(text, bytes) else text
    matches = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.M)
    check(group, len(matches) == 1 and int(matches[0][0]) == expected, 'actual unittest footer')
    check(group, re.search(r'^OK$', text, re.M) is not None and not re.search(r'^FAILED', text, re.M), 'actual unittest clean success')
    headers = list(re.finditer(r'^(test\S+) \(([^)]+)\)(?: \.\.\. .*)?$', text, re.M))
    methods = [(m.group(1),m.group(2)) for m in headers]
    if verbose:
        check(group, len(methods) == expected and len(set(methods)) == expected, 'unique verbose successful methods')
        for i,m in enumerate(headers):
            end = headers[i+1].start() if i+1<len(headers) else len(text)
            statuses = re.findall(r'(?:^|\.\.\. )(ok|ERROR|FAIL|skipped[^\n]*)$',text[m.start():end],re.M)
            check(group,statuses==['ok'],'actual method status '+m.group(1)+' '+m.group(2))
    return {'tests': int(matches[0][0]) if matches else None, 'seconds': float(matches[0][1]) if matches else None, 'verbose_methods': len(methods)}


def main():
    check('archive', ARCHIVE.stat().st_size == 36421592 and file_hash(ARCHIVE) == SHA, 'actual archive bytes and digest')
    check('archive', GENERIC['status'] == 'PASS_WITH_SCOPE_LIMITS' and GENERIC['matched_required_count'] == 2796, 'separate generic 473+2/nine-freeze audit')
    with tarfile.open(ARCHIVE, 'r|xz') as tf:
        for entry in tf:
            check('archive', entry.isfile() and entry.name not in OBSERVED, entry.name + ': regular unique member')
            if not entry.isfile():
                continue
            data = tf.extractfile(entry).read()
            row = {'sha256': sha(data), 'bytes': len(data), 'mode': entry.mode}
            OBSERVED[entry.name] = row
            expected = MANIFEST['files'].get(entry.name)
            check('archive', expected is not None and all(row[k] == expected[k] for k in row), entry.name + ': original manifest identity')
            if expected:
                ORIGINS[expected['origin']].append(entry.name)
            if entry.name.endswith(('.json', '.log', '.bundle', '.md')):
                TEXT[entry.name] = data
    check('archive', set(OBSERVED) == set(MANIFEST['files']) and len(OBSERVED) == 5602, 'all 5602 members independently read')
    check('archive', sum(v['bytes'] for v in OBSERVED.values()) == MANIFEST['uncompressed_bytes'], 'actual uncompressed denominator')
    for origin, name in MAPPING.items():
        check('origin_mapping', name in OBSERVED and origin_key(MANIFEST['files'][name]['origin']) == origin, origin)
    check('origin_mapping', len(MAPPING) == 5595, '5595 origin mapping keys')

    required = {}
    def require(path, expected_hash, expected_size=None):
        path = str(pathlib.Path(path).absolute())
        if path in required:
            check('required_origins', required[path]['sha256'] == expected_hash, path + ': duplicate expected identity consistent')
        required[path] = {'sha256': expected_hash, 'bytes': expected_size}

    for key in ('full_report','component_invocation','profile_invocation','final_audit','host_audit','ndu_result','ndu_independent_audit','ndu_requirements'):
        p = CONFIG[key]
        require(p, file_hash(p), pathlib.Path(p).stat().st_size)
    final = obj(CONFIG['final_audit'])
    originals_path = pathlib.Path(CONFIG['final_audit']).parent / 'original-evidence-manifests.json'
    original_bytes = raw(originals_path)
    check('original_roots', sha(original_bytes) == final['original_evidence_manifest_sha256'], 'primary independent auditor binds original five-root manifest')
    originals = json.loads(original_bytes)
    require(originals_path, sha(original_bytes), len(original_bytes))
    full = obj(CONFIG['full_report'])
    gates = {g['name']: g for g in full['gates']}
    roots_expected = {str(pathlib.Path(CONFIG[k]).parent) for k in ('full_report','component_invocation','profile_invocation')}
    for profile in ('recursive','finite'):
        g = gates[profile + '_bridge_identity']
        roots_expected.add(str(pathlib.Path(g['receipt']).parent))
        require(g['receipt'], g['receipt_sha256'])
        require(g['binary'], g['binary_sha256'])
    check('original_roots', set(originals) == roots_expected and len(originals) == 5, 'exact five independently frozen original roots')
    root_counts = {}
    excluded = []
    for folder, entries in originals.items():
        count = 0
        for relative, identity in entries.items():
            p = pathlib.PurePosixPath(relative)
            check('original_roots', not p.is_absolute() and '..' not in p.parts, folder + '/' + relative)
            if any(part in {'rust-target','__pycache__'} for part in p.parts):
                excluded.append(str(pathlib.Path(folder) / relative))
                continue
            require(pathlib.Path(folder) / relative, identity['sha256'], identity['bytes'])
            bind(pathlib.Path(folder) / relative, identity['sha256'], identity['bytes'], 'original_root_files')
            count += 1
        root_counts[folder] = {'original_inventory_count':len(entries), 'required_noncached_count':count}
    req = obj(CONFIG['ndu_requirements'])
    check('formal_requirements', len(req['required_files']) == 473 and sha(raw(CONFIG['ndu_requirements'])) == '19c30f199b817accb2fe16dcd4b57595f031c7d2fa2a7900fc5fb333a184a0cc', 'frozen 473 unchanged')
    for identity in req['required_files'].values():
        require(identity['source_path'], identity['sha256'], identity.get('bytes'))
    freezes = []
    for entry in CONFIG['additional_freezes']:
        path = pathlib.Path(entry['path'])
        data = raw(path)
        freeze = json.loads(data)
        check('nine_freezes', sha(data) == entry['sha256'], str(path))
        require(path, entry['sha256'], len(data))
        for row in freeze['files']:
            require(path.parent / row['path'], row['sha256'], row['bytes'])
            bind(path.parent / row['path'], row['sha256'], row['bytes'], 'nine_frozen_members')
        freezes.append({'path':str(path), 'sha256':sha(data), 'members':len(freeze['files'])})
    check('nine_freezes', len(freezes) == 9, 'all nine independent freezes')
    check('required_origins', set(required) == set(MANIFEST['required_payload_mapping']) and len(required) == 3045, 'independently reconstructed exact 3045 required origins')
    for path, identity in required.items():
        names = MANIFEST['required_payload_mapping'].get(path, [])
        check('required_origins', bool(names) and set(names) == set(ORIGINS.get(path, [])), path + ': complete original-to-member mapping')
        for name in names:
            actual = OBSERVED[name]
            check('required_origins', actual['sha256'] == identity['sha256'] and (identity['bytes'] is None or actual['bytes'] == identity['bytes']), path + ' -> ' + name)
    DETAILS['payload'] = {'all_members_read':len(OBSERVED), 'required_origins_independently_reconstructed':len(required), 'generic_required_members':2796, 'original_five_roots':root_counts, 'original_inventory_cache_entries_excluded':len(excluded), 'nine_freezes':freezes, 'denominators_not_equivalent':True}

    for item in CONFIG['readable_copies']:
        p = DELIVERY / item['name']
        check('readable_copies', file_hash(p) == OBSERVED[member_for(item['path'])]['sha256'], item['name'] + ': exact original archive bytes')
    parts_hash = hashlib.sha256()
    part_rows = []
    for item in ACCEPTANCE['parts']:
        name = item.get('name', item.get('path'))
        p = DELIVERY / pathlib.Path(name).name
        h = hashlib.sha256(); size = 0
        with p.open('rb') as f:
            while data := f.read(1024*1024):
                h.update(data); parts_hash.update(data); size += len(data)
        check('parts', size == item['bytes'] and h.hexdigest() == item['sha256'], p.name)
        part_rows.append({'name':p.name, 'bytes':size, 'sha256':h.hexdigest()})
    check('parts', len(part_rows) == 6 and parts_hash.hexdigest() == SHA and sum(x['bytes'] for x in part_rows) == 36421592, 'streamed portable concatenation matches original archive')
    DETAILS['parts'] = part_rows

    source_files = inventory(full['source_before'], full['source_after'], 'local_source')
    check('local_source', len(source_files) == 4005, '4005 tracked source files')
    check('local_source', full['external_inventory_before'] == full['external_inventory_after'] and len(full['external_inventory_before']) == 341, '341 stable external inputs')
    worktree = BASE / 'hepta-v8-efb210e-qualified'
    commit = subprocess.check_output(['git','cat-file','-p',SOURCE], cwd=worktree)
    check('git_source', b'tree '+TREE.encode()+b'\n' in commit and re.findall(rb'^parent ([0-9a-f]{40})$',commit,re.M) == [PARENT.encode()], 'actual immutable Git commit tree/parent')
    records = subprocess.check_output(['git','ls-tree','-rz','--full-tree',SOURCE],cwd=worktree).split(b'\0')
    blobs = {}
    for rec in records:
        if not rec: continue
        meta,name = rec.split(b'\t',1); mode,kind,oid = meta.split()
        check('git_source', kind == b'blob', name.decode()+': blob')
        blobs[name.decode()] = (mode.decode(),oid.decode())
    check('git_source', set(blobs) == set(source_files), 'full Git tree vs archived source inventory')
    for name, expected in source_files.items():
        p = worktree/name
        data = p.read_bytes()
        check('git_source', sha(data) == expected and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() == blobs[name][1], name)
    check('git_source', subprocess.check_output(['git','status','--porcelain'],cwd=worktree) == b'', 'immutable source still clean')
    publication = obj(BASE/'hia-round3-pilot-seal-publication.json')
    check('git_source', publication['source_commit'] == SOURCE and publication['source_tree'] == TREE and publication['source_parents'] == [PARENT], 'archived actual publication record')
    bundle = raw(BASE/'hia-round3-pilot-seal-published.bundle')
    check('git_source', sha(bundle) == publication['local_git_verification']['bundle_sha256'] and SOURCE.encode()+b' refs/heads/' in bundle[:2048], 'archived final published Git bundle')
    check('local_gates', full['ok'] and full['source_unchanged'] and full['external_inputs_unchanged'] and len(gates) == 7 and all(g['passed'] for g in gates.values()), 'seven actual local gates')
    pg = gates['full_regression']; py = python_footer(pg['execution']['stderr'],2980,'local_python',True)
    check('local_python', pg['execution']['returncode'] == 0 and pg['tests_run'] == 2980 and pg['errors'] == pg['failures'] == pg['skipped'] == 0, 'actual local exit/count/errors')
    rust = gates['rust_resource_crate']; text = rust['execution']['stdout']
    sections = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
    check('local_rust', rust['execution']['returncode'] == 0 and sum(int(v[0]) for v in sections) == 60 and all(all(int(n)==0 for n in v[1:]) for v in sections), 'actual 60 Rust tests and no ignored/failures')
    coverage = gates['merge_and_profile_coverage']
    check('local_gates', coverage['subsets_of_full_regression_only'] and not coverage['missing_modules'], 'critical coverage is subset')
    check('actual_acceptance', ACCEPTANCE['source_commit'] == SOURCE and ACCEPTANCE['source_tree'] == TREE and ACCEPTANCE['source_parents'] == [PARENT], 'actual acceptance source identity')
    check('actual_acceptance', ACCEPTANCE['full_qualification']['python_tests'] == 2980 and ACCEPTANCE['full_qualification']['rust_tests'] == 60, 'acceptance actual counts')
    DETAILS['local_actual'] = {'source_commit':SOURCE,'source_tree':TREE,'source_parent':PARENT,'tracked_git_blobs':len(blobs),'external_unchanged':341,'gates':[g['name'] for g in full['gates']],'python':py,'rust_tests':60,'critical_coverage_is_subset':True}

    for key in ('component_invocation','profile_invocation'):
        invocation = obj(CONFIG[key]); inventory(invocation['source_before'],invocation['source_after'],key)
        check(key, invocation['ok'] and invocation['source_unchanged'], 'same-source invocation completed')
        folder = pathlib.Path(CONFIG[key]).parent
        for c in invocation['commands']:
            check(key, c['returncode'] == c.get('expected_returncode',0), c['name']+': expected real exit')
            bind(folder/(c['name']+'.stdout.log'),c['stdout_sha256'],group=key)
            bind(folder/(c['name']+'.stderr.log'),c['stderr_sha256'],group=key)
            if c.get('result_path'):
                bind(c['result_path'],c['result_sha256'],group=key)
        check(key, len(invocation['commands']) == (10 if key=='component_invocation' else 4), 'exact command denominator')
    check('primary_audit', final['source_commit']==SOURCE and final['status']=='PASS_WITH_OBSERVATIONS' and not final['failed_checks'] and len(final['observations'])==2, 'original primary audit and explicit observations')
    check('primary_audit', ACCEPTANCE['audit_observations']==final['observations'], 'acceptance preserves original observations exactly')

    audit_ci_and_hosts(full, final)
    audit_negative_and_builds(gates)
    check('archive', file_hash(ARCHIVE)==SHA, 'archive unchanged at end')


def audit_ci_and_hosts(full, final):
    prefix = BASE/'hia-round3-source-ci/source-efb210e'
    for name, runid in [('full-40655694195',40655694195),('verified-40655694241',40655694241)]:
        r=obj(prefix/name/'api-run-final.json')
        check('remote_identity', r['id']==runid and r['head_sha']==SOURCE and r['event']=='push' and r['status']=='completed' and r['conclusion']=='success', name+': completed actual exact-source push')
    fullbase=prefix/'full-40655694195/artifact/selected/Hepta/Hepta/artifacts'
    release=obj(fullbase/'candidate/release-validation.json'); standalone=obj(fullbase/'hia-unified/qualification.json'); ndu=obj(fullbase/'hia-ndu/qualification.json')
    check('remote_full', release['source_git_commit']==SOURCE and release['snapshot_unchanged'] and release['status']=='passed' and len(release['gates'])==50 and all(g['status']=='passed' and g['exit_code']==0 for g in release['gates']), 'actual release 50 gates')
    check('remote_full', standalone['git_commit']==SOURCE and standalone['unchanged_source'] and standalone['ok'] and len(standalone['gates'])==35 and all(g['passed'] and g['returncode']==0 for g in standalone['gates']), 'actual standalone 35 gates')
    check('remote_full', ndu['source_revision']==SOURCE and ndu['source_revision_after']==SOURCE and ndu['source_unchanged'] and ndu['ok'] and len(ndu['gates'])==9 and all(g['passed'] for g in ndu['gates']), 'actual separate NDU 9 gates')
    check('remote_full', release['source_snapshot']==release['source_snapshot_after'], 'actual release source inventory before/after')
    check('remote_full', standalone['source_snapshot_before']==standalone['source_snapshot_after'], 'actual standalone source inventory before/after')
    check('remote_full', ndu['source_inventory_before']==ndu['source_inventory_after'], 'actual NDU source inventory before/after')
    rg=next(g for g in release['gates'] if g['name']=='unit_and_integration')
    release_log=raw(fullbase.parent/rg['log'])
    check('remote_full', sha(release_log)==rg['log_sha256'], 'release raw method log identity')
    rp=python_footer(release_log,2980,'remote_release_python',True)
    sg=next(g for g in standalone['gates'] if g['name']=='unit_regression')
    sl=raw(fullbase/'hia-unified'/sg['stderr']['path']); check('remote_full',sha(sl)==sg['stderr']['sha256'],'standalone raw unittest log identity')
    sp=python_footer(sl,2980,'remote_standalone_python')
    ng=next(g for g in ndu['gates'] if g['name']=='focused_regression'); np=python_footer(ng['execution']['stderr'],200,'remote_ndu_python')
    verifiedbase=prefix/'verified-40655694241/artifact/selected/Hepta/Hepta/artifacts/verified-optimization'
    selected=obj(verifiedbase/'regression/result.json'); vl=raw(verifiedbase/'regression/tests.log')
    check('remote_verified', selected['git_base']==SOURCE and selected['source_unchanged'] and selected['passed'] and selected['tests']==304 and selected['errors']==selected['failures']==selected['skipped']==0 and sha(vl)==selected['log_sha256'], 'actual verified selected report and raw log')
    vp=python_footer(vl,304,'remote_verified_python',True)
    check('remote_verified', len(selected['modules'])==33,'33 selected modules distinct denominator')
    check('remote_verified', 'test_upgrade_refuses_missing_kernel_seals_before_native_execution' in vl.decode() and 'test_actual_rust_counter_refuses_correct_entry_with_dead_provider' in vl.decode(), 'new refusal and formerly failing native control actually ran')
    host=obj(CONFIG['host_audit']); host_rows=[]
    check('remote_hosts',host['source_head']==SOURCE and host['source_tree']==TREE and host['push_run_id']==40655694204 and host['push_run_conclusion']=='success' and len(host['rows'])==7,'exact source seven-host primary push')
    for row in host['rows']:
        path=BASE/f"hia-round3-source-ci/source-efb210e-hosts/artifact-{row['artifact_id']}/selected/stb-divide-host/qualification.json"
        q=obj(path); bind(path,row['component_report_sha256'],group='remote_hosts')
        check('remote_hosts',q['ok'] and q['source_unchanged_during_run'] and q['source_before']==q['source_after'] and q['source_before']['commit']==SOURCE and q['source_before']['tree']==TREE,row['job']+': actual component raw source/result')
        check('remote_hosts',row['actual_component_passed'] and row['integrity_checks_passed'] and all(row['checks'].values()),row['job']+': independent selected member/source checks')
        check('remote_hosts',len(q['variants'])==2 and q['claims']['cpp_migration'] is False and q['claims']['performance_or_migration_cost_improvement_proved'] is False,row['job']+': finite component scope')
        host_rows.append({'job':row['job'],'artifact_id':row['artifact_id'],'report_member':member_for(path),'report_sha256':OBSERVED[member_for(path)]['sha256']})
    check('actual_acceptance',ACCEPTANCE['actual_hosts']['passed']==7 and ACCEPTANCE['actual_hosts']['failed']==0,'acceptance seven actual hosts')
    DETAILS['remote_actual']={'primary_push_runs':{'full':40655694195,'verified':40655694241,'hosts':40655694204},'source':SOURCE,'full_gates':{'release':50,'standalone':35,'ndu':9},'separate_test_invocations':{'release':rp,'standalone':sp,'ndu':np,'verified_selected':vp},'denominators_never_added':True,'selected_remote_worktree_untracked_paths_retained':selected['git_worktree_status'],'hosts':host_rows}


def audit_negative_and_builds(gates):
    result=obj(CONFIG['ndu_result']); episodes=result['episodes']
    check('formal_negative',result['source_head']==NDU_SOURCE and result['completed'] and result['incremental_ndu_condition_met'] is False and len(episodes)==48,'unchanged separate formal 8b experiment identity and negative result')
    check('formal_negative',all(e['selected_id']=='abstain' and e['publication'] is None for e in episodes),'all 48 actually abstained and retained baseline, no publication')
    for arm,row in result['table'].items():
        es=[e for e in episodes if e['arm']==arm]
        check('formal_negative',len(es)==6 and row['episodes']==6 and row['completed']==6,'six complete episodes '+arm)
        for cost in ('warm_deployment_ns','cold_deployment_ns','same_information_cold_ns'):
            check('formal_negative',sum(e[cost] for e in es)==row[cost]['sum'],arm+' '+cost+' actual episode sum')
    n=result['table']['ndu']; baseline=result['table']['fixed_stop']['warm_deployment_ns']['sum']
    check('formal_negative',baseline==2715459131 and n['warm_deployment_ns']['sum']==3637279312 and n['cold_deployment_ns']['sum']==24873339562,'original deployment cost sums')
    check('formal_negative',baseline-n['warm_deployment_ns']['sum']==-921820181 and baseline-n['cold_deployment_ns']['sum']==-22157880431,'independently recomputed negative actual deployment savings')
    check('formal_negative',ACCEPTANCE['ndu']['source_commit']==NDU_SOURCE and ACCEPTANCE['ndu']['episodes']==48 and ACCEPTANCE['ndu']['publications']==0 and ACCEPTANCE['ndu']['incremental_value_established'] is False,'acceptance preserves separate formal negative result')
    for field in ('six_stages_closed','whole_language_soundness_proved','global_optimality_established','universal_rust_performance_advantage','general_live_owner_loan_stack_migration','performance_cost_or_general_cpp_migration_proved'):
        check('scope_limits',ACCEPTANCE[field] is False,field)
    old=BASE/'hia-round3-qualified-739e84a/full_regression-execution.json'
    failed=obj(old); log=failed['execution']['stderr']
    check('historical_failure',failed['tests_run']==2979 and failed['errors']==1 and failed['failures']==0 and failed['skipped']==0 and failed['passed'] is False and 'F_SEAL_WRITE' in log and 'AttributeError' in log,'prior739 real failure retained without relabelling')
    ci=BASE/'hia-round3-source-ci/source-efb210e/verified-40655694241/artifact/selected/Hepta/Hepta/artifacts/verified-optimization/ndu-loop/RESULT.json'
    cr=obj(ci)
    check('separate_ci_negative',len(cr['episodes'])==30 and cr['ndu_descriptive_cost_lower_than_light'] is False and cr['ndu_descriptive_cost_lower_than_selected_fixed'] is False and cr['statistical_superiority_established'] is False,'CI30 remains separate negative')
    byhash=collections.defaultdict(list)
    for name,row in OBSERVED.items():byhash[row['sha256']].append(name)
    builds=[]
    for profile,pin,version in [('recursive','2590c0c94c5bf9a9004caeeb7b75edd6faf3eb8b','1.90.0'),('finite','4b6391e116949af0c7e59776baead67271856bdb','1.95.0')]:
        g=gates[profile+'_bridge_identity']; r=obj(g['receipt'])
        check('native_builds',g['identity']['source_commit']==pin and version in g['identity']['rustc'] and r['identity']==g['identity'],'separate actual '+profile+' pin/tool protocol')
        bind(g['receipt'],g['receipt_sha256'],group='native_builds');bind(g['binary'],g['binary_sha256'],group='native_builds')
        inputs=g['native_sources']|g['bridge_sources']; absent={p:s for p,s in inputs.items() if s not in byhash}
        builds.append({'profile':profile,'pin':pin,'rustc':g['identity']['rustc'],'binary_sha256':g['binary_sha256'],'input_files':len(inputs),'input_bytes_found_in_archive_by_sha256':len(inputs)-len(absent),'missing_raw_archive_inputs':absent})
    supplemental=load(DELIVERY/'supplemental-source.json')
    supplemental_data=(DELIVERY/supplemental['delivery_file']).read_bytes()
    check('supplemental_source',file_hash(DELIVERY/'supplemental-source.json')=='f5c1553fdf337c90c85154ad22510d066569f98b313d00e2b0cee76ac0c1f6af','frozen supplemental receipt')
    check('supplemental_source',supplemental['source_commit']=='4b6391e116949af0c7e59776baead67271856bdb' and supplemental['source_path']=='tools/hia-ndu-bridge/src/protocol_tests.rs' and supplemental['archive_sha256_unchanged']==SHA,'supplementary input identity and unchanged archive scope')
    check('supplemental_source',sha(supplemental_data)==supplemental['sha256']=='7ef966a7c757add2915468b02d0dcb58d7ed71bc3980c1308dd1e00416828f28' and len(supplemental_data)==supplemental['bytes']==5010 and hashlib.sha1(b'blob '+str(len(supplemental_data)).encode()+b'\0'+supplemental_data).hexdigest()==supplemental['git_blob'],'actual supplementary bytes/Git blob')
    check('supplemental_source',builds[0]['input_bytes_found_in_archive_by_sha256']==92 and builds[1]['input_bytes_found_in_archive_by_sha256']==92 and list(builds[1]['missing_raw_archive_inputs'].values())==[sha(supplemental_data)],'raw archive 92/93 plus exactly one separate supplemental file')
    for license in supplemental['license_and_notice']:
        for name in license['existing_archive_members']:
            check('supplemental_source',OBSERVED[name]['sha256']==license['sha256'] and OBSERVED[name]['bytes']==license['bytes'],'actual license/notice bytes '+name)
    DETAILS['supplemental_source']={'receipt_sha256':file_hash(DELIVERY/'supplemental-source.json'),'separate_file':supplemental['delivery_file'],'sha256':sha(supplemental_data),'bytes':len(supplemental_data),'raw_archive_member_count_unchanged':5602,'finite_input_bytes_available_archive_plus_supplement':93,'raw_archive_alone_is_not_claimed_to_contain_all_93':True,'license_and_notice_in_archive':supplemental['license_and_notice']}
    DETAILS['formal_ndu']={'source':NDU_SOURCE,'episodes':48,'publications':0,'baseline_sum_ns':baseline,'ndu_warm_sum_ns':n['warm_deployment_ns']['sum'],'ndu_cold_sum_ns':n['cold_deployment_ns']['sum'],'warm_net_saving_ns':-921820181,'cold_net_saving_ns':-22157880431,'incremental_condition_met':False,'ci30_separate':True,'all_generic_negative_assertions_preserved':all(r['passed'] for r in GENERIC['negative_result_assertions'])}
    DETAILS['native_builds']=builds


if __name__ == '__main__':
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        main()
    except Exception as error:
        FAILURES.append({'group':'audit_script_exception','detail':type(error).__name__+': '+str(error)})
        import traceback
        traceback.print_exc()
    report={'schema':'hepta.reconciled.archive-actual-acceptance-independent-audit.v1','status':'PASS_WITH_SCOPE_LIMITS' if not FAILURES else 'FAIL','started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Read archive bytes and raw records, independently rebuild required-origin union, inspect actual immutable Git blobs, reparse raw test outcomes and costs; no test/compiler/solver/native execution.','archive':{'path':str(ARCHIVE),'sha256':SHA,'bytes':36421592},'expected_release_source':SOURCE,'source_expected_is_not_treated_as_proof':True,'checks':dict(COUNTS),'checks_total':sum(COUNTS.values()),'failed_checks':FAILURES,'details':DETAILS,'input_manifests':{str(p):file_hash(p) for p in [OUT/'ARCHIVE-AUDIT.json',OUT/'ARCHIVE-PATH-MAPPING.json',BASE/'hia-round3-reconciled-package-config.json',DELIVERY/'raw-evidence-manifest.json',DELIVERY/'acceptance.json']},'auditor_sha256':file_hash(__file__),'scope_limits':['Read-only archive integrity and evidence reconciliation, not a new execution or language-soundness proof.','Full, selected and focused test invocations remain separate; critical methods are subsets.','Historical formal 8b48 and current CI30 are never merged or relabelled.','Raw archive finite4b includes 92/93 source-input byte identities; one separately bound supplemental source file completes the 93-input byte set without changing the archive.','The primary audit\'s two explicit resource receipt observations remain unchanged.']}
    path=OUT/'ACTUAL-ACCEPTANCE-AUDIT.json'
    if path.exists():
        raise SystemExit('refuse to overwrite an audit; preserve prior attempt explicitly first')
    path.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':report['status'],'checks':report['checks_total'],'failures':FAILURES,'output':str(path),'sha256':file_hash(path)},sort_keys=True))
    raise SystemExit(bool(FAILURES))
