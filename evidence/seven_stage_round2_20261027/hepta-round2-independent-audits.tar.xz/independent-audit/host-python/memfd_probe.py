"""Independent finite seal capability probe; no compiler/native DSO execution."""
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys

NAMES = ("F_ADD_SEALS", "F_GET_SEALS", "F_SEAL_WRITE", "F_SEAL_GROW", "F_SEAL_SHRINK", "F_SEAL_SEAL")
binary = Path(sys.executable).resolve()
with binary.open("rb") as stream:
    binary_sha256 = hashlib.file_digest(stream, "sha256").hexdigest()
report = {"python": {"executable": sys.executable, "resolved_executable": str(binary),
                      "binary_sha256": binary_sha256, "version": sys.version,
                      "fcntl_origin": fcntl.__spec__.origin},
          "constants": {name: getattr(fcntl, name, None) for name in NAMES},
          "has_memfd_create": hasattr(os, "memfd_create"),
          "numeric_constant_fallback_used": False, "native_dso_executed": False,
          "observations": [], "ok": False}
missing = [name for name in NAMES if not hasattr(fcntl, name)]
descriptor = None
try:
    if missing:
        report.update(status="required_python_api_absent", missing_constants=missing)
    else:
        payload = b"hepta-independent-sealed-snapshot-probe\n"
        descriptor = os.memfd_create("hepta-independent-seal-audit", os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING)
        count = os.write(descriptor, payload)
        requested = fcntl.F_SEAL_WRITE | fcntl.F_SEAL_GROW | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_SEAL
        fcntl.fcntl(descriptor, fcntl.F_ADD_SEALS, requested)
        obtained = fcntl.fcntl(descriptor, fcntl.F_GET_SEALS)
        report.update(bytes_written=count, requested_seals=requested, observed_seals=obtained,
                      descriptor_cloexec=bool(fcntl.fcntl(descriptor, fcntl.F_GETFD) & fcntl.FD_CLOEXEC))
        for name, operation in (("overwrite", lambda: os.pwrite(descriptor, b"X", 0)),
                                ("shrink", lambda: os.ftruncate(descriptor, len(payload) - 1)),
                                ("grow", lambda: os.ftruncate(descriptor, len(payload) + 1)),
                                ("change_seals", lambda: fcntl.fcntl(descriptor, fcntl.F_ADD_SEALS, 0))):
            row = {"operation": name, "denied": False}
            try:
                row["returned"] = operation()
            except OSError as exc:
                row.update(denied=True, errno=exc.errno, error=str(exc))
            report["observations"].append(row)
        actual = os.pread(descriptor, len(payload) + 1, 0)
        report["snapshot_preserved"] = actual == payload and os.fstat(descriptor).st_size == len(payload)
        report["ok"] = (count == len(payload) and obtained & requested == requested
                        and report["descriptor_cloexec"] and report["snapshot_preserved"]
                        and all(row["denied"] and row["errno"] == errno.EPERM for row in report["observations"]))
        report["status"] = "actual_kernel_seal_behavior_passed" if report["ok"] else "actual_kernel_seal_behavior_failed"
except Exception as exc:
    report.update(status="probe_failed", error={"type": type(exc).__name__, "message": str(exc)})
finally:
    if descriptor is not None:
        os.close(descriptor)
print(json.dumps(report, indent=2, sort_keys=True))
