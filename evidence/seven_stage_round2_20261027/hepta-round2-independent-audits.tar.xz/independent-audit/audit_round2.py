#!/usr/bin/env python3
"""Read-only retained evidence audit. Never executes compilers, models or candidates.

This verifies record/byte/count consistency under a trusted local producer and
filesystem. It is not independent execution attestation or a soundness proof.
"""
import argparse
import base64
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import subprocess

SOURCE = "806110df3ef57a388d593ac454e3011724a802e3"
TREE = "01bb1f2db323db7f79a7a6c1636319207515481d"
GATES = ["unit_regression", "standalone_native", "standalone_resources",
         "composite_resources", "composite_bulk_targets", "recursive_resource_chains",
         "source_migration", "cpp_template_migration", "c_configuration_matrix",
         "cpp_configuration_matrix", "upstream_c_resource_matrix",
         "upstream_cpp_composed_lifetimes", "selected_core_formal",
         "standalone_aarch64_qemu", "standalone_riscv64_qemu", "legacy_executable_core",
         "legacy_hosted_composition", "legacy_cortex_m4_qemu", "standalone_performance"]
ARMS = ["hia_full_context", "hia_edit_query", "rust_full_context", "rust_edit_query"]
SCORED = {"correct", "observable_wrong", "expected_overflow_trap", "response_rejected"}
checks, failures, findings = [], [], {}

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()

def digest(b):
    return hashlib.sha256(b).hexdigest()

def sha_file(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def check(name, value, detail=None):
    ok = value is True
    checks.append({"check": name, "ok": ok})
    if not ok:
        failures.append({"check": name, "detail": detail})

def exact(a, b):
    return canonical(a) == canonical(b)

def file_claim(name, path, claim):
    path = Path(path)
    check(name + ":regular", path.is_file() and not path.is_symlink())
    if path.is_file():
        if type(claim) is dict:
            check(name + ":sha256", sha_file(path) == claim["sha256"])
            if "bytes" in claim:
                check(name + ":bytes", path.stat().st_size == claim["bytes"])
        else:
            check(name + ":sha256", sha_file(path) == claim)

def git(repo, *args, data=None):
    return subprocess.run(["git", "-C", str(repo), *args], input=data,
                          capture_output=True, check=True).stdout

def committed_file_hashes(repo, commit, wanted):
    entries = {}
    for raw in git(repo, "ls-tree", "-rz", "--full-tree", commit).split(b"\0"):
        if not raw:
            continue
        header, path = raw.split(b"\t", 1)
        _, kind, oid = header.split()
        name = path.decode()
        if name in wanted and kind == b"blob":
            entries[name] = oid.decode()
    names = sorted(entries)
    stream = git(repo, "cat-file", "--batch", data="".join(entries[n] + "\n" for n in names).encode())
    position, result = 0, {}
    for name in names:
        end = stream.index(b"\n", position)
        oid, kind, length = stream[position:end].split()
        assert oid.decode() == entries[name] and kind == b"blob"
        length = int(length)
        position = end + 1
        result[name] = digest(stream[position:position + length])
        position += length + 1
    assert position == len(stream)
    return result

def audit_unified(path, repo):
    report, plan = read(path / "qualification.json"), read(path / "plan.json")
    check("unified:commit", report["git_commit"] == plan["git_commit"] == SOURCE)
    check("unified:tree", git(repo, "rev-parse", SOURCE + "^{tree}").decode().strip() == TREE)
    check("unified:nineteen_planned_gates", report["planned_gates"] == GATES)
    check("unified:nineteen_commands", [c["name"] for c in plan["commands"]] == GATES)
    check("unified:gate_order", [g["name"] for g in report["gates"]] == GATES)
    before, after = report["source_snapshot_before"], report["source_snapshot_after"]
    check("unified:source_snapshot_digest", before["sha256"] == digest(canonical(before["files"])))
    check("unified:source_snapshot_plan", before["sha256"] == plan["source_snapshot_sha256"])
    check("unified:source_claim_consistent", report["unchanged_source"] is exact(before, after))
    expected = committed_file_hashes(repo, SOURCE, before["files"])
    check("unified:all_source_bytes_match_commit", expected == before["files"],
          {"committed": len(expected), "snapshotted": len(before["files"])})
    for row, cmd in zip(report["gates"], plan["commands"]):
        name = row["name"]
        check("unified:" + name + ":argv", row["argv"] == cmd["argv"])
        for channel in ("stdout", "stderr"):
            file_claim("unified:" + name + ":" + channel, path / row[channel]["path"], row[channel])
        if name == "unit_regression":
            text = (path / row["stderr"]["path"]).read_text()
            m = re.search(r"(?m)^Ran (\d+) tests? in [0-9.]+s\s+(OK|FAILED)(?: \(([^\n]*)\))?\s*\Z", text)
            check("unified:unit_terminal_summary", m is not None)
            if m:
                counts = {"tests_run": int(m[1]), "skipped": 0, "failures": 0, "errors": 0}
                for item in (m[3] or "").split(", "):
                    if item:
                        k, n = item.split("="); counts[k] = int(n)
                check("unified:unit_counts", all(row.get(k) == v for k, v in counts.items()))
                passed = row["returncode"] == 0 and m[2] == "OK" and counts["tests_run"] > 0 and all(counts[k] == 0 for k in ("skipped", "failures", "errors"))
                check("unified:unit_pass_consistency", row["passed"] is passed)
                findings["unit_regression"] = counts
        elif "evidence" in row:
            claim = row["evidence"]
            file_claim("unified:" + name + ":evidence", path / claim["path"], claim)
            payload = read(path / claim["path"])
            passed = row["returncode"] == 0 and (payload.get("ok") is True or name == "legacy_cortex_m4_qemu" and payload.get("status") == "passed")
            check("unified:" + name + ":pass_consistency", row["passed"] is passed)
            check("unified:" + name + ":reported_payload_status", exact(claim["status"], payload.get("status")))
            check("unified:" + name + ":reported_payload_ok", exact(claim["ok"], payload.get("ok")))
        else:
            check("unified:" + name + ":missing_evidence_failed", row["passed"] is False)
    passed = sum(row["passed"] for row in report["gates"])
    check("unified:gate_counts", report["passed_gates"] == passed and report["completed_gates"] == len(report["gates"]))
    check("unified:overall_ok", report["ok"] is (report["unchanged_source"] and len(report["gates"]) == len(GATES) and passed == len(GATES)))
    check("unified:no_full_seven_claim", report["full_seven_deliverables_complete"] is False)
    findings["unified"] = {"source": SOURCE, "passed": passed, "completed": len(report["gates"]),
                          "failed": [r["name"] for r in report["gates"] if not r["passed"]], "status": report["status"]}
    return report

def chain_expected(function, n, mode, refused):
    # Stepwise independent ledger: one payload then one 24-byte header.
    attempts = nodes = payloads = peak = 0
    bytes_owned = 0
    failure = False
    count = n + 1 if function == "chain_recover" else n
    for index in range(count):
        if function != "chain_empty_payloads":
            attempts += 1
            if attempts == refused:
                failure = True; break
            payloads += 1; bytes_owned += 1; peak = max(peak, bytes_owned)
        attempts += 1
        if attempts == refused:
            failure = True; break
        nodes += 1; bytes_owned += 24; peak = max(peak, bytes_owned)
    total = sum(i % 256 for i in range(nodes))
    if function == "chain_checksum":
        result = total + int(failure) * 1000000
    elif function in {"chain_cancel", "chain_empty_payloads"}:
        result = int(not failure)
    elif function in {"chain_head_update", "chain_stored_loan"}:
        result = (total - (nodes - 1) % 256 + (255 if function == "chain_head_update" else 99)) if nodes else 0
    elif function == "chain_task":
        result = 1000000 if failure else 3000000 if mode == 0 else 2000000 if mode == 1 and nodes else total
    elif function == "chain_recover":
        result = sum(i % 256 for i in range(n)) + 73 + int(failure) * 1000000
    elif function == "chain_empty_pop":
        result = 0
    else:
        raise ValueError(function)
    return {"result": result, "attempts": attempts, "allocations": nodes + payloads, "frees": nodes + payloads,
            "node_allocations": nodes, "payload_allocations": payloads, "node_frees": nodes, "payload_frees": payloads,
            "live_bytes": 0, "peak_bytes": peak, "null_frees": 0, "bad_frees": 0, "unknown_sizes": 0}

def audit_chain(path):
    r, p = read(path / "qualification.json"), read(path / "plan.json")
    return_types = {function["name"]: function["returns"]
                    for filename in ("core_v7.core.json", "composite_v2.core.json")
                    for function in read(path / filename)["functions"]}
    check("chain:source", r["git_commit"] == SOURCE == p["source_commit"])
    check("chain:clean_frozen_source", r["git_worktree_dirty"] is False and r["source_unchanged"] is True)
    check("chain:324_cases", r["planned_cases"] == r["executed_cases"] == len(r["cases"]) == len(p["cases"]) == 324)
    for i, (row, entry) in enumerate(zip(r["cases"], p["cases"])):
        name, n, mode, refused = entry
        check(f"chain:{i}:plan", [row[k] for k in ("function", "n", "mode", "fail_at")] == entry)
        expected = chain_expected(name, n, mode, refused)
        check(f"chain:{i}:stepwise_oracle", exact(row["expected"], expected))
        check(f"chain:{i}:native", exact(row["native"], expected))
        vm, ledger = row["vm"], row["vm"]["resources"]
        boolean = return_types[name] == ["bool"]
        check(f"chain:{i}:vm_result_type", type(vm["result"]) is (bool if boolean else int))
        # The native observation driver prints scalar bool ABI results as 0/1.
        # Keep the VM's typed boolean check separate from that transport map.
        mapped = {"result": int(vm["result"]) if boolean else vm["result"], "attempts": ledger["allocation_attempts"], "allocations": ledger["allocations"],
                  "frees": ledger["frees"], "node_allocations": ledger["chain_nodes_created"],
                  "payload_allocations": ledger["allocations"] - ledger["chain_nodes_created"],
                  "node_frees": ledger["chain_nodes_dropped"], "payload_frees": ledger["frees"] - ledger["chain_nodes_dropped"],
                  "live_bytes": ledger["live_bytes"], "peak_bytes": ledger["peak_bytes"], "null_frees": 0, "bad_frees": 0, "unknown_sizes": 0}
        check(f"chain:{i}:vm", exact(mapped, expected))
    for name, claim in r["artifacts"].items():
        file_claim("chain:artifact:" + name, path / name, claim)
    check("chain:three_detected_negatives", len(r["negative_controls"]) == 3 and all(x["detected"] for x in r["negative_controls"]))
    for flag in ("all_recursive_adts_supported", "whole_language_soundness_proved", "backend_refinement_proved", "physical_device_evidence"):
        check("chain:scope:" + flag, r["claims"][flag] is False)
    findings["recursive_chain"] = {"cases": len(r["cases"]), "passed": r["cases_passed"], "max_nodes": r["claims"]["maximum_successful_tested_nodes"]}

def audit_performance(path):
    report = read(path)
    protocol, rows = report["protocol"], report["raw_samples"]
    check("performance:source", report["git_commit"] == SOURCE)
    check("performance:protocol_identity", protocol["id"] == "hepta.hia.program.perf.v3" and report["protocol_sha256"] == digest(canonical(protocol)))
    check("performance:frozen_thresholds", protocol["paired_groups"] == 7 and protocol["minimum_sample_seconds"] == .05 and protocol["maximum_sample_seconds"] == 30.0 and protocol["maximum_relative_mad"] == .05 and protocol["maximum_geometric_mean_paired_time_ratio"] == 1.10 and protocol["maximum_kernel_paired_time_ratio"] == 1.20)
    if report.get("phase") != "complete":
        check("performance:incomplete_not_passed", report["ok"] is False)
        findings["performance"] = {"phase": report["phase"], "status": report["status"], "retained_samples": len(rows)}
        return
    kernels = ["full_lifecycle", "constructor_error", "two_stage"]
    backends = ["rust", "llvm", "handwritten_rust"]
    schedule = []
    for group in range(7):
        for k in range(3):
            kernel = kernels[(group + k) % 3]
            shift = (group + kernels.index(kernel)) % 3
            selected = backends[shift:] + backends[:shift]
            if group % 2:
                selected.reverse()
            schedule += [(group, kernel, b) for b in selected]
    check("performance:63_complete_samples", len(rows) == len(schedule) == 63)
    for i, (row, selected) in enumerate(zip(rows, schedule)):
        check(f"performance:{i}:fixed_order", [row[k] for k in ("group", "kernel", "backend", "sample_index")] == [*selected, i])
        raw = json.loads(row["execution"]["stdout"])
        check(f"performance:{i}:native_stdout", all(exact(row[k], v) for k, v in raw.items()))
        check(f"performance:{i}:successful_native", row["execution"]["returncode"] == 0 and type(row["elapsed_ns"]) is int and row["elapsed_ns"] > 0)
    quality, thresholds, ratios = [], [], {}
    for kernel in kernels:
        for backend in backends:
            values = [r["elapsed_ns"] for r in rows if r["kernel"] == kernel and r["backend"] == backend]
            middle = statistics.median(values)
            mad = statistics.median(abs(n - middle) for n in values) / middle
            summary = report["evaluation"]["summary"][kernel]["implementations"][backend]
            check("performance:" + kernel + ":" + backend + ":samples", values == summary["samples_ns"])
            check("performance:" + kernel + ":" + backend + ":stats", summary["median_ns"] == middle and summary["relative_mad"] == mad)
            if min(values) < 50_000_000: quality.append(kernel + "/" + backend + ": sample shorter than fixed minimum")
            if max(values) > 30_000_000_000: quality.append(kernel + "/" + backend + ": sample longer than fixed maximum")
            if mad > .05: quality.append(kernel + "/" + backend + ": relative MAD above fixed maximum")
        for baseline in ("rust", "handwritten_rust"):
            pairs = []
            for group in range(7):
                values = {r["backend"]: r["elapsed_ns"] for r in rows if r["kernel"] == kernel and r["group"] == group}
                pairs.append(values["llvm"] / values[baseline])
            ratio = statistics.median(pairs); ratios[(kernel, baseline)] = ratio
            summary = report["evaluation"]["summary"][kernel]["comparisons"][baseline]
            check("performance:" + kernel + ":" + baseline + ":paired_ratios", summary == {"paired_time_ratios": pairs, "median_paired_time_ratio": ratio})
            if ratio > 1.20: thresholds.append(kernel + "/" + baseline + ": paired ratio exceeds fixed maximum")
    geometric = {b: math.exp(statistics.mean(math.log(ratios[(k, b)]) for k in kernels)) for b in ("rust", "handwritten_rust")}
    for baseline, ratio in geometric.items():
        if ratio > 1.10: thresholds.append(baseline + ": geometric mean exceeds fixed maximum")
    expected_status = "measurement_inconclusive" if quality else "performance_failed" if thresholds else "passed"
    evaluation = report["evaluation"]
    check("performance:geometric_ratios", geometric == evaluation["geometric_mean_paired_time_ratios"])
    check("performance:quality_failures", quality == evaluation["measurement_quality_failures"])
    check("performance:threshold_failures", thresholds == evaluation["performance_threshold_failures"])
    check("performance:status", report["status"] == evaluation["status"] == expected_status and report["ok"] is (expected_status == "passed"))
    check("performance:no_discarded_samples", report["interference_observations"]["samples_excluded"] == 0 and report["interference_observations"]["acceptance_thresholds_adjusted"] is False)
    findings["performance"] = {"status": expected_status, "retained_samples": len(rows), "ratios": geometric, "quality_failures": quality, "performance_failures": thresholds}

def task_expected(task):
    def part(name, x, y):
        if name == "capacity": return int(x < y)
        if name == "ceil_half": return x // 2 + x % 2
        if name == "low_byte": return x % 256
        if name == "xor_tag": return x ^ y
        if name == "distance": return (x - y) % (1 << 32)
        if name == "next_epoch": return (x + 1) % (1 << 32)
        if name == "triple": return (x + x + x) % (1 << 32)
        if name == "minimum": return x if x < y else y
        raise ValueError(name)
    a, b = [p["id"] for p in task["parts"]]
    return [(part(a, x, y) * 31 + part(b, x, y)) % (1 << 32) for x, y in task["cases"]]

def audit_native(name, result, expected):
    check(name + ":expected", exact(result["expected"], expected))
    if "artifact" in result:
        file_claim(name + ":artifact", result["artifact"]["path"], result["artifact"])
    if result["status"] in {"correct", "observable_wrong"}:
        values = result["actual"]
        lines = ["STUDY_READY"]
        for i, value in enumerate(values):
            lines.extend([f"STUDY_CALL {i}", f"STUDY_VALUE {i} {value}"])
        lines.append("STUDY_DONE")
        check(name + ":raw_execution", result["returncode"] == 0 and result["stdout"].splitlines() == lines and len(values) == len(expected))
        check(name + ":scoring", result["ok"] is (values == expected) and result["native_executed"] is True)
    elif result["status"] == "expected_overflow_trap":
        check(name + ":trap_not_success", result["ok"] is False and result["native_executed"] is True)
        check(name + ":trap_code", result["returncode"] in (-6, 101))

def parsed_response(task, arm, text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    if type(text) is not str or len(text.encode()) > 65536:
        raise ValueError("response size/type")
    value = json.loads(text, object_pairs_hook=unique,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    if type(value) is not dict or set(value) != {"edits"} or type(value["edits"]) is not list or len(value["edits"]) != 2:
        raise ValueError("response envelope")
    selected = {}
    for entry in value["edits"]:
        if type(entry) is not dict or set(entry) != {"site", "changes"} or type(entry["site"]) is not int or entry["site"] not in (0, 1) or entry["site"] in selected:
            raise ValueError("site identity")
        part = task["parts"][entry["site"]]
        field = part["field"] if arm.startswith("hia") else "replacement"
        if type(entry["changes"]) is not dict or set(entry["changes"]) != {field}:
            raise ValueError("changed field")
        change = entry["changes"][field]
        allowed = part["allowed"] if arm.startswith("hia") else part["rust_allowed"]
        if not any(exact(change, option) for option in allowed):
            raise ValueError("closed alternatives")
        selected[entry["site"]] = change
    return selected

def audit_response_candidate(label, task, row, response, directory):
    try:
        changes = parsed_response(task, row["arm"], response["text"])
        admitted = True
    except (ValueError, TypeError, KeyError):
        admitted = False
    check(label + ":response_admission", row["accepted"] is admitted)
    if not admitted or not row["accepted"]:
        return
    if row["arm"].startswith("hia"):
        candidate = copy.deepcopy(task["hia"])
        for site, change in changes.items():
            name = "part_" + str(site)
            part = task["parts"][site]
            matches = [op for fn in candidate["functions"] if fn["name"] == name
                       for block in fn["blocks"] if block["id"] == "entry"
                       for op in block["ops"] if any(x["name"] == part["output"] for x in op["out"])]
            if len(matches) != 1:
                raise ValueError("independent HIA edit mapping is not unique")
            matches[0][part["field"]] = change
        check(label + ":actual_hia_candidate_from_response", exact(candidate, read(directory / "program.json")))
    else:
        for site, change in changes.items():
            source = task["parts"][site]["rust_template"].replace("pub fn kernel(", "pub fn part_" + str(site) + "(").replace("@SLOT@", change)
            check(label + ":actual_rust_candidate_from_response:" + str(site), (directory / ("part_" + str(site) + ".rs")).read_text() == source)

def audit_study(path, repo):
    r, p = read(path / "report.json"), read(path / "plan.json")
    body = dict(p); claimed = body.pop("plan_sha256")
    check("study:plan_digest", digest(canonical(body)) == claimed == r["plan_sha256"])
    check("study:source", p["git_commit"] == r["git_commit"] == SOURCE and p["source_was_committed"] is True)
    check("study:source_bindings", committed_file_hashes(repo, SOURCE, p["source_bindings"]) == p["source_bindings"])
    check("study:source_unchanged", r["source_unchanged"] is True)
    check("study:toolchain_unchanged", r["toolchain_unchanged"] is True and all(exact(r["final_tool_identities"][key], p[key]) for key in ("runtime", "clang", "rustc")))
    for key in ("runtime", "clang", "rustc"):
        file_claim("study:final_tool:" + key, r["final_tool_identities"][key]["path"], r["final_tool_identities"][key])
    check("study:task_denominator", len(p["tasks"]) == 4 and p["scheduled_task_requests"] == 32 and p["scheduled_preflights"] == 4)
    check("study:model_families", len(p["models"]) == 2 and len({x["family"] for x in p["models"]}) == 2)
    frozen_lock = json.loads(git(repo, "show", SOURCE + ":experiments/hia_atomic_maintenance_20261027/models.lock.json"))
    check("study:committed_model_lock", exact(p["models"], frozen_lock["models"]))
    check("study:generic_decoder_only", p["decoder"] == {"json_schema": {"type": "object"}, "answer_fields_constrained": False})
    expected = {t["id"]: task_expected(t) for t in p["tasks"]}
    for task in p["tasks"]:
        check("study:oracle:" + task["id"], task["expected"] == expected[task["id"]] and len(task["cases"]) == 13)
    controls = read(path / "controls.json")
    check("study:32_controls", len(controls) == r["native_controls"] == 32)
    counter = Counter()
    for row in controls:
        task, language, mask = row["id"].rsplit("_", 2)
        mask = int(mask.removeprefix("mask")); counter[(task, language, mask)] += 1
        result = row["result"]
        audit_native("study:control:" + row["id"], result, expected[task])
        passed = result["native_executed"] is True and (result["status"] == "correct" if mask == 3 else result["status"] in {"observable_wrong", "expected_overflow_trap"})
        check("study:control:" + row["id"] + ":passed", row["passed"] is passed)
    check("study:complete_control_product", counter == Counter({(task, lang, mask): 1 for task in expected for lang in ("hia", "rust") for mask in range(4)}))
    check("study:control_pass_count", r["native_controls_passed"] == sum(x["passed"] for x in controls))
    total_requests = total_responses = total_tokens = preflight_tokens = task_tokens = 0
    model_findings = []
    for index, report in enumerate(r["models"]):
        name, summary = report["model"]["id"], report["summary"]
        folder = path / name
        check("study:" + name + ":report_copy", exact(read(folder / "report.json"), report))
        check("study:" + name + ":lock", exact(report["model"], p["models"][index]))
        identity_path = folder / "engine/identity.json"
        if identity_path.exists():
            identity, after = read(identity_path), read(folder / "engine/identity-after.json")
            check("study:" + name + ":runtime_context", identity["threads"] == 4 and identity["context"] == 8192 and identity["decoder"]["json_schema"] == {"type": "object"})
            check("study:" + name + ":runtime_lock", identity["model"]["sha256"] == report["model"]["sha256"] and identity["model"]["bytes"] == report["model"]["bytes"])
            check("study:" + name + ":final_runtime_identity", after["model_unchanged"] is True and after["runtime_unchanged"] is True and exact(identity["model"], after["model"]) and exact(identity["runtime_files"], after["runtime_files"]))
            file_claim("study:" + name + ":actual_model_bytes", identity["model"]["path"], identity["model"])
            for runtime_file in identity["runtime_files"]:
                file_claim("study:" + name + ":actual_runtime_bytes:" + runtime_file["path"], runtime_file["path"], runtime_file)
        requests = sorted((folder / "engine").glob("transport-*.request.json"))
        responses = sorted((folder / "engine").glob("transport-*.response.json"))
        check("study:" + name + ":actual_requests", len(requests) == report["requests_started"])
        check("study:" + name + ":actual_responses", len(responses) == report["responses_received"])
        check("study:" + name + ":unresolved", report["unresolved_requests"] == len(requests) - len(responses))
        total_requests += len(requests); total_responses += len(responses)
        for i, request in enumerate(requests, 1):
            check("study:" + name + f":request_sequence:{i}", request.name == f"transport-{i:03}.request.json")
            entry = read(request); payload = entry["payload"]
            check("study:" + name + f":request_settings:{i}", payload["json_schema"] == {"type": "object"} and payload["temperature"] == payload["seed"] == 0 and payload["n_predict"] == 512 and payload["cache_prompt"] is False)
            response = request.with_name(request.name.replace("request", "response"))
            if response.exists():
                raw = read(response)
                raw_bytes = response.with_suffix(".raw").read_bytes()
                check("study:" + name + f":raw_transport:{i}", exact(json.loads(raw_bytes), raw))
                check("study:" + name + f":actual_prompt_tokens:{i}", raw["tokens_evaluated"] == len(payload["prompt"]))
                settings = raw["generation_settings"]
                settings = settings.get("params", settings)
                check("study:" + name + f":actual_decoder_settings:{i}", settings["temperature"] == settings["seed"] == 0 and type(settings.get("grammar")) is str and bool(settings["grammar"].strip()) and settings.get("grammar_lazy") is False)
                check("study:" + name + f":untruncated_prompt:{i}", raw["truncated"] is False and raw["stop_type"] in {"eos", "limit"} and len(payload["prompt"]) + 512 <= 8192)
                predicted = raw["timings"]["predicted_n"]
                check("study:" + name + f":actual_output_tokens:{i}", type(predicted) is int and len(raw["tokens"]) <= predicted <= len(raw["tokens"]) + 1 and 0 < predicted <= 512)
                tokens = len(payload["prompt"]) + predicted
                total_tokens += tokens
                if i <= 2: preflight_tokens += tokens
                else: task_tokens += tokens
        started = {row["id"] for row in report["rows"]}
        completed = {row["id"] for row in report["rows"] if row["state"] in SCORED}
        planned = report["planned_cells"]
        check("study:" + name + ":16_planned_cells", len(planned) == 16 and len({x["id"] for x in planned}) == 16)
        check("study:" + name + ":completed", sorted(completed) == report["completed_cells"])
        check("study:" + name + ":unfinished", [x for x in planned if x["id"] not in completed] == report["unfinished_cells"])
        check("study:" + name + ":unstarted", [x for x in planned if x["id"] not in started] == report["unstarted_cells"])
        tasks_by_id = {task["id"]: task for task in p["tasks"]}
        for row_index, row in enumerate(report["rows"]):
            label = "study:" + name + ":" + row["id"]
            check(label + ":evaluation_copy", exact(read(folder / (row["id"] + ".evaluation.json")), row))
            if "native" in row:
                audit_native(label, row["native"], expected[row["task"]])
                check(label + ":native_state", row["state"] == row["native"]["status"] and row["ok"] is row["native"]["ok"])
            if "generation" in row:
                value = read(folder / row["generation"]["response"])
                check(label + ":usage_copy", exact(value["usage"], row["generation"]["usage"]))
                check(label + ":usage_arithmetic", value["usage"]["total_tokens"] == value["usage"]["input_tokens"] + value["usage"]["output_tokens"])
                transport_request = read(folder / "engine" / f"transport-{row_index + 3:03}.request.json")
                transport_response = read(folder / "engine" / f"transport-{row_index + 3:03}.response.json")
                check(label + ":raw_response_binding", exact(value["response"], transport_response) and exact(value["request"], transport_request["payload"]) and value["text"] == transport_response["content"])
                check(label + ":request_binding", exact(read(folder / (row["id"] + ".request.json"))["messages"], transport_request["messages"]))
                audit_response_candidate(label, tasks_by_id[row["task"]], row, value, folder / "candidates" / row["id"])
        for arm in ARMS:
            rows = [row for row in report["rows"] if row["arm"] == arm]
            scored = [row for row in rows if row["state"] in SCORED]
            usage = [row["generation"]["usage"] for row in rows if "generation" in row]
            wanted = {"planned_tasks": 4, "attempted_tasks": len(rows), "completed_tasks": len(scored),
                      "successes": sum(row["ok"] for row in scored),
                      "accepted_but_wrong": sum(row["state"] in {"observable_wrong", "expected_overflow_trap"} for row in scored),
                      "rejected": sum(row["state"] == "response_rejected" for row in scored),
                      "infrastructure_failures": len(rows) - len(scored),
                      "known_input_tokens": sum(x["input_tokens"] for x in usage), "known_output_tokens": sum(x["output_tokens"] for x in usage),
                      "unknown_usage_tasks": len(rows) - len(usage), "usage_complete": len(rows) == len(usage)}
            check("study:" + name + ":summary:" + arm, all(exact(summary[arm][key], value) for key, value in wanted.items()))
        hia, rust, full = (summary[arm] for arm in ("hia_edit_query", "rust_edit_query", "hia_full_context"))
        eligible = r["status"] == "completed" and all(x["usage_complete"] for x in (hia, rust, full)) and hia["successes"] == 4
        cost = lambda x: x["known_input_tokens"] + x["known_output_tokens"]
        primary = eligible and hia["successes"] >= rust["successes"] and cost(hia) <= cost(rust)
        secondary = eligible and hia["successes"] >= full["successes"] and cost(hia) < cost(full)
        check("study:" + name + ":primary", r["primary_criteria_per_model"][index] is primary)
        check("study:" + name + ":secondary", r["secondary_criteria_per_model"][index] is secondary)
        model_findings.append({"model": name, "status": report["status"], "requests": len(requests), "responses": len(responses),
                               "unstarted": len(report["unstarted_cells"]), "summary": summary, "primary": primary, "secondary": secondary})
    check("study:request_totals", r["actual_requests"] == total_requests and r["actual_responses"] == total_responses)
    complete = (r["native_controls_passed"] == 32 and r["source_unchanged"] is True and r["toolchain_unchanged"] is True
                and len(r["models"]) == 2
                and all(model["status"] == "completed" and len(model["completed_cells"]) == 16
                        and len(model["rows"]) == 16 and all(row["state"] in SCORED for row in model["rows"])
                        and not model["unfinished_cells"] and not model["unstarted_cells"] and not model["unresolved_requests"]
                        and model["identity"]["model_unchanged"] is True and model["identity"]["runtime_unchanged"] is True
                        for model in r["models"]))
    check("study:completion_status", (r["status"] == "completed") is complete)
    if complete:
        check("study:all36_requests_observed", total_requests == total_responses == 36)
    check("study:no_general_claim", r["general_productivity_advantage_established"] is False and r["total_development_cost_measured"] is False)
    findings["atomic_study"] = {"status": r["status"], "requests": total_requests, "responses": total_responses,
                                "task_tokens": task_tokens, "preflight_tokens": preflight_tokens, "all_observed_tokens": total_tokens,
                                "models": model_findings}

def main():
    global SOURCE, TREE
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--unified", required=True)
    parser.add_argument("--study")
    parser.add_argument("--source-commit", default=SOURCE)
    parser.add_argument("--source-tree", default=TREE)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    SOURCE, TREE = args.source_commit, args.source_tree
    repo, unified = map(Path, (args.repo, args.unified))
    jobs = [("unified", lambda: audit_unified(unified, repo)),
            ("recursive", lambda: audit_chain(unified / "recursive-chain")),
            ("performance", lambda: audit_performance(unified / "performance.json"))]
    if args.study:
        jobs.append(("study", lambda: audit_study(Path(args.study), repo)))
    for label, function in jobs:
        try:
            function()
        except Exception as exc:
            check(label + ":auditor_exception", False, {"type": type(exc).__name__, "message": str(exc)})
    result = {"schema": "hepta.round2.independent-evidence-audit.v1", "ok": not failures,
              "source_commit": SOURCE, "source_tree": TREE,
              "unified_directory": str(unified), "study_directory": args.study,
              "checks": len(checks), "failed_checks": failures, "observations": findings,
              "scope": "Read-only retained bytes, protocol arithmetic and count consistency. No rerun, no hostile-producer attestation, no compiler soundness proof.",
              "all_checks": checks}
    with Path(args.output).open("x") as f:
        json.dump(result, f, indent=2, ensure_ascii=False); f.write("\n")
    print(json.dumps({"ok": result["ok"], "checks": len(checks), "failures": failures}, ensure_ascii=False))
    return 0 if result["ok"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
