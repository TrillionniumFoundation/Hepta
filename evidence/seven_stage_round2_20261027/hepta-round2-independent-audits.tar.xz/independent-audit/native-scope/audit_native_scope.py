"""Independent read-only check of already-executed C/C++/RV64 evidence.

Does not import the compiler or collector, execute native candidates, rerun a
test, rewrite a receipt, or use a production acceptance flag as an oracle.
The producer and local filesystem remain trusted; this is consistency audit,
not execution attestation or a new qualification run.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path


checks = []
failures = []


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def check(name, condition):
    checks.append(name)
    if condition is not True:
        failures.append(name)


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def file_check(path, expected, name):
    path = Path(path)
    check(name + ":regular", path.is_file() and not path.is_symlink())
    check(name + ":sha256", sha(path) == (expected if isinstance(expected, str) else expected["sha256"]))
    if isinstance(expected, dict) and "bytes" in expected:
        check(name + ":bytes", path.stat().st_size == expected["bytes"])


def process_logs(owner, label):
    for process in owner.get("processes", []):
        name = label + ":process:" + process["stage"]
        for stream in ("stdout", "stderr"):
            data = Path(process[stream + "_path"]).read_bytes()
            check(name + ":" + stream + ":bytes", data == base64.b64decode(process[stream + "_bytes_base64"]))
            check(name + ":" + stream + ":hash", hashlib.sha256(data).hexdigest() == process[stream + "_sha256"])
            check(name + ":" + stream + ":text", data.decode("utf-8", errors="replace") == process[stream])


def c_matrix(root):
    report = read(root / "qualification.json")
    check("C:qualified", report["ok"] is True)
    check("C:source_unchanged", report["source_unchanged"] is True)
    check("C:HIA_count", report["native_hia_implementations"] == 0)
    check("C:safe_Hepta_Rust_variants", report["native_safe_hepta_rust_variants"] == 2)
    check("C:no_original_objects", report["original_c_objects_in_targets"] is False)
    check("C:no_translation_theorem", report["source_equivalence_proved"] is False)
    check("C:no_foreign_provenance_proof", report["foreign_pointer_provenance_proved"] is False)
    check("C:no_performance_claim", report["performance"] == {"status": "not_measured", "performance_floor_established": False})
    check("C:two_variants", [r["name"] for r in report["variants"]] == ["plain", "masked"])
    expected_coverage = {"function_converted": 10, "prototype_resolved": 16,
        "record_converted": 2, "record_forward_resolved": 2,
        "repeated_inline_definition_resolved": 3, "type_alias_resolved": 4}
    for i, coverage in enumerate(report["all_activity_dispositions"]):
        check(f"C:coverage:{i}:counts", coverage["status_counts"] == expected_coverage)
        check(f"C:coverage:{i}:total", coverage["active_project_declarations"] == sum(expected_coverage.values()) == 37)
    totals = Counter()
    for row, mask in zip(report["variants"], (0, 90)):
        label = "C:" + row["name"]
        check(label + ":passed", row["ok"] is True)
        check(label + ":exports", len(row["actual_export_symbols"]) == 10 and len(set(row["actual_export_symbols"])) == 10)
        upstream = row["upstream_sequences"]
        check(label + ":upstream_steps", upstream["state_transitions"] == 2048)
        check(label + ":upstream_counts", upstream["native_differential_calls"] == sum(upstream["calls_by_function"].values()) == 8200)
        check(label + ":upstream_actual_calls", upstream["actual_native_calls"] == 2 * upstream["native_differential_calls"] == 16400)
        cross = row["cross_module_sequences"]
        check(label + ":cross_mask", cross["mask"] == mask)
        check(label + ":cross_steps", cross["state_transitions"] == 1536)
        check(label + ":cross_calls", cross["native_transfer_calls"] == cross["native_followup_query_calls"] == 3072 and cross["native_initialization_calls"] == 12)
        check(label + ":boundary_count", len(row["boundary_controls"]) == 5)
        for boundary in row["boundary_controls"]:
            check(label + ":boundary:" + boundary["case"], boundary["exit_code"] == -6 and boundary["original_c_executed_outside_contract"] is False)
        check(label + ":layout", all(v["original_c"] == v["rust"] for v in row["layout"].values()))
        for path, identity in row["artifacts"].items():
            file_check(path, identity, label + ":artifact:" + path)
        process_logs(row, label)
        totals.update({"upstream_state_transitions": upstream["state_transitions"],
            "upstream_actual_native_calls": upstream["actual_native_calls"],
            "cross_module_state_transitions": cross["state_transitions"],
            "cross_module_transfer_calls": cross["native_transfer_calls"],
            "cross_module_query_calls": cross["native_followup_query_calls"],
            "cross_module_initialization_calls": cross["native_initialization_calls"],
            "boundary_control_processes": len(row["boundary_controls"])})
    check("C:negative_contracts", len(report["negative_contracts"]) == 3 and all(r["report"]["ok"] is False for r in report["negative_contracts"]))
    for path, identity in report["source_snapshot"].items():
        file_check(path, identity, "C:source:" + path)
    for item in report["upstream"]["files"]:
        file_check(root / "inputs/source" / item["local_path"], item, "C:unchanged_upstream:" + item["local_path"])
    return {"counts": dict(totals), "active_declarations_per_configuration": 37,
        "converted_functions_per_configuration": 10, "safe_Hepta_Rust_variants": 2,
        "standalone_HIA_variants": 0,
        "scope": "Two declared C configurations and two translation units, explicit resource contracts, no source equivalence/provenance proof or performance qualification."}


def cpp_composed(root):
    report = read(root / "qualification.json")
    check("CPP:qualified_observation", report["ok"] is True)
    check("CPP:versions", [r["version"] for r in report["versions"]] == ["3.11.3", "3.12.0"])
    check("CPP:bridge_native_separation", report["claims"]["bridge_upgrade_variants"] == 2 and report["claims"]["native_implementation_migrations"] == 0 and report["claims"]["foreign_cpp_implementation_rewritten"] is False)
    check("CPP:scope_failure", report["claims"]["all_allocation_failure_paths_recovered"] is False and report["status"] == "complete_observation_with_foreign_termination")
    expected = read(root / "expected.json")
    check("CPP:expected_case_counts", {k: len(v) for k, v in expected.items()} == {"json_cases": 112, "vector_cases": 56} == report["case_denominators_per_version"])
    faults = []
    case_routes = 0
    for row in report["versions"]:
        label = "CPP:" + row["version"]
        check(label + ":completed", row["ok"] is True)
        processes = {p["stage"]: p for p in row["processes"]}
        check(label + ":distinct_processes", len(processes) == len(row["processes"]))
        normal = json.loads(processes["normal"]["stdout"])
        check(label + ":normal_raw_matches", canonical(normal) == canonical(row["observed"]))
        for kind, cases in expected.items():
            check(label + ":normal:" + kind, canonical(normal[kind]) == canonical(cases))
            case_routes += 2 * len(cases)
        check(label + ":exports", len(row["export_symbols"]) == len(set(row["export_symbols"])) == 13)
        check(label + ":four_fault_routes", [(r["pipeline"], r["route"]) for r in row["allocation_failures"]] == [(0, 0), (0, 1), (1, 0), (1, 1)])
        for route in row["allocation_failures"]:
            prefix = f'fault_{route["pipeline"]}_{route["route"]}'
            raw = json.loads(processes[prefix + "_calibrate"]["stdout"])
            check(label + ":" + prefix + ":calibration", raw == route["calibration"])
            check(label + ":" + prefix + ":denominator", [s["site"] for s in route["sites"]] == list(range(1, raw["sites"] + 1)))
            for site in route["sites"]:
                native = processes[prefix + "_" + str(site["site"])]
                name = label + ":" + prefix + ":" + str(site["site"])
                check(name + ":actual_exit", native["exit_code"] == site["exit_code"])
                if native["exit_code"] == 0:
                    wanted = {"site": site["site"], "status": 3, "live_delta": 0, "output_preserved": True, "recovered": True}
                    check(name + ":caught", json.loads(native["stdout"]) == wanted and site["status"] == "caught_recovered" and site["recovery_qualified"] is True)
                else:
                    check(name + ":retained_termination", native["exit_code"] == -6 and "bad_alloc" in native["stderr"] and site["status"] == "foreign_noexcept_termination" and site["recovery_qualified"] is False)
                faults.append(site)
        for path, identity in row["artifacts"].items():
            file_check(path, identity, label + ":artifact:" + path)
        process_logs(row, label)
    summary = {"total": len(faults), "caught_recovered": sum(s["status"] == "caught_recovered" for s in faults),
               "foreign_noexcept_termination": sum(s["status"] == "foreign_noexcept_termination" for s in faults)}
    check("CPP:fault_summary", summary == report["allocation_fault_summary"] == {"total": 156, "caught_recovered": 132, "foreign_noexcept_termination": 24})
    check("CPP:normal_case_routes", case_routes == 672)
    check("CPP:negative_denominator", len(report["negative_controls"]) == 3)
    for negative in report["negative_controls"]:
        check("CPP:negative:" + negative["case"], negative["rejection"]["ok"] is False if negative["case"] == "native_method_mismatch" else negative["detected"] is True)
        process_logs(negative, "CPP:negative:" + negative["case"])
    check("CPP:source_stability", report["source_before"] == report["source_after"] and report["compiler_hash_before"] == report["compiler_hash_after"])
    return {"normal_case_route_executions": case_routes, "allocation_faults": summary,
        "bridge_upgrade_variants": 2, "native_implementation_migrations": 0,
        "scope": "Complete finite bridge observation over two unchanged upstream releases; 24 actual SIGABRT events remain unrecovered; no claim of foreign library memory safety or full replacement."}


def riscv64(root):
    report = read(root / "qualification.json")
    check("RV64:qualified", report["ok"] is True)
    check("RV64:physical_limit", report["claims"]["physical_hardware_executed"] is False)
    counts = report["counts"]
    check("RV64:positive_binaries", len(report["native"]) == counts["positive_binaries"] == 2)
    check("RV64:recursive_binary", len(report["recursive"]["native"]) == counts["recursive_positive_binaries"] == 1)
    check("RV64:negative_binaries", len(report["negative_controls"]) + len(report["recursive"]["negative_controls"]) == counts["all_actual_negative_executions"] == 7)
    check("RV64:call_denominator", counts["actual_c_to_hia_calls"] == 2 * (counts["scalar_calls_per_binary"] + counts["bulk_calls_per_binary"]) == 212)
    check("RV64:recursive_denominator", counts["recursive_c_to_hia_calls"] == len(report["recursive"]["cases"]) == 21)
    check("RV64:total_calls", counts["all_actual_c_to_hia_calls"] == counts["actual_c_to_hia_calls"] + counts["recursive_c_to_hia_calls"] == 233)
    for relative, identity in report["artifacts"].items():
        file_check(root / relative, identity, "RV64:artifact:" + relative)
    all_executions = [*report["native"], *report["negative_controls"], *report["recursive"]["native"], *report["recursive"]["negative_controls"]]
    for row in all_executions:
        process = report["processes"][row["run_process"]]
        actual = {"returncode": process["returncode"], "stdout": Path(process["stdout"]).read_text(), "stderr": Path(process["stderr"]).read_text()}
        check("RV64:execution:" + row["name"], actual == row["execution"] and process["argv"] == [report["tools"]["qemu"]["path"], str(root / row["name"] / "program.elf")])
    original = {k: v for k, v in report.items() if k != "record_sha256"}
    check("RV64:record_hash", hashlib.sha256(canonical(original)).hexdigest() == report["record_sha256"])
    return {"counts": counts, "scope": "RV64GC LP64D Linux userspace QEMU machine-code executions, C calls to scalar HIA exports and HIA calls to finite C allocator/memory imports; no physical hardware/device or arbitrary foreign-call claim."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = {"schema": "hepta.round2.independent-native-scope-audit.v1", "source_commit": "806110df3ef57a388d593ac454e3011724a802e3", "evidence_root": str(args.root), "new_native_executions": 0, "mutated_source_or_evidence": False}
    for label, folder, fn in (("C", "c-resource-matrix", c_matrix), ("CPP", "cpp-composed", cpp_composed), ("RV64", "riscv64", riscv64)):
        try:
            result[label] = fn(args.root / folder)
        except Exception as exc:
            failures.append(label + ":audit_exception:" + type(exc).__name__ + ":" + str(exc))
    result.update(checks=len(checks), failures=failures, ok=not failures,
        limits=["Local consistency audit; no third-party execution attestation.", "Source and evidence files only read; candidate binaries never executed."])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"ok": result["ok"], "checks": result["checks"], "failures": failures, "output": str(args.output)}))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
