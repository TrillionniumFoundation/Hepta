"""Assemble a truthful round-2 summary only after all selected runs terminate."""
from pathlib import Path
import hashlib
import json


BASE = Path('/tmp')
DEST = Path('/tmp/hepta-round2-final-text')
SOURCE = '5818c5814fb42dbd97a027e9b328f4ae3099c0fc'


def read(path):
    return json.loads(Path(path).read_text())


def write(name, value):
    with (DEST / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    first = read(BASE / 'hepta-unified-round2-run1/qualification.json')
    root = BASE / 'hepta-unified-round2-run3'
    final = read(root / 'qualification.json')
    study = read(BASE / 'hepta-batch-study-frozen-round2-run1/report.json')
    assert final['git_commit'] == study['git_commit'] == SOURCE
    assert first['compiler_tree_sha256'] == final['compiler_tree_sha256']
    assert first['unchanged_source'] and final['unchanged_source']
    assert len(final['gates']) == 19
    recursive = read(root / 'recursive-chain/qualification.json')
    c = read(root / 'c-resource-matrix/qualification.json')
    cpp = read(root / 'cpp-composed/qualification.json')
    rv = read(root / 'riscv64/qualification.json')
    perf = read(root / 'performance.json')
    perf1 = read(BASE / 'hepta-unified-round2-run1/performance.json')
    models = []
    for model in study['models']:
        tasks = [r['generation']['usage'] for r in model['rows'] if 'generation' in r]
        probes = [r['usage'] for r in model['preflight'] if 'usage' in r]
        total = lambda rows: sum(r['input_tokens'] + r['output_tokens'] for r in rows)
        models.append({'id': model['model']['id'], 'family': model['model']['family'],
            'model': model['model'], 'status': model['status'], 'arms': model['summary'],
            'requests_started': model['requests_started'], 'responses_received': model['responses_received'],
            'unresolved_requests': model['unresolved_requests'],
            'unfinished_cells': model['unfinished_cells'], 'unstarted_cells': model['unstarted_cells'],
            'task_tokens_known': total(tasks), 'preflight_tokens_known': total(probes),
            'all_generation_tokens_known': total(tasks + probes),
            'generation_usage_records': len(tasks) + len(probes),
            'requests_without_usage_record': model['requests_started'] - len(tasks) - len(probes)})
    performance = lambda p: {'ok': p['ok'], 'status': p['status'],
        'sample_count': len(p['raw_samples']), 'evaluation': p.get('evaluation'),
        'interference_observations': p.get('interference_observations'), 'claims': p['claims']}
    summary = {'schema': 'hepta.seven-stage.round2-summary.v1',
        'source': {'qualification_and_study_commit': SOURCE,
            'source_tree': '94686c350b10e93f631ea164811ecbc5948b3775',
            'initial_source_commit': first['git_commit'],
            'compiler_tree_sha256': final['compiler_tree_sha256'],
            'source_snapshot_sha256': final['source_snapshot_after']['sha256'],
            'compiler_unchanged_between_runs': True,
            'test_only_fix': ['docs/HIA_SEVEN_STAGE.md', 'tests/test_elf_shared_abi_native.py']},
        'integration': {key: final[key] for key in ('ok', 'status', 'passed_gates', 'completed_gates',
            'unchanged_source', 'full_seven_deliverables_complete')},
        'unit_regression': final['gates'][0],
        'gates': [{'name': r['name'], 'passed': r['passed'], 'returncode': r['returncode'],
                   'seconds': r['seconds']} for r in final['gates']],
        'retained_failed_run1': {'passed_gates': first['passed_gates'], 'completed_gates': first['completed_gates'],
            'unit_regression': first['gates'][0], 'performance': performance(perf1),
            'cause_scope': '61 visible subtest failures/errors from missing fcntl seals, two invalid C fixture strings; no security fallback'},
        'recursive': {'ok': recursive['ok'], 'planned_cases': recursive['planned_cases'],
            'executed_cases': recursive['executed_cases'], 'cases_passed': recursive['cases_passed'],
            'negative_control_count': len(recursive['negative_controls']), 'claims': recursive['claims']},
        'c_resource_matrix': {'ok': c['ok'], 'active_declarations': c['all_activity_dispositions'],
            'native_safe_hepta_rust_variants': c['native_safe_hepta_rust_variants'],
            'native_hia_implementations': c['native_hia_implementations'],
            'original_c_objects_in_targets': c['original_c_objects_in_targets'],
            'performance': c['performance'], 'contract_negative_controls': len(c['negative_contracts']),
            'variants': [{'name': v['name'], 'ok': v['ok'], 'upstream': v['upstream_sequences'],
                'cross_module': v['cross_module_sequences'], 'actual_export_symbols': v['actual_export_symbols'],
                'boundary_controls': len(v['boundary_controls'])} for v in c['variants']]},
        'cpp_composed': {'ok': cpp['ok'], 'status': cpp['status'],
            'allocation_fault_summary': cpp['allocation_fault_summary'],
            'case_denominators_per_version': cpp['case_denominators_per_version'],
            'normal_case_route_executions': 2 * 2 * sum(cpp['case_denominators_per_version'].values()),
            'claims': cpp['claims'], 'negative_controls': len(cpp['negative_controls'])},
        'riscv64': {'ok': rv['ok'], 'status': rv['status'], 'counts': rv['counts'], 'claims': rv['claims']},
        'performance': performance(perf),
        'all_round2_performance_samples': len(perf1['raw_samples']) + len(perf['raw_samples']),
        'agent': {'status': study['status'], 'actual_requests': study['actual_requests'],
            'actual_responses': study['actual_responses'], 'native_controls': study['native_controls'],
            'native_controls_passed': study['native_controls_passed'],
            'primary_criteria_per_model': study['primary_criteria_per_model'],
            'secondary_criteria_per_model': study['secondary_criteria_per_model'],
            'all_generation_tokens_known': sum(m['all_generation_tokens_known'] for m in models),
            'requests_without_usage_record': sum(m['requests_without_usage_record'] for m in models),
            'models': models, 'source_unchanged': study['source_unchanged'],
            'toolchain_unchanged': study['toolchain_unchanged'],
            'general_productivity_advantage_established': False, 'total_development_cost_measured': False},
        'open_obligations': ['general recursive heap ADTs and escaping loans',
            'whole-compiler/LLVM/resource/concurrency refinement proofs',
            'arbitrary C configurations and inferred resource contracts',
            'standalone HIA lowering of contracted pointer-bearing record modules',
            'broad native C++ implementation migrations and noexcept failure recovery',
            'other host ABI families and physical hardware/device protocols',
            'representative stable performance and real maintenance total development cost'],
        'full_seven_deliverables_complete': False}
    DEST.mkdir(exist_ok=False)
    write('SUMMARY.json', summary)
    history = {'schema': 'hepta.seven-stage.source-history.v2',
        'branch': 'implement/hia-seven-stage-unified-20261026',
        'pr': 'https://github.com/TrillionniumFoundation/Hepta/pull/210',
        'previous_evidence_commit': 'bdb8690317e96e1cd4a6f140e96376faa9dba522',
        'merged_native_isolation_head': 'b41db78816c39ab59dd42d35c28426c54d1fe45d',
        'runs': [{'id': 'round2_run1', 'source': first['git_commit'],
                  'passed_gates': first['passed_gates'], 'total_gates': 19, 'status': first['status']},
                 {'id': 'round2_run2', 'source': SOURCE, 'status': 'interrupted_without_terminal_report', 'unit_tests_run': None},
                 {'id': 'round2_run3', 'source': SOURCE, 'passed_gates': final['passed_gates'],
                  'total_gates': 19, 'status': final['status'], 'native_python': '/usr/bin/python3'},
                 {'id': 'atomic_two_family_study', 'source': SOURCE, 'status': study['status'],
                  'actual_requests': study['actual_requests'], 'actual_responses': study['actual_responses']}],
        'compiler_bytes_unchanged_across_round2_runs': True,
        'old_evidence_and_failed_studies_unchanged': True}
    write('SOURCE_HISTORY.json', history)
    print(json.dumps({'directory': str(DEST), 'passed_gates': final['passed_gates'],
        'tests': final['gates'][0]['tests_run'], 'model_status': study['status'],
        'actual_requests': study['actual_requests'], 'tokens_known': summary['agent']['all_generation_tokens_known']}))


if __name__ == '__main__':
    main()
