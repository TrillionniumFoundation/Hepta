"""Record an authorized long qualification independently of a transient tool handle."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def dump(path, value):
    temporary = Path(str(path) + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    os.replace(temporary, path)


def worker(spec_path):
    spec = json.loads(spec_path.read_text())
    state_path = Path(spec['state_path'])
    env = os.environ.copy()
    env.update(spec['environment'])
    record = {'schema': 'hepta.execution.supervisor.v1', 'status': 'starting',
              'worker_pid': os.getpid(), 'started_utc': now(),
              'argv': spec['argv'], 'cwd': spec['cwd'],
              'source_commit': spec['source_commit'],
              'spec_sha256': hashlib.sha256(spec_path.read_bytes()).hexdigest()}
    started = time.monotonic()
    dump(state_path, record)
    try:
        with Path(spec['driver_log']).open('xb') as output:
            process = subprocess.Popen(spec['argv'], cwd=spec['cwd'], env=env,
                stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
                close_fds=True, start_new_session=True)
            record.update(status='running', child_pid=process.pid)
            dump(state_path, record)
            code = process.wait()
        terminal = Path(spec['terminal_report'])
        record.update(status='completed' if terminal.is_file() else 'interrupted_without_terminal_report',
                      returncode=code, terminal_report_exists=terminal.is_file(),
                      terminal_report_sha256=hashlib.sha256(terminal.read_bytes()).hexdigest() if terminal.is_file() else None)
    except BaseException as error:
        record.update(status='supervisor_error', error={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        record.update(finished_utc=now(), elapsed_seconds=time.monotonic() - started)
        dump(state_path, record)


def launch(spec_path):
    spec = json.loads(spec_path.read_text())
    for key in ('state_path', 'driver_log', 'terminal_report'):
        if Path(spec[key]).exists():
            raise ValueError('new paths required: ' + key)
    with Path(spec['supervisor_log']).open('xb') as log:
        process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'worker', str(spec_path)],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            close_fds=True, start_new_session=True)
    print(json.dumps({'launched_worker_pid': process.pid, 'state_path': spec['state_path']}))


if __name__ == '__main__':
    mode, path = sys.argv[1:]
    {'launch': launch, 'worker': worker}[mode](Path(path).resolve())
