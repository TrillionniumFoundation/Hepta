#define I(T,N) T N(T v) { return v; }
I(signed char,i8) I(unsigned char,u8) I(short,i16) I(unsigned short,u16)
I(int,i32) I(unsigned int,u32) I(long long,i64) I(unsigned long long,u64)
I(_Bool,boolean) I(__SIZE_TYPE__,sizeword) I(__PTRDIFF_TYPE__,signedword)
