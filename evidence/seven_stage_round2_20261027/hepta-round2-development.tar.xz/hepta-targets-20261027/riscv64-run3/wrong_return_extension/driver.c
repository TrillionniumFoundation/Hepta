/* Finite RV64GC / LP64D Linux userspace qualification runtime.
 * 64 independent 4096-byte slots, no concurrency, realloc or production claim.
 * This code runs under QEMU; it is not physical-board or device evidence.
 */
typedef __SIZE_TYPE__ hepta_size;
typedef __UINT8_TYPE__ hepta_u8;
typedef __UINT32_TYPE__ hepta_u32;
typedef __UINT64_TYPE__ hepta_u64;
typedef __UINTPTR_TYPE__ hepta_uintptr;
#if !defined(__riscv) || __riscv_xlen != 64 || !defined(__riscv_float_abi_double)
#error requires RV64 LP64D
#endif
#if !defined(__BYTE_ORDER__) || __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error requires little endian
#endif
_Static_assert(__CHAR_BIT__ == 8 && sizeof(void *) == 8 && sizeof(hepta_size) == 8,
               "strict LP64 test ABI");
#define HEPTA_CAPACITY 4096u
#define HEPTA_SLOTS 64u
static _Alignas(16) hepta_u8 arenas[HEPTA_SLOTS][HEPTA_CAPACITY];
static volatile hepta_u8 occupied[HEPTA_SLOTS];
static volatile hepta_u32 failure_countdown;
static volatile hepta_u32 peak_outstanding, outstanding;
static volatile hepta_u32 successful_allocations, releases, denied_allocations;
static volatile hepta_u32 null_frees;

__attribute__((noreturn)) static void hepta_exit(hepta_u32 code) {
    register long a0 __asm__("a0") = (long)code;
    register long a7 __asm__("a7") = 93;
    __asm__ volatile("ecall" : : "r"(a0), "r"(a7) : "memory");
    __builtin_unreachable();
}
__attribute__((noreturn)) void abort(void) { hepta_exit(134); }
__attribute__((noinline)) void *malloc(hepta_size n) {
    if (failure_countdown && --failure_countdown == 0) {
        ++denied_allocations;
        return (void *)0;
    }
    if (n == 0 || n > HEPTA_CAPACITY) {
        ++denied_allocations;
        return (void *)0;
    }
    for (hepta_size i = 0; i < HEPTA_SLOTS; ++i) {
        if (!occupied[i]) {
            occupied[i] = 1;
            ++outstanding;
            if (outstanding > peak_outstanding) peak_outstanding = outstanding;
            ++successful_allocations;
            return (void *)arenas[i];
        }
    }
    ++denied_allocations;
    return (void *)0;
}
__attribute__((noinline)) void free(void *p) {
    if (!p) { ++null_frees; return; }
    for (hepta_size i = 0; i < HEPTA_SLOTS; ++i) {
        if (p == (void *)arenas[i]) {
            if (!occupied[i] || !outstanding) abort();
            occupied[i] = 0;
            --outstanding;
            ++releases;
            return;
        }
    }
    abort();
}
__attribute__((noinline)) void *memset(void *destination, int value, hepta_size n) {
    hepta_u8 *p = (hepta_u8 *)destination;
    for (hepta_size i = 0; i < n; ++i) p[i] = (hepta_u8)value;
    return destination;
}
__attribute__((noinline)) void *calloc(hepta_size count, hepta_size width) {
    if (width && count > ((hepta_size)-1) / width) {
        ++denied_allocations;
        return (void *)0;
    }
    hepta_size bytes = count * width;
    void *p = malloc(bytes);
    if (p) memset(p, 0, bytes);
    return p;
}
__attribute__((noinline)) void *memcpy(void *destination, const void *source, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)destination;
    const hepta_u8 *s = (const hepta_u8 *)source;
    for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    return destination;
}
__attribute__((noinline)) void *memmove(void *destination, const void *source, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)destination;
    const hepta_u8 *s = (const hepta_u8 *)source;
    if (d == s || !n) return destination;
    if ((hepta_uintptr)d < (hepta_uintptr)s) {
        for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    } else {
        for (hepta_size i = n; i; --i) d[i - 1] = s[i - 1];
    }
    return destination;
}
static int memory_primitives_ok(void) {
    hepta_u8 a[8], b[8];
    memset(a, 0, 8);
    for (hepta_size i = 0; i < 8; ++i) a[i] = (hepta_u8)(i + 1);
    memcpy(b, a, 8);
    memmove(b + 1, b, 7);
    for (hepta_size i = 0; i < 7; ++i) if (b[i + 1] != a[i]) return 0;
    memmove(b, b + 1, 7);
    for (hepta_size i = 0; i < 7; ++i) if (b[i] != a[i]) return 0;
    memmove(b, a, 8);
    for (hepta_size i = 0; i < 8; ++i) if (b[i] != a[i]) return 0;
    return 1;
}
static void write_values(const char *prefix, const hepta_u64 *values, hepta_size count) {
    char text[256];
    hepta_size used = 0;
    while (*prefix) text[used++] = *prefix++;
    for (hepta_size i = 0; i < count; ++i) {
        char digits[20];
        hepta_size n = 0;
        hepta_u64 value = values[i];
        do { digits[n++] = (char)('0' + value % 10); value /= 10; } while (value);
        while (n) text[used++] = digits[--n];
        text[used++] = i + 1 == count ? '\n' : ' ';
    }
    register long a0 __asm__("a0") = 1;
    register const char *a1 __asm__("a1") = text;
    register hepta_size a2 __asm__("a2") = used;
    register long a7 __asm__("a7") = 64;
    __asm__ volatile("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a7) : "memory");
    if (a0 != (long)used) hepta_exit(90);
}
static void write_resources(void) {
    hepta_u64 values[] = {successful_allocations, releases, outstanding,
                         denied_allocations, peak_outstanding};
    write_values("HIA_RISCV64 resources ", values, 5);
}

extern signed char abi_i8(signed char);
extern unsigned char abi_u8(unsigned char);
extern short abi_i16(short);
extern unsigned short abi_u16(unsigned short);
extern int abi_i32(int);
extern unsigned int abi_u32(unsigned int);
extern long long abi_i64(long long);
extern unsigned long long abi_u64(unsigned long long);
extern __PTRDIFF_TYPE__ abi_isize(__PTRDIFF_TYPE__);
extern __SIZE_TYPE__ abi_usize(__SIZE_TYPE__);
extern _Bool abi_bool(_Bool);
extern unsigned int abi_stack12(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int);
extern hepta_u8 aggregate_bulk(hepta_size,hepta_size,hepta_size,hepta_u8,hepta_size);
extern unsigned long long raw_u32(unsigned int);
__asm__(".text\n.globl raw_u32\n.type raw_u32,@function\nraw_u32:\naddi sp,sp,-16\nsd ra,8(sp)\ncall abi_u32\nslli a0,a0,32\nsrli a0,a0,32\nld ra,8(sp)\naddi sp,sp,16\nret\n.size raw_u32,.-raw_u32\n");
extern unsigned long long raw_i8(signed char);
__asm__(".text\n.globl raw_i8\n.type raw_i8,@function\nraw_i8:\naddi sp,sp,-16\nsd ra,8(sp)\ncall abi_i8\nld ra,8(sp)\naddi sp,sp,16\nret\n.size raw_i8,.-raw_i8\n");
extern unsigned long long raw_u8(unsigned char);
__asm__(".text\n.globl raw_u8\n.type raw_u8,@function\nraw_u8:\naddi sp,sp,-16\nsd ra,8(sp)\ncall abi_u8\nld ra,8(sp)\naddi sp,sp,16\nret\n.size raw_u8,.-raw_u8\n");
__attribute__((noreturn)) void _start(void) {
    if (!memory_primitives_ok()) hepta_exit(39);
    hepta_u64 calls = 0;
    if (abi_i8(((signed char)(-127LL - 1LL))) != ((signed char)(-127LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i8(((signed char)(-126LL - 1LL))) != ((signed char)(-126LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i8(((signed char)(-0LL - 1LL))) != ((signed char)(-0LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i8(((signed char)0ULL)) != ((signed char)0ULL)) hepta_exit(41); ++calls;
    if (abi_i8(((signed char)1ULL)) != ((signed char)1ULL)) hepta_exit(41); ++calls;
    if (abi_i8(((signed char)126ULL)) != ((signed char)126ULL)) hepta_exit(41); ++calls;
    if (abi_i8(((signed char)127ULL)) != ((signed char)127ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)0ULL)) != ((unsigned char)0ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)1ULL)) != ((unsigned char)1ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)42ULL)) != ((unsigned char)42ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)127ULL)) != ((unsigned char)127ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)128ULL)) != ((unsigned char)128ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)254ULL)) != ((unsigned char)254ULL)) hepta_exit(41); ++calls;
    if (abi_u8(((unsigned char)255ULL)) != ((unsigned char)255ULL)) hepta_exit(41); ++calls;
    if (abi_i16(((short)(-32767LL - 1LL))) != ((short)(-32767LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i16(((short)(-32766LL - 1LL))) != ((short)(-32766LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i16(((short)(-0LL - 1LL))) != ((short)(-0LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i16(((short)0ULL)) != ((short)0ULL)) hepta_exit(41); ++calls;
    if (abi_i16(((short)1ULL)) != ((short)1ULL)) hepta_exit(41); ++calls;
    if (abi_i16(((short)32766ULL)) != ((short)32766ULL)) hepta_exit(41); ++calls;
    if (abi_i16(((short)32767ULL)) != ((short)32767ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)0ULL)) != ((unsigned short)0ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)1ULL)) != ((unsigned short)1ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)42ULL)) != ((unsigned short)42ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)32767ULL)) != ((unsigned short)32767ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)32768ULL)) != ((unsigned short)32768ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)65534ULL)) != ((unsigned short)65534ULL)) hepta_exit(41); ++calls;
    if (abi_u16(((unsigned short)65535ULL)) != ((unsigned short)65535ULL)) hepta_exit(41); ++calls;
    if (abi_i32(((int)(-2147483647LL - 1LL))) != ((int)(-2147483647LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i32(((int)(-2147483646LL - 1LL))) != ((int)(-2147483646LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i32(((int)(-0LL - 1LL))) != ((int)(-0LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i32(((int)0ULL)) != ((int)0ULL)) hepta_exit(41); ++calls;
    if (abi_i32(((int)1ULL)) != ((int)1ULL)) hepta_exit(41); ++calls;
    if (abi_i32(((int)2147483646ULL)) != ((int)2147483646ULL)) hepta_exit(41); ++calls;
    if (abi_i32(((int)2147483647ULL)) != ((int)2147483647ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)0ULL)) != ((unsigned int)0ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)1ULL)) != ((unsigned int)1ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)42ULL)) != ((unsigned int)42ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)2147483647ULL)) != ((unsigned int)2147483647ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)2147483648ULL)) != ((unsigned int)2147483648ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)4294967294ULL)) != ((unsigned int)4294967294ULL)) hepta_exit(41); ++calls;
    if (abi_u32(((unsigned int)4294967295ULL)) != ((unsigned int)4294967295ULL)) hepta_exit(41); ++calls;
    if (abi_i64(((long long)(-9223372036854775807LL - 1LL))) != ((long long)(-9223372036854775807LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i64(((long long)(-9223372036854775806LL - 1LL))) != ((long long)(-9223372036854775806LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i64(((long long)(-0LL - 1LL))) != ((long long)(-0LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_i64(((long long)0ULL)) != ((long long)0ULL)) hepta_exit(41); ++calls;
    if (abi_i64(((long long)1ULL)) != ((long long)1ULL)) hepta_exit(41); ++calls;
    if (abi_i64(((long long)9223372036854775806ULL)) != ((long long)9223372036854775806ULL)) hepta_exit(41); ++calls;
    if (abi_i64(((long long)9223372036854775807ULL)) != ((long long)9223372036854775807ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)0ULL)) != ((unsigned long long)0ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)1ULL)) != ((unsigned long long)1ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)42ULL)) != ((unsigned long long)42ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)9223372036854775807ULL)) != ((unsigned long long)9223372036854775807ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)9223372036854775808ULL)) != ((unsigned long long)9223372036854775808ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)18446744073709551614ULL)) != ((unsigned long long)18446744073709551614ULL)) hepta_exit(41); ++calls;
    if (abi_u64(((unsigned long long)18446744073709551615ULL)) != ((unsigned long long)18446744073709551615ULL)) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)(-9223372036854775807LL - 1LL))) != ((__PTRDIFF_TYPE__)(-9223372036854775807LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)(-9223372036854775806LL - 1LL))) != ((__PTRDIFF_TYPE__)(-9223372036854775806LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)(-0LL - 1LL))) != ((__PTRDIFF_TYPE__)(-0LL - 1LL))) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)0ULL)) != ((__PTRDIFF_TYPE__)0ULL)) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)1ULL)) != ((__PTRDIFF_TYPE__)1ULL)) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)9223372036854775806ULL)) != ((__PTRDIFF_TYPE__)9223372036854775806ULL)) hepta_exit(41); ++calls;
    if (abi_isize(((__PTRDIFF_TYPE__)9223372036854775807ULL)) != ((__PTRDIFF_TYPE__)9223372036854775807ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)0ULL)) != ((__SIZE_TYPE__)0ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)1ULL)) != ((__SIZE_TYPE__)1ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)42ULL)) != ((__SIZE_TYPE__)42ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)9223372036854775807ULL)) != ((__SIZE_TYPE__)9223372036854775807ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)9223372036854775808ULL)) != ((__SIZE_TYPE__)9223372036854775808ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)18446744073709551614ULL)) != ((__SIZE_TYPE__)18446744073709551614ULL)) hepta_exit(41); ++calls;
    if (abi_usize(((__SIZE_TYPE__)18446744073709551615ULL)) != ((__SIZE_TYPE__)18446744073709551615ULL)) hepta_exit(41); ++calls;
    if (abi_bool(0) != 0) hepta_exit(41); ++calls;
    if (abi_bool(1) != 1) hepta_exit(41); ++calls;
    if (abi_stack12(((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL),((unsigned int)0ULL)) != 0U) hepta_exit(41); ++calls;
    if (abi_stack12(((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL),((unsigned int)1ULL)) != 78U) hepta_exit(41); ++calls;
    if (abi_stack12(((unsigned int)0ULL),((unsigned int)1ULL),((unsigned int)2ULL),((unsigned int)3ULL),((unsigned int)4ULL),((unsigned int)5ULL),((unsigned int)6ULL),((unsigned int)7ULL),((unsigned int)8ULL),((unsigned int)9ULL),((unsigned int)10ULL),((unsigned int)11ULL)) != 572U) hepta_exit(41); ++calls;
    if (abi_stack12(((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL),((unsigned int)4294967295ULL)) != 4294967218U) hepta_exit(41); ++calls;
    if (abi_stack12(((unsigned int)2147483648ULL),((unsigned int)2147483649ULL),((unsigned int)2147483650ULL),((unsigned int)2147483651ULL),((unsigned int)2147483652ULL),((unsigned int)2147483653ULL),((unsigned int)2147483654ULL),((unsigned int)2147483655ULL),((unsigned int)2147483656ULL),((unsigned int)2147483657ULL),((unsigned int)2147483658ULL),((unsigned int)2147483659ULL)) != 572U) hepta_exit(41); ++calls;
    if (abi_stack12(((unsigned int)0ULL),((unsigned int)1ULL),((unsigned int)4294967295ULL),((unsigned int)2147483648ULL),((unsigned int)7ULL),((unsigned int)31ULL),((unsigned int)2147483647ULL),((unsigned int)23ULL),((unsigned int)305419896ULL),((unsigned int)97ULL),((unsigned int)13ULL),((unsigned int)4276993775ULL)) != 385614674U) hepta_exit(41); ++calls;
    if (raw_u32(((unsigned int)0ULL)) != 0ULL) hepta_exit(42); ++calls;
    if (raw_u32(((unsigned int)1ULL)) != 1ULL) hepta_exit(42); ++calls;
    if (raw_u32(((unsigned int)2147483647ULL)) != 2147483647ULL) hepta_exit(42); ++calls;
    if (raw_u32(((unsigned int)2147483648ULL)) != 18446744071562067968ULL) hepta_exit(42); ++calls;
    if (raw_u32(((unsigned int)4294967295ULL)) != 18446744073709551615ULL) hepta_exit(42); ++calls;
    if (raw_i8(((signed char)(-127LL - 1LL))) != 18446744073709551488ULL) hepta_exit(42); ++calls;
    if (raw_i8(((signed char)(-0LL - 1LL))) != 18446744073709551615ULL) hepta_exit(42); ++calls;
    if (raw_i8(((signed char)127ULL)) != 127ULL) hepta_exit(42); ++calls;
    if (raw_u8(((unsigned char)128ULL)) != 128ULL) hepta_exit(42); ++calls;
    if (raw_u8(((unsigned char)255ULL)) != 255ULL) hepta_exit(42); ++calls;
    write_values("HIA_RISCV64 scalar ", &calls, 1);
    failure_countdown = 0;
    hepta_u64 row0[] = {0, aggregate_bulk(5,1,3,77,0)};
    write_values("HIA_RISCV64 case ", row0, 2);
    if (row0[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row1[] = {1, aggregate_bulk(5,1,3,77,1)};
    write_values("HIA_RISCV64 case ", row1, 2);
    if (row1[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row2[] = {2, aggregate_bulk(5,1,3,77,2)};
    write_values("HIA_RISCV64 case ", row2, 2);
    if (row2[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row3[] = {3, aggregate_bulk(5,1,3,77,3)};
    write_values("HIA_RISCV64 case ", row3, 2);
    if (row3[1] != 77) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row4[] = {4, aggregate_bulk(5,1,3,77,4)};
    write_values("HIA_RISCV64 case ", row4, 2);
    if (row4[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row5[] = {5, aggregate_bulk(8,2,4,255,0)};
    write_values("HIA_RISCV64 case ", row5, 2);
    if (row5[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row6[] = {6, aggregate_bulk(8,2,4,255,1)};
    write_values("HIA_RISCV64 case ", row6, 2);
    if (row6[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row7[] = {7, aggregate_bulk(8,2,4,255,2)};
    write_values("HIA_RISCV64 case ", row7, 2);
    if (row7[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row8[] = {8, aggregate_bulk(8,2,4,255,3)};
    write_values("HIA_RISCV64 case ", row8, 2);
    if (row8[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row9[] = {9, aggregate_bulk(8,2,4,255,4)};
    write_values("HIA_RISCV64 case ", row9, 2);
    if (row9[1] != 255) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row10[] = {10, aggregate_bulk(8,2,4,255,5)};
    write_values("HIA_RISCV64 case ", row10, 2);
    if (row10[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row11[] = {11, aggregate_bulk(8,2,4,255,6)};
    write_values("HIA_RISCV64 case ", row11, 2);
    if (row11[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row12[] = {12, aggregate_bulk(8,2,4,255,7)};
    write_values("HIA_RISCV64 case ", row12, 2);
    if (row12[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row13[] = {13, aggregate_bulk(1,1,0,99,0)};
    write_values("HIA_RISCV64 case ", row13, 2);
    if (row13[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row14[] = {14, aggregate_bulk(0,0,0,17,0)};
    write_values("HIA_RISCV64 case ", row14, 2);
    if (row14[1] != 0) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 0;
    hepta_u64 row15[] = {15, aggregate_bulk(4096,4096,0,31,4095)};
    write_values("HIA_RISCV64 case ", row15, 2);
    if (row15[1] != 11) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 1;
    hepta_u64 row16[] = {16, aggregate_bulk(5,1,3,77,3)};
    write_values("HIA_RISCV64 case ", row16, 2);
    if (row16[1] != 251) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    failure_countdown = 2;
    hepta_u64 row17[] = {17, aggregate_bulk(5,1,3,77,3)};
    write_values("HIA_RISCV64 case ", row17, 2);
    if (row17[1] != 252) hepta_exit(41);
    if (outstanding) {write_resources(); hepta_exit(91);}
    write_resources();
    if (successful_allocations != 31 || releases != 31 || denied_allocations != 2 || peak_outstanding != 2) hepta_exit(92);
    hepta_exit(0);
}
