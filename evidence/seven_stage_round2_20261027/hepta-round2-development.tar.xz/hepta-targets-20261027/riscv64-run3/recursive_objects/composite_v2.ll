; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "riscv64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal { ptr, i1 } @__hia_fn_0(i64 %p_0_0) {
b0:
  br label %edge_0
b1:
  %p_1_0 = phi ptr [ null, %edge_0 ], [ %t14, %edge_5 ]
  %p_1_1 = phi i64 [ 0, %edge_0 ], [ %t21, %edge_5 ]
  %p_1_2 = phi i64 [ %p_0_0, %edge_0 ], [ %p_3_3, %edge_5 ]
  %t1 = icmp ult i64 %p_1_1, %p_1_2
  br i1 %t1, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi ptr [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 1, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 1, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi ptr [ %p_2_0, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_3_2 = phi i64 [ %p_2_1, %edge_3 ]
  %p_3_3 = phi i64 [ %p_2_2, %edge_3 ]
  %t7 = trunc i64 %p_3_2 to i8
  %t8 = extractvalue %hia.buffer %p_3_1, 0
  %t9 = extractvalue %hia.buffer %p_3_1, 1
  %t10 = icmp ult i64 0, %t9
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  %t12 = getelementptr i8, ptr %t8, i64 0
  store i8 %t7, ptr %t12, align 1
  %t13 = call %hia.chain.result @__hia_chain_push(ptr %p_3_0, %hia.buffer %p_3_1)
  %t14 = extractvalue %hia.chain.result %t13, 0
  %t15 = extractvalue %hia.chain.result %t13, 1
  %t16 = extractvalue %hia.chain.result %t13, 2
  %t17 = extractvalue %hia.buffer %t15, 0
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %drop_nonnull_19, label %drop_after_19
drop_nonnull_19:
  call void @free(ptr %t17) nobuiltin
  br label %drop_after_19
drop_after_19:
  %t20 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_3_2, i64 1)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  %t23 = xor i1 %t22, true
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  br i1 %t16, label %edge_5, label %edge_6
b4:
  %p_4_0 = phi ptr [ %p_2_0, %edge_4 ]
  %p_4_1 = phi %hia.buffer [ %t6, %edge_4 ]
  %t25 = extractvalue %hia.buffer %p_4_1, 0
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %drop_nonnull_27, label %drop_after_27
drop_nonnull_27:
  call void @free(ptr %t25) nobuiltin
  br label %drop_after_27
drop_after_27:
  %t28 = insertvalue { ptr, i1 } zeroinitializer, ptr %p_4_0, 0
  %t29 = insertvalue { ptr, i1 } %t28, i1 false, 1
  ret { ptr, i1 } %t29
b5:
  %p_5_0 = phi ptr [ %t14, %edge_6 ]
  %t30 = insertvalue { ptr, i1 } zeroinitializer, ptr %p_5_0, 0
  %t31 = insertvalue { ptr, i1 } %t30, i1 false, 1
  ret { ptr, i1 } %t31
b6:
  %p_6_0 = phi ptr [ %p_1_0, %edge_2 ]
  %t32 = insertvalue { ptr, i1 } zeroinitializer, ptr %p_6_0, 0
  %t33 = insertvalue { ptr, i1 } %t32, i1 true, 1
  ret { ptr, i1 } %t33
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b6
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b1
edge_6:
  br label %b5
}

define internal i64 @__hia_fn_1(ptr %p_0_0) {
b0:
  br label %edge_0
b1:
  %p_1_0 = phi ptr [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i64 [ 0, %edge_0 ], [ %t12, %edge_3 ]
  %t1 = call %hia.chain.result @__hia_chain_pop(ptr %p_1_0)
  %t2 = extractvalue %hia.chain.result %t1, 0
  %t3 = extractvalue %hia.chain.result %t1, 1
  %t4 = extractvalue %hia.chain.result %t1, 2
  br i1 %t4, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi ptr [ %t2, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t3, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_1, %edge_1 ]
  %t5 = extractvalue %hia.buffer %p_2_1, 0
  %t6 = extractvalue %hia.buffer %p_2_1, 1
  %t7 = icmp ult i64 0, %t6
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = getelementptr i8, ptr %t5, i64 0
  %t10 = load i8, ptr %t9, align 1
  %t11 = zext i8 %t10 to i64
  %t12 = add i64 %p_2_2, %t11
  %t13 = extractvalue %hia.buffer %p_2_1, 0
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %drop_nonnull_15, label %drop_after_15
drop_nonnull_15:
  call void @free(ptr %t13) nobuiltin
  br label %drop_after_15
drop_after_15:
  br label %edge_3
b3:
  %p_3_0 = phi ptr [ %t2, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t3, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_1, %edge_2 ]
  %t16 = extractvalue %hia.buffer %p_3_1, 0
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %drop_nonnull_18, label %drop_after_18
drop_nonnull_18:
  call void @free(ptr %t16) nobuiltin
  br label %drop_after_18
drop_after_18:
  call void @__hia_chain_drop(ptr %p_3_0)
  ret i64 %p_3_2
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal { i32, ptr, i64, i64 } @__hia_fn_2(ptr %p_0_0, i64 %p_0_1) {
b0:
  %t1 = call %hia.chain.result @__hia_chain_pop(ptr %p_0_0)
  %t2 = extractvalue %hia.chain.result %t1, 0
  %t3 = extractvalue %hia.chain.result %t1, 1
  %t4 = extractvalue %hia.chain.result %t1, 2
  br i1 %t4, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi ptr [ %t2, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %t3, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_1, %edge_0 ]
  %t5 = extractvalue %hia.buffer %p_1_1, 0
  %t6 = extractvalue %hia.buffer %p_1_1, 1
  %t7 = icmp ult i64 0, %t6
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = getelementptr i8, ptr %t5, i64 0
  %t10 = load i8, ptr %t9, align 1
  %t11 = extractvalue %hia.buffer %p_1_1, 0
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %drop_nonnull_13, label %drop_after_13
drop_nonnull_13:
  call void @free(ptr %t11) nobuiltin
  br label %drop_after_13
drop_after_13:
  %t14 = zext i8 %t10 to i64
  %t15 = add i64 %p_1_2, %t14
  %t16 = insertvalue { i32, ptr, i64, i64 } zeroinitializer, i32 0, 0
  %t17 = insertvalue { i32, ptr, i64, i64 } %t16, ptr %p_1_0, 1
  %t18 = insertvalue { i32, ptr, i64, i64 } %t17, i64 %t15, 2
  %t19 = insertvalue { i32, ptr, i64, i64 } %t18, i64 0, 3
  ret { i32, ptr, i64, i64 } %t19
b2:
  %p_2_0 = phi ptr [ %t2, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t3, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_1, %edge_1 ]
  call void @__hia_chain_drop(ptr %p_2_0)
  %t20 = extractvalue %hia.buffer %p_2_1, 0
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %drop_nonnull_22, label %drop_after_22
drop_nonnull_22:
  call void @free(ptr %t20) nobuiltin
  br label %drop_after_22
drop_after_22:
  %t23 = insertvalue { i32, ptr, i64, i64 } zeroinitializer, i32 1, 0
  %t24 = insertvalue { i32, ptr, i64, i64 } %t23, ptr null, 1
  %t25 = insertvalue { i32, ptr, i64, i64 } %t24, i64 0, 2
  %t26 = insertvalue { i32, ptr, i64, i64 } %t25, i64 %p_2_2, 3
  ret { i32, ptr, i64, i64 } %t26
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal void @__hia_fn_3(ptr %p_0_0, i64 %p_0_1) {
b0:
  call void @__hia_chain_drop(ptr %p_0_0)
  ret void
}

define internal i64 @__hia_fn_4(i64 %p_0_0, i8 %p_0_1) {
b0:
  %t1 = call { ptr, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { ptr, i1 } %t1, 0
  %t3 = extractvalue { ptr, i1 } %t1, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi ptr [ %t2, %edge_0 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi ptr [ %t2, %edge_1 ]
  %p_2_1 = phi i8 [ %p_0_1, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi i32 [ 0, %edge_2 ], [ 1, %edge_3 ]
  %p_3_1 = phi ptr [ %p_1_0, %edge_2 ], [ null, %edge_3 ]
  %p_3_2 = phi ptr [ null, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_3 = phi i8 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %t4 = icmp eq i32 %p_3_0, 0
  br i1 %t4, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i32 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi ptr [ %p_3_1, %edge_4 ]
  %p_4_2 = phi ptr [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i8 [ %p_3_3, %edge_4 ]
  call void @__hia_chain_drop(ptr %p_4_2)
  br label %edge_6
b5:
  %p_5_0 = phi i32 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi ptr [ %p_3_1, %edge_5 ]
  %p_5_2 = phi ptr [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i8 [ %p_3_3, %edge_5 ]
  %t5 = icmp eq i32 %p_5_0, 1
  br i1 %t5, label %edge_7, label %edge_8
b6:
  %p_6_0 = phi i32 [ %p_5_0, %edge_7 ]
  %p_6_1 = phi ptr [ %p_5_1, %edge_7 ]
  %p_6_2 = phi ptr [ %p_5_2, %edge_7 ]
  %p_6_3 = phi i8 [ %p_5_3, %edge_7 ]
  call void @__hia_chain_drop(ptr %p_6_1)
  br label %edge_9
b7:
  %p_7_0 = phi i32 [ %p_5_0, %edge_8 ]
  %p_7_1 = phi ptr [ %p_5_1, %edge_8 ]
  %p_7_2 = phi ptr [ %p_5_2, %edge_8 ]
  %p_7_3 = phi i8 [ %p_5_3, %edge_8 ]
  call void @abort()
  unreachable
b8:
  %p_8_0 = phi ptr [ %p_6_2, %edge_9 ]
  %p_8_1 = phi i8 [ %p_6_3, %edge_9 ]
  call void @__hia_chain_drop(ptr %p_8_0)
  ret i64 1000000
b9:
  %p_9_0 = phi ptr [ %p_4_1, %edge_6 ]
  %p_9_1 = phi i8 [ %p_4_3, %edge_6 ]
  %t6 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 0, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  %t11 = icmp eq i8 %p_9_1, 0
  br i1 %t11, label %edge_10, label %edge_11
b10:
  %p_10_0 = phi i8 [ 0, %edge_10 ]
  %p_10_1 = phi %hia.buffer [ %t10, %edge_10 ]
  %p_10_2 = phi ptr [ %p_9_0, %edge_10 ]
  %p_10_3 = phi i64 [ 0, %edge_10 ]
  %p_10_4 = phi i64 [ 0, %edge_10 ]
  %t12 = call { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_6(i8 %p_10_0, %hia.buffer %p_10_1, ptr %p_10_2, i64 %p_10_3, i64 %p_10_4)
  %t13 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t12, 0
  %t14 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t12, 1
  %t15 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t12, 2
  %t16 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t12, 3
  %t17 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t12, 4
  %t18 = call { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_6(i8 %t13, %hia.buffer %t14, ptr %t15, i64 %t16, i64 %t17)
  %t19 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t18, 0
  %t20 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t18, 1
  %t21 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t18, 2
  %t22 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t18, 3
  %t23 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t18, 4
  call void @__hia_fn_7(i8 %t19, %hia.buffer %t20, ptr %t21, i64 %t22, i64 %t23)
  ret i64 3000000
b11:
  %p_11_0 = phi i8 [ 0, %edge_11 ]
  %p_11_1 = phi %hia.buffer [ %t10, %edge_11 ]
  %p_11_2 = phi ptr [ %p_9_0, %edge_11 ]
  %p_11_3 = phi i64 [ 0, %edge_11 ]
  %p_11_4 = phi i64 [ 0, %edge_11 ]
  %p_11_5 = phi i8 [ %p_9_1, %edge_11 ]
  %t24 = call { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_8(i8 %p_11_0, %hia.buffer %p_11_1, ptr %p_11_2, i64 %p_11_3, i64 %p_11_4)
  %t25 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t24, 0
  %t26 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t24, 1
  %t27 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t24, 2
  %t28 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t24, 3
  %t29 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t24, 4
  %t30 = call { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_9(i8 %t25, %hia.buffer %t26, ptr %t27, i64 %t28, i64 %t29)
  %t31 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t30, 0
  %t32 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t30, 1
  %t33 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t30, 2
  %t34 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t30, 3
  %t35 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t30, 4
  %t36 = icmp eq i8 %p_11_5, 1
  br i1 %t36, label %edge_12, label %edge_13
b12:
  %p_12_0 = phi i8 [ %t31, %edge_12 ]
  %p_12_1 = phi %hia.buffer [ %t32, %edge_12 ]
  %p_12_2 = phi ptr [ %t33, %edge_12 ]
  %p_12_3 = phi i64 [ %t34, %edge_12 ]
  %p_12_4 = phi i64 [ %t35, %edge_12 ]
  %t37 = call { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_6(i8 %p_12_0, %hia.buffer %p_12_1, ptr %p_12_2, i64 %p_12_3, i64 %p_12_4)
  %t38 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t37, 0
  %t39 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t37, 1
  %t40 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t37, 2
  %t41 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t37, 3
  %t42 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t37, 4
  %t43 = icmp eq i8 %t38, 2
  br i1 %t43, label %edge_14, label %edge_15
b13:
  %p_13_0 = phi i8 [ %t38, %edge_15 ]
  %p_13_1 = phi %hia.buffer [ %t39, %edge_15 ]
  %p_13_2 = phi ptr [ %t40, %edge_15 ]
  %p_13_3 = phi i64 [ %t41, %edge_15 ]
  %p_13_4 = phi i64 [ %t42, %edge_15 ]
  call void @__hia_fn_7(i8 %p_13_0, %hia.buffer %p_13_1, ptr %p_13_2, i64 %p_13_3, i64 %p_13_4)
  ret i64 2000000
b14:
  %p_14_0 = phi i8 [ %t31, %edge_13 ], [ %t46, %edge_18 ]
  %p_14_1 = phi %hia.buffer [ %t32, %edge_13 ], [ %t47, %edge_18 ]
  %p_14_2 = phi ptr [ %t33, %edge_13 ], [ %t48, %edge_18 ]
  %p_14_3 = phi i64 [ %t34, %edge_13 ], [ %t49, %edge_18 ]
  %p_14_4 = phi i64 [ %t35, %edge_13 ], [ %t50, %edge_18 ]
  %t44 = icmp eq i8 %p_14_0, 2
  br i1 %t44, label %edge_16, label %edge_17
b15:
  %p_15_0 = phi i8 [ %p_14_0, %edge_17 ]
  %p_15_1 = phi %hia.buffer [ %p_14_1, %edge_17 ]
  %p_15_2 = phi ptr [ %p_14_2, %edge_17 ]
  %p_15_3 = phi i64 [ %p_14_3, %edge_17 ]
  %p_15_4 = phi i64 [ %p_14_4, %edge_17 ]
  %t45 = call { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_9(i8 %p_15_0, %hia.buffer %p_15_1, ptr %p_15_2, i64 %p_15_3, i64 %p_15_4)
  %t46 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t45, 0
  %t47 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t45, 1
  %t48 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t45, 2
  %t49 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t45, 3
  %t50 = extractvalue { i8, %hia.buffer, ptr, i64, i64 } %t45, 4
  br label %edge_18
b16:
  %p_16_0 = phi i8 [ %t38, %edge_14 ], [ %p_14_0, %edge_16 ]
  %p_16_1 = phi %hia.buffer [ %t39, %edge_14 ], [ %p_14_1, %edge_16 ]
  %p_16_2 = phi ptr [ %t40, %edge_14 ], [ %p_14_2, %edge_16 ]
  %p_16_3 = phi i64 [ %t41, %edge_14 ], [ %p_14_3, %edge_16 ]
  %p_16_4 = phi i64 [ %t42, %edge_14 ], [ %p_14_4, %edge_16 ]
  %t51 = call i64 @__hia_fn_10(i8 %p_16_0, %hia.buffer %p_16_1, ptr %p_16_2, i64 %p_16_3, i64 %p_16_4)
  ret i64 %t51
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b9
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b10
edge_11:
  br label %b11
edge_12:
  br label %b12
edge_13:
  br label %b14
edge_14:
  br label %b16
edge_15:
  br label %b13
edge_16:
  br label %b16
edge_17:
  br label %b15
edge_18:
  br label %b14
}

define internal i64 @__hia_fn_5(i64 %p_0_0) {
b0:
  %t1 = call { ptr, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { ptr, i1 } %t1, 0
  %t3 = extractvalue { ptr, i1 } %t1, 1
  %t4 = icmp eq ptr %t2, null
  br i1 %t4, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi ptr [ %t2, %edge_0 ]
  call void @__hia_chain_drop(ptr %p_1_0)
  ret i64 0
b2:
  %p_2_0 = phi ptr [ %t2, %edge_1 ]
  %t5 = icmp ne ptr %p_2_0, null
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = load %hia.buffer, ptr %p_2_0, align 8
  br label %edge_2
b3:
  %p_3_0 = phi ptr [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t7, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %t7, %edge_2 ]
  %t8 = extractvalue %hia.buffer %p_3_2, 0
  %t9 = extractvalue %hia.buffer %p_3_2, 1
  %t10 = icmp ult i64 0, %t9
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  %t12 = getelementptr i8, ptr %t8, i64 0
  %t13 = load i8, ptr %t12, align 1
  %t14 = extractvalue %hia.buffer %p_3_1, 0
  %t15 = extractvalue %hia.buffer %p_3_1, 1
  %t16 = icmp ult i64 0, %t15
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = getelementptr i8, ptr %t14, i64 0
  store i8 99, ptr %t18, align 1
  %t19 = call i64 @__hia_fn_1(ptr %p_3_0)
  ret i64 %t19
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
}

define internal { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_6(i8 %p_0_0, %hia.buffer %p_0_1, ptr %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp ult i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi ptr [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  call void @__hia_fn_3(ptr %p_1_2, i64 %p_1_3)
  %t2 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } zeroinitializer, i8 3, 0
  %t3 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t2, %hia.buffer %p_1_1, 1
  %t4 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t3, ptr null, 2
  %t5 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t4, i64 0, 3
  %t6 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t5, i64 0, 4
  ret { i8, %hia.buffer, ptr, i64, i64 } %t6
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi ptr [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %t7 = icmp ule i8 %p_2_0, 3
  br i1 %t7, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_2 = phi ptr [ %p_2_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_2_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_2 ]
  %t8 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } zeroinitializer, i8 %p_3_0, 0
  %t9 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t8, %hia.buffer %p_3_1, 1
  %t10 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t9, ptr %p_3_2, 2
  %t11 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t10, i64 %p_3_3, 3
  %t12 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t11, i64 %p_3_4, 4
  ret { i8, %hia.buffer, ptr, i64, i64 } %t12
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_2 = phi ptr [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal void @__hia_fn_7(i8 %p_0_0, %hia.buffer %p_0_1, ptr %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 3
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi ptr [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  call void @free(ptr %t2) nobuiltin
  br label %drop_after_4
drop_after_4:
  call void @__hia_chain_drop(ptr %p_1_2)
  ret void
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi ptr [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_8(i8 %p_0_0, %hia.buffer %p_0_1, ptr %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi ptr [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } zeroinitializer, i8 1, 0
  %t3 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t2, %hia.buffer %p_1_1, 1
  %t4 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t3, ptr %p_1_2, 2
  %t5 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t4, i64 %p_1_3, 3
  %t6 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t5, i64 %p_1_4, 4
  ret { i8, %hia.buffer, ptr, i64, i64 } %t6
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi ptr [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, ptr, i64, i64 } @__hia_fn_9(i8 %p_0_0, %hia.buffer %p_0_1, ptr %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 1
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi ptr [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = call { i32, ptr, i64, i64 } @__hia_fn_2(ptr %p_1_2, i64 %p_1_3)
  %t3 = extractvalue { i32, ptr, i64, i64 } %t2, 0
  %t4 = extractvalue { i32, ptr, i64, i64 } %t2, 1
  %t5 = extractvalue { i32, ptr, i64, i64 } %t2, 2
  %t6 = extractvalue { i32, ptr, i64, i64 } %t2, 3
  %t7 = icmp ule i32 %t3, 1
  br i1 %t7, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_1_1, %edge_2 ]
  %p_2_1 = phi i32 [ %t3, %edge_2 ]
  %p_2_2 = phi ptr [ %t4, %edge_2 ]
  %p_2_3 = phi i64 [ %t5, %edge_2 ]
  %p_2_4 = phi i64 [ %t6, %edge_2 ]
  %t8 = icmp eq i32 %p_2_1, 1
  %t9 = select i1 %t8, i8 2, i8 1
  %t10 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } zeroinitializer, i8 %t9, 0
  %t11 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t10, %hia.buffer %p_2_0, 1
  %t12 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t11, ptr %p_2_2, 2
  %t13 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t12, i64 %p_2_3, 3
  %t14 = insertvalue { i8, %hia.buffer, ptr, i64, i64 } %t13, i64 %p_2_4, 4
  ret { i8, %hia.buffer, ptr, i64, i64 } %t14
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_1, %edge_3 ]
  %p_3_1 = phi i32 [ %t3, %edge_3 ]
  %p_3_2 = phi ptr [ %t4, %edge_3 ]
  %p_3_3 = phi i64 [ %t5, %edge_3 ]
  %p_3_4 = phi i64 [ %t6, %edge_3 ]
  call void @abort()
  unreachable
b4:
  %p_4_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_4_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_4_2 = phi ptr [ %p_0_2, %edge_1 ]
  %p_4_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_4_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b4
edge_2:
  br label %b2
edge_3:
  br label %b3
}

define internal i64 @__hia_fn_10(i8 %p_0_0, %hia.buffer %p_0_1, ptr %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi ptr [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  call void @free(ptr %t2) nobuiltin
  br label %drop_after_4
drop_after_4:
  call void @__hia_chain_drop(ptr %p_1_2)
  ret i64 %p_1_4
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi ptr [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define i64 @chain_task(i64 %a0, i8 zeroext %a1) {
entry:
  %result = call i64 @__hia_fn_4(i64 %a0, i8 %a1)
  ret i64 %result
}

define i64 @chain_stored_loan(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_5(i64 %a0)
  ret i64 %result
}
