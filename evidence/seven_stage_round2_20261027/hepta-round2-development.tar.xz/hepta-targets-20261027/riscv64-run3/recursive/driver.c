/* Finite RV64GC / LP64D Linux userspace qualification runtime.
 * 64 independent 4096-byte slots, no concurrency, realloc or production claim.
 * This code runs under QEMU; it is not physical-board or device evidence.
 */
typedef __SIZE_TYPE__ hepta_size;
typedef __UINT8_TYPE__ hepta_u8;
typedef __UINT32_TYPE__ hepta_u32;
typedef __UINT64_TYPE__ hepta_u64;
typedef __UINTPTR_TYPE__ hepta_uintptr;
#if !defined(__riscv) || __riscv_xlen != 64 || !defined(__riscv_float_abi_double)
#error requires RV64 LP64D
#endif
#if !defined(__BYTE_ORDER__) || __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error requires little endian
#endif
_Static_assert(__CHAR_BIT__ == 8 && sizeof(void *) == 8 && sizeof(hepta_size) == 8,
               "strict LP64 test ABI");
#define HEPTA_CAPACITY 4096u
#define HEPTA_SLOTS 64u
static _Alignas(16) hepta_u8 arenas[HEPTA_SLOTS][HEPTA_CAPACITY];
static volatile hepta_u8 occupied[HEPTA_SLOTS];
static volatile hepta_u32 failure_countdown;
static volatile hepta_u32 peak_outstanding, outstanding;
static volatile hepta_u32 successful_allocations, releases, denied_allocations;
static volatile hepta_u32 null_frees;

__attribute__((noreturn)) static void hepta_exit(hepta_u32 code) {
    register long a0 __asm__("a0") = (long)code;
    register long a7 __asm__("a7") = 93;
    __asm__ volatile("ecall" : : "r"(a0), "r"(a7) : "memory");
    __builtin_unreachable();
}
__attribute__((noreturn)) void abort(void) { hepta_exit(134); }
__attribute__((noinline)) void *malloc(hepta_size n) {
    if (failure_countdown && --failure_countdown == 0) {
        ++denied_allocations;
        return (void *)0;
    }
    if (n == 0 || n > HEPTA_CAPACITY) {
        ++denied_allocations;
        return (void *)0;
    }
    for (hepta_size i = 0; i < HEPTA_SLOTS; ++i) {
        if (!occupied[i]) {
            occupied[i] = 1;
            ++outstanding;
            if (outstanding > peak_outstanding) peak_outstanding = outstanding;
            ++successful_allocations;
            return (void *)arenas[i];
        }
    }
    ++denied_allocations;
    return (void *)0;
}
__attribute__((noinline)) void free(void *p) {
    if (!p) { ++null_frees; return; }
    for (hepta_size i = 0; i < HEPTA_SLOTS; ++i) {
        if (p == (void *)arenas[i]) {
            if (!occupied[i] || !outstanding) abort();
            occupied[i] = 0;
            --outstanding;
            ++releases;
            return;
        }
    }
    abort();
}
__attribute__((noinline)) void *memset(void *destination, int value, hepta_size n) {
    hepta_u8 *p = (hepta_u8 *)destination;
    for (hepta_size i = 0; i < n; ++i) p[i] = (hepta_u8)value;
    return destination;
}
__attribute__((noinline)) void *calloc(hepta_size count, hepta_size width) {
    if (width && count > ((hepta_size)-1) / width) {
        ++denied_allocations;
        return (void *)0;
    }
    hepta_size bytes = count * width;
    void *p = malloc(bytes);
    if (p) memset(p, 0, bytes);
    return p;
}
__attribute__((noinline)) void *memcpy(void *destination, const void *source, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)destination;
    const hepta_u8 *s = (const hepta_u8 *)source;
    for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    return destination;
}
__attribute__((noinline)) void *memmove(void *destination, const void *source, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)destination;
    const hepta_u8 *s = (const hepta_u8 *)source;
    if (d == s || !n) return destination;
    if ((hepta_uintptr)d < (hepta_uintptr)s) {
        for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    } else {
        for (hepta_size i = n; i; --i) d[i - 1] = s[i - 1];
    }
    return destination;
}
static int memory_primitives_ok(void) {
    hepta_u8 a[8], b[8];
    memset(a, 0, 8);
    for (hepta_size i = 0; i < 8; ++i) a[i] = (hepta_u8)(i + 1);
    memcpy(b, a, 8);
    memmove(b + 1, b, 7);
    for (hepta_size i = 0; i < 7; ++i) if (b[i + 1] != a[i]) return 0;
    memmove(b, b + 1, 7);
    for (hepta_size i = 0; i < 7; ++i) if (b[i] != a[i]) return 0;
    memmove(b, a, 8);
    for (hepta_size i = 0; i < 8; ++i) if (b[i] != a[i]) return 0;
    return 1;
}
static void write_values(const char *prefix, const hepta_u64 *values, hepta_size count) {
    char text[256];
    hepta_size used = 0;
    while (*prefix) text[used++] = *prefix++;
    for (hepta_size i = 0; i < count; ++i) {
        char digits[20];
        hepta_size n = 0;
        hepta_u64 value = values[i];
        do { digits[n++] = (char)('0' + value % 10); value /= 10; } while (value);
        while (n) text[used++] = digits[--n];
        text[used++] = i + 1 == count ? '\n' : ' ';
    }
    register long a0 __asm__("a0") = 1;
    register const char *a1 __asm__("a1") = text;
    register hepta_size a2 __asm__("a2") = used;
    register long a7 __asm__("a7") = 64;
    __asm__ volatile("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a7) : "memory");
    if (a0 != (long)used) hepta_exit(90);
}
static void write_resources(void) {
    hepta_u64 values[] = {successful_allocations, releases, outstanding,
                         denied_allocations, peak_outstanding};
    write_values("HIA_RISCV64 resources ", values, 5);
}

extern unsigned long long chain_checksum(__SIZE_TYPE__);
extern _Bool chain_cancel(__SIZE_TYPE__);
extern unsigned long long chain_head_update(__SIZE_TYPE__);
extern _Bool chain_empty_pop(void);
extern unsigned char chain_empty_head(void);
extern _Bool chain_empty_payloads(__SIZE_TYPE__);
extern unsigned long long chain_recover(__SIZE_TYPE__);
extern unsigned long long chain_task(__SIZE_TYPE__, unsigned char);
extern unsigned long long chain_stored_loan(__SIZE_TYPE__);
__attribute__((noreturn)) void _start(void) {
    if (!memory_primitives_ok()) hepta_exit(39);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer0 = chain_checksum(0);
    hepta_u64 row0[] = {0, answer0, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row0, 7);
    if (answer0 != 0ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 0 || successful_allocations != 0 || releases != 0 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer1 = chain_checksum(1);
    hepta_u64 row1[] = {1, answer1, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row1, 7);
    if (answer1 != 0ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 2 || successful_allocations != 2 || releases != 2 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer2 = chain_checksum(17);
    hepta_u64 row2[] = {2, answer2, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row2, 7);
    if (answer2 != 136ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 34 || successful_allocations != 34 || releases != 34 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer3 = chain_checksum(32);
    hepta_u64 row3[] = {3, answer3, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row3, 7);
    if (answer3 != 496ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 64 || successful_allocations != 64 || releases != 64 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer4 = chain_cancel(32);
    hepta_u64 row4[] = {4, answer4, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row4, 7);
    if (answer4 != 1ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 64 || successful_allocations != 64 || releases != 64 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer5 = chain_head_update(17);
    hepta_u64 row5[] = {5, answer5, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row5, 7);
    if (answer5 != 375ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 34 || successful_allocations != 34 || releases != 34 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 1;
    hepta_u64 answer6 = chain_checksum(17);
    hepta_u64 row6[] = {6, answer6, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row6, 7);
    if (answer6 != 1000000ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 1 || successful_allocations != 0 || releases != 0 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 2;
    hepta_u64 answer7 = chain_checksum(17);
    hepta_u64 row7[] = {7, answer7, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row7, 7);
    if (answer7 != 1000000ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 2 || successful_allocations != 1 || releases != 1 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 17;
    hepta_u64 answer8 = chain_checksum(17);
    hepta_u64 row8[] = {8, answer8, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row8, 7);
    if (answer8 != 1000028ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 17 || successful_allocations != 16 || releases != 16 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 18;
    hepta_u64 answer9 = chain_checksum(17);
    hepta_u64 row9[] = {9, answer9, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row9, 7);
    if (answer9 != 1000028ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 18 || successful_allocations != 17 || releases != 17 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer10 = chain_recover(17);
    hepta_u64 row10[] = {10, answer10, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row10, 7);
    if (answer10 != 209ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 36 || successful_allocations != 36 || releases != 36 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 36;
    hepta_u64 answer11 = chain_recover(17);
    hepta_u64 row11[] = {11, answer11, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row11, 7);
    if (answer11 != 1000209ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 36 || successful_allocations != 35 || releases != 35 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer12 = chain_empty_payloads(17);
    hepta_u64 row12[] = {12, answer12, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row12, 7);
    if (answer12 != 1ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 17 || successful_allocations != 17 || releases != 17 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 3;
    hepta_u64 answer13 = chain_empty_payloads(17);
    hepta_u64 row13[] = {13, answer13, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row13, 7);
    if (answer13 != 0ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 3 || successful_allocations != 2 || releases != 2 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer14 = chain_empty_pop();
    hepta_u64 row14[] = {14, answer14, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row14, 7);
    if (answer14 != 0ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 0 || successful_allocations != 0 || releases != 0 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer15 = chain_stored_loan(17);
    hepta_u64 row15[] = {15, answer15, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row15, 7);
    if (answer15 != 219ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 34 || successful_allocations != 34 || releases != 34 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 18;
    hepta_u64 answer16 = chain_stored_loan(17);
    hepta_u64 row16[] = {16, answer16, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row16, 7);
    if (answer16 != 120ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 18 || successful_allocations != 17 || releases != 17 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer17 = chain_task(17, 0);
    hepta_u64 row17[] = {17, answer17, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row17, 7);
    if (answer17 != 3000000ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 34 || successful_allocations != 34 || releases != 34 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer18 = chain_task(17, 1);
    hepta_u64 row18[] = {18, answer18, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row18, 7);
    if (answer18 != 2000000ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 34 || successful_allocations != 34 || releases != 34 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 0;
    hepta_u64 answer19 = chain_task(17, 2);
    hepta_u64 row19[] = {19, answer19, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row19, 7);
    if (answer19 != 136ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 34 || successful_allocations != 34 || releases != 34 || outstanding || null_frees) hepta_exit(92);
    if (outstanding) {write_resources(); hepta_exit(91);}
    successful_allocations = releases = denied_allocations = peak_outstanding = null_frees = 0;
    failure_countdown = 18;
    hepta_u64 answer20 = chain_task(17, 2);
    hepta_u64 row20[] = {20, answer20, successful_allocations + denied_allocations, successful_allocations, releases, outstanding, null_frees};
    write_values("HIA_RISCV64 chain ", row20, 7);
    if (answer20 != 1000000ULL) hepta_exit(41);
    if (successful_allocations + denied_allocations != 18 || successful_allocations != 17 || releases != 17 || outstanding || null_frees) hepta_exit(92);
    hepta_exit(0);
}
