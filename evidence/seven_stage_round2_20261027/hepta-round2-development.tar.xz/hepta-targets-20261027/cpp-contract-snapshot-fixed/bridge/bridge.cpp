// Generated bridge: foreign code and caller pointers remain unverified.
#include "bridge.h"
#include "/tmp/hepta-targets-20261027/cpp-contract-snapshot-fixed/foreign.hpp"
#include <cstdint>
#include <cstddef>
#include <type_traits>
#include <span>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <limits>
#include <utility>
#include <atomic>
namespace {
std::atomic<std::uint64_t> hepta_cpp_composed_next_handle{1};
std::uint64_t hepta_cpp_composed_allocate_handle() noexcept {
    auto current = hepta_cpp_composed_next_handle.load(std::memory_order_relaxed);
    while (current) {
        if (hepta_cpp_composed_next_handle.compare_exchange_weak(current, current + 1, std::memory_order_relaxed)) return current;
    }
    return 0;
}
[[maybe_unused]] const std::shared_ptr<const std::uint8_t>& hepta_cpp_composed_thread_token() {
    // A retained token distinguishes thread instances even when std::thread::id is reused.
    static thread_local const auto token = std::make_shared<const std::uint8_t>(0);
    return token;
}
}
namespace {
using hepta_cpp_composed_Vector_object = std::vector<std::int64_t>;
static_assert(std::is_nothrow_destructible_v<std::vector<std::int64_t>>);
struct hepta_cpp_composed_Vector_entry { std::recursive_mutex mutex; std::shared_ptr<std::vector<std::int64_t>> object; std::shared_ptr<const std::uint8_t> creator; unsigned active = 0; };
struct hepta_cpp_composed_Vector_registry { std::mutex mutex; std::unordered_map<std::uint64_t, std::shared_ptr<hepta_cpp_composed_Vector_entry>> objects; };
// Process-lifetime registry avoids destroying abandoned affine objects on an arbitrary shutdown thread.
hepta_cpp_composed_Vector_registry& hepta_cpp_composed_Vector_registry_get() { static auto* r = new hepta_cpp_composed_Vector_registry; return *r; }
struct hepta_cpp_composed_Vector_active { hepta_cpp_composed_Vector_entry& e; explicit hepta_cpp_composed_Vector_active(hepta_cpp_composed_Vector_entry& v): e(v) { ++e.active; } ~hepta_cpp_composed_Vector_active() { --e.active; } };
}
static_assert(std::is_constructible_v<std::vector<std::int64_t>, std::size_t, std::int64_t>);
extern "C" std::int32_t hepta_cpp_composed_Vector_filled(std::size_t hepta_arg0, std::int64_t hepta_arg1, std::uint64_t* out) noexcept {
    if (!out) return 1;
    if (reinterpret_cast<std::uintptr_t>(out) % alignof(std::uint64_t)) return 8;
    try {
        auto entry = std::make_shared<hepta_cpp_composed_Vector_entry>();
        entry->object = std::make_shared<std::vector<std::int64_t>>(static_cast<std::size_t>(hepta_arg0), static_cast<std::int64_t>(hepta_arg1));
        auto handle = hepta_cpp_composed_allocate_handle();
        if (!handle) return 4;
        auto& registry = hepta_cpp_composed_Vector_registry_get();
        std::lock_guard<std::mutex> lock(registry.mutex);
        if (!registry.objects.emplace(handle, entry).second) return 4;
        *out = handle;
        return 0;
    } catch (...) { return 3; }
}
extern "C" std::int32_t hepta_cpp_composed_Vector_destroy(std::uint64_t handle) noexcept {
    try {
        auto& registry = hepta_cpp_composed_Vector_registry_get();
        std::shared_ptr<hepta_cpp_composed_Vector_entry> entry;
        {
            std::lock_guard<std::mutex> lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end()) return 2;
            entry = it->second;
        }
        std::lock_guard<std::recursive_mutex> lock(entry->mutex);
        if (!entry->object) return 2;
        if (entry->active) return 6;
        {
            std::lock_guard<std::mutex> registry_lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end() || it->second != entry) return 2;
            registry.objects.erase(it);
        }
        entry->object.reset();
        return 0;
    } catch (...) { return 3; }
}
static_assert(std::is_reference_v<decltype(std::declval<const std::vector<std::int64_t>&>().at(std::declval<std::size_t>()))> && std::is_same_v<std::remove_cvref_t<decltype(std::declval<const std::vector<std::int64_t>&>().at(std::declval<std::size_t>()))>, std::int64_t>);
extern "C" std::int32_t hepta_cpp_composed_Vector_at(std::uint64_t handle, std::size_t hepta_arg0, std::int64_t* out) noexcept {
    if (!out) return 1;
    if (reinterpret_cast<std::uintptr_t>(out) % alignof(std::int64_t)) return 8;
    try {
        auto& registry = hepta_cpp_composed_Vector_registry_get();
        std::shared_ptr<hepta_cpp_composed_Vector_entry> entry;
        {
            std::lock_guard<std::mutex> lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end()) return 2;
            entry = it->second;
        }
        std::lock_guard<std::recursive_mutex> lock(entry->mutex);
        if (!entry->object) return 2;
        if (entry->active) return 6;
        auto object = entry->object;
        hepta_cpp_composed_Vector_active active(*entry);
        const std::vector<std::int64_t>& receiver = *object;
        auto result = receiver.at(static_cast<std::size_t>(hepta_arg0));
        *out = result;
        return 0;
    } catch (...) { return 3; }
}
static_assert(std::is_same_v<decltype(std::declval<std::vector<std::int64_t>&>().push_back(std::declval<const std::int64_t&>())), void>);
extern "C" std::int32_t hepta_cpp_composed_Vector_append(std::uint64_t handle, std::int64_t hepta_arg0) noexcept {
    try {
        auto& registry = hepta_cpp_composed_Vector_registry_get();
        std::shared_ptr<hepta_cpp_composed_Vector_entry> entry;
        {
            std::lock_guard<std::mutex> lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end()) return 2;
            entry = it->second;
        }
        std::lock_guard<std::recursive_mutex> lock(entry->mutex);
        if (!entry->object) return 2;
        if (entry->active) return 6;
        auto object = entry->object;
        hepta_cpp_composed_Vector_active active(*entry);
        std::vector<std::int64_t>& receiver = *object;
        receiver.push_back(static_cast<const std::int64_t&>(hepta_arg0));
        return 0;
    } catch (...) { return 3; }
}
namespace {
using hepta_cpp_composed_Deque_object = std::deque<std::int64_t>;
static_assert(std::is_nothrow_destructible_v<std::deque<std::int64_t>>);
struct hepta_cpp_composed_Deque_entry { std::recursive_mutex mutex; std::shared_ptr<std::deque<std::int64_t>> object; std::shared_ptr<const std::uint8_t> creator; unsigned active = 0; };
struct hepta_cpp_composed_Deque_registry { std::mutex mutex; std::unordered_map<std::uint64_t, std::shared_ptr<hepta_cpp_composed_Deque_entry>> objects; };
// Process-lifetime registry avoids destroying abandoned affine objects on an arbitrary shutdown thread.
hepta_cpp_composed_Deque_registry& hepta_cpp_composed_Deque_registry_get() { static auto* r = new hepta_cpp_composed_Deque_registry; return *r; }
struct hepta_cpp_composed_Deque_active { hepta_cpp_composed_Deque_entry& e; explicit hepta_cpp_composed_Deque_active(hepta_cpp_composed_Deque_entry& v): e(v) { ++e.active; } ~hepta_cpp_composed_Deque_active() { --e.active; } };
}
static_assert(std::is_constructible_v<std::deque<std::int64_t>, std::size_t, std::int64_t>);
extern "C" std::int32_t hepta_cpp_composed_Deque_filled(std::size_t hepta_arg0, std::int64_t hepta_arg1, std::uint64_t* out) noexcept {
    if (!out) return 1;
    if (reinterpret_cast<std::uintptr_t>(out) % alignof(std::uint64_t)) return 8;
    try {
        auto entry = std::make_shared<hepta_cpp_composed_Deque_entry>();
        entry->object = std::make_shared<std::deque<std::int64_t>>(static_cast<std::size_t>(hepta_arg0), static_cast<std::int64_t>(hepta_arg1));
        auto handle = hepta_cpp_composed_allocate_handle();
        if (!handle) return 4;
        auto& registry = hepta_cpp_composed_Deque_registry_get();
        std::lock_guard<std::mutex> lock(registry.mutex);
        if (!registry.objects.emplace(handle, entry).second) return 4;
        *out = handle;
        return 0;
    } catch (...) { return 3; }
}
extern "C" std::int32_t hepta_cpp_composed_Deque_destroy(std::uint64_t handle) noexcept {
    try {
        auto& registry = hepta_cpp_composed_Deque_registry_get();
        std::shared_ptr<hepta_cpp_composed_Deque_entry> entry;
        {
            std::lock_guard<std::mutex> lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end()) return 2;
            entry = it->second;
        }
        std::lock_guard<std::recursive_mutex> lock(entry->mutex);
        if (!entry->object) return 2;
        if (entry->active) return 6;
        {
            std::lock_guard<std::mutex> registry_lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end() || it->second != entry) return 2;
            registry.objects.erase(it);
        }
        entry->object.reset();
        return 0;
    } catch (...) { return 3; }
}
static_assert(std::is_reference_v<decltype(std::declval<const std::deque<std::int64_t>&>().at(std::declval<std::size_t>()))> && std::is_same_v<std::remove_cvref_t<decltype(std::declval<const std::deque<std::int64_t>&>().at(std::declval<std::size_t>()))>, std::int64_t>);
extern "C" std::int32_t hepta_cpp_composed_Deque_at(std::uint64_t handle, std::size_t hepta_arg0, std::int64_t* out) noexcept {
    if (!out) return 1;
    if (reinterpret_cast<std::uintptr_t>(out) % alignof(std::int64_t)) return 8;
    try {
        auto& registry = hepta_cpp_composed_Deque_registry_get();
        std::shared_ptr<hepta_cpp_composed_Deque_entry> entry;
        {
            std::lock_guard<std::mutex> lock(registry.mutex);
            auto it = registry.objects.find(handle);
            if (it == registry.objects.end()) return 2;
            entry = it->second;
        }
        std::lock_guard<std::recursive_mutex> lock(entry->mutex);
        if (!entry->object) return 2;
        if (entry->active) return 6;
        auto object = entry->object;
        hepta_cpp_composed_Deque_active active(*entry);
        const std::deque<std::int64_t>& receiver = *object;
        auto result = receiver.at(static_cast<std::size_t>(hepta_arg0));
        *out = result;
        return 0;
    } catch (...) { return 3; }
}
extern "C" std::int32_t hepta_cpp_composed_vector_deque(std::size_t hepta_arg0, std::int64_t hepta_arg1, std::int64_t hepta_arg2, std::size_t hepta_arg3, std::size_t hepta_arg4, std::size_t hepta_arg5, std::int64_t* out) noexcept {
    if (!out) return 1;
    if (reinterpret_cast<std::uintptr_t>(out) % alignof(std::int64_t)) return 8;
    try {
        auto hepta_pipeline_result = [&]() -> std::int64_t {
            auto hepta_pipeline_object0 = std::vector<std::int64_t>(static_cast<std::size_t>(hepta_arg0), static_cast<std::int64_t>(hepta_arg1));
            (void)static_cast<std::vector<std::int64_t>&>(hepta_pipeline_object0).push_back(static_cast<const std::int64_t&>(hepta_arg2));
            const std::int64_t hepta_pipeline_value2 = static_cast<const std::vector<std::int64_t>&>(hepta_pipeline_object0).at(static_cast<std::size_t>(hepta_arg3));
            auto hepta_pipeline_object1 = std::deque<std::int64_t>(static_cast<std::size_t>(hepta_arg4), static_cast<std::int64_t>(hepta_pipeline_value2));
            const std::int64_t hepta_pipeline_value4 = static_cast<const std::deque<std::int64_t>&>(hepta_pipeline_object1).at(static_cast<std::size_t>(hepta_arg5));
            return hepta_pipeline_value4;
        }();
        *out = hepta_pipeline_result;
        return 0;
    } catch (...) { return 3; }
}
