/* Finite RV64GC / LP64D Linux userspace qualification runtime.
 * 64 independent 4096-byte slots, no concurrency, realloc or production claim.
 * This code runs under QEMU; it is not physical-board or device evidence.
 */
typedef __SIZE_TYPE__ hepta_size;
typedef __UINT8_TYPE__ hepta_u8;
typedef __UINT32_TYPE__ hepta_u32;
typedef __UINT64_TYPE__ hepta_u64;
typedef __UINTPTR_TYPE__ hepta_uintptr;
#if !defined(__riscv) || __riscv_xlen != 64 || !defined(__riscv_float_abi_double)
#error requires RV64 LP64D
#endif
#if !defined(__BYTE_ORDER__) || __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error requires little endian
#endif
_Static_assert(__CHAR_BIT__ == 8 && sizeof(void *) == 8 && sizeof(hepta_size) == 8,
               "strict LP64 test ABI");
#define HEPTA_CAPACITY 4096u
#define HEPTA_SLOTS 64u
static _Alignas(16) hepta_u8 arenas[HEPTA_SLOTS][HEPTA_CAPACITY];
static volatile hepta_u8 occupied[HEPTA_SLOTS];
static volatile hepta_u32 failure_countdown;
static volatile hepta_u32 peak_outstanding, outstanding;
static volatile hepta_u32 successful_allocations, releases, denied_allocations;

__attribute__((noreturn)) static void hepta_exit(hepta_u32 code) {
    register long a0 __asm__("a0") = (long)code;
    register long a7 __asm__("a7") = 93;
    __asm__ volatile("ecall" : : "r"(a0), "r"(a7) : "memory");
    __builtin_unreachable();
}
__attribute__((noreturn)) void abort(void) { hepta_exit(134); }
__attribute__((noinline)) void *malloc(hepta_size n) {
    if (failure_countdown && --failure_countdown == 0) {
        ++denied_allocations;
        return (void *)0;
    }
    if (n == 0 || n > HEPTA_CAPACITY) {
        ++denied_allocations;
        return (void *)0;
    }
    for (hepta_size i = 0; i < HEPTA_SLOTS; ++i) {
        if (!occupied[i]) {
            occupied[i] = 1;
            ++outstanding;
            if (outstanding > peak_outstanding) peak_outstanding = outstanding;
            ++successful_allocations;
            return (void *)arenas[i];
        }
    }
    ++denied_allocations;
    return (void *)0;
}
__attribute__((noinline)) void free(void *p) {
    if (!p) return;
    for (hepta_size i = 0; i < HEPTA_SLOTS; ++i) {
        if (p == (void *)arenas[i]) {
            if (!occupied[i] || !outstanding) abort();
            occupied[i] = 0;
            --outstanding;
            ++releases;
            return;
        }
    }
    abort();
}
__attribute__((noinline)) void *memset(void *destination, int value, hepta_size n) {
    hepta_u8 *p = (hepta_u8 *)destination;
    for (hepta_size i = 0; i < n; ++i) p[i] = (hepta_u8)value;
    return destination;
}
__attribute__((noinline)) void *calloc(hepta_size count, hepta_size width) {
    if (width && count > ((hepta_size)-1) / width) {
        ++denied_allocations;
        return (void *)0;
    }
    hepta_size bytes = count * width;
    void *p = malloc(bytes);
    if (p) memset(p, 0, bytes);
    return p;
}
__attribute__((noinline)) void *memcpy(void *destination, const void *source, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)destination;
    const hepta_u8 *s = (const hepta_u8 *)source;
    for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    return destination;
}
__attribute__((noinline)) void *memmove(void *destination, const void *source, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)destination;
    const hepta_u8 *s = (const hepta_u8 *)source;
    if (d == s || !n) return destination;
    if ((hepta_uintptr)d < (hepta_uintptr)s) {
        for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    } else {
        for (hepta_size i = n; i; --i) d[i - 1] = s[i - 1];
    }
    return destination;
}
static int memory_primitives_ok(void) {
    hepta_u8 a[8], b[8];
    memset(a, 0, 8);
    for (hepta_size i = 0; i < 8; ++i) a[i] = (hepta_u8)(i + 1);
    memcpy(b, a, 8);
    memmove(b + 1, b, 7);
    for (hepta_size i = 0; i < 7; ++i) if (b[i + 1] != a[i]) return 0;
    memmove(b, b + 1, 7);
    for (hepta_size i = 0; i < 7; ++i) if (b[i] != a[i]) return 0;
    memmove(b, a, 8);
    for (hepta_size i = 0; i < 8; ++i) if (b[i] != a[i]) return 0;
    return 1;
}
static void write_values(const char *prefix, const hepta_u64 *values, hepta_size count) {
    char text[256];
    hepta_size used = 0;
    while (*prefix) text[used++] = *prefix++;
    for (hepta_size i = 0; i < count; ++i) {
        char digits[20];
        hepta_size n = 0;
        hepta_u64 value = values[i];
        do { digits[n++] = (char)('0' + value % 10); value /= 10; } while (value);
        while (n) text[used++] = digits[--n];
        text[used++] = i + 1 == count ? '\n' : ' ';
    }
    register long a0 __asm__("a0") = 1;
    register const char *a1 __asm__("a1") = text;
    register hepta_size a2 __asm__("a2") = used;
    register long a7 __asm__("a7") = 64;
    __asm__ volatile("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a7) : "memory");
    if (a0 != (long)used) hepta_exit(90);
}
static void write_resources(void) {
    hepta_u64 values[] = {successful_allocations, releases, outstanding,
                         denied_allocations, peak_outstanding};
    write_values("HIA_RISCV64 resources ", values, 5);
}

extern signed char abi_i8(signed char);
extern unsigned char abi_u8(unsigned char);
extern short abi_i16(short);
extern unsigned short abi_u16(unsigned short);
extern int abi_i32(int);
extern unsigned int abi_u32(unsigned int);
extern long long abi_i64(long long);
extern unsigned long long abi_u64(unsigned long long);
extern __PTRDIFF_TYPE__ abi_isize(__PTRDIFF_TYPE__);
extern __SIZE_TYPE__ abi_usize(__SIZE_TYPE__);
extern _Bool abi_bool(_Bool);
extern unsigned int abi_stack12(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int);
extern hepta_u8 aggregate_bulk(hepta_size,hepta_size,hepta_size,hepta_u8,hepta_size);
extern unsigned long long raw_u32(unsigned int);
__asm__(".text\n.globl raw_u32\n.type raw_u32,@function\nraw_u32:\naddi sp,sp,-16\nsd ra,8(sp)\ncall abi_u32\nld ra,8(sp)\naddi sp,sp,16\nret\n.size raw_u32,.-raw_u32\n");
extern unsigned long long raw_i8(signed char);
__asm__(".text\n.globl raw_i8\n.type raw_i8,@function\nraw_i8:\naddi sp,sp,-16\nsd ra,8(sp)\ncall abi_i8\nld ra,8(sp)\naddi sp,sp,16\nret\n.size raw_i8,.-raw_i8\n");
extern unsigned long long raw_u8(unsigned char);
__asm__(".text\n.globl raw_u8\n.type raw_u8,@function\nraw_u8:\naddi sp,sp,-16\nsd ra,8(sp)\ncall abi_u8\nld ra,8(sp)\naddi sp,sp,16\nret\n.size raw_u8,.-raw_u8\n");
__attribute__((noreturn)) void _start(void) {
    if (!memory_primitives_ok()) hepta_exit(39);
    (void)aggregate_bulk(5,4,2,7,0);
    write_resources();
    hepta_exit(99);
}
