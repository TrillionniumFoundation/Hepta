"""Independent real-render / real-native-compiler contract snapshot witness."""
import argparse
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, '/workspace/scratch/1e9cfaeb170c/hepta-work')
from hepta.cpp_contracts import _Generator, _validate, bridge_cpp_contracts
from tests.test_cpp_pipelines import contract

parser = argparse.ArgumentParser()
parser.add_argument('directory', type=Path)
args = parser.parse_args()
root = args.directory
root.mkdir()
header = root / 'foreign.hpp'
header.write_text('#pragma once\n#include <cstdint>\n#include <vector>\n#include <deque>\n')
candidate = contract()
original = deepcopy(candidate)
canonical = lambda x: json.dumps(x, sort_keys=True, separators=(',', ':')).encode()
identity = lambda x: sha256(canonical(x)).hexdigest()
render = _Generator.render
checked_bytes = {}

def mutate_after_real_render(generator):
    rendered = render(generator)
    checked_bytes['cpp_sha256'] = sha256(rendered[0].encode()).hexdigest()
    checked_bytes['render_contract_sha256'] = identity(generator.c)
    # Both dictionaries remain individually valid contracts, with distinct
    # pipeline dataflow. No native compiler or verification result is mocked.
    candidate['pipelines'][0]['steps'][2]['args'] = ['other_index']
    candidate['pipelines'][0]['steps'][4]['args'] = ['index']
    _validate(candidate)
    return rendered

with patch.object(_Generator, 'render', mutate_after_real_render):
    report = bridge_cpp_contracts(header, candidate, root / 'bridge',
                                 cxx='/usr/bin/g++',
                                 rustc='/tmp/hepta-ai-rust-1.90.0/bin/rustc')
(root / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
published = json.loads((root / 'bridge/contract.json').read_text()) if report['ok'] else None
evidence = {
    'ok': report['ok'], 'diagnostics': report['diagnostics'],
    'snapshot_A_contract_sha256': identity(original),
    'mutated_B_contract_sha256': identity(candidate),
    'render_contract_sha256': checked_bytes['render_contract_sha256'],
    'receipt_contract_sha256': report.get('contract_sha256'),
    'published_contract_sha256': identity(published) if published else None,
    'rendered_A_cpp_sha256': checked_bytes['cpp_sha256'],
    'published_cpp_sha256': report.get('outputs', {}).get('bridge.cpp', {}).get('sha256'),
    'caller_changed': candidate != original,
}
evidence['immutable_snapshot_preserved'] = (
    report['ok'] and evidence['caller_changed']
    and evidence['render_contract_sha256'] == identity(original)
    and evidence['receipt_contract_sha256'] == identity(original)
    and evidence['published_contract_sha256'] == identity(original)
    and evidence['published_cpp_sha256'] == checked_bytes['cpp_sha256'])
(root / 'evidence.json').write_text(json.dumps(evidence, indent=2, sort_keys=True) + '\n')
print(json.dumps(evidence, indent=2, sort_keys=True))
raise SystemExit(0 if evidence['immutable_snapshot_preserved'] else 1)
