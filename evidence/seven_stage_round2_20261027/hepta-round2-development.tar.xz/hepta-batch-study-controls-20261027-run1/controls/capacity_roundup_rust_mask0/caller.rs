mod part_0; mod part_1;
fn entrypoint(x:u32,y:u32)->u32{part_0::part_0(x,y).wrapping_mul(31).wrapping_add(part_1::part_1(x))}