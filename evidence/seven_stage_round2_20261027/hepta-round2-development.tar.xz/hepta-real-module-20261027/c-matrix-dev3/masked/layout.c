#include "ringbuffer.h"
#include <stddef.h>
size_t probe_size(void){return sizeof(ring_buffer_t);}
size_t probe_align(void){return _Alignof(ring_buffer_t);}
size_t probe_buffer(void){return offsetof(ring_buffer_t,buffer);}
size_t probe_buffer_mask(void){return offsetof(ring_buffer_t,buffer_mask);}
size_t probe_tail_index(void){return offsetof(ring_buffer_t,tail_index);}
size_t probe_head_index(void){return offsetof(ring_buffer_t,head_index);}