#pragma once
#include "/workspace/scratch/1e9cfaeb170c/hepta-work/tests/fixtures/cpp_upgrade/3.12.0/json.hpp"
#include "/workspace/scratch/1e9cfaeb170c/hepta-work/examples/cpp/composed/foreign.hpp"
