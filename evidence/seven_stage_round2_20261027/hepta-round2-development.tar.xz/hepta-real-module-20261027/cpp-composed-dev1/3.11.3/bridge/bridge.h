// C ABI declarations. See contract.json for caller obligations.
#pragma once
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
#define HEPTA_CPP_NOEXCEPT noexcept
extern "C" {
#else
#define HEPTA_CPP_NOEXCEPT
#endif
int32_t hepta_cpp_composed_Vector_filled(size_t count, int64_t initial, uint64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Vector_destroy(uint64_t handle) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Vector_at(uint64_t handle, size_t index, int64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Vector_append(uint64_t handle, int64_t value) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Deque_filled(size_t count, int64_t initial, uint64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Deque_destroy(uint64_t handle) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Deque_at(uint64_t handle, size_t index, int64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Document_parse(const uint8_t* text, size_t text_len, uint64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Document_destroy(uint64_t handle) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Document_replace(uint64_t handle, size_t index, int64_t value) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_Document_sum(uint64_t handle, int64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_vector_deque(size_t count, int64_t initial, int64_t appended, size_t index, size_t other_count, size_t other_index, int64_t* out) HEPTA_CPP_NOEXCEPT;
int32_t hepta_cpp_composed_json_chain(const uint8_t* first, size_t first_len, const uint8_t* second, size_t second_len, size_t index, int64_t replacement, size_t repeat_count, size_t final_index, int64_t* out) HEPTA_CPP_NOEXCEPT;
#ifdef __cplusplus
}
#endif
#undef HEPTA_CPP_NOEXCEPT
