"""Create a new evidence archive and exact byte inventory; never extract it."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def create(spec_path, destination):
    spec = json.loads(Path(spec_path).read_text())
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    manifest_path = Path(str(destination) + '.manifest.json')
    if destination.exists() or manifest_path.exists():
        raise ValueError('new archive and manifest paths required')
    entries = []
    omitted = []
    names = set()
    for item in spec['inputs']:
        source = Path(item['path'])
        prefix = PurePosixPath(item['prefix'])
        assert not prefix.is_absolute() and '..' not in prefix.parts
        if not source.exists() and not source.is_symlink():
            raise ValueError('missing input: ' + str(source))
        paths = [source] if not source.is_dir() else sorted(source.rglob('*'))
        for path in paths:
            if path.is_dir() and not path.is_symlink():
                continue
            rel = str(path.relative_to(source)) if source.is_dir() else ''
            if rel in item.get('exclude', []):
                omitted.append({'path': str(path), 'bytes': path.stat().st_size,
                                'sha256': sha(path), 'reason': item['exclusion_reason']})
                continue
            name = str(prefix / rel) if rel else str(prefix)
            assert name not in names and '..' not in PurePosixPath(name).parts
            names.add(name)
            if path.is_symlink():
                identity = {'name': name, 'kind': 'symlink', 'target': os.readlink(path)}
            elif path.is_file():
                identity = {'name': name, 'kind': 'file', 'bytes': path.stat().st_size,
                            'sha256': sha(path)}
            else:
                raise ValueError('non-regular evidence: ' + str(path))
            entries.append((path, identity))
    entries.sort(key=lambda item: item[1]['name'])
    with destination.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6) as archive:
            for path, identity in entries:
                archive.add(path, arcname=identity['name'], recursive=False)
    actual = []
    with tarfile.open(destination, 'r:xz') as archive:
        for member in archive:
            if member.isfile():
                with archive.extractfile(member) as stream:
                    identity = {'name': member.name, 'kind': 'file', 'bytes': member.size,
                                'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
            elif member.issym():
                identity = {'name': member.name, 'kind': 'symlink', 'target': member.linkname}
            else:
                raise ValueError('unexpected archive member')
            actual.append(identity)
    expected = [identity for _, identity in entries]
    if actual != expected:
        raise ValueError('source or archive changed during collection')
    record = {'schema': 'hepta.seven-stage.archive.v1', 'archive': destination.name,
              'sha256': sha(destination), 'bytes': destination.stat().st_size,
              'input_mapping': spec['inputs'], 'explicitly_omitted': omitted,
              'members': expected}
    with manifest_path.open('x') as output:
        json.dump(record, output, indent=2, sort_keys=True)
        output.write('\n')
    return {'archive': str(destination), 'bytes': record['bytes'],
            'sha256': record['sha256'], 'members': len(expected), 'omitted': len(omitted)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('spec')
    parser.add_argument('destination')
    args = parser.parse_args()
    print(json.dumps(create(args.spec, args.destination), sort_keys=True))
