; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1 immarg)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal { ptr, i1 } @__hia_fn_0(i64 %p_0_0) {
b0:
  br label %edge_0
b1:
  %p_1_0 = phi ptr [ null, %edge_0 ], [ %t14, %edge_5 ]
  %p_1_1 = phi i64 [ 0, %edge_0 ], [ %t21, %edge_5 ]
  %p_1_2 = phi i64 [ %p_0_0, %edge_0 ], [ %p_3_3, %edge_5 ]
  %t1 = icmp ult i64 %p_1_1, %p_1_2
  br i1 %t1, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi ptr [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 1, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 1, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi ptr [ %p_2_0, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_3_2 = phi i64 [ %p_2_1, %edge_3 ]
  %p_3_3 = phi i64 [ %p_2_2, %edge_3 ]
  %t7 = trunc i64 %p_3_2 to i8
  %t8 = extractvalue %hia.buffer %p_3_1, 0
  %t9 = extractvalue %hia.buffer %p_3_1, 1
  %t10 = icmp ult i64 0, %t9
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  %t12 = getelementptr i8, ptr %t8, i64 0
  store i8 %t7, ptr %t12, align 1
  %t13 = call %hia.chain.result @__hia_chain_push(ptr %p_3_0, %hia.buffer %p_3_1)
  %t14 = extractvalue %hia.chain.result %t13, 0
  %t15 = extractvalue %hia.chain.result %t13, 1
  %t16 = extractvalue %hia.chain.result %t13, 2
  %t17 = extractvalue %hia.buffer %t15, 0
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %drop_nonnull_19, label %drop_after_19
drop_nonnull_19:
  call void @free(ptr %t17) nobuiltin
  br label %drop_after_19
drop_after_19:
  %t20 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_3_2, i64 1)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  %t23 = xor i1 %t22, true
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  br i1 %t16, label %edge_5, label %edge_6
b4:
  %p_4_0 = phi ptr [ %p_2_0, %edge_4 ]
  %p_4_1 = phi %hia.buffer [ %t6, %edge_4 ]
  %t25 = extractvalue %hia.buffer %p_4_1, 0
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %drop_nonnull_27, label %drop_after_27
drop_nonnull_27:
  call void @free(ptr %t25) nobuiltin
  br label %drop_after_27
drop_after_27:
  %t28 = insertvalue { ptr, i1 } zeroinitializer, ptr %p_4_0, 0
  %t29 = insertvalue { ptr, i1 } %t28, i1 false, 1
  ret { ptr, i1 } %t29
b5:
  %p_5_0 = phi ptr [ %t14, %edge_6 ]
  %t30 = insertvalue { ptr, i1 } zeroinitializer, ptr %p_5_0, 0
  %t31 = insertvalue { ptr, i1 } %t30, i1 false, 1
  ret { ptr, i1 } %t31
b6:
  %p_6_0 = phi ptr [ %p_1_0, %edge_2 ]
  %t32 = insertvalue { ptr, i1 } zeroinitializer, ptr %p_6_0, 0
  %t33 = insertvalue { ptr, i1 } %t32, i1 true, 1
  ret { ptr, i1 } %t33
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b6
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b1
edge_6:
  br label %b5
}

define internal i64 @__hia_fn_1(ptr %p_0_0) {
b0:
  br label %edge_0
b1:
  %p_1_0 = phi ptr [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i64 [ 0, %edge_0 ], [ %t12, %edge_3 ]
  %t1 = call %hia.chain.result @__hia_chain_pop(ptr %p_1_0)
  %t2 = extractvalue %hia.chain.result %t1, 0
  %t3 = extractvalue %hia.chain.result %t1, 1
  %t4 = extractvalue %hia.chain.result %t1, 2
  br i1 %t4, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi ptr [ %t2, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t3, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_1, %edge_1 ]
  %t5 = extractvalue %hia.buffer %p_2_1, 0
  %t6 = extractvalue %hia.buffer %p_2_1, 1
  %t7 = icmp ult i64 0, %t6
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = getelementptr i8, ptr %t5, i64 0
  %t10 = load i8, ptr %t9, align 1
  %t11 = zext i8 %t10 to i64
  %t12 = add i64 %p_2_2, %t11
  %t13 = extractvalue %hia.buffer %p_2_1, 0
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %drop_nonnull_15, label %drop_after_15
drop_nonnull_15:
  call void @free(ptr %t13) nobuiltin
  br label %drop_after_15
drop_after_15:
  br label %edge_3
b3:
  %p_3_0 = phi ptr [ %t2, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t3, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_1, %edge_2 ]
  %t16 = extractvalue %hia.buffer %p_3_1, 0
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %drop_nonnull_18, label %drop_after_18
drop_nonnull_18:
  call void @free(ptr %t16) nobuiltin
  br label %drop_after_18
drop_after_18:
  call void @__hia_chain_drop(ptr %p_3_0)
  ret i64 %p_3_2
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal i64 @__hia_fn_2(i64 %p_0_0) {
b0:
  %t1 = call { ptr, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { ptr, i1 } %t1, 0
  %t3 = extractvalue { ptr, i1 } %t1, 1
  %t4 = call i64 @__hia_fn_1(ptr %t2)
  %t5 = select i1 %t3, i64 0, i64 1000000
  %t6 = add i64 %t4, %t5
  ret i64 %t6
}

define internal i1 @__hia_fn_3(i64 %p_0_0) {
b0:
  %t1 = call { ptr, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { ptr, i1 } %t1, 0
  %t3 = extractvalue { ptr, i1 } %t1, 1
  call void @__hia_chain_drop(ptr %t2)
  ret i1 %t3
}

define internal i64 @__hia_fn_4(i64 %p_0_0) {
b0:
  %t1 = call { ptr, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { ptr, i1 } %t1, 0
  %t3 = extractvalue { ptr, i1 } %t1, 1
  %t4 = icmp eq ptr %t2, null
  br i1 %t4, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi ptr [ %t2, %edge_0 ]
  call void @__hia_chain_drop(ptr %p_1_0)
  ret i64 0
b2:
  %p_2_0 = phi ptr [ %t2, %edge_1 ]
  %t5 = icmp ne ptr %p_2_0, null
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = load %hia.buffer, ptr %p_2_0, align 8
  %t8 = extractvalue %hia.buffer %t7, 0
  %t9 = extractvalue %hia.buffer %t7, 1
  %t10 = icmp ult i64 0, %t9
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  %t12 = getelementptr i8, ptr %t8, i64 0
  %t13 = load i8, ptr %t12, align 1
  %t14 = extractvalue %hia.buffer %t7, 0
  %t15 = extractvalue %hia.buffer %t7, 1
  %t16 = icmp ule i64 0, %t15
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = sub i64 %t15, 0
  %t19 = icmp ule i64 1, %t18
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t22 = icmp ne i64 1, 0
  br i1 %t22, label %fill_nonempty_21, label %fill_after_21
fill_nonempty_21:
  %t23 = getelementptr i8, ptr %t14, i64 0
  call void @llvm.memset.p0.i64(ptr align 1 %t23, i8 255, i64 1, i1 false)
  br label %fill_after_21
fill_after_21:
  %t24 = call i64 @__hia_fn_1(ptr %p_2_0)
  ret i64 %t24
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i1 @__hia_fn_5() {
b0:
  %t1 = call %hia.chain.result @__hia_chain_pop(ptr null)
  %t2 = extractvalue %hia.chain.result %t1, 0
  %t3 = extractvalue %hia.chain.result %t1, 1
  %t4 = extractvalue %hia.chain.result %t1, 2
  call void @__hia_chain_drop(ptr %t2)
  %t5 = extractvalue %hia.buffer %t3, 0
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %drop_nonnull_7, label %drop_after_7
drop_nonnull_7:
  call void @free(ptr %t5) nobuiltin
  br label %drop_after_7
drop_after_7:
  ret i1 %t4
}

define internal i8 @__hia_fn_6() {
b0:
  %t1 = icmp ne ptr null, null
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = load %hia.buffer, ptr null, align 8
  %t4 = extractvalue %hia.buffer %t3, 0
  %t5 = extractvalue %hia.buffer %t3, 1
  %t6 = icmp ult i64 0, %t5
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = getelementptr i8, ptr %t4, i64 0
  %t9 = load i8, ptr %t8, align 1
  call void @__hia_chain_drop(ptr null)
  ret i8 %t9
}

define i64 @chain_checksum(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_2(i64 %a0)
  ret i64 %result
}

define zeroext i1 @chain_cancel(i64 %a0) {
entry:
  %result = call i1 @__hia_fn_3(i64 %a0)
  ret i1 %result
}

define i64 @chain_head_update(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_4(i64 %a0)
  ret i64 %result
}

define zeroext i1 @chain_empty_pop() {
entry:
  %result = call i1 @__hia_fn_5()
  ret i1 %result
}

define zeroext i8 @chain_empty_head() {
entry:
  %result = call i8 @__hia_fn_6()
  ret i8 %result
}
