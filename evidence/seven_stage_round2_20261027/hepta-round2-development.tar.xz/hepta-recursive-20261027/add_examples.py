from pathlib import Path
import json
from tests.test_hia_program import p,i,c,b,f,ret,jump,branch
path=Path('examples/hia_recursive_chain/core_v7.json')
doc=json.loads(path.read_text())
empty=f('chain_empty_payloads',[('count','usize')],['bool'],['alloc','trap'],[
 b('entry',[('count','usize')],[i('chain.empty',out=[('empty','chain')]),c('zero','usize',0)],jump('loop','empty','zero','count')),
 b('loop',[('tail','chain'),('index','usize'),('limit','usize')],[i('compare.lt',['index','limit'],[('more','bool')])],branch('more',('push','tail','index','limit'),('done','tail'))),
 b('push',[('push_tail','chain'),('push_index','usize'),('push_limit','usize')],[c('payload_size','usize',0),i('buffer.try_new',['payload_size'],[('payload','buffer'),('payload_ok','bool')]),i('chain.try_push',['push_tail','payload'],[('pushed','chain'),('fallback','buffer'),('ok','bool')]),i('owner.drop',['fallback']),c('one','usize',1),i('int.add.checked',['push_index','one'],[('next','usize')])],branch('ok',('loop','pushed','next','push_limit'),('error','pushed'))),
 b('done',[('done_chain','chain')],[i('owner.drop',['done_chain']),c('yes','bool',True)],ret('yes')),
 b('error',[('error_chain','chain')],[i('owner.drop',['error_chain']),c('no','bool',False)],ret('no'))])
recover=f('chain_recover',[('count','usize')],['u64'],['alloc','read','write','trap'],[
 b('entry',[('count','usize')],[i('call',['count'],[('tail','chain'),('built','bool')],function='build_chain'),c('one','usize',1),i('buffer.new',['one'],[('payload','buffer')]),i('borrow.mut',['payload'],[('writer','mutbuf')]),c('zero','usize',0),c('byte','u8',73),i('buffer.store',['writer','zero','byte']),i('loan.end',['writer']),i('chain.try_push',['tail','payload'],[('after','chain'),('fallback','buffer'),('ok','bool')])],branch('ok',('success','after','fallback'),('failure','after','fallback'))),
 b('success',[('success_chain','chain'),('empty_fallback','buffer')],[i('owner.drop',['empty_fallback']),i('chain.pop',['success_chain'],[('success_tail','chain'),('recovered','buffer'),('present','bool')]),c('success_code','u64',0)],jump('observe','success_tail','recovered','success_code')),
 b('failure',[('failure_tail','chain'),('retained','buffer')],[c('failure_code','u64',1000000)],jump('observe','failure_tail','retained','failure_code')),
 b('observe',[('observe_tail','chain'),('observe_payload','buffer'),('code','u64')],[i('borrow.read',['observe_payload'],[('reader','readbuf')]),c('position','usize',0),i('buffer.load',['reader','position'],[('value','u8')]),i('loan.end',['reader']),i('owner.drop',['observe_payload']),i('int.cast',['value'],[('wide','u64')],mode='wrap'),i('call',['observe_tail'],[('tail_sum','u64')],function='drain_chain'),i('int.add.wrap',['tail_sum','wide'],[('sum','u64')]),i('int.add.wrap',['sum','code'],[('result','u64')])],ret('result'))])
doc['functions'] += [empty,recover]
path.write_text(json.dumps(doc,indent=2)+'\n')
from hepta.hia_program import verify_program
from hepta.hia_program_runtime import execute_program
p=verify_program(doc)
for n in [0,1,2,17]:
 for fail in [None,2*n+2]:
  print(n,fail,execute_program(p,'chain_recover',[n],allocation_fail_at=fail)['result'])
 for fail in [None,1,3]:
  r=execute_program(p,'chain_empty_payloads',[n],allocation_fail_at=fail)
  print('empty',n,fail,r['result'],r['resources'])
