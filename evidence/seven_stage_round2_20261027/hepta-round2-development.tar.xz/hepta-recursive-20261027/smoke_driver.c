#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
uint64_t chain_checksum(uint64_t);
bool chain_cancel(uint64_t);
uint64_t chain_head_update(uint64_t);
uint64_t chain_stored_loan(uint64_t);
uint64_t chain_task(uint64_t,uint8_t);
int main(void) {
 unsigned ns[]={0,1,2,17,257,4097};
 for(unsigned j=0;j<6;j++) {
  uint64_t n=ns[j],expected=0; for(uint64_t i=0;i<n;i++)expected+=(uint8_t)i;
  if(chain_checksum(n)!=expected || !chain_cancel(n))return 11;
  if(chain_task(n,2)!=expected)return 12;
  if(chain_stored_loan(n)!=(n?expected-(uint8_t)(n-1)+99:0))return 13;
  if(chain_head_update(n)!=(n?expected-(uint8_t)(n-1)+255:0))return 14;
  printf("%llu %llu\n",(unsigned long long)n,(unsigned long long)expected);
 }
 return 0;
}
