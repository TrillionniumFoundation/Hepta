from pathlib import Path
import json
from tests.test_hia_program import p,i,c,b,f,ret,jump,branch
from tests.test_hia_program_composite import record,enum,ref,match
A=['alloc','read','write','trap']
build=f('build_chain',[('n','usize')],['chain','bool'],A,[
 b('entry',[('n','usize')],[i('chain.empty',out=[('initial','chain')]),c('zero','usize',0)],jump('loop','initial','zero','n')),
 b('loop',[('tail','chain'),('index','usize'),('limit','usize')],[i('compare.lt',['index','limit'],[('more','bool')])],branch('more',('allocate','tail','index','limit'),('complete','tail'))),
 b('allocate',[('alloc_tail','chain'),('alloc_index','usize'),('alloc_limit','usize')],[c('one','usize',1),i('buffer.try_new',['one'],[('payload','buffer'),('payload_ok','bool')])],branch('payload_ok',('fill','alloc_tail','payload','alloc_index','alloc_limit'),('payload_error','alloc_tail','payload'))),
 b('fill',[('fill_tail','chain'),('fill_payload','buffer'),('fill_index','usize'),('fill_limit','usize')],[
  i('borrow.mut',['fill_payload'],[('writer','mutbuf')]),c('position','usize',0),i('int.cast',['fill_index'],[('byte','u8')],mode='wrap'),i('buffer.store',['writer','position','byte']),i('loan.end',['writer']),
  i('chain.try_push',['fill_tail','fill_payload'],[('pushed','chain'),('remainder','buffer'),('push_ok','bool')]),i('owner.drop',['remainder']),c('step','usize',1),i('int.add.checked',['fill_index','step'],[('next_index','usize')])],
  branch('push_ok',('loop','pushed','next_index','fill_limit'),('node_error','pushed'))),
 b('payload_error',[('payload_error_tail','chain'),('empty_payload','buffer')],[i('owner.drop',['empty_payload']),c('payload_false','bool',False)],ret('payload_error_tail','payload_false')),
 b('node_error',[('node_error_tail','chain')],[c('node_false','bool',False)],ret('node_error_tail','node_false')),
 b('complete',[('complete_tail','chain')],[c('completed','bool',True)],ret('complete_tail','completed'))])
drain=f('drain_chain',[('owned','chain')],['u64'],['alloc','read','trap'],[
 b('entry',[('owned','chain')],[c('sum_zero','u64',0)],jump('drain','owned','sum_zero')),
 b('drain',[('rest','chain'),('sum','u64')],[i('chain.pop',['rest'],[('next','chain'),('item','buffer'),('present','bool')])],branch('present',('add','next','item','sum'),('done','next','item','sum'))),
 b('add',[('add_rest','chain'),('add_item','buffer'),('add_sum','u64')],[i('borrow.read',['add_item'],[('reader','readbuf')]),c('offset','usize',0),i('buffer.load',['reader','offset'],[('value','u8')]),i('loan.end',['reader']),i('int.cast',['value'],[('wide','u64')],mode='wrap'),i('int.add.wrap',['add_sum','wide'],[('added','u64')]),i('owner.drop',['add_item'])],jump('drain','add_rest','added')),
 b('done',[('done_rest','chain'),('empty_item','buffer'),('total','u64')],[i('owner.drop',['empty_item']),i('owner.drop',['done_rest'])],ret('total'))])
checksum=f('chain_checksum',[('count','usize')],['u64'],A,[b('entry',[('count','usize')],[i('call',['count'],[('built','chain'),('all_ok','bool')],function='build_chain'),i('call',['built'],[('total','u64')],function='drain_chain'),c('fine','u64',0),c('failed','u64',1000000),i('select',['all_ok','fine','failed'],[('code','u64')]),i('int.add.wrap',['total','code'],[('result','u64')])],ret('result'))])
cancel=f('chain_cancel',[('count','usize')],['bool'],A,[b('entry',[('count','usize')],[i('call',['count'],[('built','chain'),('all_ok','bool')],function='build_chain'),i('owner.move',['built'],[('moved','chain')]),i('owner.drop',['moved'])],ret('all_ok'))])
head=f('chain_head_update',[('count','usize')],['u64'],A,[
 b('entry',[('count','usize')],[i('call',['count'],[('built','chain'),('all_ok','bool')],function='build_chain'),i('chain.is_empty',['built'],[('empty','bool')])],branch('empty',('none','built'),('some','built'))),
 b('none',[('none_chain','chain')],[i('owner.drop',['none_chain']),c('none_zero','u64',0)],ret('none_zero')),
 b('some',[('some_chain','chain')],[i('chain.head_mut',['some_chain'],[('writer','mutbuf')]),i('borrow.read',['writer'],[('child','readbuf')]),c('zero','usize',0),i('buffer.load',['child','zero'],[('before','u8')]),i('loan.end',['child']),c('replacement','u8',255),i('buffer.fill_range',['writer','zero','count_one','replacement'])] if False else [
  i('chain.head_mut',['some_chain'],[('writer','mutbuf')]),i('borrow.read',['writer'],[('child','readbuf')]),c('zero','usize',0),i('buffer.load',['child','zero'],[('before','u8')]),i('loan.end',['child']),c('replacement','u8',255),c('count_one','usize',1),i('buffer.fill_range',['writer','zero','count_one','replacement']),i('loan.end',['writer']),i('call',['some_chain'],[('total','u64')],function='drain_chain')],ret('total'))])
empty=f('chain_empty_pop',[],['bool'],['alloc'],[b('entry',[],[i('chain.empty',out=[('empty','chain')]),i('chain.pop',['empty'],[('rest','chain'),('item','buffer'),('present','bool')]),i('owner.drop',['rest']),i('owner.drop',['item'])],ret('present'))])
trap=f('chain_empty_head',[],['u8'],['alloc','read','trap'],[b('entry',[],[i('chain.empty',out=[('empty','chain')]),i('chain.head_read',['empty'],[('reader','readbuf')]),c('zero','usize',0),i('buffer.load',['reader','zero'],[('value','u8')]),i('loan.end',['reader']),i('owner.drop',['empty'])],ret('value'))])
core={'schema':'hepta.hia.program.v7','module':'recursive_chain','functions':[build,drain,checksum,cancel,head,empty,trap]}
root=Path('examples/hia_recursive_chain')
(root/'core_v7.json').write_text(json.dumps(core,indent=2)+'\n')
# The same inductive primitive is embedded in generic records, stored loans,
# generic result enums and cooperative tasks; their independent Core remains v7.
state=ref('Pair','chain','u64'); step=ref('Step',state,'u64'); result=ref('Result','chain','chain')
types=[record('Pair',[('first','T'),('second','U')],['T','U']),enum('Step',[('pending',[('state','S')]),('ready',[('value','R')])],['S','R']),enum('Result',[('ok',[('value','T')]),('error',[('value','E')])],['T','E']),record('Frame',[('owned','chain'),('writer','mutbuf'),('reader','readbuf')]),{'name':'ChainTask','kind':'task','params':[],'state':state,'result':'u64','poll':'poll_chain','cancel':'cancel_chain'}]
poll=f('poll_chain',[('state',state)],[step],['alloc','read','trap'],[
 b('entry',[('state',state)],[i('record.unpack',['state'],[('owned','chain'),('sum','u64')]),i('chain.pop',['owned'],[('rest','chain'),('item','buffer'),('present','bool')])],branch('present',('more','rest','item','sum'),('done','rest','item','sum'))),
 b('more',[('more_rest','chain'),('more_item','buffer'),('more_sum','u64')],[i('borrow.read',['more_item'],[('reader','readbuf')]),c('zero','usize',0),i('buffer.load',['reader','zero'],[('byte','u8')]),i('loan.end',['reader']),i('owner.drop',['more_item']),i('int.cast',['byte'],[('wide','u64')],mode='wrap'),i('int.add.wrap',['more_sum','wide'],[('total','u64')]),i('record.make',['more_rest','total'],[('new_state',state)]),i('enum.make',['new_state'],[('pending',step)],variant='pending')],ret('pending')),
 b('done',[('empty_chain','chain'),('empty_item','buffer'),('answer','u64')],[i('owner.drop',['empty_chain']),i('owner.drop',['empty_item']),i('enum.make',['answer'],[('ready',step)],variant='ready')],ret('ready'))])
cancel_task=f('cancel_chain',[('state',state)],[],['alloc'],[b('entry',[('state',state)],[i('record.unpack',['state'],[('owned','chain'),('sum','u64')]),i('owner.drop',['owned'])],ret())])
task=f('chain_task',[('count','usize'),('mode','u8')],['u64'],A,[
 b('entry',[('count','usize'),('mode','u8')],[i('call',['count'],[('built','chain'),('ok','bool')],function='build_chain')],branch('ok',('good','built','mode'),('bad','built','mode'))),
 b('good',[('good_chain','chain'),('good_mode','u8')],[i('enum.make',['good_chain'],[('good_result',result)],variant='ok')],jump('match_result','good_result','good_mode')),
 b('bad',[('bad_chain','chain'),('bad_mode','u8')],[i('enum.make',['bad_chain'],[('bad_result',result)],variant='error')],jump('match_result','bad_result','bad_mode')),
 b('match_result',[('result',result),('result_mode','u8')],[],match('result',('ok','prepare',['result_mode']),('error','error',['result_mode']))),
 b('error',[('error_chain','chain'),('error_mode','u8')],[i('owner.drop',['error_chain']),c('failure','u64',1000000)],ret('failure')),
 b('prepare',[('prepare_chain','chain'),('prepare_mode','u8')],[c('initial_sum','u64',0),i('record.make',['prepare_chain','initial_sum'],[('initial_state',state)]),i('task.create',['initial_state'],[('created','ChainTask')]),c('zero_mode','u8',0),i('compare.eq',['prepare_mode','zero_mode'],[('cancel_now','bool')])],branch('cancel_now',('cancel_pending','created'),('start','created','prepare_mode'))),
 b('cancel_pending',[('pending_task','ChainTask')],[i('task.cancel',['pending_task'],[('stopped','ChainTask')]),i('task.cancel',['stopped'],[('again','ChainTask')]),i('task.close',['again']),c('cancelled','u64',3000000)],ret('cancelled')),
 b('start',[('new_task','ChainTask'),('start_mode','u8')],[i('task.start',['new_task'],[('started','ChainTask')]),i('task.poll',['started'],[('once','ChainTask')]),c('one_mode','u8',1),i('compare.eq',['start_mode','one_mode'],[('cancel_after_poll','bool')])],branch('cancel_after_poll',('cancel_running','once'),('loop_task','once'))),
 b('cancel_running',[('running_task','ChainTask')],[i('task.cancel',['running_task'],[('cancelled_task','ChainTask')]),i('task.state',['cancelled_task'],[('cancel_state','u8')]),c('complete_state','u8',2),i('compare.eq',['cancel_state','complete_state'],[('already_done','bool')])],branch('already_done',('join_task','cancelled_task'),('close_cancelled','cancelled_task'))),
 b('close_cancelled',[('closing_task','ChainTask')],[i('task.close',['closing_task']),c('partial_cancelled','u64',2000000)],ret('partial_cancelled')),
 b('loop_task',[('looping_task','ChainTask')],[i('task.state',['looping_task'],[('status','u8')]),c('complete','u8',2),i('compare.eq',['status','complete'],[('finished','bool')])],branch('finished',('join_task','looping_task'),('poll_task','looping_task'))),
 b('poll_task',[('polling_task','ChainTask')],[i('task.poll',['polling_task'],[('next_task','ChainTask')])],jump('loop_task','next_task')),
 b('join_task',[('finished_task','ChainTask')],[i('task.join',['finished_task'],[('answer','u64')])],ret('answer'))])
stored=f('chain_stored_loan',[('count','usize')],['u64'],A,[
 b('entry',[('count','usize')],[i('call',['count'],[('built','chain'),('ok','bool')],function='build_chain'),i('chain.is_empty',['built'],[('empty','bool')])],branch('empty',('none','built'),('borrow','built'))),
 b('none',[('none_chain','chain')],[i('owner.drop',['none_chain']),c('nothing','u64',0)],ret('nothing')),
 b('borrow',[('borrow_chain','chain')],[i('chain.head_mut',['borrow_chain'],[('writer','mutbuf')]),i('borrow.read',['writer'],[('reader','readbuf')]),i('record.make',['borrow_chain','writer','reader'],[('frame','Frame')])],jump('use','frame')),
 b('use',[('stored','Frame')],[i('record.unpack',['stored'],[('owned','chain'),('parent','mutbuf'),('child','readbuf')]),c('zero','usize',0),i('buffer.load',['child','zero'],[('previous','u8')]),i('loan.end',['child']),c('new_byte','u8',99),i('buffer.store',['parent','zero','new_byte']),i('loan.end',['parent']),i('call',['owned'],[('sum','u64')],function='drain_chain')],ret('sum'))])
composite={'schema':'hepta.hia.composite.v2','module':'recursive_chain_composition','types':types,'functions':[build,drain,poll,cancel_task,task,stored]}
(root/'composite_v2.json').write_text(json.dumps(composite,indent=2)+'\n')
from hepta.hia_program import verify_program
from hepta.hia_program_runtime import execute_program
for name,document in [('core',core),('composite',composite)]:
 checked=verify_program(document)
 print(name,checked.sha256,checked.as_dict()['schema'])
for n in [0,1,2,17,257]:
 print('sum',n,execute_program(core,'chain_checksum',[n])['result'])
 print('cancel',n,execute_program(core,'chain_cancel',[n])['result'])
 print('head',n,execute_program(core,'chain_head_update',[n])['result'])
 print('stored',n,execute_program(composite,'chain_stored_loan',[n])['result'])
 for mode in [0,1,2]:
  print('task',n,mode,execute_program(composite,'chain_task',[n,mode])['result'])
