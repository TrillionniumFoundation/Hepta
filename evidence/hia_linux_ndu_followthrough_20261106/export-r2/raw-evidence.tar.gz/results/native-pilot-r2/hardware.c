unsigned hardware_popcnt(unsigned w) {return __builtin_popcount(w);}
