#define SYM_FUNC_START(n) .globl n; .type n,@function; .p2align 4; n:
#define SYM_FUNC_END(n) .size n,.-n
#define RET jmp __x86_return_thunk
