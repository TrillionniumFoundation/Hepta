#define __ASM_SIZE(x,y) x##q
#define __ASM_REG(x) r##x
