import sys,json,hashlib,platform,unittest
from pathlib import Path
repo=Path('/data/hepta-hia-linux-followthrough-20261106-bedaafad8a2f/repo')
sys.path.insert(0,str(repo))
from tools.qualify_hia_linux_tests import git
from tools.qualify_hia_three_lane import _IdentityRecordingResult,_outcome_admissible,_planned_test_ids
modules=('tests.test_hia_ndu_feedback_coverage','tests.test_hia_ndu_policy_audit','tests.test_hia_ndu_policy_campaign')
before={'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}')}
assert not git('status','--porcelain','--untracked-files=all')
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
planned=_planned_test_ids(suite)
result=unittest.TextTestRunner(stream=sys.stderr,verbosity=2,resultclass=_IdentityRecordingResult).run(suite)
after={'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}')}
dirty=git('status','--porcelain','--untracked-files=all')
passed=_outcome_admissible(result,planned,immutable=before==after and not dirty)
record={'schema':'hepta.hia.ndu-compute-debit-regressions.v1','status':'PASS' if passed else 'FAIL','source_before':before,'source_after':after,'source_status_after':dirty,'python_version':platform.python_version(),'modules':list(modules),'tests_planned':len(planned),'tests_executed':result.testsRun,'planned_ids':list(planned),'started_ids':result.started_ids,'finished_ids':result.finished_ids,'planned_ids_sha256':hashlib.sha256(json.dumps(planned,separators=(',',':')).encode()).hexdigest(),'errors':[t.id() for t,_ in result.errors],'failures':[t.id() for t,_ in result.failures],'skipped':[{'test':t.id(),'reason':r} for t,r in result.skipped],'expected_failures':[t.id() for t,_ in result.expectedFailures],'unexpected_successes':[t.id() for t in result.unexpectedSuccesses],'scope':'deterministic_compute_debit_and_existing_model_regressions_not_native_performance','claims':{'kernel_booted':False,'whole_kernel_rewritten':False,'global_comparison_completed':False,'ndu_gain_established':False}}
Path(sys.argv[1]).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('status','tests_planned','tests_executed','skipped')}))
raise SystemExit(0 if passed else 1)
