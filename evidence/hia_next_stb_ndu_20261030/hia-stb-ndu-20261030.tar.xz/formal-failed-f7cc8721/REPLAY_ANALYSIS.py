"""Read-only arithmetic reconstruction; never promotes the failed formal run."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys
import time

SOURCE = Path('/workspace/scratch/f0c12f106c89/hepta-next-optimization')
ROOT = Path(__file__).resolve().parent
FIX = 'a88b9e164ecbd6dad1ec146c2833798b181e30ee'
ORIGINAL = '411a8eabb85adbee5334afe0c684b42de39367f2b74ae3caa515ec7674465ae9'
sys.path.insert(0, str(SOURCE))
from tools import qualify_hia_stb_ndu as study


def identity(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    target = ROOT / 'OFFLINE_ANALYSIS_SIDECAR.json'
    if target.exists():
        raise RuntimeError('Separate replay receipt already exists')
    started = time.monotonic_ns()
    source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
    source_status = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=SOURCE, text=True).strip()
    assert source_head == FIX and source_status == ''
    original_path = ROOT / 'run/RESULT.json'
    before = identity(original_path)
    assert before['sha256'] == ORIGINAL
    original = json.loads(original_path.read_bytes())
    assert original['qualified'] is False
    assert original['analysis_error'] == {'type': 'KeyError', 'message': "'wall_ns'"}
    report = copy.deepcopy(original)
    failed_analysis = report['ledger'].pop()
    assert failed_analysis['label'] == 'post-policy.analysis' and failed_analysis['wall_ns'] == 145660
    assert failed_analysis['status'] == 'failed'
    closed_costs = copy.deepcopy(report['ledger'])
    result = study.analyze_measured(report, report['protocol'])
    assert report['qualified'] is False
    after = identity(original_path)
    assert after == before
    sidecar = {'schema': 'hepta.hia.stb-ndu.offline-analysis-sidecar.v1',
        'original_result': before, 'original_execution': identity(ROOT / 'EXECUTION.json'),
        'original_qualified': False, 'original_result_modified': False,
        'original_failed_analysis': failed_analysis, 'original_status_reclassified': False,
        'new_native_application_executions': 0, 'new_model_executions': 0,
        'new_economic_observations': 0, 'purpose': 'Repair arithmetic aggregation only; the formal run remains failed.',
        'fix_source_commit': source_head, 'fix_source_clean': source_status == '',
        'fix_implementation': identity(SOURCE / 'tools/qualify_hia_stb_ndu.py'),
        'regression_fixture': identity(SOURCE / 'tests/fixtures/hia_stb_ndu/failed_formal_analysis_f7cc8721.json'),
        'replay_script': identity(__file__), 'closed_cost_ledger': closed_costs,
        'analysis': result, 'new_analysis_measurement': report['ledger'][-1],
        'pure_replay_wall_ns_before_encoding': time.monotonic_ns() - started,
        'performance_timing_qualified': False, 'authority': 'DENY_ALL', 'safety_certificate': False}
    target.write_text(json.dumps(sidecar, sort_keys=True, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'sidecar': str(target), 'original_qualified': False,
        'standalone_measured_ns': result['standalone_measured_ns'],
        'baseline_only_standalone_ns': result['baseline_only_standalone_ns'],
        'native_build_inclusive_ns': result['native_build_inclusive_ns'],
        'net_gates': [result[k] for k in ('candidate_cold_observed_net_gate', 'ndu_warm_observed_net_gate',
                                        'ndu_build_inclusive_observed_net_gate')],
        'same_model_decisions': len(result['same_model_audit']),
        'new_analysis_wall_ns': report['ledger'][-1]['wall_ns']}))


if __name__ == '__main__':
    main()
