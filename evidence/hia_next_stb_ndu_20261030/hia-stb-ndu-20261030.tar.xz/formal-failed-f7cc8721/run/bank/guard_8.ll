; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i32 %p_0_1, 8
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  br label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %t2 = icmp ne i32 %p_2_1, 0
  br i1 %t2, label %ok_3, label %trap_3
trap_3:
  call void @abort()
  unreachable
ok_3:
  %t4 = icmp eq i32 %p_2_0, -2147483648
  %t5 = icmp eq i32 %p_2_1, -1
  %t6 = and i1 %t4, %t5
  %t7 = xor i1 %t6, true
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = srem i32 %p_2_0, %p_2_1
  %t10 = trunc i64 0 to i32
  %t11 = icmp sge i32 %t9, %t10
  br i1 %t11, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi i32 [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i32 [ %p_2_0, %edge_3 ]
  %p_3_3 = phi i32 [ %p_2_1, %edge_3 ]
  %p_3_4 = phi i32 [ %t9, %edge_3 ]
  ret i32 %p_3_4
b4:
  %p_4_0 = phi i32 [ %p_2_0, %edge_4 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_4_2 = phi i32 [ %p_2_0, %edge_4 ]
  %p_4_3 = phi i32 [ %p_2_1, %edge_4 ]
  %p_4_4 = phi i32 [ %t9, %edge_4 ]
  br label %edge_5
b5:
  %p_5_0 = phi i32 [ %p_4_3, %edge_5 ]
  %p_5_1 = phi i32 [ %p_4_0, %edge_5 ]
  %p_5_2 = phi i32 [ %p_4_1, %edge_5 ]
  %p_5_3 = phi i32 [ %p_4_2, %edge_5 ]
  %p_5_4 = phi i32 [ %p_4_3, %edge_5 ]
  %p_5_5 = phi i32 [ %p_4_4, %edge_5 ]
  %t12 = trunc i64 0 to i32
  %t13 = icmp slt i32 %p_5_0, %t12
  br i1 %t13, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i32 [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi i32 [ %p_5_2, %edge_6 ]
  %p_6_3 = phi i32 [ %p_5_3, %edge_6 ]
  %p_6_4 = phi i32 [ %p_5_4, %edge_6 ]
  %p_6_5 = phi i32 [ %p_5_5, %edge_6 ]
  br label %edge_8
b7:
  %p_7_0 = phi i32 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi i32 [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_7 ]
  %p_7_4 = phi i32 [ %p_5_4, %edge_7 ]
  %p_7_5 = phi i32 [ %p_5_5, %edge_7 ]
  %t14 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_7_0)
  %t15 = extractvalue { i32, i1 } %t14, 0
  %t16 = extractvalue { i32, i1 } %t14, 1
  %t17 = xor i1 %t16, true
  br i1 %t17, label %ok_18, label %trap_18
trap_18:
  call void @abort()
  unreachable
ok_18:
  br label %edge_9
b8:
  %p_8_0 = phi i32 [ %p_6_0, %edge_8 ], [ %t15, %edge_9 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ], [ %p_7_1, %edge_9 ]
  %p_8_2 = phi i32 [ %p_6_2, %edge_8 ], [ %p_7_2, %edge_9 ]
  %p_8_3 = phi i32 [ %p_6_3, %edge_8 ], [ %p_7_3, %edge_9 ]
  %p_8_4 = phi i32 [ %p_6_4, %edge_8 ], [ %p_7_4, %edge_9 ]
  %p_8_5 = phi i32 [ %p_6_5, %edge_8 ], [ %p_7_5, %edge_9 ]
  %t19 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_8_5, i32 %p_8_0)
  %t20 = extractvalue { i32, i1 } %t19, 0
  %t21 = extractvalue { i32, i1 } %t19, 1
  %t22 = xor i1 %t21, true
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  ret i32 %t20
b9:
  %p_9_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_9_1 = phi i32 [ 8, %edge_0 ]
  br label %edge_10
b10:
  %p_10_0 = phi i32 [ %p_9_0, %edge_10 ]
  %p_10_1 = phi i32 [ %p_9_1, %edge_10 ]
  %t24 = icmp ne i32 %p_10_1, 0
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = icmp eq i32 %p_10_0, -2147483648
  %t27 = icmp eq i32 %p_10_1, -1
  %t28 = and i1 %t26, %t27
  %t29 = xor i1 %t28, true
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  %t31 = srem i32 %p_10_0, %p_10_1
  %t32 = trunc i64 0 to i32
  %t33 = icmp sge i32 %t31, %t32
  br i1 %t33, label %edge_11, label %edge_12
b11:
  %p_11_0 = phi i32 [ %p_10_0, %edge_11 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_11 ]
  %p_11_2 = phi i32 [ %p_10_0, %edge_11 ]
  %p_11_3 = phi i32 [ %p_10_1, %edge_11 ]
  %p_11_4 = phi i32 [ %t31, %edge_11 ]
  ret i32 %p_11_4
b12:
  %p_12_0 = phi i32 [ %p_10_0, %edge_12 ]
  %p_12_1 = phi i32 [ %p_10_1, %edge_12 ]
  %p_12_2 = phi i32 [ %p_10_0, %edge_12 ]
  %p_12_3 = phi i32 [ %p_10_1, %edge_12 ]
  %p_12_4 = phi i32 [ %t31, %edge_12 ]
  br label %edge_13
b13:
  %p_13_0 = phi i32 [ %p_12_3, %edge_13 ]
  %p_13_1 = phi i32 [ %p_12_0, %edge_13 ]
  %p_13_2 = phi i32 [ %p_12_1, %edge_13 ]
  %p_13_3 = phi i32 [ %p_12_2, %edge_13 ]
  %p_13_4 = phi i32 [ %p_12_3, %edge_13 ]
  %p_13_5 = phi i32 [ %p_12_4, %edge_13 ]
  %t34 = trunc i64 0 to i32
  %t35 = icmp slt i32 %p_13_0, %t34
  br i1 %t35, label %edge_14, label %edge_15
b14:
  %p_14_0 = phi i32 [ %p_13_0, %edge_14 ]
  %p_14_1 = phi i32 [ %p_13_1, %edge_14 ]
  %p_14_2 = phi i32 [ %p_13_2, %edge_14 ]
  %p_14_3 = phi i32 [ %p_13_3, %edge_14 ]
  %p_14_4 = phi i32 [ %p_13_4, %edge_14 ]
  %p_14_5 = phi i32 [ %p_13_5, %edge_14 ]
  br label %edge_16
b15:
  %p_15_0 = phi i32 [ %p_13_0, %edge_15 ]
  %p_15_1 = phi i32 [ %p_13_1, %edge_15 ]
  %p_15_2 = phi i32 [ %p_13_2, %edge_15 ]
  %p_15_3 = phi i32 [ %p_13_3, %edge_15 ]
  %p_15_4 = phi i32 [ %p_13_4, %edge_15 ]
  %p_15_5 = phi i32 [ %p_13_5, %edge_15 ]
  %t36 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_15_0)
  %t37 = extractvalue { i32, i1 } %t36, 0
  %t38 = extractvalue { i32, i1 } %t36, 1
  %t39 = xor i1 %t38, true
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  br label %edge_17
b16:
  %p_16_0 = phi i32 [ %p_14_0, %edge_16 ], [ %t37, %edge_17 ]
  %p_16_1 = phi i32 [ %p_14_1, %edge_16 ], [ %p_15_1, %edge_17 ]
  %p_16_2 = phi i32 [ %p_14_2, %edge_16 ], [ %p_15_2, %edge_17 ]
  %p_16_3 = phi i32 [ %p_14_3, %edge_16 ], [ %p_15_3, %edge_17 ]
  %p_16_4 = phi i32 [ %p_14_4, %edge_16 ], [ %p_15_4, %edge_17 ]
  %p_16_5 = phi i32 [ %p_14_5, %edge_16 ], [ %p_15_5, %edge_17 ]
  %t41 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_16_5, i32 %p_16_0)
  %t42 = extractvalue { i32, i1 } %t41, 0
  %t43 = extractvalue { i32, i1 } %t41, 1
  %t44 = xor i1 %t43, true
  br i1 %t44, label %ok_45, label %trap_45
trap_45:
  call void @abort()
  unreachable
ok_45:
  ret i32 %t42
edge_0:
  br label %b9
edge_1:
  br label %b1
edge_2:
  br label %b2
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b8
edge_10:
  br label %b10
edge_11:
  br label %b11
edge_12:
  br label %b12
edge_13:
  br label %b13
edge_14:
  br label %b14
edge_15:
  br label %b15
edge_16:
  br label %b16
edge_17:
  br label %b16
}

define i32 @calculate(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_0(i32 %a0, i32 %a1)
  ret i32 %result
}
