#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>
typedef uint32_t (*kernel_t)(uint32_t, uint32_t);
typedef struct { uint32_t id, image, mode, seed, parameter, begin, count, repetitions; } request_t;
static request_t requests[256];
static uint32_t values[65536];
static const char *trace;
static uint64_t now(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) exit(95);
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}
static void limit(int resource, rlim_t n) {
    struct rlimit l = {n, n};
    if (setrlimit(resource, &l)) exit(83);
}
static uint64_t configured(int resource) {
    struct rlimit l;
    if (getrlimit(resource, &l)) exit(83);
    return (uint64_t)l.rlim_cur;
}
static uint32_t number(int delimiter) {
    int c = fgetc(stdin), first = c;
    uint64_t n = 0;
    unsigned digits = 0;
    while (c >= '0' && c <= '9') {
        if (++digits > 10 || (digits > 1 && first == '0')) exit(84);
        n = n * 10 + (unsigned)(c - '0');
        if (n > UINT32_MAX) exit(84);
        c = fgetc(stdin);
    }
    if (!digits || c != delimiter) exit(84);
    return (uint32_t)n;
}
static void flush(void) {
    if (ferror(stdout) || fflush(stdout)) exit(94);
}
static void image_event(uint32_t i, const char *kind) {
    printf("{\"image\":%" PRIu32 ",\"kind\":\"%s\",\"trace\":\"%s\"}\n", i, kind, trace);
    flush();
}
static void fault(uint32_t i, uint32_t code) {
    printf("{\"code\":%" PRIu32 ",\"image\":%" PRIu32 ",\"kind\":\"fault\",\"trace\":\"%s\"}\n", code, i, trace);
    flush();
}
int main(int argc, char **argv) {
    limit(RLIMIT_CORE, 0);
    limit(RLIMIT_CPU, 3);
    limit(RLIMIT_AS, (rlim_t)256 * 1024 * 1024);
    limit(RLIMIT_FSIZE, 128 * 1024);
    if (argc < 3 || argc > 10 || strlen(argv[1]) != 64) return 84;
    trace = argv[1];
    for (unsigned i = 0; i < 64; ++i)
        if (!((trace[i] >= '0' && trace[i] <= '9') || (trace[i] >= 'a' && trace[i] <= 'f'))) return 84;
    uint32_t images = (uint32_t)argc - 2, count = number('\n'), total = 0;
    uint64_t work = 0;
    if (!count || count > 256) return 84;
    for (uint32_t i = 0; i < count; ++i) {
        request_t *r = &requests[i];
        r->id = number(' '); r->image = number(' '); r->mode = number(' ');
        r->seed = number(' '); r->parameter = number(' '); r->count = number(' ');
        r->repetitions = r->mode == 2 ? number(' ') : 1;
        if (r->image >= images || r->mode > 2 || (!r->mode && r->parameter)
            || (r->mode == 2 && r->seed) || !r->repetitions || r->repetitions > 4096
            || !r->count || r->count > 65536 - total) return 84;
        work += (uint64_t)r->count * r->repetitions;
        if (work > UINT64_C(16777216)) return 84;
        for (uint32_t j = 0; j < i; ++j) if (requests[j].id == r->id) return 84;
        r->begin = total;
        for (uint32_t j = 0; j < r->count; ++j) {
            uint32_t value = number(j + 1 == r->count ? '\n' : ' ');
            if (r->mode == 1 && value > 255) return 84;
            values[total++] = value;
        }
    }
    if (fgetc(stdin) != EOF || ferror(stdin)) return 84;
    printf("{\"as_bytes\":%" PRIu64 ",\"core_bytes\":%" PRIu64 ",\"cpu_seconds\":%" PRIu64
           ",\"fsize_bytes\":%" PRIu64 ",\"kind\":\"limits\",\"trace\":\"%s\"}\n",
           configured(RLIMIT_AS), configured(RLIMIT_CORE), configured(RLIMIT_CPU), configured(RLIMIT_FSIZE), trace);
    flush();
    void *libraries[8] = {0};
    kernel_t kernels[8] = {0};
    uint32_t acquired = 0, closed = 0;
    int status = 0;
    for (uint32_t i = 0; i < images; ++i) {
        libraries[i] = dlopen(argv[i + 2], RTLD_NOW | RTLD_LOCAL);
        if (!libraries[i]) { fault(i, 86); status = 86; goto cleanup; }
        ++acquired;
        image_event(i, "opened");
        (void)dlerror();
        kernels[i] = (kernel_t)dlsym(libraries[i], "calculate");
        if (dlerror() || !kernels[i]) { fault(i, 87); status = 87; goto cleanup; }
        image_event(i, "ready");
    }
    for (uint32_t i = 0; i < count; ++i) {
        request_t *r = &requests[i];
        printf("{\"candidate\":%" PRIu32 ",\"id\":%" PRIu32 ",\"kind\":\"start\",\"seq\":%" PRIu32
               ",\"trace\":\"%s\"}\n", r->image, r->id, i, trace);
        flush();
        uint32_t state = r->seed;
        uint64_t checksum = 0;
        uint64_t kernel_start = r->mode == 2 ? now() : 0;
        for (uint32_t repetition = 0; repetition < r->repetitions; ++repetition)
          for (uint32_t j = 0; j < r->count; ++j) {
            uint32_t value = values[r->begin + j];
            state = r->mode == 2 ? kernels[r->image](value, r->parameter)
                    : r->mode ? kernels[r->image](state ^ value, r->parameter)
                            : kernels[r->image](state, value);
            checksum = checksum * UINT64_C(1099511628211) + state;
        }
        if (r->mode == 2) {
            uint64_t kernel_ns = now() - kernel_start;
            printf("{\"calls\":%" PRIu32 ",\"candidate\":%" PRIu32 ",\"checksum\":%" PRIu64
               ",\"id\":%" PRIu32 ",\"kernel_ns\":%" PRIu64 ",\"kind\":\"result\",\"mode\":2,\"parameter\":%" PRIu32
               ",\"repetitions\":%" PRIu32 ",\"seed\":0,\"seq\":%" PRIu32 ",\"state\":%" PRIu32 ",\"trace\":\"%s\"}\n",
               r->count * r->repetitions, r->image, checksum, r->id, kernel_ns,
               r->parameter, r->repetitions, i, state, trace);
        } else {
        printf("{\"calls\":%" PRIu32 ",\"candidate\":%" PRIu32 ",\"checksum\":%" PRIu64
               ",\"id\":%" PRIu32 ",\"kind\":\"result\",\"mode\":%" PRIu32 ",\"parameter\":%" PRIu32 ",\"seed\":%" PRIu32 ",\"seq\":%" PRIu32
               ",\"state\":%" PRIu32 ",\"trace\":\"%s\"}\n",
               r->count, r->image, checksum, r->id, r->mode, r->parameter, r->seed, i, state, trace);
        }
        flush();
        /* A later version can be selected only after this request returned. */
    }
cleanup:
    for (uint32_t n = acquired; n > 0; --n) {
        uint32_t i = n - 1;
        void *owned = libraries[i];
        libraries[i] = 0; kernels[i] = 0; /* Consume before a possibly uncertain close. */
        int ok = dlclose(owned) == 0;
        if (ok) ++closed; else status = 88;
        printf("{\"image\":%" PRIu32 ",\"kind\":\"closed\",\"ok\":%s,\"trace\":\"%s\"}\n",
               i, ok ? "true" : "false", trace);
        flush();
    }
    printf("{\"acquired\":%" PRIu32 ",\"closed\":%" PRIu32 ",\"kind\":\"finish\",\"ok\":%s,\"trace\":\"%s\"}\n",
           acquired, closed, status == 0 ? "true" : "false", trace);
    flush();
    return status;
}
