; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i32 %p_0_1, 8
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = icmp eq i32 %p_1_1, 10
  br i1 %t2, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i32 [ %p_1_0, %edge_3 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_3 ]
  br label %edge_4
b3:
  %p_3_0 = phi i32 [ %p_2_0, %edge_4 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_4 ]
  %t3 = icmp ne i32 %p_3_1, 0
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = icmp eq i32 %p_3_0, -2147483648
  %t6 = icmp eq i32 %p_3_1, -1
  %t7 = and i1 %t5, %t6
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = srem i32 %p_3_0, %p_3_1
  %t11 = trunc i64 0 to i32
  %t12 = icmp sge i32 %t10, %t11
  br i1 %t12, label %edge_5, label %edge_6
b4:
  %p_4_0 = phi i32 [ %p_3_0, %edge_5 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_5 ]
  %p_4_2 = phi i32 [ %p_3_0, %edge_5 ]
  %p_4_3 = phi i32 [ %p_3_1, %edge_5 ]
  %p_4_4 = phi i32 [ %t10, %edge_5 ]
  ret i32 %p_4_4
b5:
  %p_5_0 = phi i32 [ %p_3_0, %edge_6 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_6 ]
  %p_5_2 = phi i32 [ %p_3_0, %edge_6 ]
  %p_5_3 = phi i32 [ %p_3_1, %edge_6 ]
  %p_5_4 = phi i32 [ %t10, %edge_6 ]
  br label %edge_7
b6:
  %p_6_0 = phi i32 [ %p_5_3, %edge_7 ]
  %p_6_1 = phi i32 [ %p_5_0, %edge_7 ]
  %p_6_2 = phi i32 [ %p_5_1, %edge_7 ]
  %p_6_3 = phi i32 [ %p_5_2, %edge_7 ]
  %p_6_4 = phi i32 [ %p_5_3, %edge_7 ]
  %p_6_5 = phi i32 [ %p_5_4, %edge_7 ]
  %t13 = trunc i64 0 to i32
  %t14 = icmp slt i32 %p_6_0, %t13
  br i1 %t14, label %edge_8, label %edge_9
b7:
  %p_7_0 = phi i32 [ %p_6_0, %edge_8 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_7_2 = phi i32 [ %p_6_2, %edge_8 ]
  %p_7_3 = phi i32 [ %p_6_3, %edge_8 ]
  %p_7_4 = phi i32 [ %p_6_4, %edge_8 ]
  %p_7_5 = phi i32 [ %p_6_5, %edge_8 ]
  br label %edge_10
b8:
  %p_8_0 = phi i32 [ %p_6_0, %edge_9 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_9 ]
  %p_8_2 = phi i32 [ %p_6_2, %edge_9 ]
  %p_8_3 = phi i32 [ %p_6_3, %edge_9 ]
  %p_8_4 = phi i32 [ %p_6_4, %edge_9 ]
  %p_8_5 = phi i32 [ %p_6_5, %edge_9 ]
  %t15 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_8_0)
  %t16 = extractvalue { i32, i1 } %t15, 0
  %t17 = extractvalue { i32, i1 } %t15, 1
  %t18 = xor i1 %t17, true
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  br label %edge_11
b9:
  %p_9_0 = phi i32 [ %p_7_0, %edge_10 ], [ %t16, %edge_11 ]
  %p_9_1 = phi i32 [ %p_7_1, %edge_10 ], [ %p_8_1, %edge_11 ]
  %p_9_2 = phi i32 [ %p_7_2, %edge_10 ], [ %p_8_2, %edge_11 ]
  %p_9_3 = phi i32 [ %p_7_3, %edge_10 ], [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i32 [ %p_7_4, %edge_10 ], [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i32 [ %p_7_5, %edge_10 ], [ %p_8_5, %edge_11 ]
  %t20 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_9_5, i32 %p_9_0)
  %t21 = extractvalue { i32, i1 } %t20, 0
  %t22 = extractvalue { i32, i1 } %t20, 1
  %t23 = xor i1 %t22, true
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  ret i32 %t21
b10:
  %p_10_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_10_1 = phi i32 [ 8, %edge_0 ]
  br label %edge_12
b11:
  %p_11_0 = phi i32 [ %p_10_0, %edge_12 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ]
  %t25 = icmp ne i32 %p_11_1, 0
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = icmp eq i32 %p_11_0, -2147483648
  %t28 = icmp eq i32 %p_11_1, -1
  %t29 = and i1 %t27, %t28
  %t30 = xor i1 %t29, true
  br i1 %t30, label %ok_31, label %trap_31
trap_31:
  call void @abort()
  unreachable
ok_31:
  %t32 = srem i32 %p_11_0, %p_11_1
  %t33 = trunc i64 0 to i32
  %t34 = icmp sge i32 %t32, %t33
  br i1 %t34, label %edge_13, label %edge_14
b12:
  %p_12_0 = phi i32 [ %p_11_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_11_1, %edge_13 ]
  %p_12_2 = phi i32 [ %p_11_0, %edge_13 ]
  %p_12_3 = phi i32 [ %p_11_1, %edge_13 ]
  %p_12_4 = phi i32 [ %t32, %edge_13 ]
  ret i32 %p_12_4
b13:
  %p_13_0 = phi i32 [ %p_11_0, %edge_14 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_13_2 = phi i32 [ %p_11_0, %edge_14 ]
  %p_13_3 = phi i32 [ %p_11_1, %edge_14 ]
  %p_13_4 = phi i32 [ %t32, %edge_14 ]
  br label %edge_15
b14:
  %p_14_0 = phi i32 [ %p_13_3, %edge_15 ]
  %p_14_1 = phi i32 [ %p_13_0, %edge_15 ]
  %p_14_2 = phi i32 [ %p_13_1, %edge_15 ]
  %p_14_3 = phi i32 [ %p_13_2, %edge_15 ]
  %p_14_4 = phi i32 [ %p_13_3, %edge_15 ]
  %p_14_5 = phi i32 [ %p_13_4, %edge_15 ]
  %t35 = trunc i64 0 to i32
  %t36 = icmp slt i32 %p_14_0, %t35
  br i1 %t36, label %edge_16, label %edge_17
b15:
  %p_15_0 = phi i32 [ %p_14_0, %edge_16 ]
  %p_15_1 = phi i32 [ %p_14_1, %edge_16 ]
  %p_15_2 = phi i32 [ %p_14_2, %edge_16 ]
  %p_15_3 = phi i32 [ %p_14_3, %edge_16 ]
  %p_15_4 = phi i32 [ %p_14_4, %edge_16 ]
  %p_15_5 = phi i32 [ %p_14_5, %edge_16 ]
  br label %edge_18
b16:
  %p_16_0 = phi i32 [ %p_14_0, %edge_17 ]
  %p_16_1 = phi i32 [ %p_14_1, %edge_17 ]
  %p_16_2 = phi i32 [ %p_14_2, %edge_17 ]
  %p_16_3 = phi i32 [ %p_14_3, %edge_17 ]
  %p_16_4 = phi i32 [ %p_14_4, %edge_17 ]
  %p_16_5 = phi i32 [ %p_14_5, %edge_17 ]
  %t37 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_16_0)
  %t38 = extractvalue { i32, i1 } %t37, 0
  %t39 = extractvalue { i32, i1 } %t37, 1
  %t40 = xor i1 %t39, true
  br i1 %t40, label %ok_41, label %trap_41
trap_41:
  call void @abort()
  unreachable
ok_41:
  br label %edge_19
b17:
  %p_17_0 = phi i32 [ %p_15_0, %edge_18 ], [ %t38, %edge_19 ]
  %p_17_1 = phi i32 [ %p_15_1, %edge_18 ], [ %p_16_1, %edge_19 ]
  %p_17_2 = phi i32 [ %p_15_2, %edge_18 ], [ %p_16_2, %edge_19 ]
  %p_17_3 = phi i32 [ %p_15_3, %edge_18 ], [ %p_16_3, %edge_19 ]
  %p_17_4 = phi i32 [ %p_15_4, %edge_18 ], [ %p_16_4, %edge_19 ]
  %p_17_5 = phi i32 [ %p_15_5, %edge_18 ], [ %p_16_5, %edge_19 ]
  %t42 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_17_5, i32 %p_17_0)
  %t43 = extractvalue { i32, i1 } %t42, 0
  %t44 = extractvalue { i32, i1 } %t42, 1
  %t45 = xor i1 %t44, true
  br i1 %t45, label %ok_46, label %trap_46
trap_46:
  call void @abort()
  unreachable
ok_46:
  ret i32 %t43
b18:
  %p_18_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_18_1 = phi i32 [ 10, %edge_2 ]
  br label %edge_20
b19:
  %p_19_0 = phi i32 [ %p_18_0, %edge_20 ]
  %p_19_1 = phi i32 [ %p_18_1, %edge_20 ]
  %t47 = icmp ne i32 %p_19_1, 0
  br i1 %t47, label %ok_48, label %trap_48
trap_48:
  call void @abort()
  unreachable
ok_48:
  %t49 = icmp eq i32 %p_19_0, -2147483648
  %t50 = icmp eq i32 %p_19_1, -1
  %t51 = and i1 %t49, %t50
  %t52 = xor i1 %t51, true
  br i1 %t52, label %ok_53, label %trap_53
trap_53:
  call void @abort()
  unreachable
ok_53:
  %t54 = srem i32 %p_19_0, %p_19_1
  %t55 = trunc i64 0 to i32
  %t56 = icmp sge i32 %t54, %t55
  br i1 %t56, label %edge_21, label %edge_22
b20:
  %p_20_0 = phi i32 [ %p_19_0, %edge_21 ]
  %p_20_1 = phi i32 [ %p_19_1, %edge_21 ]
  %p_20_2 = phi i32 [ %p_19_0, %edge_21 ]
  %p_20_3 = phi i32 [ %p_19_1, %edge_21 ]
  %p_20_4 = phi i32 [ %t54, %edge_21 ]
  ret i32 %p_20_4
b21:
  %p_21_0 = phi i32 [ %p_19_0, %edge_22 ]
  %p_21_1 = phi i32 [ %p_19_1, %edge_22 ]
  %p_21_2 = phi i32 [ %p_19_0, %edge_22 ]
  %p_21_3 = phi i32 [ %p_19_1, %edge_22 ]
  %p_21_4 = phi i32 [ %t54, %edge_22 ]
  br label %edge_23
b22:
  %p_22_0 = phi i32 [ %p_21_3, %edge_23 ]
  %p_22_1 = phi i32 [ %p_21_0, %edge_23 ]
  %p_22_2 = phi i32 [ %p_21_1, %edge_23 ]
  %p_22_3 = phi i32 [ %p_21_2, %edge_23 ]
  %p_22_4 = phi i32 [ %p_21_3, %edge_23 ]
  %p_22_5 = phi i32 [ %p_21_4, %edge_23 ]
  %t57 = trunc i64 0 to i32
  %t58 = icmp slt i32 %p_22_0, %t57
  br i1 %t58, label %edge_24, label %edge_25
b23:
  %p_23_0 = phi i32 [ %p_22_0, %edge_24 ]
  %p_23_1 = phi i32 [ %p_22_1, %edge_24 ]
  %p_23_2 = phi i32 [ %p_22_2, %edge_24 ]
  %p_23_3 = phi i32 [ %p_22_3, %edge_24 ]
  %p_23_4 = phi i32 [ %p_22_4, %edge_24 ]
  %p_23_5 = phi i32 [ %p_22_5, %edge_24 ]
  br label %edge_26
b24:
  %p_24_0 = phi i32 [ %p_22_0, %edge_25 ]
  %p_24_1 = phi i32 [ %p_22_1, %edge_25 ]
  %p_24_2 = phi i32 [ %p_22_2, %edge_25 ]
  %p_24_3 = phi i32 [ %p_22_3, %edge_25 ]
  %p_24_4 = phi i32 [ %p_22_4, %edge_25 ]
  %p_24_5 = phi i32 [ %p_22_5, %edge_25 ]
  %t59 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_24_0)
  %t60 = extractvalue { i32, i1 } %t59, 0
  %t61 = extractvalue { i32, i1 } %t59, 1
  %t62 = xor i1 %t61, true
  br i1 %t62, label %ok_63, label %trap_63
trap_63:
  call void @abort()
  unreachable
ok_63:
  br label %edge_27
b25:
  %p_25_0 = phi i32 [ %p_23_0, %edge_26 ], [ %t60, %edge_27 ]
  %p_25_1 = phi i32 [ %p_23_1, %edge_26 ], [ %p_24_1, %edge_27 ]
  %p_25_2 = phi i32 [ %p_23_2, %edge_26 ], [ %p_24_2, %edge_27 ]
  %p_25_3 = phi i32 [ %p_23_3, %edge_26 ], [ %p_24_3, %edge_27 ]
  %p_25_4 = phi i32 [ %p_23_4, %edge_26 ], [ %p_24_4, %edge_27 ]
  %p_25_5 = phi i32 [ %p_23_5, %edge_26 ], [ %p_24_5, %edge_27 ]
  %t64 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_25_5, i32 %p_25_0)
  %t65 = extractvalue { i32, i1 } %t64, 0
  %t66 = extractvalue { i32, i1 } %t64, 1
  %t67 = xor i1 %t66, true
  br i1 %t67, label %ok_68, label %trap_68
trap_68:
  call void @abort()
  unreachable
ok_68:
  ret i32 %t65
edge_0:
  br label %b10
edge_1:
  br label %b1
edge_2:
  br label %b18
edge_3:
  br label %b2
edge_4:
  br label %b3
edge_5:
  br label %b4
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b9
edge_11:
  br label %b9
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b16
edge_18:
  br label %b17
edge_19:
  br label %b17
edge_20:
  br label %b19
edge_21:
  br label %b20
edge_22:
  br label %b21
edge_23:
  br label %b22
edge_24:
  br label %b23
edge_25:
  br label %b24
edge_26:
  br label %b25
edge_27:
  br label %b25
}

define i32 @calculate(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_0(i32 %a0, i32 %a1)
  ret i32 %result
}
