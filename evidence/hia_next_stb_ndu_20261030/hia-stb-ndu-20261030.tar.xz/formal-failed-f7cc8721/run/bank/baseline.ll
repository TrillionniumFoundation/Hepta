; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i32 %p_0_0, i32 %p_0_1) {
b0:
  br label %edge_0
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t1 = icmp ne i32 %p_1_1, 0
  br i1 %t1, label %ok_2, label %trap_2
trap_2:
  call void @abort()
  unreachable
ok_2:
  %t3 = icmp eq i32 %p_1_0, -2147483648
  %t4 = icmp eq i32 %p_1_1, -1
  %t5 = and i1 %t3, %t4
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = srem i32 %p_1_0, %p_1_1
  %t9 = trunc i64 0 to i32
  %t10 = icmp sge i32 %t8, %t9
  br i1 %t10, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_1_0, %edge_1 ]
  %p_2_3 = phi i32 [ %p_1_1, %edge_1 ]
  %p_2_4 = phi i32 [ %t8, %edge_1 ]
  ret i32 %p_2_4
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i32 [ %p_1_0, %edge_2 ]
  %p_3_3 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_4 = phi i32 [ %t8, %edge_2 ]
  br label %edge_3
b4:
  %p_4_0 = phi i32 [ %p_3_3, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_0, %edge_3 ]
  %p_4_2 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_3 = phi i32 [ %p_3_2, %edge_3 ]
  %p_4_4 = phi i32 [ %p_3_3, %edge_3 ]
  %p_4_5 = phi i32 [ %p_3_4, %edge_3 ]
  %t11 = trunc i64 0 to i32
  %t12 = icmp slt i32 %p_4_0, %t11
  br i1 %t12, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i32 [ %p_4_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_4 ]
  %p_5_2 = phi i32 [ %p_4_2, %edge_4 ]
  %p_5_3 = phi i32 [ %p_4_3, %edge_4 ]
  %p_5_4 = phi i32 [ %p_4_4, %edge_4 ]
  %p_5_5 = phi i32 [ %p_4_5, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_5 ]
  %p_6_2 = phi i32 [ %p_4_2, %edge_5 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_5 ]
  %p_6_4 = phi i32 [ %p_4_4, %edge_5 ]
  %p_6_5 = phi i32 [ %p_4_5, %edge_5 ]
  %t13 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %p_6_0)
  %t14 = extractvalue { i32, i1 } %t13, 0
  %t15 = extractvalue { i32, i1 } %t13, 1
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  br label %edge_7
b7:
  %p_7_0 = phi i32 [ %p_5_0, %edge_6 ], [ %t14, %edge_7 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_6_1, %edge_7 ]
  %p_7_2 = phi i32 [ %p_5_2, %edge_6 ], [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_6 ], [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i32 [ %p_5_4, %edge_6 ], [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i32 [ %p_5_5, %edge_6 ], [ %p_6_5, %edge_7 ]
  %t18 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %p_7_5, i32 %p_7_0)
  %t19 = extractvalue { i32, i1 } %t18, 0
  %t20 = extractvalue { i32, i1 } %t18, 1
  %t21 = xor i1 %t20, true
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  ret i32 %t19
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b7
}

define i32 @calculate(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_0(i32 %a0, i32 %a1)
  ret i32 %result
}
