"""One frozen study invocation; stdout/stderr and all termination costs retained."""
from pathlib import Path
import hashlib
import json
import os
import platform
import shutil
import signal
import subprocess
import time
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/f0c12f106c89/hepta-integration')
HEAD = '44e34b7a9ecd6bf1b3ad6093d21bba10d2a18304'
TREE = '835555fb35dbdcf867724ef7a0bb1a6616270217'
PYTHON = '/workspace/scratch/f0c12f106c89/hepta-native-venv/bin/python'
CLANG = '/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/llvm-20/bin/clang'
IDENTITY = Path('/workspace/scratch/f0c12f106c89/ndu-builds/stream/identity.json')
LIMIT_NS = 900_000_000_000


def save(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')


def file_identity(path):
    path = Path(path).resolve(strict=True)
    with path.open('rb') as stream:
        return {'path': str(path), 'bytes': path.stat().st_size,
                'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}


def source():
    def git(*args):
        return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT).decode().strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


def host():
    mem = {}
    for row in Path('/proc/meminfo').read_text().splitlines():
        key, value = row.split(':', 1)
        if key in {'MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'}:
            mem[key] = value.strip()
    cgroups = {}
    for name in ('cpu.max', 'memory.max', 'memory.current'):
        path = Path('/sys/fs/cgroup') / name
        cgroups[name] = path.read_text().strip() if path.exists() else None
    return {'utc': datetime.now(timezone.utc).isoformat(), 'platform': platform.platform(),
            'load_average_1_5_15': os.getloadavg(), 'cpu_affinity_count': len(os.sched_getaffinity(0)),
            'memory': mem, 'cgroups': cgroups, 'free_bytes': shutil.disk_usage(OUT).free,
            'pid_namespace': os.readlink('/proc/self/ns/pid'),
            'dedicated_physical_host_attested': False,
            'coordination': 'Root opened the sole local native/model heavy-task window; other team agents idle.'}


def main():
    if (OUT / 'PLAN.json').exists() or (OUT / 'run').exists():
        raise RuntimeError('No retry or output reuse is permitted')
    started = time.monotonic_ns()
    receipt = {'schema': 'hepta.hia.stb-ndu.external-execution.v1', 'stage': 'study',
               'started_utc': datetime.now(timezone.utc).isoformat(), 'budget_ns': LIMIT_NS,
               'performance_timing_qualified': False, 'economic_study_attempts': 1,
               'retry_permitted': False, 'termination_events': [], 'errors': [],
               'attempt_role': 'explicit software-defect revalidation; identical candidate/input/budget/protocol',
               'previous_failed_result_sha256': '411a8eabb85adbee5334afe0c684b42de39367f2b74ae3caa515ec7674465ae9',
               'previous_failed_result_qualified': False,
               'measurement_boundary': 'launcher main preflight through child termination; launcher imports and later audit separately scoped',
               'launcher': file_identity(__file__)}
    process = None
    try:
        receipt['source_before'] = source()
        assert receipt['source_before'] == {'head': HEAD, 'tree': TREE, 'status': ''}
        manifest = json.loads(IDENTITY.read_bytes())
        bound = {'python': PYTHON, 'clang': CLANG, 'native_manifest': IDENTITY,
                 'native_binary': manifest['binary'],
                 'protocol': ROOT / 'experiments/hia_stb_ndu_20261030/PROTOCOL.json'}
        receipt['tools_before'] = {key: file_identity(path) for key, path in bound.items()}
        receipt['host_before'] = host()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CLANG=CLANG,
            LD_LIBRARY_PATH='/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/x86_64-linux-gnu',
            PATH='/workspace/scratch/f0c12f106c89/hepta-native-venv/bin:/workspace/scratch/f0c12f106c89/toolchains/llvm20/usr/lib/llvm-20/bin:/usr/bin:/bin')
        argv = [PYTHON, 'tools/qualify_hia_stb_ndu.py', '--stage', 'study', '--output', str(OUT / 'run'),
                '--expected-head', HEAD, '--clang', CLANG, '--identity', str(IDENTITY)]
        receipt.update(argv=argv, cwd=str(ROOT), environment={key: env[key] for key in
            ('PYTHONDONTWRITEBYTECODE', 'CLANG', 'LD_LIBRARY_PATH', 'PATH')},
            stdout='stdout', stderr='stderr')
        save('PLAN.json', receipt)
        with (OUT / 'stdout').open('xb') as stdout, (OUT / 'stderr').open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            receipt['pid'] = process.pid
            save('STARTED.json', {'pid': process.pid, 'source': HEAD,
                                'started_utc': datetime.now(timezone.utc).isoformat()})
            remaining = max(0, (LIMIT_NS - (time.monotonic_ns() - started)) / 1e9)
            try:
                process.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                receipt['termination_events'].append({'reason': '900-second total budget exceeded',
                    'signal': 'SIGINT', 'wall_ns': time.monotonic_ns() - started})
                os.killpg(process.pid, signal.SIGINT)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    receipt['termination_events'].append({'reason': 'bounded cleanup grace exhausted',
                        'signal': 'SIGKILL', 'wall_ns': time.monotonic_ns() - started})
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
            receipt['returncode'] = process.returncode
            receipt['study_process_wall_ns'] = time.monotonic_ns() - started
    except BaseException as error:
        receipt['errors'].append({'type': type(error).__name__, 'message': str(error)})
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
        if process is not None:
            receipt['returncode'] = process.returncode
    finally:
        receipt.setdefault('study_process_wall_ns', time.monotonic_ns() - started)
        for key, callback in (('source_after', source), ('host_after', host),
                ('tools_after', lambda: {key: file_identity(value['path']) for key, value in receipt.get('tools_before', {}).items()})):
            try:
                receipt[key] = callback()
            except BaseException as error:
                receipt['errors'].append({'stage': key, 'type': type(error).__name__, 'message': str(error)})
        terminal = OUT / 'run/RESULT.json'
        if terminal.exists():
            receipt['result_identity'] = file_identity(terminal)
            result = json.loads(terminal.read_bytes())
            receipt['internal_qualified'] = result.get('qualified')
            receipt['internal_status'] = result.get('status')
        receipt['identities_unchanged'] = (receipt.get('source_before') == receipt.get('source_after')
            and receipt.get('tools_before') == receipt.get('tools_after') and 'source_before' in receipt)
        receipt['total_wall_ns_before_receipt_encoding'] = time.monotonic_ns() - started
        receipt['within_total_budget'] = receipt['total_wall_ns_before_receipt_encoding'] <= LIMIT_NS
        receipt['qualified_complete_observation'] = bool(receipt.get('returncode') == 0
            and receipt.get('internal_qualified') is True and receipt['identities_unchanged']
            and receipt['within_total_budget'] and not receipt['errors'] and not receipt['termination_events'])
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save('EXECUTION.json', receipt)
    print(json.dumps({key: receipt.get(key) for key in ('returncode', 'internal_status',
        'qualified_complete_observation', 'total_wall_ns_before_receipt_encoding', 'termination_events', 'errors')}), flush=True)


if __name__ == '__main__':
    main()
