"""Read recorded qualification evidence; never compile, test or edit the repo."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import zipfile

BASE = Path('/workspace/scratch/bf7d454bbc83')
OUT = BASE / 'hia-evidence-audit'
RUNS = {'run1': BASE / 'hia-final-qualification', 'run2': BASE / 'hia-final-qualification-run2'}


def load(path):
    return json.loads(path.read_text()) if path.exists() else None


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def ref(path):
    return {'path': str(path), 'sha256': digest(path)}


def select(value, fields):
    return {k: value.get(k) for k in fields}


def failure_accounting(execution):
    text = execution['execution']['stderr']
    starts = list(re.finditer(r'^(ERROR|FAIL): ([^\n]+)', text, re.M))
    entries = []
    for index, match in enumerate(starts):
        block = text[match.start():starts[index + 1].start() if index + 1 < len(starts) else len(text)]
        ident = re.search(r'\((test_[^)]+)\)', match.group(2))
        cause = ('missing_python_fcntl_seal_names' if "has no attribute 'F_SEAL_WRITE'" in block else
                 'missing_qemu_system_arm' if 'qemu-system-arm is required' in block else
                 'missing_thumbv7em_core_target' if 'thumbv7em-none-eabi' in block and "find crate for `core`" in block else
                 'other')
        entries.append({'kind': match.group(1), 'header': match.group(2),
                        'identity': ident.group(1) if ident else match.group(2), 'cause': cause,
                        'class_setup': match.group(2).startswith('setUpClass ')})
    identities = {entry['identity'] for entry in entries}
    groups = {}
    for cause in sorted({entry['cause'] for entry in entries}):
        values = [entry for entry in entries if entry['cause'] == cause]
        groups[cause] = {'entries': len(values), 'kinds': dict(Counter(e['kind'] for e in values)),
                         'distinct_affected_identities': len({e['identity'] for e in values})}
    return {'reported': select(execution, ('tests_run', 'failures', 'errors', 'skipped', 'passed')),
            'actual_failed_entry_count': len(entries), 'entry_kind_counts': dict(Counter(e['kind'] for e in entries)),
            'distinct_affected_identities': len(identities),
            'distinct_test_methods': len({e['identity'] for e in entries if not e['class_setup']}),
            'distinct_class_setup_identities': len({e['identity'] for e in entries if e['class_setup']}),
            'failure_categories': groups,
            'entries_are_not_unique_bugs': True,
            'passed_test_count_not_derived_by_subtracting_subtest_entries': True}


def artifacts(builds, directory):
    records = {}
    for label, build in builds.items():
        path = directory / (label + '.so')
        expected = build['artifact_sha256']
        observed = digest(path)
        records[label] = {'path': str(path), 'recorded_sha256': expected,
                          'observed_sha256': observed, 'matches': expected == observed}
    return records


def analyze_run(directory):
    frozen_path = directory / 'frozen-plan.json'
    frozen = load(frozen_path)
    if frozen is None:
        return {'directory': str(directory), 'state': 'not_started'}
    summary_path = directory / 'qualification.json'
    summary = load(summary_path)
    result = {'directory': str(directory), 'source_revision': frozen['source_revision'],
              'state': 'complete' if summary else 'in_progress', 'frozen_plan': ref(frozen_path)}
    if summary:
        result['aggregate'] = select(summary, ('ok', 'status', 'mechanism_qualified', 'source_is_committed',
            'source_unchanged', 'source_revision_after', 'started_utc', 'finished_utc', 'six_stages_closed',
            'scientific_incremental_advantage_established', 'global_optimality_established', 'whole_language_soundness_proved',
            'native_bridge_sha256', 'ndu_build_receipt_sha256'))
        result['aggregate']['source_inventory_before_equals_after'] = summary['source_inventory_before'] == summary['source_inventory_after']
        result['aggregate']['source_inventory_entry_count'] = len(summary['source_inventory_before'])
        result['qualification_record'] = ref(summary_path)
    gates = []
    for command in frozen['commands']:
        path = directory / (command['name'] + '-execution.json')
        execution = load(path)
        row = {'name': command['name'], 'state': 'record_available' if execution else 'pending'}
        if execution:
            row.update(select(execution, ('passed', 'tests_run', 'failures', 'errors', 'skipped')))
            row['seconds'] = execution['execution']['seconds']
            row['returncode'] = execution['execution']['returncode']
            row['execution_record'] = ref(path)
            if 'evidence' in execution:
                evidence = Path(execution['evidence'])
                row['evidence'] = ref(evidence)
                row['recorded_evidence_sha256'] = execution['evidence_sha256']
                row['evidence_hash_matches'] = row['evidence']['sha256'] == execution['evidence_sha256']
        gates.append(row)
    result['gates'] = gates
    result['gate_counts'] = {'planned': len(gates), 'records_available': sum(g['state'] == 'record_available' for g in gates),
                            'passed': sum(g.get('passed') is True for g in gates),
                            'failed': sum(g.get('passed') is False for g in gates),
                            'pending': sum(g['state'] == 'pending' for g in gates)}
    full = load(directory / 'full_regression-execution.json')
    if full:
        result['full_regression_accounting'] = failure_accounting(full)
    focused = load(directory / 'focused_regression-execution.json')
    if focused:
        result['focused'] = select(focused, ('tests_run', 'failures', 'errors', 'skipped', 'passed'))
    rust = load(directory / 'rust_resource_crate-execution.json')
    if rust:
        counts = [tuple(map(int, x)) for x in re.findall(
            r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
            rust['execution']['stdout'])]
        result['rust_tests'] = select(rust, ('tests_run', 'failures', 'skipped', 'filtered_out', 'measured', 'test_binaries', 'passed'))
        result['rust_tests'].update(recounted_passed=sum(x[0] for x in counts),
                                    nonempty_result_groups=sum(x[0] > 0 for x in counts))
    translation = load(directory / 'translation.json')
    if translation:
        result['translation'] = {'evidence': ref(directory / 'translation.json'), 'ok': translation['ok'],
            'actual_statuses': {k: v['status'] for k, v in translation['cases'].items()},
            'expected_statuses': translation['expected_statuses'],
            'forged_proved_receipt_rejected': translation['forged_proved_receipt_rejected'], 'claims': translation['claims']}
    cfg = load(directory / 'rust-cfg.json')
    if cfg:
        result['rust_cfg'] = {'evidence': ref(directory / 'rust-cfg.json'), 'ok': cfg['ok'],
            'reported_pairs': cfg['parity_observations'], 'observed_pair_records': len(cfg['observations']),
            'distinct_programs': len(cfg['programs_by_sha256']), 'tests': cfg['tests'],
            'source_unchanged': cfg['source_unchanged'], 'claims': cfg['claims'], 'limits': cfg['limits']}
    migration = load(directory / 'migration/qualification.json')
    if migration:
        native_path = Path(migration['native_report']['path'])
        native = load(native_path)
        denominators = migration['denominators']
        result['migration'] = {'evidence': ref(directory / 'migration/qualification.json'),
            'native_evidence': ref(native_path), 'native_evidence_hash_matches': digest(native_path) == migration['native_report']['sha256'],
            'ok': migration['ok'], 'denominators': denominators,
            'unique_native_case_vectors_per_implementation': (denominators['c_multi_owner_native_cases_per_implementation']
                + denominators['cpp_scalar_class_native_cases_per_implementation'] + denominators['cpp_byte_owner_native_cases_per_implementation']),
            'native_result_executions_recounted': 2 * (len(native['multi_owner_cases']) + len(native['cpp_class_cases']) + native['cpp_owned']['case_count']),
            'native_fault_executions_already_in_total': native['actual_fault_executions'],
            'actual_python_rust_pair_records': len(migration['observations']),
            'python_rust_pairs_by_family': dict(Counter(x['case']['family'] for x in migration['observations'])),
            'distinct_programs': len(migration['programs_by_sha256']), 'claims': migration['claims']}
    ndu = load(directory / 'ndu-search.json')
    if ndu:
        native_files = artifacts(ndu['native_builds'], directory / 'ndu-native')
        decisions = {}
        for name, decision in ndu['policy_decisions'].items():
            item = select(decision, ('selected_id', 'proposed_id', 'policy_cost_ns', 'search_cost_ns',
                                    'within_resource_cap', 'baseline_lower_cost_ns', 'candidate_upper_cost_ns'))
            if name == 'ndu':
                ranking = decision['report']
                item.update(ranker_internal_costs=ranking['costs'], actual_outer_call_ns=decision['policy_cost_ns'],
                            actual_outer_total_search_ns=ndu['equal_budget']['shared_search_cost_ns'] + decision['policy_cost_ns'],
                            native_entry_point=ranking['native_response']['entry_point'], native_authority=ranking['native_response']['authority'],
                            reason=ranking['reason'], bridge=ranking['bridge'])
            else:
                item['actual_total_search_and_policy_ns'] = item['search_cost_ns'] + item['policy_cost_ns']
            decisions[name] = item
        training, holdout = ndu['training_samples'], ndu['holdout_samples']
        result['ndu'] = {'evidence': ref(directory / 'ndu-search.json'),
            'qualified_for_finite_paired_replay': ndu['qualified_for_finite_paired_replay'],
            'source_inputs_unchanged': ndu['source_inputs_unchanged'], 'candidate_count': len(ndu['candidates']),
            'proof_statuses': dict(Counter(x['status'] for x in ndu['translation_receipts'].values())),
            'training_samples': len(training), 'holdout_samples': len(holdout),
            'sample_statuses': dict(Counter(x['status'] for x in training + holdout)),
            'timed_native_calls': sum(x['iterations'] for x in training + holdout),
            'warmup_calls_separate': (len(training) + len(holdout)) * ndu['protocol']['warmup_iterations'],
            'distinct_artifact_hashes': sorted({x['observed_sha256'] for x in native_files.values()}),
            'artifacts_rehashed': native_files, 'equal_budget': ndu['equal_budget'], 'objective': ndu['objective'],
            'policy_decisions': decisions, 'claims': ndu['claims']}
    multiversion = load(directory / 'multiversion.json')
    if multiversion:
        result['multiversion'] = {'evidence': ref(directory / 'multiversion.json'),
            'qualified': multiversion['qualified_for_declared_finite_lifecycle'],
            'generations': len(multiversion['generations']),
            'native_admission_probe_calls': multiversion['native_probe_calls'],
            'additional_lifecycle_observations': len(multiversion['native_observations']),
            'independent_export_translation_proofs': multiversion['independent_export_translation_proofs'],
            'claims': multiversion['claims']}
    background = load(directory / 'background.json')
    if background:
        trials = {}
        for name, trial in background['trials'].items():
            ranking = trial.get('ranking') or {}
            trials[name] = {'status': trial['status'], 'selected_id': trial['selected_id'],
                'reason': trial['reason'], 'objective': ranking.get('objective'), 'ranking_costs': ranking.get('costs'),
                'actual_publication': trial.get('publication') is not None,
                'costs': trial['costs'],
                'candidate_model_statuses': {c['id']: c.get('proof', {}).get('status') for c in ranking.get('candidate_reports', [])}}
        measured = background['measurements']
        timed = sum(s['calls'] for label in ('baseline', 'candidate') for s in measured[label]['samples'])
        result['background'] = {'evidence': ref(directory / 'background.json'), 'ok': background['ok'],
            'actual_native_ndu_invocations': background['actual_native_ndu_invocations'],
            'reported_native_measurement_calls_including_warmup': background['native_measurement_calls'],
            'timed_native_lease_calls': timed,
            'warmup_native_calls': background['native_measurement_calls'] - timed,
            'timing_scope': measured['baseline']['scope'], 'trials': trials, 'claims': background['claims']}
    x86 = load(directory / 'x86-search.json')
    if x86:
        files = artifacts(x86['native_builds'], directory / 'x86-native')
        result['x86'] = {'evidence': ref(directory / 'x86-search.json'),
            **select(x86, ('ok', 'source_inputs_unchanged', 'minimum_encoded_bytes', 'llvm_baseline_encoded_bytes',
                'finite_minimum_encoded_bytes_proved', 'selected_id', 'selected_native_body_identical_to_llvm',
                'timed_native_call_count', 'edge_native_call_count', 'search_and_all_build_wall_ns',
                'global_optimality_established', 'native_backend_refinement_proved', 'runtime_improvement_established')),
            'grammar_size': len(x86['search']['candidates']),
            'model_proof_statuses': dict(Counter(x['proof']['status'] for x in x86['search']['candidates'])),
            'native_built_artifacts_including_llvm': len(x86['native_builds']),
            'timed_samples': len(x86['native_samples']), 'sample_statuses': dict(Counter(x['status'] for x in x86['native_samples'])),
            'timed_native_calls_recounted': sum(x['iterations'] for x in x86['native_samples']),
            'edge_native_calls_recounted': sum(len(x['outputs']) for x in x86['edge_samples']),
            'warmup_calls_separate': len(x86['native_samples']) * x86['protocol']['warmup_iterations'],
            'selected_machine_body': x86['native_body_inspections'][x86['selected_id']]['code_hex'],
            'empirical_timing_relations': dict(Counter(x['empirical_relation'] for x in x86['comparisons_to_llvm_o3'])),
            'artifacts_rehashed': files, 'limits': x86['limits']}
    return result


def analyze_host_ci():
    directory = BASE / 'hia-source-host-ci'
    run = load(directory / 'workflow-run.json')
    workflow_jobs = load(directory / 'workflow-jobs.json')
    workflow_artifacts = load(directory / 'workflow-artifacts.json')
    tree = load(directory / 'remote-source-tree.json')
    api_artifacts = {x['id']: x for x in workflow_artifacts['artifacts']} if workflow_artifacts else {}
    source_tree_binding = None
    if tree:
        local_tree = subprocess.run(['git', 'rev-parse', tree['local_tested_commit'] + '^{tree}'],
            cwd=BASE / 'hepta', check=True, capture_output=True, text=True).stdout.strip()
        source_tree_binding = {'evidence': ref(directory / 'remote-source-tree.json'),
            'local_tested_commit': tree['local_tested_commit'], 'local_git_tree_independently_read': local_tree,
            'remote_ci_commit': tree['remote_commit']['sha'], 'remote_api_tree': tree['remote_commit']['tree']['sha'],
            'trees_equal': local_tree == tree['local_tree'] == tree['remote_commit']['tree']['sha'],
            'retrieval_url': tree['retrieval_url']}
    jobs = []
    for metadata_path in sorted(directory.glob('*-metadata.json')):
        metadata = load(metadata_path)
        zip_path = Path(metadata['zip_path'])
        report_path = directory / str(metadata['id']) / 'native-host.json'
        report = load(report_path)
        source_match = re.search(r'-([0-9a-f]{40})$', metadata['name'])
        api_artifact = api_artifacts.get(metadata['id'])
        api_binding_matches = bool(api_artifact and run and api_artifact['name'] == metadata['name']
            and api_artifact['digest'] == 'sha256:' + digest(zip_path)
            and api_artifact['workflow_run']['id'] == run['id']
            and api_artifact['workflow_run']['head_sha'] == run['head_sha']
            and source_match and source_match.group(1) == run['head_sha'])
        with zipfile.ZipFile(zip_path) as artifact:
            names = artifact.namelist()
            matching = [n for n in names if n.endswith('native-host.json')]
            raw_report_matches = len(matching) == 1 and artifact.read(matching[0]) == report_path.read_bytes()
            members = [{'name': n, 'bytes': artifact.getinfo(n).file_size,
                        'sha256': sha256(artifact.read(n)).hexdigest()} for n in names]
        expected_calls = report['matrix']['expected_foreign_calls_per_run']
        all_runs_match = len(report['executions']) == 2 and all(
            x['returncode'] == 0 and x['layout_checked'] is True and x['observed']['status'] == 'passed'
            and x['observed']['foreign_calls'] == expected_calls for x in report['executions'])
        negatives = [report['negative_control'], *report['type_negative_controls']]
        jobs.append({'artifact_id': metadata['id'], 'artifact_name': metadata['name'],
            'metadata': ref(metadata_path), 'zip': ref(zip_path), 'zip_sha256_matches_metadata': digest(zip_path) == metadata['sha256'],
            'archive_members': members, 'report': ref(report_path), 'report_matches_zip_member': raw_report_matches,
            'source_head_in_artifact_name': source_match.group(1) if source_match else None,
            'api_workflow_source_and_digest_binding_matches': api_binding_matches,
            'source_binding_scope': 'Saved GitHub workflow-run, jobs and artifacts API records bind sourcehead and ZIP digest; native-host.v2 itself has no Git commit field.',
            'status': report['status'], 'host': report['host'],
            'compiler_family': report['c_compiler']['family'], 'c_target': report['c_compiler']['target'],
            'compiler_identity_observed': report['c_compiler']['identity_probe']['observed'],
            'executions': report['executions'], 'actual_foreign_calls': sum(x['observed']['foreign_calls'] for x in report['executions']),
            'expected_calls_per_execution': expected_calls, 'all_positive_runs_and_layout_checks_passed': all_runs_match,
            'negative_control': report['negative_control'], 'type_negative_controls': report['type_negative_controls'],
            'all_four_negative_controls_rejected': len(negatives) == 4 and all(x['status'] == 'rejected_as_expected' and x['returncode'] != 0 for x in negatives),
            'finite_matrix': select(report['matrix'], ('scalar_types', 'aggregate_shapes', 'pointer_shapes', 'values_per_shape',
                                      'register_spill_float_arguments', 'register_spill_integer_arguments', 'seed')),
            'claims': report['claims'], 'limits': report['limits'],
            'native_executable_bytes_in_archive': any(n.lower().endswith(('.exe', '.o', '.obj', '.so', '.dylib', '.dll')) for n in names)})
    workflow_binding = None
    if run and workflow_jobs and workflow_artifacts:
        workflow_binding = {'run_record': ref(directory / 'workflow-run.json'),
            'jobs_record': ref(directory / 'workflow-jobs.json'), 'artifacts_record': ref(directory / 'workflow-artifacts.json'),
            **select(run, ('id', 'head_sha', 'status', 'conclusion', 'html_url', 'event')),
            'jobs': [select(x, ('id', 'name', 'status', 'conclusion', 'head_sha', 'run_id', 'html_url')) for x in workflow_jobs['jobs']],
            'all_seven_jobs_complete_success_at_sourcehead': len(workflow_jobs['jobs']) == 7 and all(
                x['status'] == 'completed' and x['conclusion'] == 'success' and x['head_sha'] == run['head_sha']
                and x['run_id'] == run['id'] for x in workflow_jobs['jobs'])}
    return {'root': str(directory), 'jobs': jobs, 'job_count': len(jobs),
            'source_tree_binding': source_tree_binding, 'workflow_binding': workflow_binding,
            'positive_execution_count': sum(len(x['executions']) for x in jobs),
            'actual_foreign_calls': sum(x['actual_foreign_calls'] for x in jobs),
            'expected_negative_rejections': sum(1 + len(x['type_negative_controls']) for x in jobs),
            'all_reports_passed': bool(jobs) and all(x['status'] == 'passed' and x['all_positive_runs_and_layout_checks_passed']
                and x['all_four_negative_controls_rejected'] and x['zip_sha256_matches_metadata'] and x['report_matches_zip_member']
                and x['api_workflow_source_and_digest_binding_matches'] for x in jobs),
            'source_heads_from_artifact_metadata': sorted({x['source_head_in_artifact_name'] for x in jobs}),
            'scope': 'Existing finite Hepta C ABI host matrix; does not qualify the new Linux HIA multiversion runtime, NDU integration or x86 instruction search on these other platforms.'}


ledger = {'schema': 'hepta.hia.independent-evidence-ledger.v1',
          'generated_utc': datetime.now(timezone.utc).isoformat(),
          'method': 'Read recorded outputs, recount arrays/log entries, and rehash referenced evidence and retained binaries; no new tests or repository changes.',
          'runs': {name: analyze_run(path) for name, path in RUNS.items()},
          'existing_c_abi_host_ci': analyze_host_ci(),
          'reporting_constraints': [
              'Unittest failure/error entries can be multiple subtests of one method; never equate them with unique bugs or subtract them to infer passed methods.',
              'Focused, full-suite, crate and qualification tests overlap; do not add them into a purported independent-test total.',
              '1102 migration native result executions are 551 input cases times two implementations; 188 interpreter observations are Python/Rust pairs on a subset.',
              '212 native allocation-fault executions are already included in 1102, not an extra denominator.',
              'NDU uses one shared observation table and paired holdout replay. This does not evaluate sequential learning or establish NDU advantage.',
              'NDU outer call timing and internal adapter timing are separately reported; neither is a whole-program speedup.',
              'Resource-cap checks are admission thresholds; they are not an OS-enforced preemptive CPU/memory quota.',
              'Background actual publication uses explicitly synthetic costs. The measured one-call horizon abstains; no measured speedup follows from publication.',
              'The x86 minimum is only encoded bytes within the declared 146-recipe grammar under the trusted model and encoder; native timing and general optimality are separate.',
              'CFG parity is a finite corpus across18 programs with step/heap/call policies, not a general safety, Rust production admission or native refinement proof.',
              'Nine mechanism gates passing is not six-stage closure, whole-language soundness, unrestricted C/C++ migration or global optimality.',
              'Historical run1 results stay bound to c8c11a4; final claims about c430971 require the complete run2 aggregate and source-unchanged check.',
              'The seven native-host CI jobs qualify the existing finite C ABI matrix, not cross-platform support for the new Linux HIA runtime. Their uploaded ZIPs retain reports/logs, not native executable bytes.',
          ]}
OUT.mkdir(exist_ok=True)
(OUT / 'evidence-ledger.json').write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + '\n')

r1, r2 = ledger['runs']['run1'], ledger['runs']['run2']
def gate_text(run, name):
    g = next(x for x in run['gates'] if x['name'] == name)
    if g['state'] == 'pending': return '等待记录'
    if g.get('tests_run') is not None:
        return f"{g['tests_run']} tests; F={g.get('failures', 0)}, E={g.get('errors') or 0}, skip={g.get('skipped', 0)}"
    return '通过' if g.get('passed') else '未通过'

lines = ['# HIA / NDU 资格证据台账', '',
    f"生成：{ledger['generated_utc']}。仅审计现有记录、重算分母并核对文件哈希；未执行新测试、未修改仓库。", '',
    '## 源码及总状态', '',
    '| 运行 | 精确提交 | 已有 gate 记录 | 汇总状态 |', '|---|---|---:|---|']
for name, run in ledger['runs'].items():
    aggregate = run.get('aggregate')
    state = (f"ok={aggregate['ok']}; mechanism_qualified={aggregate['mechanism_qualified']}; source_unchanged={aggregate['source_unchanged']}"
             if aggregate else '全量回归/最终源码一致性汇总待完成，不能提前宣告总体验收通过')
    lines.append(f"| {name} | `{run['source_revision']}` | {run['gate_counts']['records_available']}/{run['gate_counts']['planned']} | {state} |")
lines += ['', '## Gate 分母', '', '| Gate | run1 | run2 |', '|---|---|---|']
for name in [g['name'] for g in r1['gates']]:
    lines.append(f'| {name} | {gate_text(r1, name)} | {gate_text(r2, name)} |')
f = r1['full_regression_accounting']
lines += ['',
    f"run1 的 {f['reported']['failures']} FAIL + {f['reported']['errors']} ERROR 是 **{f['actual_failed_entry_count']} 条 unittest 失败/错误记录**，涉及 **{f['distinct_test_methods']} 个测试方法及 {f['distinct_class_setup_identities']} 个类初始化**。它们不是63个独立缺陷，也不能据此把2633减63当作通过方法数。", '',
    '其中61条来自一个 Python 未导出 fcntl seal 常量名称的兼容性问题，覆盖37个测试方法；另有缺少 `qemu-system-arm` 的类初始化错误，以及缺少 `thumbv7em-none-eabi` core 的一个失败。', '',
    '聚焦回归、完整回归、Rust crate 和工具内部测试有重叠，不能合并为一个不重复测试总数。', '',
    '## 有限语义与迁移证据', '',
    '- Rust crate：54个测试通过，10个 result 汇总组，其中8组非空；没有忽略或过滤测试。',
    '- Rust CFG：179对 Python/Rust 观测、18个不同程序；比较返回值、trap、步数/堆/调用深度停止和资源台账。工具另执行10个回归测试。',
    '- 迁移：C多所有者56个、C++标量类20个、C++字节所有者475个输入案例，每个分别运行原始实现和HIA，因此为 **551×2=1102次 native 结果执行**。212次分配故障执行已包含在1102内。',
    '- 迁移解释器比较为 **188对** Python/Rust：56+20+112。C++字节所有者仅选size≤17的112例，不能声称475例均经Rust执行。',
    '- 翻译验证控制：wrapping cancellation被证明；安全但错误的改写和删除checked trap被否证；循环返回unknown；伪造proved receipt被拒绝。',
    '- 这些结果不等于任意C/C++可自动安全迁移、Rust版验证器取得生产准入权、全语言安全或native backend refinement证明。', '',
    '## NDU：实际等预算负对照', '']
for name, run in ledger['runs'].items():
    if 'ndu' not in run: continue
    n = run['ndu']
    lines += [f"### {name}", '',
        f"{n['candidate_count']}个候选均获得实际SMT证明；{n['training_samples']}个训练样本+{n['holdout_samples']}个holdout样本，合计 **{n['timed_native_calls']:,}次计时native调用**，另有{n['warmup_calls_separate']:,}次预热。基线及6个候选的完整共享库SHA-256均为 `{n['distinct_artifact_hashes'][0]}`，重新读盘核对一致。", '',
        f"共享搜索成本{n['equal_budget']['shared_search_cost_ns']:,}ns；固定配方、随机、穷举观察和原生NDU均选择abstain。", '',
        '| 选择器 | 实际选择 | 策略调用开销ns | 搜索+策略ns |', '|---|---|---:|---:|']
    for policy, d in n['policy_decisions'].items():
        total = d.get('actual_total_search_and_policy_ns', d.get('actual_outer_total_search_ns'))
        lines.append(f"| {policy} | {d['selected_id']} | {d['policy_cost_ns']:,} | {total:,} |")
    d = n['policy_decisions']['ndu']
    lines += ['', f"NDU内部实际adapter成本另记为{d['ranker_internal_costs']['actual_adapter_ns']:,}ns，内部准入总search成本{d['ranker_internal_costs']['total_search_ns']:,}ns；上表使用完整外层调用计时，二者不应混写。", '']
lines += ['这是一张共同观测表的paired replay，不能视为在线或顺序学习对照；经验不确定性包络不是置信区间。所有策略均没有建立运行时收益或NDU独有增益。资源cap是准入门槛，非抢占式OS配额。', '',
    '## 后台优化及多版本生命周期', '']
for name, run in ledger['runs'].items():
    if 'background' not in run: continue
    b = run['background']
    lines += [f"- {name}：实际NDU调用{b['actual_native_ndu_invocations']}次。测量共{b['reported_native_measurement_calls_including_warmup']:,}次native调用，其中{b['timed_native_lease_calls']:,}次计时、{b['warmup_native_calls']}次预热；计时包含Python lease校验和native调用开销。",
              f"- {name}：实际测量的expected_calls=1 horizon选择`{b['trials']['measured_finite_horizon']['selected_id']}`；显式synthetic-cost lifecycle控制实际发布新代；随后行为错误候选被否证并abstain。真实发布证明生命周期接通，不能作为实测加速证据。"]
lines += ['', '独立多版本控制保留3代的生命周期证据：18次native准入探测、14次额外调用观测、2个逐导出翻译证明；观察旧lease继续运行、回滚和内核拒绝写sealed代码。这不是任意在线指令修改或资源状态迁移。', '',
    '## 有限x86指令搜索', '']
for name, run in ledger['runs'].items():
    if 'x86' not in run: continue
    x = run['x86']
    lines += [f"- {name}：完整{ x['grammar_size'] }个配方，实际Z3判定139个不等价、7个等价；全部7个等价候选与LLVM基线均汇编/检查/执行。",
              f"- {name}：{x['timed_samples']}个等量样本、{x['timed_native_call_count']:,}次计时调用、{x['edge_native_call_count']}次边界调用；另有{x['warmup_calls_separate']:,}次预热。搜索及所有构建成本{x['search_and_all_build_wall_ns']:,}ns。",
              f"- {name}：最短函数体{ x['minimum_encoded_bytes'] }字节，`{x['selected_machine_body']}`，与LLVM `-O3`的{ x['llvm_baseline_encoded_bytes'] }字节函数体完全相同；7组计时包络全部重叠。"]
lines += ['', '这个byte minimum仅针对完整声明的146配方文法及可信ISA模型/编码器，不能推导最低运行时间、全程序最优或普遍超过LLVM/Rust。该离线穷举结果也不能归功于NDU的学习能力。', '',
    '## 另行完成的既有C ABI host CI', '',
    '这组证据属于原有Hepta有限C ABI matrix，不把新的Linux HIA multiversion、NDU后台优化或x86指令搜索扩展成跨平台支持。', '',
    '| Host | C编译器 | 两个实际优化级 | 实际foreign_calls | 负例 |', '|---|---|---|---:|---|']
for host in ledger['existing_c_abi_host_ci']['jobs']:
    levels = ', '.join(x['optimization'] for x in host['executions'])
    lines.append(f"| {host['host']['system']} {host['host']['machine']} | {host['compiler_family']} | {levels} | {host['actual_foreign_calls']} | 1运行负例+3类型负例均拒绝 |")
h = ledger['existing_c_abi_host_ci']
lines += ['', f"共{h['job_count']}个job、{h['positive_execution_count']}次正向native执行，每次181 foreign_calls，合计{h['actual_foreign_calls']}次调用；{h['expected_negative_rejections']}项预期负例拒绝。ZIP digest与metadata逐一匹配，报告与ZIP内成员逐字节一致。", '',
    '保留的GitHub workflow-run/jobs/artifacts API记录逐一绑定sourcehead `e1473a42f6b9a50a42f8cca8fadff47e709cf4d4`、run40551242969及ZIP digest。Git commit API记录与独立读取的本地Git tree均为 `f0625fe5579fcfd0c712cd37da88455c1ae39fa0`，证实e147与c430源码树完全一致。仍严格将本地资格验证归于c430、host CI归于e147；native-host.v2报告本身没有Git commit字段。', '',
    '有限profile包含12种scalar、36种ordinary-record形状、12种pointer形状、嵌套数组及整数/浮点register-spill调用。packed records、bitfields、varargs、外部对象生命周期安全不在此matrix内；不声称物理板卡、MMIO/DMA/IRQ或GPU验证。', '',
    '每个上传ZIP只有native-host.json、native-host-setup.log、native-host-adapter-tests.log三成员。它们是完整下载并校验的CI上传制品，但不能称为七个平台native对象或可执行字节的归档。', '',
    '## 文件和核验范围', '',
    '机器可读账本保存每个gate证据路径及重新计算的SHA-256，并逐个重新哈希NDU与x86保留的native产物。它是对现有证据的独立计数/完整性审阅，未重新执行这些工作负载。', '',
    '- run1汇总：`/workspace/scratch/bf7d454bbc83/hia-final-qualification/qualification.json`',
    '- run2汇总：`/workspace/scratch/bf7d454bbc83/hia-final-qualification-run2/qualification.json`（文件完成前，状态保持pending）。',
    '- 机器可读账本：`/workspace/scratch/bf7d454bbc83/hia-evidence-audit/evidence-ledger.json`', '',
    '正式结论必须保留：`six_stages_closed=false`、`whole_language_soundness_proved=false`、`global_optimality_established=false`、`scientific_incremental_advantage_established=false`。完整运行通过只关闭当前声明的有限机制gate。', '']
(OUT / 'evidence-ledger.md').write_text('\n'.join(lines))

# Archive inventory is separate from semantic/test counts. The qualification
# trees are retained raw evidence; external tool executables require copying
# from /tmp if the parent wants those exact bytes in the deliverable archive.
archive = {'schema': 'hepta.hia.evidence-archive-inputs.v1',
           'generated_utc': ledger['generated_utc'], 'qualification_trees': {}, 'external_binaries': {},
           'lifecycle_artifacts': {'retained_as_files': False,
               'reason': 'The multiversion/background qualifiers close all generations and remove their temporary artifacts; receipts, observations and hashes remain in JSON.',
               'native_artifact_bytes_must_not_be_claimed_archived': True},
           'scope': 'Existing evidence and exact tool executables only; excludes compiler installations/dependency caches and does not claim all build-environment bytes are archived.'}
archive['existing_c_abi_host_ci'] = {'root': str(BASE / 'hia-source-host-ci'),
    'source_and_workflow_records': [ref(BASE / 'hia-source-host-ci' / name) for name in
                                   ('remote-source-tree.json', 'workflow-run.json', 'workflow-jobs.json', 'workflow-artifacts.json')
                                   if (BASE / 'hia-source-host-ci' / name).exists()],
    'artifacts': [{'artifact_id': x['artifact_id'], 'zip': x['zip'], 'metadata': x['metadata'], 'report': x['report'],
                  'zip_sha256_matches_metadata': x['zip_sha256_matches_metadata'], 'members': x['archive_members'],
                  'native_executable_bytes_in_archive': x['native_executable_bytes_in_archive']}
                 for x in ledger['existing_c_abi_host_ci']['jobs']]}
for name, directory in RUNS.items():
    files = []
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():
            files.append({'path': str(path), 'relative': str(path.relative_to(directory)), 'kind': 'symlink_not_followed'})
        elif path.is_file():
            files.append({'path': str(path), 'relative': str(path.relative_to(directory)),
                          'kind': 'regular_file', 'bytes': path.stat().st_size, 'sha256': digest(path)})
    archive['qualification_trees'][name] = {'root': str(directory), 'source_revision': ledger['runs'][name]['source_revision'],
        'aggregate_complete': ledger['runs'][name]['state'] == 'complete', 'file_count': len(files),
        'total_file_bytes': sum(x.get('bytes', 0) for x in files), 'files': files}
    for filename, field in (('rust-cfg.json', 'rust_executable'), ('migration/qualification.json', 'rust_binary')):
        report = load(directory / filename)
        if report:
            item = report[field]
            path = Path(item['path'])
            observed = digest(path) if path.is_file() else None
            key = str(path)
            entry = archive['external_binaries'].setdefault(key, {'path': key, 'observed_sha256': observed,
                'bytes': path.stat().st_size if path.is_file() else None, 'references': []})
            entry['references'].append({'evidence': str(directory / filename), 'expected_sha256': item['sha256'],
                                         'matches': observed == item['sha256']})
    receipt = load(directory / 'ndu-build-receipt.json')
    if receipt:
        path = Path(receipt['binary'])
        observed = digest(path) if path.is_file() else None
        entry = archive['external_binaries'].setdefault(str(path), {'path': str(path), 'observed_sha256': observed,
            'bytes': path.stat().st_size if path.is_file() else None, 'references': []})
        entry['references'].append({'evidence': str(directory / 'ndu-build-receipt.json'),
            'expected_sha256': receipt['binary_sha256'], 'matches': observed == receipt['binary_sha256']})
(OUT / 'archive-inputs.json').write_text(json.dumps(archive, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'ledger': str(OUT / 'evidence-ledger.json'), 'readable': str(OUT / 'evidence-ledger.md'),
                  'runs': {k: {'state': v['state'], 'source_revision': v['source_revision'], 'gates': v['gate_counts']}
                           for k, v in ledger['runs'].items()}}, ensure_ascii=False))
