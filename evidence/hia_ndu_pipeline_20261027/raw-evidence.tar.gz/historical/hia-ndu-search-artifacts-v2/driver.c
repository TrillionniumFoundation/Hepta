#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <time.h>
typedef uint64_t (*kernel_t)(uint64_t);
static uint64_t now(clockid_t kind) {
    struct timespec t;
    if (clock_gettime(kind, &t)) exit(81);
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}
static uint64_t step(uint64_t x) {
    return x * UINT64_C(6364136223846793005) + UINT64_C(1442695040888963407);
}
int main(int argc, char **argv) {
    if (argc != 5) return 82;
    uint64_t iterations = strtoull(argv[2], NULL, 10);
    uint64_t warmup = strtoull(argv[3], NULL, 10);
    uint64_t seed = strtoull(argv[4], NULL, 10);
    if (!iterations || iterations > UINT64_C(10000000) || warmup > UINT64_C(1000000)) return 83;
    void *library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) { fprintf(stderr, "%s\n", dlerror()); return 84; }
    kernel_t kernel = (kernel_t)dlsym(library, "calculate");
    if (!kernel) return 85;
    volatile uint64_t warm_checksum = 0;
    uint64_t x = seed;
    for (uint64_t i = 0; i < warmup; ++i) { x = step(x); warm_checksum ^= kernel(x); }
    (void)warm_checksum;
    struct rusage before, after;
    if (getrusage(RUSAGE_SELF, &before)) return 86;
    x = seed;
    uint64_t checksum = 0;
    uint64_t cpu_start = now(CLOCK_PROCESS_CPUTIME_ID), start = now(CLOCK_MONOTONIC);
    for (uint64_t i = 0; i < iterations; ++i) { x = step(x); checksum += kernel(x); }
    uint64_t end = now(CLOCK_MONOTONIC), cpu_end = now(CLOCK_PROCESS_CPUTIME_ID);
    if (getrusage(RUSAGE_SELF, &after)) return 87;
    printf("{\"elapsed_ns\":%" PRIu64 ",\"process_cpu_ns\":%" PRIu64
           ",\"iterations\":%" PRIu64 ",\"seed\":%" PRIu64 ",\"checksum\":%" PRIu64
           ",\"voluntary_context_switches\":%ld,\"involuntary_context_switches\":%ld"
           ",\"minor_page_faults\":%ld,\"major_page_faults\":%ld}\n",
           end-start, cpu_end-cpu_start, iterations, seed, checksum,
           after.ru_nvcsw-before.ru_nvcsw, after.ru_nivcsw-before.ru_nivcsw,
           after.ru_minflt-before.ru_minflt, after.ru_majflt-before.ru_majflt);
    if (dlclose(library)) return 88;
    return 0;
}
