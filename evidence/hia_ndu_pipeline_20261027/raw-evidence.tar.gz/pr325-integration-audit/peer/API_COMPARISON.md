# PR #325 与本轮实现：证明和运行时接口只读比较

## 比较身份和结论

- 远程：`bdb0b39c99b7980b98cb3f9e07ba406cc20f0940`，PR #325。
- 本轮冻结：`c4309712d8f4d21563a26c174391bd66195a9e34`。
- 共同基线：`3db07aa877ab1a5fc00560d7037e6efbc884fc1f`。
- 范围：静态读取远程 `hia_optimization.py`、`hia_adaptive.py` 及本轮对应四个模块；没有执行任一分支代码、没有修改仓库源码、没有合并或覆盖引用。PR #325 的 201 项测试结果不属于本轮，也没有在此复跑。

这两组实现的模块名称不同，可作为不同能力并存，但不是可直接互换的 API。证明覆盖面是互补关系：PR #325 保持整个模块 CFG 和资源/调用骨架不变，在效果边界逐段证明标量观测相同；本轮比较选定公开标量函数的完整无环路径行为，可以比较不同无环 CFG，但不接受资源、调用或循环。运行时同样有不同契约：PR #325 只在所有调用静止时显式切换单个 u64 函数；本轮保留每一代的租约，允许已有调用继续完成，并有带快照、取消和实际准备成本门槛的后台发布路径。

## 1. 公共 API 与返回结构

| 角色 | PR #325 | 本轮 c430971 |
|---|---|---|
| 等价性检查 | `verify_optimization(base, candidate, policy=None)` | `validate_translation(before, after, *, function=None, timeout_ms=2000)` |
| 结果 schema | `hepta.hia.optimization-verification.v1` | `hepta.hia.translation-validation.v1` |
| 成功/失败状态 | `verified/rejected/unknown/timeout` | `proved/disproved/unknown` |
| 证明作用域 | 全模块；相同完整去纯标量指令骨架；每个 block/segment 的效果实参、终结符观测和首个陷阱 | `scope=selected_public_scalar_function`，`profile=hia.scalar-acyclic-bitvector-traps.v1` |
| 绑定字段 | `base_sha256/candidate_sha256`、两侧 input hashes、policy/checker hashes、完整 solver identity、obligations、verification hash | `before_sha256/after_sha256`、两侧 input hashes、function/profile/scope、validator hash、solver name/version/result |
| 重验入口 | `require_verified(...)` 总是重新执行证明；构建入口不接收调用方 receipt | `verify_translation_receipt(...)` 重新执行证明，并逐项绑定 schema/profile/scope/function/hashes/validator |
| 提案 | `fold_constants(program) -> (VerifiedProgram, {rule,replacements,equivalence_authority:false})` | `propose_candidates(document, *, function, max_candidates=8) -> list[{id,action,program}]` |
| 证明后构建 | `build_optimized_native(base,candidate,output,*,policy=None,clang="clang",kind="shared")` | 证明模块不直接构建；`ScalarMultiversionRuntime.publish*` 执行每个导出函数的证明、构建、实际制品检查及有限 native probes |
| native receipt | `hepta.hia.optimized-native.v1` / `verified_core_native_bound`，包裹 verification/native/binding hash | `GenerationInfo` 含 generation、Core/input/artifact hashes、ABI、proof/probe counts；snapshot 使用 runtime PROFILE |

不能将远程 `rejected` 一律映射为本轮 `disproved`：远程还用 rejected 表示 Core admission 失败；本轮 disproved 专指由 canonical interpreter 独立重放确认的行为反例。远程 SAT 模型记录于 obligation；本轮会实际重放两侧观察，重放不一致会保持 unknown。

来源：[远程 verifier 与 policy](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_optimization.py#L220-L280)、[远程提案与构建](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_optimization.py#L364-L445)。本轮：`hepta/hia_translation_validation.py:57–88,312–431`、`hepta/hia_finite_actions.py:181–227`、`hepta/hia_multiversion.py:95–113,175–190,373–415`。

## 2. 两种证明并非相互包含

PR #325 的 `_skeleton` 删除 PURE 指令后要求整个 canonical document 相等，保留函数签名、参数名称、块参数、CFG 边、资源和调用指令的完整 operands/results/attributes；不同骨架直接 unknown。它对每个块的任意标量输入及每个资源/调用屏障的标量观测建立 UNSAT 义务，屏障输出作为双方共享的未知符号。这样可处理“循环/资源程序内局部纯标量表达式改写”，但没有证明任意循环改写、改变 CFG、资源操作重排/删除或任意状态迁移。

本轮允许选定函数的两个无环 CFG 不同，以返回值及首个规定陷阱码为观察；有调用、资源类型、资源效果或循环即 unknown。其他公开导出的行为不是单次证明的对象；本轮 runtime 明确为全部导出函数逐个重验。

因此可保留两条显式 profile：`scalar_acyclic` 和 `same_cfg_effect_skeleton`。dispatcher 应先判断请求所需的覆盖面，再运行对应 checker；不能把任一成功标记升级成另一条 profile 的证明。

来源：[远程骨架和分段](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_optimization.py#L98-L131)、[远程逐段义务](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_optimization.py#L282-L361)。本轮：`hepta/hia_translation_validation.py:94–129,312–408`、`hepta/hia_multiversion.py:175–190`。

## 3. Solver 与时间预算必须收敛

PR #325 源码硬性要求 `z3.get_version_string()=="4.13.4"`，否则返回 unknown；它还记录实际加载的 Z3 动态库 SHA256 和 Python bindings SHA256，并在结束及 native 构建前后重验身份。本轮 pyproject 的 verification extra 固定 `z3-solver==4.15.4.0`，但本轮 `validate_translation` **没有**同样的运行时版本硬拒绝条件：它报告实际版本，使用单独 context，并在 receipt 重验中绑定本模块 source digest。

所以安装本轮依赖并直接运行远程 checker 会得到 unknown；反向采用 4.13.4 可能在本轮 API 层被接受，但会改变本轮已测试的 solver 版本，必须重新资格验证。两个固定版本不能装进同一个 Python 环境。应明确选择并复验一个统一 pin，或使用独立进程/环境并保留 checker/solver profile 身份，不能只放宽远程硬门槛。

两者都为每个请求创建独立 Z3 Context。timeout_ms 的契约也不同：远程用 monotonic 总截止时间并扣减每条 obligation 的剩余时间；本轮用 solver timeout，另有静态 profile 大小上限，端到端准备成本由 runtime/coordinator 另外计量。

来源：[远程 solver identity](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_optimization.py#L23-L96)、[远程版本门槛](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_optimization.py#L261-L281)。本轮：`pyproject.toml:12–13`、`hepta/hia_translation_validation.py:48–55,132–137,357–378`。

## 4. 运行时生命周期差异

| 契约 | PR #325 AdaptiveRuntime | 本轮 ScalarMultiversionRuntime + BackgroundOptimizer |
|---|---|---|
| API | `AdaptiveRuntime(base,directory,*,clang="clang",policy=None)`；prepare/call/call_many/measure/select/snapshot/close | `ScalarMultiversionRuntime(baseline,directory,*,clang="clang",validation_timeout_ms=2000,max_live_generations=8)`；publish/publish_if_current/lease/call/rollback/snapshot/close |
| Profile | 单公开函数、1–8 个 u64 参数、一个 u64 返回、单块、最多 4096 ops、无 effects/calls/resources/traps | 1–16 个公开函数、每个最多 16 参数、bool/各整数宽度、单 scalar 返回、无环 CFG 每函数最多 64 blocks/2048 ops、total/effect-free |
| ABI/state | 完整 adaptive-state 字典相等，包含参数名称和空 persistent/live owner/loan 状态 | 按名称排序的 ScalarABI 相等，比较参数类型和返回类型；仅无资源状态 profile |
| 准备/选择 | prepare 生成随机 token、保存已加载 image；select explicit 时重新证明当前程序到 candidate | publish 对不可变初始 baseline 证明所有导出，再构建并选择；conditional publication 加 expected_generation/epoch、取消和实际预算 |
| 在途调用 | 全局 active>0 时拒绝 select；一个 call_many 批次固定 image | 每次 lease 固定 generation；新一代可选中，旧一代直到租约退出才回收 |
| 版本回收 | 最多 16 个 images，保留到 close；无单独 retire API | 默认最多 8、可设 2–64；retired 且 leases==0 后卸载；初始 baseline 保留供 rollback |
| close | active calls 或 prepares 存在时拒绝 | 禁止新调用，把代标为 retired；已有租约可完成再回收 |
| 自动发布 | select(mode="auto") 无条件保留当前版本，明确未实现 profitable selection | 单后台 worker、最多 8 个在途任务；绑定当前代+epoch，正净收益/资源 cap 检查后才能进入条件发布 |
| 测量 | measure 实际执行配对 shadow calls，内部保留测量及过期时间；拒绝外部性能数字成为选择依据 | submit 接收绑定程序 hash 的 host observations，明确其未独立认证；计入 rank/coordinator/prepare 实际成本 |
| 并发取消 | 无对应 Future API | PublicationCancellation 与最终指针交换共用锁；成功 Future.cancel 保证不会随后发布 |

两边均重新核对程序并由内部构建 native，加载 sealed memfd 的固定字节；没有通用 live-state 迁移。PR #325 的 measurement 是有限 shadow 实验，其源码解释了成本全部计入后不能作为自动盈利发布策略；本轮的自动发布仍依赖可信 host measurements/expected_calls，不代表性能优势已实证成立。

来源：[远程 runtime profile 和装载](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_adaptive.py#L26-L105)、[prepare/calls](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_adaptive.py#L176-L245)、[measure/select/close](https://github.com/TrillionniumFoundation/Hepta/blob/bdb0b39c99b7980b98cb3f9e07ba406cc20f0940/hepta/hia_adaptive.py#L247-L381)。本轮：`hepta/hia_multiversion.py:116–190,291–337,348–371,417–607`、`hepta/hia_background_optimizer.py:104–198,214–325`。

## 5. 具体收敛点

1. 保留两个 proof schema 和覆盖范围，定义共同 envelope 中的 checker ID、profile、function/module scope、exact input/Core hashes、solver identity、outcome；消费者仍调用实际 checker，不能仅转换 serialized status。
2. 同时保留两个 proposal API，通过无授权的薄适配将远程 fold 的 canonical program 转成 `{id,action,program}`；然后重跑所需 profile 的证明。不能假定本轮 identity/CFG 变换符合远程 exact-skeleton 限制。
3. 统一或隔离 Z3 固定版本，重新运行两套各自资格门槛。runtime/profile 成功不能代替 solver 迁移后的资格记录。
4. 公布两种不同的切换语义：全局 quiescent selection 与 per-generation lease selection。两类 generation/token/snapshot 字段不可互换；共享 facade 需要明确 capability，不宜只改类名。
5. 若复用远程 shadow measurement，绑定本轮 canonical program/input hash、selection_epoch、目标和计量 profile，重新计算真实工作量及成本；不得把远程的负净收益 shadow 数字当作未来工作量的收益预测。
6. 本轮保持不可变 baseline 与 rollback；远程 prepare/select 都相对于当前程序重新证明。若统一成 current-to-candidate 增量证明，必须保留 rollback 可信链或继续对初始 baseline 全量重验。
7. PR #325 修改了共同 native backend，本轮 runtime 依赖其 receipt、ELF inspection 和编译入口；即使这些 API 形状兼容，合并后的 backend/source identity 改变，两边旧制品/旧资格结果均不能直接赋给合并版本。

以上是接口整合建议，没有断言未经运行的合并版本通过测试，也没有把任一分支的研究目标升级为已实现能力。
