; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i64 %p_0_1, i8 %p_0_2, i32 %p_0_3) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %p_0_0, %t2
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_1_2 = phi i8 [ %p_0_2, %edge_1 ]
  %p_1_3 = phi i32 [ %p_0_3, %edge_1 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_5 = phi i64 [ %p_0_1, %edge_1 ]
  %p_1_6 = phi i8 [ %p_0_2, %edge_1 ]
  %p_1_7 = phi i32 [ %p_0_3, %edge_1 ]
  %p_1_8 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_9 = phi i64 [ 0, %edge_1 ]
  %p_1_10 = phi i32 [ %t1, %edge_1 ]
  %p_1_11 = phi i64 [ %t2, %edge_1 ]
  %p_1_12 = phi i1 [ %t3, %edge_1 ]
  %p_1_13 = phi i1 [ %t3, %edge_1 ]
  %t4 = trunc i64 0 to i32
  %t5 = sext i32 %t4 to i64
  %t6 = icmp eq i64 %p_1_5, %t5
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_2 = phi i8 [ %p_0_2, %edge_0 ]
  %p_2_3 = phi i32 [ %p_0_3, %edge_0 ]
  %p_2_4 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_5 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_6 = phi i8 [ %p_0_2, %edge_0 ]
  %p_2_7 = phi i32 [ %p_0_3, %edge_0 ]
  %p_2_8 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_9 = phi i64 [ 0, %edge_0 ]
  %p_2_10 = phi i32 [ %t1, %edge_0 ]
  %p_2_11 = phi i64 [ %t2, %edge_0 ]
  %p_2_12 = phi i1 [ %t3, %edge_0 ]
  %p_2_13 = phi i1 [ %t3, %edge_0 ]
  br label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i8 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ], [ %p_2_4, %edge_3 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ], [ %p_2_5, %edge_3 ]
  %p_3_6 = phi i8 [ %p_1_6, %edge_2 ], [ %p_2_6, %edge_3 ]
  %p_3_7 = phi i32 [ %p_1_7, %edge_2 ], [ %p_2_7, %edge_3 ]
  %p_3_8 = phi i64 [ %p_1_8, %edge_2 ], [ %p_2_8, %edge_3 ]
  %p_3_9 = phi i64 [ %p_1_9, %edge_2 ], [ %p_2_9, %edge_3 ]
  %p_3_10 = phi i32 [ %p_1_10, %edge_2 ], [ %p_2_10, %edge_3 ]
  %p_3_11 = phi i64 [ %p_1_11, %edge_2 ], [ %p_2_11, %edge_3 ]
  %p_3_12 = phi i1 [ %p_1_12, %edge_2 ], [ %p_2_12, %edge_3 ]
  %p_3_13 = phi i1 [ %t6, %edge_2 ], [ %p_2_12, %edge_3 ]
  br i1 %p_3_13, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i8 [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_3_3, %edge_4 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_4 ]
  %p_4_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_4_6 = phi i8 [ %p_3_6, %edge_4 ]
  %p_4_7 = phi i32 [ %p_3_7, %edge_4 ]
  %t7 = trunc i64 0 to i32
  %t8 = sext i32 %t7 to i64
  ret i64 %t8
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_5_2 = phi i8 [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i32 [ %p_3_3, %edge_5 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_5 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_5_6 = phi i8 [ %p_3_6, %edge_5 ]
  %p_5_7 = phi i32 [ %p_3_7, %edge_5 ]
  %t9 = call %hia.alloc @__hia_allocate(i64 %p_5_4, i1 true)
  %t10 = extractvalue %hia.alloc %t9, 0
  %t11 = extractvalue %hia.alloc %t9, 1
  %t12 = select i1 %t11, i64 %p_5_4, i64 0
  %t13 = insertvalue %hia.buffer %t10, i64 %t12, 1
  br i1 %t11, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi i8 [ %p_5_2, %edge_6 ]
  %p_6_3 = phi i32 [ %p_5_3, %edge_6 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_6 ]
  %p_6_5 = phi i64 [ %p_5_5, %edge_6 ]
  %p_6_6 = phi i8 [ %p_5_6, %edge_6 ]
  %p_6_7 = phi i32 [ %p_5_7, %edge_6 ]
  %p_6_8 = phi i1 [ %t11, %edge_6 ]
  %p_6_9 = phi %hia.buffer [ %t13, %edge_6 ]
  %p_6_10 = phi i8 [ 1, %edge_6 ]
  %t14 = call %hia.alloc @__hia_allocate(i64 %p_6_5, i1 true)
  %t15 = extractvalue %hia.alloc %t14, 0
  %t16 = extractvalue %hia.alloc %t14, 1
  %t17 = select i1 %t16, i64 %p_6_5, i64 0
  %t18 = insertvalue %hia.buffer %t15, i64 %t17, 1
  br i1 %t16, label %edge_8, label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi i8 [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_7 ]
  %p_7_6 = phi i8 [ %p_5_6, %edge_7 ]
  %p_7_7 = phi i32 [ %p_5_7, %edge_7 ]
  %p_7_8 = phi i1 [ %t11, %edge_7 ]
  %p_7_9 = phi %hia.buffer [ %t13, %edge_7 ]
  %p_7_10 = phi i8 [ 1, %edge_7 ]
  %t19 = extractvalue %hia.buffer %p_7_9, 0
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %drop_nonnull_21, label %drop_after_21
drop_nonnull_21:
  call void @free(ptr %t19) nobuiltin
  br label %drop_after_21
drop_after_21:
  %t22 = trunc i64 1001 to i32
  %t23 = sext i32 %t22 to i64
  ret i64 %t23
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i64 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi i8 [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i32 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %p_8_6 = phi i8 [ %p_6_6, %edge_8 ]
  %p_8_7 = phi i32 [ %p_6_7, %edge_8 ]
  %p_8_8 = phi %hia.buffer [ %p_6_9, %edge_8 ]
  %p_8_9 = phi i1 [ %t16, %edge_8 ]
  %p_8_10 = phi %hia.buffer [ %t18, %edge_8 ]
  %p_8_11 = phi i8 [ 1, %edge_8 ]
  %t24 = trunc i64 0 to i32
  %t25 = sext i32 %t24 to i64
  br label %edge_10
b9:
  %p_9_0 = phi i64 [ %p_6_0, %edge_9 ]
  %p_9_1 = phi i64 [ %p_6_1, %edge_9 ]
  %p_9_2 = phi i8 [ %p_6_2, %edge_9 ]
  %p_9_3 = phi i32 [ %p_6_3, %edge_9 ]
  %p_9_4 = phi i64 [ %p_6_4, %edge_9 ]
  %p_9_5 = phi i64 [ %p_6_5, %edge_9 ]
  %p_9_6 = phi i8 [ %p_6_6, %edge_9 ]
  %p_9_7 = phi i32 [ %p_6_7, %edge_9 ]
  %p_9_8 = phi %hia.buffer [ %p_6_9, %edge_9 ]
  %p_9_9 = phi i1 [ %t16, %edge_9 ]
  %p_9_10 = phi %hia.buffer [ %t18, %edge_9 ]
  %p_9_11 = phi i8 [ 1, %edge_9 ]
  %t26 = extractvalue %hia.buffer %p_9_10, 0
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %drop_nonnull_28, label %drop_after_28
drop_nonnull_28:
  call void @free(ptr %t26) nobuiltin
  br label %drop_after_28
drop_after_28:
  %t29 = extractvalue %hia.buffer %p_9_8, 0
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %drop_nonnull_31, label %drop_after_31
drop_nonnull_31:
  call void @free(ptr %t29) nobuiltin
  br label %drop_after_31
drop_after_31:
  %t32 = trunc i64 1002 to i32
  %t33 = sext i32 %t32 to i64
  ret i64 %t33
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_10 ], [ %p_11_0, %edge_13 ]
  %p_10_1 = phi i64 [ %p_8_1, %edge_10 ], [ %p_11_1, %edge_13 ]
  %p_10_2 = phi i8 [ %p_8_2, %edge_10 ], [ %p_11_2, %edge_13 ]
  %p_10_3 = phi i32 [ %p_8_3, %edge_10 ], [ %p_11_3, %edge_13 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_10 ], [ %p_11_4, %edge_13 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ], [ %p_11_5, %edge_13 ]
  %p_10_6 = phi i8 [ %p_8_6, %edge_10 ], [ %p_11_6, %edge_13 ]
  %p_10_7 = phi i32 [ %p_8_7, %edge_10 ], [ %p_11_7, %edge_13 ]
  %p_10_8 = phi %hia.buffer [ %p_8_8, %edge_10 ], [ %p_11_8, %edge_13 ]
  %p_10_9 = phi %hia.buffer [ %p_8_10, %edge_10 ], [ %p_11_9, %edge_13 ]
  %p_10_10 = phi i64 [ %t25, %edge_10 ], [ %t42, %edge_13 ]
  %t34 = icmp ult i64 %p_10_10, %p_10_4
  br i1 %t34, label %edge_11, label %edge_12
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_11 ]
  %p_11_1 = phi i64 [ %p_10_1, %edge_11 ]
  %p_11_2 = phi i8 [ %p_10_2, %edge_11 ]
  %p_11_3 = phi i32 [ %p_10_3, %edge_11 ]
  %p_11_4 = phi i64 [ %p_10_4, %edge_11 ]
  %p_11_5 = phi i64 [ %p_10_5, %edge_11 ]
  %p_11_6 = phi i8 [ %p_10_6, %edge_11 ]
  %p_11_7 = phi i32 [ %p_10_7, %edge_11 ]
  %p_11_8 = phi %hia.buffer [ %p_10_8, %edge_11 ]
  %p_11_9 = phi %hia.buffer [ %p_10_9, %edge_11 ]
  %p_11_10 = phi i64 [ %p_10_10, %edge_11 ]
  %t35 = call i64 @__hia_fn_1(i64 %p_11_10, i8 %p_11_6)
  %t36 = trunc i64 %t35 to i8
  %t37 = extractvalue %hia.buffer %p_11_8, 0
  %t38 = extractvalue %hia.buffer %p_11_8, 1
  %t39 = icmp ult i64 %p_11_10, %t38
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = getelementptr i8, ptr %t37, i64 %p_11_10
  store i8 %t36, ptr %t41, align 1
  %t42 = add i64 %p_11_10, 1
  br label %edge_13
b12:
  %p_12_0 = phi i64 [ %p_10_0, %edge_12 ]
  %p_12_1 = phi i64 [ %p_10_1, %edge_12 ]
  %p_12_2 = phi i8 [ %p_10_2, %edge_12 ]
  %p_12_3 = phi i32 [ %p_10_3, %edge_12 ]
  %p_12_4 = phi i64 [ %p_10_4, %edge_12 ]
  %p_12_5 = phi i64 [ %p_10_5, %edge_12 ]
  %p_12_6 = phi i8 [ %p_10_6, %edge_12 ]
  %p_12_7 = phi i32 [ %p_10_7, %edge_12 ]
  %p_12_8 = phi %hia.buffer [ %p_10_8, %edge_12 ]
  %p_12_9 = phi %hia.buffer [ %p_10_9, %edge_12 ]
  %p_12_10 = phi i64 [ %p_10_10, %edge_12 ]
  %t43 = trunc i64 0 to i32
  %t44 = sext i32 %t43 to i64
  br label %edge_14
b13:
  %p_13_0 = phi i64 [ %p_12_0, %edge_14 ], [ %p_14_0, %edge_17 ]
  %p_13_1 = phi i64 [ %p_12_1, %edge_14 ], [ %p_14_1, %edge_17 ]
  %p_13_2 = phi i8 [ %p_12_2, %edge_14 ], [ %p_14_2, %edge_17 ]
  %p_13_3 = phi i32 [ %p_12_3, %edge_14 ], [ %p_14_3, %edge_17 ]
  %p_13_4 = phi i64 [ %p_12_4, %edge_14 ], [ %p_14_4, %edge_17 ]
  %p_13_5 = phi i64 [ %p_12_5, %edge_14 ], [ %p_14_5, %edge_17 ]
  %p_13_6 = phi i8 [ %p_12_6, %edge_14 ], [ %p_14_6, %edge_17 ]
  %p_13_7 = phi i32 [ %p_12_7, %edge_14 ], [ %p_14_7, %edge_17 ]
  %p_13_8 = phi %hia.buffer [ %p_12_8, %edge_14 ], [ %p_14_8, %edge_17 ]
  %p_13_9 = phi %hia.buffer [ %p_12_9, %edge_14 ], [ %p_14_9, %edge_17 ]
  %p_13_10 = phi i64 [ %p_12_10, %edge_14 ], [ %p_14_10, %edge_17 ]
  %p_13_11 = phi i64 [ %t44, %edge_14 ], [ %t56, %edge_17 ]
  %t45 = icmp ult i64 %p_13_11, %p_13_5
  br i1 %t45, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_14_1 = phi i64 [ %p_13_1, %edge_15 ]
  %p_14_2 = phi i8 [ %p_13_2, %edge_15 ]
  %p_14_3 = phi i32 [ %p_13_3, %edge_15 ]
  %p_14_4 = phi i64 [ %p_13_4, %edge_15 ]
  %p_14_5 = phi i64 [ %p_13_5, %edge_15 ]
  %p_14_6 = phi i8 [ %p_13_6, %edge_15 ]
  %p_14_7 = phi i32 [ %p_13_7, %edge_15 ]
  %p_14_8 = phi %hia.buffer [ %p_13_8, %edge_15 ]
  %p_14_9 = phi %hia.buffer [ %p_13_9, %edge_15 ]
  %p_14_10 = phi i64 [ %p_13_10, %edge_15 ]
  %p_14_11 = phi i64 [ %p_13_11, %edge_15 ]
  %t46 = call i64 @__hia_fn_1(i64 %p_14_11, i8 %p_14_6)
  %t47 = trunc i64 90 to i32
  %t48 = sext i32 %t47 to i64
  %t49 = xor i64 %t46, %t48
  %t50 = trunc i64 %t49 to i8
  %t51 = extractvalue %hia.buffer %p_14_9, 0
  %t52 = extractvalue %hia.buffer %p_14_9, 1
  %t53 = icmp ult i64 %p_14_11, %t52
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  %t55 = getelementptr i8, ptr %t51, i64 %p_14_11
  store i8 %t50, ptr %t55, align 1
  %t56 = add i64 %p_14_11, 1
  br label %edge_17
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i64 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi i8 [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i32 [ %p_13_3, %edge_16 ]
  %p_15_4 = phi i64 [ %p_13_4, %edge_16 ]
  %p_15_5 = phi i64 [ %p_13_5, %edge_16 ]
  %p_15_6 = phi i8 [ %p_13_6, %edge_16 ]
  %p_15_7 = phi i32 [ %p_13_7, %edge_16 ]
  %p_15_8 = phi %hia.buffer [ %p_13_8, %edge_16 ]
  %p_15_9 = phi %hia.buffer [ %p_13_9, %edge_16 ]
  %p_15_10 = phi i64 [ %p_13_10, %edge_16 ]
  %p_15_11 = phi i64 [ %p_13_11, %edge_16 ]
  %t57 = trunc i64 0 to i32
  %t58 = icmp ne i32 %p_15_7, %t57
  br i1 %t58, label %edge_18, label %edge_19
b16:
  %p_16_0 = phi i64 [ %p_15_0, %edge_18 ]
  %p_16_1 = phi i64 [ %p_15_1, %edge_18 ]
  %p_16_2 = phi i8 [ %p_15_2, %edge_18 ]
  %p_16_3 = phi i32 [ %p_15_3, %edge_18 ]
  %p_16_4 = phi i64 [ %p_15_4, %edge_18 ]
  %p_16_5 = phi i64 [ %p_15_5, %edge_18 ]
  %p_16_6 = phi i8 [ %p_15_6, %edge_18 ]
  %p_16_7 = phi i32 [ %p_15_7, %edge_18 ]
  %p_16_8 = phi %hia.buffer [ %p_15_8, %edge_18 ]
  %p_16_9 = phi %hia.buffer [ %p_15_9, %edge_18 ]
  %p_16_10 = phi i64 [ %p_15_10, %edge_18 ]
  %p_16_11 = phi i64 [ %p_15_11, %edge_18 ]
  %t59 = extractvalue %hia.buffer %p_16_9, 0
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %drop_nonnull_61, label %drop_after_61
drop_nonnull_61:
  call void @free(ptr %t59) nobuiltin
  br label %drop_after_61
drop_after_61:
  %t62 = extractvalue %hia.buffer %p_16_8, 0
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %drop_nonnull_64, label %drop_after_64
drop_nonnull_64:
  call void @free(ptr %t62) nobuiltin
  br label %drop_after_64
drop_after_64:
  %t65 = trunc i64 2000 to i32
  %t66 = sext i32 %t65 to i64
  ret i64 %t66
b17:
  %p_17_0 = phi i64 [ %p_15_0, %edge_19 ]
  %p_17_1 = phi i64 [ %p_15_1, %edge_19 ]
  %p_17_2 = phi i8 [ %p_15_2, %edge_19 ]
  %p_17_3 = phi i32 [ %p_15_3, %edge_19 ]
  %p_17_4 = phi i64 [ %p_15_4, %edge_19 ]
  %p_17_5 = phi i64 [ %p_15_5, %edge_19 ]
  %p_17_6 = phi i8 [ %p_15_6, %edge_19 ]
  %p_17_7 = phi i32 [ %p_15_7, %edge_19 ]
  %p_17_8 = phi %hia.buffer [ %p_15_8, %edge_19 ]
  %p_17_9 = phi %hia.buffer [ %p_15_9, %edge_19 ]
  %p_17_10 = phi i64 [ %p_15_10, %edge_19 ]
  %p_17_11 = phi i64 [ %p_15_11, %edge_19 ]
  %t67 = trunc i64 0 to i32
  %t68 = sext i32 %t67 to i64
  %t69 = trunc i64 0 to i32
  %t70 = sext i32 %t69 to i64
  br label %edge_20
b18:
  %p_18_0 = phi i64 [ %p_17_0, %edge_20 ], [ %p_19_0, %edge_23 ]
  %p_18_1 = phi i64 [ %p_17_1, %edge_20 ], [ %p_19_1, %edge_23 ]
  %p_18_2 = phi i8 [ %p_17_2, %edge_20 ], [ %p_19_2, %edge_23 ]
  %p_18_3 = phi i32 [ %p_17_3, %edge_20 ], [ %p_19_3, %edge_23 ]
  %p_18_4 = phi i64 [ %p_17_4, %edge_20 ], [ %p_19_4, %edge_23 ]
  %p_18_5 = phi i64 [ %p_17_5, %edge_20 ], [ %p_19_5, %edge_23 ]
  %p_18_6 = phi i8 [ %p_17_6, %edge_20 ], [ %p_19_6, %edge_23 ]
  %p_18_7 = phi i32 [ %p_17_7, %edge_20 ], [ %p_19_7, %edge_23 ]
  %p_18_8 = phi %hia.buffer [ %p_17_8, %edge_20 ], [ %p_19_8, %edge_23 ]
  %p_18_9 = phi %hia.buffer [ %p_17_9, %edge_20 ], [ %p_19_9, %edge_23 ]
  %p_18_10 = phi i64 [ %p_17_10, %edge_20 ], [ %p_19_10, %edge_23 ]
  %p_18_11 = phi i64 [ %p_17_11, %edge_20 ], [ %p_19_11, %edge_23 ]
  %p_18_12 = phi i64 [ %t68, %edge_20 ], [ %t79, %edge_23 ]
  %p_18_13 = phi i64 [ %t70, %edge_20 ], [ %t80, %edge_23 ]
  %t71 = icmp ult i64 %p_18_13, %p_18_4
  br i1 %t71, label %edge_21, label %edge_22
b19:
  %p_19_0 = phi i64 [ %p_18_0, %edge_21 ]
  %p_19_1 = phi i64 [ %p_18_1, %edge_21 ]
  %p_19_2 = phi i8 [ %p_18_2, %edge_21 ]
  %p_19_3 = phi i32 [ %p_18_3, %edge_21 ]
  %p_19_4 = phi i64 [ %p_18_4, %edge_21 ]
  %p_19_5 = phi i64 [ %p_18_5, %edge_21 ]
  %p_19_6 = phi i8 [ %p_18_6, %edge_21 ]
  %p_19_7 = phi i32 [ %p_18_7, %edge_21 ]
  %p_19_8 = phi %hia.buffer [ %p_18_8, %edge_21 ]
  %p_19_9 = phi %hia.buffer [ %p_18_9, %edge_21 ]
  %p_19_10 = phi i64 [ %p_18_10, %edge_21 ]
  %p_19_11 = phi i64 [ %p_18_11, %edge_21 ]
  %p_19_12 = phi i64 [ %p_18_12, %edge_21 ]
  %p_19_13 = phi i64 [ %p_18_13, %edge_21 ]
  %t72 = extractvalue %hia.buffer %p_19_8, 0
  %t73 = extractvalue %hia.buffer %p_19_8, 1
  %t74 = icmp ult i64 %p_19_13, %t73
  br i1 %t74, label %ok_75, label %trap_75
trap_75:
  call void @abort()
  unreachable
ok_75:
  %t76 = getelementptr i8, ptr %t72, i64 %p_19_13
  %t77 = load i8, ptr %t76, align 1
  %t78 = zext i8 %t77 to i64
  %t79 = add i64 %p_19_12, %t78
  %t80 = add i64 %p_19_13, 1
  br label %edge_23
b20:
  %p_20_0 = phi i64 [ %p_18_0, %edge_22 ]
  %p_20_1 = phi i64 [ %p_18_1, %edge_22 ]
  %p_20_2 = phi i8 [ %p_18_2, %edge_22 ]
  %p_20_3 = phi i32 [ %p_18_3, %edge_22 ]
  %p_20_4 = phi i64 [ %p_18_4, %edge_22 ]
  %p_20_5 = phi i64 [ %p_18_5, %edge_22 ]
  %p_20_6 = phi i8 [ %p_18_6, %edge_22 ]
  %p_20_7 = phi i32 [ %p_18_7, %edge_22 ]
  %p_20_8 = phi %hia.buffer [ %p_18_8, %edge_22 ]
  %p_20_9 = phi %hia.buffer [ %p_18_9, %edge_22 ]
  %p_20_10 = phi i64 [ %p_18_10, %edge_22 ]
  %p_20_11 = phi i64 [ %p_18_11, %edge_22 ]
  %p_20_12 = phi i64 [ %p_18_12, %edge_22 ]
  %p_20_13 = phi i64 [ %p_18_13, %edge_22 ]
  %t81 = trunc i64 0 to i32
  %t82 = sext i32 %t81 to i64
  br label %edge_24
b21:
  %p_21_0 = phi i64 [ %p_20_0, %edge_24 ], [ %p_22_0, %edge_27 ]
  %p_21_1 = phi i64 [ %p_20_1, %edge_24 ], [ %p_22_1, %edge_27 ]
  %p_21_2 = phi i8 [ %p_20_2, %edge_24 ], [ %p_22_2, %edge_27 ]
  %p_21_3 = phi i32 [ %p_20_3, %edge_24 ], [ %p_22_3, %edge_27 ]
  %p_21_4 = phi i64 [ %p_20_4, %edge_24 ], [ %p_22_4, %edge_27 ]
  %p_21_5 = phi i64 [ %p_20_5, %edge_24 ], [ %p_22_5, %edge_27 ]
  %p_21_6 = phi i8 [ %p_20_6, %edge_24 ], [ %p_22_6, %edge_27 ]
  %p_21_7 = phi i32 [ %p_20_7, %edge_24 ], [ %p_22_7, %edge_27 ]
  %p_21_8 = phi %hia.buffer [ %p_20_8, %edge_24 ], [ %p_22_8, %edge_27 ]
  %p_21_9 = phi %hia.buffer [ %p_20_9, %edge_24 ], [ %p_22_9, %edge_27 ]
  %p_21_10 = phi i64 [ %p_20_10, %edge_24 ], [ %p_22_10, %edge_27 ]
  %p_21_11 = phi i64 [ %p_20_11, %edge_24 ], [ %p_22_11, %edge_27 ]
  %p_21_12 = phi i64 [ %p_20_12, %edge_24 ], [ %t91, %edge_27 ]
  %p_21_13 = phi i64 [ %p_20_13, %edge_24 ], [ %p_22_13, %edge_27 ]
  %p_21_14 = phi i64 [ %t82, %edge_24 ], [ %t92, %edge_27 ]
  %t83 = icmp ult i64 %p_21_14, %p_21_5
  br i1 %t83, label %edge_25, label %edge_26
b22:
  %p_22_0 = phi i64 [ %p_21_0, %edge_25 ]
  %p_22_1 = phi i64 [ %p_21_1, %edge_25 ]
  %p_22_2 = phi i8 [ %p_21_2, %edge_25 ]
  %p_22_3 = phi i32 [ %p_21_3, %edge_25 ]
  %p_22_4 = phi i64 [ %p_21_4, %edge_25 ]
  %p_22_5 = phi i64 [ %p_21_5, %edge_25 ]
  %p_22_6 = phi i8 [ %p_21_6, %edge_25 ]
  %p_22_7 = phi i32 [ %p_21_7, %edge_25 ]
  %p_22_8 = phi %hia.buffer [ %p_21_8, %edge_25 ]
  %p_22_9 = phi %hia.buffer [ %p_21_9, %edge_25 ]
  %p_22_10 = phi i64 [ %p_21_10, %edge_25 ]
  %p_22_11 = phi i64 [ %p_21_11, %edge_25 ]
  %p_22_12 = phi i64 [ %p_21_12, %edge_25 ]
  %p_22_13 = phi i64 [ %p_21_13, %edge_25 ]
  %p_22_14 = phi i64 [ %p_21_14, %edge_25 ]
  %t84 = extractvalue %hia.buffer %p_22_9, 0
  %t85 = extractvalue %hia.buffer %p_22_9, 1
  %t86 = icmp ult i64 %p_22_14, %t85
  br i1 %t86, label %ok_87, label %trap_87
trap_87:
  call void @abort()
  unreachable
ok_87:
  %t88 = getelementptr i8, ptr %t84, i64 %p_22_14
  %t89 = load i8, ptr %t88, align 1
  %t90 = zext i8 %t89 to i64
  %t91 = add i64 %p_22_12, %t90
  %t92 = add i64 %p_22_14, 1
  br label %edge_27
b23:
  %p_23_0 = phi i64 [ %p_21_0, %edge_26 ]
  %p_23_1 = phi i64 [ %p_21_1, %edge_26 ]
  %p_23_2 = phi i8 [ %p_21_2, %edge_26 ]
  %p_23_3 = phi i32 [ %p_21_3, %edge_26 ]
  %p_23_4 = phi i64 [ %p_21_4, %edge_26 ]
  %p_23_5 = phi i64 [ %p_21_5, %edge_26 ]
  %p_23_6 = phi i8 [ %p_21_6, %edge_26 ]
  %p_23_7 = phi i32 [ %p_21_7, %edge_26 ]
  %p_23_8 = phi %hia.buffer [ %p_21_8, %edge_26 ]
  %p_23_9 = phi %hia.buffer [ %p_21_9, %edge_26 ]
  %p_23_10 = phi i64 [ %p_21_10, %edge_26 ]
  %p_23_11 = phi i64 [ %p_21_11, %edge_26 ]
  %p_23_12 = phi i64 [ %p_21_12, %edge_26 ]
  %p_23_13 = phi i64 [ %p_21_13, %edge_26 ]
  %p_23_14 = phi i64 [ %p_21_14, %edge_26 ]
  %t93 = extractvalue %hia.buffer %p_23_9, 0
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %drop_nonnull_95, label %drop_after_95
drop_nonnull_95:
  call void @free(ptr %t93) nobuiltin
  br label %drop_after_95
drop_after_95:
  %t96 = extractvalue %hia.buffer %p_23_8, 0
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %drop_nonnull_98, label %drop_after_98
drop_nonnull_98:
  call void @free(ptr %t96) nobuiltin
  br label %drop_after_98
drop_after_98:
  ret i64 %p_23_12
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b11
edge_12:
  br label %b12
edge_13:
  br label %b10
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b13
edge_18:
  br label %b16
edge_19:
  br label %b17
edge_20:
  br label %b18
edge_21:
  br label %b19
edge_22:
  br label %b20
edge_23:
  br label %b18
edge_24:
  br label %b21
edge_25:
  br label %b22
edge_26:
  br label %b23
edge_27:
  br label %b21
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i8 %p_0_1) {
b0:
  %t1 = zext i8 %p_0_1 to i64
  %t2 = add i64 %p_0_0, %t1
  %t3 = trunc i64 251 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp ne i64 %t4, 0
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = urem i64 %t2, %t4
  ret i64 %t7
}

define i64 @c_hia_paired_bytes(i64 %a0, i64 %a1, i8 zeroext %a2, i32 %a3) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i64 %a1, i8 %a2, i32 %a3)
  ret i64 %result
}

define i64 @c_hia_seed_byte(i64 %a0, i8 zeroext %a1) {
entry:
  %result = call i64 @__hia_fn_1(i64 %a0, i8 %a1)
  ret i64 %result
}
