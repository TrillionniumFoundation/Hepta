#!/usr/bin/env python3
"""Download connector-returned references without publishing private transport URLs."""
from __future__ import annotations

import argparse
import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import urllib.error
import urllib.request


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def download(row, output):
    artifact = row['artifact']
    aid = int(artifact['id'])
    expected_size = int(artifact['size_in_bytes'])
    expected_sha = artifact['digest'].removeprefix('sha256:')
    assert len(expected_sha) == 64 and not artifact['expired']
    destination = output / 'raw-artifacts' / f'{aid}.zip'
    partial = destination.with_suffix('.zip.part')
    receipt = dict(artifact_id=aid, run_id=row['run_id'], name=artifact['name'],
                   source_sha=artifact['workflow_run']['head_sha'],
                   expected_bytes=expected_size, expected_sha256=expected_sha,
                   relative_path=str(destination.relative_to(output)),
                   official_url=artifact['url'], started_at_utc=now())
    try:
        if destination.exists():
            data = destination.read_bytes()
            actual_size, actual_sha = len(data), hashlib.sha256(data).hexdigest()
            receipt['transport'] = 'already-present-verified-original-zip'
        else:
            partial.unlink(missing_ok=True)
            digest = hashlib.sha256()
            actual_size = 0
            with urllib.request.urlopen(row['uri']['download_url'], timeout=120) as response:
                with partial.open('xb') as stream:
                    while block := response.read(1024 * 1024):
                        actual_size += len(block)
                        if actual_size > expected_size:
                            raise ValueError('official-size-limit-exceeded')
                        digest.update(block)
                        stream.write(block)
            actual_sha = digest.hexdigest()
            receipt['transport'] = 'github-connector-file-reference'
        assert actual_size == expected_size, 'official-byte-count-mismatch'
        assert actual_sha == expected_sha, 'official-digest-mismatch'
        if partial.exists():
            partial.rename(destination)
        receipt.update(ok=True, actual_bytes=actual_size, actual_sha256=actual_sha)
    except Exception as exc:
        # Exception messages can contain transport URLs. Publish only class/status.
        receipt.update(ok=False, error_type=type(exc).__name__)
        if isinstance(exc, urllib.error.HTTPError):
            receipt['http_status'] = exc.code
        partial.unlink(missing_ok=True)
    receipt['ended_at_utc'] = now()
    (output / 'download-receipts' / f'{aid}.json').write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--private-references', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args()
    rows = json.loads(args.private_references.read_text())
    assert len({row['artifact']['id'] for row in rows}) == len(rows)
    (args.output / 'raw-artifacts').mkdir(exist_ok=True)
    (args.output / 'download-receipts').mkdir(exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        receipts = list(pool.map(lambda row: download(row, args.output), rows))
    print(json.dumps(dict(count=len(receipts), ok=sum(r['ok'] for r in receipts),
                          bytes=sum(r.get('actual_bytes', 0) for r in receipts),
                          failures=[r for r in receipts if not r['ok']]), indent=2))
    return 0 if all(r['ok'] for r in receipts) else 1


if __name__ == '__main__':
    raise SystemExit(main())
