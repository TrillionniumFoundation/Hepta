#!/usr/bin/env python3
"""Freeze exact official-ZIP publication units, including lossless ordered parts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIMIT, PART = 12_000_000, 4 * 1024 * 1024


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def main():
    target = ROOT / 'publication-parts'
    target.mkdir(exist_ok=False)
    rows = []
    for path in sorted((ROOT / 'raw-artifacts').glob('*.zip')):
        original = path.read_bytes(); record = identity(original)
        receipt = json.loads((ROOT / 'download-receipts' / (path.stem + '.json')).read_text())
        assert receipt['ok'] is True
        assert record['sha256'] == receipt['expected_sha256'] and record['bytes'] == receipt['expected_bytes']
        row = {'artifact_id': int(path.stem), 'run_id': receipt['run_id'], 'source': receipt['source_sha'],
               'original_path': str(path.relative_to(ROOT)), **record, 'payloads': []}
        if len(original) <= LIMIT:
            row['payloads'].append({'path': str(path.relative_to(ROOT)), 'index': 0, **record})
        else:
            count = (len(original) + PART - 1) // PART
            for index in range(count):
                data = original[index * PART:(index + 1) * PART]
                part_path = target / f'{path.name}.part-{index + 1:03d}-of-{count:03d}'
                part_path.write_bytes(data)
                row['payloads'].append({'path': str(part_path.relative_to(ROOT)), 'index': index, **identity(data)})
        # Read every payload back and reconstruct the original byte stream.
        restored = bytearray()
        for entry in row['payloads']:
            data = (ROOT / entry['path']).read_bytes()
            assert identity(data) == {k: entry[k] for k in ('bytes', 'sha256', 'git_blob_sha1')}
            assert len(data) <= LIMIT
            restored.extend(data)
        assert bytes(restored) == original and identity(restored) == record
        row['ordered_readback_matches_original'] = True
        rows.append(row)
    assert len(rows) == 18
    result = {'schema': 'hepta.official-artifact-publication-payloads.v1',
              'source': '699de39a8e92e0f083df316ecc5333fb3ecf8571',
              'scope': 'Official ZIP bytes only; independent content-audit results are a separate record.',
              'whole_file_limit_bytes': LIMIT, 'part_bytes': PART, 'artifacts': rows,
              'artifact_count': len(rows), 'payload_count': sum(len(r['payloads']) for r in rows),
              'original_bytes': sum(r['bytes'] for r in rows)}
    (ROOT / 'publication-payloads.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('artifact_count', 'payload_count', 'original_bytes')}))


if __name__ == '__main__':
    main()
