#!/usr/bin/env python3
"""Summarize immutable hosted observations and the completed offline audit."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = '699de39a8e92e0f083df316ecc5333fb3ecf8571'
KINDS = {40862645159: 'actual-host-ABI', 40862645199: 'actual-host-C++',
         40862645202: 'source/application-push', 40862658213: 'source/application-pull-request',
         40862645459: 'verified-optimization-NDU-push', 40862658216: 'verified-optimization-NDU-pull-request',
         40862645318: 'full-release'}


def load(name):
    return json.loads((ROOT / name).read_text())


def main():
    audits = {int(p.stem): json.loads(p.read_text()) for p in (ROOT / 'content-audits').glob('*.json')}
    assert len(audits) == 18 and all(d['status'] == 'passed_with_explicit_scope_limits' for d in audits.values())
    runs = []
    for run in load('runs-snapshot-03.json')['workflow_runs']:
        rid = run['id']; jobs = load(f'jobs-{rid}-snapshot-03.json')['jobs']
        artifacts = load(f'artifacts-{rid}-snapshot-03.json')['artifacts']
        assert run['head_sha'] == SOURCE and all(a['workflow_run']['head_sha'] == SOURCE for a in artifacts)
        rows = []
        for artifact in artifacts:
            audit = audits[artifact['id']]
            rows.append(dict(id=artifact['id'], name=artifact['name'], bytes=artifact['size_in_bytes'],
                             official_sha256=artifact['digest'].removeprefix('sha256:'),
                             audit_status=audit['status'], content_audit=f'content-audits/{artifact["id"]}.json',
                             source_maps=audit['source_maps'], details=audit['details'],
                             bound_retained_files=len(audit['checked_content_bindings']),
                             unretained_reference_paths=len(audit['unretained_reference_paths'])))
        runs.append(dict(run_id=rid, kind=KINDS[rid], event=run['event'], attempt=run['run_attempt'],
                         url=run['html_url'], status=run['status'], conclusion=run['conclusion'],
                         jobs_total=len(jobs), successful_jobs=sum(j['conclusion'] == 'success' for j in jobs),
                         failed_steps=[dict(job_id=j['id'], name=s['name'], conclusion=s['conclusion'])
                                       for j in jobs for s in j['steps'] if s['conclusion'] in ('failure', 'timed_out', 'cancelled')],
                         artifact_content_audit='completed_with_explicit_scope_limits' if artifacts else 'not_available_run_still_in_progress',
                         artifacts=rows))
    final = load('full-release-final-observation.json')
    assert final['run']['head_sha'] == SOURCE
    result = dict(schema='hepta.current-hosted-ci-audit-summary.v1', source=SOURCE,
                  tree='592b6114f659fb18b13ad3fa5ed5e213ecdb92b5',
                  snapshot_03=load('observation-snapshot-03.json'), runs=sorted(runs, key=lambda r: r['run_id']),
                  content_audit_completed_utc=load('content-audit-index.json')['completed_utc'],
                  raw_zip_publication_commit=load('raw-zip-publication-commit.json')['sha'],
                  original_zip_count=18, original_zip_bytes=sum(d['official_archive']['bytes'] for d in audits.values()),
                  original_zip_members=sum(len(d['retained_members']) for d in audits.values()),
                  original_member_bytes=sum(v['bytes'] for d in audits.values() for v in d['retained_members'].values()),
                  independently_hash_bound_retained_files=sum(len(d['checked_content_bindings']) for d in audits.values()),
                  full_release_final=dict(observed_start=final['observed_start'], observed_end=final['observed_end'],
                    status=final['run']['status'], conclusion=final['run']['conclusion'], artifacts=final['artifacts']['total_count'],
                    active_steps=[dict(job_id=j['id'], name=s['name'], status=s['status'])
                                  for j in final['jobs']['jobs'] for s in j['steps'] if s['status'] == 'in_progress'],
                    failed_steps=[dict(job_id=j['id'], name=s['name'], conclusion=s['conclusion'])
                                  for j in final['jobs']['jobs'] for s in j['steps'] if s['conclusion'] in ('failure', 'timed_out', 'cancelled')]),
                  claims=dict(all_18_official_archives_sha_size_crc_verified=True, selected_retained_content_and_source_bindings_audited=True,
                              all_original_full_toolchains_retained=False, all_abi_binary_bytes_retained=False,
                              full_release_succeeded=False, current_filecheck_performance_measured=False,
                              independent_agent_efficiency_qualified=False, whole_language_soundness_proved=False,
                              rust_production_authority_switched=False, optimization_policy_changed=False),
                  local_actions=dict(native_programs_executed=0, test_suites_executed=0, source_files_modified=0, workflows_triggered=0,
                                     prior_snapshots_or_component_archive_modified=False))
    (ROOT / 'summary.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('original_zip_count', 'original_zip_bytes', 'original_zip_members',
                                          'original_member_bytes', 'independently_hash_bound_retained_files')}))


if __name__ == '__main__':
    main()
