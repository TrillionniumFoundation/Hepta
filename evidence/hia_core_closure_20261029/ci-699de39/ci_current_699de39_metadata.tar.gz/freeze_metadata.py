#!/usr/bin/env python3
"""Freeze metadata separately from the already-published exact ZIP payloads."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

from scan_public_files import PATTERNS

ROOT = Path(__file__).resolve().parent
ARCHIVE = 'ci_current_699de39_metadata.tar.gz'
GENERATED = {'PUBLIC_FILES.json', 'MANIFEST.json', 'freeze-receipt.json', 'publication-metadata.json', ARCHIVE}
SOURCE = '699de39a8e92e0f083df316ecc5333fb3ecf8571'


def ident(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                git_blob_sha1=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest())


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def scan(data, path):
    for label, pattern in PATTERNS.items():
        assert not re.search(pattern, data), f'credential pattern {label} in {path}; values not printed'


def read(name):
    p = ROOT / name
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT.resolve())
    return p.read_bytes()


def main():
    assert all(not (ROOT / name).exists() for name in GENERATED), 'freeze outputs already exist'
    payload_map = json.loads(read('publication-payloads.json'))
    assert ident(read('publication-payloads.json'))['sha256'] == '54bb41503f8ae316a6d650dd458ae2272007e3172b8c704ab4086ed9ff63da23'
    summary = json.loads(read('summary.json'))
    assert summary['original_zip_count'] == 18 and summary['original_zip_bytes'] == 79211552
    assert all(r['status'] == 'passed_with_explicit_scope_limits' for r in json.loads(read('content-audit-index.json'))['artifacts'])
    scanner = json.loads(read('credential-scan.json'))
    assert scanner['pattern_count'] == 10 and scanner['findings'] == [] and scanner['zip_members_scanned'] == 3068
    payloads = sorted(p['path'] for row in payload_map['artifacts'] for p in row['payloads'])
    assert len(payloads) == len(set(payloads)) == 28
    metadata = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
                      if p.is_file() and p.name not in GENERATED and p.suffix != '.pyc'
                      and 'raw-artifacts' not in p.parts and 'publication-parts' not in p.parts
                      and '__pycache__' not in p.parts)
    local_large_originals = sorted(row['original_path'] for row in payload_map['artifacts'] if len(row['payloads']) > 1)
    selected = sorted(metadata + payloads + list(GENERATED))
    assert len(selected) == len(set(selected))
    for name in selected:
        posix = PurePosixPath(name)
        assert not posix.is_absolute() and '..' not in posix.parts and '\\' not in name
        assert 'private' not in posix.name.lower()
    allow = dict(schema='hepta.current-ci-public-allowlist.v1', source=SOURCE, files=selected,
                 metadata_archive=ARCHIVE, metadata_members=sorted(metadata + ['PUBLIC_FILES.json', 'MANIFEST.json']),
                 already_published_original_zip_payloads=payloads,
                 original_zip_payload_map='publication-payloads.json',
                 excluded_local_reconstructable_original_zip_copies=local_large_originals,
                 excluded_private_transport_references='Outside this directory; never selected or read by this collector.',
                 final_control_files=sorted(GENERATED - {ARCHIVE}),
                 delivery='Metadata members are embedded in the metadata archive; 28 original ZIP payloads remain separate.')
    allow_bytes = encode(allow); scan(allow_bytes, 'PUBLIC_FILES.json')
    (ROOT / 'PUBLIC_FILES.json').write_bytes(allow_bytes)
    inputs = metadata + payloads + ['PUBLIC_FILES.json']
    inventory = []
    for name in sorted(inputs):
        data = read(name); scan(data, name)
        inventory.append(dict(path=name, delivery='separate-original-zip-payload' if name in payloads else 'metadata-archive-member', **ident(data)))
    manifest = dict(schema='hepta.current-ci-public-manifest.v1', source=SOURCE,
                    tree=summary['tree'], files=inventory,
                    original_archives=payload_map['artifacts'],
                    self_and_receipt_policy='This manifest, the metadata archive, and final receipts are bound by freeze-receipt.json and publication-metadata.json; Git publication binds the final control files.',
                    public_allowlist_sha256=ident(allow_bytes)['sha256'])
    manifest_bytes = encode(manifest); scan(manifest_bytes, 'MANIFEST.json')
    (ROOT / 'MANIFEST.json').write_bytes(manifest_bytes)
    members = sorted(metadata + ['PUBLIC_FILES.json', 'MANIFEST.json'])
    expected = {row['path']: {k: row[k] for k in ('bytes', 'sha256', 'git_blob_sha1')} for row in inventory if row['path'] in members}
    expected['MANIFEST.json'] = ident(manifest_bytes)
    with (ROOT / ARCHIVE).open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
            with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name in members:
                    data = read(name); assert ident(data) == expected[name]
                    info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
    archive_bytes = read(ARCHIVE); assert len(archive_bytes) <= 12_000_000
    scanned_members = 0
    with tarfile.open(ROOT / ARCHIVE, 'r:gz') as archive:
        actual = archive.getmembers(); assert [x.name for x in actual] == members
        for info in actual:
            assert info.isfile() and info.mode == 0o644
            data = archive.extractfile(info).read()
            assert ident(data) == expected[info.name]
            assert data == read(info.name)
            scan(data, ARCHIVE + '!' + info.name); scanned_members += 1
    # Re-read every original payload and its original local ZIP after packaging.
    for row in payload_map['artifacts']:
        restored = bytearray()
        for payload in row['payloads']:
            data = read(payload['path'])
            assert ident(data) == {k: payload[k] for k in ('bytes', 'sha256', 'git_blob_sha1')}
            restored.extend(data)
        assert bytes(restored) == read(row['original_path'])
        assert ident(restored) == {k: row[k] for k in ('bytes', 'sha256', 'git_blob_sha1')}
    receipt = dict(schema='hepta.current-ci-freeze-receipt.v1', source=SOURCE,
                   metadata_archive=dict(path=ARCHIVE, **ident(archive_bytes)),
                   metadata_members=scanned_members, metadata_raw_bytes=sum(expected[n]['bytes'] for n in members),
                   all_metadata_members_read_back=True, all_metadata_sha_git_blob_mode_checks_passed=True,
                   original_archives=18, original_archive_bytes=79211552, original_payloads=28,
                   original_payloads_rechecked_after_packaging=True, ordered_parts_reconstructed_byte_identical=True,
                   manifest=dict(path='MANIFEST.json', **ident(manifest_bytes)),
                   public_allowlist=dict(path='PUBLIC_FILES.json', **ident(allow_bytes)),
                   completed_content_audits=18, runtime_or_test_reruns=0,
                   credential_scan=dict(pattern_count=10, decoded_original_zip_members=3068,
                                        decoded_original_zip_bytes=342675778, findings=[],
                                        all_selected_metadata_and_payloads_scanned=True, all_metadata_archive_members_scanned=True,
                                        private_transport_references_read=False),
                   full_release_final_observation=summary['full_release_final'],
                   previously_frozen_component_archive_or_snapshots_modified=False)
    receipt_bytes = encode(receipt); scan(receipt_bytes, 'freeze-receipt.json')
    (ROOT / 'freeze-receipt.json').write_bytes(receipt_bytes)
    publish_names = [ARCHIVE, 'README.md', 'summary.json', 'content-audit-index.json', 'PUBLIC_FILES.json', 'MANIFEST.json', 'freeze-receipt.json']
    public = dict(schema='hepta.current-ci-metadata-publication.v1', source=SOURCE,
                  repository_prefix='evidence/hia_core_closure_20261029/ci-699de39/',
                  prior_original_zip_commit='5c9875c14f12a676beef70da0674c1701c99f92c',
                  payloads=[dict(path=n, **ident(read(n))) for n in publish_names],
                  original_zip_payloads_repeated=False,
                  this_map_is_a_final_control_file='Publish this JSON beside these seven files; its identity is bound by the resulting Git commit.')
    public_bytes = encode(public); scan(public_bytes, 'publication-metadata.json')
    (ROOT / 'publication-metadata.json').write_bytes(public_bytes)
    for name in GENERATED:
        scan(read(name), name)
    assert sorted(p for p in selected if not (ROOT / p).is_file()) == []
    print(json.dumps(dict(metadata_archive=receipt['metadata_archive'], metadata_members=scanned_members,
                          metadata_publication_files=len(publish_names) + 1,
                          public_allowlist_files=len(selected), manifest_sha256=ident(manifest_bytes)['sha256'],
                          receipt_sha256=ident(receipt_bytes)['sha256'], publication_map_sha256=ident(public_bytes)['sha256']), indent=2))


if __name__ == '__main__':
    main()
