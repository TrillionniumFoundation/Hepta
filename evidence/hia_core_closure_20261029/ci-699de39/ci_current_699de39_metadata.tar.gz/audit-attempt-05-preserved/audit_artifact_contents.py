#!/usr/bin/env python3
"""Offline audit of official ZIP bytes, recorded inputs, and retained outputs.

No native compiler, test suite, workflow, artifact executable, or network is run.
The ABI validator only regenerates/checks finite frontend material with native=False.
Host compiler bytes and temporary native-host binaries are not present in the ZIPs;
they are explicitly outside this independent retained-content audit.
"""
from __future__ import annotations

import base64
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import sys
import traceback
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'hepta'
HEAD = '699de39a8e92e0f083df316ecc5333fb3ecf8571'
TREE = '592b6114f659fb18b13ad3fa5ed5e213ecdb92b5'
SHA = re.compile(r'[0-9a-f]{64}\Z')
WINDOWS_CRLF_EXAMPLES = {
    'examples/cpp/upgrade/adapter.hpp', 'examples/cpp/upgrade/consumer.hepta',
    'examples/cpp/upgrade/contract.json', 'examples/cpp/upgrade/harness.cpp',
    'examples/cpp/upstream_host/README.md', 'examples/cpp/upstream_host/consumer.hepta',
    'examples/cpp/upstream_host/harness.cpp',
}
sys.dont_write_bytecode = True


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n')


def git(*args, input=None):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args], input=input)


def collect_blobs():
    require(git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE, 'public source tree differs')
    tracked = set(git('ls-tree', '-r', '--name-only', HEAD).decode().splitlines())
    wanted = {p for p in tracked if p.startswith(('hepta/', 'tools/')) and p.endswith('.py')}
    for path in sorted((ROOT / 'raw-artifacts').glob('*.zip')):
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist():
                if not info.filename.endswith('.json'):
                    continue
                try:
                    value = json.loads(archive.read(info))
                except (UnicodeError, ValueError):
                    continue
                def walk(obj):
                    if isinstance(obj, dict):
                        for key, item in obj.items():
                            if key in tracked and isinstance(item, str) and SHA.fullmatch(item):
                                wanted.add(key)
                            walk(item)
                    elif isinstance(obj, list):
                        for item in obj:
                            walk(item)
                walk(value)
    wanted.update(p for p in tracked if p.startswith('tests/fixtures/c_migration/stb_divide/'))
    wanted.update(p for p in tracked if p.startswith('tests/fixtures/cpp_upstream/'))
    wanted.update(['docs/HIA_SAFETY_CONTRACT.json', 'experiments/hia_filecheck/PROTOCOL_20261028.json'])
    wanted.update(p for p in tracked if p.startswith('rust/hia-ndu-bridge/'))
    names = sorted(wanted)
    raw = git('cat-file', '--batch', input=''.join(HEAD + ':' + p + '\n' for p in names).encode())
    blobs, offset = {}, 0
    for path in names:
        end = raw.index(b'\n', offset)
        fields = raw[offset:end].split()
        require(len(fields) == 3 and fields[1] == b'blob', 'source path is not a blob: ' + path)
        size = int(fields[2]); offset = end + 1
        data = raw[offset:offset + size]; offset += size + 1
        require(hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + data).hexdigest() == fields[0].decode(),
                'Git object hash mismatch: ' + path)
        blobs[path] = data
    require(offset == len(raw), 'unconsumed Git batch bytes')
    return blobs


BLOBS = collect_blobs()
SOURCE_HASHES = {path: digest(data) for path, data in BLOBS.items()}
compiler = hashlib.sha256()
for name in sorted(p for p in BLOBS if p.startswith('hepta/') and p.count('/') == 1 and p.endswith('.py')):
    compiler.update(Path(name).name.encode() + b'\0' + BLOBS[name] + b'\0')
COMPILER_SHA = compiler.hexdigest()
for name, data in BLOBS.items():
    if name.startswith(('hepta/', 'tools/')) and name.endswith('.py'):
        require((REPO / name).read_bytes() == data, 'local audit dependency differs from public source: ' + name)
sys.path.insert(0, str(REPO))
from tools.validate_native_host import validate_report as validate_abi
from tools.qualify_cpp_upstream_host import check_observation, CLAIMS as CPP_CLAIMS


def no_process(*args, **kwargs):
    raise RuntimeError('Native/test/process execution prohibited during offline artifact audit')


class Audit:
    def __init__(self, artifact, run_id):
        self.artifact, self.run_id = artifact, run_id
        self.path = ROOT / 'raw-artifacts' / (str(artifact['id']) + '.zip')
        self.z = zipfile.ZipFile(self.path)
        self.files, self.source_checks, self.content_checks = {}, [], {}
        self.windows_paths = False
        self.unretained = {}
        self.declared_path_mutations = {}
        self.report_names = []
        require(artifact['workflow_run']['head_sha'] == HEAD and artifact['workflow_run']['id'] == run_id,
                'official artifact source/run identity differs')
        require(not artifact['expired'], 'official artifact expired')
        require(self.path.stat().st_size == artifact['size_in_bytes'], 'official archive size differs')
        require(digest(self.path.read_bytes()) == artifact['digest'].removeprefix('sha256:'), 'official archive digest differs')
        require(self.z.testzip() is None, 'ZIP CRC failure')
        for item in self.z.infolist():
            p = PurePosixPath(item.filename)
            require(not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename,
                    'unsafe archive name: ' + item.filename)
            require(item.filename not in self.files, 'duplicate ZIP member')
            require((item.external_attr >> 16) & 0o170000 != 0o120000, 'ZIP symlink is not accepted')
            data = self.z.read(item)
            self.files[item.filename] = dict(bytes=len(data), sha256=digest(data), crc32=f'{item.CRC:08x}')

    def read(self, name):
        require(name in self.files, 'retained artifact missing: ' + name)
        return self.z.read(name)

    def report(self, name):
        self.report_names.append(name)
        data = self.read(name)
        out = ROOT / 'selected-raw-reports' / str(self.artifact['id']) / name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        return json.loads(data)

    def source(self, mapping, where, prefix=''):
        require(isinstance(mapping, dict) and mapping, 'missing source map: ' + where)
        names = []
        for name, sha in mapping.items():
            # Git tree names use '/', while the actual Windows producer used
            # str(relative_path). Only the recorded Windows host permits this
            # path representation mapping; source bytes and argv stay exact.
            if self.windows_paths:
                name = name.replace('\\', '/')
            path = prefix + name
            require(isinstance(sha, str) and SHA.fullmatch(sha), 'non-SHA source identity: ' + path)
            require(SOURCE_HASHES.get(path) == sha, 'source differs from exact public Git blob: ' + path)
            names.append(path)
        require(len(set(names)) == len(names), 'ambiguous normalized source path')
        self.source_checks.append(dict(where=where, count=len(names), paths=sorted(names), all_match=True))

    def cpp_sources(self, mapping):
        exact, checkouts = {}, []
        for original, sha in mapping.items():
            name = original.replace('\\', '/') if self.windows_paths else original
            if SOURCE_HASHES.get(name) == sha:
                exact[name] = sha
                continue
            require(self.windows_paths and name in WINDOWS_CRLF_EXAMPLES, 'unexpected C++ source byte difference: ' + name)
            original_bytes = BLOBS[name]
            require(b'\r' not in original_bytes, 'ambiguous source newline reconstruction')
            reconstructed = original_bytes.replace(b'\n', b'\r\n')
            require(digest(reconstructed) == sha, 'Windows checkout is not exact LF-to-CRLF bytes: ' + name)
            checkouts.append(dict(path=name, git_blob_sha256=SOURCE_HASHES[name], checkout_sha256=sha,
                                  transformation='replace each LF byte with CRLF; no other edits',
                                  git_blob_bytes=len(original_bytes), checkout_bytes=len(reconstructed)))
        self.source(exact, 'cpp/source_inputs/exact_git_blob_bytes')
        if self.windows_paths:
            require({r['path'] for r in checkouts} == WINDOWS_CRLF_EXAMPLES, 'Windows checkout reconstruction denominator differs')
        self.source_checks.append(dict(where='cpp/source_inputs/windows_checkout_reconstructions', count=len(checkouts),
                                       all_match=True, reconstructions=checkouts,
                                       limitation='These checkout SHA values differ from LF Git blob SHA values; both are preserved.'))

    def map_path(self, path):
        if not isinstance(path, str):
            return None
        normalized = path.replace('\\', '/')
        candidates = [normalized]
        if '/artifacts/' in normalized:
            tail = normalized.split('/artifacts/', 1)[1]
            candidates += [tail, 'Hepta/Hepta/artifacts/' + tail]
            if tail.startswith('six-outcomes/'):
                candidates.append(tail.removeprefix('six-outcomes/'))
        if '/_temp/' in normalized:
            candidates.append('_temp/' + normalized.split('/_temp/', 1)[1])
        matches = sorted({p for p in candidates if p in self.files})
        require(len(matches) <= 1, 'ambiguous archive reference: ' + path)
        return matches[0] if matches else None

    def bound(self, name, sha, size=None, *, where):
        if self.windows_paths:
            name = name.replace('\\', '/')
        require(name in self.files, 'expected retained file missing: ' + name)
        require(self.files[name]['sha256'] == sha, 'retained digest mismatch: ' + name)
        require(size is None or self.files[name]['bytes'] == size, 'retained byte count mismatch: ' + name)
        row = self.content_checks.setdefault(name, dict(sha256=sha, bytes=self.files[name]['bytes'], references=[]))
        if where not in row['references']:
            row['references'].append(where)

    def ref(self, path, sha, size=None, *, where, required=True, base=None):
        member = self.map_path(path)
        if member is None and base and not str(path).startswith(('/', '\\')) and ':' not in str(path):
            candidate = base + str(path).replace('\\', '/')
            if candidate in self.files:
                member = candidate
        if member is None:
            if required:
                raise ValueError('required referenced bytes not retained: ' + path)
            self.unretained.setdefault(path, []).append(where)
            return None
        mutation = self.declared_path_mutations.get(member)
        if mutation is not None and sha == mutation['original_sha256']:
            self.bound(mutation['retained_original_member'], sha, size, where=where + '/sealed-snapshot-before-negative-path-tamper')
            return mutation['retained_original_member']
        self.bound(member, sha, size, where=where)
        return member

    def references(self, obj, where, base=None):
        """Check every resolvable declared file reference; retain omissions explicitly."""
        if isinstance(obj, dict):
            for path_key, hash_key, size_key in [
                ('path', 'sha256', 'bytes'), ('artifact', 'artifact_sha256', 'artifact_bytes'),
                ('output', 'artifact_sha256', 'artifact_bytes'), ('binary', 'binary_sha256', None),
                ('compiled_binary', 'compiled_binary_sha256', None),
                ('stdout_path', 'stdout_sha256', None), ('stderr_path', 'stderr_sha256', None),
            ]:
                if isinstance(obj.get(path_key), str) and isinstance(obj.get(hash_key), str) and SHA.fullmatch(obj[hash_key]):
                    self.ref(obj[path_key], obj[hash_key], obj.get(size_key) if size_key else None,
                             where=where + '/' + path_key, required=False, base=base)
            for key, value in obj.items():
                self.references(value, where + '/' + key, base=base)
        elif isinstance(obj, list):
            for index, value in enumerate(obj):
                self.references(value, where + '/' + str(index), base=base)

    def process(self, process, where, expected_code=None):
        require(process['status'] == 'exited' and process['executable_unchanged'] is True, 'process receipt not stable/exited')
        if expected_code is not None:
            require(type(process['exit_code']) is int and process['exit_code'] == expected_code, 'process exit code differs')
        for stream in ('stdout', 'stderr'):
            member = self.ref(process[stream + '_path'], process[stream + '_sha256'], where=where + '/' + stream)
            raw = self.read(member)
            require(base64.b64decode(process[stream + '_bytes_base64'], validate=True) == raw, 'raw/base64 stream differs')
            require(raw.decode('utf-8', errors='replace') == process[stream], 'raw/text stream differs')

    def executable(self, name, expected, host, where):
        self.bound(name, expected['sha256'], expected['bytes'], where=where)
        data = self.read(name)
        system, machine = host['system'], host['machine']
        if system == 'Linux':
            valid = data[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', data, 18)[0] == {'x86_64': 62, 'aarch64': 183}[machine]
            fmt = 'ELF64'
        elif system == 'Darwin':
            valid = data[:4] == b'\xcf\xfa\xed\xfe' and struct.unpack_from('<I', data, 4)[0] == {'x86_64': 0x1000007, 'aarch64': 0x100000c}[machine]
            fmt = 'Mach-O64'
        else:
            offset = struct.unpack_from('<I', data, 60)[0]
            valid = data[:2] == b'MZ' and data[offset:offset + 4] == b'PE\0\0' and struct.unpack_from('<H', data, offset + 4)[0] == {'x86_64': 0x8664, 'aarch64': 0xaa64}[machine]
            fmt = 'PE32+'
        require(valid and expected['format'] == fmt and expected['machine'] == machine, 'native artifact machine/format mismatch')

    def abi(self):
        native = self.report('native-host.json')
        self.windows_paths = native['host']['system'] == 'Windows'
        original_popen = subprocess.Popen
        try:
            subprocess.Popen = no_process
            validate_abi(native)
        finally:
            subprocess.Popen = original_popen
        require(native['compiler_sha256'] == COMPILER_SHA, 'ABI compiler digest differs from Git')
        preflight = self.report('original-type-preflight.json')
        require(preflight['ok'] is True, 'original type preflight failed')
        require(preflight['reader_identity']['worker']['sha256'] == SOURCE_HASHES['hepta/c_parameter_types.py'], 'preflight worker differs')
        stb = self.report('stb-divide-host.json')
        require(stb['ok'] is True and stb['source_unchanged_during_run'] is True, 'stb host qualification not passed/stable')
        require(stb['source_before'] == stb['source_after'], 'stb source changed')
        for label in ('source_before', 'source_after'):
            source = stb[label]
            require(source['commit'] == HEAD and source['tree'] == TREE and source['status'] == '', 'stb source identity differs')
            self.source(source['implementation_files'], 'stb/' + label + '/implementation_files')
            self.source(source['fixture_files'], 'stb/' + label + '/fixture_files', 'tests/fixtures/c_migration/stb_divide/')
        require(self.read('stb-divide-host/qualification.json') == self.read('stb-divide-host.json'), 'copied stb report differs')
        for item in stb['artifacts']:
            self.bound('stb-divide-host/' + item['path'], item['sha256'], item['bytes'], where='stb/artifacts')
        self.references(stb, 'stb')
        require(all(stb['checks'].values()), 'stb check failed')
        return dict(kind='actual_host_abi_and_declared_stb_component', host=native['host'], c_family=native['c_compiler']['family'],
                    abi_report_static_validator='passed with native process execution prohibited',
                    abi_compiler_sha256=COMPILER_SHA, abi_foreign_calls_each=native['matrix']['expected_foreign_calls_per_run'],
                    abi_profiles=len(native['executions']), abi_type_negative_controls=len(native['type_negative_controls']),
                    abi_wrong_code=native['negative_control']['status'], stb_totals=stb['totals'],
                    limitations=['Temporary ABI matrix object/executables are not uploaded by this workflow; their report SHA values were not recomputed from original binary bytes.',
                                 'The retained stb_divide outputs are separately byte-audited; the finite ABI matrix does not qualify all ABI/lifetime/callback cases.'])

    def cpp(self):
        report = self.report('cpp-upstream-host.json')
        self.windows_paths = report['host']['system'] == 'Windows'
        require(report['ok'] is True and report['status'] == 'passed' and report['inputs_unchanged'] is True, 'C++ report not passed/stable')
        require(report['source_commit'] == HEAD and report['tracked_source_status'] == '', 'C++ source identity differs')
        require(report['compiler_sha256'] == COMPILER_SHA and report['claims'] == CPP_CLAIMS, 'C++ compiler/scope differs')
        self.cpp_sources(report['source_inputs'])
        require(self.read('cpp-upstream-host/qualification.json') == self.read('cpp-upstream-host.json'), 'copied C++ report differs')
        retained = report['retained_files']
        actual = {p.removeprefix('cpp-upstream-host/') for p in self.files if p.startswith('cpp-upstream-host/')} - {'qualification.json', 'audit.json'}
        reported_names = {p.replace('\\', '/') if self.windows_paths else p for p in retained}
        require(len(reported_names) == len(retained) and actual == reported_names, 'C++ retained file set differs')
        for name, entry in retained.items():
            self.bound('cpp-upstream-host/' + name, entry['sha256'], entry['bytes'], where='cpp/retained_files')
        host = report['host']; versions = []
        require([row['version'] for row in report['versions']] == ['3.11.3', '3.12.0'], 'C++ version denominator differs')
        for row in report['versions']:
            version = row['version']; base = 'cpp-upstream-host/' + version + '/'
            require(row['status'] == 'passed', 'C++ version failed')
            check_observation(row['observed'], version)
            for name, sha in row['generated_identity'].items():
                self.bound(base + 'bridge/' + name, sha, where='cpp/generated_identity')
            caller = BLOBS['examples/cpp/upstream_host/consumer.hepta']
            if self.windows_paths:
                caller = caller.replace(b'\n', b'\r\n')
            require(self.read(base + 'bridge/consumer.hepta') == caller, 'actual Hepta consumer differs from recorded checkout bytes')
            require(json.loads(self.read(base + 'bridge/consumer.native.json')) == row['native'], 'native receipt differs')
            require(json.loads(self.read(base + 'bridge/report.json')) == row['bridge'], 'bridge receipt differs')
            self.ref(row['native']['artifact'], row['native']['artifact_sha256'], row['native']['artifact_bytes'], where='cpp/native_object')
            exe = self.map_path(row['execution']['argv'][0]); require(exe is not None, 'C++ actual executable missing')
            self.executable(exe, row['executable'], host, 'cpp/executable')
            require(row['executable']['sha256'] == row['execution']['executable_sha256'], 'executed binary receipt differs')
            require([p['stage'] for p in row['processes']] == ['compile-bridge', 'compile-harness', 'link', 'execute'], 'C++ process set differs')
            for process in row['processes']:
                self.process(process, 'cpp/' + version + '/' + process['stage'], expected_code=0)
            require(row['execution'] == row['processes'][-1] and row['link'] == row['processes'][-2], 'C++ original process record differs')
            require(json.loads(row['execution']['stdout']) == row['observed'], 'C++ raw observations differ')
            versions.append(dict(version=version, cases=len(row['observed']['cases']), lifecycle_cases=row['observed']['lifecycle_cases'],
                                 concurrent_calls=row['observed']['concurrent_calls'], executable_sha256=row['executable']['sha256']))
        require(report['versions'][0]['generated_identity'] == report['versions'][1]['generated_identity'], 'C++ contract changed across locked versions')
        for process in report['processes']:
            self.process(process, 'cpp/' + process['stage'], expected_code=2 if process['stage'] == 'wrong-execute' else 0)
        bad = report['incompatible_signature']; require(bad['ok'] is False and bad['failure']['phase'] == 'cpp_compile', 'bad signature not compile-refused')
        failure = bad['failure']['process']; paths = report['incompatible_signature_evidence']
        require(failure['exit_code'] > 0 and failure['status'] == 'exited', 'bad signature did not fail actual compile')
        require('HEPTA_CPP_METHOD_RESULT:hepta_cpp_json_upgrade_Document_sum' in failure['stdout'] + failure['stderr'], 'expected negative diagnostic absent')
        for stream in ('stdout', 'stderr'):
            name = self.map_path(paths[stream]); require(name is not None, 'negative raw stream absent')
            raw = self.read(name)
            require(digest(raw) == failure[stream + '_raw_sha256'] and len(raw) == failure[stream + '_raw_bytes'], 'negative diagnostic digest/length differs')
            require(base64.b64decode(failure[stream + '_raw_base64'], validate=True) == raw, 'negative diagnostic raw/base64 differs')
        wrong = report['wrong_code']; require(wrong['status'] == 'rejected' and wrong['process']['exit_code'] == 2, 'wrong code was not rejected')
        self.executable(self.map_path(wrong['process']['argv'][0]), wrong['artifact'], host, 'cpp/wrong_code_executable')
        self.references(report, 'cpp')
        original_audit = self.report('cpp-upstream-host/audit.json')
        require(original_audit['status'] == 'passed' and original_audit['versions'] == 2 and original_audit['cases_per_version'] == 98, 'original hosted C++ audit not passed')
        require(all(c['rejected'] is True for c in original_audit['negative_evidence_controls']), 'original evidence negative control failed')
        return dict(kind='actual_host_cpp_upstream_reuse', host=host, cxx_driver=report['cxx']['driver'], versions=versions,
                    original_hosted_evidence_negative_controls=len(original_audit['negative_evidence_controls']),
                    limitations=['Remote compiler/sysroot binaries are not retained in these ZIPs and were not independently rehashed here.',
                                 'This audit rechecks original retained native observations and bytes; it does not execute native programs or claim general foreign lifetime safety.'])

    def sourceapp(self):
        safety = self.report('safety.json')
        require(safety['status'] == 'passed' and safety['source_stable'] is True and safety['source_before'] == safety['source_after'], 'safety qualification failed/changed')
        self.source(safety['source_before'], 'safety/source_before'); self.source(safety['source_after'], 'safety/source_after')
        for key in ('head_before', 'head_after'):
            require(safety[key]['returncode'] == 0 and safety[key]['stdout'].strip() == HEAD, 'safety head differs')
        require(safety['expected_tests'] == safety['tests_run'] == len(safety['tests']) == 95, 'safety method denominator differs')
        require(all(row['status'] == 'passed' for row in safety['tests'].values()), 'safety method failed/skipped')
        require(safety['contract'] == json.loads(BLOBS['docs/HIA_SAFETY_CONTRACT.json']), 'safety contract bytes differ')
        require(digest(canonical(safety['contract'])) == safety['contract_sha256'] == safety['reviewed_contract_sha256'], 'safety contract digest differs')
        regression = self.report('regression.json')
        require(regression == {'tests': 183, 'failures': 0, 'errors': 0, 'skipped': 0}, 'source/app regression result differs')
        fc = self.report('filecheck/qualification.json')
        require(fc['ok'] is True and fc['prepare_only'] is True and fc['status'] == 'prepared_not_measured' and fc['samples'] == [], 'filecheck was not successful prepare-only')
        require(fc['git'] == HEAD and fc['git_status'] == '' and fc['source_files_tracked'] is True, 'filecheck source identity differs')
        self.source(fc['source_bindings'], 'filecheck/source_bindings')
        require(fc['protocol_sha256'] == SOURCE_HASHES['experiments/hia_filecheck/PROTOCOL_20261028.json'], 'filecheck protocol differs')
        require(fc['linker_driver']['unchanged'] is True, 'linker identity drifted')
        require(fc['differential']['cases'] == 96 and fc['differential']['native_calls'] == 768 and fc['differential']['routes'] == 8, 'filecheck differential denominator differs')
        require(len(fc['resource_cases']) == 48 and len(fc['maintenance']['cases']) == 4 and len(fc['maintenance']['application']) == 2, 'filecheck resource/maintenance denominator differs')
        for label in ('artifacts', 'inputs'):
            for key, row in fc[label].items():
                self.ref(row['path'], row['sha256'], row['bytes'], where='filecheck/' + label + '/' + key)
        for key in ('process_ledger', 'native_validation_context'):
            row = fc[key]; self.ref(row['path'], row['sha256'], row['bytes'], where='filecheck/' + key)
        row = fc['differential']['ledger']; self.ref(row['path'], row['sha256'], row['bytes'], where='filecheck/differential/ledger')
        self.references(fc, 'filecheck')
        controls = self.report('agent-controls/CONTROLS.json')
        require(controls['count'] == controls['passed'] == len(controls['rows']) == 35 and controls['model_requests'] == 0, 'factorial controls denominator differs')
        require(all(row['passed'] is True and row['model_answer'] is False for row in controls['rows']), 'factorial control failed/model mislabeled')
        self.references(controls, 'agent-controls')
        return dict(kind='six_outcomes_source_application', safety=dict(tests=95, failures=0, skips=0, capabilities=len(safety['capabilities'])),
                    regression=regression, filecheck=dict(status='prepared_not_measured', differential_calls=768, routes=8,
                    resource_cases=48, maintenance_cases=4, maintenance_applications=2, samples=0),
                    agent_controls=dict(passed=35, model_requests=0),
                    limitations=['Prepare-only filecheck is not a current throughput/tail-latency qualification.',
                                 '35 deterministic controls with zero model requests do not establish independent real-task agent efficiency.',
                                 'The full release workflow is a separate run and is not implied by these results.'])

    def ndu(self):
        prefix = 'Hepta/Hepta/artifacts/verified-optimization/'
        result = self.report(prefix + 'ndu-loop/RESULT.json')
        require(all(result[k] is True for k in ('all_actual_budgets_passed', 'all_actual_outputs_correct', 'all_episodes_completed')), 'NDU loop actual outputs/budgets not passed')
        require(result['authority'] == 'DENY_ALL' and result['safety_from_ndu_claim'] is False and result['statistical_superiority_established'] is False, 'NDU authority/performance scope differs')
        identity = self.report(prefix + 'ndu-loop/SOURCE_IDENTITY.json')
        require(identity == result['source_identity'], 'NDU source maps differ')
        self.source(identity, 'ndu-loop/source_identity')
        require(len(result['episodes']) == 30, 'NDU episode denominator differs')
        loop = prefix + 'ndu-loop/'
        require(digest(canonical(json.loads(self.read(loop + 'PROTOCOL.json')))) == result['protocol_sha256'], 'NDU protocol binding differs')
        bank = json.loads(self.read(loop + 'BANK.json'))
        require(bank['bank_sha256'] == result['bank_sha256'], 'NDU bank/result differs')
        require(digest(canonical({k: v for k, v in bank.items() if k != 'bank_sha256'})) == bank['bank_sha256'], 'NDU bank content digest differs')
        self.bound(loop + 'driver', result['driver']['sha256'], where='ndu-loop/driver')
        self.bound(loop + 'driver.c', result['driver']['source_sha256'], where='ndu-loop/driver_source')
        for episode in result['episodes']:
            name = loop + f"episode-{episode['group']}-{episode['n']}-{episode['arm']}/EPISODE.json"
            require(json.loads(self.read(name)) == episode, 'NDU episode original/aggregate differs')
            require(episode['status'] == 'completed' and episode['actual_budget_passed'] is True and episode['completion_admitted'] is True,
                    'NDU actual episode did not complete within budget')
        build = self.report(prefix + 'ndu-loop/NATIVE_BUILD_IDENTITY.json')
        require(build['identity'] == result['native_identity'] and build['binary_sha256'] == result['native_binary_sha256'], 'NDU result/build identity differs')
        native_receipts = []
        workflow = BLOBS['.github/workflows/hepta-verified-optimization.yml'].decode()
        source_pins = {name: re.search(r'^\s+' + name + r'_NDU_SOURCE_SHA: ([a-f0-9]{40})\s*$', workflow, re.M).group(1)
                       for name in ('RECURSIVE', 'FINITE', 'STREAM')}
        for name in ('_temp/hia-recursive-ndu/identity.json', '_temp/hia-finite-ndu/identity.json', '_temp/hia-stream-ndu/identity.json'):
            item = self.report(name)
            require(item['authority'] == 'DENY_ALL' and item['safety_certificate'] is False, 'NDU bridge authority changed')
            require(item['build_tools']['builder_sha256'] == SOURCE_HASHES['tools/build_hia_recursive_ndu_bridge.py'],
                    'current Hepta NDU builder differs from public Git blob')
            admission = item['source_admission']
            require(admission['before'] == admission['after'], 'external NDU source admission changed')
            require(admission['before']['all_declared_inputs_match_pinned_blobs'] is True and admission['before']['status_porcelain'] == '', 'external source admission not pinned/clean')
            kind = name.split('/')[1].split('-')[1].upper()
            require(admission['before']['head'] == item['identity']['source_commit'] == source_pins[kind], 'external NDU source differs from its separately locked workflow pin')
            declared = admission['before']['input_git_blob_sha256']
            require(all(declared.get(k) == v for k, v in item['native_sources'].items()), 'external recorded native sources differ from pinned admission map')
            require(all(declared.get(k) == v for k, v in item['bridge_sources'].items()), 'external recorded bridge sources differ from pinned admission map')
            require(set(declared) == set(item['native_sources']) | set(item['bridge_sources']), 'external declared source denominator differs')
            self.ref(item['binary'], item['binary_sha256'], where=name + '/binary')
            require(item['compiled_binary_sha256'] == item['binary_sha256'], 'compiled/admitted NDU binary differ')
            command = item['command_evidence']
            base = str(PurePosixPath(name).parent) + '/'
            command_file = base + command['path']
            self.bound(command_file, command['sha256'], where=name + '/command_evidence')
            commands = json.loads(self.read(command_file))
            require(len(commands) == 11, 'NDU original command denominator differs')
            for index, row in enumerate(commands, 1):
                require(row['returncode'] == 0 and row['launch_error'] is None, 'NDU original build command failed')
                require(json.loads(self.read(base + f'commands/{index:03d}.json')) == row, 'NDU command aggregate/original differs')
                for stream in ('stdout', 'stderr'):
                    record = row[stream]
                    self.bound(base + record['path'], record['sha256'], record['bytes'], where=name + f'/command-{index}/{stream}')
            self.references(item, name, base=base)
            native_receipts.append(dict(name=name, source_commit=item['identity']['source_commit'],
                                        native_source_files=len(item['native_sources']), bridge_source_files=len(item['bridge_sources']),
                                        binary_sha256=item['binary_sha256']))
        ranking = self.report('_temp/hepta-ranking-ndu-build/build-receipt.json')
        require(ranking['upstream'] == json.loads(BLOBS['rust/hia-ndu-bridge/upstream.json']), 'ranking upstream pin differs')
        require(ranking['builder_sha256'] == SOURCE_HASHES['tools/build_hia_ndu_bridge.py'], 'current ranking builder differs')
        require(ranking['production_activation'] is False and ranking['original_rust_sources_unchanged'] is True
                and ranking['all_original_non_manifest_inputs_unchanged'] is True and ranking['build_inputs_unchanged'] is True,
                'ranking source/activation receipt differs')
        self.source(ranking['adapter_files'], 'ranking/adapter_files', 'rust/hia-ndu-bridge/')
        self.ref(ranking['binary'], ranking['binary_sha256'], where='ranking/binary')
        self.references(result, 'ndu-loop')
        regression = self.report(prefix + 'regression/result.json')
        require(regression['passed'] is True and regression['tests'] == 595 and regression['errors'] == regression['failures'] == 0 and regression['skipped'] == [], 'NDU regression result differs')
        require(regression['git_base'] == HEAD and regression['source_unchanged'] is True, 'NDU regression source differs')
        self.source(regression['source_sha256'], 'ndu-regression/source_sha256')
        subreports = {}
        for key in ('adaptive', 'cpp-composed-project', 'cpp-scoped', 'owned-state'):
            value = self.report(prefix + key + '/qualification.json'); require(value['ok'] is True, key + ' failed')
            if 'source_bindings' in value:
                self.source(value['source_bindings'], key + '/source_bindings')
                require(value['source_bindings_unchanged'] is True, key + ' source changed')
            if 'compiler_sha256' in value:
                require(value['compiler_sha256'] == COMPILER_SHA, key + ' compiler digest differs')
            if key == 'adaptive':
                require(all(v is True for v in value['controls'].values()), 'adaptive negative control failed')
                for label, snapshot in value['retained_native_artifacts'].items():
                    name = prefix + key + '/' + snapshot['path']
                    token = snapshot['image_token']; admitted = value['admitted_native_images'][token]
                    require(snapshot['origin'] == 'actual sealed descriptor before tamper controls'
                            and snapshot['sha256'] == admitted['artifact_sha256']
                            and snapshot['loaded_mapping'] == admitted['loaded_mapping'], 'adaptive snapshot/admission binding differs')
                    self.bound(name, snapshot['sha256'], snapshot['bytes'], where='adaptive/retained_native_artifacts/' + label)
                candidate = value['retained_native_artifacts']['candidate']
                original = value['builds'][candidate['image_token']]['native']
                original_member = self.map_path(original['output'])
                require(original['artifact_sha256'] == candidate['sha256'] and original['artifact_bytes'] == candidate['bytes'],
                        'adaptive original build and sealed snapshot differ')
                tampered = b'not the loaded artifact'
                require(self.read(original_member) == tampered, 'adaptive declared after-load tamper bytes differ')
                self.bound(original_member, digest(tampered), len(tampered), where='adaptive/declared_after_load_negative_tamper')
                retained_original = prefix + key + '/' + candidate['path']
                self.declared_path_mutations[original_member] = dict(original_sha256=candidate['sha256'],
                    retained_original_member=retained_original, final_path_sha256=digest(tampered),
                    final_path_bytes=len(tampered), reason='producer deliberately overwrote publication path after sealed-descriptor admission',
                    qualifier_source_sha256=SOURCE_HASHES['tools/qualify_hia_adaptive.py'])
                require(self.read(prefix + key + '/changed.so') == self.read(retained_original) + b'changed',
                        'adaptive before-load negative tamper bytes differ')
            if key == 'owned-state':
                for label, snapshot in value['native_snapshots'].items():
                    self.bound(prefix + key + '/native-snapshots/' + label + '.so', snapshot['sha256'], snapshot['bytes'],
                               where='owned-state/native_snapshots/' + label)
            self.references(value, key, base=prefix + key + '/')
            subreports[key] = dict(ok=True, status=value.get('status'))
        guarded = self.report(prefix + 'guarded-cli/result.json')
        require(guarded['passed'] is True and guarded['timeout_never_published'] is True, 'guarded CLI failed')
        require(guarded['qualifier_sha256'] == SOURCE_HASHES['experiments/hia_verified_integration/next_20261028/qualify_guarded_cli.py'], 'guarded CLI source differs')
        self.references(guarded, 'guarded-cli')
        return dict(kind='verified_optimization_ndu', authority='DENY_ALL', episodes=30, regression_tests=595,
                    native_receipts=native_receipts, ranking_upstream=ranking['upstream'], subreports=subreports,
                    limitations=['Recursive, finite, stream, and ranking upstream sources keep four separate workflow/adapter pins; none is relabeled as Hepta 699de39.',
                                 'The original external admission maps and retained binaries are checked; external upstream raw source blobs were not independently reacquired in this audit.',
                                 'No general speedup, statistical superiority, safety from NDU, or production authority switch is established.'])

    def run(self):
        name = self.artifact['name']
        if 'cpp-upstream' in name:
            details = self.cpp()
        elif name.startswith('native-'):
            details = self.abi()
        elif 'six-outcomes' in name:
            details = self.sourceapp()
        elif 'verified-optimization' in name:
            details = self.ndu()
        else:
            raise ValueError('unknown artifact family: ' + name)
        return dict(schema='hepta.current-hosted-artifact-content-audit.v1', status='passed_with_explicit_scope_limits',
                    artifact_id=self.artifact['id'], run_id=self.run_id, source=HEAD, source_tree=TREE,
                    official_archive=dict(bytes=self.path.stat().st_size, sha256=digest(self.path.read_bytes()), crc32_all_members_valid=True),
                    retained_members=self.files, source_maps=self.source_checks, checked_content_bindings=self.content_checks,
                    declared_negative_path_mutations=self.declared_path_mutations,
                    unretained_reference_paths=self.unretained, selected_raw_reports=self.report_names, details=details,
                    native_programs_executed=0, test_suites_executed=0, workflows_triggered=0)


def main():
    entries = []
    for file in sorted(ROOT.glob('artifacts-*-snapshot-03.json')):
        run_id = int(file.name.split('-')[1])
        for artifact in json.loads(file.read_text())['artifacts']:
            entries.append((artifact, run_id))
    results = []
    for artifact, run_id in entries:
        try:
            audit = Audit(artifact, run_id)
            result = audit.run()
        except Exception as exc:
            result = dict(status='failed_audit', artifact_id=artifact['id'], run_id=run_id,
                          error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        dump(ROOT / 'content-audits' / f'{artifact["id"]}.json', result)
        row = dict(artifact_id=artifact['id'], run_id=run_id, status=result['status'],
                   source_maps=len(result.get('source_maps', [])), checked_files=len(result.get('checked_content_bindings', {})),
                   error=result.get('error'))
        print(json.dumps(row), flush=True); results.append(row)
    dump(ROOT / 'source-git-blob-hashes.json', dict(source=HEAD, tree=TREE, compiler_sha256=COMPILER_SHA, files=SOURCE_HASHES))
    dump(ROOT / 'content-audit-index.json', dict(source=HEAD, observed_snapshot='03',
         completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), artifacts=results))
    return 0 if all(r['status'] == 'passed_with_explicit_scope_limits' for r in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
