#!/usr/bin/env python3
"""Credential-pattern scan of public candidates and decoded official ZIP members.

Private connector transport references live outside this directory and are never
read by this scanner. Findings contain only locations and pattern names.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
PATTERNS = {
    'github_fine_grained_token': rb'github_pat_[A-Za-z0-9_]{50,}',
    'github_classic_or_app_token': rb'gh[pousr]_[A-Za-z0-9]{30,}',
    'openai_secret_key': rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}',
    'aws_access_key': rb'(?:AKIA|ASIA)[A-Z0-9]{16}',
    'private_key_header': rb'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----',
    'slack_token': rb'xox[baprs]-[A-Za-z0-9-]{20,}',
    'google_api_key': rb'AIza[0-9A-Za-z_-]{35}',
    'gitlab_access_token': rb'glpat-[A-Za-z0-9_-]{20,}',
    'sendgrid_api_key': rb'SG\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}',
    'signed_download_url': rb'https?://[^\s"<>]+(?:[?&](?:sig|X-Amz-Signature|Signature)=)[^\s"<>]+',
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='credential-scan.json')
    args = parser.parse_args()
    findings, files, decoded = [], [], []

    def scan(data, where):
        for label, pattern in PATTERNS.items():
            for match in re.finditer(pattern, data):
                findings.append(dict(path=where, pattern=label, byte_offset=match.start(), length=len(match.group())))

    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.name == args.output or path.suffix in ('.gz', '.pyc'):
            continue
        relative = str(path.relative_to(ROOT))
        assert 'private' not in path.name.lower() or path.name == 'scan_public_files.py'
        data = path.read_bytes(); scan(data, relative)
        files.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
        if path.parent.name == 'raw-artifacts' and path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                for info in archive.infolist():
                    payload = archive.read(info)
                    scan(payload, relative + '!' + info.filename)
                    decoded.append(dict(path=relative + '!' + info.filename, bytes=len(payload),
                                        sha256=hashlib.sha256(payload).hexdigest()))
    result = dict(schema='hepta.current-ci-credential-scan.v1', pattern_count=len(PATTERNS), patterns=list(PATTERNS),
                  files_scanned=len(files), file_bytes_scanned=sum(x['bytes'] for x in files),
                  zip_members_scanned=len(decoded), decoded_zip_bytes_scanned=sum(x['bytes'] for x in decoded),
                  findings=findings, secret_values_printed=False, private_transport_references_read=False,
                  file_inventory_sha256=hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(),
                  decoded_inventory_sha256=hashlib.sha256(json.dumps(decoded, sort_keys=True).encode()).hexdigest())
    (ROOT / args.output).write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if not findings else 1


if __name__ == '__main__':
    raise SystemExit(main())
