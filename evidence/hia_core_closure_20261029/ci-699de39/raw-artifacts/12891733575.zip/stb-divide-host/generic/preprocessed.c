
extern int stb_div_trunc(int value_to_be_divided, int value_to_divide_by);
extern int stb_div_floor(int value_to_be_divided, int value_to_divide_by);
extern int stb_div_eucl (int value_to_be_divided, int value_to_divide_by);
extern int stb_mod_trunc(int value_to_be_divided, int value_to_divide_by);
extern int stb_mod_floor(int value_to_be_divided, int value_to_divide_by);
extern int stb_mod_eucl (int value_to_be_divided, int value_to_divide_by);
int stb_div_trunc(int v1, int v2)
{
   if (v1 >= 0 && v2 <= 0)
      return -((-v1)/(v2));
   if (v1 <= 0 && v2 >= 0)
      if (v1 != (-2147483647 -1))
         return -((v1)/(-v2));
      else
         return -((v1+v2)/(-v2))-1;
   else
      return v1/v2;
}
int stb_div_floor(int v1, int v2)
{
   if (v1 >= 0 && v2 < 0) {
      if (v2 + 1 >= (-2147483647 -1) + v1)
         return -(((v2+1)-v1)/(v2));
      else
         return -((-v1)/(v2)) + ((-v1)%v2 ? -1 : 0);
   }
   if (v1 < 0 && v2 >= 0) {
      if (v1 != (-2147483647 -1)) {
         if (v1 + 1 >= (-2147483647 -1) + v2)
            return -(((v1+1)-v2)/(-v2));
         else
            return -((-v1)/(v2)) + (((v1)%(-v2)) ? -1 : 0);
      } else
         return -((-(v1+v2))/(v2)) + (((-(v1+v2))%(v2)) ? -2 : -1);
   } else
      return v1/v2;
}
int stb_div_eucl(int v1, int v2)
{
   int q,r;
   if (v1 >= 0)
      if (v2 >= 0)
         return ((v1)/(v2));
      else if (v2 != (-2147483647 -1))
         q = -((v1)/(-v2)), r = ((v1)%(-v2));
      else
         q = 0, r = v1;
   else if (v1 != (-2147483647 -1))
      if (v2 >= 0)
         q = -((-v1)/(v2)), r = -((-v1)%(v2));
      else if (v2 != (-2147483647 -1))
         q = ((-v1)/(-v2)), r = -((-v1)%(-v2));
      else
         q = 1, r = v1-q*v2;
   else
      if (v2 >= 0)
         q = -((-(v1+v2))/(v2))-1, r = -((-(v1+v2))%(v2));
      else if (v2 != (-2147483647 -1))
         q = ((-(v1-v2))/(-v2))+1, r = -((-(v1-v2))%(-v2));
      else
         q = 1, r = 0;
   if (r >= 0)
      return q;
   else
      return q + (v2 > 0 ? -1 : 1);
}
int stb_mod_trunc(int v1, int v2)
{
   if (v1 >= 0) {
      int r = ((v1)%(v2));
      if (r >= 0)
         return r;
      else
         return r - (v2 < 0 ? v2 : -v2);
   } else {
      int r = ((v1)%(v2));
      if (r <= 0)
         return r;
      else
         return r + (v2 < 0 ? v2 : -v2);
   }
}
int stb_mod_floor(int v1, int v2)
{
   if (v2 >= 0) {
      int r = ((v1)%(v2));
      if (r >= 0)
         return r;
      else
         return r + v2;
   } else {
      int r = ((v1)%(v2));
      if (r <= 0)
         return r;
      else
         return r + v2;
   }
}
int stb_mod_eucl(int v1, int v2)
{
   int r = ((v1)%(v2));
   if (r >= 0)
      return r;
   else
      return r - (v2 < 0 ? v2 : -v2);
}

