
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#ifdef _WIN32
#include <windows.h>
typedef HMODULE Library;
static Library open_library(const char *path) { return LoadLibraryA(path); }
#else
#include <dlfcn.h>
#include <sys/resource.h>
typedef void *Library;
static Library open_library(const char *path) { return dlopen(path,RTLD_NOW|RTLD_LOCAL); }
#endif
#define STB_DIVIDE_IMPLEMENTATION
#include "stb_divide.h"
_Static_assert(sizeof(int)==4 && INT_MIN==(-2147483647-1) && INT_MAX==2147483647,"int32 ABI required");
_Static_assert(sizeof(unsigned long long)==8,"counter ABI required");
typedef int (*Function)(int,int);
typedef unsigned long long (*Counter)(int);
static const char *names[6]={"stb_div_trunc","stb_div_floor","stb_div_eucl","stb_mod_trunc","stb_mod_floor","stb_mod_eucl"};
static Function originals[6]={stb_div_trunc,stb_div_floor,stb_div_eucl,stb_mod_trunc,stb_mod_floor,stb_mod_eucl};
static int symbol(Library lib,const char *name,void *destination,size_t size) {
#ifdef _WIN32
    FARPROC pointer=GetProcAddress(lib,name);
#else
    void *pointer=dlsym(lib,name);
#endif
    if(!pointer || size!=sizeof(pointer)) return 0;
    memcpy(destination,&pointer,size); return 1;
}
int main(int argc,char **argv) {
    Library lib; Function functions[6]; Counter count=NULL;
    int i,a,b,expected[6],original[6],actual[6],read_count;
    unsigned long long before[4]={0,0,0,0},after[4]={0,0,0,0},cases=0;
    FILE *input,*output;
    if(argc<3)return 10;
#ifndef _WIN32
    {struct rlimit limit={0,0}; if(setrlimit(RLIMIT_CORE,&limit)!=0)return 19;}
#else
    SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOGPFAULTERRORBOX);
#endif
    lib=open_library(argv[1]); if(!lib)return 11;
    for(i=0;i<6;i++)if(!symbol(lib,names[i],&functions[i],sizeof(functions[i])))return 12;
    if(strcmp(argv[2],"--trap")==0) {
        int result,index;
        if(argc!=6)return 13;
        index=atoi(argv[3]); if(index<0||index>=6)return 14;
        a=(int)strtol(argv[4],NULL,10);b=(int)strtol(argv[5],NULL,10);
        puts("ENTERED_SAFE_TARGET");fflush(stdout);
        result=functions[index](a,b);
        printf("UNEXPECTED_RETURN %d\n",result);return 99;
    }
    if(argc!=4)return 15;
    (void)symbol(lib,"stb_migration_resource_count",&count,sizeof(count));
    if(count)for(i=0;i<4;i++)before[i]=count(i);
    input=fopen(argv[2],"r");output=fopen(argv[3],"w");if(!input||!output)return 16;
    while((read_count=fscanf(input,"%d%d%d%d%d%d%d%d",&a,&b,&expected[0],&expected[1],&expected[2],&expected[3],&expected[4],&expected[5]))==8) {
        if(b==0 || (a==INT_MIN && b==-1))return 17;
        for(i=0;i<6;i++){original[i]=originals[i](a,b);actual[i]=functions[i](a,b);}
        fprintf(output,"%d\t%d",a,b);
        for(i=0;i<6;i++)fprintf(output,"\t%d",expected[i]);
        for(i=0;i<6;i++)fprintf(output,"\t%d",original[i]);
        for(i=0;i<6;i++)fprintf(output,"\t%d",actual[i]);
        fputc('\n',output);cases++;
        for(i=0;i<6;i++)if(original[i]!=expected[i]||actual[i]!=expected[i]) {
            fprintf(stderr,"functional mismatch case %llu function %s expected %d original %d target %d\n",cases,names[i],expected[i],original[i],actual[i]);
            fclose(input);fclose(output);return 2;
        }
        if(count)for(i=0;i<4;i++)if(count(i)!=before[i])return 3;
    }
    if(read_count!=EOF)return 18;
    fclose(input);fclose(output);
    if(count)for(i=0;i<4;i++)after[i]=count(i);
    printf("{\"cases\":%llu,\"native_function_observations\":%llu,\"allocation_probe\":%s",cases,cases*12,count?"true":"false");
    if(count)printf(",\"resource_before\":[%llu,%llu,%llu,%llu],\"resource_after\":[%llu,%llu,%llu,%llu]}",before[0],before[1],before[2],before[3],after[0],after[1],after[2],after[3]);
    else printf(",\"resource_before\":null,\"resource_after\":null}");
    putchar('\n');
    return 0;
}
