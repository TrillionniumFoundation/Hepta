// Generated caller-unsafe C ABI bridge. NOT a proof of foreign pointer validity.

// SAFETY: nonempty buffers must be initialized, aligned, live within one allocation,

// stable throughout the call; a mutable slice additionally requires exclusive access.

// These are caller-supplied contracts and may narrow the original C input domain.

#[export_name = "stb_div_eucl"]
pub unsafe extern "C" fn __hepta_c_export_0(b_v1: i32, b_v2: i32) -> i32 {
    h_c_stb_div_eucl(b_v1, b_v2)
}

#[export_name = "stb_div_floor"]
pub unsafe extern "C" fn __hepta_c_export_1(b_v1: i32, b_v2: i32) -> i32 {
    h_c_stb_div_floor(b_v1, b_v2)
}

#[export_name = "stb_div_trunc"]
pub unsafe extern "C" fn __hepta_c_export_2(b_v1: i32, b_v2: i32) -> i32 {
    h_c_stb_div_trunc(b_v1, b_v2)
}

#[export_name = "stb_mod_eucl"]
pub unsafe extern "C" fn __hepta_c_export_3(b_v1: i32, b_v2: i32) -> i32 {
    h_c_stb_mod_eucl(b_v1, b_v2)
}

#[export_name = "stb_mod_floor"]
pub unsafe extern "C" fn __hepta_c_export_4(b_v1: i32, b_v2: i32) -> i32 {
    h_c_stb_mod_floor(b_v1, b_v2)
}

#[export_name = "stb_mod_trunc"]
pub unsafe extern "C" fn __hepta_c_export_5(b_v1: i32, b_v2: i32) -> i32 {
    h_c_stb_mod_trunc(b_v1, b_v2)
}
