#define STB_DIVIDE_IMPLEMENTATION
#include "stb_divide.h"
int unsupported_path(int c){int x;if(c)x=1;return x;}
