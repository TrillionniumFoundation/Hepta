unsigned int probe(unsigned int n, const unsigned int data[8]) { return n; }
