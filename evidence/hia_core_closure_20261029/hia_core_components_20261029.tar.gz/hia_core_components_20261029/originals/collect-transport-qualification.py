from __future__ import annotations

from collections import Counter
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/b484d4086829/hepta-transport')
OUT = Path('/workspace/scratch/b484d4086829/transport-qualification-2c8785a')
OUT.mkdir(exist_ok=True)
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from hepta import hia_rust_crosscheck as transport
from tests.test_hia_rust_transport_lifecycle import RustShadowTransportLifecycle


def command(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


head = command('git', 'rev-parse', 'HEAD')
before_status = command('git', 'status', '--porcelain')
assert head == '2c8785a506faacaece51612c88beea893faf5490'
assert not before_status
paths = ['hepta/hia_rust_crosscheck.py', 'tests/test_hia_rust_transport_lifecycle.py',
         'docs/HIA_RUST_SHADOW_PROCESS_OWNERSHIP.md', 'rust/hia-core-shadow/src/main.rs',
         'rust/hia-core-shadow/Cargo.lock']
source_hashes = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in paths}
lifecycle_rows, transport_rows = [], []
original_observe = RustShadowTransportLifecycle.observe
original_run = transport._run_bounded_shadow


def observe(self, mode, **options):
    result = original_observe(self, mode, **options)
    lifecycle_rows.append({'test': self.id(), 'mode': mode, 'options': options, **result})
    return result


def run(cmd, payload, timeout, maximum_output=transport.MAX_OUTPUT_BYTES):
    raw = Path(cmd[0]).read_bytes()
    row = {'arguments': cmd[1:], 'binary_sha256': sha256(raw).hexdigest(),
           'actual_elf_executable': raw.startswith(b'\x7fELF'),
           'payload_sha256': sha256(payload).hexdigest(),
           'payload_bytes': len(payload), 'timeout_seconds': timeout,
           'maximum_output_bytes': maximum_output}
    started = time.monotonic()
    try:
        stdout, stderr, returncode = original_run(cmd, payload, timeout,
                                                 maximum_output=maximum_output)
        row.update(returncode=returncode, stdout_bytes=len(stdout), stderr_bytes=len(stderr),
                   stdout_sha256=sha256(stdout).hexdigest(), stderr_sha256=sha256(stderr).hexdigest())
        if row['actual_elf_executable'] and returncode == 0:
            row['actual_rust_report'] = json.loads(stdout)
        return stdout, stderr, returncode
    except Exception as error:
        row.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        row['elapsed_seconds'] = time.monotonic() - started
        transport_rows.append(row)


modules = ['tests.test_hia_rust_transport_lifecycle', 'tests.test_hia_rust_crosscheck',
           'tests.test_hia_rust_execution_crosscheck', 'tests.test_hia_rust_crosscheck_cli']
suite = unittest.defaultTestLoader.loadTestsFromNames(modules)
started = time.monotonic()
with (OUT / 'unittest.log').open('w') as log:
    with patch.object(RustShadowTransportLifecycle, 'observe', observe), \
            patch.object(transport, '_run_bounded_shadow', run):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
elapsed = time.monotonic() - started
after_head = command('git', 'rev-parse', 'HEAD')
after_status = command('git', 'status', '--porcelain')
assert after_head == head and not after_status
assert source_hashes == {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in paths}
elf_rows = [row for row in transport_rows if row['actual_elf_executable']]
summary = {
    'schema': 'hepta.rust-shadow-process-ownership.qualification.v1',
    'head': head, 'branch': command('git', 'branch', '--show-current'),
    'checkout': str(ROOT), 'source_hashes': source_hashes,
    'source_clean_before_and_after': not before_status and not after_status,
    'head_unchanged': head == after_head, 'test_modules': modules,
    'tests_run': result.testsRun, 'failures': len(result.failures),
    'errors': len(result.errors), 'skips': len(result.skipped),
    'passed': result.wasSuccessful() and not result.skipped,
    'elapsed_seconds': elapsed,
    'real_lifecycle_observations': len(lifecycle_rows),
    'lifecycle_descendants_survived': sum(row['descendant_survived'] for row in lifecycle_rows),
    'lifecycle_one_signal_and_reaped': all(len(row['signals']) == 1 and row['leader_reaped']
                                          for row in lifecycle_rows),
    'actual_rust_transport_invocations': len(elf_rows),
    'actual_rust_modes': dict(Counter(row['arguments'][0] if row['arguments'] else 'scalar'
                                     for row in elf_rows)),
    'actual_rust_binary_sha256': sorted({row['binary_sha256'] for row in elf_rows}),
    'python': sys.version, 'rustc': command('rustc', '--version'),
    'cargo': command('cargo', '--version'),
    'cargo_target_dir': os.environ['CARGO_TARGET_DIR'],
    'pre_fix_log': 'before.log',
    'claims': {'ordinary_owned_process_group_checked': True,
               'hostile_binary_containment': False, 'whole_project_blockers_closed': False},
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
(OUT / 'lifecycle-observations.json').write_text(json.dumps(lifecycle_rows, indent=2, sort_keys=True) + '\n')
(OUT / 'transport-observations.json').write_text(json.dumps(transport_rows, indent=2, sort_keys=True) + '\n')
shutil.copyfile('/workspace/scratch/b484d4086829/transport-lifecycle-before.log', OUT / 'before.log')
shutil.copyfile(__file__, OUT / 'collector.py')
manifest = {str(path.relative_to(OUT)): sha256(path.read_bytes()).hexdigest()
            for path in sorted(OUT.iterdir()) if path.is_file() and path.name != 'sha256.json'}
(OUT / 'sha256.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary, indent=2, sort_keys=True))
sys.exit(0 if summary['passed'] else 1)
