"""Small independent negative controls; does not run integrated qualification."""
from pathlib import Path
from hashlib import sha256
from types import SimpleNamespace
import copy
import importlib.util
import io
import json
import subprocess
import sys
import tarfile
import tempfile

BASE = Path('/workspace/scratch/b484d4086829')
ROOT = BASE / 'hepta-live'
sys.path.insert(0, str(ROOT))
from tools import qualify_hia_integrated as q

def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.PIPE)

def result(call):
    try:
        return {'accepted': True, 'value': call()}
    except Exception as exc:
        return {'accepted': False, 'error_type': type(exc).__name__, 'error': str(exc)}

files = ['tools/qualify_hia_integrated.py', 'tests/test_hia_integrated_inputs.py']
before = {name: digest(ROOT / name) for name in files}
report = {
    'scope': 'Exact declared Git source blobs and registered native inputs only; not transitive toolchain closure, remote attestation, or Core semantics proof.',
    'head': git(ROOT, 'rev-parse', 'HEAD').decode().strip(),
    'status': git(ROOT, 'status', '--porcelain').decode(),
    'source_sha256': before,
    'original_replacement_failure': json.loads((BASE / 'integrated-git-replacement-review.json').read_text()),
    'controls': {},
}
controls = report['controls']
with tempfile.TemporaryDirectory(prefix='hepta-independent-git-input-') as tmp:
    root = Path(tmp)
    git(root, 'init', '--quiet')
    git(root, 'config', 'user.name', 'Independent audit fixture')
    git(root, 'config', 'user.email', 'audit@example.invalid')
    source = root / 'source.rs'
    source.write_bytes(b'// $Format:%H$\nfn original() {}\n')
    (root / '.gitattributes').write_text('source.rs export-subst\n')
    git(root, 'add', '.')
    git(root, 'commit', '--quiet', '-m', 'original')
    original_commit = git(root, 'rev-parse', 'HEAD').decode().strip()
    original_blob = git(root, 'rev-parse', 'HEAD:source.rs').decode().strip()
    original = {'source.rs': digest(source)}
    with tarfile.open(fileobj=io.BytesIO(git(root, 'archive', '--format=tar', original_commit, 'source.rs'))) as archive:
        archived = archive.extractfile('source.rs').read()
    controls['export_subst'] = {
        'archive_bytes_differ_from_raw': sha256(archived).hexdigest() != original['source.rs'],
        'raw_source': result(lambda: q._git_inventory(root, original_commit, original)),
    }
    source.write_bytes(b'fn unrelated_replacement() {}\n')
    changed = {'source.rs': digest(source)}
    git(root, 'add', 'source.rs')
    git(root, 'commit', '--quiet', '-m', 'replacement')
    changed_commit = git(root, 'rev-parse', 'HEAD').decode().strip()
    changed_blob = git(root, 'rev-parse', 'HEAD:source.rs').decode().strip()
    for name, old, new in [('commit_replacement', original_commit, changed_commit),
                           ('blob_replacement', original_blob, changed_blob)]:
        git(root, 'replace', old, new)
        try:
            controls[name] = {
                'requested_commit': original_commit,
                'replacement_object': new,
                'original_bytes': result(lambda: q._git_inventory(root, original_commit, original)),
                'replacement_bytes': result(lambda: q._git_inventory(root, original_commit, changed)),
            }
        finally:
            git(root, 'replace', '-d', old)
    (root / '.gitattributes').write_text('source.rs export-ignore\n')
    git(root, 'add', '.gitattributes')
    git(root, 'commit', '--quiet', '-m', 'archive omission')
    ignore_commit = git(root, 'rev-parse', 'HEAD').decode().strip()
    with tarfile.open(fileobj=io.BytesIO(git(root, 'archive', '--format=tar', ignore_commit))) as archive:
        archive_names = archive.getnames()
    controls['export_ignore'] = {
        'archive_omits_source': 'source.rs' not in archive_names,
        'raw_source': result(lambda: q._git_inventory(root, ignore_commit, changed)),
    }
    controls['wrong_source_bytes'] = result(lambda: q._git_inventory(root, original_commit, changed))
    controls['missing_commit_source'] = result(lambda: q._git_inventory(root, original_commit, {'missing.rs': '0' * 64}))

with tempfile.TemporaryDirectory(prefix='hepta-independent-external-input-') as tmp:
    root = Path(tmp)
    values = {}
    for name in ['ranking_bridge', 'ranking_build_receipt', 'recursive_bridge', 'recursive_identity',
                 'finite_bridge', 'finite_identity', 'stream_bridge', 'stream_identity']:
        values[name] = root / name
        values[name].write_bytes(name.encode())
    for profile in ['recursive', 'finite', 'stream']:
        values[profile + '_upstream'] = root
    options = SimpleNamespace(**values)
    native, bridge, compiler = [root / name for name in ['native.rs', 'bridge.rs', 'selected-rustc']]
    for path in [native, bridge, compiler]:
        path.write_bytes(path.name.encode())
    row = {'name': 'stream_bridge_identity', 'passed': True,
           'manifest_binary_invocation': str(options.stream_bridge),
           'binary': str(options.stream_bridge), 'binary_sha256': digest(options.stream_bridge),
           'receipt_sha256': digest(options.stream_identity),
           'native_sources': {native.name: digest(native)},
           'bridge_sources': {bridge.name: digest(bridge)},
           'build_tools': {'rustc': {'path': str(compiler), 'sha256': digest(compiler)}}}
    valid = q._external_inventory(options, [row])
    tracked = [options.stream_bridge, options.stream_identity, native, bridge, compiler]
    controls['stream_registered_inputs_present'] = all(valid[str(p)] == digest(p) for p in tracked)
    controls['stream_input_mutations'] = {}
    for path in tracked:
        raw = path.read_bytes()
        path.write_bytes(raw + b'changed')
        try:
            controls['stream_input_mutations'][path.name] = result(lambda: q._external_inventory(options, [row]))
        finally:
            path.write_bytes(raw)
    changed_row = copy.deepcopy(row)
    changed_row['manifest_binary_invocation'] = str(options.finite_bridge)
    controls['retargeted_manifest_invocation'] = result(lambda: q._external_inventory(options, [changed_row]))
    raw = native.read_bytes()
    native.unlink()
    controls['missing_declared_native_source'] = result(lambda: q._external_inventory(options, [row]))
    native.write_bytes(raw)

stream_path = BASE / 'stream-gate-development-v3/probe.json'
stream = json.loads(stream_path.read_text())
report['existing_actual_stream_probe_reviewed'] = {
    'path': str(stream_path), 'sha256': digest(stream_path),
    'passed': stream['passed'], 'source_commit': stream['identity']['source_commit'],
    'binary_sha256_matches_current_bytes': digest(stream['binary']) == stream['binary_sha256'],
    'receipt_sha256_matches_current_bytes': digest(stream['receipt']) == stream['receipt_sha256'],
    'requests': stream['session_observation']['requests'],
    'closed_after_context': stream['session_observation']['closed_after_context'],
    'independently_reexecuted': False,
}
report['expected_gate_names'] = list(q.EXPECTED_GATE_NAMES)
report['source_unchanged_during_review'] = before == {name: digest(ROOT / name) for name in files}
report['checks_passed'] = (
    all(controls[n]['original_bytes']['accepted'] and not controls[n]['replacement_bytes']['accepted']
        for n in ['commit_replacement', 'blob_replacement'])
    and controls['export_subst']['archive_bytes_differ_from_raw']
    and controls['export_subst']['raw_source']['accepted']
    and controls['export_ignore']['archive_omits_source']
    and controls['export_ignore']['raw_source']['accepted']
    and not controls['wrong_source_bytes']['accepted']
    and not controls['missing_commit_source']['accepted']
    and controls['stream_registered_inputs_present']
    and not any(item['accepted'] for item in controls['stream_input_mutations'].values())
    and not controls['retargeted_manifest_invocation']['accepted']
    and not controls['missing_declared_native_source']['accepted']
    and report['source_unchanged_during_review'])
destination = BASE / 'integrated-inputs-independent-review.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'checks_passed': report['checks_passed'], 'path': str(destination),
                  'source_sha256': report['source_sha256']}, indent=2))
if not report['checks_passed']:
    raise SystemExit(1)
