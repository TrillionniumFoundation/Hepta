"""Adversarial checks of one frozen bound-v2 binary; never builds a crate."""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys
import tempfile
from unittest.mock import patch

BASE = Path('/workspace/scratch/b484d4086829')
ROOT = BASE / 'hepta-rust'
EXE = BASE / 'target-rust-depth-v2/debug/hia-core-shadow'
EXPECTED_HEAD = 'd62b1654306f6de3aed88da003c1b94434c1b388'
EXPECTED_BINARY = '5cce99dd8f70067983cd4d2a4dacaf988df16d0ac5f194c9e07ad44daf45aae7'
sys.path.insert(0, str(ROOT))
from hepta import hia_rust_crosscheck as crosscheck
from hepta.hia_program import verify_program


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(ROOT), *args]).decode().strip()


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def policy(depth=2, steps=1000, heap=0, fail=None):
    return {'max_steps': steps, 'max_heap_bytes': heap,
            'allocation_fail_at': fail, 'max_call_depth': depth}


def scalar_module():
    parameter = {'name': 'value', 'type': 'u32'}
    identity = {'name': 'identity', 'params': [parameter], 'returns': ['u32'],
                'effects': [], 'entry': 'entry', 'blocks': [{'id': 'entry',
                'params': [parameter], 'ops': [], 'term': {'op': 'ret', 'values': ['value']}}]}
    loop = deepcopy(identity)
    loop['name'] = 'loop'
    loop['blocks'][0]['ops'] = [{'op': 'call', 'args': ['value'],
                                'out': [{'name': 'never', 'type': 'u32'}],
                                'attrs': {'function': 'loop'}}]
    loop['blocks'][0]['term']['values'] = ['never']
    return {'schema': 'hepta.hia.program.v8', 'module': 'independent_depth_review',
            'functions': [identity, loop], 'exports': ['identity', 'loop']}


def owning_recursion():
    parameter = {'name': 'size', 'type': 'usize'}
    function = {'name': 'recur_owner', 'params': [parameter], 'returns': [],
                'effects': ['alloc', 'trap'], 'entry': 'entry', 'blocks': [{
                    'id': 'entry', 'params': [parameter], 'ops': [
                        {'op': 'buffer.new', 'args': ['size'], 'out': [{'name': 'owner', 'type': 'buffer'}], 'attrs': {}},
                        {'op': 'call', 'args': ['size'], 'out': [], 'attrs': {'function': 'recur_owner'}},
                        {'op': 'owner.drop', 'args': ['owner'], 'out': [], 'attrs': {}},
                    ], 'term': {'op': 'ret', 'values': []}}]}
    return {'schema': 'hepta.hia.program.v8', 'module': 'independent_owned_depth_review',
            'functions': [function], 'exports': ['recur_owner']}


source_names = ['hepta/hia_rust_crosscheck.py', 'rust/hia-core-shadow/src/scalar_vm.rs',
                'rust/hia-core-shadow/src/main.rs', 'rust/hia-core-shadow/src/lib.rs',
                'tests/test_hia_rust_bound_depth.py', 'rust/hia-core-shadow/tests/bound_execution_v2.rs',
                'tools/qualify_hia_rust_bound_depth.py', 'docs/HIA_RUST_BOUND_DEPTH_V2.md']
before = {name: digest(ROOT / name) for name in source_names}
assert git('rev-parse', 'HEAD') == EXPECTED_HEAD and not git('status', '--porcelain')
assert digest(EXE) == EXPECTED_BINARY
report = {'scope': 'Finite strict policy decoding, actual Machine depth/ledger binding, v1 compatibility, whole-module rejection, and deliberate replay refusal. No production authority switch or complete semantics proof.',
          'source_head': EXPECTED_HEAD, 'source_sha256': before,
          'binary': {'path': str(EXE), 'sha256': EXPECTED_BINARY},
          'source_clean_before': True, 'checks': [], 'actual_processes': [],
          'fresh_crosschecks': [], 'replay_refusal_controls': [], 'programs': {}}


def check(name, passed, **details):
    report['checks'].append({'name': name, 'passed': bool(passed), **details})


def raw(label, source, entry, arguments, raw_policy=None, *, mode='--owned-run-bound-v2', extra=None):
    encoded = source if type(source) is bytes else wire(source)
    argv = [str(EXE), mode, entry, arguments]
    if raw_policy is not None:
        argv.append(raw_policy.decode() if type(raw_policy) is bytes else raw_policy)
    if extra:
        argv.extend(extra)
    completed = subprocess.run(argv, input=encoded, cwd=ROOT, capture_output=True, timeout=15)
    record = {'label': label, 'argv': argv, 'stdin_sha256': sha256(encoded).hexdigest(),
              'returncode': completed.returncode, 'stdout': completed.stdout.decode(),
              'stderr': completed.stderr.decode()}
    report['programs'][record['stdin_sha256']] = encoded.decode()
    report['actual_processes'].append(record)
    return completed


def rejects(label, source, args, raw_policy):
    observed = raw(label, source, 'identity', args, raw_policy)
    check(label, observed.returncode == 1 and observed.stdout == b''
          and observed.stderr.startswith(b'E_HIA_') and b'panicked' not in observed.stderr)


module = scalar_module()
core = verify_program(module)
valid = wire(policy()).decode()
malformed = {
    'duplicate_same_key': valid[:-1] + ',"max_call_depth":2}',
    'duplicate_escaped_key': valid[:-1] + r',"\u006dax_call_depth":2}',
    'unknown_key': valid[:-1] + ',"unreviewed":0}',
    'missing_depth': wire({k: v for k, v in policy().items() if k != 'max_call_depth'}).decode(),
    'trailing_document': valid + '{}',
    'policy_1025_bytes': ' ' * (1025 - len(valid)) + valid,
    'nested_policy': '[' * 70 + '0' + ']' * 70,
}
for token in ['2.0', '2e0', '2E-0', '02', '+2', '-0', '-00', 'true', '"2"',
              'null', '[]', '{}', 'NaN', 'Infinity', '18446744073709551616', '1e309']:
    malformed['depth_token_' + token] = valid.replace('"max_call_depth":2', '"max_call_depth":' + token)
for name, value in malformed.items():
    rejects(name, core.canonical_bytes, '[7]', value)
for argument in ['[true]', '[false]', '[7.0]', '[7e0]', '["7"]', '[7,8]', '[-1]',
                 '[4294967296]', '[{"x":1,"x":2}]']:
    rejects('typed_arguments_' + argument, core.canonical_bytes, argument, valid)

# Formatting/escaped spelling and integer -0 remain semantic JSON equivalents.
valid_variants = {
    'policy_1024_bytes': ' ' * (1024 - len(valid)) + valid,
    'escaped_single_key': valid.replace('"max_call_depth"', r'"\u006dax_call_depth"'),
    'integer_negative_zero_heap': valid.replace('"max_heap_bytes":0', '"max_heap_bytes":-0'),
    'largest_unused_allocation_failure': wire(policy(fail=(1 << 64) - 1)).decode(),
}
for name, value in valid_variants.items():
    observed = raw(name, core.canonical_bytes, 'identity', '[7]', value)
    document = json.loads(observed.stdout) if observed.returncode == 0 else {}
    check(name, observed.returncode == 0 and not observed.stderr
          and document.get('execution', {}).get('values') == [7])

for depth, steps, expected_code, ticks in [(1, 1000, 'calls', 2), (2, 1000, 'calls', 4),
                                         (7, 1000, 'calls', 14), (32, 1000, 'calls', 64),
                                         (2, 3, 'steps', 4), (2, 4, 'calls', 4)]:
    observed = crosscheck.crosscheck_rust_execution_v2(module, 'loop', [7], EXE,
        executable_sha256=EXPECTED_BINARY, max_call_depth=depth, max_steps=steps, max_heap_bytes=0)
    report['fresh_crosschecks'].append(observed)
    vm = observed['rust_report']
    check('actual_depth_' + str(depth) + '_steps_' + str(steps),
          vm['error'] == {'code': expected_code} and vm['steps'] == ticks
          and vm['max_call_depth'] == depth and observed['request']['policy']['max_call_depth'] == depth
          and observed['claims']['rust_is_production_admission_authority'] is False)

owner = owning_recursion()
verify_program(owner)
for depth in [1, 3]:
    observed = crosscheck.crosscheck_rust_execution_v2(owner, 'recur_owner', [3], EXE,
        executable_sha256=EXPECTED_BINARY, max_call_depth=depth, max_steps=1000, max_heap_bytes=3 * depth)
    report['fresh_crosschecks'].append(observed)
    vm = observed['rust_report']
    resources = vm['resources']
    check('stopped_live_owners_at_depth_' + str(depth),
          vm['error'] == {'code': 'calls'} and vm['steps'] == 3 * depth
          and resources['live_owners'] == depth and resources['live_bytes'] == 3 * depth
          and resources['frees'] == 0)

for corruption in ['unknown_opcode', 'unknown_type', 'duplicate_core_key']:
    changed = deepcopy(module)
    hidden = deepcopy(changed['functions'][0]); hidden['name'] = 'hidden'
    if corruption == 'unknown_opcode':
        hidden['blocks'][0]['ops'] = [{'op': 'future.unsafe', 'args': [], 'out': [], 'attrs': {}}]
    elif corruption == 'unknown_type':
        hidden['params'][0]['type'] = 'pointer'
        hidden['blocks'][0]['params'][0]['type'] = 'pointer'
    changed['functions'].append(hidden)
    encoded = wire(changed)
    if corruption == 'duplicate_core_key':
        encoded = encoded.replace(b'"module":', b'"module":"forged","module":', 1)
    rejects('whole_module_' + corruption, encoded, '[7]', wire(policy(1, 1, 0, 1)).decode())
    with patch.object(crosscheck, '_verified_executable_bytes') as launch:
        try:
            crosscheck.crosscheck_rust_execution_v2(encoded, 'identity', [7], EXE,
                executable_sha256=EXPECTED_BINARY, max_call_depth=1, max_steps=1,
                max_heap_bytes=0, allocation_fail_at=1)
            error = None
        except Exception as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
        check('python_whole_module_' + corruption, error is not None and not launch.called, error=error)

legacy = raw('legacy_loop', core.canonical_bytes, 'loop', '[7]', mode='--owned-run',
             extra=['1000', '0', 'none'])
v1 = raw('bound_v1_loop', core.canonical_bytes, 'loop', '[7]', mode='--owned-run-bound',
         extra=['1000', '0', 'none'])
v2 = raw('bound_v2_loop', core.canonical_bytes, 'loop', '[7]', wire(policy(32)).decode())
old, first, second = [json.loads(x.stdout) for x in [legacy, v1, v2]]
check('legacy_and_v1_keep_depth_32', old == first['execution'] == second['execution']
      and old['max_call_depth'] == 32 and old['steps'] == 64
      and first['schema'].endswith('.v1') and second['schema'].endswith('.v2')
      and first['request_sha256'] != second['request_sha256'])

v1_identity = raw('actual_v1_identity', core.canonical_bytes, 'identity', '[7]',
                  mode='--owned-run-bound', extra=['1000', '0', 'none']).stdout
v2_identity = raw('actual_v2_identity', core.canonical_bytes, 'identity', '[7]', wire(policy(32))).stdout
replays = [('actual_v1_into_v2', v1_identity, 2), ('actual_v2_into_v1', v2_identity, 1)]
for field, value in [('max_call_depth', 31), ('max_call_depth', True), ('max_steps', 999),
                     ('max_heap_bytes', 1), ('allocation_fail_at', 1)]:
    altered = json.loads(v2_identity)
    altered['request']['policy'][field] = value
    altered['request_sha256'] = sha256(wire(altered['request'])).hexdigest()
    replays.append(('rehashed_policy_' + field + '_' + str(value), wire(altered) + b'\n', 2))
for field, value in [('max_call_depth', 31), ('max_call_depth', True), ('values', [True])]:
    altered = json.loads(v2_identity); altered['execution'][field] = value
    replays.append(('result_' + field + '_' + str(value), wire(altered) + b'\n', 2))
for label, producer_bytes, version in replays:
    with tempfile.TemporaryDirectory(prefix='hepta-independent-v2-replay-') as td:
        executable = Path(td) / 'replay'
        executable.write_text(f'#!{sys.executable}\nimport sys\nsys.stdin.buffer.read()\nsys.stdout.buffer.write({producer_bytes!r})\n')
        executable.chmod(0o700)
        api = crosscheck.crosscheck_rust_execution_v2 if version == 2 else crosscheck.crosscheck_rust_execution
        extra = {'max_call_depth': 32} if version == 2 else {}
        try:
            api(module, 'identity', [7], executable, executable_sha256=digest(executable),
                max_steps=1000, max_heap_bytes=0, **extra)
            error = None
        except crosscheck.HIARustCrosscheckRejected as exc:
            error = str(exc)
        check(label, error is not None)
        report['replay_refusal_controls'].append({'label': label, 'synthetic_producer': True,
            'raw_stdout': producer_bytes.decode(), 'rejected': error is not None, 'error': error})

report['source_clean_after'] = not git('status', '--porcelain')
report['source_unchanged'] = before == {name: digest(ROOT / name) for name in source_names}
report['binary_unchanged'] = digest(EXE) == EXPECTED_BINARY
report['checks_passed'] = (all(row['passed'] for row in report['checks'])
                           and report['source_clean_after'] and report['source_unchanged'] and report['binary_unchanged'])
destination = BASE / 'rust-bound-depth-independent-review.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'checks_passed': report['checks_passed'], 'checks': len(report['checks']),
                  'actual_direct_processes': len(report['actual_processes']),
                  'fresh_crosschecks': len(report['fresh_crosschecks']),
                  'synthetic_replay_controls': len(report['replay_refusal_controls']),
                  'failed_checks': [r for r in report['checks'] if not r['passed']],
                  'path': str(destination)}, indent=2))
if not report['checks_passed']:
    raise SystemExit(1)
