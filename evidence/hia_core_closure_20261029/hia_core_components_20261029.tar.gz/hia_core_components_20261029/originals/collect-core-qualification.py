from pathlib import Path
import contextlib
import hashlib
import json
import os
import subprocess
import sys
import time
import unittest

root = Path('/workspace/scratch/b484d4086829/hepta-core')
output = Path('/workspace/scratch/b484d4086829/core-qualification-b20b1da')
sys.path.insert(0, str(root))
os.environ['HIA_LOCAL_VIEW_NATIVE_DIR'] = str(output)
def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, text=True).strip()

head = git('rev-parse', 'HEAD')
assert head == 'b20b1da6d5002bfe80689901e4016a0c4cbffb57', head
before = git('status', '--porcelain')
assert not before, before
modules = ['tests.test_hia_source_local_views', 'tests.test_hia_program_source',
           'tests.test_hia_source_partial', 'tests.test_hia_returned_loans',
           'tests.test_hia_source_exports', 'tests.test_hia_routes', 'tests.test_hia_round3_routes']
start = time.monotonic()
with (output / 'unittest.log').open('w') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(modules))
from tests.test_hia_source_local_views import HIASourceLocalViewNative, HIASourceLocalViewRust, SOURCE
from hepta.hia_program_source import lower_source, source_report
from hepta.hia_program_llvm import emit_program_llvm
from hepta.hia_schema import SCHEMA, SCHEMA_V8
sources = {}
for schema in (SCHEMA, SCHEMA_V8):
    core = lower_source(SOURCE, core_schema=schema)
    filename = schema.rsplit('.', 1)[-1]
    (output / (filename + '.core.json')).write_bytes(core.canonical_bytes)
    (output / (filename + '.ll')).write_text(emit_program_llvm(core).text)
    sources[schema] = {'core_sha256': core.sha256, 'source_report': source_report(SOURCE, core_schema=schema)}
observations = getattr(HIASourceLocalViewRust, 'observations', [])
(output / 'rust-observations.json').write_text(json.dumps({'build': getattr(HIASourceLocalViewRust, 'build', None),
    'programs': getattr(HIASourceLocalViewRust, 'programs', None), 'observations': observations}, indent=2))
(output / 'native-observations.json').write_text(json.dumps({'differential': HIASourceLocalViewNative.records,
    'allocator': getattr(HIASourceLocalViewNative, 'allocator', None)}, indent=2))
after = git('status', '--porcelain')
summary = {'source_commit': head, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'source_clean_before': not before, 'source_clean_after': not after,
    'head_unchanged': git('rev-parse', 'HEAD') == head, 'modules': modules,
    'tests': result.testsRun, 'failures': result.failures, 'errors': result.errors, 'skipped': result.skipped,
    'elapsed_seconds': time.monotonic()-start, 'sources': sources,
    'rust_full_ledger_observations': len(observations),
    'native_paired_value_cases': sum(len(record['observations']) for record in HIASourceLocalViewNative.records),
    'native_allocator_cases': len(getattr(HIASourceLocalViewNative, 'allocator', {}).get('observations', [])),
    'qualified': result.wasSuccessful() and not result.skipped and not after,
    'whole_language_soundness_proved': False, 'all_blockers_closed': False}
(output / 'summary.json').write_text(json.dumps(summary, indent=2))
inventory = {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted(output.rglob('*')) if path.is_file()}
(output / 'sha256.json').write_text(json.dumps(inventory, indent=2))
print(json.dumps({key: summary[key] for key in ['source_commit','tests','elapsed_seconds',
    'rust_full_ledger_observations','native_paired_value_cases','native_allocator_cases','qualified']}, indent=2))
sys.exit(0 if summary['qualified'] else 1)
