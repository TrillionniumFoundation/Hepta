import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/b484d4086829/hepta-core')
sys.path.insert(0, str(ROOT))
from hepta.backend import compile_rust, emit_rust
from hepta.checker import check
from hepta.hia_program_runtime import execute_program
from hepta.hia_program_source import HIAProgramSourceRejected, lower_source
from hepta.hia_program_llvm import build_program_native
from hepta.parser import parse
from hepta.resource_lowering import lower_resource_ir

OUT = Path('/workspace/scratch/b484d4086829/localview-independent-review/focused')
OUT.mkdir(exist_ok=False)
HEADER = "struct View<'a>{data:read 'a [u8],tag:u64} struct Edit<'a>{data:mut 'a [u8],tag:u64}\n"
def source(body, mutable=False):
    return HEADER + f"fn inner(b:{'mut' if mutable else 'read'} [u8],n:u8)->u64 effects{{panic,write}}{{" + body + "}"
negatives = {
 'mutable_copy':(source('let first=Edit{data:mut b,tag:3};let copy=first;drop(move first);drop(move copy);return 0;',True),'requires an explicit move'),
 'mutable_use_after_move':(source('let first=Edit{data:mut b,tag:3};let last=move first;let label=first.tag;drop(move last);return label;',True),'moved or partially initialized'),
 'mutable_double_drop':(source('let first=Edit{data:mut b,tag:3};drop(move first);drop(move first);return 0;',True),'moved or partially initialized'),
 'mutable_missing_branch_drop':(source('let first=Edit{data:mut b,tag:3};if n==0{drop(move first);}return 0;',True),'both continuing branches must leave the same linear owners live'),
 'parent_write_while_shared_alias_live':(source('let first=View{data:read b,tag:3};let copied=first;b[0]=7;return copied.tag;',True),'Direct access conflicts with a live loan'),
 'parent_read_while_mutable_live':(source('let first=Edit{data:mut b,tag:3};let x=b[0];drop(move first);return x as u64;',True),'Direct access conflicts with a live loan'),
 'mutable_second_overlapping_origin':(source('let first=Edit{data:mut b,tag:3};let second=Edit{data:mut b,tag:4};drop(move first);drop(move second);return 0;',True),'Direct access conflicts with a live loan'),
 'escaped_stored_view':(HEADER+"fn escape<'a>(b:read 'a [u8])->View<'a> effects{}{return View{data:read b,tag:7};}",'Stored view parameters/returns'),
 'stored_call_return':(HEADER+"fn get(b:read [u8])->read [u8] from b effects{}{return read b;}fn inner(b:read [u8])->u64 effects{}{let view=View{data:read get(read b),tag:7};return view.tag;}",'borrow and assignment places must be local records or fields'),
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
before=sha(ROOT/'hepta/hia_program_source.py')
report={'schema':'hepta.independent-local-view-focused-review.v1','head':head,'source_sha256_before':before,'negative':[],'returned_sibling':{},'formal_refinement_proved':False}
for name,(text,diagnostic) in negatives.items():
    (OUT/(name+'.hepta')).write_text(text)
    row={'case':name,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'results':[]}
    for schema in ('hepta.hia.program.v1','hepta.hia.program.v8'):
        try:
            lower_source(text,core_schema=schema)
            result={'schema':schema,'passed':False,'error':'Unexpected acceptance'}
        except HIAProgramSourceRejected as exc:
            message=str(exc)
            result={'schema':schema,'passed':diagnostic in message,'error':type(exc).__name__+': '+message}
        except Exception as exc:
            result={'schema':schema,'passed':False,'error':type(exc).__name__+': '+str(exc)}
        row['results'].append(result)
    row['passed']=all(x['passed'] for x in row['results']);report['negative'].append(row)
    print(name,row['passed'],flush=True)

text = HEADER + '''
fn child(b:read [u8],n:u8)->read [u8] from b effects{panic}{
    let outer=View{data:read b,tag:4};let sibling=outer;
    for i in 0..n as usize {let copied=sibling;assert(copied.tag==4);if i==1{return read b;}}
    assert(outer.tag==4);return read b;
}
export "C" fn probe(n:u8)->u64 effects{alloc,block,panic,write}{
    let mut b=buffer(1);b[0]=5;
    let result=child(read b,n)[0] as u64;
    b[0]=7;let parent=b[0] as u64;
    drop(move b);return result+parent;
}'''
row=report['returned_sibling'];(OUT/'returned_sibling.hepta').write_text(text)
row['source_sha256']=hashlib.sha256(text.encode()).hexdigest()
try:
    ast=parse(text);checked=check(ast)
    if not checked.ok:raise ValueError('frontend diagnostics: '+str([d.message for d in checked.diagnostics]))
    graph=lower_resource_ir(ast,checked);row['resource_schema']=graph['schema']
    generated=emit_rust(ast,checked,crate_type='cdylib');(OUT/'returned_sibling.rs').write_text(generated)
    reference=compile_rust(generated,crate_type='cdylib',output=OUT/'returned_sibling-reference.so',linker=os.environ['CLANG'])
    if not reference['ok']:raise ValueError('Rust build failed: '+str(reference))
    original=ctypes.CDLL(str(OUT/'returned_sibling-reference.so')).probe;original.argtypes=[ctypes.c_uint8];original.restype=ctypes.c_uint64
    core=lower_source(text,core_schema='hepta.hia.program.v8');(OUT/'returned_sibling.json').write_bytes(core.canonical_bytes)
    native=build_program_native(core.canonical_bytes,OUT/'returned_sibling-native.so',clang=os.environ['CLANG'])
    if not native['ok']:raise ValueError('LLVM build failed: '+str(native))
    compiled=ctypes.CDLL(str(OUT/'returned_sibling-native.so')).probe;compiled.argtypes=[ctypes.c_uint8];compiled.restype=ctypes.c_uint64
    row['rust_reference']=reference;row['llvm']=native;row['observations']=[]
    for n in (0,1,2,3):
        vm=execute_program(core,'probe',[n]);actual={'n':n,'expected':12,'vm':vm['result'],'source_rust':original(n),'core_llvm':compiled(n),'resources':vm['resources']}
        row['observations'].append(actual)
        if not 12==actual['vm']==actual['source_rust']==actual['core_llvm']:raise ValueError('semantic value mismatch')
        if any(vm['resources'][k] for k in ('live_bytes','live_owners','live_local_loans')):raise ValueError('normal return leaked resources')
    row['passed']=True
except Exception as exc:
    row['passed']=False;row['error']=type(exc).__name__+': '+str(exc)
print('returned_sibling',row['passed'],row.get('error',''),flush=True)
report['source_sha256_after']=sha(ROOT/'hepta/hia_program_source.py')
report['source_unchanged']=before==report['source_sha256_after']
report['passed']=report['source_unchanged'] and all(x['passed'] for x in report['negative']) and row['passed']
(OUT/'focused.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':report['passed'],'report':str(OUT/'focused.json')}))
raise SystemExit(0 if report['passed'] else 1)
