source /workspace/scratch/bf7d454bbc83/round4-env.sh
export CARGO_HOME=/workspace/scratch/b484d4086829/cargo-home
export PYTHONDONTWRITEBYTECODE=1
export CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR=/workspace/scratch/b484d4086829/target-main
export HEPTA_NDU_STREAM_BRIDGE=/workspace/scratch/bf7d454bbc83/round5-ndu-stream-build/native/hepta-hia-ndu-bridge
export HEPTA_NDU_STREAM_IDENTITY=/workspace/scratch/bf7d454bbc83/round5-ndu-stream-build/identity.json
export HEPTA_NDU_STREAM_UPSTREAM=/workspace/scratch/bf7d454bbc83/ndu-stream-round5
