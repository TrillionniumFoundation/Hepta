"""Read-only finite review of the safety protocol helper, not Core semantics."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import types

ROOT = Path('/workspace/scratch/b484d4086829/hepta-live')
OUTPUT = Path('/workspace/scratch/b484d4086829/safety-protocol-independent-review.json')
PATH = 'tools/qualify_hia_safety_contract.py'
BEFORE = 'b16cb6c'
AFTER = 'd06c917'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def module_at(ref):
    full = git('rev-parse', ref).decode().strip()
    source = git('show', full + ':' + PATH)
    module = types.ModuleType('safety_independent_review_' + ref)
    module.__file__ = str(ROOT / PATH)
    exec(compile(source, str(ROOT / PATH) + '@' + full, 'exec'), module.__dict__)
    return module, {'commit': full, 'runner_sha256': sha256(source).hexdigest()}


class ChangedIteration(list):
    """First serialization is full; later iteration offers a changed value."""
    def __init__(self, values, replacement):
        super().__init__(values)
        self.replacement = replacement
        self.reads = 0

    def __iter__(self):
        self.reads += 1
        return super().__iter__() if self.reads == 1 else iter(self.replacement)


contract = json.loads(git('show', BEFORE + ':docs/HIA_SAFETY_CONTRACT.json'))
expected = sorted({test for row in contract['capabilities']
                   for test in row['regression_selectors']})
results = {}
for label, ref in [('before_snapshot_fix', BEFORE), ('after_snapshot_fix', AFTER)]:
    module, source = module_at(ref)
    selected = module.validate_contract(deepcopy(contract))
    changed = deepcopy(contract)
    for row in changed['capabilities']:
        row['regression_selectors'] = ChangedIteration(
            row['regression_selectors'], row['regression_selectors'][:1])
    reduced = module.validate_contract(changed)

    altered = deepcopy(contract)
    altered['capabilities'][0]['entrypoints'] = ChangedIteration(
        altered['capabilities'][0]['entrypoints'], ['os.system'])
    resolved = []
    original_resolve = module.resolve

    def observed_resolve(name):
        resolved.append(name)
        return original_resolve(name)

    module.resolve = observed_resolve
    module.validate_contract(altered)
    module.resolve = original_resolve

    deleted = deepcopy(contract)
    deleted['capabilities'] = deleted['capabilities'][:1]
    try:
        module.validate_contract(deleted)
        reduction_error = None
    except ValueError as error:
        reduction_error = str(error)
    reordered = {key: contract[key] for key in reversed(contract)}
    formatting_same = module.validate_contract(
        json.loads(json.dumps(reordered, indent=4))) == selected

    changed_entry = deepcopy(contract)
    changed_entry['capabilities'][0]['entrypoints'] = ['os.system']
    entry_resolution_calls = []

    def forbidden_resolution(name):
        entry_resolution_calls.append(name)
        raise AssertionError('unreviewed resolution occurred')

    module.resolve = forbidden_resolution
    try:
        module.validate_contract(changed_entry)
        entry_error = None
    except ValueError as error:
        entry_error = str(error)
    module.resolve = original_resolve

    results[label] = {
        **source, 'ordinary_reviewed_selectors': len(selected),
        'reviewed_protocol_identity': module.REVIEWED_CONTRACT_SHA256,
        'stateful_selector_container_count': len(reduced),
        'stateful_selector_container_preserves_full_selection': reduced == expected,
        'stateful_entrypoint_container_resolved_unreviewed_os_system': 'os.system' in resolved,
        'ordinary_json_deletion_rejection': reduction_error,
        'json_whitespace_and_object_key_order_preserved': formatting_same,
        'ordinary_changed_entrypoint_rejection': entry_error,
        'ordinary_changed_entrypoint_resolution_calls': entry_resolution_calls,
    }

doc = git('show', AFTER + ':docs/HIA_SAFETY_CONTRACT.md').decode()
record = {
    'schema': 'hepta.safety-protocol-independent-review.v1',
    'scope': 'finite Python-helper snapshot and qualification-protocol checks only',
    'reviewed_capabilities': len(contract['capabilities']),
    'expected_distinct_selectors': len(expected),
    'results': results,
    'pre_fix_exploit_required_python_list_subclass': True,
    'plain_json_cli_input_did_not_have_the_list_subclass_bypass': True,
    'source_root_was_not_modified_by_this_review': True,
    'protocol_revision_requires_explicit_hash_update_by_design': True,
    'whole_language_or_backend_proof_established': False,
    'documentation_explicitly_disclaims_soundness_or_refinement_proof':
        'It is not a soundness or refinement proof.' in doc,
    'all_contract_unproved_claims_remain_false':
        all(value is False for value in contract['unproved_claims'].values()),
    'review_passed': (
        results['before_snapshot_fix']['stateful_selector_container_count'] < len(expected)
        and results['after_snapshot_fix']['stateful_selector_container_preserves_full_selection']
        and not results['after_snapshot_fix']['stateful_entrypoint_container_resolved_unreviewed_os_system']
        and results['after_snapshot_fix']['json_whitespace_and_object_key_order_preserved']
        and not results['after_snapshot_fix']['ordinary_changed_entrypoint_resolution_calls']
        and results['after_snapshot_fix']['ordinary_json_deletion_rejection'] is not None
    ),
}
OUTPUT.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True, indent=2))
raise SystemExit(0 if record['review_passed'] else 1)
