"""Read-only source/hash/selector review. It does not execute test methods."""
from __future__ import annotations

import ast
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import importlib
import inspect
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import textwrap
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/b484d4086829/hepta-migration')
OUTPUT = Path(sys.argv[1])
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT).decode()


def read(name, before=False):
    return git('show', 'HEAD:' + name) if before else (ROOT / name).read_text()


def assignment(source, name):
    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise AssertionError('missing assignment ' + name)


def normalized_without_assignment(source, name):
    tree = ast.parse(source)
    tree.body = [node for node in tree.body if not (isinstance(node, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == name for t in node.targets))]
    return ast.dump(tree, include_attributes=False)


def python_block(workflow):
    blocks = list(re.finditer(r"(?ms)^          python - <<'PY'\n(.*?)^          PY\s*$", workflow))
    assert len(blocks) == 1
    match = blocks[0]
    return textwrap.dedent(match.group(1)), workflow[:match.start()] + '<python-run-block>' + workflow[match.end():]


head = git('rev-parse', 'HEAD').strip()
status_before = git('status', '--porcelain')
changed = git('diff', '--name-only').splitlines()
paths = set(changed) | {
    '.gitattributes', '.github/workflows/hepta-qualification.yml', '.github/workflows/hepta-six-outcomes.yml',
    'docs/HIA_SAFETY_CONTRACT.json', 'docs/HIA_CORE_CLOSURE_20261028.md',
    'tools/qualify_hia_safety_contract.py', 'tools/qualify_hia_integrated.py',
    'hepta/hia_program_source.py', 'hepta/hia_rust_crosscheck.py', 'hepta/hia_program_runtime.py',
    'rust/hia-core-shadow/src/main.rs', 'tests/test_hia_integrated_workflow.py',
    'tests/test_hia_safety_protocol.py', 'tests/test_cpp_upstream_host.py',
    'tests/test_hia_source_unit_enums.py', 'tests/test_hia_rust_bound_depth.py',
}
before_hashes = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(paths)}

old = json.loads(read('docs/HIA_SAFETY_CONTRACT.json', True))
new = json.loads(read('docs/HIA_SAFETY_CONTRACT.json'))
old_rows = {row['id']: row for row in old['capabilities']}
new_rows = {row['id']: row for row in new['capabilities']}
old_selectors = {s for row in old_rows.values() for s in row['regression_selectors']}
all_new_selectors = [s for row in new_rows.values() for s in row['regression_selectors']]
new_selectors = set(all_new_selectors)
row_checks = {}
for key, previous in old_rows.items():
    current = new_rows.get(key, {})
    row_checks[key] = {
        'old_selectors_retained': set(previous['regression_selectors']) <= set(current.get('regression_selectors', [])),
        'old_entrypoints_retained': set(previous['entrypoints']) <= set(current.get('entrypoints', [])),
        'old_exclusions_retained': set(previous['exclusions']) <= set(current.get('exclusions', [])),
        'guarantee_unchanged': current.get('guarantee') == previous['guarantee'],
        'scope_original_prefix_retained': current.get('scope', '').startswith(previous['scope']),
    }
top_unchanged = {key: value == new.get(key) for key, value in old.items() if key != 'capabilities'}
reviewed = assignment(read('tools/qualify_hia_safety_contract.py'), 'REVIEWED_CONTRACT_SHA256')
canonical_sha = sha256(json.dumps(new, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

# Resolving existing methods imports their modules, but never calls a method,
# setUpClass, compiler, native observer or subprocess. Enforce that last bound.
with patch('subprocess.Popen', side_effect=AssertionError('static selector resolution may not launch a process')):
    safety = importlib.import_module('tools.qualify_hia_safety_contract')
    resolved = safety.validate_contract(new)
    resolution_rows = []
    for selector in resolved:
        loader = unittest.TestLoader()
        suite = loader.loadTestsFromName(selector)
        assert not loader.errors and suite.countTestCases() == 1
        function = safety.resolve(selector)
        path = Path(inspect.getsourcefile(function)).resolve()
        resolution_rows.append({'selector': selector, 'case_count': suite.countTestCases(),
                                'source': str(path.relative_to(ROOT)),
                                'source_sha256': sha256(path.read_bytes()).hexdigest()})

old_critical = assignment(read('tools/qualify_hia_integrated.py', True), 'CRITICAL_MODULES')
new_critical = assignment(read('tools/qualify_hia_integrated.py'), 'CRITICAL_MODULES')
critical_retained = {key: set(values) <= set(new_critical.get(key, ())) for key, values in old_critical.items()}
critical_added = {key: sorted(set(values) - set(old_critical.get(key, ())))
                  for key, values in new_critical.items() if set(values) - set(old_critical.get(key, ()))}
critical_exist = all((ROOT / 'tests' / (name + '.py')).is_file()
                     for values in new_critical.values() for name in values)
critical_only_change = normalized_without_assignment(read('tools/qualify_hia_integrated.py', True), 'CRITICAL_MODULES') == \
                      normalized_without_assignment(read('tools/qualify_hia_integrated.py'), 'CRITICAL_MODULES')
old_block, old_other = python_block(read('.github/workflows/hepta-six-outcomes.yml', True))
new_block, new_other = python_block(read('.github/workflows/hepta-six-outcomes.yml'))
old_names, new_names = assignment(old_block, 'names'), assignment(new_block, 'names')
ci_retained = [name for name in new_names if name in set(old_names)] == old_names
ci_no_duplicates = len(new_names) == len(set(new_names))
ci_execution_unchanged = old_other == new_other and normalized_without_assignment(old_block, 'names') == \
                                                  normalized_without_assignment(new_block, 'names')
ci_modules_exist = all((ROOT / (name.replace('.', '/') + '.py')).is_file() for name in new_names)

inventory = safety.source_inventory()
tracked = set(git('ls-files', '-z').split('\0')) - {''}
control_inputs = sorted(name for name in tracked if name == '.gitattributes'
                       or name.startswith('.github/workflows/') or name.startswith('tests/fixtures/cpp_upgrade/'))
missing_controls = sorted(set(control_inputs) - set(inventory))
input_hashes_correct = all(inventory.get(name) == sha256((ROOT / name).read_bytes()).hexdigest()
                          for name in control_inputs if name in inventory)

closure = read('docs/HIA_CORE_CLOSURE_20261028.md')
boundary_checks = {
    'all_unproved_claims_still_exact_false': all(value is False for value in new['unproved_claims'].values()),
    'python_authority_and_metadata_refusal_unchanged': new['authority'] == old['authority'],
    'six_execution_boundary_descriptions_unchanged': new['boundaries'] == old['boundaries'],
    'v1_wrapper_fixed_depth_32': 'timeout=timeout, max_call_depth=32, protocol_version=1)' in read('hepta/hia_rust_crosscheck.py'),
    'v2_exact_integer_depth_one_to_32': 'type(max_call_depth) is not int or not 1 <= max_call_depth <= 32' in read('hepta/hia_rust_crosscheck.py'),
    'enum_original_nominal_export_guard_present': 'and all(p.mode == "value" and scalar(p.type) for p in fn.params)' in read('hepta/hia_program_source.py'),
    'enum_explicit_c_abi_refusal_present': 'aggregate scalarization does not preserve a public C ABI' in read('hepta/hia_program_source.py'),
    'enum_finite_payload_and_generic_refusal_present': 'enum.type_params or not 1 <= len(enum.variants) <= MAX_VARIANTS' in read('hepta/hia_program_source.py'),
    'shell_fixture_explicitly_not_qualification': "'qualification_executed': False" in read('tests/test_hia_integrated_workflow.py'),
    'checkout_fixture_explicitly_not_windows_native': 'does not simulate Windows C++ execution' in read('tests/test_cpp_upstream_host.py'),
    'closure_requires_new_actual_windows_run': 'only a new actual\nWindows host run can qualify' in closure,
    'closure_does_not_claim_unobserved_ci_passed': 'not a claim that an unobserved host run has\nalready passed' in closure,
    'closure_keeps_general_blockers_open': 'whole_project_blockers_closed=false' in closure,
    'closure_keeps_rust_nonauthoritative': 'rust_is_production_admission_authority=false' in closure,
    'closure_preserves_no_change_policy': '`no_change`' in closure,
}

after_hashes = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(paths)}
stable = before_hashes == after_hashes and status_before == git('status', '--porcelain') and head == git('rev-parse', 'HEAD').strip()
checks = {
    'capability_ids_preserved': old_rows.keys() == new_rows.keys(),
    'capability_count_is_16': len(new_rows) == 16,
    'old_selector_count_is_56': len(old_selectors) == 56,
    'all_old_selectors_retained': old_selectors <= new_selectors,
    'all_row_controls_retained': all(all(v.values()) for v in row_checks.values()),
    'top_level_contract_unchanged': all(top_unchanged.values()),
    'reviewed_hash_matches_canonical_json': reviewed == canonical_sha,
    'selector_resolution_exact': set(resolved) == new_selectors and len(resolved) == len(new_selectors),
    'selectors_are_not_duplicated': len(new_selectors) == len(all_new_selectors),
    'critical_modules_preserved': all(critical_retained.values()),
    'critical_module_files_exist': critical_exist,
    'integrated_code_changed_only_critical_module_list': critical_only_change,
    'ci_old_modules_preserved_in_order': ci_retained,
    'ci_no_duplicate_modules': ci_no_duplicates,
    'ci_rejection_and_remaining_execution_unchanged': ci_execution_unchanged,
    'ci_module_files_exist': ci_modules_exist,
    'new_control_input_inventory_complete': not missing_controls,
    'control_input_hashes_match_actual_bytes': input_hashes_correct,
    'review_snapshot_stable': stable,
    **boundary_checks,
}
report = {
    'schema': 'hepta.final-control-static-review.v1', 'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'subject': str(ROOT), 'head': head, 'status_before': status_before,
    'uncommitted_snapshot': bool(status_before), 'source_sha256_before': before_hashes,
    'source_sha256_after': after_hashes, 'checks': checks, 'passed': all(checks.values()),
    'matrix': {'old_selectors': len(old_selectors), 'new_selectors': len(new_selectors),
               'capabilities': len(new_rows), 'canonical_sha256': canonical_sha, 'reviewed_constant': reviewed,
               'added_selectors': sorted(new_selectors - old_selectors), 'removed_selectors': sorted(old_selectors - new_selectors),
               'duplicate_selectors': sorted(name for name, count in Counter(all_new_selectors).items() if count > 1),
               'row_preservation': row_checks, 'top_level_preservation': top_unchanged},
    'resolved_selectors': resolution_rows, 'critical_module_additions': critical_added,
    'ci_module_additions': sorted(set(new_names) - set(old_names)),
    'source_inventory': {'count': len(inventory), 'required_new_control_inputs': control_inputs,
                         'missing': missing_controls,
                         'hashes': {name: inventory[name] for name in control_inputs if name in inventory}},
    'prior_finding': {'id': 'F001', 'description': 'Standalone safety inventory omitted workflow, attributes and license inputs used by added selectors.',
                     'originally_observed_missing': ['.gitattributes', '.github/workflows/hepta-qualification.yml',
                       '.github/workflows/hepta-six-outcomes.yml', 'tests/fixtures/cpp_upgrade/3.11.3/LICENSE.MIT',
                       'tests/fixtures/cpp_upgrade/3.12.0/LICENSE.MIT'],
                     'resolved_in_this_snapshot': not missing_controls},
    'claims': {'test_methods_executed': False, 'native_execution_performed': False,
               'ci_run_qualified': False, 'windows_native_qualified': False,
               'uncommitted_snapshot_is_a_published_commit': False},
    'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
}
with OUTPUT.open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'output': str(OUTPUT), 'passed': report['passed'],
                  'old_selectors': len(old_selectors), 'new_selectors': len(new_selectors),
                  'capabilities': len(new_rows), 'hash': canonical_sha,
                  'failed_checks': [key for key, value in checks.items() if not value]}, indent=2))
