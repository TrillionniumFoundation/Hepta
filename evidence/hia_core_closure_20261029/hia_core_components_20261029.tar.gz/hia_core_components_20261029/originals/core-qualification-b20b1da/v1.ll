; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(%hia.buffer %p_0_0, i1 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 9, i64 17)
  %t3 = extractvalue { i64, i1 } %t2, 0
  %t4 = extractvalue { i64, i1 } %t2, 1
  %t5 = xor i1 %t4, true
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t3, i64 %t1)
  %t8 = extractvalue { i64, i1 } %t7, 0
  %t9 = extractvalue { i64, i1 } %t7, 1
  %t10 = xor i1 %t9, true
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  br i1 true, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i1 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ 9, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_4 = phi i64 [ %t1, %edge_0 ]
  %p_1_5 = phi i64 [ 17, %edge_0 ]
  %p_1_6 = phi i64 [ %t1, %edge_0 ]
  %p_1_7 = phi i64 [ %t8, %edge_0 ]
  %t12 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_1_7, i64 %p_1_2)
  %t13 = extractvalue { i64, i1 } %t12, 0
  %t14 = extractvalue { i64, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  br i1 %p_1_1, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i1 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ 9, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_4 = phi i64 [ %t1, %edge_1 ]
  %p_2_5 = phi i64 [ 17, %edge_1 ]
  %p_2_6 = phi i64 [ %t1, %edge_1 ]
  %p_2_7 = phi i64 [ %t8, %edge_1 ]
  br label %edge_4
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i1 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_6, %edge_2 ]
  %p_3_7 = phi i64 [ %t13, %edge_2 ]
  %p_3_8 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_9 = phi i64 [ %p_1_4, %edge_2 ]
  ret i64 %p_3_7
b4:
  %p_4_0 = phi %hia.buffer [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i1 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_6, %edge_3 ]
  %p_4_7 = phi i64 [ %t13, %edge_3 ]
  %p_4_8 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_9 = phi i64 [ %p_1_4, %edge_3 ]
  br label %edge_5
b5:
  %p_5_0 = phi %hia.buffer [ %p_2_0, %edge_4 ], [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i1 [ %p_2_1, %edge_4 ], [ %p_4_1, %edge_5 ]
  %p_5_2 = phi i64 [ %p_2_2, %edge_4 ], [ %p_4_2, %edge_5 ]
  %p_5_3 = phi %hia.buffer [ %p_2_3, %edge_4 ], [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i64 [ %p_2_4, %edge_4 ], [ %p_4_4, %edge_5 ]
  %p_5_5 = phi i64 [ %p_2_5, %edge_4 ], [ %p_4_5, %edge_5 ]
  %p_5_6 = phi i64 [ %p_2_6, %edge_4 ], [ %p_4_6, %edge_5 ]
  %p_5_7 = phi i64 [ %p_2_7, %edge_4 ], [ %p_4_7, %edge_5 ]
  %t17 = extractvalue %hia.buffer %p_5_3, 1
  %t18 = icmp ugt i64 %t17, 0
  br i1 %t18, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi %hia.buffer [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i1 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi i64 [ %p_5_2, %edge_6 ]
  %p_6_3 = phi %hia.buffer [ %p_5_3, %edge_6 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_6 ]
  %p_6_5 = phi i64 [ %p_5_5, %edge_6 ]
  %p_6_6 = phi i64 [ %p_5_6, %edge_6 ]
  %p_6_7 = phi i64 [ %p_5_7, %edge_6 ]
  %t19 = extractvalue %hia.buffer %p_6_3, 0
  %t20 = extractvalue %hia.buffer %p_6_3, 1
  %t21 = icmp ult i64 0, %t20
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  %t23 = getelementptr i8, ptr %t19, i64 0
  %t24 = load i8, ptr %t23, align 1
  %t25 = zext i8 %t24 to i64
  %t26 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_6_7, i64 %t25)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  %t29 = xor i1 %t28, true
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  br label %edge_8
b7:
  %p_7_0 = phi %hia.buffer [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i1 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi i64 [ %p_5_2, %edge_7 ]
  %p_7_3 = phi %hia.buffer [ %p_5_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_7 ]
  %p_7_6 = phi i64 [ %p_5_6, %edge_7 ]
  %p_7_7 = phi i64 [ %p_5_7, %edge_7 ]
  br label %edge_9
b8:
  %p_8_0 = phi %hia.buffer [ %p_6_0, %edge_8 ], [ %p_7_0, %edge_9 ]
  %p_8_1 = phi i1 [ %p_6_1, %edge_8 ], [ %p_7_1, %edge_9 ]
  %p_8_2 = phi i64 [ %p_6_2, %edge_8 ], [ %p_7_2, %edge_9 ]
  %p_8_3 = phi %hia.buffer [ %p_6_3, %edge_8 ], [ %p_7_3, %edge_9 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ], [ %p_7_4, %edge_9 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ], [ %p_7_5, %edge_9 ]
  %p_8_6 = phi i64 [ %p_6_6, %edge_8 ], [ %p_7_6, %edge_9 ]
  %p_8_7 = phi i64 [ %t27, %edge_8 ], [ %p_7_7, %edge_9 ]
  ret i64 %p_8_7
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b8
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i8 %p_0_1, i8 %p_0_2) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i8 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i1 [ %t3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_5 = phi i8 [ 1, %edge_0 ]
  %t6 = icmp ugt i64 %p_1_0, 0
  br i1 %t6, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i8 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i1 [ %t3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_5 = phi i8 [ 1, %edge_1 ]
  %t7 = extractvalue %hia.buffer %p_2_4, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  %t10 = zext i8 %p_2_5 to i64
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t10)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  ret i64 %t12
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i8 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %t16 = extractvalue %hia.buffer %p_3_3, 0
  %t17 = extractvalue %hia.buffer %p_3_3, 1
  %t18 = icmp ult i64 0, %t17
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = getelementptr i8, ptr %t16, i64 0
  store i8 %p_3_1, ptr %t20, align 1
  br label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i8 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i8 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ], [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i8 [ %p_3_1, %edge_4 ], [ %p_4_1, %edge_5 ]
  %p_5_2 = phi i8 [ %p_3_2, %edge_4 ], [ %p_4_2, %edge_5 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ], [ %p_4_3, %edge_5 ]
  %t21 = icmp ne i8 %p_5_2, 0
  %t22 = call i64 @__hia_fn_0(%hia.buffer %p_5_3, i1 %t21)
  %t23 = extractvalue %hia.buffer %p_5_3, 0
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %drop_nonnull_25, label %drop_after_25
drop_nonnull_25:
  call void @free(ptr %t23) nobuiltin
  br label %drop_after_25
drop_after_25:
  ret i64 %t22
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b5
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i8 %p_0_1, i64 %p_0_2) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 %p_0_0, 1
  br label %edge_0
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ], [ %p_6_0, %edge_9 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ], [ %p_6_1, %edge_9 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ], [ %p_6_2, %edge_9 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ], [ %p_6_3, %edge_9 ]
  %p_1_4 = phi i64 [ 0, %edge_0 ], [ %t22, %edge_9 ]
  %p_1_5 = phi i64 [ %p_0_2, %edge_0 ], [ %p_6_5, %edge_9 ]
  %p_1_6 = phi i64 [ 0, %edge_0 ], [ %t27, %edge_9 ]
  %t6 = icmp ult i64 %p_1_6, %p_1_5
  br i1 %t6, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_1_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_1_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_1_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_1_6, %edge_1 ]
  %t7 = icmp ugt i64 %p_2_0, 0
  br i1 %t7, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_6, %edge_2 ]
  %t8 = icmp ugt i64 %p_3_0, 0
  br i1 %t8, label %edge_5, label %edge_6
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i8 [ %p_2_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_2_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_2_6, %edge_3 ]
  %p_4_7 = phi %hia.buffer [ %p_2_3, %edge_3 ]
  %p_4_8 = phi i64 [ %p_2_6, %edge_3 ]
  %t9 = trunc i64 %p_4_6 to i8
  %t10 = add i8 %p_4_1, %t9
  %t11 = extractvalue %hia.buffer %p_4_7, 0
  %t12 = extractvalue %hia.buffer %p_4_7, 1
  %t13 = icmp ult i64 0, %t12
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = getelementptr i8, ptr %t11, i64 0
  store i8 %t10, ptr %t15, align 1
  br label %edge_7
b5:
  %p_5_0 = phi i64 [ %p_2_0, %edge_4 ]
  %p_5_1 = phi i8 [ %p_2_1, %edge_4 ]
  %p_5_2 = phi i64 [ %p_2_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %p_2_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_2_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_2_5, %edge_4 ]
  %p_5_6 = phi i64 [ %p_2_6, %edge_4 ]
  %p_5_7 = phi %hia.buffer [ %p_2_3, %edge_4 ]
  %p_5_8 = phi i64 [ %p_2_6, %edge_4 ]
  br label %edge_8
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_7 ], [ %p_5_0, %edge_8 ]
  %p_6_1 = phi i8 [ %p_4_1, %edge_7 ], [ %p_5_1, %edge_8 ]
  %p_6_2 = phi i64 [ %p_4_2, %edge_7 ], [ %p_5_2, %edge_8 ]
  %p_6_3 = phi %hia.buffer [ %p_4_3, %edge_7 ], [ %p_5_3, %edge_8 ]
  %p_6_4 = phi i64 [ %p_4_4, %edge_7 ], [ %p_5_4, %edge_8 ]
  %p_6_5 = phi i64 [ %p_4_5, %edge_7 ], [ %p_5_5, %edge_8 ]
  %p_6_6 = phi i64 [ %p_4_6, %edge_7 ], [ %p_5_6, %edge_8 ]
  %p_6_7 = phi %hia.buffer [ %p_4_7, %edge_7 ], [ %p_5_7, %edge_8 ]
  %p_6_8 = phi i64 [ %p_4_8, %edge_7 ], [ %p_5_8, %edge_8 ]
  %t16 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_6_8, i64 1)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  %t19 = xor i1 %t18, true
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_6_4, i64 %t17)
  %t22 = extractvalue { i64, i1 } %t21, 0
  %t23 = extractvalue { i64, i1 } %t21, 1
  %t24 = xor i1 %t23, true
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_6_6, i64 1)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  %t29 = xor i1 %t28, true
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  br label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_7_1 = phi i8 [ %p_3_1, %edge_5 ]
  %p_7_2 = phi i64 [ %p_3_2, %edge_5 ]
  %p_7_3 = phi %hia.buffer [ %p_3_3, %edge_5 ]
  %p_7_4 = phi i64 [ %p_3_4, %edge_5 ]
  %t31 = extractvalue %hia.buffer %p_7_3, 0
  %t32 = extractvalue %hia.buffer %p_7_3, 1
  %t33 = icmp ult i64 0, %t32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = getelementptr i8, ptr %t31, i64 0
  %t36 = load i8, ptr %t35, align 1
  %t37 = zext i8 %t36 to i64
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_4, i64 %t37)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  br label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_3_0, %edge_6 ]
  %p_8_1 = phi i8 [ %p_3_1, %edge_6 ]
  %p_8_2 = phi i64 [ %p_3_2, %edge_6 ]
  %p_8_3 = phi %hia.buffer [ %p_3_3, %edge_6 ]
  %p_8_4 = phi i64 [ %p_3_4, %edge_6 ]
  br label %edge_11
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_10 ], [ %p_8_0, %edge_11 ]
  %p_9_1 = phi i8 [ %p_7_1, %edge_10 ], [ %p_8_1, %edge_11 ]
  %p_9_2 = phi i64 [ %p_7_2, %edge_10 ], [ %p_8_2, %edge_11 ]
  %p_9_3 = phi %hia.buffer [ %p_7_3, %edge_10 ], [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i64 [ %t39, %edge_10 ], [ %p_8_4, %edge_11 ]
  %t43 = extractvalue %hia.buffer %p_9_3, 0
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %drop_nonnull_45, label %drop_after_45
drop_nonnull_45:
  call void @free(ptr %t43) nobuiltin
  br label %drop_after_45
drop_after_45:
  ret i64 %p_9_4
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b7
edge_6:
  br label %b8
edge_7:
  br label %b6
edge_8:
  br label %b6
edge_9:
  br label %b1
edge_10:
  br label %b9
edge_11:
  br label %b9
}

define internal i64 @__hia_fn_3(i64 %p_0_0, i8 %p_0_1, i8 %p_0_2) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 %p_0_0, 1
  %t6 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t7 = extractvalue { i64, i1 } %t6, 0
  %t8 = extractvalue { i64, i1 } %t6, 1
  %t9 = xor i1 %t8, true
  br i1 %t9, label %ok_10, label %trap_10
trap_10:
  call void @abort()
  unreachable
ok_10:
  %t11 = call %hia.alloc @__hia_allocate(i64 %t7, i1 true)
  %t12 = extractvalue %hia.alloc %t11, 0
  %t13 = extractvalue %hia.alloc %t11, 1
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = insertvalue %hia.buffer %t12, i64 %t7, 1
  %t16 = icmp ne i8 %p_0_2, 0
  br i1 %t16, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i8 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %t15, %edge_0 ]
  %p_1_5 = phi i64 [ 0, %edge_0 ]
  %t17 = icmp ugt i64 %p_1_0, 0
  br i1 %t17, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i8 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %t15, %edge_1 ]
  %p_2_5 = phi i64 [ 0, %edge_1 ]
  %t18 = extractvalue %hia.buffer %p_2_3, 1
  %t19 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 7, i64 %t18)
  %t20 = extractvalue { i64, i1 } %t19, 0
  %t21 = extractvalue { i64, i1 } %t19, 1
  %t22 = xor i1 %t21, true
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  br label %edge_4
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i8 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_7 = phi i64 [ 11, %edge_2 ]
  %p_3_8 = phi i64 [ 5, %edge_2 ]
  %p_3_9 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %p_3_10 = phi i64 [ 3, %edge_2 ]
  %p_3_11 = phi i64 [ 5, %edge_2 ]
  %p_3_12 = phi i64 [ 3, %edge_2 ]
  %t24 = extractvalue %hia.buffer %p_3_6, 0
  %t25 = extractvalue %hia.buffer %p_3_6, 1
  %t26 = icmp ult i64 0, %t25
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  %t28 = getelementptr i8, ptr %t24, i64 0
  store i8 %p_3_1, ptr %t28, align 1
  br label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i8 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i8 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_7 = phi i64 [ 11, %edge_3 ]
  %p_4_8 = phi i64 [ 5, %edge_3 ]
  %p_4_9 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  %p_4_10 = phi i64 [ 3, %edge_3 ]
  %p_4_11 = phi i64 [ 5, %edge_3 ]
  %p_4_12 = phi i64 [ 3, %edge_3 ]
  br label %edge_6
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_5 ], [ %p_4_0, %edge_6 ]
  %p_5_1 = phi i8 [ %p_3_1, %edge_5 ], [ %p_4_1, %edge_6 ]
  %p_5_2 = phi i8 [ %p_3_2, %edge_5 ], [ %p_4_2, %edge_6 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_5 ], [ %p_4_3, %edge_6 ]
  %p_5_4 = phi %hia.buffer [ %p_3_4, %edge_5 ], [ %p_4_4, %edge_6 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_5 ], [ %p_4_5, %edge_6 ]
  %p_5_6 = phi %hia.buffer [ %p_3_6, %edge_5 ], [ %p_4_6, %edge_6 ]
  %p_5_7 = phi i64 [ %p_3_7, %edge_5 ], [ %p_4_7, %edge_6 ]
  %p_5_8 = phi i64 [ %p_3_8, %edge_5 ], [ %p_4_8, %edge_6 ]
  %p_5_9 = phi %hia.buffer [ %p_3_9, %edge_5 ], [ %p_4_9, %edge_6 ]
  %p_5_10 = phi i64 [ %p_3_10, %edge_5 ], [ %p_4_10, %edge_6 ]
  %p_5_11 = phi i64 [ %p_3_11, %edge_5 ], [ %p_4_11, %edge_6 ]
  %p_5_12 = phi i64 [ %p_3_12, %edge_5 ], [ %p_4_12, %edge_6 ]
  %t29 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_5_7, i64 %p_5_11)
  %t30 = extractvalue { i64, i1 } %t29, 0
  %t31 = extractvalue { i64, i1 } %t29, 1
  %t32 = xor i1 %t31, true
  br i1 %t32, label %ok_33, label %trap_33
trap_33:
  call void @abort()
  unreachable
ok_33:
  %t34 = extractvalue %hia.buffer %p_5_9, 1
  %t35 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t30, i64 %t34)
  %t36 = extractvalue { i64, i1 } %t35, 0
  %t37 = extractvalue { i64, i1 } %t35, 1
  %t38 = xor i1 %t37, true
  br i1 %t38, label %ok_39, label %trap_39
trap_39:
  call void @abort()
  unreachable
ok_39:
  br label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_0, %edge_7 ]
  %p_6_1 = phi i8 [ %p_2_1, %edge_4 ], [ %p_5_1, %edge_7 ]
  %p_6_2 = phi i8 [ %p_2_2, %edge_4 ], [ %p_5_2, %edge_7 ]
  %p_6_3 = phi %hia.buffer [ %p_2_3, %edge_4 ], [ %p_5_3, %edge_7 ]
  %p_6_4 = phi %hia.buffer [ %p_2_4, %edge_4 ], [ %p_5_4, %edge_7 ]
  %p_6_5 = phi i64 [ %t20, %edge_4 ], [ %t36, %edge_7 ]
  %t40 = icmp ugt i64 %p_6_0, 0
  br i1 %t40, label %edge_8, label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_7_1 = phi i8 [ %p_6_1, %edge_8 ]
  %p_7_2 = phi i8 [ %p_6_2, %edge_8 ]
  %p_7_3 = phi %hia.buffer [ %p_6_3, %edge_8 ]
  %p_7_4 = phi %hia.buffer [ %p_6_4, %edge_8 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t41 = extractvalue %hia.buffer %p_7_3, 0
  %t42 = extractvalue %hia.buffer %p_7_3, 1
  %t43 = icmp ult i64 0, %t42
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = getelementptr i8, ptr %t41, i64 0
  %t46 = load i8, ptr %t45, align 1
  %t47 = zext i8 %t46 to i64
  %t48 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_5, i64 %t47)
  %t49 = extractvalue { i64, i1 } %t48, 0
  %t50 = extractvalue { i64, i1 } %t48, 1
  %t51 = xor i1 %t50, true
  br i1 %t51, label %ok_52, label %trap_52
trap_52:
  call void @abort()
  unreachable
ok_52:
  br label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_9 ]
  %p_8_1 = phi i8 [ %p_6_1, %edge_9 ]
  %p_8_2 = phi i8 [ %p_6_2, %edge_9 ]
  %p_8_3 = phi %hia.buffer [ %p_6_3, %edge_9 ]
  %p_8_4 = phi %hia.buffer [ %p_6_4, %edge_9 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_9 ]
  br label %edge_11
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_10 ], [ %p_8_0, %edge_11 ]
  %p_9_1 = phi i8 [ %p_7_1, %edge_10 ], [ %p_8_1, %edge_11 ]
  %p_9_2 = phi i8 [ %p_7_2, %edge_10 ], [ %p_8_2, %edge_11 ]
  %p_9_3 = phi %hia.buffer [ %p_7_3, %edge_10 ], [ %p_8_3, %edge_11 ]
  %p_9_4 = phi %hia.buffer [ %p_7_4, %edge_10 ], [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i64 [ %t49, %edge_10 ], [ %p_8_5, %edge_11 ]
  %t53 = extractvalue %hia.buffer %p_9_3, 0
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %drop_nonnull_55, label %drop_after_55
drop_nonnull_55:
  call void @free(ptr %t53) nobuiltin
  br label %drop_after_55
drop_after_55:
  %t56 = extractvalue %hia.buffer %p_9_4, 0
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %drop_nonnull_58, label %drop_after_58
drop_nonnull_58:
  call void @free(ptr %t56) nobuiltin
  br label %drop_after_58
drop_after_58:
  ret i64 %p_9_5
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b6
edge_5:
  br label %b5
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b9
edge_11:
  br label %b9
}

define internal i64 @__hia_fn_4(%hia.buffer %p_0_0, i64 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = call %hia.alloc @__hia_allocate(i64 %p_0_1, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 %p_0_1, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ 40, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_4 = phi i64 [ %t1, %edge_0 ]
  %p_1_5 = phi i1 [ %t4, %edge_0 ]
  %p_1_6 = phi %hia.buffer [ %t6, %edge_0 ]
  %p_1_7 = phi i8 [ 1, %edge_0 ]
  %t7 = extractvalue %hia.buffer %p_1_6, 1
  %t8 = extractvalue %hia.buffer %p_1_6, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  call void @free(ptr %t8) nobuiltin
  br label %drop_after_10
drop_after_10:
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_1_2, i64 %p_1_4)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t16 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t12, i64 %t7)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  %t19 = xor i1 %t18, true
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  ret i64 %t17
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ 40, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_4 = phi i64 [ %t1, %edge_1 ]
  %p_2_5 = phi i1 [ %t4, %edge_1 ]
  %p_2_6 = phi %hia.buffer [ %t6, %edge_1 ]
  %p_2_7 = phi i8 [ 1, %edge_1 ]
  %t21 = extractvalue %hia.buffer %p_2_6, 0
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %drop_nonnull_23, label %drop_after_23
drop_nonnull_23:
  call void @free(ptr %t21) nobuiltin
  br label %drop_after_23
drop_after_23:
  %t24 = zext i8 %p_2_7 to i64
  %t25 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_2_2, i64 %t24)
  %t26 = extractvalue { i64, i1 } %t25, 0
  %t27 = extractvalue { i64, i1 } %t25, 1
  %t28 = xor i1 %t27, true
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  ret i64 %t26
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i64 @__hia_fn_5(i64 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 3, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 3, 1
  %t6 = call i64 @__hia_fn_4(%hia.buffer %t5, i64 %p_0_0)
  %t7 = extractvalue %hia.buffer %t5, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  ret i64 %t6
}

define i64 @shared_case(i64 %a0, i8 zeroext %a1, i8 zeroext %a2) {
entry:
  %result = call i64 @__hia_fn_1(i64 %a0, i8 %a1, i8 %a2)
  ret i64 %result
}

define i64 @mutable_case(i64 %a0, i8 zeroext %a1, i64 %a2) {
entry:
  %result = call i64 @__hia_fn_2(i64 %a0, i8 %a1, i64 %a2)
  ret i64 %result
}

define i64 @branch_case(i64 %a0, i8 zeroext %a1, i8 zeroext %a2) {
entry:
  %result = call i64 @__hia_fn_3(i64 %a0, i8 %a1, i8 %a2)
  ret i64 %result
}

define i64 @failure_case(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_5(i64 %a0)
  ret i64 %result
}
