
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[8]; static size_t sizes[8];
static size_t attempts, allocations, frees, live_bytes, peak_bytes, fail_at;
static void *remember(void *p,size_t n){
    if(!p)return p; size_t i=0;while(i<8&&addresses[i])i++;if(i==8)exit(81);
    addresses[i]=p;sizes[i]=n;allocations++;live_bytes+=n;
    if(live_bytes>peak_bytes)peak_bytes=live_bytes;return p;
}
void *__wrap_malloc(size_t n){
    attempts++;if(attempts==fail_at)return NULL;return remember(__real_malloc(n),n);
}
void *__wrap_calloc(size_t n,size_t w){
    attempts++;if(attempts==fail_at)return NULL;return remember(__real_calloc(n,w),n*w);
}
void __wrap_free(void *p){
    if(!p)exit(82);size_t i=0;while(i<8&&addresses[i]!=p)i++;if(i==8)exit(83);
    frees++;live_bytes-=sizes[i];addresses[i]=NULL;__real_free(p);
}
extern uint64_t failure_case(size_t);
int main(int argc,char **argv){
    if(argc!=2)return 84;fail_at=(size_t)strtoull(argv[1],NULL,10);
    size_t value=(size_t)failure_case(7);
    printf("{\"value\":%zu,\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,"
           "\"live_bytes\":%zu,\"peak_bytes\":%zu}\n",value,attempts,allocations,frees,live_bytes,peak_bytes);
    return live_bytes ? 85 : 0;
}
