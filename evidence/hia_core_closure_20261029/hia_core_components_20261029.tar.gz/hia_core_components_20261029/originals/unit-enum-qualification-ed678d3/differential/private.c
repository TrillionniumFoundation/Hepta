#include <stdint.h>
uint64_t error_score(uint32_t);
uint32_t make_phase(uint8_t);
int main(void){return error_score(make_phase(0))!=101;}
