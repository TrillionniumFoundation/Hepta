; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal i64 @__hia_fn_0(i32 %p_0_0) {
b0:
  %t1 = icmp eq i32 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_0, %edge_0 ]
  ret i64 101
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_0, %edge_1 ]
  %t2 = icmp eq i32 %p_2_1, 1
  br i1 %t2, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i32 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_2 ]
  ret i64 202
b4:
  %p_4_0 = phi i32 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_3 ]
  %t3 = icmp eq i32 %p_4_1, 2
  br i1 %t3, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i32 [ %p_4_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_4 ]
  ret i64 303
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_5 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define internal i64 @__hia_fn_1(i32 %p_0_0) {
b0:
  %t1 = icmp eq i32 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_0, %edge_0 ]
  ret i64 4
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_0, %edge_1 ]
  %t2 = icmp eq i32 %p_2_1, 1
  br i1 %t2, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i32 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_2 ]
  ret i64 17
b4:
  %p_4_0 = phi i32 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_3 ]
  %t3 = icmp eq i32 %p_4_1, 2
  br i1 %t3, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i32 [ %p_4_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_4 ]
  ret i64 29
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_5 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define internal i32 @__hia_fn_2(i32 %p_0_0) {
b0:
  %t1 = icmp eq i32 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_0, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_0, %edge_1 ]
  %t2 = icmp eq i32 %p_2_1, 1
  br i1 %t2, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi i32 [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_3 ]
  br label %edge_5
b4:
  %p_4_0 = phi i32 [ %p_2_0, %edge_4 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_4 ]
  %t3 = icmp eq i32 %p_4_1, 2
  br i1 %t3, label %edge_6, label %edge_7
b5:
  %p_5_0 = phi i32 [ %p_4_0, %edge_6 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_6 ]
  br label %edge_8
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_7 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_7 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i32 [ 1, %edge_2 ], [ 2, %edge_5 ], [ 0, %edge_8 ]
  ret i32 %p_7_0
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b7
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b7
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
}

define internal i64 @__hia_fn_3(i64 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_11(i32 0)
  br label %edge_0
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i32 [ %t1, %edge_0 ], [ %t3, %edge_3 ]
  %p_1_2 = phi i64 [ 0, %edge_0 ], [ %t6, %edge_3 ]
  %p_1_3 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_3, %edge_3 ]
  %p_1_4 = phi i64 [ 0, %edge_0 ], [ %t11, %edge_3 ]
  %t2 = icmp ult i64 %p_1_4, %p_1_3
  br i1 %t2, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_1_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_1_4, %edge_1 ]
  %t3 = call i32 @__hia_fn_2(i32 %p_2_1)
  %t4 = call i64 @__hia_fn_1(i32 %t3)
  %t5 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_2_2, i64 %t4)
  %t6 = extractvalue { i64, i1 } %t5, 0
  %t7 = extractvalue { i64, i1 } %t5, 1
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_2_4, i64 1)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  br label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  ret i64 %p_3_2
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal i64 @__hia_fn_4(i64 %p_0_0) {
b0:
  br label %edge_0
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i32 [ 0, %edge_0 ], [ %t2, %edge_3 ]
  %p_1_2 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_2, %edge_3 ]
  %p_1_3 = phi i32 [ 0, %edge_0 ], [ %p_2_3, %edge_3 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_4, %edge_3 ]
  %p_1_5 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_5, %edge_3 ]
  %p_1_6 = phi i64 [ 0, %edge_0 ], [ %t4, %edge_3 ]
  %t1 = icmp ult i64 %p_1_6, %p_1_5
  br i1 %t1, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %p_2_3 = phi i32 [ %p_1_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_1_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_1_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_1_6, %edge_1 ]
  %t2 = call i32 @__hia_fn_2(i32 %p_2_1)
  %t3 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_2_6, i64 1)
  %t4 = extractvalue { i64, i1 } %t3, 0
  %t5 = extractvalue { i64, i1 } %t3, 1
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  br label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_6, %edge_2 ]
  %t8 = call i64 @__hia_fn_1(i32 %p_3_1)
  %t9 = call i64 @__hia_fn_1(i32 %p_3_3)
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t8, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t11, i64 %p_3_2)
  %t16 = extractvalue { i64, i1 } %t15, 0
  %t17 = extractvalue { i64, i1 } %t15, 1
  %t18 = xor i1 %t17, true
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  ret i64 %t16
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal i32 @__hia_fn_5(i8 %p_0_0) {
b0:
  %t1 = icmp eq i8 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  ret i32 0
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %t2 = icmp eq i8 %p_2_0, 1
  br i1 %t2, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_2 ]
  ret i32 1
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_3 ]
  ret i32 2
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal { i32, i32 } @__hia_fn_6(i32 %p_0_0, i8 %p_0_1) {
b0:
  %t1 = call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %p_0_0, i32 1)
  %t2 = extractvalue { i32, i1 } %t1, 0
  %t3 = extractvalue { i32, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = call i32 @__hia_fn_5(i8 %p_0_1)
  %t7 = insertvalue { i32, i32 } zeroinitializer, i32 %t6, 0
  %t8 = insertvalue { i32, i32 } %t7, i32 %t2, 1
  ret { i32, i32 } %t8
}

define internal i64 @__hia_fn_7(i8 %p_0_0) {
b0:
  %t1 = call { i32, i32 } @__hia_fn_6(i32 0, i8 %p_0_0)
  %t2 = extractvalue { i32, i32 } %t1, 0
  %t3 = extractvalue { i32, i32 } %t1, 1
  %t4 = icmp eq i32 %t2, 0
  br i1 %t4, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %t3, %edge_0 ]
  %p_1_2 = phi i64 [ 0, %edge_0 ]
  %p_1_3 = phi i32 [ %t2, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %t3, %edge_1 ]
  %p_2_2 = phi i64 [ 0, %edge_1 ]
  %p_2_3 = phi i32 [ %t2, %edge_1 ]
  %t5 = icmp eq i32 %p_2_3, 1
  br i1 %t5, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i64 [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i32 [ %p_2_3, %edge_3 ]
  br label %edge_5
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_4 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_4_2 = phi i64 [ %p_2_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_2_3, %edge_4 ]
  %t6 = icmp eq i32 %p_4_3, 2
  br i1 %t6, label %edge_6, label %edge_7
b5:
  %p_5_0 = phi i8 [ %p_4_0, %edge_6 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_6 ]
  %p_5_2 = phi i64 [ %p_4_2, %edge_6 ]
  %p_5_3 = phi i32 [ %p_4_3, %edge_6 ]
  br label %edge_8
b6:
  %p_6_0 = phi i8 [ %p_4_0, %edge_7 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_7 ]
  %p_6_2 = phi i64 [ %p_4_2, %edge_7 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_7 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i8 [ %p_1_0, %edge_2 ], [ %p_3_0, %edge_5 ], [ %p_5_0, %edge_8 ]
  %p_7_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_3_1, %edge_5 ], [ %p_5_1, %edge_8 ]
  %p_7_2 = phi i64 [ 4, %edge_2 ], [ 17, %edge_5 ], [ 29, %edge_8 ]
  %t7 = zext i32 %p_7_1 to i64
  %t8 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %t7, i64 1000)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t9, i64 %p_7_2)
  %t14 = extractvalue { i64, i1 } %t13, 0
  %t15 = extractvalue { i64, i1 } %t13, 1
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  ret i64 %t14
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b7
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b7
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
}

define internal i64 @__hia_fn_8() {
b0:
  %t1 = icmp eq i32 0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i32 [ 0, %edge_0 ]
  ret i64 99
b2:
  %p_2_0 = phi i32 [ 0, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i1, %hia.buffer, i32, i64, i32 } @__hia_fn_9(i64 %p_0_0, i8 %p_0_1) {
b0:
  %t1 = icmp eq i64 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = insertvalue %hia.buffer %t3, i64 0, 1
  %t7 = insertvalue { i1, %hia.buffer, i32, i64, i32 } zeroinitializer, i1 false, 0
  %t8 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t7, %hia.buffer %t6, 1
  %t9 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t8, i32 0, 2
  %t10 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t9, i64 0, 3
  %t11 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t10, i32 0, 4
  ret { i1, %hia.buffer, i32, i64, i32 } %t11
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_0_1, %edge_1 ]
  %t12 = icmp ugt i64 %p_2_0, 8
  br i1 %t12, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_2_1, %edge_2 ]
  %t13 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t14 = extractvalue %hia.alloc %t13, 0
  %t15 = extractvalue %hia.alloc %t13, 1
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  %t17 = insertvalue %hia.buffer %t14, i64 0, 1
  %t18 = insertvalue { i1, %hia.buffer, i32, i64, i32 } zeroinitializer, i1 false, 0
  %t19 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t18, %hia.buffer %t17, 1
  %t20 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t19, i32 0, 2
  %t21 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t20, i64 0, 3
  %t22 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t21, i32 1, 4
  ret { i1, %hia.buffer, i32, i64, i32 } %t22
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i8 [ %p_2_1, %edge_3 ]
  %t23 = call %hia.alloc @__hia_allocate(i64 %p_4_0, i1 true)
  %t24 = extractvalue %hia.alloc %t23, 0
  %t25 = extractvalue %hia.alloc %t23, 1
  %t26 = select i1 %t25, i64 %p_4_0, i64 0
  %t27 = insertvalue %hia.buffer %t24, i64 %t26, 1
  br i1 %t25, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_4_0, %edge_4 ]
  %p_5_1 = phi i8 [ %p_4_1, %edge_4 ]
  %p_5_2 = phi i1 [ %t25, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %t27, %edge_4 ]
  %p_5_4 = phi i8 [ 1, %edge_4 ]
  %t28 = extractvalue %hia.buffer %p_5_3, 0
  %t29 = extractvalue %hia.buffer %p_5_3, 1
  %t30 = icmp ult i64 0, %t29
  br i1 %t30, label %ok_31, label %trap_31
trap_31:
  call void @abort()
  unreachable
ok_31:
  %t32 = getelementptr i8, ptr %t28, i64 0
  store i8 %p_5_1, ptr %t32, align 1
  %t33 = insertvalue { i1, %hia.buffer, i32, i64, i32 } zeroinitializer, i1 true, 0
  %t34 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t33, %hia.buffer %p_5_3, 1
  %t35 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t34, i32 1, 2
  %t36 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t35, i64 40, 3
  %t37 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t36, i32 0, 4
  ret { i1, %hia.buffer, i32, i64, i32 } %t37
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_5 ]
  %p_6_1 = phi i8 [ %p_4_1, %edge_5 ]
  %p_6_2 = phi i1 [ %t25, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %t27, %edge_5 ]
  %p_6_4 = phi i8 [ 1, %edge_5 ]
  %t38 = extractvalue %hia.buffer %p_6_3, 0
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %drop_nonnull_40, label %drop_after_40
drop_nonnull_40:
  call void @free(ptr %t38) nobuiltin
  br label %drop_after_40
drop_after_40:
  %t41 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t42 = extractvalue %hia.alloc %t41, 0
  %t43 = extractvalue %hia.alloc %t41, 1
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = insertvalue %hia.buffer %t42, i64 0, 1
  %t46 = insertvalue { i1, %hia.buffer, i32, i64, i32 } zeroinitializer, i1 false, 0
  %t47 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t46, %hia.buffer %t45, 1
  %t48 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t47, i32 0, 2
  %t49 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t48, i64 0, 3
  %t50 = insertvalue { i1, %hia.buffer, i32, i64, i32 } %t49, i32 2, 4
  ret { i1, %hia.buffer, i32, i64, i32 } %t50
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define internal i64 @__hia_fn_10(i64 %p_0_0, i8 %p_0_1, i8 %p_0_2) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 3, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 3, 1
  %t6 = call { i1, %hia.buffer, i32, i64, i32 } @__hia_fn_9(i64 %p_0_0, i8 %p_0_1)
  %t7 = extractvalue { i1, %hia.buffer, i32, i64, i32 } %t6, 0
  %t8 = extractvalue { i1, %hia.buffer, i32, i64, i32 } %t6, 1
  %t9 = extractvalue { i1, %hia.buffer, i32, i64, i32 } %t6, 2
  %t10 = extractvalue { i1, %hia.buffer, i32, i64, i32 } %t6, 3
  %t11 = extractvalue { i1, %hia.buffer, i32, i64, i32 } %t6, 4
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i8 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i1 [ %t7, %edge_0 ]
  %p_1_5 = phi %hia.buffer [ %t8, %edge_0 ]
  %p_1_6 = phi i32 [ %t9, %edge_0 ]
  %p_1_7 = phi i64 [ %t10, %edge_0 ]
  %p_1_8 = phi i32 [ %t11, %edge_0 ]
  %t12 = icmp ne i8 %p_1_2, 0
  br i1 %t12, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i8 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i1 [ %t7, %edge_1 ]
  %p_2_5 = phi %hia.buffer [ %t8, %edge_1 ]
  %p_2_6 = phi i32 [ %t9, %edge_1 ]
  %p_2_7 = phi i64 [ %t10, %edge_1 ]
  %p_2_8 = phi i32 [ %t11, %edge_1 ]
  %t13 = extractvalue %hia.buffer %p_2_5, 0
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %drop_nonnull_15, label %drop_after_15
drop_nonnull_15:
  call void @free(ptr %t13) nobuiltin
  br label %drop_after_15
drop_after_15:
  %t16 = call i64 @__hia_fn_0(i32 %p_2_8)
  %t17 = extractvalue %hia.buffer %p_2_3, 0
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %drop_nonnull_19, label %drop_after_19
drop_nonnull_19:
  call void @free(ptr %t17) nobuiltin
  br label %drop_after_19
drop_after_19:
  ret i64 %t16
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i8 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_1_5, %edge_2 ]
  %p_3_5 = phi i32 [ %p_1_6, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_7, %edge_2 ]
  %t20 = extractvalue %hia.buffer %p_3_4, 0
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %drop_nonnull_22, label %drop_after_22
drop_nonnull_22:
  call void @free(ptr %t20) nobuiltin
  br label %drop_after_22
drop_after_22:
  %t23 = extractvalue %hia.buffer %p_3_3, 0
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %drop_nonnull_25, label %drop_after_25
drop_nonnull_25:
  call void @free(ptr %t23) nobuiltin
  br label %drop_after_25
drop_after_25:
  ret i64 900
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i8 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i8 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_1_5, %edge_3 ]
  %p_4_5 = phi i32 [ %p_1_6, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_7, %edge_3 ]
  %t26 = extractvalue %hia.buffer %p_4_4, 1
  %t27 = extractvalue %hia.buffer %p_4_4, 0
  %t28 = extractvalue %hia.buffer %p_4_4, 1
  %t29 = icmp ult i64 0, %t28
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  %t31 = getelementptr i8, ptr %t27, i64 0
  %t32 = load i8, ptr %t31, align 1
  %t33 = zext i8 %t32 to i64
  %t34 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t26, i64 %t33)
  %t35 = extractvalue { i64, i1 } %t34, 0
  %t36 = extractvalue { i64, i1 } %t34, 1
  %t37 = xor i1 %t36, true
  br i1 %t37, label %ok_38, label %trap_38
trap_38:
  call void @abort()
  unreachable
ok_38:
  %t39 = call i64 @__hia_fn_1(i32 %p_4_5)
  %t40 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t35, i64 %t39)
  %t41 = extractvalue { i64, i1 } %t40, 0
  %t42 = extractvalue { i64, i1 } %t40, 1
  %t43 = xor i1 %t42, true
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t41, i64 %p_4_6)
  %t46 = extractvalue { i64, i1 } %t45, 0
  %t47 = extractvalue { i64, i1 } %t45, 1
  %t48 = xor i1 %t47, true
  br i1 %t48, label %ok_49, label %trap_49
trap_49:
  call void @abort()
  unreachable
ok_49:
  %t50 = extractvalue %hia.buffer %p_4_4, 0
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %drop_nonnull_52, label %drop_after_52
drop_nonnull_52:
  call void @free(ptr %t50) nobuiltin
  br label %drop_after_52
drop_after_52:
  %t53 = extractvalue %hia.buffer %p_4_3, 0
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %drop_nonnull_55, label %drop_after_55
drop_nonnull_55:
  call void @free(ptr %t53) nobuiltin
  br label %drop_after_55
drop_after_55:
  ret i64 %t46
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal i32 @__hia_fn_11(i32 %p_0_0) {
b0:
  ret i32 %p_0_0
}

define i64 @cycle_case(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_3(i64 %a0)
  ret i64 %result
}

define i64 @record_case(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_4(i64 %a0)
  ret i64 %result
}

define i64 @once_case(i8 zeroext %a0) {
entry:
  %result = call i64 @__hia_fn_7(i8 %a0)
  ret i64 %result
}

define i64 @only_case() {
entry:
  %result = call i64 @__hia_fn_8()
  ret i64 %result
}

define i64 @packet_case(i64 %a0, i8 zeroext %a1, i8 zeroext %a2) {
entry:
  %result = call i64 @__hia_fn_10(i64 %a0, i8 %a1, i8 %a2)
  ret i64 %result
}
