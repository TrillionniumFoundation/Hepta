import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/b484d4086829/hepta-core')
sys.path.insert(0, str(ROOT))
from hepta.backend import compile_rust, emit_rust
from hepta.checker import check
from hepta.hia_program_runtime import execute_program
from hepta.hia_program_source import lower_source
from hepta.hia_program_llvm import build_program_native
from hepta.parser import parse
from hepta.resource_lowering import lower_resource_ir

OUT = Path('/workspace/scratch/b484d4086829/localview-independent-review')
OUT.mkdir(exist_ok=False)
HEADER = "struct View<'a>{data:read 'a [u8],tag:u64} struct Edit<'a>{data:mut 'a [u8],tag:u64}\n"

def source(body, mutable=False):
    return HEADER + f"fn inner(b:{'mut' if mutable else 'read'} [u8],n:u8)->u64 effects{{panic,write}}{{" + body + "}" + f'''
export "C" fn probe(n:u8)->u64 effects{{alloc,block,panic,write}}{{
let mut b=buffer(1);b[0]=5;let result=inner({'mut' if mutable else 'read'} b,n);drop(move b);return result;
}}'''

positives = {
 'shared_alias_loop_labels': (source('''
    let a=View{data:read b,tag:11}; let mut z=a; z.tag=17; let mut sum:u64=0;
    for i in 0..n as usize {let mut t=z; t.tag=t.tag+i as u64;sum=sum+t.tag;
        if i==1 {let u=a;sum=sum+u.tag;}}
    return a.tag+z.tag+sum+a.data[0] as u64;'''),
    lambda n: 33+n*17+n*(n-1)//2+(11 if n>1 else 0)),
 'mutable_two_moves_branch': (source('''
    let first=Edit{data:mut b,tag:3};let second=move first;
    if n==0 {let mut last=move second;last.data[0]=7;drop(move last);}
    else {let mut last=move second;last.data[0]=9;drop(move last);}
    return b[0] as u64;''', True),lambda n:7 if n==0 else 9),
 'shared_alias_early_loop_return': (source('''
    let a=View{data:read b,tag:11};let mut answer:u64=0;
    for i in 0..n as usize{let copied=a;answer=answer+copied.tag;
      if i==1{return answer+copied.data[0] as u64;}}
    return answer+a.tag;'''),lambda n:27 if n>=2 else 11+n*11),
 'mutable_view_across_loop': (source('''
    let mut view=Edit{data:mut b,tag:2};
    for i in 0..n as usize{view.tag=view.tag+1;view.data[0]=wrapping_add(view.data[0],1);}
    let label=view.tag;drop(move view);return b[0] as u64+label;''',True),lambda n:7+2*n),
 'shared_alias_branch_mutable_labels': (source('''
    let mut first=View{data:read b,tag:7};let mut second=first;
    if n==0{first.tag=13;let alias=second;assert(alias.tag==7);}
    else{second.tag=17;let alias=first;assert(alias.tag==7);}
    return first.tag+second.tag+first.data[0] as u64;'''),lambda n:25 if n==0 else 29),
}
negatives = {
 'mutable_copy':source('let first=Edit{data:mut b,tag:3};let copy=first;drop(move first);drop(move copy);return 0;',True),
 'mutable_use_after_move':source('let first=Edit{data:mut b,tag:3};let last=move first;let n=first.tag;drop(move last);return n;',True),
 'mutable_double_drop':source('let first=Edit{data:mut b,tag:3};drop(move first);drop(move first);return 0;',True),
 'mutable_missing_branch_drop':source('let first=Edit{data:mut b,tag:3};if n==0{drop(move first);}return 0;',True),
 'parent_write_while_shared_alias_live':source('let first=View{data:read b,tag:3};let copied=first;b[0]=7;return copied.tag;',True),
 'parent_read_while_mutable_live':source('let first=Edit{data:mut b,tag:3};let x=b[0];drop(move first);return x as u64;',True),
 'mutable_second_overlapping_origin':source('let first=Edit{data:mut b,tag:3};let second=Edit{data:mut b,tag:4};drop(move first);drop(move second);return 0;',True),
 'escaped_stored_view':HEADER+"fn escape<'a>(b:read 'a [u8])->View<'a> effects{}{return View{data:read b,tag:7};}",
 'stored_call_return':HEADER+"fn get(b:read [u8])->read [u8] from b effects{}{return read b;}fn inner(b:read [u8])->u64 effects{}{let view=View{data:get(read b),tag:7};return view.tag;}",
}
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before=digest(ROOT/'hepta/hia_program_source.py')
report={'schema':'hepta.independent-local-view-review.v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'source_sha256_before':before,'positive':[],'negative':[],'scope':['shared aliases across nested lexical scopes and CFG/loop phis','independent scalar label copies','affine mutable move/drop on every path','normal cleanup versus rejected origin access/escape'],
        'claims':{'formal_refinement_proved':False,'whole_language_soundness_proved':False,'all_blockers_closed':False}}
for name,(text,expected) in positives.items():
    directory=OUT/name;directory.mkdir();(directory/'input.hepta').write_text(text)
    row={'case':name,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'observations':[]}
    try:
        ast=parse(text);checked=check(ast)
        if not checked.ok:raise ValueError('frontend diagnostics: '+str([d.message for d in checked.diagnostics]))
        graph=lower_resource_ir(ast,checked);row['resource_schema']=graph['schema']
        generated=emit_rust(ast,checked,crate_type='cdylib');(directory/'source.rs').write_text(generated)
        reference=compile_rust(generated,crate_type='cdylib',output=directory/'reference.so',linker=os.environ['CLANG'])
        if not reference['ok']:raise ValueError('Rust reference failed: '+str(reference))
        original=ctypes.CDLL(str(directory/'reference.so')).probe;original.argtypes=[ctypes.c_uint8];original.restype=ctypes.c_uint64
        row['rust_reference']=reference
        for schema in ('hepta.hia.program.v1','hepta.hia.program.v8'):
            core=lower_source(text,core_schema=schema);(directory/(schema+'.json')).write_bytes(core.canonical_bytes)
            native=build_program_native(core.canonical_bytes,directory/(schema+'.so'),clang=os.environ['CLANG'])
            if not native['ok']:raise ValueError('LLVM build failed: '+str(native))
            compiled=ctypes.CDLL(str(directory/(schema+'.so'))).probe;compiled.argtypes=[ctypes.c_uint8];compiled.restype=ctypes.c_uint64
            for n in (0,1,2,3):
                vm=execute_program(core,'probe',[n]);want=expected(n)
                actual={'schema':schema,'n':n,'expected':want,'vm':vm['result'],'source_rust':original(n),'core_llvm':compiled(n),'resources':vm['resources']}
                row['observations'].append(actual)
                if not want==actual['vm']==actual['source_rust']==actual['core_llvm']:raise ValueError('semantic value mismatch')
                if any(vm['resources'][k] for k in ('live_bytes','live_owners','live_local_loans')):raise ValueError('normal return leaked resources')
        row['status']='passed'
    except Exception as exc:row.update(status='failed',error=f'{type(exc).__name__}: {exc}')
    report['positive'].append(row);print(name,row['status'],row.get('error',''),flush=True)
for name,text in negatives.items():
    row={'case':name,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'results':[]}
    for schema in ('hepta.hia.program.v1','hepta.hia.program.v8'):
        try:core=lower_source(text,core_schema=schema);row['results'].append({'schema':schema,'rejected':False,'core_sha256':core.sha256})
        except Exception as exc:row['results'].append({'schema':schema,'rejected':True,'error':f'{type(exc).__name__}: {exc}'})
    row['status']='passed' if all(x['rejected'] for x in row['results']) else 'failed'
    report['negative'].append(row);print(name,row['status'],flush=True)
report['source_sha256_after']=digest(ROOT/'hepta/hia_program_source.py')
report['source_unchanged']=before==report['source_sha256_after']
report['positive_cases']=len(report['positive']);report['negative_cases']=len(report['negative'])
report['native_value_observations']=sum(len(row['observations']) for row in report['positive'])
report['passed']=report['source_unchanged'] and all(row['status']=='passed' for row in report['positive']+report['negative'])
(OUT/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':report['passed'],'review':str(OUT/'review.json'),'head':report['head'],'source_sha256':before}))
