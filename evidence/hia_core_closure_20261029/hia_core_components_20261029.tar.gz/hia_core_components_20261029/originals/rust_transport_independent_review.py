"""Independent reproduction of exited-leader orphan and success cleanup."""
from pathlib import Path
from hashlib import sha256
import ctypes
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch

BASE = Path('/workspace/scratch/b484d4086829')
ROOT = BASE / 'hepta-transport'
sys.path.insert(0, str(ROOT))
from hepta.hia_rust_crosscheck import _run_bounded_shadow

def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(ROOT), *args]).decode().strip()

# This standalone audit process adopts its fixture's orphan so it can record
# an actual exit status and reap it; it does not alter the test host's policy.
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), 'independent audit child subreaper failed')

source_names = ['hepta/hia_rust_crosscheck.py', 'tests/test_hia_rust_transport_lifecycle.py',
                'docs/HIA_RUST_SHADOW_PROCESS_OWNERSHIP.md']
before = {name: digest(ROOT / name) for name in source_names}
report = {'scope': 'Trusted pinned child and descendants remaining in its fresh process group; excludes hostile process-group escape, concurrent external reapers, and uninterruptible kernel waits.',
          'head': git('rev-parse', 'HEAD'), 'clean_before': not git('status', '--porcelain'),
          'source_sha256': before,
          'original_failure': json.loads((BASE / 'rust-transport-orphan-review.json').read_text()),
          'controls': {}}

producer = r'''
import json, os, pathlib, sys, time
record, marker, mode = sys.argv[1:]
child = os.fork()
if child == 0:
    if mode == 'success':
        for fd in (0, 1, 2):
            os.close(fd)
    time.sleep(.6)
    pathlib.Path(marker).write_text('descendant survived')
    os._exit(0)
pathlib.Path(record).write_text(json.dumps({'leader':os.getpid(),'child':child,'group':os.getpgrp()}))
os.write(1, b'parent exited\n')
os._exit(0)
'''
real_killpg = os.killpg
for mode in ['inherited_pipe_timeout', 'success']:
    with tempfile.TemporaryDirectory(prefix='hepta-independent-shadow-orphan-') as tmp:
        directory = Path(tmp)
        record, marker = directory / 'identity.json', directory / 'survived.txt'
        observed = {'signals': []}
        def kill_owned(pgid, sig):
            status = os.waitid(os.P_PID, pgid, os.WEXITED | os.WNOWAIT | os.WNOHANG)
            observed['signals'].append({'pgid': pgid, 'signal': int(sig),
                                        'leader_still_waitable': True,
                                        'leader_exited_but_unreaped': status is not None})
            return real_killpg(pgid, sig)
        started = time.monotonic()
        try:
            with patch('hepta.hia_rust_crosscheck.os.killpg', side_effect=kill_owned):
                stdout, stderr, returncode = _run_bounded_shadow(
                    [sys.executable, '-c', producer, str(record), str(marker), mode], b'', .15)
                observed.update(stdout=stdout.decode(), stderr=stderr.decode(), returncode=returncode)
        except Exception as exc:
            observed.update(error_type=type(exc).__name__, error=str(exc))
        observed['elapsed_seconds'] = time.monotonic() - started
        identity = json.loads(record.read_text())
        observed['identity'] = identity
        try:
            os.waitpid(identity['leader'], os.WNOHANG)
            observed['leader_reaped'] = False
        except ChildProcessError:
            observed['leader_reaped'] = True
        deadline = time.monotonic() + 2
        observed['descendant_exit_code'] = None
        while time.monotonic() < deadline:
            child, status = os.waitpid(identity['child'], os.WNOHANG)
            if child:
                observed['descendant_exit_code'] = os.waitstatus_to_exitcode(status)
                break
            time.sleep(.005)
        if observed['descendant_exit_code'] is None:
            os.kill(identity['child'], signal.SIGKILL)
            os.waitpid(identity['child'], 0)
        observed['descendant_wrote_survival_marker'] = marker.exists()
        observed['passed'] = (
            observed['leader_reaped'] and observed['descendant_exit_code'] == -signal.SIGKILL
            and len(observed['signals']) == 1 and observed['signals'][0]['leader_exited_but_unreaped']
            and observed['signals'][0]['pgid'] == identity['leader'] == identity['group']
            and not observed['descendant_wrote_survival_marker']
            and (observed.get('error_type') == 'HIARustCrosscheckRejected'
                 if mode == 'inherited_pipe_timeout' else observed.get('returncode') == 0))
        report['controls'][mode] = observed

report['clean_after'] = not git('status', '--porcelain')
report['source_unchanged'] = before == {name: digest(ROOT / name) for name in source_names}
report['checks_passed'] = (all(x['passed'] for x in report['controls'].values())
                           and report['clean_before'] and report['clean_after'] and report['source_unchanged'])
destination = BASE / 'rust-transport-independent-review.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if not report['checks_passed']:
    raise SystemExit(1)
