"""Retain completed Hepta component evidence; never execute qualifications."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/b484d4086829')
REPO = ROOT / 'hepta-live'  # Read Git objects only; do not touch the active final-run tree.
STAGE = ROOT / 'evidence-staging/hia_core_closure_20261029'
PAYLOAD = STAGE / 'hia_core_components_20261029'
ARCHIVE = STAGE / 'hia_core_components_20261029.tar.gz'
WHEN = datetime.now(timezone.utc).isoformat()
DIRECTORIES = (
    'core-qualification-b20b1da', 'transport-qualification-2c8785a',
    'unit-enum-qualification-ed678d3', 'rust-bound-depth-d62b165',
    'localview-independent-review', 'unit-enum-independent-review',
    'unit-enum-independent-buffer-review', 'rust-execution-evidence',
    'migration-evidence', 'windows-cpp-failure-evidence', 'ci-wiring-evidence',
    'final-qualification-a9e22f9', 'stream-gate-development',
    'stream-gate-development-v2', 'stream-gate-development-v3',
    'baseline-safety', 'combined-safety-development', 'a9-shadow-build',
)
ROOT_FILES = (
    'a9-shadow-cache-retention.json', 'baseline-matrix-reduction.json',
    'baseline-safety.stderr', 'baseline-safety.stdout', 'ci-initial-a9e22f9.json',
    'collect-core-qualification.py', 'collect-transport-qualification.py',
    'collect-unit-enum-qualification.py', 'combined-safety-development.stderr',
    'combined-safety-development.stdout', 'component-retention.json',
    'component-sources.bundle', 'component-sources-v2.bundle',
    'core-closure-state-20261029.json', 'core-regression-development.log',
    'final-control-development.stderr.log', 'final-control-development.stdout.log',
    'final-control-static-review.json', 'final-local-source.json',
    'final-safety-input-controls.stderr.log', 'final-safety-input-controls.stdout.log',
    'integrated-git-controls-v2.stderr', 'integrated-git-controls-v2.stdout',
    'integrated-git-replacement-review.json', 'integrated-inputs-independent-review.json',
    'integrated-inputs-independent-tests.log', 'integrated-protocol-controls.stderr',
    'integrated-protocol-controls.stdout', 'integrated_inputs_independent_review.py',
    'localview-independent-focused.py', 'localview-independent-review.py',
    'pre-freeze-controls.stderr', 'pre-freeze-controls.stdout',
    'review-final-control-static.py', 'round5-env.sh',
    'rust-bound-depth-independent-review.json', 'rust-bound-depth-independent-review.log',
    'rust-bound-execution-independent-review.json', 'rust-transport-independent-review.json',
    'rust-transport-orphan-review.json', 'rust_bound_depth_independent_review.py',
    'rust_execution_independent_review.py', 'rust_transport_independent_review.py',
    'safety-protocol-independent-review.json', 'safety-protocol-independent-tests.log',
    'safety-protocol-tests-v2.stderr', 'safety-protocol-tests-v2.stdout',
    'safety-protocol-tests.stderr', 'safety-protocol-tests.stdout',
    'safety_protocol_independent_review.py', 'transport-lifecycle-before.log',
    'transport-lifecycle-development.log', 'transport-regression-development.log',
    'unit-enum-independent-buffer.stderr.log', 'unit-enum-independent-buffer.stdout.log',
    'unit-enum-independent-review.initial.py', 'unit-enum-independent-review.py',
    'unit-enum-independent-summary.json', 'unit-enum-independent.stderr.log',
    'unit-enum-independent.stdout.log', 'unit-enum-native-development.log',
    'unit-enum-python-development.log', 'unit-enum-regression-development.log',
    'prepare-component-archive.py',
)
ALIASES = {
    'unit-enum-independent-review/shadow': 'a9-shadow-build/hia-core-shadow',
    'unit-enum-independent-buffer-review/shadow': 'a9-shadow-build/hia-core-shadow',
}
SPECIAL_OMISSIONS = {
    'a9-shadow-binary-before-cache-cleanup': 'Unexecuted cache-relocation copy; no qualification relies on this copy. The separately rebuilt and actually executed a9-shadow-build/hia-core-shadow is retained.',
    'component-evidence.tar.gz': 'Superseded aggregate archive. Its original payload, original retention manifest and original source bundle are retained individually.',
    'run-final-qualification.sh': 'Final-public-source driver belongs to the separate final-run archive; it is not a component qualification input.',
}
PATTERNS = {
    'private_key_block': rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
    'github_access_token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
    'aws_access_key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'slack_access_token': rb'\bxox[baprs]-[A-Za-z0-9-]{20,}\b',
    'provider_secret_key': rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b',
    'literal_authorization': rb'(?i)authorization\s*[:=]\s*[\"\x27]?(?:bearer|basic)\s+[A-Za-z0-9+/=_-]{24,}',
    'credential_in_url': rb'https?://[^\s/:@<>]+:[A-Za-z0-9+/=_-]{12,}@',
    'literal_secret_assignment': rb'(?i)[\"\x27]?(?:password|client_secret|api_key|aws_secret_access_key|access_token)[\"\x27]?\s*[:=]\s*[\"\x27][A-Za-z0-9+/=_-]{24,}[\"\x27]',
    'jwt_value': rb'\beyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\b',
}
REGEX = {name: re.compile(pattern) for name, pattern in PATTERNS.items()}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args], env=env)


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def scan(data, source):
    # Never expose matched bytes or credential values in output or records.
    return [{'source': source, 'category': name, 'count': len(matches)}
            for name, expression in REGEX.items()
            if (matches := list(expression.finditer(data)))]


assert not PAYLOAD.exists() and not ARCHIVE.exists(), 'Refuse to replace a prior archive.'
selected = {ROOT / name for name in ROOT_FILES}
for name in DIRECTORIES:
    directory = ROOT / name
    assert directory.is_dir(), name
    for path in directory.rglob('*'):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            selected.add(path)
assert all(path.is_file() and not path.is_symlink() for path in selected)

old = json.loads((ROOT / 'component-retention.json').read_text())
old_validation = []
for item in old['files']:
    path = ROOT / item['path']
    data = path.read_bytes()
    assert len(data) == item['bytes'] and digest(data) == item['sha256'], item['path']
    assert path in selected, 'old record missing from selection: ' + item['path']
    old_validation.append(item['path'])

bundle_bytes = (ROOT / 'component-sources-v2.bundle').read_bytes()
header = bundle_bytes.split(b'\n\n', 1)[0].decode().splitlines()
prerequisites = [line[1:].split(' ', 1)[0] for line in header if line.startswith('-')]
bundle_refs = [{'commit': line.split(' ', 1)[0], 'ref': line.split(' ', 1)[1]}
               for line in header if re.match(r'^[0-9a-f]{40} ', line)]
revisions = [item['commit'] for item in bundle_refs] + ['^' + value for value in prerequisites]
commits = git('rev-list', '--reverse', '--topo-order', *revisions).decode().splitlines()
objects = git('rev-list', '--objects', '--no-object-names', *revisions).decode().splitlines()
findings = []
object_scan = []
for oid in sorted(set(objects)):
    kind = git('cat-file', '-t', oid).decode().strip()
    data = git('cat-file', kind, oid)
    findings.extend(scan(data, 'git-object:' + oid))
    object_scan.append({'oid': oid, 'type': kind, 'bytes': len(data), 'sha256': digest(data)})

snapshots = []
commit_records = []
for commit in commits:
    fields = git('show', '-s', '--format=%H%n%T%n%P%n%s', commit).decode().splitlines()
    commit_records.append({'commit': fields[0], 'tree': fields[1], 'parents': fields[2].split(), 'subject': fields[3]})
    names = git('diff-tree', '--root', '--no-commit-id', '--no-renames', '--diff-filter=ACMT', '--name-only', '-r', '-z', commit).decode().split('\0')
    for name in filter(None, names):
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        oid = git('rev-parse', commit + ':' + name).decode().strip()
        kind = git('cat-file', '-t', oid).decode().strip()
        assert kind == 'blob', (commit, name, kind)
        data = git('cat-file', 'blob', oid)
        snapshots.append((commit, name, oid, data))

original_data = {}
for path in sorted(selected | {ROOT / name for name in SPECIAL_OMISSIONS}):
    data = path.read_bytes()
    original_data[path] = data
    findings.extend(scan(data, str(path)))
if findings:
    STAGE.mkdir(parents=True, exist_ok=True)
    (STAGE / 'credential-scan-hold.json').write_bytes(json_bytes({'findings': findings, 'matched_values_disclosed': False}))
    print(json.dumps({'archive_created': False, 'credential_review_required': findings}, indent=2))
    raise SystemExit(2)

PAYLOAD.mkdir(parents=True)
records = []
for path in sorted(original_data):
    name = str(path.relative_to(ROOT))
    data = original_data[path]
    row = {'original_path': str(path), 'original_relative_path': name,
           'bytes': len(data), 'sha256': digest(data),
           'hash_basis': 'post_execution_retention_snapshot'}
    if name in SPECIAL_OMISSIONS or (path.suffix == '.so' and len(data) > 100 * 1024):
        row.update(disposition='omitted', archive_path=None, reason=SPECIAL_OMISSIONS.get(name,
            'Rebuildable native shared library larger than 100 KiB. Exact original identity retained; source, generated inputs, commands and observation records remain in this archive or its original-commit bundle.'))
    else:
        target = PAYLOAD / 'originals' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if name in ALIASES:
            canonical = ALIASES[name]
            assert data == original_data[ROOT / canonical]
            os.link(PAYLOAD / 'originals' / canonical, target)
            row.update(disposition='retained_hardlink_alias', archive_alias_of='originals/' + canonical,
                       reason='Identical actually executed a9 shadow copy deduplicated by exact bytes and SHA256; tar retains the original relative name as a hardlink to the canonical binary.')
        else:
            target.write_bytes(data)
            target.chmod(stat.S_IMODE(path.stat().st_mode) & 0o777)
            row.update(disposition='retained', reason='Original component, review, development, failure or incomplete-run record retained without editing.')
        row['archive_path'] = str(target.relative_to(PAYLOAD))
        assert target.read_bytes() == data
    records.append(row)

for commit, name, oid, data in snapshots:
    relative = 'source-inputs/' + commit + '/' + name
    target = PAYLOAD / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    records.append({'original_path': 'git:' + commit + ':' + name, 'repository_path': str(REPO),
                    'original_commit': commit, 'original_relative_path': name, 'git_blob_oid': oid,
                    'bytes': len(data), 'sha256': digest(data), 'archive_path': relative,
                    'disposition': 'retained_git_blob', 'hash_basis': 'post_execution_frozen_git_object_retention',
                    'reason': 'Changed source/input blob retained at its exact original component commit; not relabeled as final-public-source execution.'})

security = {
    'schema': 'hepta.component-retention-credential-review.v1', 'performed_at_utc': WHEN,
    'scan_scope': 'All selected and explicitly omitted original files, plus expanded objects introduced by the new component bundle relative to its two public prerequisites.',
    'original_files_scanned': len(original_data), 'expanded_git_objects_scanned': len(object_scan),
    'pattern_categories': list(PATTERNS), 'findings': [], 'matched_values_disclosed': False,
    'public_placeholder_expressions_and_masked_CI_values_are_not_credentials': True,
    'limitations': 'Pattern-based retention inspection is not a proof that every possible encoding of a secret is absent. Private NDU repositories, credential stores, toolchains and caches are outside the selected archive scope.',
}
provenance = {
    'schema': 'hepta.component-source-retention.v2', 'repository': 'TrillionniumFoundation/Hepta',
    'bundle': 'originals/component-sources-v2.bundle', 'bundle_sha256': digest(bundle_bytes),
    'bundle_refs': bundle_refs, 'public_prerequisite_commits': prerequisites,
    'commits_introduced_by_bundle': commit_records, 'expanded_object_inventory': object_scan,
    'source_snapshot_rule': 'Every added, copied, modified or type-changed blob in every introduced commit is retained under source-inputs/<original-commit>/. Baseline source is obtained from the public prerequisite commits.',
    'original_source_binding_not_rewritten': True,
    'final_public_source': '3d5401cf9bacddfd6d8f14c806b29ce13bb04eed',
    'final_public_source_execution_qualified_by_this_archive': False,
    'final_local_source': 'ae741c5395f9307515c8b0e7e1217f72f477f2c5',
    'local_final_commit_retained_for_source_provenance_only': True,
}
README = '''# Hepta component and independent-review evidence — 2026-10-29

This archive retains original component evidence and the development, failure,
incomplete-run and independent-review records leading to the final source. It is
**not** the full integrated qualification of public commit
`3d5401cf9bacddfd6d8f14c806b29ce13bb04eed`. The final eight-gate run, 75-selector
safety run and final hosted CI outcomes belong to a separate archive.

## Original source identities

| Component | Original frozen commit | Primary records |
| --- | --- | --- |
| Local borrowed views | `b20b1da6d5002bfe80689901e4016a0c4cbffb57` | `originals/core-qualification-b20b1da/`; `originals/localview-independent-review/` |
| Bounded C migration capture | `429de074aedeedb8c06d5cf08fd5d2701f25fe98` | `originals/migration-evidence/` |
| Bound Rust execution v1 | `d5a93e1a6a5de93b31ca172462f4371cbc2e4036` | `originals/rust-execution-evidence/`; execution independent review |
| Shadow process ownership | `2c8785a506faacaece51612c88beea893faf5490` | `originals/transport-qualification-2c8785a/`; orphan and independent reviews |
| Finite unit source enums | `ed678d362535550e7ded449a30362b696c05f286` | `originals/unit-enum-qualification-ed678d3/`; both enum independent-review directories |
| Explicit Rust call-depth v2 | `d62b1654306f6de3aed88da003c1b94434c1b388` | `originals/rust-bound-depth-d62b165/`; bound-depth independent review |
| CI invocation wiring | `62b3c9ee1d332188a8c98d910ac287e9f3d99822` | `originals/ci-wiring-evidence/` |
| Frozen Windows checkout bytes | `546b82c0c5ab29dea90c3de690a434ce747660e3` | `originals/windows-cpp-failure-evidence/` |

The final control review describes its original `e03a661...` plus six-file
uncommitted snapshot, with exact file hashes. The later local commit `ae741...`
is retained as source provenance, not substituted into those historical records.
Unfrozen development logs remain development observations. No original component
commit, native result or incomplete run has been relabeled as final-source proof.

## Retained adverse and incomplete observations

- Transport pre-fix failures and the original orphan reproduction are retained.
- Migration pre-capture-fix failures and later regression logs are both retained.
- The safety matrix reduction reproduction, protocol-control iterations and final
  input-inventory finding/resolution are retained.
- `final-qualification-a9e22f9/incomplete-run-observation.json` explicitly records
  that the full-regression result was unavailable. Completed sub-gate observations
  are not promoted to an overall pass.
- The two Windows job logs at original public source `a9e22f...` remain failures
  before C++ execution. Autocrlf controls are not Windows native qualification.
- The first enum review contains the rejected immutable packet fixture. Its
  original script and result are retained alongside the corrected fixture-only
  rerun and summary; the other passed cases were not rerun to replace that record.
- Coordinator state JSON is an archival snapshot, not an authoritative account of
  the final run or final hosted CI status.

## Layout and reconstruction

`originals/` preserves workspace-relative paths and original bytes. Collectors,
review scripts, generated Hepta/Core/Rust/LLVM/C inputs and raw logs/JSON are kept.
`source-inputs/<commit>/` contains changed blobs at their original Git identities.
`source-provenance.json` lists all original bundle refs, commits and object hashes.

Both source bundles are retained. The newer bundle has nine refs and requires the
public commits `2f49151ab9d8812eeb02ac2056f224f140099d76` and
`a9e22f96d3bf67181bbb92c286bfd5e07cfa11e4`. Fetch those commits from the public
TrillionniumFoundation/Hepta repository into a separate checkout before verifying
and importing the bundle. Absolute paths in original scripts may need relocating;
the archive itself does not run them or recreate a qualification result.

Shared libraries larger than 100 KiB are omitted as rebuildable outputs; their
original paths, byte counts and SHA256 values remain in `manifest.json`. The
actually executed a9 shadow binary is retained once at
`originals/a9-shadow-build/hia-core-shadow`. The two identical review-local copies
are explicit hardlink aliases with their own manifest rows. Small observed native
outputs remain. The unexecuted cache-relocation shadow copy and the superseded
old aggregate archive are omitted with explicit reasons.

No Cargo targets, toolchain installations, dependency caches, credential stores,
private NDU repository contents or final running qualification directory are
copied. Existing bridge receipts and their recorded external identities remain as
original observations; they are not a copy of those external dependencies.

## Integrity and limits

`manifest.json` records original paths, sizes, SHA256 values, source commits,
archive paths, aliases and omissions. These hashes are **post-execution retention
hashes**, not a newly established before/after execution identity proof. Original
run-time identity evidence stays in the original reports with its original scope.
The old retention manifest's 100 listed payload files were all checked and kept;
the old manifest itself is retained too.

`credential-review.json` records a scan of all selected original bytes and expanded
Git objects for literal credential formats, without printing matched values. This
scan found no such credential values; its explicit limitations remain recorded.
`archive-receipt.json`, adjacent to the tarball, binds the completed tarball and
manifest. No publication or remote mutation is performed by this packaging step.
'''

generated = {'credential-review.json': json_bytes(security),
             'source-provenance.json': json_bytes(provenance), 'README.md': README.encode()}
for name, data in generated.items():
    assert not scan(data, name)
    (PAYLOAD / name).write_bytes(data)
    records.append({'original_path': None, 'archive_path': name, 'bytes': len(data),
                    'sha256': digest(data), 'disposition': 'generated_retention_metadata',
                    'hash_basis': 'archive_preparation', 'reason': 'New packaging metadata only; not a qualification execution record.'})

for path, data in original_data.items():
    assert path.read_bytes() == data, 'Original changed during retention: ' + str(path)

manifest = {
    'schema': 'hepta.component-retention.v2', 'created_at_utc': WHEN,
    'purpose': 'Original component and independent review records; not final-public-source qualification.',
    'hash_time_scope': 'All newly measured hashes are post-execution retention identities, not proof of pre/post execution source or binary stability.',
    'original_records_edited': False, 'original_commits_relabelled': False,
    'originals_stable_during_copy': True, 'old_retention_payload_count': len(old_validation),
    'old_retention_all_sizes_and_hashes_match': True, 'old_retention_all_payloads_retained': True,
    'files': records, 'retention_summary': dict(Counter(row['disposition'] for row in records)),
    'source_bundle_prerequisites': prerequisites,
    'out_of_scope_not_inventoried': [
        {'path': str(ROOT / name), 'bytes': None, 'sha256': None, 'reason': reason}
        for name, reason in (
            ('final-qualification-3d5401c', 'Active final-source evidence; root will retain in a separate final-run archive.'),
            ('target-*', 'Rebuildable compiler targets, including active final-run output. Not read or copied.'),
            ('cargo-home', 'Dependency cache; not a qualification observation record.'),
            ('hepta-*', 'Working tree contents not copied; exact component source retained via original-commit bundle and blobs.'),
            ('/workspace/scratch/bf7d454bbc83', 'Toolchains and private external NDU repositories are not part of this archive.'),
        )],
    'self_hash_policy': 'manifest.json does not hash itself; adjacent archive-receipt.json hashes the manifest and complete tarball.',
}
manifest_bytes = json_bytes(manifest)
(PAYLOAD / 'manifest.json').write_bytes(manifest_bytes)
(STAGE / 'component-retention-v2.json').write_bytes(manifest_bytes)

with ARCHIVE.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT, dereference=False) as tar:
        for path in sorted(PAYLOAD.rglob('*')):
            if path.is_file():
                info = tar.gettarinfo(str(path), arcname=PAYLOAD.name + '/' + str(path.relative_to(PAYLOAD)))
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                info.pax_headers = {}
                with path.open('rb') as stream:
                    tar.addfile(info, stream if info.isfile() else None)

with tarfile.open(ARCHIVE, 'r:gz') as tar:
    members = tar.getmembers()
    expected = {row['archive_path']: row for row in records if row['archive_path'] is not None}
    assert {m.name for m in members} == {PAYLOAD.name + '/' + name for name in [*expected, 'manifest.json']}
    for name, row in expected.items():
        data = tar.extractfile(PAYLOAD.name + '/' + name).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256'], name
    assert tar.extractfile(PAYLOAD.name + '/manifest.json').read() == manifest_bytes
    aliases = [m for m in members if m.islnk()]
    assert len(aliases) == 2
    assert all(m.linkname == PAYLOAD.name + '/originals/a9-shadow-build/hia-core-shadow' for m in aliases)

receipt = {
    'schema': 'hepta.component-archive-receipt.v2', 'created_at_utc': WHEN,
    'archive': {'path': str(ARCHIVE), 'bytes': ARCHIVE.stat().st_size, 'sha256': digest(ARCHIVE.read_bytes())},
    'manifest': {'path': str(STAGE / 'component-retention-v2.json'), 'bytes': len(manifest_bytes), 'sha256': digest(manifest_bytes)},
    'archive_members': len(members), 'member_bytes_and_hashes_verified': True,
    'hardlink_aliases_verified': len(aliases), 'credential_patterns_found': 0,
    'old_retention_payloads_verified_and_retained': len(old_validation),
    'source_snapshot_files': len(snapshots), 'source_bundle_refs': len(bundle_refs),
    'retention_summary': manifest['retention_summary'],
    'component_records_relabelled_as_final_source': False,
    'qualification_tests_executed_by_packaging': False, 'remote_mutations_performed': False,
}
(STAGE / 'archive-receipt.json').write_bytes(json_bytes(receipt))
print(json.dumps(receipt, indent=2, sort_keys=True))
