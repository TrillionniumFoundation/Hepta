"""Independent enum boundary observations; run only against a frozen source."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--head', required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--shadow', type=Path, required=True)
p.add_argument('--only-case')
a = p.parse_args()
ROOT = a.root.resolve()
OUT = a.out.resolve()
OUT.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(ROOT))
from hepta.backend import compile_rust, emit_rust
from hepta.checker import check
from hepta.hia_program_llvm import build_program_native
from hepta.hia_program_runtime import execute_program
from hepta.hia_program_source import lower_source
from hepta.hia_rust_crosscheck import crosscheck_rust_execution
from hepta.parser import parse

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, text=True).strip()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

before = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
          'status': git('status', '--porcelain'), 'adapter_sha256': sha(ROOT/'hepta/hia_program_source.py')}
assert before['head'] == a.head and not before['status'], before
shadow = OUT/'shadow'
shadow.write_bytes(a.shadow.read_bytes())
shadow.chmod(0o700)
shadow_sha = sha(shadow)

helpers = '''enum Signal { Red, Amber, Green }
fn choose(n:u8)->Signal effects{} {
 if n==0 {return Signal::Red;} if n==1 {return Signal::Amber;} return Signal::Green;
}
fn weight(s:Signal)->u64 effects{} {
 match s {Signal::Red=>{return 13;},Signal::Amber=>{return 29;},Signal::Green=>{return 47;},}
}
export "C" fn probe(n:u8)->u64 effects{} {return weight(choose(n));}
'''
copies = '''enum State { Cold, Warm, Hot }
struct Label { state:State, number:u64 }
export "C" fn probe(n:u8)->u64 effects{} {
 let initial=Label{state:State::Cold,number:11};let mut current=initial;
 for i in 0..n as usize {
  match current.state {
   State::Cold=>{current.state=State::Warm;},
   State::Warm=>{current.state=State::Hot;},
   State::Hot=>{current.state=State::Cold;},
  }
  current.number=wrapping_add(current.number,1);
 }
 let mut result:u64=0;
 match current.state {State::Cold=>{result=3;},State::Warm=>{result=5;},State::Hot=>{result=7;},}
 match initial.state {State::Cold=>{return wrapping_add(result,wrapping_add(current.number,initial.number));},
  State::Warm=>{return 901;},State::Hot=>{return 902;},}
}
'''
buffers = (ROOT/'examples/owned/buffers.hepta').read_text() + '''
export "C" fn probe(n:u8)->u64 effects{alloc,block,panic,write} {
 match create(n as usize,3,17) {
  Result::Ok(packet)=>{let mut owned=move packet;fill(mut owned,5);let value=checksum(read owned);close(move owned);return value;},
  Result::Err(error)=>{match error {
   BuildError::Empty=>{return 101;},BuildError::AboveLimit=>{return 103;},BuildError::AllocationFailed=>{return 107;},
  }},
 }
}
'''
wide = 'enum Choice {' + ','.join('V'+str(i) for i in range(32)) + '}\n'
wide += 'fn select(n:u8)->Choice effects{} {'
wide += ''.join('if n=='+str(i)+' {return Choice::V'+str(i)+';}' for i in range(31))
wide += 'return Choice::V31;}\nexport "C" fn probe(n:u8)->u64 effects{} {match select(n) {'
wide += ''.join('Choice::V'+str(i)+'=>{return '+str(7*i+1)+';},' for i in range(32)) + '}}'
cases = [
 ('private_nominal_helpers', helpers, list(range(4)), lambda n: (13,29,47,47)[n], {'probe'}),
 ('copy_fields_and_loop', copies, list(range(7)), lambda n: (3,5,7)[n%3]+22+n, {'probe'}),
 ('existing_buffers_application', buffers, [0,1,2,3,4,8], lambda n: 101 if n==0 else 103 if n>3 else 5*n, {'probe'}),
 ('thirty_two_variants', wide, list(range(33)), lambda n: 7*min(n,31)+1, {'probe'}),
]
bad = {
 'unused_payload':'enum Hidden { Some(u32), None } export "C" fn probe()->u32 effects{} {return 1;}',
 'unused_generic':'enum Hidden<T> { First, Second } export "C" fn probe()->u32 effects{} {return 1;}',
 'too_many_variants':'enum Huge {'+','.join('V'+str(i) for i in range(33))+'} export "C" fn probe()->u32 effects{} {return 1;}',
 'nominal_mismatch':'enum A{X,Y} enum B{X,Y} fn f(a:A)->u32 effects{} {return 1;} export "C" fn probe()->u32 effects{} {return f(B::X);}',
 'missing_case':'enum A{X,Y,Z} export "C" fn probe()->u32 effects{} {match A::X {A::X=>{return 1;},A::Y=>{return 2;},}}',
 'duplicate_case':'enum A{X,Y} export "C" fn probe()->u32 effects{} {match A::X {A::X=>{return 1;},A::X=>{return 2;},A::Y=>{return 3;},}}',
 'c_argument':'enum A{X,Y} export "C" fn probe(a:A)->u32 effects{} {return 1;}',
 'c_return':'enum A{X,Y} export "C" fn probe()->A effects{} {return A::X;}',
}
report = {'schema':'hepta.independent-unit-enum-review.v1','source_before':before,
          'shadow_source_commit':'a9e22f96d3bf67181bbb92c286bfd5e07cfa11e4',
          'shadow_sha256':shadow_sha, 'positive':[], 'negative':[],
          'claims':{'general_enum_support':False,'source_refinement_proved':False,'all_blockers_closed':False}}
for name,text,inputs,want,exports in cases:
    if a.only_case and name!=a.only_case:
        continue
    directory=OUT/name;directory.mkdir();(directory/'input.hepta').write_text(text)
    row={'case':name,'observations':[]}
    try:
        ast=parse(text);checked=check(ast)
        assert checked.ok, [d.message for d in checked.diagnostics]
        generated=emit_rust(ast,checked,crate_type='cdylib')
        (directory/'source.rs').write_text(generated)
        reference=compile_rust(generated,crate_type='cdylib',output=directory/'source.so',linker=os.environ['CLANG'])
        assert reference['ok'], reference
        row['reference_build']=reference
        native_source=ctypes.CDLL(str(directory/'source.so')).probe
        native_source.argtypes=[ctypes.c_uint8];native_source.restype=ctypes.c_uint64
        for version in (1,8):
            core=lower_source(text,core_schema='hepta.hia.program.v'+str(version))
            (directory/('v'+str(version)+'.json')).write_bytes(core.canonical_bytes)
            assert set(core.scalar_entrypoints)==exports, core.scalar_entrypoints
            build=build_program_native(core,directory/('v'+str(version)+'.so'),clang=os.environ['CLANG'])
            assert build['ok'] and set(build['exports'])==exports, build
            row.setdefault('llvm_builds',[]).append(build)
            native=ctypes.CDLL(str(directory/('v'+str(version)+'.so'))).probe
            native.argtypes=[ctypes.c_uint8];native.restype=ctypes.c_uint64
            for n in inputs:
                vm=execute_program(core,'probe',[n])
                bound=crosscheck_rust_execution(core,'probe',[n],shadow,executable_sha256=shadow_sha)
                observation={'schema':core.as_dict()['schema'],'argument':n,'expected':want(n),
                             'python':vm,'bound':bound,'source_rust':native_source(n),'llvm':native(n)}
                row['observations'].append(observation)
                assert observation['source_rust']==observation['llvm']==vm['result']==want(n), observation
                assert bound.get('status')=='execution_corroborated_not_authority', bound
                assert not any(vm['resources'][key] for key in ('live_bytes','live_owners','live_local_loans')),vm
        row['passed']=True
    except Exception as error:
        row.update(passed=False,error=type(error).__name__+': '+str(error))
    report['positive'].append(row);print(name,row['passed'],row.get('error',''),flush=True)
for name,text in bad.items():
    if a.only_case:
        continue
    row={'case':name,'source':text,'observations':[]}
    for version in (1,8):
        try:
            core=lower_source(text,core_schema='hepta.hia.program.v'+str(version))
            row['observations'].append({'version':version,'rejected':False,'core_sha256':core.sha256})
        except Exception as error:
            row['observations'].append({'version':version,'rejected':True,'error':type(error).__name__+': '+str(error)})
    row['passed']=all(x['rejected'] for x in row['observations']);report['negative'].append(row)
report['source_after']={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),
                       'status':git('status','--porcelain'),'adapter_sha256':sha(ROOT/'hepta/hia_program_source.py')}
report['source_unchanged']=before==report['source_after']
report['shadow_unchanged']=shadow_sha==sha(shadow)
report['passed']=report['source_unchanged'] and report['shadow_unchanged'] and all(r['passed'] for r in report['positive']+report['negative'])
(OUT/'review.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'positive_inputs':sum(len(r['observations']) for r in report['positive']),
                  'negative_inputs':sum(len(r['observations']) for r in report['negative'])}))
raise SystemExit(0 if report['passed'] else 1)
