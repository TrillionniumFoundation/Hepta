"""Finite read-only review of invocation binding and stopped resource reports."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

ROOT = Path('/workspace/scratch/b484d4086829/hepta-live')
sys.path.insert(0, str(ROOT))
from hepta import hia_rust_crosscheck as consumer
from hepta.hia_program import verify_program
from tests.test_hia_rust_crosscheck import scalar_program, owned_program
from tests.test_hia_composite_abi import nominal_identity_program

EXE = Path('/workspace/scratch/b484d4086829/target-rust/debug/hia-core-shadow')
DIGEST = sha256(EXE.read_bytes()).hexdigest()
EXPECTED = '8838b29949394cf819f8421ee674d70d4d5dd86362978123cfc2416efc425249'
assert DIGEST == EXPECTED, 'review must use the actually tested Rust producer'
FILES = [
    'hepta/hia_rust_crosscheck.py', 'hepta/hia_program.py',
    'hepta/hia_program_runtime.py', 'rust/hia-core-shadow/src/lib.rs',
    'rust/hia-core-shadow/src/main.rs', 'rust/hia-core-shadow/src/scalar_vm.rs',
    'rust/hia-core-shadow/src/scalar_vm/byte_memory.rs',
    'docs/HIA_RUST_BOUND_EXECUTION.md',
]


def inventory():
    return {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in FILES}


def head():
    return subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'],
                                   text=True).strip()


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode() + b'\n'


before, source_head = inventory(), head()
records, observations = [], {}


def actual(label, program, function, args, **policy):
    result = consumer.crosscheck_rust_execution(program, function, args, EXE,
        executable_sha256=DIGEST, **policy)
    report = result['rust_report']
    observations[label] = (program, result)
    records.append({'case': label, 'status': report['status'],
                    'steps': report['steps'], 'values': report.get('values'),
                    'error': report.get('error'), 'resources': report['resources'],
                    'request': result['request'], 'request_sha256': result['request_sha256']})
    return result


for kind, value in [('bool', True), ('unit', None)]:
    source = scalar_program()
    fn = source['functions'][0]
    fn['params'][0]['type'] = fn['blocks'][0]['params'][0]['type'] = kind
    fn['returns'] = [kind]
    result = actual(kind + '_boundary', source, 'identity', [value])
    assert type(result['rust_report']['values'][0]) is type(value)

actual('normal_cleanup', owned_program(), 'allocate_release', [3])
stopped = actual('live_owner_step_stop', owned_program(), 'allocate_release', [3], max_steps=2)
assert stopped['rust_report']['status'] == 'budget_exceeded'
assert stopped['rust_report']['resources']['live_owners'] == 1
assert stopped['rust_report']['resources']['live_bytes'] == 3
trapping = owned_program()
block = trapping['functions'][0]['blocks'][0]
block['ops'] = block['ops'][:1]
block['term'] = {'op': 'trap', 'code': 'user'}
trapped = actual('live_owner_semantic_trap', trapping, 'allocate_release', [3])
assert trapped['rust_report']['status'] == 'trapped'
assert trapped['rust_report']['resources']['live_owners'] == 1
assert trapped['rust_report']['resources']['frees'] == 0
actual('unused_policies_still_bound', scalar_program(), 'identity', [7],
       max_heap_bytes=0, allocation_fail_at=(1 << 64) - 1)
actual('nominal_public_entry', nominal_identity_program(), 'public_identity', [42])
with patch.object(consumer, '_verified_executable_bytes',
                  side_effect=AssertionError('nominal private entry reached execution')):
    try:
        consumer.crosscheck_rust_execution(nominal_identity_program(), 'inspect_packet',
            [42], EXE, executable_sha256=DIGEST)
        nominal_rejected = False
    except consumer.HIARustCrosscheckRejected:
        nominal_rejected = True
assert nominal_rejected

program, observed = observations['live_owner_step_stop']
body = verify_program(program).as_dict()
request = observed['request']
envelope = {'schema': 'hepta.hia.rust-bound-execution.v1',
            'request': request, 'request_sha256': observed['request_sha256'],
            'execution': observed['rust_report']}
controls = []


def refuse(label, changed):
    try:
        consumer._validate_execution(wire(changed), request, body,
                                     observed['python_report'])
        raise AssertionError('forged report accepted: ' + label)
    except consumer.HIARustCrosscheckRejected as error:
        controls.append({'case': label, 'rejected': True, 'reason': str(error)})


for field, value in [('program_sha256', '0' * 64), ('function', 'other'),
                     ('arguments', [True]), ('mode', 'scalar')]:
    bad = deepcopy(envelope)
    bad['request'][field] = value
    bad['request_sha256'] = sha256(consumer._canonical(bad['request'])).hexdigest()
    refuse('rehashed_request_' + field, bad)
for field, value in [('max_steps', 3), ('max_heap_bytes', 0),
                     ('allocation_fail_at', 1), ('max_call_depth', 31)]:
    bad = deepcopy(envelope)
    bad['request']['policy'][field] = value
    bad['request_sha256'] = sha256(consumer._canonical(bad['request'])).hexdigest()
    refuse('rehashed_policy_' + field, bad)
for label, mutate in [
    ('fabricated_cleanup', lambda report: report['resources'].update(live_owners=0, live_bytes=0, frees=1)),
    ('integer_boolean_substitution', lambda report: report['resources'].update(allocation_attempts=True)),
    ('float_counter', lambda report: report['resources'].update(live_bytes=3.0)),
    ('missing_counter', lambda report: report['resources'].pop('peak_bytes')),
    ('error_as_return', lambda report: report.update(status='returned', values=[])),
    ('promoted_authority', lambda report: report['claims'].update(production_admission_authorized=True)),
]:
    bad = deepcopy(envelope)
    mutate(bad['execution'])
    refuse(label, bad)

after = inventory()
record = {
    'schema': 'hepta.rust-bound-execution-independent-review.v1',
    'source_head_before': source_head, 'source_head_after': head(),
    'source_hashes_before': before, 'source_hashes_after': after,
    'reviewed_sources_unchanged': before == after,
    'rust_binary_sha256': DIGEST,
    'producer_evidence_source': 'd5a93e1a6a5de93b31ca172462f4371cbc2e4036',
    'scope': 'finite exact invocation/type/policy/complete reported counters, not Core soundness or Rust authority switch',
    'actual_binary_invocations': records,
    'malicious_report_controls': controls,
    'nominal_internal_entry_rejected_before_executable_read': nominal_rejected,
    'binding_and_report_review_passed': before == after and len(controls) == 14,
    'whole_language_or_backend_refinement_proved': False,
    'independent_known_transport_finding': 'rust-transport-orphan-review.json: exited parent prevented process-group cleanup on deadline',
    'full_24_test_suite_repeated': False,
}
output = Path('/workspace/scratch/b484d4086829/rust-bound-execution-independent-review.json')
output.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'output': str(output), 'source': source_head,
                  'actual_cases': len(records), 'rejected_controls': len(controls),
                  'review_passed': record['binding_and_report_review_passed']}))
raise SystemExit(0 if record['binding_and_report_review_passed'] else 1)
