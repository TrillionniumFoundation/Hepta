from __future__ import annotations

import contextlib
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/b484d4086829/hepta-core')
EXPECTED = 'ed678d362535550e7ded449a30362b696c05f286'
OUT = Path('/workspace/scratch/b484d4086829/unit-enum-qualification-ed678d3')
OUT.mkdir(exist_ok=False)
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
os.environ['HIA_UNIT_ENUM_NATIVE_DIR'] = str(OUT)

from hepta.hia_program import verify_program
from hepta.hia_program_llvm import emit_program_llvm
from hepta.hia_program_source import lower_source, source_report
from hepta.hia_schema import SCHEMA, SCHEMA_V8
from tests import test_hia_source_unit_enums as tests


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


assert git('rev-parse', 'HEAD') == EXPECTED
assert not git('status', '--porcelain')
source_paths = ['hepta/hia_program_source.py', 'examples/hia_program/source_unit_enums.hepta',
                'tests/test_hia_source_unit_enums.py', 'docs/HIA_SOURCE_UNIT_ENUMS.md']
source_hashes = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in source_paths}
lower_original, execute_original = tests.lower_source, tests.execute_program
source_refusals, stopped_or_refused = [], []


def lower(source, **options):
    try:
        return lower_original(source, **options)
    except Exception as error:
        source_refusals.append({'source': source, 'source_sha256': sha256(source.encode()).hexdigest(),
                               'options': options, 'type': type(error).__name__, 'error': str(error)})
        raise


def execute(core, function, arguments, **policy):
    try:
        return execute_original(core, function, arguments, **policy)
    except Exception as error:
        row = {'core_sha256': verify_program(core).sha256, 'function': function, 'arguments': arguments,
               'policy': policy, 'type': type(error).__name__, 'error': str(error)}
        if hasattr(error, 'report'):
            row['report'] = error.report
        stopped_or_refused.append(row)
        raise


started = time.monotonic()
with (OUT / 'unittest.log').open('w') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
    with patch.object(tests, 'lower_source', lower), patch.object(tests, 'execute_program', execute):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromName('tests.test_hia_source_unit_enums'))
elapsed = time.monotonic() - started

sources = {}
for schema in (SCHEMA, SCHEMA_V8):
    core = lower_source(tests.SOURCE, core_schema=schema)
    prefix = schema.rsplit('.', 1)[-1]
    (OUT / (prefix + '.core.json')).write_bytes(core.canonical_bytes)
    (OUT / (prefix + '.ll')).write_text(emit_program_llvm(core).text)
    sources[schema] = {'core_sha256': core.sha256,
                       'source_report': source_report(tests.SOURCE, core_schema=schema)}
rust = {'build': tests.HIASourceUnitEnumRust.build,
        'executable_sha256': tests.HIASourceUnitEnumRust.digest,
        'observations': tests.HIASourceUnitEnumRust.observations}
native = {'differential': tests.HIASourceUnitEnumNative.records,
          'allocator': tests.HIASourceUnitEnumNative.allocator,
          'invalid_tag': tests.HIASourceUnitEnumNative.invalid}
for name, value in [('rust-observations.json', rust), ('native-observations.json', native),
                    ('source-refusals.json', source_refusals), ('stopped-and-refused.json', stopped_or_refused)]:
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

regression = Path('/workspace/scratch/b484d4086829/unit-enum-regression-development.log')
regression_text = regression.read_text()
matched = re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK\n', regression_text)
assert matched is not None and int(matched.group(1)) == 113
shutil.copyfile(regression, OUT / 'related-regression-precommit.log')
shutil.copyfile(__file__, OUT / 'collector.py')
assert git('rev-parse', 'HEAD') == EXPECTED and not git('status', '--porcelain')
assert source_hashes == {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in source_paths}
summary = {
    'schema': 'hepta.source-unit-enums.qualification.v1',
    'source_commit': EXPECTED, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'base_commit': 'a9e22f96d3bf67181bbb92c286bfd5e07cfa11e4',
    'branch': git('branch', '--show-current'), 'source_hashes': source_hashes,
    'source_clean_before_and_after': True, 'head_and_source_unchanged': True,
    'frozen_increment_tests': result.testsRun, 'failures': result.failures,
    'errors': result.errors, 'skipped': result.skipped, 'elapsed_seconds': elapsed,
    'qualified': result.wasSuccessful() and not result.skipped,
    'related_regression': {'tests': int(matched.group(1)), 'seconds': float(matched.group(2)),
                           'stage': 'before_commit', 'log': 'related-regression-precommit.log'},
    'sources': sources, 'rust_full_ledger_observations': len(rust['observations']),
    'native_paired_value_cases': sum(len(row['observations']) for row in native['differential']),
    'native_allocator_cases': len(native['allocator']['observations']),
    'native_invalid_tag_cases': len(native['invalid_tag']['observations']),
    'source_rejection_observations': len(source_refusals),
    'vm_stopped_or_entry_refused_observations': len(stopped_or_refused),
    'toolchain_environment': {key: os.environ.get(key) for key in
                              ('CARGO_TARGET_DIR', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_INCREMENTAL',
                               'CARGO_NET_OFFLINE', 'CLANG', 'RUSTC')},
    'python': sys.version, 'claims': {'whole_language_soundness_proved': False,
                                     'all_blockers_closed': False,
                                     'new_primitive_or_runtime_added': False},
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
manifest = {str(path.relative_to(OUT)): sha256(path.read_bytes()).hexdigest()
            for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'sha256.json'}
(OUT / 'sha256.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: summary[key] for key in ['source_commit', 'frozen_increment_tests', 'elapsed_seconds',
    'rust_full_ledger_observations', 'native_paired_value_cases', 'native_allocator_cases',
    'native_invalid_tag_cases', 'source_rejection_observations', 'qualified']}, indent=2))
sys.exit(0 if summary['qualified'] else 1)
