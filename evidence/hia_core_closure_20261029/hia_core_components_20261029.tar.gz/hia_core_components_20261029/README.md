# Hepta component and independent-review evidence — 2026-10-29

This archive retains original component evidence and the development, failure,
incomplete-run and independent-review records leading to the final source. It is
**not** the full integrated qualification of public commit
`3d5401cf9bacddfd6d8f14c806b29ce13bb04eed`. The final eight-gate run, 75-selector
safety run and final hosted CI outcomes belong to a separate archive.

## Original source identities

| Component | Original frozen commit | Primary records |
| --- | --- | --- |
| Local borrowed views | `b20b1da6d5002bfe80689901e4016a0c4cbffb57` | `originals/core-qualification-b20b1da/`; `originals/localview-independent-review/` |
| Bounded C migration capture | `429de074aedeedb8c06d5cf08fd5d2701f25fe98` | `originals/migration-evidence/` |
| Bound Rust execution v1 | `d5a93e1a6a5de93b31ca172462f4371cbc2e4036` | `originals/rust-execution-evidence/`; execution independent review |
| Shadow process ownership | `2c8785a506faacaece51612c88beea893faf5490` | `originals/transport-qualification-2c8785a/`; orphan and independent reviews |
| Finite unit source enums | `ed678d362535550e7ded449a30362b696c05f286` | `originals/unit-enum-qualification-ed678d3/`; both enum independent-review directories |
| Explicit Rust call-depth v2 | `d62b1654306f6de3aed88da003c1b94434c1b388` | `originals/rust-bound-depth-d62b165/`; bound-depth independent review |
| CI invocation wiring | `62b3c9ee1d332188a8c98d910ac287e9f3d99822` | `originals/ci-wiring-evidence/` |
| Frozen Windows checkout bytes | `546b82c0c5ab29dea90c3de690a434ce747660e3` | `originals/windows-cpp-failure-evidence/` |

The final control review describes its original `e03a661...` plus six-file
uncommitted snapshot, with exact file hashes. The later local commit `ae741...`
is retained as source provenance, not substituted into those historical records.
Unfrozen development logs remain development observations. No original component
commit, native result or incomplete run has been relabeled as final-source proof.

## Retained adverse and incomplete observations

- Transport pre-fix failures and the original orphan reproduction are retained.
- Migration pre-capture-fix failures and later regression logs are both retained.
- The safety matrix reduction reproduction, protocol-control iterations and final
  input-inventory finding/resolution are retained.
- `final-qualification-a9e22f9/incomplete-run-observation.json` explicitly records
  that the full-regression result was unavailable. Completed sub-gate observations
  are not promoted to an overall pass.
- The two Windows job logs at original public source `a9e22f...` remain failures
  before C++ execution. Autocrlf controls are not Windows native qualification.
- The first enum review contains the rejected immutable packet fixture. Its
  original script and result are retained alongside the corrected fixture-only
  rerun and summary; the other passed cases were not rerun to replace that record.
- Coordinator state JSON is an archival snapshot, not an authoritative account of
  the final run or final hosted CI status.

## Layout and reconstruction

`originals/` preserves workspace-relative paths and original bytes. Collectors,
review scripts, generated Hepta/Core/Rust/LLVM/C inputs and raw logs/JSON are kept.
`source-inputs/<commit>/` contains changed blobs at their original Git identities.
`source-provenance.json` lists all original bundle refs, commits and object hashes.

Both source bundles are retained. The newer bundle has nine refs and requires the
public commits `2f49151ab9d8812eeb02ac2056f224f140099d76` and
`a9e22f96d3bf67181bbb92c286bfd5e07cfa11e4`. Fetch those commits from the public
TrillionniumFoundation/Hepta repository into a separate checkout before verifying
and importing the bundle. Absolute paths in original scripts may need relocating;
the archive itself does not run them or recreate a qualification result.

Shared libraries larger than 100 KiB are omitted as rebuildable outputs; their
original paths, byte counts and SHA256 values remain in `manifest.json`. The
actually executed a9 shadow binary is retained once at
`originals/a9-shadow-build/hia-core-shadow`. The two identical review-local copies
are explicit hardlink aliases with their own manifest rows. Small observed native
outputs remain. The unexecuted cache-relocation shadow copy and the superseded
old aggregate archive are omitted with explicit reasons.

No Cargo targets, toolchain installations, dependency caches, credential stores,
private NDU repository contents or final running qualification directory are
copied. Existing bridge receipts and their recorded external identities remain as
original observations; they are not a copy of those external dependencies.

## Integrity and limits

`manifest.json` records original paths, sizes, SHA256 values, source commits,
archive paths, aliases and omissions. These hashes are **post-execution retention
hashes**, not a newly established before/after execution identity proof. Original
run-time identity evidence stays in the original reports with its original scope.
The old retention manifest's 100 listed payload files were all checked and kept;
the old manifest itself is retained too.

`credential-review.json` records a scan of all selected original bytes and expanded
Git objects for literal credential formats, without printing matched values. This
scan found no such credential values; its explicit limitations remain recorded.
`archive-receipt.json`, adjacent to the tarball, binds the completed tarball and
manifest. No publication or remote mutation is performed by this packaging step.
