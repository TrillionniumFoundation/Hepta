#define STB_DIVIDE_IMPLEMENTATION
#include "stb_divide.h"
int *unsupported_pointer(int *p){return p;}
