#if defined(__clang__)
HEPTA_CC_FAMILY clang
HEPTA_CC_VERSION __clang_major__ __clang_minor__ __clang_patchlevel__
#elif defined(_MSC_VER)
HEPTA_CC_FAMILY msvc
HEPTA_CC_VERSION _MSC_FULL_VER _MSC_BUILD
#elif defined(__GNUC__)
HEPTA_CC_FAMILY gcc
HEPTA_CC_VERSION __GNUC__ __GNUC_MINOR__ __GNUC_PATCHLEVEL__
#else
#error Unsupported native C compiler family
#endif
#if defined(_WIN32)
HEPTA_CC_SYSTEM Windows
#elif defined(__APPLE__) && defined(__MACH__)
HEPTA_CC_SYSTEM Darwin
#elif defined(__linux__)
HEPTA_CC_SYSTEM Linux
#else
#error Unsupported native C operating system
#endif
#if defined(__x86_64__) || defined(_M_X64)
HEPTA_CC_MACHINE x86_64
#elif defined(__aarch64__) || defined(_M_ARM64)
HEPTA_CC_MACHINE aarch64
#else
#error Unsupported native C architecture
#endif
#if !defined(__STDC_VERSION__) || __STDC_VERSION__ != 201112L
#error The native matrix requires C11 mode
#endif
HEPTA_C_STANDARD __STDC_VERSION__
