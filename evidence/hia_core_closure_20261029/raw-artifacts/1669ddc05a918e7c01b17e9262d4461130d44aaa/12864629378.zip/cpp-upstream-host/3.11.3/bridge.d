/Users/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/bridge.o: \
  /Users/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/bridge/bridge.cpp \
  /Users/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/bridge/bridge.h \
  /Users/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/selected.hpp \
  /Users/runner/work/Hepta/Hepta/tests/fixtures/cpp_upgrade/3.11.3/json.hpp \
  /Users/runner/work/Hepta/Hepta/examples/cpp/upgrade/adapter.hpp
