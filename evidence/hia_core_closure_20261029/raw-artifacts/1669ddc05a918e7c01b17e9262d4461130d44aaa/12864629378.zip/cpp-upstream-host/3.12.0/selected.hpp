#pragma once
#include "/Users/runner/work/Hepta/Hepta/tests/fixtures/cpp_upgrade/3.12.0/json.hpp"
#include "/Users/runner/work/Hepta/Hepta/examples/cpp/upgrade/adapter.hpp"
