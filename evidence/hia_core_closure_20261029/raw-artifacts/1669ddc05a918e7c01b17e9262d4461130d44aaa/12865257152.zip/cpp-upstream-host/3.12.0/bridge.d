/home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.12.0/bridge.o: \
  /home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.12.0/bridge/bridge.cpp \
  /home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.12.0/bridge/bridge.h \
  /home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.12.0/selected.hpp \
  /home/runner/work/Hepta/Hepta/tests/fixtures/cpp_upgrade/3.12.0/json.hpp \
  /home/runner/work/Hepta/Hepta/examples/cpp/upgrade/adapter.hpp
