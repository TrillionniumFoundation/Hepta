/home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/bridge.o: \
  /home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/bridge/bridge.cpp \
  /home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/bridge/bridge.h \
  /home/runner/work/Hepta/Hepta/artifacts/cpp-upstream-host/3.11.3/selected.hpp \
  /home/runner/work/Hepta/Hepta/tests/fixtures/cpp_upgrade/3.11.3/json.hpp \
  /home/runner/work/Hepta/Hepta/examples/cpp/upgrade/adapter.hpp
