#!/usr/bin/env python3
"""Read final receipts and raw logs only; never compile, run tests, or execute artifacts.

Run only after the parent confirms process.json and qualification.json are final:
    python audit_final_run.py --completed
"""
from pathlib import Path
import argparse
import ast
from collections import Counter
import datetime
import hashlib
import json
import os
import re
import signal
import stat
import subprocess

BASE = Path('/workspace/scratch/b484d4086829')
REPO = BASE / 'hepta'
FULL = BASE / 'final-qualification-699de39'
RUN = FULL / 'run'
SAFETY = BASE / 'final-safety-699de39'
OUT = Path(__file__).resolve().parent
SOURCE = '699de39a8e92e0f083df316ecc5333fb3ecf8571'
TREE = '592b6114f659fb18b13ad3fa5ed5e213ecdb92b5'
PINS = {'ranking': 'd3c2d760eca5065fc966820379c35c6e8d56e855',
        'recursive': '2590c0c94c5bf9a9004caeeb7b75edd6faf3eb8b',
        'finite': '4b6391e116949af0c7e59776baead67271856bdb',
        'stream': 'c4a1bbed3a39beba43a6abf1a18b6f75c5725c21'}
GATES = ['actual_tools_and_linux_seals', 'ranking_bridge_identity',
         'recursive_bridge_identity', 'finite_bridge_identity', 'stream_bridge_identity',
         'rust_resource_crate', 'full_regression', 'merge_and_profile_coverage']
READ_IDENTITIES = {}
REPORT = {'schema': 'hepta.independent-final-run-audit.v1', 'source_commit': SOURCE,
          'tests_rerun': False, 'native_artifacts_executed': False, 'source_modified': False,
          'scope': 'completed original logs, source and external identities, coverage and finite retained fixtures',
          'checks': [], 'findings': [], 'limitations': []}


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def check(name, passed, detail=None):
    row = {'name': name, 'passed': bool(passed)}
    if detail is not None:
        row['detail'] = detail
    REPORT['checks'].append(row)
    if not passed:
        REPORT['findings'].append({'check': name, 'detail': detail})
    return bool(passed)


def stable_identity(path, *, git_blob=None, git_mode=None):
    path = Path(path)
    initial = path.lstat()
    assert stat.S_ISREG(initial.st_mode), str(path)
    h = hashlib.sha256()
    g = hashlib.sha1(('blob ' + str(initial.st_size) + '\0').encode())
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        while block := stream.read(1024 * 1024):
            h.update(block)
            g.update(block)
        final_fd = os.fstat(stream.fileno())
    final_path = path.lstat()
    signatures = {(s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
                  for s in (initial, opened, final_fd, final_path)}
    assert len(signatures) == 1, 'Input changed during read: ' + str(path)
    mode = '100755' if initial.st_mode & stat.S_IXUSR else '100644'
    if git_blob is not None:
        assert g.hexdigest() == git_blob, 'Raw Git blob differs: ' + str(path)
    if git_mode is not None:
        assert mode == git_mode, 'Raw Git mode differs: ' + str(path)
    return {'bytes': initial.st_size, 'sha256': h.hexdigest(), 'git_blob': g.hexdigest(), 'git_mode': mode}


def read(path):
    path = Path(path)
    before = stable_identity(path)
    data = path.read_bytes()
    assert len(data) == before['bytes'] and hashlib.sha256(data).hexdigest() == before['sha256']
    assert stable_identity(path) == before
    READ_IDENTITIES[str(path)] = before
    return data


def load(path):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            assert key not in value, 'Duplicate JSON key: ' + key
            value[key] = item
        return value
    return json.loads(read(path), object_pairs_hook=unique)


def git(*args, root=REPO):
    return subprocess.check_output(['git', '--no-replace-objects', *map(str, args)], cwd=root,
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))


def constants(path):
    tree = ast.parse(read(path), filename=str(path))
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return result


def parse_python(log, returncode):
    # Main runner records begin at column zero. Subtest diagnostics do not
    # create additional method denominators. Expected failures never count as OK.
    summary = list(re.finditer(r'^Ran (\d+) tests? in ([0-9.]+)s\s*\n\s*'
                              r'(OK|FAILED)(?: \(([^\n]*)\))?\s*\Z', log, re.M))
    assert len(summary) == 1, 'One complete final unittest summary is required'
    last = summary[0]
    methods = list(re.finditer(r'^test\w+ \(((?:tests\.)?test_[^\s)]+)\)', log, re.M))
    rows = []
    for index, match in enumerate(methods):
        end = methods[index + 1].start() if index + 1 < len(methods) else last.start()
        segment = log[match.end():end]
        statuses = re.findall(r'\.\.\. (ok|FAIL|ERROR|expected failure|unexpected success|skipped[^\n]*)\s*$',
                              segment, re.M)
        rows.append({'method': match.group(1).removeprefix('tests.'),
                     'status': statuses[0] if len(statuses) == 1 else 'ambiguous_or_missing',
                     'status_records': len(statuses)})
    count = int(last.group(1))
    details = last.group(4)
    summary_counts = {'failures': 0, 'errors': 0, 'skipped': 0,
                      'expected failures': 0, 'unexpected successes': 0}
    unknown_details = []
    if details:
        for part in details.split(', '):
            field = re.fullmatch(r'(failures|errors|skipped|expected failures|unexpected successes)=(\d+)', part)
            if field:
                summary_counts[field.group(1)] = int(field.group(2))
            else:
                unknown_details.append(part)
    counts = Counter(row['status'] for row in rows)
    names = [row['method'] for row in rows]
    passed = (type(returncode) is int and returncode == 0 and last.group(3) == 'OK'
              and details is None and count > 0 and len(names) == len(set(names)) == count
              and all(row['status'] == 'ok' for row in rows))
    return {'passed': passed, 'tests_run': count, 'verbose_records': len(rows),
            'unique_methods': len(set(names)), 'summary_status': last.group(3),
            'summary_details': details, 'status_counts': dict(counts),
            'summary_counts': summary_counts, 'unknown_summary_details': unknown_details,
            'seconds': float(last.group(2)), 'methods': rows,
            'method_set_sha256': hashlib.sha256(wire(sorted(set(names)))).hexdigest()}


def parse_rust(stdout, stderr, returncode):
    starts = list(re.finditer(r'^running (\d+) tests?\s*$', stdout, re.M))
    harness_names = re.findall(r'^\s+(?:Running (.+)|Doc-tests (.+))\s*$', stderr, re.M)
    names = [left or 'Doc-tests ' + right for left, right in harness_names]
    rows = []
    for index, start in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else len(stdout)
        block = stdout[start.end():end]
        summaries = list(re.finditer(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; '
                                    r'(\d+) ignored; (\d+) measured; (\d+) filtered out; '
                                    r'finished in ([0-9.]+)s\s*$', block, re.M))
        assert len(summaries) == 1, 'Each Rust harness needs one complete result'
        summary = summaries[0]
        assert not block[summary.end():].strip(), 'Unaccounted output after Rust harness result'
        tests = re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored(?:[^\n]*))\s*$',
                           block[:summary.start()], re.M)
        passed, failed, ignored, measured, filtered = map(int, summary.group(2, 3, 4, 5, 6))
        declared = int(start.group(1))
        strict = (summary.group(1) == 'ok' and failed == ignored == measured == filtered == 0
                  and declared == passed == len(tests) == len({name for name, _ in tests})
                  and all(status == 'ok' for _, status in tests))
        rows.append({'harness': names[index] if index < len(names) else None,
                     'declared_tests': declared, 'passed': passed, 'failed': failed,
                     'ignored': ignored, 'measured': measured, 'filtered_out': filtered,
                     'method_records': len(tests), 'strict_success': strict,
                     'methods_sha256': hashlib.sha256(wire(tests)).hexdigest()})
    total = sum(row['passed'] + row['failed'] for row in rows)
    return {'passed': type(returncode) is int and returncode == 0 and bool(rows) and total > 0
            and len(rows) == len(names) and all(row['strict_success'] for row in rows),
            'tests_run': total, 'test_binaries': len(rows), 'harnesses': rows,
            **{key: sum(row[key] for row in rows) for key in ('failed', 'ignored', 'measured', 'filtered_out')}}


def source_checks(report, process):
    snapshots = [report['source_before'], report['source_after'],
                 load(FULL / 'source-before.json'), load(FULL / 'source-after.json'),
                 load(SAFETY / 'source-before.json'), load(SAFETY / 'source-after.json')]
    check('all_six_raw_source_snapshots_identical_exact_source',
          all(s == snapshots[0] for s in snapshots) and snapshots[0]['head'] == SOURCE
          and snapshots[0]['tree'] == TREE and snapshots[0]['status'] == ''
          and len(snapshots[0]['files']) == 4385
          and report['source_unchanged'] is True and process['source_unchanged'] is True,
          {'snapshots': len(snapshots), 'source_files': len(snapshots[0]['files'])})
    check('audit_checkout_still_exact_raw_public_head',
          git('rev-parse', 'HEAD').decode().strip() == SOURCE
          and git('rev-parse', SOURCE + '^{tree}').decode().strip() == TREE
          and git('status', '--porcelain', '--untracked-files=all').decode() == '')
    raw = git('ls-tree', '-r', '-t', '--full-tree', '-z', TREE)
    entries = {}
    for record in raw.split(b'\0')[:-1]:
        meta, raw_name = record.split(b'\t', 1)
        mode, kind, blob = meta.decode().split(' ')
        name = raw_name.decode()
        assert all(part not in ('', '.', '..', '.git') for part in name.split('/'))
        assert mode == '040000' and kind == 'tree' or mode in ('100644', '100755') and kind == 'blob'
        if kind == 'blob':
            assert name not in entries
            entries[name] = (mode, blob)
    check('source_inventory_is_complete_raw_tree_blob_set', set(entries) == set(snapshots[0]['files']))
    actual = {}
    for name, (mode, blob) in entries.items():
        actual[name] = stable_identity(REPO / name, git_blob=blob, git_mode=mode)['sha256']
    check('4385_current_source_bytes_and_modes_match_raw_git_and_both_snapshots',
          len(actual) == 4385 and actual == snapshots[0]['files'],
          {'raw_blob_and_mode_verified_files': len(actual),
           'historical_manifest_has_explicit_per_file_modes': False,
           'historical_mode_binding': 'frozen collector _source_state validates raw Git mode at both snapshots; independent audit rechecks current mode'})
    return snapshots[0]


def option(argv, flag):
    assert argv.count(flag) == 1, flag
    return argv[argv.index(flag) + 1]


def external_and_tool_checks(report, gates, invocation):
    before, after = report['external_inventory_before'], report['external_inventory_after']
    check('external_inventory_before_after_exact', before == after and bool(before)
          and report['external_inputs_unchanged'] is True and 'external_identity_error' not in report,
          {'entries': len(before)})
    mismatches = []
    for name, expected in before.items():
        if stable_identity(Path(name))['sha256'] != expected:
            mismatches.append(name)
    check('every_external_input_still_matches_its_observed_digest', not mismatches,
          {'files_rehashed': len(before), 'mismatches': mismatches})
    tool_gate = gates['actual_tools_and_linux_seals']
    expected_tools = {'python', 'clang', 'clangxx', 'cargo', 'rustc', 'gcc', 'gxx', 'lld',
                      'llvm_readobj', 'qemu_aarch64', 'qemu_riscv64', 'qemu_x86_64', 'qemu_system_arm', 'lean'}
    check('all_declared_actual_tool_version_probes_present', set(tool_gate['tools']) == expected_tools)
    tools = []
    for name, tool in tool_gate['tools'].items():
        saved = load(RUN / (name + '-tool-probe.json'))
        execution = tool['execution']
        okay = (saved == tool and execution['returncode'] == 0
                and bool((execution['stdout'] + execution['stderr']).strip())
                and execution['argv'][0] == tool['invocation_path']
                and '--version' in execution['argv']
                and str(Path(tool['invocation_path']).resolve(strict=True)) == tool['path']
                and before.get(tool['path']) == tool['sha256'])
        check('actual_version_and_identity_' + name, okay)
        tools.append({'tool': name, 'sha256': tool['sha256'], 'path': tool['path'],
                      'version_first_line': (execution['stdout'] + execution['stderr']).strip().splitlines()[0]})
    REPORT['actual_tools'] = tools
    seals = tool_gate['linux_seals']
    check('actual_linux_seal_observation', seals['required_bits'] == 15
          and seals['actual_bits'] & 15 == 15 and seals['actual_write_rejected_errno'] == 1
          and seals['exact_readback'] is True)
    check('actual_solver_pin_and_library_binding', tool_gate['solver']['version'] == '4.15.4'
          and before.get(tool_gate['solver']['library_path']) == tool_gate['solver']['library_sha256'])
    native = []
    argv = invocation['argv']
    for profile, pin in PINS.items():
        gate = gates[profile + '_bridge_identity']
        binary = gate['binary']
        receipt_path = gate['receipt']
        identity = gate['identity']
        binary_hash = identity['binary_sha256'] if profile == 'ranking' else gate['binary_sha256']
        receipt_hash = identity['build_receipt_sha256'] if profile == 'ranking' else gate['receipt_sha256']
        actual_pin = identity['upstream_commit'] if profile == 'ranking' else identity['source_commit']
        check(profile + '_independent_pin_binary_and_receipt_binding', actual_pin == pin
              and before.get(binary) == binary_hash and before.get(receipt_path) == receipt_hash
              and str(Path(option(argv, '--' + profile + '-bridge')).resolve()) == binary)
        receipt = load(Path(receipt_path))
        upstream = Path(option(argv, '--' + profile + '-upstream'))
        source_maps = [gate['original_source_files']] if profile == 'ranking' else [gate['native_sources'], gate['bridge_sources']]
        source_files = {k: v for mapping in source_maps for k, v in mapping.items()}
        raw_tree = {}
        for entry in git('ls-tree', '-r', '-z', pin, root=upstream).split(b'\0')[:-1]:
            metadata, name = entry.split(b'\t', 1)
            mode, kind, blob = metadata.decode().split()
            raw_tree[name.decode()] = (mode, kind, blob)
        for name, sha in source_files.items():
            mode, kind, blob = raw_tree[name]
            assert kind == 'blob'
            assert stable_identity(upstream / name, git_blob=blob, git_mode=mode)['sha256'] == sha
            if profile != 'ranking':
                assert before[str(upstream / name)] == sha
        if profile == 'ranking':
            check('ranking_actual_control_and_frozen_lock', gate['response']['advisory_recommendation'] == 'control'
                  and gate['response']['upstream_commit'] == pin
                  and load(REPO / 'rust/hia-ndu-bridge/upstream.json')['commit'] == pin
                  and gate['response']['proves_program_safety'] is False)
            for name, digest in gate['build_inputs'].items():
                assert before[str(Path(receipt_path).parent / name)] == digest
        else:
            check(profile + '_actual_advisory_identity_and_no_authority',
                  receipt['identity'] == identity == gate['response']['identity']
                  and receipt['authority'] == identity['authority'] == gate['response']['authority'] == 'DENY_ALL'
                  and receipt['safety_certificate'] is identity['safety_certificate'] is gate['response']['safety_certificate'] is False
                  and str(Path(gate['manifest_binary_invocation']).resolve(strict=True)) == binary)
            for field, digest_field in [('native_sources', 'source_digest'), ('bridge_sources', 'bridge_digest')]:
                assert hashlib.sha256(wire(gate[field])).hexdigest() == identity[digest_field]
            for tool in gate['build_tools'].values():
                assert before[tool['path']] == tool['sha256']
            if profile == 'finite':
                plan = gate['finite_bundle']['plans'][gate['response']['advisory_candidate_id']]
                check('finite_actual_selected_continuation', [a['id'] for a in plan['actions']] == ['hold', 'install-fast'])
            else:
                check(profile + '_actual_selected_control', gate['response']['advisory_candidate_id'] == 'control')
            if profile == 'stream':
                session = gate['session_observation']
                check('stream_actual_two_request_sealed_session_and_cleanup',
                      session['requests'] == 2 and session['identity'] == identity
                      and session['binary_sha256'] == binary_hash and session['image_check_profile'] == 'sealed'
                      and session['initial_full_digest_verified'] is True and session['closed_after_context'] is True
                      and type(session['pid']) is int and session['pid'] > 0)
        native.append({'profile': profile, 'upstream_commit': actual_pin,
                       'binary_sha256': binary_hash, 'receipt_sha256': receipt_hash,
                       'source_files_checked_against_raw_upstream_git': len(source_files)})
    check('four_distinct_native_source_pins', len({row['upstream_commit'] for row in native}) == 4)
    REPORT['native_profiles'] = native


def masked_observation(payload):
    obs = payload['observations']
    assert payload['schema'] == 'hepta.filecheck-target-profile-regression.v1'
    assert all(row['returncode'] == 0 for row in payload['commands'])
    cpu = {'avx2': 1, 'avx512f': 0, 'avx512dq': 0, 'avx512vl': 0, 'xcr0': 7}
    assert obs['cpu'] == cpu
    assert obs['original_ci_host_features_reconstructed'] is False
    for label in ('raw', 'bound', 'c', 'alternate_bound'):
        expected_counts = [1] if label == 'raw' else [0, 1, 2, 3, 4, (1 << 64) - 1]
        assert [row['count'] for row in obs[label]] == expected_counts
        for row in obs[label]:
            output = [json.loads(line) for line in row['stdout'].splitlines()]
            assert output[0] == cpu and row['argv'][1:3] == ['-cpu', 'Haswell-v4']
            if label == 'raw':
                assert row['returncode'] == -signal.SIGILL
            else:
                assert row['returncode'] == 0
                assert output[1:] == [{'result': (1 << min(row['count'], 4)) - 1}]
    for driver in obs['linker_drivers'].values():
        assert driver['selected_before'] == driver['selected_after']
        assert driver['driver_before'] == driver['driver_after'] and driver['unchanged'] is True
        assert driver['selected_before']['sha256'] == driver['driver_before']['sha256']
        if driver['temporary_alias']:
            assert driver['temporary_alias_removed'] is True
    return {'actual_positive_invocations': 18, 'actual_sigill_negative_invocations': 1,
            'cpu': cpu, 'original_ci_host_features_reconstructed': False}


def fixture_checks(full_execution, safety_stdout, invocation):
    def get_payload(text):
        rows = []
        for line in text.splitlines():
            if line.startswith('{') and 'filecheck_target_profile_execution' in line:
                value = json.loads(line)
                if 'filecheck_target_profile_execution' in value:
                    rows.append(value['filecheck_target_profile_execution'])
        assert len(rows) == 1, 'Exactly one measured target fixture payload is required'
        return rows[0]
    full_payload = get_payload(full_execution['stdout'])
    safety_payload = get_payload(safety_stdout)
    check('full_actual_masked_cpu_positive_negative_stdout', True, masked_observation(full_payload))
    check('safety_actual_masked_cpu_positive_negative_stdout', True, masked_observation(safety_payload))
    retained = FULL / 'target-profile-fixtures/masked-cpu-lto'
    declared = invocation['environment'].get('HEPTA_FILECHECK_TARGET_EVIDENCE')
    check('full_target_fixture_directory_matches_declared_collector',
          declared is not None and Path(declared) / 'masked-cpu-lto' == retained and retained.is_dir())
    check('full_retained_execution_is_same_payload_as_full_stdout', load(retained / 'execution.json') == full_payload)
    for label, digest in full_payload['observations']['binary_identities'].items():
        check('full_actual_retained_' + label + '_binary_identity',
              stable_identity(retained / (label + '.so'))['sha256'] == digest)
    profile = load(retained / 'target-profile/profile.json')
    unsigned = {k: v for k, v in profile.items() if k != 'profile_sha256'}
    check('full_retained_target_profile_digest_flags_and_no_authority',
          hashlib.sha256(wire(unsigned)).hexdigest() == profile['profile_sha256']
          == full_payload['observations']['profile_sha256']
          and profile['target_cpu'] == 'znver4' and '-avx512f' in profile['signed_features']
          and '+avx512f' not in profile['signed_features']
          and profile['default_backend_receipt'] is False and profile['program_admission_authority'] is False)
    for filename, field in [('raw.ll', 'original_ir_sha256'), ('bound.ll', 'bound_ir_sha256')]:
        check('full_retained_' + filename + '_identity', stable_identity(retained / filename)['sha256'] == profile[field])
    REPORT['limitations'].append('Safety collector used HEPTA_FILECHECK_TARGET_FIXTURES rather than the recognized evidence variable: its original stdout observations are audited, but no safety-run fixture binary is reconstructed or claimed retained.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--completed', action='store_true', required=True,
                        help='Use only after parent confirms final process and qualification records exist')
    parser.parse_args()
    required = [FULL / 'process.json', FULL / 'source-after.json', RUN / 'qualification.json',
                RUN / 'full_regression-execution.json', RUN / 'merge-and-profile-coverage.json']
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        raise RuntimeError('Final audit is not ready; missing completed records: ' + ', '.join(missing))
    REPORT['started_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = load(FULL / 'process.json')
    report = load(RUN / 'qualification.json')
    invocation = load(FULL / 'invocation.json')
    safety_process = load(SAFETY / 'process.json')
    safety = load(SAFETY / 'qualification.json')
    check('completed_main_process_outcome_and_exact_source', type(process['returncode']) is int
          and process['returncode'] == (0 if report['ok'] else 1) and process['source_commit'] == SOURCE
          and bool(process['finished_utc']) and bool(report['finished_utc'])
          and option(invocation['argv'], '--expected-head') == SOURCE)
    for folder, receipt in [(FULL, process), (SAFETY, safety_process)]:
        for name in ('stdout', 'stderr'):
            digest = hashlib.sha256(read(folder / (name + '.log'))).hexdigest()
            check(folder.name + '_' + name + '_complete_process_capture', digest == receipt[name + '_sha256'])
    check('exact_eight_gate_order_and_consistent_overall_report',
          [g['name'] for g in report['gates']] == GATES
          and all(type(g['passed']) is bool for g in report['gates'])
          and report['ok'] == (all(g['passed'] for g in report['gates'])
                               and report['source_unchanged'] and report['external_inputs_unchanged'])
          and report['status'] == ('bounded_integrated_contracts_passed' if report['ok'] else 'integration_qualification_failed'))
    gates = {row['name']: row for row in report['gates']}
    for name in GATES:
        filename = ('merge-and-profile-coverage.json' if name == 'merge_and_profile_coverage'
                    else name + ('-execution.json' if name in ('rust_resource_crate', 'full_regression') else '.json'))
        check('original_gate_file_matches_final_report_' + name, load(RUN / filename) == gates[name])
    source = source_checks(report, process)
    rust_exec, python_exec = gates['rust_resource_crate']['execution'], gates['full_regression']['execution']
    check('raw_rust_execution_is_locked_offline_crate_command',
          rust_exec['argv'][1:] == ['test', '--locked', '--offline', '--manifest-path', 'rust/hia-core-shadow/Cargo.toml']
          and 'capture_error' not in rust_exec)
    check('raw_python_execution_is_one_complete_discovery',
          python_exec['argv'][1:] == ['-m', 'unittest', 'discover', '-s', 'tests', '-v']
          and 'capture_error' not in python_exec)
    rust = parse_rust(rust_exec['stdout'], rust_exec['stderr'], rust_exec['returncode'])
    python = parse_python(python_exec['stderr'], python_exec['returncode'])
    selected = parse_python(safety['log'], safety_process['returncode'])
    check('raw_rust_every_harness_and_method_strict_success', rust['passed'], rust)
    check('raw_python_every_actual_method_has_unambiguous_status',
          python['tests_run'] == python['verbose_records'] == python['unique_methods']
          and 'ambiguous_or_missing' not in python['status_counts']
          and python['unknown_summary_details'] == [],
          {k: v for k, v in python.items() if k != 'methods'})
    check('raw_safety_every_actual_method_strict_success', selected['passed'],
          {k: v for k, v in selected.items() if k != 'methods'})
    check('recomputed_counts_match_reported_rust_and_python_outcomes',
          rust['tests_run'] == gates['rust_resource_crate']['tests_run']
          and rust['test_binaries'] == gates['rust_resource_crate']['test_binaries']
          and python['tests_run'] == gates['full_regression']['tests_run']
          and rust['passed'] == gates['rust_resource_crate']['passed']
          and python['passed'] == gates['full_regression']['passed']
          and all(python['summary_counts'][key] == gates['full_regression'][key]
                  for key in ('failures', 'errors', 'skipped'))
          and rust['failed'] == gates['rust_resource_crate']['failures']
          and rust['ignored'] == gates['rust_resource_crate']['skipped'])
    diagnostics = re.findall(r'^(ERROR|FAIL): (.+)$', python_exec['stderr'], re.M)
    failed_methods = [row for row in python['methods'] if row['status'] != 'ok']
    REPORT['recorded_run_outcome'] = {
        'qualification_passed': report['ok'], 'process_returncode': process['returncode'],
        'gate_statuses': {name: gates[name]['passed'] for name in GATES},
        'python_strict_success': python['passed'], 'python_summary_counts': python['summary_counts'],
        'nonpassing_methods': failed_methods, 'diagnostic_headers': diagnostics}
    check('raw_python_error_failure_diagnostics_match_counts',
          sum(kind == 'ERROR' for kind, _ in diagnostics) == python['summary_counts']['errors']
          and sum(kind == 'FAIL' for kind, _ in diagnostics) == python['summary_counts']['failures'])
    error_start = python_exec['stderr'].find('\n======================================================================\n')
    if error_start >= 0:
        (OUT / 'recorded-error-diagnostics.log').write_text(python_exec['stderr'][error_start:] )
    source_constants = constants(REPO / 'tools/qualify_hia_integrated.py')
    critical = source_constants['CRITICAL_MODULES']
    unique_modules = set(module for modules in critical.values() for module in modules)
    plan = load(RUN / 'frozen-plan.json')
    check('frozen_plan_matches_47_groups_119_unique_source_modules',
          len(critical) == 47 and len(unique_modules) == 119
          and plan['critical_modules'] == {k: list(v) for k, v in critical.items()}
          and plan['source_head'] == SOURCE and plan['source_tree'] == TREE)
    methods = {row['method'] for row in python['methods']}
    coverage = {group: {module: sorted(m for m in methods if m.startswith(module + '.'))
                        for module in modules} for group, modules in critical.items()}
    missing_modules = sorted({module for group in coverage.values() for module, records in group.items() if not records})
    recorded_coverage = gates['merge_and_profile_coverage']
    check('independently_recomputed_full_run_critical_coverage', not missing_modules
          and recorded_coverage['groups'] == coverage
          and recorded_coverage['unique_method_records'] == recorded_coverage['verbose_method_records'] == len(methods)
          and recorded_coverage['missing_modules'] == []
          and recorded_coverage['subsets_of_full_regression_only'] is True
          and recorded_coverage['passed'] == (python['passed'] and not missing_modules),
          {'groups': len(coverage), 'unique_modules': len(unique_modules),
           'unique_full_methods': len(methods), 'missing_modules': missing_modules})
    contract = load(REPO / 'docs/HIA_SAFETY_CONTRACT.json')
    selector_list = [name for capability in contract['capabilities'] for name in capability['regression_selectors']]
    selectors = {name.removeprefix('tests.') for name in selector_list}
    safety_names = {row['method'] for row in selected['methods']}
    check('95_actual_safety_methods_are_exact_contract_and_subset_of_full',
          len(selectors) == len(safety_names) == selected['tests_run'] == safety['tests_run'] == 95
          and selectors == safety_names and selectors <= methods
          and {name.removeprefix('tests.') for name in safety['tests']} == selectors
          and all(row['status'] == 'passed' for row in safety['tests'].values()),
          {'actual_safety_methods': len(safety_names), 'missing_from_full': sorted(selectors - methods),
           'denominator_policy': 'Safety and critical group memberships are subsets; never added to the full Python or Rust counts.'})
    check('safety_source_and_reviewed_contract_stable', safety['contract'] == contract
          and hashlib.sha256(wire(contract)).hexdigest() == safety['contract_sha256'] == safety['reviewed_contract_sha256']
          == '01dbcbee699def90fd3d3fe13211b861c564386625b13bfbf957ccc20232c1f3'
          and safety['source_before'] == safety['source_after']
          and all(source['files'][name] == digest for name, digest in safety['source_before'].items())
          and safety['head_before']['stdout'].strip() == safety['head_after']['stdout'].strip() == SOURCE
          and safety['head_before']['returncode'] == safety['head_after']['returncode'] == 0
          and safety['status'] == 'passed' and safety['source_stable'] is True)
    REPORT['method_denominators'] = {'rust': rust['tests_run'], 'rust_harnesses': rust['test_binaries'],
                                     'python_full': len(methods), 'safety_subset': len(selectors),
                                     'critical_groups': len(critical), 'unique_critical_modules': len(unique_modules),
                                     'combined_distinct_task_count_claimed': False}
    (OUT / 'method-status-index.json').write_text(json.dumps({
        'full_python': python['methods'], 'safety_subset': selected['methods'], 'rust_harnesses': rust['harnesses'],
        'critical_module_unique_method_counts': {m: len({n for n in methods if n.startswith(m + '.')}) for m in sorted(unique_modules)}},
        indent=2, sort_keys=True) + '\n')
    external_and_tool_checks(report, gates, invocation)
    fixture_checks(python_exec, read(SAFETY / 'stdout.log').decode(), invocation)
    check('full_scope_does_not_promote_historical_campaigns_or_global_claims',
          report['historical_evidence_reused_as_current'] is False
          and report['standalone_performance_campaigns_replayed'] is False
          and report['scientific_incremental_advantage_established'] is False
          and report['whole_language_soundness_proved'] is False
          and report['global_optimality_established'] is False and report['six_stages_closed'] is False)
    check('all_reviewed_original_records_unchanged_during_audit',
          all(stable_identity(Path(path)) == expected for path, expected in READ_IDENTITIES.items()),
          {'input_records_rechecked': len(READ_IDENTITIES)})
    REPORT['input_identities'] = READ_IDENTITIES
    REPORT['qualification_passed'] = (process['returncode'] == 0 and rust['passed'] and python['passed']
                                      and selected['passed'] and all(g['passed'] for g in gates.values())
                                      and report['source_unchanged'] and report['external_inputs_unchanged'])
    check('independent_qualification_result_matches_original', REPORT['qualification_passed'] == report['ok'])
    REPORT['ok'] = not REPORT['findings']
    REPORT['audit_integrity_ok'] = REPORT['ok']
    REPORT['status'] = ('independently_verified_successful_attempt' if REPORT['qualification_passed'] else
                        'independently_verified_failed_attempt') if REPORT['ok'] else 'independent_review_found_inconsistencies'


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        REPORT.update(ok=False, status='independent_review_incomplete_or_failed')
        REPORT['findings'].append({'exception': type(exc).__name__, 'message': str(exc)})
        raise
    finally:
        REPORT['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (OUT / 'audit.json').write_text(json.dumps(REPORT, indent=2, sort_keys=True) + '\n')
        print(json.dumps({'ok': REPORT.get('ok'), 'status': REPORT.get('status'),
                          'checks': len(REPORT['checks']), 'findings': REPORT['findings']}))
