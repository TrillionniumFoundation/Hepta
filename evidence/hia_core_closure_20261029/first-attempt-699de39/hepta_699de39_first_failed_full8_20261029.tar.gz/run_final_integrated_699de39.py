from datetime import datetime, timezone
from hashlib import sha256
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace

workspace = Path('/workspace/scratch/b484d4086829')
root = workspace / 'hepta'
native = workspace / 'toolchains/native'
rust = workspace / 'toolchains/rust-1.90.0'
parser = argparse.ArgumentParser()
parser.add_argument('--preflight-only', action='store_true')
args = parser.parse_args()
output = workspace / ('integrated-preflight-699de39' if args.preflight_only else 'final-qualification-699de39')
output.mkdir(exist_ok=False)
env = dict(os.environ)
env.update(
    PATH=f'{native}/usr/lib/llvm-20/bin:{native}/usr/bin:{rust}/bin:' + env['PATH'],
    LD_LIBRARY_PATH=f'{native}/usr/lib/x86_64-linux-gnu',
    PYTHONPATH=f'{workspace}/toolchains/python-deps:{root}',
    CLANG=f'{native}/usr/lib/llvm-20/bin/clang',
    CLANGXX=f'{native}/usr/lib/llvm-20/bin/clang++',
    RUSTC=f'{rust}/bin/rustc', CARGO=f'{rust}/bin/cargo',
    LEAN=f'{workspace}/toolchains/lean-4.19.0/bin/lean',
    HEPTA_LLD=f'{rust}/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld',
    HEPTA_LLVM_READOBJ=f'{native}/usr/lib/llvm-20/bin/llvm-readobj',
    HEPTA_QEMU_X86_64=f'{native}/usr/bin/qemu-x86_64',
    HEPTA_QEMU_RISCV64=f'{native}/usr/bin/qemu-riscv64',
    HEPTA_QEMU_AARCH64=f'{workspace}/toolchains/qemu-8.2.2/qemu-aarch64-static',
    CARGO_HOME='/workspace/scratch/0db0c44c1fb0/rust-tools/cargo',
    CARGO_TARGET_DIR=f'{workspace}/target-rust-policy-v3-190',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
    HEPTA_FILECHECK_TARGET_EVIDENCE=f'{output}/target-profile-fixtures',
)
os.environ.update(env)
sys.path[:0] = [str(root), str(workspace / 'toolchains/python-deps')]
from tools import qualify_hia_integrated as integrated

native_options = json.loads((workspace / 'native-dependencies/integrated-native-options.json').read_text())
options = SimpleNamespace(**{k: Path(v) if k not in ('finite_cargo', 'finite_rustc') else v
                            for k, v in native_options.items()},
    clang=env['CLANG'], cargo=env['CARGO'], rustc=env['RUSTC'],
    expected_head='699de39a8e92e0f083df316ecc5333fb3ecf8571',
    cargo_target_dir=workspace / 'target-rust-policy-v3-190',
    output_directory=output / 'run', timeout=3600)
before = integrated._source_state()
assert before['head'] == options.expected_head and before['status'] == ''
(output / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')

if args.preflight_only:
    rows = []
    with integrated._environment(options, output):
        for label, function in (
            ('actual_tools_and_linux_seals', integrated._tool_gate),
            ('ranking_bridge_identity', integrated._ranking_gate),
            ('recursive_bridge_identity', integrated._recursive_gate),
            ('finite_bridge_identity', integrated._finite_gate),
            ('stream_bridge_identity', integrated._stream_gate),
        ):
            try:
                record = {'name': label, **function(options, output)}
            except Exception as error:
                record = {'name': label, 'passed': False, 'error': type(error).__name__ + ': ' + str(error)}
            rows.append(record)
            (output / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
            print(json.dumps({k: record[k] for k in ('name', 'passed', 'error') if k in record}), flush=True)
            if not record['passed']:
                raise SystemExit(1)
    after = integrated._source_state()
    report = {'preflight_only': True, 'gates': rows, 'source_unchanged': before == after,
              'source_commit': before['head'], 'full_regression_executed': False}
    (output / 'preflight.json').write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(0 if before == after else 1)

argv = [sys.executable, 'tools/qualify_hia_integrated.py',
    '--expected-head', options.expected_head,
    '--output-directory', str(options.output_directory),
    '--clang', options.clang, '--cargo', options.cargo, '--rustc', options.rustc,
    '--cargo-target-dir', str(options.cargo_target_dir), '--timeout', str(options.timeout),
    *json.loads((workspace / 'native-dependencies/integrated-native-args.json').read_text())]
(output / 'invocation.json').write_text(json.dumps({'argv': argv, 'environment': {
    k: env.get(k) for k in ('PATH', 'LD_LIBRARY_PATH', 'PYTHONPATH', 'CARGO_HOME',
        'CARGO_TARGET_DIR', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'CARGO_INCREMENTAL',
        'LEAN', 'HEPTA_LLD', 'HEPTA_LLVM_READOBJ', 'HEPTA_QEMU_AARCH64',
        'HEPTA_QEMU_RISCV64', 'HEPTA_QEMU_X86_64', 'HEPTA_FILECHECK_TARGET_EVIDENCE')}}, indent=2) + '\n')
started = datetime.now(timezone.utc).isoformat()
tick = time.monotonic()
with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
    proc = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=7600)
after = integrated._source_state()
(output / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
record = {'source_commit': before['head'], 'returncode': proc.returncode,
    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'wall_seconds': time.monotonic()-tick, 'source_unchanged': before == after,
    'stdout_sha256': sha256((output / 'stdout.log').read_bytes()).hexdigest(),
    'stderr_sha256': sha256((output / 'stderr.log').read_bytes()).hexdigest()}
(output / 'process.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if proc.returncode == 0 and before == after else 1)
