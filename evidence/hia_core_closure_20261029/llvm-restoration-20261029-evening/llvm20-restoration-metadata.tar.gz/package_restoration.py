#!/usr/bin/env python3
"""Retain public restoration metadata, original logs, and native probes; no compiler tree duplication."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import stat
import tarfile

ROOT=Path(__file__).resolve().parent
NAME='llvm20-restoration-metadata.tar.gz'
EXCLUDE={NAME,'metadata-retention.json','metadata-archive-receipt.json','publication-metadata.json','package.stdout.log','package.stderr.log'}

def identity(p):
    h=hashlib.sha256();g=hashlib.sha1();s=p.stat();g.update(f'blob {s.st_size}\0'.encode())
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);g.update(b)
    return {'bytes':s.st_size,'sha256':h.hexdigest(),'git_blob_sha1':g.hexdigest(),'mode':oct(stat.S_IMODE(s.st_mode))}

def save(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')

files=[]
for p in sorted(ROOT.rglob('*')):
    rel=p.relative_to(ROOT)
    if any(part in {'gpg-home','data-archives','__pycache__'} for part in rel.parts):continue
    if rel.parts[0]=='packages' and not p.name.endswith('.json'):continue
    if p.is_dir():continue
    assert p.is_file() and not p.is_symlink(),p
    if str(rel) in EXCLUDE:continue
    files.append({'path':str(rel),**identity(p)})
manifest={'schema':'hepta.llvm20-restoration-retention.v1','files':files,'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'excluded_large_reproducible_files':['packages/*.deb','data-archives/*.tar','../toolchains/llvm20-evening/**'],'raw_large_files_retained_locally':True,'contains_private_transport':False}
save(ROOT/'metadata-retention.json',manifest)
members=files+[{'path':'metadata-retention.json',**identity(ROOT/'metadata-retention.json')}]
with (ROOT/NAME).open('wb') as out:
    with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as gz:
        with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
            for row in members:
                p=ROOT/row['path'];info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=int(row['mode'],8);info.mtime=0
                with p.open('rb') as f:tf.addfile(info,f)
expected={x['path']:x for x in members};seen=[]
with tarfile.open(ROOT/NAME,'r:gz') as tf:
    for m in tf:
        assert m.isfile() and m.name in expected and m.name not in seen,m.name
        x=expected[m.name];h=hashlib.sha256();g=hashlib.sha1();g.update(f'blob {m.size}\0'.encode());size=0
        with tf.extractfile(m) as f:
            for b in iter(lambda:f.read(1024*1024),b''):size+=len(b);h.update(b);g.update(b)
        assert (size,h.hexdigest(),g.hexdigest(),oct(m.mode))==(x['bytes'],x['sha256'],x['git_blob_sha1'],x['mode']),m.name
        seen.append(m.name)
assert set(seen)==set(expected)
with gzip.open(ROOT/NAME,'rb') as f:
    decoded=0
    for b in iter(lambda:f.read(1024*1024),b''):decoded+=len(b)
for row in members:assert identity(ROOT/row['path'])=={k:v for k,v in row.items() if k!='path'},row['path']
receipt={'schema':'hepta.llvm20-restoration-archive.v1','archive':NAME,**identity(ROOT/NAME),'input_files':len(files),'archive_members':len(members),'uncompressed_member_bytes':sum(x['bytes'] for x in members),'decoded_tar_bytes':decoded,'all_paths_modes_bytes_sha256_git_blob_readbacks_passed':True,'gzip_eof_crc_consumed':True,'selected_inputs_unchanged_after_pack_readback':True}
save(ROOT/'metadata-archive-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
