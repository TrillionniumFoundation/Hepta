#!/usr/bin/env python3
"""Extract verified Debian data archives to an isolated prefix; run no maintainer scripts."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent
PREFIX = ROOT.parent / "toolchains" / "llvm20-evening"

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def save(p,obj): p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

if PREFIX.exists() and any(PREFIX.iterdir()):
    raise SystemExit('refusing nonempty prefix')
PREFIX.mkdir(parents=True,exist_ok=True)
(ROOT/'data-archives').mkdir(exist_ok=True)
selected=json.loads((ROOT/'selected-packages.json').read_text())
rows=[]
paths={}
for s in selected:
    p=ROOT/'packages'/PurePosixPath(s['filename']).name
    assert p.stat().st_size==s['bytes'] and sha(p)==s['sha256']
    dest=ROOT/'data-archives'/(s['package']+'.tar')
    argv=['/usr/bin/dpkg-deb','--fsys-tarfile',str(p)]
    begin=time.monotonic()
    started=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    with dest.open('wb') as out:
        proc=subprocess.run(argv,stdout=out,stderr=subprocess.PIPE,timeout=60)
    (ROOT/'processes'/(s['package']+'-data.stderr.log')).write_bytes(proc.stderr)
    save(ROOT/'processes'/(s['package']+'-data.json'),{'argv':argv,'returncode':proc.returncode,'started_utc':started,'elapsed_seconds':time.monotonic()-begin,'data_archive':str(dest.relative_to(ROOT)),'bytes':dest.stat().st_size,'sha256':sha(dest),'stderr_path':'processes/'+s['package']+'-data.stderr.log'})
    assert proc.returncode==0, proc.stderr
    items=[]
    with tarfile.open(dest,'r:') as tf:
        for m in tf.getmembers():
            if m.name=='.': continue
            n=m.name[2:] if m.name.startswith('./') else m.name
            path=PurePosixPath(n)
            assert not path.is_absolute() and '..' not in path.parts and str(path)==n.rstrip('/'), n
            assert m.isdir() or m.isfile() or m.issym() or m.islnk(), (n,m.type)
            tarfile.data_filter(m,str(PREFIX))
            if m.isdir(): continue
            row={'path':str(path),'kind':'file' if m.isfile() else 'symlink' if m.issym() else 'hardlink','mode':oct(m.mode),'package':s['package']}
            if m.isfile():
                h=hashlib.sha256()
                with tf.extractfile(m) as f:
                    for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
                row.update(bytes=m.size,sha256=h.hexdigest())
            else: row['link_target']=m.linkname
            if n in paths:
                assert {k:v for k,v in paths[n].items() if k!='package'}=={k:v for k,v in row.items() if k!='package'},n
            paths[n]=row
            items.append(row)
        tf.extractall(PREFIX,filter='data')
    rows.append({'package':s['package'],'package_sha256':s['sha256'],'members':len(items),'data_archive_sha256':sha(dest)})
    print(json.dumps({'extracted':s['package'],'members':len(items)}),flush=True)
for n,row in paths.items():
    p=PREFIX/n
    if row['kind']=='file':
        assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],n
    elif row['kind']=='symlink':
        assert p.is_symlink() and os.readlink(p)==row['link_target'],n
        resolved=p.resolve()
        assert resolved==PREFIX or PREFIX in resolved.parents,(n,resolved)
    else:
        assert p.is_file(),n
save(ROOT/'installed-files.json',{'prefix':str(PREFIX),'files':list(paths.values()),'all_member_readbacks_passed':True})
save(ROOT/'extraction-receipt.json',{'prefix':str(PREFIX),'packages':rows,'members':len(paths),'regular_files':sum(x['kind']=='file' for x in paths.values()),'symlinks':sum(x['kind']=='symlink' for x in paths.values()),'hardlinks':sum(x['kind']=='hardlink' for x in paths.values()),'ok':True,'system_apt_changes':False,'maintainer_scripts_executed':False})
print(json.dumps({'ok':True,'prefix':str(PREFIX),'members':len(paths)}),flush=True)
