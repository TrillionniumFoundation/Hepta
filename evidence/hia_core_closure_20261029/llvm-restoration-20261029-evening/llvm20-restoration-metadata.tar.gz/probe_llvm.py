#!/usr/bin/env python3
"""Observe actual restored LLVM startup and tiny host C/C++/LLVM execution."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT=Path(__file__).resolve().parent
PREFIX=ROOT.parent/'toolchains/llvm20-evening'
BIN=PREFIX/'usr/lib/llvm-20/bin'
WORK=ROOT/'probes'
WORK.mkdir(exist_ok=True)
LIBS=str(PREFIX/'usr/lib/x86_64-linux-gnu')+':'+str(PREFIX/'usr/lib/llvm-20/lib')
ENV=os.environ.copy()
ENV['PATH']=str(BIN)+':'+ENV.get('PATH','')
ENV['LD_LIBRARY_PATH']=LIBS+(':'+ENV['LD_LIBRARY_PATH'] if ENV.get('LD_LIBRARY_PATH') else '')
rows=[]

def identity(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return {'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':h.hexdigest()}

def save(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def run(label,argv,expected_stdout=None):
    started=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());start=time.monotonic()
    p=subprocess.run([str(x) for x in argv],cwd=WORK,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    stdout=WORK/(label+'.stdout.log');stderr=WORK/(label+'.stderr.log')
    stdout.write_bytes(p.stdout);stderr.write_bytes(p.stderr)
    row={'label':label,'argv':[str(x) for x in argv],'cwd':str(WORK),'environment_override':{'PATH_prefix':str(BIN),'LD_LIBRARY_PATH_prefix':LIBS},'started_utc':started,'elapsed_seconds':time.monotonic()-start,'returncode':p.returncode,'stdout':identity(stdout),'stderr':identity(stderr),'expected_stdout':expected_stdout,'expected_stdout_matches':expected_stdout is None or p.stdout.decode()==expected_stdout}
    rows.append(row);save(WORK/(label+'.json'),row)
    assert p.returncode==0,(label,p.returncode,p.stderr.decode())
    assert row['expected_stdout_matches'],(label,p.stdout)
    return p.stdout.decode()

versions=[]
for tool in ['clang','clang++','llvm-readobj','llvm-ar','llvm-ranlib','ld.lld']:
    p=BIN/tool
    stdout=run(tool.replace('+','p')+'-version',[p,'--version'])
    assert '20.1.2' in stdout,(tool,stdout)
    versions.append({'tool':tool,**identity(p),'version':stdout})
libs={}
for tool in ['clang','llvm-readobj','llvm-ar','ld.lld']:
    stdout=run(tool+'-ldd',['/usr/bin/ldd',BIN/tool])
    assert 'not found' not in stdout,(tool,stdout)
    for line in stdout.splitlines():
        m=re.search(r'(?:=>\s+)?(/\S+)\s+\(0x[0-9a-f]+\)',line)
        if m:
            p=Path(m.group(1));libs[str(p.resolve())]=identity(p)

sources={
 'helper.ll':'''target triple = "x86_64-unknown-linux-gnu"
define i32 @hepta_probe_twice(i32 %x) {
entry:
  %r = mul i32 %x, 2
  ret i32 %r
}
''',
 'probe.c':'''#include <stdio.h>
#include <stdint.h>
extern int32_t hepta_probe_twice(int32_t x);
int main(void) {
  int32_t value = hepta_probe_twice(21);
  printf("llvm20-c-ir=%d\\n", (int)value);
  return value == 42 ? 0 : 1;
}
''',
 'probe.cpp':'''#include <iostream>
#include <memory>
#include <vector>
int main() {
  auto values = std::make_unique<std::vector<int>>(std::initializer_list<int>{19, 23});
  const int answer = values->at(0) + values->at(1);
  std::cout << "llvm20-cpp=" << answer << '\\n';
  return answer == 42 ? 0 : 1;
}
'''
}
for n,t in sources.items():(WORK/n).write_text(t)
run('resource-dir',[BIN/'clang','-print-resource-dir'])
run('llvm-ir-compile',[BIN/'clang','-x','ir','-O2','-c','helper.ll','-o','helper.o'])
run('archive-create',[BIN/'llvm-ar','rcs','libhelper.a','helper.o'])
run('archive-ranlib',[BIN/'llvm-ranlib','libhelper.a'])
run('archive-readobj',[BIN/'llvm-readobj','--file-headers','--symbols','libhelper.a'])
run('c-compile-link',[BIN/'clang','-std=c17','-O2','-Wall','-Wextra','-Werror','probe.c','libhelper.a','-fuse-ld=lld','-o','probe-c-ir'])
run('c-ir-execute',[WORK/'probe-c-ir'],'llvm20-c-ir=42\n')
run('cpp-compile-link',[BIN/'clang++','-std=c++20','-O2','-Wall','-Wextra','-Werror','-v','probe.cpp','-fuse-ld=lld','-o','probe-cpp'])
run('cpp-execute',[WORK/'probe-cpp'],'llvm20-cpp=42\n')
readout=run('executables-readobj',[BIN/'llvm-readobj','--file-headers','probe-c-ir','probe-cpp'])
assert readout.count('Machine: EM_X86_64')==2
summary={'ok':True,'llvm_package_version':'1:20.1.2-0ubuntu1~24.04.3','compiler_version':'20.1.2','environment':{'PATH_prefix':str(BIN),'LD_LIBRARY_PATH_prefix':LIBS},'tool_versions':versions,'runtime_libraries_observed':list(libs.values()),'processes':rows,'sources':[identity(WORK/n) for n in sources],'outputs':[identity(WORK/n) for n in ['helper.o','libhelper.a','probe-c-ir','probe-cpp']],'scope':'toolchain restoration and tiny native host startup/compile/link/run only; no full Hepta qualification or cross-target claim','host_standard_library':'pre-existing Debian 13 GCC 14 C/C++ headers/runtime; exact paths and driver observations retained','system_package_install':False,'source_repository_modified':False,'rust_toolchains_modified':False}
save(ROOT/'probe-summary.json',summary)
(ROOT/'llvm20-env.sh').write_text("# Isolated restored LLVM 20.1.2; source this file before native probes.\nexport PATH='"+str(BIN)+"':\"$PATH\"\nexport LD_LIBRARY_PATH='"+LIBS+"'${LD_LIBRARY_PATH:+:\"$LD_LIBRARY_PATH\"}\n")
print(json.dumps({'ok':True,'tool_versions':[{'tool':x['tool'],'sha256':x['sha256'],'first_version_line':x['version'].splitlines()[0]} for x in versions],'environment':summary['environment'],'processes':len(rows),'runtime_libraries':len(libs)},indent=2))
