#!/usr/bin/env python3
"""Retrieve an exact Ubuntu snapshot LLVM package set without system apt changes."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
PROV = ROOT / "provenance"
BASE = "https://snapshot.ubuntu.com/ubuntu/20260828T000000Z/"
FPR = "F6ECB3762474EDA9D21B7022871920D1991BC93C"
VERSION = "1:20.1.2-0ubuntu1~24.04.3"
KEY_SHA = "80a36b0a6de2f69f49d2df75ef473ccde121e9e190b9ea01d20a4f63778d5c31"
WANTED = ["clang-20", "libclang-common-20-dev", "libclang-cpp20", "libclang1-20",
          "libllvm20", "llvm-20", "llvm-20-runtime", "llvm-20-linker-tools", "lld-20",
          "libclang-rt-20-dev"]


def utc():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def identity(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
            size += len(chunk)
    return {"bytes": size, "sha256": h.hexdigest()}


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def fetch(url, target, expected=None):
    started = utc()
    attempts = []
    for attempt in range(1, 4):
        temp = target.with_name(target.name + ".partial")
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Hepta-exact-LLVM-restoration/1"})
            with urllib.request.urlopen(request, timeout=30) as response, temp.open("wb") as out:
                status = response.status
                final_url = response.url
                headers = dict(response.headers.items())
                while data := response.read(1024 * 1024):
                    out.write(data)
            got = identity(temp)
            if expected is not None and got != expected:
                raise ValueError(f"authenticated size/digest mismatch: {target.name}: {got} != {expected}")
            os.replace(temp, target)
            receipt = {"url": url, "final_url": final_url, "started_utc": started,
                       "completed_utc": utc(), "http_status": status,
                       "response_headers": headers, **got, "attempts": attempts,
                       "expected_from_authenticated_metadata": expected,
                       "verified": expected is not None,
                       "path": str(target.relative_to(ROOT))}
            save(target.with_name(target.name + ".download.json"), receipt)
            print(json.dumps({"download": target.name, **got, "verified": expected is not None}), flush=True)
            return receipt
        except Exception as exc:
            attempts.append({"attempt": attempt, "error": repr(exc), "time_utc": utc()})
            save(target.with_name(target.name + ".attempts.json"), attempts)
            if attempt == 3:
                raise


def run(label, argv):
    started = utc()
    begin = time.monotonic()
    p = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    stem = ROOT / "processes" / label
    stem.with_suffix(".stdout.log").write_bytes(p.stdout)
    stem.with_suffix(".stderr.log").write_bytes(p.stderr)
    row = {"argv": argv, "cwd": str(ROOT), "started_utc": started,
           "completed_utc": utc(), "elapsed_seconds": time.monotonic() - begin,
           "returncode": p.returncode,
           "stdout": {"path": str(stem.with_suffix('.stdout.log').relative_to(ROOT)), **identity(stem.with_suffix('.stdout.log'))},
           "stderr": {"path": str(stem.with_suffix('.stderr.log').relative_to(ROOT)), **identity(stem.with_suffix('.stderr.log'))}}
    save(stem.with_suffix(".json"), row)
    if p.returncode:
        raise RuntimeError(f"{label} failed: {p.returncode}: {p.stderr.decode(errors='replace')}")
    return p.stdout.decode()


def parse_deb822(text):
    records = []
    for para in text.split("\n\n"):
        if not para.strip():
            continue
        fields = {}
        previous = None
        for line in para.splitlines():
            if line.startswith((" ", "\t")):
                if previous is None:
                    raise ValueError("orphan continuation")
                fields[previous] += "\n" + line
            else:
                key, value = line.split(":", 1)
                if key in fields:
                    raise ValueError("duplicate Deb822 key")
                fields[key] = value.lstrip()
                previous = key
        records.append((fields, para + "\n"))
    return records


def authenticated_index(suite, component):
    key = PROV / "recovered-ubuntu-archive-keyring.gpg"
    assert identity(key)["sha256"] == KEY_SHA
    home = ROOT / "gpg-home"
    home.mkdir(mode=0o700, exist_ok=True)
    release = PROV / (suite + "-InRelease")
    if not release.exists():
        fetch(BASE + "dists/" + suite + "/InRelease", release)
    status = run(suite + "-signature", ["/usr/bin/gpg", "--batch", "--no-options", "--homedir", str(home),
                 "--no-default-keyring", "--keyring", str(key), "--status-fd", "1", "--verify", str(release)])
    valids = [line.split()[2] for line in status.splitlines() if line.startswith("[GNUPG:] VALIDSIG ")]
    if valids != [FPR]:
        raise ValueError(f"unexpected signing fingerprint(s): {valids}")
    if any(line.startswith(("[GNUPG:] BADSIG ", "[GNUPG:] ERRSIG ", "[GNUPG:] REVKEYSIG ", "[GNUPG:] EXPKEYSIG ")) for line in status.splitlines()):
        raise ValueError("invalid signature status")
    signed = release.read_text()
    hashes = {}
    active = False
    for line in signed.splitlines():
        if line == "SHA256:":
            active = True
            continue
        if active and line.startswith(" "):
            digest, size, relpath = line.split()
            if relpath in hashes:
                raise ValueError("duplicate signed index")
            hashes[relpath] = {"sha256": digest, "bytes": int(size)}
        elif active:
            active = False
    rel = f"{component}/binary-amd64/Packages.xz"
    compressed = PROV / f"{suite}-{component}-Packages.xz"
    fetch(BASE + "dists/" + suite + "/" + rel, compressed, hashes[rel])
    decoded = lzma.decompress(compressed.read_bytes())
    unpacked = PROV / f"{suite}-{component}-Packages"
    unpacked.write_bytes(decoded)
    if identity(unpacked) != hashes[rel.removesuffix(".xz")]:
        raise ValueError("uncompressed index mismatches signed release")
    recovered = PROV / ("recovered-" + suite + "-InRelease")
    row = {"suite": suite, "component": component, "signing_fingerprint": FPR,
           "release": {"path": str(release.relative_to(ROOT)), **identity(release)},
           "exact_recovered_release": recovered.exists() and identity(recovered) == identity(release),
           "compressed_index": {"path": str(compressed.relative_to(ROOT)), **identity(compressed)},
           "decoded_index": {"path": str(unpacked.relative_to(ROOT)), **identity(unpacked)},
           "snapshot": BASE, "signature_verified": True, "signed_size_sha256_verified": True}
    save(PROV / f"{suite}-{component}-authentication.json", row)
    return parse_deb822(decoded.decode())


def select_main():
    records = authenticated_index("noble-updates", "universe")
    selected = []
    for name in WANTED:
        matching = [(fields, para) for fields, para in records if fields.get("Package") == name and fields.get("Version") == VERSION]
        if len(matching) != 1:
            raise ValueError(f"expected one exact {name} {VERSION}: found {len(matching)}")
        fields, raw = matching[0]
        assert fields["Architecture"] in {"amd64", "all"}
        path = PurePosixPath(fields["Filename"])
        if path.is_absolute() or ".." in path.parts or not str(path).startswith("pool/"):
            raise ValueError("unsafe package path")
        selected.append({"package": name, "version": fields["Version"], "architecture": fields["Architecture"],
                         "filename": fields["Filename"], "bytes": int(fields["Size"]), "sha256": fields["SHA256"],
                         "depends": fields.get("Depends", ""), "metadata": raw,
                         "authenticated_index": "provenance/noble-updates-universe-Packages"})
    save(ROOT / "selected-packages.json", selected)
    print(json.dumps({"selected": [{k: x[k] for k in ("package", "version", "bytes", "sha256", "depends")} for x in selected]}, indent=2))


def fetch_main():
    selected = json.loads((ROOT / "selected-packages.json").read_text())
    def work(x):
        target = ROOT / "packages" / PurePosixPath(x["filename"]).name
        return fetch(BASE + x["filename"], target, {"bytes": x["bytes"], "sha256": x["sha256"]})
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        receipts = list(executor.map(work, selected))
    save(ROOT / "downloaded-packages.json", receipts)


if __name__ == "__main__":
    if sys.argv[1:] == ["select"]:
        select_main()
    elif sys.argv[1:] == ["fetch"]:
        fetch_main()
    else:
        raise SystemExit("usage: fetch_authenticated_llvm.py select|fetch")
