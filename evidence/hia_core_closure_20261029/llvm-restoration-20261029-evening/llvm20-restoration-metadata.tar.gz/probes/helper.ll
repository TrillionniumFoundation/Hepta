target triple = "x86_64-unknown-linux-gnu"
define i32 @hepta_probe_twice(i32 %x) {
entry:
  %r = mul i32 %x, 2
  ret i32 %r
}
