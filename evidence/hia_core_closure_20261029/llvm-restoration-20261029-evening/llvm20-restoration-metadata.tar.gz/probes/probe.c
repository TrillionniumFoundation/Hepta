#include <stdio.h>
#include <stdint.h>
extern int32_t hepta_probe_twice(int32_t x);
int main(void) {
  int32_t value = hepta_probe_twice(21);
  printf("llvm20-c-ir=%d\n", (int)value);
  return value == 42 ? 0 : 1;
}
