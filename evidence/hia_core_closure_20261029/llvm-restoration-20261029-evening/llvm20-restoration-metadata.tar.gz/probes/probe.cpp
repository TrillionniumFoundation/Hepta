#include <iostream>
#include <memory>
#include <vector>
int main() {
  auto values = std::make_unique<std::vector<int>>(std::initializer_list<int>{19, 23});
  const int answer = values->at(0) + values->at(1);
  std::cout << "llvm20-cpp=" << answer << '\n';
  return answer == 42 ? 0 : 1;
}
