# Independent finite bound-v3 continuation review

Source: `efb2fea1de2855b2669593660d787b98fc966aa6`.
Tree: `a7fd0ceaa1a595da393608ac5a79ececb2aed7ef`.
Existing Rust executable SHA-256: `816c42ad810cde27023cc433169137a456d0a7423a43a5459193d7bd8adcc5a8`.

This independent review reused the already built executable. It made **242 actual bound Python/Rust execution comparisons** and **33 prelaunch refusals**. There was no new compiler build or hosted CI run. Every comparison passed; the complete frozen-source identity and executable bytes remained unchanged before and after execution. No new reproducible runtime defect was found within these cases.

## Cases and findings

- A separately authored scalar program alternates mutually recursive functions and then makes sibling calls in the same caller frame. Both helper and final calls return multiple values. Normal results cover recursive arguments through 253 and root-inclusive depth 256. Selected earlier depth boundaries stop with the exact `calls` outcome.
- Every allowed-tick prefix of the selected mutual/sibling-call execution matches the independent Python outcome and step count. This checks caller continuation positions across repeated returns and child admissions.
- Existing mixed shared-loan and swapped mutable-loan multi-return fixtures were independently selected and checked at every allowed-tick prefix. Their complete resource ledgers match, including interrupted formal scopes and successful cleanup. The same bounded inputs produce identical underlying v1, v2 and v3 reports within legacy policy limits.
- Boolean, float, integer-subclass and string policy values reject before executable admission. Invalid, non-finite or subclass timeout values also reject. Original nominal and explicit-export restrictions remain enforced; a list subclass and a boolean supplied for `u32` reject.
- Static review confirmed that language depth is checked before the entry tick, ownership transfer precedes callee admission, the caller's operation position advances before suspension, and successful return applies return-loan rebinding and formal-scope exit before binding results. Stopped execution does not fabricate language-resource cleanup.

The original independent fixture reused an SSA name across two blocks. The existing checker correctly refused it before any native execution. The initial fixture and stderr are retained. Correcting that test fixture did not modify implementation code.

## Raw records

`review.json` contains the full before/after source identity, exact canonical programs, all Python and Rust reports, every actual process invocation/output and refusal details. `actual-observations.jsonl` retains a per-process journal, and `programs.json` contains the exact canonical inputs. `summary.json` identifies the finite observations and review limits.

The separate collector acceptance bug involving `expectedFailures` was found by the root review and fixed at `52653dbc182ff400c95f7cda771800e9961c3c83`. This directory remains bound to the original runtime source `efb2fea`; it does not relabel these observations as an execution of that later collector commit or of a later integrated tree.

These finite observations overlap other component tests and must not be added to them as independent task counts. They establish neither complete production API parity, universal semantic equivalence, native backend refinement, nor whole-language soundness. Python remains production authority; broad P2 closure remains open.
