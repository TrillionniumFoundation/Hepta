#!/usr/bin/env python3
"""Independent finite continuation and policy review on frozen efb2fea bytes."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

ROOT=Path('/workspace/scratch/b484d4086829/hepta-v3-peer')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from hepta import hia_rust_crosscheck as cross
from hepta.hia_program import verify_program
from tests.test_hia_program import b,branch,c,f,i,m,ret
from tests.test_hia_returned_loans import multiple_shared,swapped_mutable
from tests.test_hia_composite_abi import nominal_identity_program
from tools.qualify_hia_integrated import _source_state

BINARY=Path('/workspace/scratch/b484d4086829/core-next-evidence-efb2fea/bin/hia-core-shadow')
DIGEST='816c42ad810cde27023cc433169137a456d0a7423a43a5459193d7bd8adcc5a8'
OBS=[];REFUSALS=[];PROGRAMS={}

def mutual_siblings():
    pair=f('pair',[('x','u32')],['u32','u32'],[],[
      b('entry',[('x','u32')],[c('one','u32',1),c('three','u32',3),
        i('int.add.wrap',['x','one'],[('a','u32')]),i('int.mul.wrap',['x','three'],[('z','u32')])],ret('a','z'))])
    functions=[pair]
    for name,other in [('alpha','beta'),('beta','alpha')]:
      functions.append(f(name,[('n','u32'),('x','u32')],['u32'],[],[
       b('entry',[('n','u32'),('x','u32')],[c('zero','u32',0),i('compare.eq',['n','zero'],[('done','bool')])],
         branch('done',('base','x'),('step','n','x'))),
       b('base',[('base_x','u32')],[i('call',['base_x'],[('a','u32'),('z','u32')],function='pair'),
         i('int.add.wrap',['a','z'],[('answer','u32')])],ret('answer')),
       b('step',[('step_n','u32'),('step_x','u32')],[c('one','u32',1),
         i('int.sub.wrap',['step_n','one'],[('next_n','u32')]),
         i('call',['next_n','step_x'],[('child','u32')],function=other),
         i('call',['child'],[('a','u32'),('z','u32')],function='pair'),
         i('int.add.wrap',['a','z'],[('combined','u32')]),
         i('int.add.wrap',['combined','step_x'],[('answer','u32')])],ret('answer'))]))
    functions.append(f('driver',[('n','u32'),('seed','u32')],['u32'],[],[
      b('entry',[('n','u32'),('seed','u32')],[
        i('call',['n','seed'],[('first','u32')],function='alpha'),
        i('call',['n','first'],[('second','u32')],function='beta'),
        i('call',['second'],[('a','u32'),('z','u32')],function='pair'),
        i('int.add.wrap',['a','z'],[('answer','u32')])],ret('answer'))]))
    source=m(*functions);source['schema']='hepta.hia.program.v8';source['exports']=['driver']
    return source

def compare(source,entry,args,*,label,api=3,depth=256,steps=100000,heap=1024):
    core=verify_program(source);PROGRAMS[core.sha256]=core.canonical_bytes.decode()
    calls=[];original=cross._run_pinned_shadow
    def observed(binary,argv,stdin,timeout,**kwargs):
      stdout,stderr,status=original(binary,argv,stdin,timeout,**kwargs)
      calls.append({'argv':argv,'executable_sha256':sha256(binary).hexdigest(),'stdin_sha256':sha256(stdin).hexdigest(),
                    'stdout':stdout.decode(),'stderr':stderr.decode(),'exit_code':status})
      return stdout,stderr,status
    fn={1:cross.crosscheck_rust_execution,2:cross.crosscheck_rust_execution_v2,3:cross.crosscheck_rust_execution_v3}[api]
    options={'executable_sha256':DIGEST,'max_steps':steps,'max_heap_bytes':heap}
    if api!=1:options['max_call_depth']=depth
    with patch.object(cross,'_run_pinned_shadow',observed):result=fn(source,entry,args,BINARY,**options)
    assert len(calls)==1 and calls[0]['exit_code']==0 and calls[0]['stderr']==''
    assert result['claims']['rust_is_production_admission_authority'] is False
    OBS.append({'label':label,'protocol':api,'matched':True,'result':result,'process':calls[0]})
    return result['rust_report']

def main():
    assert sha256(BINARY.read_bytes()).hexdigest()==DIGEST
    before=_source_state();assert before['head'].startswith('efb2fea') and not before['status']
    source=mutual_siblings()
    for n,seed in [(0,0),(1,1),(2,0xffffffff),(5,17),(33,0xffffffff),(63,3),(127,7),(253,11)]:
      result=compare(source,'driver',[n,seed],label=f'mutual-siblings-return-{n}',depth=n+3)
      assert result['status']=='returned'
    for depth in [1,2,3,4,7,32,33,64,128,255,256]:
      result=compare(source,'driver',[253,9],label=f'mutual-siblings-depth-{depth}',depth=depth)
      assert result['status']==('returned' if depth==256 else 'budget_exceeded')
      if depth!=256:assert result['error']=={'code':'calls'}
    normal=compare(source,'driver',[4,13],label='all-prefix-reference',depth=8)
    for ticks in range(1,normal['steps']):
      result=compare(source,'driver',[4,13],label=f'every-mutual-prefix-{ticks}',depth=8,steps=ticks)
      assert result['error']=={'code':'steps'} and result['steps']==ticks+1
    for fixture,label,args in [(multiple_shared('mixed'),'mixed-shared-multi-return',[19]),
                                (swapped_mutable(),'swapped-mutable-multi-return',[])]:
      entry=fixture['exports'][0]
      complete=compare(fixture,entry,args,label=label+'-return')
      assert complete['status']=='returned' and complete['resources']['live_local_loans']==0
      for ticks in range(1,complete['steps']):
        stopped=compare(fixture,entry,args,label=f'{label}-prefix-{ticks}',steps=ticks)
        assert stopped['error']=={'code':'steps'} and stopped['steps']==ticks+1
      legacy=[]
      for protocol in [1,2,3]:
        legacy.append(compare(fixture,entry,args,label=f'{label}-compat-v{protocol}',api=protocol,depth=32))
      assert legacy[0]==legacy[1]==legacy[2]
    nominal=nominal_identity_program()
    assert compare(nominal,'public_identity',[7],label='original-nominal-public-entry')['values']==[7]
    class IntegerSubclass(int):pass
    class FloatSubclass(float):pass
    class ListSubclass(list):pass
    bad=[]
    for field in ['max_steps','max_heap_bytes','max_call_depth','allocation_fail_at']:
      for value in [True,False,1.0,IntegerSubclass(1),'1']:
        bad.append((field,type(value).__name__,{field:value}))
    for value in [True,False,float('inf'),float('nan'),0,-1,121,FloatSubclass(1)]:
      bad.append(('timeout',repr(value),{'timeout':value}))
    with patch.object(cross,'_verified_executable_bytes') as launch:
      for field,label,options in bad:
        try:cross.crosscheck_rust_execution_v3(source,'driver',[0,1],BINARY,executable_sha256=DIGEST,**options)
        except cross.HIARustCrosscheckRejected as error:REFUSALS.append({'field':field,'case':label,'error':str(error)})
        else:raise AssertionError(('bad policy accepted',field,label))
      for doc,entry,args,label in [(nominal,'inspect_packet',[7],'original-nominal-private'),
              (verify_program(nominal),'inspect_packet',[7],'verified-nominal-private'),
              (source,'alpha',[0,7],'unexported-scalar-helper'),
              (source,'driver',ListSubclass([0,1]),'list-subclass'),
              (source,'driver',[True,1],'bool-for-u32')]:
        try:cross.crosscheck_rust_execution_v3(doc,entry,args,BINARY,executable_sha256=DIGEST)
        except cross.HIARustCrosscheckRejected as error:REFUSALS.append({'field':'entry_or_arguments','case':label,'error':str(error)})
        else:raise AssertionError(('bad entry accepted',label))
      launch.assert_not_called()
    after=_source_state();assert before==after
    assert sha256(BINARY.read_bytes()).hexdigest()==DIGEST
    report={'status':'finite_independent_review_passed','ok':True,'source_commit':before['head'],
      'source_tree':before['tree'],'binary_sha256':DIGEST,'actual_native_processes':len(OBS),
      'actual_bound_comparisons':len(OBS),'prelaunch_refusals':len(REFUSALS),'source_unchanged':True,
      'binary_unchanged':True,'source_before':before,'source_after':after,'programs':PROGRAMS,
      'observations':OBS,'refusals':REFUSALS,'new_production_admission':False,
      'whole_language_soundness_proved':False,'backend_refinement_proved':False,
      'scope':['mutual and sibling scalar calls with multi-value continuations',
        'exact tick prefixes across returns and multi-loan returns',
        'selected depth boundaries including root-inclusive 256',
        'strict Python types and original nominal/export eligibility',
        'same-input v1/v2/v3 full-report equality within legacy limits'],
      'limitations':['finite independently selected fixtures only','no new build or CI run',
        'does not establish complete production parity or universal semantic equivalence',
        'collector expected-failure fix 52653db is separate from this efb2fea runtime review']}
    (OUT/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['source_before','source_after','programs','observations','refusals']},indent=2))

if __name__=='__main__':main()
