"""Record actual before/after generic-LLD regressions without relabeling CI."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ORIGINAL = BASE / 'hepta'
FIXED = BASE / 'hepta-ci-repair'
NATIVE = BASE / 'toolchains/native/usr'
RUST = BASE / 'toolchains/rust-1.90.0'
CHANGED = ['tests/test_hia_filecheck_target_profile.py', 'tools/hia_filecheck_target_profile.py',
           'tools/qualify_hia_filecheck.py', 'tools/qualify_hia_integrated.py',
           'tools/qualify_hia_safety_contract.py']


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args]).decode().strip()


def snapshot(root):
    files = {}
    for name in CHANGED:
        value = (root / name).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(value)).encode() + b'\0' + value).hexdigest()
        assert blob == git(root, 'rev-parse', 'HEAD:' + name)
        files[name] = {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest(), 'git_blob': blob}
    return {'commit': git(root, 'rev-parse', 'HEAD'), 'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
            'tracked_status': git(root, 'status', '--porcelain', '--untracked-files=no'), 'files': files}


def run(name, root, linker, selectors, expected_code):
    directory = HERE / ('attempt03-' + name)
    directory.mkdir()
    env = dict(os.environ, CLANG=str(NATIVE / 'lib/llvm-20/bin/clang'),
               CLANGXX=str(NATIVE / 'lib/llvm-20/bin/clang++'),
               HEPTA_LLD=str(linker), HEPTA_QEMU_X86_64=str(NATIVE / 'bin/qemu-x86_64'),
               LD_LIBRARY_PATH=str(NATIVE / 'lib/x86_64-linux-gnu'),
               RUSTC=str(RUST / 'bin/rustc'), CARGO=str(RUST / 'bin/cargo'),
               HEPTA_FILECHECK_TARGET_EVIDENCE=str(directory / 'native-fixtures'),
               PYTHONDONTWRITEBYTECODE='1')
    before = snapshot(root)
    start = time.perf_counter()
    argv = [sys.executable, '-B', '-m', 'unittest', '-v', *selectors]
    observed = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True, timeout=180)
    elapsed = time.perf_counter() - start
    (directory / 'stdout.log').write_text(observed.stdout)
    (directory / 'stderr.log').write_text(observed.stderr)
    after = snapshot(root)
    report = {'name': name, 'argv': argv, 'cwd': str(root), 'returncode': observed.returncode,
              'seconds': elapsed, 'environment': {key: env[key] for key in ('CLANG', 'CLANGXX', 'HEPTA_LLD',
              'HEPTA_QEMU_X86_64', 'LD_LIBRARY_PATH', 'RUSTC', 'CARGO')},
              'source_before': before, 'source_after': after, 'source_unchanged': before == after,
              'expected_returncode': expected_code, 'actual_execution': True,
              'reported_summary': re.findall(r'(?:Ran \d+ tests? in [^\n]+|FAILED \([^\n]+\)|OK(?: \([^\n]+\))?)', observed.stderr)}
    (directory / 'execution.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    assert before == after
    assert observed.returncode == expected_code, observed.stderr[-8000:]
    if expected_code:
        assert 'lld is a generic driver.' in observed.stderr
        assert 'FAILED (failures=1)' in observed.stderr
    else:
        assert 'skipped' not in observed.stderr and 'FAILED' not in observed.stderr
    print(json.dumps({key: report[key] for key in ('name', 'returncode', 'seconds', 'source_unchanged', 'reported_summary')}), flush=True)
    return report


generic = RUST / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld'
rows = [json.loads((HERE / 'original-generic-driver/execution.json').read_text()),
        run('fixed-generic-driver', FIXED, generic, ['tests.test_hia_filecheck_target_profile'], 0),
        run('fixed-elf-driver', FIXED, NATIVE / 'lib/llvm-20/bin/ld.lld', ['tests.test_hia_filecheck_target_profile'], 0)]
(HERE / 'focused-execution-summary.json').write_text(json.dumps({'ok': True, 'profiles': rows,
    'fixed_unique_test_methods': 10, 'fixed_test_executions': 20,
    'independent_qualifications_are_not_additive': True, 'original_failure_preserved': True, 'original_control_reused_not_reexecuted': True,
    'full_regression_reexecuted': False, 'optimization_policy': 'no_change'}, indent=2, sort_keys=True) + '\n')
