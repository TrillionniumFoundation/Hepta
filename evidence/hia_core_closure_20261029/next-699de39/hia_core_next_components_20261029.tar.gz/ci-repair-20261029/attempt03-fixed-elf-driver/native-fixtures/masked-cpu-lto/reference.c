typedef unsigned long long vector4 __attribute__((ext_vector_type(4)));
unsigned int feature_probe(unsigned long long count) {
    vector4 values = (vector4){count, count, count, count};
    vector4 thresholds = (vector4){1, 2, 3, 4};
    vector4 compared = (vector4)(values >= thresholds);
    return (unsigned int)((compared[0] & 1) | (compared[1] & 2) |
                          (compared[2] & 4) | (compared[3] & 8));
}
