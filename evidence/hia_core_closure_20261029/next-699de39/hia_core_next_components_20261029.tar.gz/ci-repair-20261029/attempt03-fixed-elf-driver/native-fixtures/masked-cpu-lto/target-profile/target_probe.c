unsigned long long __hepta_filecheck_target_probe(unsigned long long value) {
    return value ^ 1ULL;
}
