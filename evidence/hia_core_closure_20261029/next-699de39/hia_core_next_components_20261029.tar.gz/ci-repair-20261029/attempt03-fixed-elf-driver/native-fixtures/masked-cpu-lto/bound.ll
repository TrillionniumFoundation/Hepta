target triple = "x86_64-unknown-linux-gnu"
define i32 @feature_probe(i64 %n) #0 {
entry:
  %one = insertelement <4 x i64> poison, i64 %n, i32 0
  %all = shufflevector <4 x i64> %one, <4 x i64> poison, <4 x i32> zeroinitializer
  %predicate = icmp uge <4 x i64> %all, <i64 1, i64 2, i64 3, i64 4>
  %bits = bitcast <4 x i1> %predicate to i4
  %result = zext i4 %bits to i32
  ret i32 %result
}

attributes #0 = { "target-cpu"="znver4" "target-features"="+adx,+aes,+avx,+avx2,+bmi,+bmi2,+clflushopt,+clwb,+clzero,+crc32,+cx16,+cx8,+evex512,+f16c,+fma,+fsgsbase,+fxsr,+gfni,+invpcid,+lzcnt,+mmx,+movbe,+mwaitx,+pclmul,+pku,+popcnt,+prfchw,+rdpid,+rdpru,+rdrnd,+rdseed,+sahf,+sha,+shstk,+sse,+sse2,+sse3,+sse4.1,+sse4.2,+sse4a,+ssse3,+vaes,+vpclmulqdq,+wbnoinvd,+x87,+xsave,+xsavec,+xsaveopt,+xsaves,-amx-avx512,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq" }
