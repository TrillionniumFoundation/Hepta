target triple = "x86_64-unknown-linux-gnu"
define i32 @feature_probe(i64 %n) {
entry:
  %one = insertelement <4 x i64> poison, i64 %n, i32 0
  %all = shufflevector <4 x i64> %one, <4 x i64> poison, <4 x i32> zeroinitializer
  %predicate = icmp uge <4 x i64> %all, <i64 1, i64 2, i64 3, i64 4>
  %bits = bitcast <4 x i1> %predicate to i4
  %result = zext i4 %bits to i32
  ret i32 %result
}
