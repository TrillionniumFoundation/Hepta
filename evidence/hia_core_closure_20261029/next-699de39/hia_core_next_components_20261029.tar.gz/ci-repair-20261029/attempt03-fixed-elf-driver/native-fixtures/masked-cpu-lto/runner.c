
#include <cpuid.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t (*probe_fn)(uint64_t);
int main(int argc, char **argv) {
    if (argc != 3) return 64;
    unsigned a, b, c, d, lo = 0, hi = 0;
    if (!__get_cpuid(1, &a, &b, &c, &d) || !(c & (1U << 27))) return 65;
    __asm__ volatile("xgetbv" : "=a"(lo), "=d"(hi) : "c"(0));
    if (!__get_cpuid_count(7, 0, &a, &b, &c, &d)) return 66;
    printf("{\"avx2\":%u,\"avx512f\":%u,\"avx512dq\":%u,\"avx512vl\":%u,\"xcr0\":%llu}\n",
           (b >> 5) & 1U, (b >> 16) & 1U, (b >> 17) & 1U, (b >> 31) & 1U,
           (unsigned long long)lo | ((unsigned long long)hi << 32));
    fflush(stdout);
    void *library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) { fprintf(stderr, "%s\n", dlerror()); return 67; }
    void *symbol = dlsym(library, "feature_probe");
    if (!symbol) return 68;
    probe_fn fn;
    _Static_assert(sizeof(fn) == sizeof(symbol), "POSIX pointer representation");
    memcpy(&fn, &symbol, sizeof(fn));
    uint32_t result = fn(strtoull(argv[2], NULL, 10));
    printf("{\"result\":%u}\n", result);
    return dlclose(library) ? 69 : 0;
}
