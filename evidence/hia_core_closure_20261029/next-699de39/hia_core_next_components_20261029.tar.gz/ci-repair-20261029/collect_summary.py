"""Freeze observed CI failures and finite fixes; never infer a full-run pass."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'hepta-ci-repair'
BASELINE = '1669ddc05a918e7c01b17e9262d4461130d44aaa'
LINKER = '9da1d4b7921c780b45ead661466cf3506b6792e2'
FINAL = 'e25b2eb77ea68f4488d742cfaa34f65a9acffb6c'


def read(name):
    return json.loads((HERE / name).read_text())


def identity(path):
    value = path.read_bytes()
    return {'path': str(path.relative_to(HERE)), 'bytes': len(value),
            'sha256': hashlib.sha256(value).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(value)).encode() + b'\0' + value).hexdigest()}


def test_summary(name, expected):
    log = (HERE / name).read_text()
    match = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', log, re.M)
    assert len(match) == 1 and int(match[0][0]) == expected
    assert re.search(r'^OK$', log, re.M)
    assert not re.search(r'^FAILED|^FAIL:|^ERROR:|\.\.\. skipped|unexpected success|expected failure', log, re.M)
    methods = re.findall(r'^test_\S+ \(([^\r\n()]+)\) \.\.\. ok$', log, re.M)
    assert len(methods) == len(set(methods)) == expected
    return {'tests_run': expected, 'failures': 0, 'errors': 0, 'skipped': 0,
            'seconds': float(match[0][1]), 'methods': methods, 'log': identity(HERE / name)}


metadata = read('original-ci-metadata.json')
artifact = metadata['artifacts']['artifacts'][0]
assert artifact['id'] == 12868778348
assert artifact['digest'] == 'sha256:77e2f532ddd607c812607d0d9c3b3494496f22dd84a5dcbd0ec29f39c22c772f'
assert artifact['workflow_run']['head_sha'] == BASELINE
integrated = read('extracted/_temp/hepta-integrated/qualification.json')
full = read('extracted/_temp/hepta-integrated/full_regression-execution.json')
unified = read('extracted/Hepta/Hepta/artifacts/hia-unified/qualification.json')
release = read('extracted/Hepta/Hepta/artifacts/candidate/release-validation.json')
release_log = (HERE / 'extracted/Hepta/Hepta/artifacts/candidate/unit_and_integration.log').read_text()
unified_log = (HERE / 'extracted/Hepta/Hepta/artifacts/hia-unified/unit_regression.stderr.log').read_text()
failures = lambda log: re.findall(r'^FAIL: ([^\n]+)', log, re.M)
assert len(failures(release_log)) == 1
assert len(failures(unified_log)) == 2
assert len(failures(full['execution']['stderr'])) == 1
assert 'Ran 3614 tests' in release_log and 'Ran 3614 tests' in unified_log
assert full['tests_run'] == 3614 and full['failures'] == 1 and full['errors'] == full['skipped'] == 0
assert integrated['source_before'] == integrated['source_after']
assert integrated['external_inventory_before'] == integrated['external_inventory_after']
assert integrated['source_before']['head'] == BASELINE

generic = test_summary('attempt03-fixed-generic-driver/stderr.log', 10)
elf = test_summary('attempt03-fixed-elf-driver/stderr.log', 10)
helpers = test_summary('helper-regressions-attempt02.stderr.log', 23)
child = test_summary('child-limits.stderr.log', 4)
assert set(generic['methods']) == set(elf['methods'])
assert read('helper-regressions-attempt02-execution.json')['source_commit'] == LINKER
assert read('child-limits-execution.json')['source_commit'] == FINAL
observations = {}
for label in ('generic', 'elf'):
    prefix = 'attempt03-fixed-' + label + '-driver'
    execution = read(prefix + '/native-fixtures/masked-cpu-lto/execution.json')
    facts = execution['observations']
    assert facts['raw'][0]['returncode'] == -4
    for arm in ('bound', 'c', 'alternate_bound'):
        assert len(facts[arm]) == 6 and all(row['returncode'] == 0 for row in facts[arm])
    assert all(row['unchanged'] for row in facts['linker_drivers'].values())
    assert any(row['temporary_alias'] and row['temporary_alias_removed'] for row in facts['linker_drivers'].values())
    observations[label] = {'cpu': facts['cpu'], 'raw_negative_signal': -4,
                           'positive_arms': 3, 'positive_inputs_per_arm': 6,
                           'linker_drivers': facts['linker_drivers'],
                           'record': identity(HERE / prefix / 'native-fixtures/masked-cpu-lto/execution.json')}

prepare = read('fixed-generic-prepare-attempt02/qualification.json')
assert prepare['ok'] and prepare['status'] == 'prepared_not_measured'
assert prepare['git'] == FINAL and prepare['git_status'] == '' and prepare['samples'] == []
assert prepare['differential']['native_calls'] == 768 and prepare['differential']['cases'] == 96
assert len(prepare['resource_cases']) == 48 and len(prepare['maintenance']['cases']) == 4
assert len(prepare['maintenance']['application']) == 2
assert prepare['linker_driver']['unchanged'] and prepare['linker_driver']['temporary_alias_removed']
window = read('native-refusal-window-control-attempt02/summary.json')
assert window['ok'] and window['source_commit'] == FINAL
assert len(window['observations']) == 4 and all(row['marker_absent'] for row in window['observations'])

changed = subprocess.check_output(['git', '-C', str(ROOT), 'diff', '--name-only', BASELINE, FINAL]).decode().splitlines()
files = {}
for name in changed:
    payload = subprocess.check_output(['git', '-C', str(ROOT), 'show', FINAL + ':' + name])
    assert payload == (ROOT / name).read_bytes()
    files[name] = {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(),
                  'git_blob': hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()}
    if name != 'tests/test_hia_native_child_limits.py':
        assert payload == subprocess.check_output(['git', '-C', str(ROOT), 'show', LINKER + ':' + name])

result = {'schema': 'hepta.ci-driver-refusal-repair.v1', 'status': 'finite_repairs_passed_full_gates_not_reexecuted',
    'source': {'original': BASELINE, 'first_linker_attempt': '92cad48', 'qualified_linker_component': LINKER,
               'qualified_timeout_component': FINAL,
               'final_tree': subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', FINAL + '^{tree}']).decode().strip(),
               'changed_files': files},
    'original_ci': {'run_id': 40799429611, 'job_id': 123203698473, 'conclusion': 'failure',
        'artifact_id': artifact['id'], 'artifact_bytes': artifact['size_in_bytes'], 'artifact_digest': artifact['digest'],
        'original_archive_reference': 'https://github.com/TrillionniumFoundation/Hepta/actions/runs/40799429611/artifacts/12868778348',
        'complete_archive_bytes_downloaded_and_sha256_checked': True,
        'complete_archive_embedded_in_this_component': False,
        'archive_cache_removed_after_verified_selected_record_extraction': True,
        'release': {'passed_gates': sum(g['status'] == 'passed' for g in release['gates']), 'total_gates': len(release['gates']),
                    'tests_run': 3614, 'failures': 1, 'errors': 0, 'skipped': 0, 'failed_methods': failures(release_log)},
        'unified': {'passed_gates': unified['passed_gates'], 'total_gates': unified['completed_gates'],
                    'tests_run': 3614, 'failures': 2, 'errors': 0, 'skipped': 0, 'failed_methods': failures(unified_log)},
        'integrated': {'passed_gates': sum(g['passed'] for g in integrated['gates']), 'total_gates': len(integrated['gates']),
            'tests_run': 3614, 'failures': 1, 'errors': 0, 'skipped': 0, 'failed_methods': failures(full['execution']['stderr']),
            'source_files': len(integrated['source_before']['files']),
            'external_inventory_entries': len(integrated['external_inventory_before']),
            'source_and_external_inputs_unchanged': True, 'coverage_failure_derived_from_regression_failure': True}},
    'tests': {'generic_profile': generic, 'elf_profile': elf, 'helper_regressions': helpers, 'child_limits': child,
        'unique_methods': len(set(generic['methods'] + helpers['methods'] + child['methods'])),
        'overlapping_profiles_not_summed_as_independent_tasks': True},
    'masked_native_observations': observations,
    'prepare_only': {'ok': True, 'source_commit': FINAL, 'status': prepare['status'], 'arms': prepare['differential']['routes'],
        'cases': 96, 'native_calls': 768, 'resource_cases': 48, 'maintenance_cases': 4, 'whole_applications': 2,
        'samples': 0, 'driver_identity_unchanged': True, 'temporary_driver_alias_removed': True,
        'record': identity(HERE / 'fixed-generic-prepare-attempt02/qualification.json')},
    'refusal_window_control': {'observations': window['observations'],
        'record': identity(HERE / 'native-refusal-window-control-attempt02/summary.json'),
        'original_ci_exact_delay_point_reconstructed': False},
    'intermediate_records_retained': [
        'original-generic-driver/execution.json', 'fixed-generic-driver/execution.json',
        'focused-attempt02.stderr.log', 'helper-regressions-execution.json', 'prepare-execution.json',
        'refusal-window.stderr.log'],
    'claims': {'whole_project_blockers_closed': False, 'all_P0_P7_closed': False,
        'whole_language_soundness_proved': False, 'backend_refinement_proved': False,
        'performance_advantage_measured': False, 'general_cancellation_or_cleanup_proved': False,
        'full_regression_reexecuted_on_fixed_source': False, 'production_authority': 'Python',
        'optimization_policy': 'no_change'}}
(HERE / 'summary.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': result['status'], 'unique_methods': result['tests']['unique_methods'],
                  'original_integrated': result['original_ci']['integrated'], 'prepare_only': result['prepare_only']}, sort_keys=True))
