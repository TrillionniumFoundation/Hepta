
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <stdint.h>
static int32_t spawn_child(void) {
    pid_t pid = fork();
    if (pid < 0) return 99;
    if (pid == 0) {
        usleep(800000);
        int fd = open("/workspace/scratch/b484d4086829/ci-repair-20261029/native-refusal-window-control-attempt02/escaped-child-wrote-marker", O_WRONLY|O_CREAT, 0600);
        if (fd >= 0) close(fd);
        _exit(0);
    }
    return 7;
}
int32_t fork_and_stall(void) {
    /* Deliberate pre-fork initialization/scheduling time. The syscall refusal
       control must not depend on reaching fork within the timeout-only budget. */
    usleep(350000);
    int32_t value = spawn_child();
    sleep(4);
    return value;
}
int32_t fork_and_return(void) { return spawn_child(); }
int32_t stall_only(void) { sleep(3); return 7; }
