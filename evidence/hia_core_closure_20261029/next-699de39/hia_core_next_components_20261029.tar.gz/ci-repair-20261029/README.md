# Generic LLD dispatch and native refusal observation controls

This component closes two reproduced qualification failures without claiming a
new complete release qualification. Python remains production authority and the
optimization policy remains `no_change`.

## Original hosted failure

[Run 40799429611](https://github.com/TrillionniumFoundation/Hepta/actions/runs/40799429611)
executed source `1669ddc05a918e7c01b17e9262d4461130d44aaa` and failed. Its original
[artifact 12868778348](https://github.com/TrillionniumFoundation/Hepta/actions/runs/40799429611/artifacts/12868778348)
was downloaded and its complete 337,379,434-byte archive matched the official
SHA-256 `77e2f532ddd607c812607d0d9c3b3494496f22dd84a5dcbd0ec29f39c22c772f`.
The full ZIP remains an official Actions reference; it is not embedded in this
component. Selected original records and the decoded job log are retained here.

The release candidate and integrated full suites each executed 3,614 methods
with one failure. The standalone unified full suite executed 3,614 methods with
two failures. These are repeated suites, not independent task counts. All three
had zero errors/skips. The two distinct failure types were:

1. The masked CPU regression invoked `rust-lld --version`. That executable is a
   generic dispatcher and requires an explicit ELF/GNU flavor or a suitable
   `argv[0]`. The same incomplete version probe existed in filecheck and safety
   environment capture. The integrated tool probe already selected its flavor.
2. The unified run's `fork_and_stall` control expected exact `SIGSYS`, while its
   200 ms deadline could expire before observing that signal. The original log
   does not identify the child's exact delay point. The separate
   `fork_and_return` control already used a three-second observation window.

The integrated source inventory (4,379 files) and external input inventory stayed
unchanged. Its coverage failure followed its failed full suite; it is not a
third independent defect. Current release/standalone/integrated results are
reported separately in [summary.json](summary.json).

## Finite fixes and actual checks

Local commit `9da1d4b7921c780b45ead661466cf3506b6792e2` unifies LLD version
arguments and uses a temporary `ld.lld` symlink when Clang must invoke a generic
driver. The symlink points to the selected executable itself. The selected
binary, resolved path and alias are hashed and checked before and after use;
cleanup runs on success and exceptions. A changed binary/alias rejects the run.

An initial attempt at `92cad48` put `-flavor gnu` in Clang's forwarded linker
options. Actual execution showed why that failed: LLD consumes the flavor at
the first argument, while Clang places forwarded options later. That failed
attempt and its records remain; the final implementation uses `argv[0]`.

The same 10 test methods passed under actual Rust 1.90's LLD 20.1.8 and under
the restored ELF driver LLD 20.1.2. Each run also exercised both generic and ELF
spellings against the same binary. Under the explicit Haswell CPU mask, raw IR
still terminated with `SIGILL`, while bound IR, the C reference and the alternate
bound-driver arm returned the six expected values. Twenty executions represent
ten distinct methods. Another 23 worker, source-identity, workflow and safety
protocol tests passed. The first helper command's incorrect module name is
retained as an error, followed by the corrected command's successful execution.

Local commit `e25b2eb77ea68f4488d742cfaa34f65a9acffb6c` changes only the native
child-control test. Both fork refusal controls keep an exact `SIGSYS`
requirement and use a three-second observation window. The independent
non-forking stall keeps its 200 ms timeout. A deliberate 350 ms pre-fork delay
makes the distinction explicit. All four child-limit methods passed. A separate
actual native control recorded the short-window timeout, the same delayed
function's `SIGSYS` with the longer window, the direct fork's `SIGSYS`, and the
non-forking timeout; all four marker observations remained absent. Production
deadlines, seccomp and process cleanup code were not changed. This does not
reconstruct the historical CI host's delay or prove general cleanup.

The complete filecheck preparation on `e25b2eb` also passed using the selected
generic Rust LLD: eight arms, 96 cases, 768 native differential calls, 48 resource
cases, four maintenance cases and two whole applications. The temporary alias
was removed and its selected binary identity remained stable. It reports
`prepared_not_measured` with an empty sample list. The first attempt failed
before building because restored tooling lacked `llvm-profdata`; that record
is preserved. After restoring the actual tool and profile runtime, the complete
prepare-only run succeeded in about 25.15 seconds.

There are 37 distinct successful test methods across the component runs. Results
retain their original commits; they are not relabeled as one whole-project run.
The six changed files' final blob identities are in the summary. The linker
files are identical between `9da1d4b` and `e25b2eb`.

## Retained evidence and reproduction

- [Machine-readable summary](summary.json) links the raw report identities.
- `extracted/` contains exact selected original CI artifact members, including
  all three full-suite outcomes and current candidate reports.
- `attempt03-fixed-*/native-fixtures/` contains actual IR, libraries, CPU
  observations, version/build commands, negative controls and alias receipts.
- `fixed-generic-prepare-attempt02/` contains the full preparation output,
  workers, baselines, inputs, LLVM/native artifacts and process ledger.
- `native-refusal-window-control-attempt02/` contains the controlled C/native
  fixture and all four observed refusals.
- `ci-repair-source.bundle` retains the three local commits and requires the
  already-public `1669ddc` commit. `git bundle verify` passed.
- `PUBLIC_FILES.json` is the exact publication allowlist. The private download
  transport metadata is excluded. The signed URL is not evidence content.

The collector checks the actual record counts and source identities. It does
not run native code, reconstruct deleted historical local results, perform a
new full regression, qualify all hosts, switch Rust authority, establish a
performance improvement, or close all P0–P7 obligations.
