from pathlib import Path
import json
import os
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'hepta-ci-repair'
initial = json.loads((HERE / 'prepare-execution.json').read_text())
env = dict(os.environ, **initial['environment'], PYTHONDONTWRITEBYTECODE='1')
argv = list(initial['argv'])
argv[argv.index('--output') + 1] = str(HERE / 'fixed-generic-prepare-attempt02')
before = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip()
assert before == 'e25b2eb77ea68f4488d742cfaa34f65a9acffb6c'
assert not subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain', '--untracked-files=no'])
start = time.perf_counter()
with (HERE / 'prepare-attempt02.stdout.log').open('w') as stdout, (HERE / 'prepare-attempt02.stderr.log').open('w') as stderr:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=300)
after = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip()
status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain', '--untracked-files=no']).decode()
report = {'argv': argv, 'cwd': str(ROOT), 'environment': initial['environment'],
          'source_before': before, 'source_after': after, 'tracked_status': status,
          'source_unchanged': before == after and not status, 'returncode': result.returncode,
          'seconds': time.perf_counter() - start, 'performance_measurement': False}
(HERE / 'prepare-attempt02-execution.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: report[key] for key in ('source_after', 'source_unchanged', 'returncode', 'seconds')}))
assert result.returncode == 0
assert report['source_unchanged']
