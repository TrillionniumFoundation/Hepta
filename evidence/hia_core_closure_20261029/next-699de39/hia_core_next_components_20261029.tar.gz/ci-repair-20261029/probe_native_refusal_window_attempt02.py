"""Controlled reproduction; the historical CI's exact delay point is unknown."""
from pathlib import Path
import ast
import hashlib
import inspect
import json
import os
import subprocess
import sys
import textwrap
import time

BASE = Path(__file__).resolve().parent.parent
ROOT = BASE / 'hepta-ci-repair'
OUT = Path(__file__).resolve().parent / 'native-refusal-window-control-attempt02'
OUT.mkdir()
sys.path.insert(0, str(ROOT))
from hepta import hia_native_differential as differential
from tests.test_hia_native_child_limits import NativeChildHardLimitTests

marker = OUT / 'escaped-child-wrote-marker'
function = NativeChildHardLimitTests.test_worker_timeout_and_normal_exit_both_reap_forked_descendants
module_tree = ast.parse(Path(inspect.getsourcefile(function)).read_text())
tree = next(node for node in ast.walk(module_tree) if isinstance(node, ast.FunctionDef)
            and node.name == function.__name__)
expression = next(node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
                  and any(isinstance(item, ast.Name) and item.id == 'code' for item in node.targets))
code = eval(compile(ast.Expression(expression), '<frozen controlled fixture>', 'eval'),
            {'json': json, 'marker': marker})
source, library = OUT / 'fork.c', OUT / 'fork.so'
source.write_text(code)
compiler = BASE / 'toolchains/native/usr/lib/llvm-20/bin/clang'
argv = [str(compiler), '-O0', '-shared', '-fPIC', str(source), '-o', str(library)]
compiled = subprocess.run(argv, text=True, capture_output=True, timeout=30)
assert compiled.returncode == 0, compiled.stderr
rows = []
for symbol, timeout, expected in [('fork_and_stall', 0.2, 'timed out'),
                                  ('fork_and_stall', 3.0, 'unexpected error/signal -31'),
                                  ('fork_and_return', 3.0, 'unexpected error/signal -31'),
                                  ('stall_only', 0.2, 'timed out')]:
    original, identity, descriptor = differential._pin_native_artifact(library)
    start = time.perf_counter()
    try:
        differential._check_artifact_unchanged(library, original, identity)
        differential._observe_native(library, symbol, 'i32', [], timeout=timeout, pinned_fd=descriptor)
    except differential.HIADifferentialRejected as error:
        observed = str(error)
    else:
        raise AssertionError('native refusal expected')
    finally:
        os.close(descriptor)
    elapsed = time.perf_counter() - start
    time.sleep(1.1)
    row = {'symbol': symbol, 'timeout': timeout, 'observed': observed, 'seconds': elapsed,
           'expected': expected, 'marker_observation_delay_seconds': 1.1,
           'marker_absent': not marker.exists()}
    rows.append(row)
    (OUT / 'observations.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
    assert expected in observed, row
    assert not marker.exists(), row
report = {'ok': True, 'source_commit': subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip(),
          'fixture_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'fixture_library_sha256': hashlib.sha256(library.read_bytes()).hexdigest(),
          'compile': {'argv': argv, 'returncode': compiled.returncode, 'stdout': compiled.stdout, 'stderr': compiled.stderr},
          'observations': rows, 'original_ci_exact_delay_point_reconstructed': False,
          'production_deadlines_changed': False, 'seccomp_policy_changed': False,
          'general_cancellation_or_cleanup_proved': False}
(OUT / 'summary.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'ok': True, 'controls': len(rows), 'ci_delay_point_reconstructed': False}))
