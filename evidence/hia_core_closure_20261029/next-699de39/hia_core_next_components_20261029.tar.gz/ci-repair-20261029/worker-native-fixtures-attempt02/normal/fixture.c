
#include <stddef.h>
#include <stdint.h>
#include <signal.h>
static uint64_t calculate(size_t count, uint64_t packed, uint32_t state, uint32_t polynomial) {
    if (count > 8) return UINT64_C(4294967296);
    for (size_t i = 0; i < count; ++i) {
        state ^= (unsigned char)(packed >> (i * 8));
        for (unsigned bit = 0; bit < 8; ++bit)
            state = (state >> 1) ^ ((state & 1) ? polynomial : 0);
    }
    return state;
}
uint64_t checksum_chunk(size_t count, uint64_t packed, uint32_t state, uint32_t polynomial) {
#ifdef FAULT_SIGILL
    if (count == 1) raise(SIGILL);
#endif
    return calculate(count, packed, state, polynomial);
}
uint64_t c_checksum_chunk(size_t count, uint64_t packed, uint32_t state, uint32_t polynomial) {
    return checksum_chunk(count, packed, state, polynomial);
}
uint64_t checksum_chunk_v2(size_t count, uint64_t packed, uint32_t state, uint32_t algorithm) {
#ifdef FAULT_SIGABRT
    if (algorithm == 2) raise(SIGABRT);
#endif
    if (algorithm == 1) return calculate(count, packed, state, UINT32_C(0xedb88320));
    if (algorithm == 2) return calculate(count, packed, state, UINT32_C(0x82f63b78));
    return UINT64_C(12884901888);
}
uint64_t c_checksum_chunk_v2(size_t count, uint64_t packed, uint32_t state, uint32_t algorithm) {
    return checksum_chunk_v2(count, packed, state, algorithm);
}
