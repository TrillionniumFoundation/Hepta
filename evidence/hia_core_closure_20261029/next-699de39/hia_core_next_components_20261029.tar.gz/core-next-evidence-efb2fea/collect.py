from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/workspace/scratch/b484d4086829/hepta-core-next')
output = Path('/workspace/scratch/b484d4086829/core-next-evidence-efb2fea')
output.mkdir(exist_ok=False)
env = dict(os.environ)
env.update(PATH='/workspace/scratch/b484d4086829/toolchains/rust-1.90.0/bin:' + env['PATH'],
    CARGO_HOME='/workspace/scratch/0db0c44c1fb0/rust-tools/cargo',
    CARGO_TARGET_DIR='/workspace/scratch/b484d4086829/target-rust-policy-v3-190',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0',
    CARGO_NET_OFFLINE='true')
sys.path.insert(0, str(root))
from tools.qualify_hia_integrated import _source_state
before = _source_state()
assert before['head'] == 'efb2fea1de2855b2669593660d787b98fc966aa6' and not before['status']
commands = [
    ('rust-crate', ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'rust/hia-core-shadow/Cargo.toml']),
    ('legacy-python', [sys.executable, '-m', 'unittest',
        'tests.test_hia_rust_scalar_vm', 'tests.test_hia_rust_owned_vm',
        'tests.test_hia_rust_owned_memory', 'tests.test_hia_rust_bulk_vm',
        'tests.test_hia_rust_returned_loans', 'tests.test_hia_rust_returned_chains',
        'tests.test_hia_rust_bound_depth', 'tests.test_hia_rust_execution_crosscheck',
        'tests.test_hia_rust_crosscheck', 'tests.test_hia_rust_crosscheck_cli', '-v']),
    ('v3-frozen', [sys.executable, 'tools/qualify_hia_rust_budget_v3.py',
        '--expected-head', before['head'], '--output-directory', str(output / 'v3')]),
]
records = []
for label, argv in commands:
    started = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    with (output / (label + '.stdout')).open('wb') as stdout, (output / (label + '.stderr')).open('wb') as stderr:
        proc = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=900)
    record = {'label': label, 'argv': argv, 'cwd': str(root), 'returncode': proc.returncode,
              'started_utc': started, 'wall_seconds': time.monotonic() - tick,
              'finished_utc': datetime.now(timezone.utc).isoformat(),
              'stdout_sha256': sha256((output / (label + '.stdout')).read_bytes()).hexdigest(),
              'stderr_sha256': sha256((output / (label + '.stderr')).read_bytes()).hexdigest()}
    records.append(record)
    (output / 'processes.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
after = _source_state()
report = {'source_before': before, 'source_after': after, 'source_unchanged': before == after,
          'processes': records, 'processes_passed': all(r['returncode'] == 0 for r in records),
          'rust_is_production_authority': False, 'full_P2_closed': False}
(output / 'source-and-processes.json').write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if before == after and report['processes_passed'] else 1)
