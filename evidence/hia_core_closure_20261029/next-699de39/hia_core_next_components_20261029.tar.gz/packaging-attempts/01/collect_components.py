"""Freeze distinct finite source qualifications; no native/test execution."""
from __future__ import annotations
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import tempfile

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
REPO = BASE / 'hepta'
ARCHIVE_NAME = 'hia_core_next_components_20261029.tar.gz'
MAX_SINGLE_BLOB_BYTES = 12_000_000
SOURCE = '699de39a8e92e0f083df316ecc5333fb3ecf8571'
PATTERNS = {
    'github_fine_grained_token': rb'github_pat_[A-Za-z0-9_]{50,}',
    'github_classic_or_app_token': rb'gh[pousr]_[A-Za-z0-9]{30,}',
    'openai_secret_key': rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}',
    'aws_access_key': rb'(?:AKIA|ASIA)[A-Z0-9]{16}',
    'private_key_header': rb'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----',
    'slack_token': rb'xox[baprs]-[A-Za-z0-9-]{20,}',
    'google_api_key': rb'AIza[0-9A-Za-z_-]{35}',
    'gitlab_access_token': rb'glpat-[A-Za-z0-9_-]{20,}',
    'sendgrid_api_key': rb'SG\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}',
    'signed_download_url': rb'https?://[^\s"<>]+(?:[?&](?:sig|X-Amz-Signature|Signature)=)[^\s"<>]+',
}
FINDINGS = []


def valid_name(value):
    path = PurePosixPath(value)
    assert type(value) is str and value and not path.is_absolute()
    assert path.as_posix() == value and all(part not in ('', '.', '..') for part in path.parts)
    assert '\\' not in value and '\x00' not in value
    return value


def read_regular(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode), path
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        data = stream.read()
        final = os.fstat(stream.fileno())
    after = path.lstat()
    fields = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mode, info.st_mtime_ns, info.st_ctime_ns)
    assert fields(before) == fields(opened) == fields(final) == fields(after), path
    assert len(data) == before.st_size
    return data


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def dump(name, value):
    path = OUT / valid_name(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    return path


def scan(label, data):
    for name, pattern in PATTERNS.items():
        matches = sum(1 for _ in re.finditer(pattern, data))
        if matches:
            FINDINGS.append({'location': label, 'pattern': name, 'matches': matches})


entries = {}
groups = {}


def add(path, archive_path):
    name = valid_name(archive_path)
    assert name not in entries, name
    data = read_regular(path)
    entries[name] = {'source_path': path, 'path': name, 'mode': stat.S_IMODE(path.stat().st_mode), **identity(data)}


whole_directories = ['core-next-evidence-efb2fea', 'core-next-strict-result-52653db',
                     'v3-peer-review-efb2fea', 'integration-static-review-20261029']
excluded_nested = 'v3-peer-review-efb2fea/peer-review-efb2fea.tar.gz'
for directory in whole_directories:
    names = []
    for path in sorted((BASE / directory).rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        name = str(path.relative_to(BASE))
        if name == excluded_nested:
            continue
        names.append(name)
        add(path, name)
    groups[directory] = names

allowlist_path = BASE / 'ci-repair-20261029/PUBLIC_FILES.json'
allowlist = json.loads(read_regular(allowlist_path))
ci_names = []
for row in allowlist['files']:
    relative = valid_name(row['path'])
    assert relative != 'original-ci-download-private.json'
    path = allowlist_path.parent / relative
    observed = identity(read_regular(path))
    assert all(observed[key] == row[key] for key in ('bytes', 'sha256', 'git_blob')), relative
    name = 'ci-repair-20261029/' + relative
    add(path, name)
    ci_names.append(name)
add(allowlist_path, 'ci-repair-20261029/PUBLIC_FILES.json')
groups['ci-repair-20261029'] = ci_names + ['ci-repair-20261029/PUBLIC_FILES.json']

for name in ['source-publication-699de39.json', 'final-control-tests-95.log']:
    add(BASE / name, name)
for path in sorted((OUT / 'ci-699de39').iterdir()):
    assert path.is_file() and not path.is_symlink()
    add(path, 'ci-699de39/' + path.name)
add(Path(__file__), 'collect_components.py')

# Existing component manifests are themselves retained and checked unchanged.
for name in ('core-next-evidence-efb2fea', 'core-next-strict-result-52653db'):
    records = json.loads(read_regular(BASE / name / 'artifact-manifest.json'))
    for row in records:
        entry = entries[name + '/' + valid_name(row['path'])]
        assert entry['bytes'] == row['bytes'] and entry['sha256'] == row['sha256']
for row in json.loads(read_regular(BASE / 'v3-peer-review-efb2fea/retention.json'))['files']:
    entry = entries['v3-peer-review-efb2fea/' + valid_name(row['path'])]
    assert entry['bytes'] == row['bytes'] and entry['sha256'] == row['sha256']

# Exclude only the redundant container: every raw member is represented exactly.
old_archive = read_regular(BASE / excluded_nested)
old_receipt = json.loads(read_regular(BASE / 'v3-peer-review-efb2fea/archive-receipt.json'))
assert identity(old_archive)['sha256'] == old_receipt['sha256']
duplicate_members = []
with tarfile.open(fileobj=io.BytesIO(old_archive), mode='r:gz') as archive:
    for member in archive.getmembers():
        assert member.isfile()
        original = archive.extractfile(member).read()
        represented = 'v3-peer-review-efb2fea/' + valid_name(member.name)
        assert identity(original) == {key: entries[represented][key] for key in ('bytes', 'sha256', 'git_blob')}
        duplicate_members.append({'original_member': member.name, 'represented_by': represented, **identity(original)})
exclusions = [{
    'path': excluded_nested, **identity(old_archive),
    'reason': 'redundant tar container; every raw member retained byte-identically; original gzip container bytes not embedded',
    'represented_members': duplicate_members,
}, {'path': 'ci-repair-20261029/original-ci-download-private.json',
    'reason': 'private signed transport metadata intentionally excluded by the component publication allowlist; not read or scanned'},
    {'artifact_id': 12868778348, 'bytes': 337379434,
     'sha256': '77e2f532ddd607c812607d0d9c3b3494496f22dd84a5dcbd0ec29f39c22c772f',
     'url': 'https://github.com/TrillionniumFoundation/Hepta/actions/runs/40799429611/artifacts/12868778348',
     'reason': 'complete original hosted failure archive is externally referenced, not embedded; selected original reports/logs are retained'}]

# Scan decoded Git objects as well as the compressed bundle bytes. Temporary
# repositories use the existing repository only as a read-only object alternate.
common = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', '--git-common-dir']).decode().strip()
common_path = Path(common) if Path(common).is_absolute() else REPO / common
alternate = str((common_path / 'objects').resolve())
bundle_scans = []
for name, entry in sorted(entries.items()):
    if not name.endswith('.bundle'):
        continue
    data = read_regular(entry['source_path'])
    header, pack = data.split(b'\n\n', 1)
    assert header.startswith((b'# v2 git bundle\n', b'# v3 git bundle\n')) and pack.startswith(b'PACK')
    with tempfile.TemporaryDirectory(prefix='hepta-bundle-readback-') as folder:
        env = dict(os.environ, GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_NO_REPLACE_OBJECTS='1',
                   GIT_ALTERNATE_OBJECT_DIRECTORIES=alternate)
        subprocess.run(['git', 'init', '--bare', folder], env=env, check=True, capture_output=True)
        env['GIT_DIR'] = folder
        packed = subprocess.run(['git', 'index-pack', '--fix-thin', '--stdin'], input=pack,
                                env=env, check=True, capture_output=True)
        index = next((Path(folder) / 'objects/pack').glob('*.idx'))
        listing = subprocess.check_output(['git', 'verify-pack', '-v', str(index)], env=env).decode()
        objects = []
        for line in listing.splitlines():
            columns = line.split()
            if len(columns) >= 3 and re.fullmatch('[0-9a-f]{40}', columns[0]) and columns[1] in ('commit', 'tree', 'blob', 'tag'):
                oid, kind, length = columns[:3]
                payload = subprocess.check_output(['git', 'cat-file', kind, oid], env=env)
                assert len(payload) == int(length)
                assert hashlib.sha1(kind.encode() + b' ' + str(len(payload)).encode() + b'\0' + payload).hexdigest() == oid
                scan(name + ':decoded-object:' + oid, payload)
                objects.append({'object': oid, 'type': kind, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
        bundle_scans.append({'bundle': name, 'bundle_sha256': entry['sha256'],
            'header': header.decode(), 'index_pack_result': packed.stdout.decode().strip(),
            'decoded_objects_including_needed_thin_pack_bases': objects,
            'source_repository_modified': False, 'native_or_test_code_executed': False})
add(dump('bundle-object-scan.json', {'bundles': bundle_scans}), 'bundle-object-scan.json')

publication = json.loads(read_regular(BASE / 'source-publication-699de39.json'))
assert publication['public_commit'] == SOURCE and publication['tree'] == '592b6114f659fb18b13ad3fa5ed5e213ecdb92b5'
control = read_regular(BASE / 'final-control-tests-95.log').decode()
assert re.search(r'^Ran 23 tests in [0-9.]+s$', control, re.M) and re.search(r'^OK$', control, re.M)
ci = json.loads(read_regular(OUT / 'ci-699de39/summary.json'))
assert ci['source_commit'] == SOURCE and all(run['source_commit'] == SOURCE for run in ci['runs'])
pack_inputs = {'schema': 'hepta.next-component-inputs.v1', 'published_source': publication,
    'groups': groups, 'exclusions': exclusions,
    'frozen_control_log': {'path': 'final-control-tests-95.log', 'tests_run': 23,
        'scope': 'pre-publication focused controls; filename 95 is not an execution count',
        'public_699_full_gate_qualification': False},
    'ci_snapshot_scope': {'source_commit': SOURCE, 'observed_start_utc': ci['observed_start_utc'],
        'observed_finish_utc': ci['observed_finish_utc'], 'official_run_and_job_metadata_only': True,
        'artifacts_downloaded': False},
    'complete_699_integrated_and_safety_runs_included': False,
    'individual_component_results_relabelled_as_699_execution': False,
    'optimization_policy': 'no_change', 'production_authority': 'Python', 'all_P0_P7_closed': False}
add(dump('pack-inputs.json', pack_inputs), 'pack-inputs.json')
add(OUT / 'README.md', 'README.md')

for name, entry in sorted(entries.items()):
    scan(name, read_regular(entry['source_path']))
scan_report = {'schema': 'hepta.next-component-credential-scan.v1', 'patterns': list(PATTERNS),
    'pattern_count': len(PATTERNS), 'files_scanned': len(entries),
    'raw_bytes_scanned': sum(entry['bytes'] for entry in entries.values()),
    'git_bundles_decoded': len(bundle_scans),
    'git_objects_scanned': sum(len(row['decoded_objects_including_needed_thin_pack_bases']) for row in bundle_scans),
    'findings': FINDINGS, 'secret_values_printed': False,
    'excluded_private_transport_metadata_was_not_read': True}
add(dump('credential-scan.json', scan_report), 'credential-scan.json')
assert not FINDINGS, 'credential scan produced findings; see locations only in credential-scan.json'

retention = {'schema': 'hepta.next-component-retention.v1',
    'files': [{key: entry[key] for key in ('path', 'bytes', 'sha256', 'git_blob', 'mode')} for _, entry in sorted(entries.items())],
    'files_listed_excluding_this_retention_manifest': len(entries),
    'bytes_listed_excluding_this_retention_manifest': sum(entry['bytes'] for entry in entries.values()),
    'exclusions': exclusions, 'source_scopes_remain_independent': True}
retention_path = dump('retention.json', retention)
add(retention_path, 'retention.json')
archive_path = OUT / ARCHIVE_NAME
assert not archive_path.exists()
with archive_path.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as compressed:
    with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, entry in sorted(entries.items()):
            payload = read_regular(entry['source_path'])
            assert identity(payload) == {key: entry[key] for key in ('bytes', 'sha256', 'git_blob')}
            member = tarfile.TarInfo(name)
            member.size = len(payload)
            member.mode = entry['mode']
            member.mtime = 0
            member.uid = member.gid = 0
            member.uname = member.gname = ''
            archive.addfile(member, io.BytesIO(payload))

readback = []
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(entries)
    assert len({member.name for member in members}) == len(members)
    for member in members:
        assert member.isfile() and member.name in entries
        payload = archive.extractfile(member).read()
        expected = entries[member.name]
        assert identity(payload) == {key: expected[key] for key in ('bytes', 'sha256', 'git_blob')}
        assert member.mode == expected['mode']
        readback.append(member.name)
for entry in entries.values():
    assert identity(read_regular(entry['source_path'])) == {key: entry[key] for key in ('bytes', 'sha256', 'git_blob')}
for directory in whole_directories:
    current = sorted(str(path.relative_to(BASE)) for path in (BASE / directory).rglob('*')
                     if path.is_file() and str(path.relative_to(BASE)) != excluded_nested)
    assert current == groups[directory], directory

archive_bytes = read_regular(archive_path)
receipt = {'schema': 'hepta.next-component-archive-receipt.v1', 'ok': True, 'status': 'frozen_and_readback_verified',
    'archive': ARCHIVE_NAME, **identity(archive_bytes), 'members': len(readback),
    'uncompressed_file_bytes': sum(entry['bytes'] for entry in entries.values()),
    'all_member_bytes_hashes_and_modes_matched': True, 'all_inputs_rechecked_after_archive': True,
    'retention': {'path': 'retention.json', **identity(read_regular(retention_path))},
    'credential_scan': {'path': 'credential-scan.json', **identity(read_regular(OUT / 'credential-scan.json'))},
    'ci_snapshot_utc': ci['observed_finish_utc'], 'qualified_source_scopes_are_distinct': True,
    'contains_new_699_full_gate_qualification': False, 'storage_representation': 'whole-file',
    'max_single_blob_raw_bytes': MAX_SINGLE_BLOB_BYTES}
if len(archive_bytes) > MAX_SINGLE_BLOB_BYTES:
    part_dir = OUT / 'archive.parts'
    part_dir.mkdir()
    parts = []
    for index, offset in enumerate(range(0, len(archive_bytes), 4 * 1024 * 1024)):
        payload = archive_bytes[offset:offset + 4 * 1024 * 1024]
        name = 'archive.parts/part-' + str(index).zfill(5) + '.bin'
        (OUT / name).write_bytes(payload)
        parts.append({'index': index, 'offset': offset, 'path': name, **identity(payload)})
    restored = b''.join(read_regular(OUT / part['path']) for part in parts)
    assert restored == archive_bytes
    receipt.update(storage_representation='ordered-lossless-raw-parts', parts=parts,
                   reassembly_sha256_verified=True, monolithic_archive_required_for_publication=False)
dump('archive-receipt.json', receipt)
print(json.dumps(receipt, sort_keys=True))
