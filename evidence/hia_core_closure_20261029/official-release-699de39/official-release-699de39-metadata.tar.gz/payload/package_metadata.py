#!/usr/bin/env python3
"""Package the completed read-only official-release audit, excluding raw ZIPs."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, os, stat, tarfile
from inventory_official_zip import RX

HERE=Path(__file__).resolve().parent
ROOT_FILES=('README.md','summary.json','download-receipt.json','job-123409464501.log',
 'zip-inventory.json','zip-credential-scan.json','raw-parts.json',
 'inventory_official_zip.py','inventory.stdout.log','inventory.stderr.log',
 'audit_official_release.py','audit.json','audit.stdout.log','audit.stderr.log',
 'audit-execution-receipt.json','method-statuses.json','source-git-binding.json','retained-members.json',
 'restore_official_zip.py','restore-process.json','restore-readback.json','restore.stdout.log','restore.stderr.log',
 'package_metadata.py')
TREES=('metadata','retained','auditor-development','packaging-development')

def identity(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 raw=p.read_bytes();after=p.lstat()
 stable=lambda v:(v.st_dev,v.st_ino,v.st_mode,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
 assert len(raw)==s.st_size and stable(after)==stable(s)
 return {'path':p.relative_to(HERE).as_posix(),'bytes':len(raw),'mode_octal':oct(stat.S_IMODE(s.st_mode)),
         'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}

def main():
 paths={HERE/n for n in ROOT_FILES}
 for name in TREES:
  for p in (HERE/name).rglob('*'):
   if p.is_dir():assert not p.is_symlink();continue
   paths.add(p)
 rows=[identity(p) for p in sorted(paths)]
 findings=[]
 for row in rows:
  raw=(HERE/row['path']).read_bytes()
  for name,rx in RX.items():
   findings.extend({'path':row['path'],'pattern':name,'offset':m.start()} for m in rx.finditer(raw))
 scan={'schema':'hepta.official-release-metadata-scan.v1','files':len(rows),'bytes':sum(r['bytes'] for r in rows),'patterns':len(RX),'findings':findings,'values_printed':False,'general_absence_of_secrets_proved':False}
 assert not findings
 (HERE/'metadata-credential-scan.json').write_text(json.dumps(scan,indent=2)+'\n')
 manifest={'schema':'hepta.official-release-metadata-retention.v1','source_commit':'699de39a8e92e0f083df316ecc5333fb3ecf8571','files':rows,'file_count':len(rows),'retained_bytes':sum(r['bytes'] for r in rows),'raw_zip_and_raw_parts_duplicated':False,'private_transport_selected':False,'scope':'Original selected current reports/streams, exact inventories and read-only audit records. Complete raw ZIP retained separately as original parts.'}
 manifest_raw=(json.dumps(manifest,indent=2)+'\n').encode()
 (HERE/'metadata-retention.json').write_bytes(manifest_raw)
 generated={'MANIFEST.json':manifest_raw,'FINITE_SCAN.json':(HERE/'metadata-credential-scan.json').read_bytes()}
 output=HERE/'official-release-699de39-metadata.tar.gz'
 assert not output.exists()
 with output.open('xb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as gz,tarfile.open(mode='w|',fileobj=gz,format=tarfile.PAX_FORMAT) as tar:
  for row in rows:
   p=HERE/row['path'];assert identity(p)==row
   info=tarfile.TarInfo('payload/'+row['path']);info.size=row['bytes'];info.mode=int(row['mode_octal'],8);info.mtime=0;info.uid=info.gid=0
   with p.open('rb') as src:tar.addfile(info,src)
  for name,raw in generated.items():
   info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0
   tar.addfile(info,io.BytesIO(raw))
 expected={'payload/'+r['path']:r for r in rows};seen=set();decoded=0
 with output.open('rb') as src,gzip.GzipFile(fileobj=src,mode='rb') as gz,tarfile.open(fileobj=gz,mode='r|') as tar:
  for info in tar:
   assert info.isfile() and info.name not in seen and info.uid==info.gid==info.mtime==0
   seen.add(info.name);f=tar.extractfile(info);sha=hashlib.sha256();blob=hashlib.sha1(b'blob '+str(info.size).encode()+b'\0');n=0
   for chunk in iter(lambda:f.read(1024*1024),b''):sha.update(chunk);blob.update(chunk);n+=len(chunk)
   assert n==info.size;decoded+=n
   if info.name in expected:
    row=expected[info.name];assert n==row['bytes'] and info.mode==int(row['mode_octal'],8) and sha.hexdigest()==row['sha256'] and blob.hexdigest()==row['git_blob_sha1']
   else:
    assert info.name in generated and n==len(generated[info.name]) and info.mode==0o644 and sha.hexdigest()==hashlib.sha256(generated[info.name]).hexdigest()
  trailing=0
  for chunk in iter(lambda:tar.fileobj.read(1024*1024),b''):
   trailing+=len(chunk);assert trailing<=16*1024*1024 and not any(chunk)
 assert seen==set(expected)|set(generated)
 assert rows==[identity(HERE/r['path']) for r in rows]
 result=identity(output)
 receipt={'schema':'hepta.official-release-metadata-archive.v1','created_utc':datetime.now(timezone.utc).isoformat(),'archive':result,'original_selected_files':len(rows),'retained_input_bytes':manifest['retained_bytes'],'archive_members':len(seen),'decoded_member_bytes':decoded,'all_original_bytes_modes_and_paths_match':True,'all_members_read_through_gzip_eof_crc':True,'inputs_unchanged':True,'raw_zip_bytes_duplicated':False,'native_or_test_execution_by_packager':0,'source_commit':manifest['source_commit'],'broad_P0_P7_closed':False,'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest()}
 (HERE/'metadata-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt))

if __name__=='__main__':main()
