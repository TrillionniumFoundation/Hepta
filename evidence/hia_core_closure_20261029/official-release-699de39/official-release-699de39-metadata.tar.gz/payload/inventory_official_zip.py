#!/usr/bin/env python3
"""Read actual official ZIP bytes without executing or extracting archived code."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import collections, hashlib, json, re, stat, zipfile

HERE=Path(__file__).resolve().parent
ZIP=HERE/'official-full-release-699de39.zip'
EXPECTED_BYTES=344601243
EXPECTED_SHA='0bd04d40b4a88be8f244d93d6adfb6460680ddc0b1c03e4524c9a02c6bbb613e'
PATTERNS={
 'private_key_pem':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
 'github_token':rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{35,})',
 'api_secret_prefix':rb'\b(?:sk-proj-|sk-ant-api)[A-Za-z0-9_-]{24,}',
 'aws_access_key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'aws_secret_assignment':rb'(?i)aws_secret_access_key[\s\"\x27:=]{1,8}[A-Za-z0-9/+]{40}\b',
 'authorization_header':rb'(?i)authorization\s*:\s*(?:bearer|token|basic)\s+[A-Za-z0-9][A-Za-z0-9._+/=-]{15,}',
 'signed_or_credential_url':rb'(?i)[?&](?:sig|x-amz-signature|x-goog-signature|access_token)=[A-Za-z0-9%_+/=-]{16,}',
 'url_user_password':rb'https?://[A-Za-z0-9._-]{2,}:[^\s/@<>\"\x27]{8,}@',
 'secret_assignment':rb'(?i)(?:api_secret|client_secret|api_key)\s*[=:]\s*[\"\x27][A-Za-z0-9_+/-]{24,}[\"\x27]',
 'slack_or_npm_token':rb'(?:xox[baprs]-[A-Za-z0-9-]{24,}|npm_[A-Za-z0-9]{30,})',
}
RX={k:re.compile(v) for k,v in PATTERNS.items()}

def digest_file(path):
 h=hashlib.sha256(); n=0
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b);n+=len(b)
 return n,h.hexdigest()

def main():
 n,digest=digest_file(ZIP)
 assert (n,digest)==(EXPECTED_BYTES,EXPECTED_SHA)
 rows=[]; paths=set(); findings=[]; scopes=collections.Counter(); scan_bytes=0
 with zipfile.ZipFile(ZIP) as z:
  for i,info in enumerate(z.infolist()):
   name=info.filename; p=PurePosixPath(name)
   assert name and not name.startswith('/') and '\\' not in name and '\x00' not in name
   assert all(x not in ('','.','..') for x in name.split('/')) and str(p)==name
   assert name not in paths, ('duplicate',name)
   paths.add(name)
   assert info.flag_bits&1==0, ('encrypted',name)
   mode=info.external_attr>>16
   assert stat.S_ISREG(mode), ('nonregular',name,mode)
   h=hashlib.sha256(); g=hashlib.sha1(b'blob '+str(info.file_size).encode()+b'\0'); count=0;tail=b''
   with z.open(info) as f:
    while True:
     b=f.read(1024*1024)
     if not b:break
     h.update(b);g.update(b)
     data=tail+b; start=count-len(tail)
     for key,rx in RX.items():
      for match in rx.finditer(data):
       offset=start+match.start()
       if offset+len(match.group())>count:
        findings.append({'path':name,'pattern':key,'offset':offset})
     count+=len(b);tail=data[-4096:]
   assert count==info.file_size
   scan_bytes+=count
   current=(name.startswith(('Hepta/Hepta/artifacts/candidate/','Hepta/Hepta/artifacts/hia-unified/','Hepta/Hepta/artifacts/hia-ndu/','_temp/')) or name=='Hepta/Hepta/artifacts/workflow-source.json')
   scope='current_workflow_selected_outputs' if current else 'historical_or_other_uploaded_outputs'
   scopes[scope]+=1
   rows.append({'path':name,'bytes':count,'sha256':h.hexdigest(),'git_blob_sha1':g.hexdigest(),'zip_mode_octal':oct(mode),'crc32':f'{info.CRC:08x}','compressed_bytes':info.compress_size,'scope':scope})
   if (i+1)%1000==0: print(json.dumps({'members_read':i+1,'bytes_read':scan_bytes}),flush=True)
  # Each member was read through EOF, so zipfile checked every CRC.
 out={'schema':'hepta.official-release-zip-inventory.v1','source_commit':'699de39a8e92e0f083df316ecc5333fb3ecf8571','artifact_id':12898133203,'archive':{'path':ZIP.name,'bytes':n,'sha256':digest,'official_digest_matches':True},'member_count':len(rows),'decoded_bytes':scan_bytes,'scope_counts':dict(scopes),'all_members_streamed_to_eof_and_crc_checked':True,'no_archive_code_executed':True,'paths_unique_and_canonical':True,'members':rows}
 (HERE/'zip-inventory.json').write_text(json.dumps(out,indent=2)+'\n')
 scan={'schema':'hepta.official-release-finite-scan.v1','created_utc':datetime.now(timezone.utc).isoformat(),'pattern_count':len(RX),'patterns':{k:v.decode() for k,v in PATTERNS.items()},'members_scanned':len(rows),'decoded_bytes_scanned':scan_bytes,'findings':findings,'matched_values_printed':False,'no_general_absence_of_credentials_proof':True,'nested_archives_decoded':False,'scope':'All original ZIP member bytes; finite ten-pattern inspection only. Nested archive bytes are scanned as stored, not recursively interpreted.'}
 (HERE/'zip-credential-scan.json').write_text(json.dumps(scan,indent=2)+'\n')
 print(json.dumps({'member_count':len(rows),'decoded_bytes':scan_bytes,'finding_count':len(findings),'all_crc_checked':True,'scope_counts':dict(scopes)}))

if __name__=='__main__':main()
