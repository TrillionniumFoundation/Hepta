#!/usr/bin/env python3
"""Package frozen local/public v4 evidence without relabeling executions."""
from datetime import datetime, timezone
from hashlib import sha1, sha256
import gzip
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

WORKSPACE = Path('/workspace/scratch/b484d4086829')
LOCAL = WORKSPACE / 'rust-api-v4-validation'
PUBLIC = WORKSPACE / 'rust-api-v4-public-validation'
REVIEW = WORKSPACE / 'rust-api-independent-review'
OUTPUT = WORKSPACE / 'rust-api-v4-evidence-package'
LOCAL_COMMIT = 'bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7'
PUBLIC_COMMIT = 'adbe4a1168a84d0696749ef54f933994b5dc554c'
SOURCE_TREE = '04b70dccc157af470aa2b5bdeb74e6f88dbff5bf'


def read_json(path):
    return json.loads(path.read_bytes())


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def checksum(raw):
    return sha256(raw).hexdigest()


def git_blob(raw):
    return sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': checksum(raw), 'git_blob_sha1': git_blob(raw)}


def public_summary():
    processes = {name: read_json(PUBLIC / name / 'process.json') for name in
                 ('public-rust-crate', 'public-v4-process', 'public-related-python')}
    for process in processes.values():
        assert process['returncode'] == 0
        assert process['source_before'] == process['source_after'] == {
            'head': PUBLIC_COMMIT, 'tree': SOURCE_TREE, 'status': ''}
        assert process['source_unchanged'] and process['toolchains_unchanged']
        assert process['original_local_binary_and_evidence_preserved']
        for entry in process['raw'].values():
            assert identity(Path(entry['path']))['sha256'] == entry['sha256']
    rust_log = (PUBLIC / 'public-rust-crate/stdout.log').read_text()
    rust_rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                          r'(\d+) measured; (\d+) filtered out', rust_log)
    assert len(rust_rows) == 18
    assert all(row[0] == 'ok' and all(int(value) == 0 for value in row[2:]) for row in rust_rows)
    assert sum(int(row[1]) for row in rust_rows) == 93
    python_log = (PUBLIC / 'public-related-python/stderr.log').read_text()
    assert re.search(r'\nRan 45 tests in [0-9.]+s\n\nOK\n\Z', python_log)
    assert len(re.findall(r'^test_.* \.\.\. ok$', python_log, re.MULTILINE)) == 45
    qualified = read_json(PUBLIC / 'public-v4/qualification.json')
    assert qualified['expected_head'] == PUBLIC_COMMIT and qualified['ok'] is True
    assert qualified['tests'] == {'run': 8, 'failures': 0, 'errors': 0, 'skipped': 0,
                                  'expected_failures': 0, 'unexpected_successes': 0}
    assert qualified['source_unchanged'] and qualified['toolchains_unchanged']
    assert qualified['positive_observations'] == 155 and qualified['raw_refusals'] == 37
    assert qualified['legacy_compatibility_versions'] == 8
    assert sum(len(row['reports']) for row in qualified['legacy_compatibility']) == 72
    review = read_json(REVIEW / 'execution-review.json')
    assert review['source_commit'] == LOCAL_COMMIT and review['source_tree'] == SOURCE_TREE
    assert review['native_process_invocations'] == 11 and review['ok'] is True and not review['findings']
    assert read_json(PUBLIC / 'prior-evidence-before.json') == read_json(PUBLIC / 'prior-evidence-after.json')
    binaries = {label: identity(WORKSPACE / target / 'debug/hia-core-shadow')
                for label, target in (('original_local', 'rust-api-target'), ('public_rebuilt', 'rust-api-public-target'))}
    assert binaries['original_local'] == binaries['public_rebuilt']
    assert binaries['public_rebuilt']['sha256'] == qualified['binary']['sha256_before'] == qualified['binary']['sha256_after']
    for name in ('public-v4-process', 'public-related-python'):
        assert processes[name]['binary_before'] == processes[name]['binary_after']
    report = {
        'schema': 'hepta.hia.rust-v4-public-focused-validation.v1', 'ok': True,
        'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'public_execution_commit': PUBLIC_COMMIT, 'original_local_execution_commit': LOCAL_COMMIT,
        'identical_source_tree': SOURCE_TREE,
        'public_execution_started_utc': processes['public-rust-crate']['started_utc'],
        'public_execution_finished_utc': processes['public-related-python']['finished_utc'],
        'public_results': {'rust_tests_passed': 93, 'rust_harness_blocks': 18,
            'v4_selected_methods_passed': 8, 'related_python_methods_passed': 45,
            'positive_observations': 155, 'raw_refusals': 37, 'legacy_report_count': 72,
            'legacy_primitive_versions': 8, 'failures': 0, 'errors': 0, 'skips': 0},
        'process_records': {name: {'relative_path': name + '/process.json',
                            **identity(PUBLIC / name / 'process.json')} for name in processes},
        'public_v4_qualification': {'relative_path': 'public-v4/qualification.json',
                                    **identity(PUBLIC / 'public-v4/qualification.json')},
        'independent_review': {'execution_commit': LOCAL_COMMIT, 'actual_native_invocations': 11,
            'findings': [], 'frozen_files': 26, 'public_execution_relabeling': False},
        'binaries': binaries, 'identical_binary_bytes_stored_once_in_archive': True,
        'source_and_tools_stable': True, 'prior_local_and_review_records_preserved': True,
        'original_publication_snapshot_preserved': True,
        'claims': {'required_focused_public_execution_passed': True,
            'full_integrated_gates_run_by_this_component': False,
            'separate_699de39_full_release_run_reused_as_public_v4_execution': False,
            'complete_python_api_parity': False, 'unbounded_failure_index_transport': False,
            'production_authority': 'Python', 'optimization_policy': 'no_change',
            'full_P2_closed': False, 'all_P0_P7_closed': False},
    }
    (PUBLIC / 'public-focused-summary.json').write_bytes(json_bytes(report))
    return report


def main():
    summary = public_summary()
    review_files = sorted(path for path in REVIEW.rglob('*') if path.is_file())
    assert len(review_files) == 26
    for item in read_json(REVIEW / 'retention.json')['files']:
        path = REVIEW / item['path']
        assert identity(path) == {key: item[key] for key in ('bytes', 'sha256', 'git_blob_sha1')}
        assert f'{stat.S_IMODE(path.stat().st_mode):04o}' == item['mode_octal']
    for path in (WORKSPACE / 'hepta-api-public', WORKSPACE / 'hepta-api'):
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=path)

    payload = {}
    for label, folder in (('original-local', LOCAL), ('public-execution', PUBLIC), ('independent-review', REVIEW)):
        for path in sorted(folder.rglob('*')):
            if path.is_file():
                assert not path.is_symlink()
                payload['payload/' + label + '/' + path.relative_to(folder).as_posix()] = (
                    path.read_bytes(), stat.S_IMODE(path.stat().st_mode), str(path))
    binary = WORKSPACE / 'rust-api-public-target/debug/hia-core-shadow'
    payload['payload/native/hia-core-shadow'] = (binary.read_bytes(), stat.S_IMODE(binary.stat().st_mode), str(binary))
    script = Path(__file__)
    payload['build_evidence_archive.py'] = (script.read_bytes(), stat.S_IMODE(script.stat().st_mode), str(script))
    readme = f'''# Bound-v4 exact finite API increment: retained evidence

This package preserves three distinct evidence origins without relabeling:

* Original local component executions: {LOCAL_COMMIT}.
* Actual required focused public executions: {PUBLIC_COMMIT}.
* Independent review: 11 actual executions on the original local commit,
  plus static review, with no findings. The review's 26 files are unchanged.

The two component commits have the same exact source tree {SOURCE_TREE}.
Both native builds produced identical 3,470,040-byte executables, SHA256
{summary['binaries']['public_rebuilt']['sha256']}; one exact binary is retained
under payload/native/. Its original and rebuilt identities remain separately
recorded in the execution records. The full transitive toolchain and system
runtime are not bundled or claimed to be closed by this archive.

The public run actually performed the full Rust crate (93 passed across 18
harness blocks), all 8 selected v4 methods, and 45 related existing Python
methods, with zero failures, errors or skips. The v4 collector retains 155
actual observations, 37 raw refusals, and 72 legacy reports across primitive
v1-v8. These observations and reports are not additional language test methods.
The local and public reruns are not added together as new unique coverage.
The earlier initial-* records remain historical pre-freeze attempts.

The source-files directory, exact patch, local/public/base raw Git commit
objects, changed-file blob/mode map, and the four original publication receipt
files are retained. The historical public-source-commit.json snapshot saying
public_execution_not_yet_repeated=true is intentionally unchanged. The later
public-focused-summary.json and actual public process logs record the new run.

This is finite bound-v4 API evidence. Policy transport still has a 1024-byte
ceiling; scalar transport remains 8192 arguments and 128 KiB. Production
authority remains Python and optimization policy remains no_change. Full P2
and all P0-P7 closure remain false. The separate full eight-gate 699de39
qualification is not a public-v4 execution and is not included in these counts.

MANIFEST.json binds every payload file's bytes, SHA256, Git blob SHA1 and stored
mode. The external archive-receipt.json binds this entire archive and records
complete gzip-stream and per-member tar read-back verification.
'''
    payload['README.md'] = (readme.encode(), 0o644, 'generated package index')
    manifest = {'schema': 'hepta.hia.rust-v4-evidence-package-manifest.v1',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'original_local_commit': LOCAL_COMMIT, 'public_execution_commit': PUBLIC_COMMIT,
        'source_tree': SOURCE_TREE, 'public_results': summary['public_results'],
        'independent_review_local_invocations': 11,
        'files': [{'path': name, 'mode_octal': f'{mode:04o}', 'bytes': len(raw),
                   'sha256': checksum(raw), 'git_blob_sha1': git_blob(raw), 'source_path': origin}
                  for name, (raw, mode, origin) in sorted(payload.items())],
        'self_digest_bound_by_archive_receipt': True,
        'all_P0_P7_closed': False, 'production_authority': 'Python', 'optimization_policy': 'no_change'}
    manifest_raw = json_bytes(manifest)
    (OUTPUT / 'manifest.json').write_bytes(manifest_raw)
    (OUTPUT / 'README.md').write_text(readme)
    archive = OUTPUT / 'rust-api-v4-local-public-evidence.tar.gz'
    assert not archive.exists()
    expected = dict(payload)
    expected['MANIFEST.json'] = (manifest_raw, 0o644, str(OUTPUT / 'manifest.json'))
    with archive.open('wb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as tar:
                for name, (raw, mode, _) in sorted(expected.items()):
                    member = tarfile.TarInfo(name)
                    member.size, member.mode, member.mtime = len(raw), mode, 0
                    member.uid, member.gid, member.uname, member.gname = 0, 0, '', ''
                    tar.addfile(member, io.BytesIO(raw))
    assert archive.stat().st_size <= 12 * 1024 * 1024
    expanded, total = sha256(), 0
    with gzip.open(archive, 'rb') as stream:
        while block := stream.read(1024 * 1024):
            expanded.update(block)
            total += len(block)
    seen = set()
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            assert member.isfile() and not member.issym() and not member.islnk()
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and member.name not in seen
            raw, mode, _ = expected[member.name]
            assert member.size == len(raw) and member.mode == mode
            recovered = sha256()
            recovered_size = 0
            with tar.extractfile(member) as stream:
                while block := stream.read(1024 * 1024):
                    recovered.update(block)
                    recovered_size += len(block)
            assert recovered_size == len(raw) and recovered.hexdigest() == checksum(raw)
            seen.add(member.name)
    assert seen == set(expected)
    for name, (raw, _, origin) in payload.items():
        if origin != 'generated package index':
            assert Path(origin).read_bytes() == raw, name
    receipt = {'schema': 'hepta.hia.rust-v4-evidence-archive-receipt.v1',
        'completed_utc': datetime.now(timezone.utc).isoformat(),
        'archive': {'path': str(archive), **identity(archive)},
        'manifest': {'path': str(OUTPUT / 'manifest.json'), **identity(OUTPUT / 'manifest.json')},
        'compressed_limit_bytes': 12 * 1024 * 1024, 'within_limit': True,
        'full_gzip_stream_readback': {'ok': True, 'uncompressed_bytes': total,
                                      'uncompressed_sha256': expanded.hexdigest()},
        'full_tar_member_readback': {'ok': True, 'members': len(seen),
            'payload_files_in_manifest': len(payload), 'missing': [], 'unexpected': [],
            'duplicate_names': [], 'unsafe_paths': [], 'size_hash_mode_mismatches': []},
        'all_original_input_bytes_unchanged_after_packaging': True,
        'public_execution_commit': PUBLIC_COMMIT, 'original_local_execution_commit': LOCAL_COMMIT,
        'independent_review_execution_commit': LOCAL_COMMIT, 'source_tree': SOURCE_TREE,
        'public_results': summary['public_results'], 'independent_native_invocations': 11,
        'no_original_execution_relabelled': True, 'no_optional_tests_run': True,
        'all_P0_P7_closed': False, 'production_authority': 'Python', 'optimization_policy': 'no_change'}
    (OUTPUT / 'archive-receipt.json').write_bytes(json_bytes(receipt))
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
