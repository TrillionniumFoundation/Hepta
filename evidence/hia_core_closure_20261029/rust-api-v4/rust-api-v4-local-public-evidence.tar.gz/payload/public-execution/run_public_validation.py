#!/usr/bin/env python3
"""Retain actual required focused executions on the published v4 commit."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

WORKSPACE = Path('/workspace/scratch/b484d4086829')
ROOT = WORKSPACE / 'hepta-api-public'
OUTPUT = WORKSPACE / 'rust-api-v4-public-validation'
PUBLIC = 'adbe4a1168a84d0696749ef54f933994b5dc554c'
TREE = '04b70dccc157af470aa2b5bdeb74e6f88dbff5bf'
TOOLCHAIN = WORKSPACE / 'toolchains/rust-1.90.0/bin'
TARGET = WORKSPACE / 'rust-api-public-target'
ENV = os.environ.copy()
ENV.update(PATH=str(TOOLCHAIN) + ':' + ENV['PATH'],
    RUSTC=str(TOOLCHAIN / 'rustc'), CARGO_HOME=str(WORKSPACE / 'toolchains/cargo-home'),
    CARGO_TARGET_DIR=str(TARGET), CARGO_NET_OFFLINE='true', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', PYTHONDONTWRITEBYTECODE='1')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def identity(path):
    if not path.is_file():
        return {'path': str(path), 'exists': False}
    return {'path': str(path), 'exists': True, 'bytes': path.stat().st_size, 'sha256': digest(path)}


def git(*arguments):
    return subprocess.run(['git', *arguments], cwd=ROOT, check=True,
        capture_output=True, text=True).stdout.strip()


def source():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def tools():
    values = {}
    for name, flag in (('cargo', '-V'), ('rustc', '-vV')):
        executable = Path(shutil.which(name, path=ENV['PATH']))
        argv = [str(executable), flag]
        result = subprocess.run(argv, env=ENV, cwd=ROOT, capture_output=True, text=True)
        values[name] = {**identity(executable), 'argv': argv, 'returncode': result.returncode,
                        'stdout': result.stdout, 'stderr': result.stderr}
        assert result.returncode == 0
    return values


def main():
    initial = source()
    assert initial == {'head': PUBLIC, 'tree': TREE, 'status': ''}, initial
    retained = [p for p in (WORKSPACE / 'rust-api-v4-validation').rglob('*') if p.is_file()]
    retained += [p for p in (WORKSPACE / 'rust-api-independent-review').rglob('*') if p.is_file()]
    retained += [WORKSPACE / 'rust-api-target/debug/hia-core-shadow']
    baseline = {str(path): identity(path) for path in sorted(retained)}
    (OUTPUT / 'prior-evidence-before.json').write_text(json.dumps(baseline, sort_keys=True, indent=2) + '\n')
    commands = [
        ('public-rust-crate', ['cargo', 'test', '--locked', '--offline', '--manifest-path',
            'rust/hia-core-shadow/Cargo.toml']),
        ('public-v4-process', ['python', 'tools/qualify_hia_rust_api_v4.py', '--expected-head', PUBLIC,
            '--output-directory', str(OUTPUT / 'public-v4')]),
        ('public-related-python', ['python', '-m', 'unittest',
            'tests.test_hia_rust_execution_crosscheck', 'tests.test_hia_rust_bound_depth',
            'tests.test_hia_rust_budget_v3', 'tests.test_hia_safety_protocol',
            'tests.test_hia_rust_budget_qualification', 'tests.test_hia_integrated_inputs', '-v']),
    ]
    for name, argv in commands:
        destination = OUTPUT / name
        destination.mkdir(exist_ok=False)
        before, tools_before = source(), tools()
        binary_before = identity(TARGET / 'debug/hia-core-shadow')
        started, clock = datetime.now(timezone.utc).isoformat(), time.monotonic()
        print(json.dumps({'started': name, 'argv': argv, 'utc': started}), flush=True)
        with (destination / 'stdout.log').open('wb') as stdout, (destination / 'stderr.log').open('wb') as stderr:
            result = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr)
        finished, elapsed = datetime.now(timezone.utc).isoformat(), time.monotonic() - clock
        after, tools_after = source(), tools()
        binary_after = identity(TARGET / 'debug/hia-core-shadow')
        preserved = all(identity(Path(path)) == value for path, value in baseline.items())
        report = {'argv': argv, 'cwd': str(ROOT), 'started_utc': started, 'finished_utc': finished,
            'returncode': result.returncode, 'wall_seconds': elapsed,
            'source_before': before, 'source_after': after, 'source_unchanged': before == after,
            'toolchains_before': tools_before, 'toolchains_after': tools_after,
            'toolchains_unchanged': tools_before == tools_after,
            'binary_before': binary_before, 'binary_after': binary_after,
            'original_local_binary_and_evidence_preserved': preserved,
            'environment': {key: ENV.get(key) for key in ('PATH', 'RUSTC', 'CARGO_HOME',
                'CARGO_TARGET_DIR', 'CARGO_NET_OFFLINE', 'CARGO_INCREMENTAL',
                'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'PYTHONDONTWRITEBYTECODE')},
            'raw': {file: identity(destination / file) for file in ('stdout.log', 'stderr.log')}}
        (destination / 'process.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
        print(json.dumps({'finished': name, 'returncode': result.returncode, 'wall_seconds': elapsed,
            'source_unchanged': before == after, 'toolchains_unchanged': tools_before == tools_after,
            'prior_evidence_preserved': preserved, 'raw_directory': str(destination)}), flush=True)
        assert before == after == initial and tools_before == tools_after and preserved
        if result.returncode:
            print((destination / 'stderr.log').read_text()[-10000:], flush=True)
            return result.returncode
    final = {str(path): identity(path) for path in sorted(retained)}
    (OUTPUT / 'prior-evidence-after.json').write_text(json.dumps(final, sort_keys=True, indent=2) + '\n')
    assert final == baseline
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
