from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256, sha1
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
REPO = ROOT / 'hepta-api'
HEAD = 'bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7'
TREE = '04b70dccc157af470aa2b5bdeb74e6f88dbff5bf'
BINARY_SHA = '5c39bec4def3b274487c4dce5f37475d7c2e0ac0c1e14634f5fa906f87c15abc'

def require(condition, reason):
    if not condition:
        raise AssertionError(reason)

def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate decoded JSON key')
        result[key] = value
    return result

def parse(data):
    return json.loads(data, object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def identity(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
            'git_blob_sha1': sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def save(path, value):
    with path.open('x') as output:
        output.write(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n')

execution = parse((BASE / 'execution-review.json').read_text())
require(execution['ok'] and execution['native_process_invocations'] == 11, 'Independent execution result differs')
require(execution['source_commit'] == HEAD and execution['source_tree'] == TREE, 'Independent source differs')
owner_path = ROOT / 'rust-api-v4-validation/frozen-v4/qualification.json'
owner = parse(owner_path.read_text())
require(owner['ok'] and owner['expected_head'] == HEAD, 'Owner qualification source/result differs')
require(owner['tests'] == {'run': 8, 'errors': 0, 'failures': 0, 'skipped': 0,
                          'expected_failures': 0, 'unexpected_successes': 0}, 'Owner method denominator differs')
require(owner['source_before'] == owner['source_after'] and owner['source_unchanged'], 'Owner source drift')
require(owner['binary']['sha256_before'] == owner['binary']['sha256_after'] == BINARY_SHA, 'Owner binary differs')
require(len(owner['observations']) == owner['positive_observations'] == 155, 'Owner observation count differs')
require(len(owner['refusals']) == owner['raw_refusals'] == 37, 'Owner refusal count differs')
for row in owner['observations']:
    result, process = row['crosscheck'], row['process']
    native = parse(process['stdout'])
    require(process['returncode'] == 0 and process['stderr'] == '' and row['matched'], 'Bad original native execution')
    require(process['executable_sha256'] == BINARY_SHA and process['stdin_sha256'] == result['core_sha256'], 'Original process identity differs')
    require(native['request'] == result['request'] and native['execution'] == result['rust_report'], 'Original raw stdout differs from retained report')
    require(native['request_sha256'] == result['request_sha256'] == sha256(canonical(result['request'])).hexdigest(), 'Original request binding differs')
    require(result['request']['schema'] == 'hepta.hia.rust-execution-request.v4', 'Wrong original request protocol')
    require(result['rust_report']['schema'] == 'hepta.hia.rust-byte-owner-execution.v2', 'Wrong original inner protocol')
for row in owner['refusals']:
    process = row['process']
    require(row['rejected'] and process['returncode'] != 0 and process['stdout'] == '' and process['stderr'], 'Original refusal not demonstrated')
    require(sha256(row['raw_core_utf8'].encode()).hexdigest() == row['raw_core_sha256'], 'Original refused source differs')
require([row['version'] for row in owner['legacy_compatibility']] == list(range(1, 9)), 'Legacy version coverage differs')
for version in owner['legacy_compatibility']:
    require(version['unchanged'] and len(version['reports']) == 9, 'Legacy report denominator differs')
    for report in version['reports']:
        require(report['shadow_executable_sha256'] == BINARY_SHA, 'Legacy binary differs')
        require(report['rust_report']['schema'] == 'hepta.hia.rust-byte-owner-execution.v1', 'Legacy report schema changed')
        require(report['request_sha256'] == sha256(canonical(report['request'])).hexdigest(), 'Legacy invocation digest differs')

crate_stdout_path = ROOT / 'rust-api-v4-validation/frozen-rust-crate/stdout.log'
crate_stdout = crate_stdout_path.read_text()
harnesses = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', crate_stdout)
require(len(harnesses) == 18 and sum(int(row[0]) for row in harnesses) == 93, 'Rust harness denominator differs')
require(all(all(int(value) == 0 for value in row[1:]) for row in harnesses), 'Rust nonpassing result')

tree = subprocess.run(['git', '-C', str(REPO), 'ls-tree', '-r', '-z', HEAD], capture_output=True, check=True).stdout
index = {}
for item in tree.split(b'\0'):
    if not item:
        continue
    metadata, raw_path = item.split(b'\t', 1)
    mode, typ, blob = metadata.decode().split()
    index[raw_path.decode()] = {'mode': mode, 'type': typ, 'git_blob_sha1': blob}
sources = {}
for path in parse((BASE / 'source-after.json').read_text())['changed_source_files']:
    file = REPO / path
    current = identity(file)
    current['git_mode'] = '100755' if file.stat().st_mode & 0o111 else '100644'
    require(index[path]['type'] == 'blob' and current['git_blob_sha1'] == index[path]['git_blob_sha1']
            and current['git_mode'] == index[path]['mode'], 'Changed file differs from frozen Git bytes/mode')
    sources[path] = current
require(len(sources) == 14, 'Frozen diff denominator differs')
status = subprocess.run(['git', '-C', str(REPO), 'status', '--porcelain'], capture_output=True, check=True).stdout
require(status == b'', 'Source is no longer clean')

static = [
    {'id': 'S01', 'finding': None, 'conclusion': 'One existing checker, Machine and ByteMemory remain; the failure target field changes to an exact Word/Wide sum type.'},
    {'id': 'S02', 'finding': None, 'conclusion': 'Positive canonical hexadecimal with more than 16 digits is mathematically above u64::MAX; exact counter inequality retains the full string and does not use None, truncation, floats or a tick-budget projection.'},
    {'id': 'S03', 'finding': None, 'conclusion': 'Accepted policies retain the full canonical hex in both bound request digest and versioned execution report, including returned, trapped and budget-stopped outcomes.'},
    {'id': 'S04', 'finding': None, 'conclusion': 'The complete 1024-byte policy remains bounded; Python calculates the exact available digit count and rejects oversized integers by bit_length before formatting or opening the executable.'},
    {'id': 'S05', 'finding': None, 'conclusion': 'Rust checks raw policy length before decoding and uses the existing duplicate-key-rejecting decoder; numeric budget fields, canonical hex and exact key set are checked before Machine creation.'},
    {'id': 'S06', 'finding': None, 'conclusion': 'Tuple admission is gated to protocol v4 and copied into the same ordered JSON array; exact scalar types and original nominal/public-entry eligibility remain checked.'},
    {'id': 'S07', 'finding': None, 'conclusion': 'Full-module verification remains on both Python and Rust paths before execution; a tiny execution budget cannot bypass invalid unused declarations.'},
    {'id': 'S08', 'finding': None, 'conclusion': 'v1-v3 retain list-only/u64 domains, their old budgets and numeric/null inner schema. The CLI usage text now lists v4, but valid legacy envelopes are not upgraded.'},
    {'id': 'S09', 'finding': None, 'conclusion': 'Each admitted operation can attempt at most one logical allocation and the existing finite tick ceiling bounds the u64 counter; zero-size and heap checks retain their order.'},
    {'id': 'S10', 'finding': None, 'conclusion': 'No production admission/calling path is switched. Wider Python integer transport, unrestricted API parity, normalization port, general memory/ABI and refinement remain explicitly unqualified.'},
]
review = {'schema': 'hepta.rust-api-v4-independent-review.v1',
    'finished_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': HEAD, 'source_tree': TREE,
    'base_source_commit': '699de39a8e92e0f083df316ecc5333fb3ecf8571',
    'review_ok': True, 'findings': [], 'static_review': static,
    'new_independent_execution_observations': 11, 'new_independent_programs': 2,
    'original_collector_methods': 8, 'original_collector_observations_read_back': 155,
    'original_raw_refusals_read_back': 37, 'original_legacy_reports_read_back': 72,
    'original_rust_tests_from_raw_log': 93, 'original_rust_harness_blocks': 18,
    'original_collector_or_crate_rerun_by_reviewer': False, 'overlapping_counts_summed': False,
    'binary_sha256': BINARY_SHA, 'changed_source_files': sources,
    'inputs': [identity(owner_path), identity(crate_stdout_path), identity(BASE / 'execution-review.json')],
    'source_identity_scope': 'Before/after HEAD, tree, clean Git state and fourteen changed-file byte identities; all fourteen current bytes and executable modes separately matched raw Git blobs. Original collector retains its full source snapshots.',
    'production_authority': 'Python', 'optimization_policy': 'no_change',
    'complete_python_api_parity': False, 'all_P0_P7_closed': False,
    'limits': ['Bounded transport remains at 1024 policy bytes, 8192 scalar arguments and 128 KiB argument bytes.',
               'A finite code review and these observations do not prove full language soundness, production authority or native refinement.',
               'The new observations are independent finite dual executions, not independent model productivity tasks or physical-device measurements.']}
save(BASE / 'review-summary.json', review)
print(json.dumps({'review_ok': True, 'static_items': len(static), 'independent_native_processes': 11,
                  'original_observations_read_back': 155, 'original_refusals_read_back': 37,
                  'findings': []}))
