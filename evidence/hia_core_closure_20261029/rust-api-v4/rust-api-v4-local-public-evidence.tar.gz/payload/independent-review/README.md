# Rust bound-v4 独立审查

**审查通过，没有剩余 finding。** 冻结实现为本地提交 `bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7`，tree `04b70dccc157af470aa2b5bdeb74e6f88dbff5bf`，直接父提交为 `699de39a8e92e0f083df316ecc5333fb3ecf8571`。公开发布若采用另一个 commit，必须另外证明 tree 相同；本审查不改标为另一份源码上的执行。

固定实际 Rust binary 的 SHA-256 为 `5c39bec4def3b274487c4dce5f37475d7c2e0ac0c1e14634f5fa906f87c15abc`。审查者没有修改生产源码、重新编译 Cargo 或重跑实现者的完整 corpus。

## 独立执行的新增边界

实际执行 **11 次** Python/Rust 对照，使用两个自行构造的完整 Core 程序。每条记录保存 canonical Core、实际 native 参数/stdout/stderr/退出码、binary/stdin 身份、完整请求及两份执行报告。

| 独立观察 | 实际次数 | 核验结果 |
| --- | ---: | --- |
| 混合参数与多返回值 | 4 | `u64` 大于 `2**53`、`i64` 最小值、bool、unit 及 `u64::MAX` 经过内部调用和返回值重排，数值与次序精确；对应 list/tuple 的请求和 digest 完全相同 |
| 两个内部 allocation 调用 | 4 | Word 索引 2 与一个低位也是 2 的 193-bit Wide 索引，分别走正常返回和显式 user trap；第二次分配只在 Word 对照中失败，Wide 未被截断或映射成较小索引 |
| 第二个内部调用中的 step stop | 3 | 停止于第 11 tick，两个 allocation attempts 和一个仍存活的 owner 保留；Wide 保留 13 bytes，Word 2 对照保留空 owner，完整 hex 在 stopped report 中不丢失 |

所用 Wide 值为 `(1 << 192) + (1 << 65) + 2`。所有观察均检查请求中的精确 hex、完整 request digest、内层 v2 execution report schema、每次实际 binary 和 Core 字节身份。正常返回与 user trap 均确认已完成的两个调用没有遗留 owner；budget stop 的未清资源按原合同保留，未称为取消或 unwind 清理。

11 次是新增有限执行观察，不是 11 个新增语言测试方法，也不与实现者的 corpus 或完整 Rust crate 数量相加。原始资料在 `observations/`、`programs/`、`execution-review.json` 与实际脚本/日志中。

## 静态审查与既有原件复核

`review-summary.json` 记录十项静态检查：

- 同一个 checker、显式帧 `Machine` 和 `ByteMemory` 保留；没有新的 evaluator、Core opcode 或生产准入路径。
- `Word(u64)` 保存精确字值；`Wide(String)` 保存全部 canonical hex。超过 16 个非前导零 hex digits 的正整数严格大于任何 u64 counter，比较结果是精确整数不等关系，未改成 `None`、float、clamp 或预算投影。
- Python 先依据完整 1024-byte policy 的实际剩余空间比较 `bit_length`，再构造 hex；Rust 先拒绝超长原始 policy，然后使用原有的重复键拒绝 decoder 和精确字段检查。
- tuple 仅在新 v4 入口接受，转换为同一个有序 JSON array；原 exact scalar 类型和 nominal/public-entry 资格继续执行。
- 两端完整模块准入仍在执行之前。极小 tick budget 或 Wide index 不隐藏非法 unused function。
- v1/v2/v3 继续使用原 list/u64 接受域、预算、numeric/null report 和旧 schema。CLI usage 文本增加 v4 名称，不等于升级旧合法请求的合同。
- v4 的 request/envelope schema 与内层 execution-v2 schema 明确分版；完整 hex 在正常、trap 和 budget-stop 中都受请求绑定。
- 原 allocation 顺序保留：zero-size 不消耗 attempt，object-size/heap 检查在 attempt 之前；当前有限 tick 合同使 u64 attempt counter 不会溢出。

另外只读复核了实现者的原始冻结材料：8 个方法、155 个实际 v4 observations、37 个 raw refusals，以及 primitive v1–v8 的 72 份 legacy 对照报告。逐条比较原 stdout 与保存的 request/execution，并重新计算 request digest、检查实际 binary/Core 身份及拒绝退出。此处没有再次执行这 155/37/72 组记录。

原 Rust stdout 的 18 个 harness summary 合计 93 tests，failed/ignored/measured/filtered 全为零。该完整 crate 是实现者原运行，未被本审查重跑或加入新增 11 次分母。

## 源码和边界

本次独立执行前后核对 HEAD、tree、clean Git state 和全部 14 个变更文件的实际字节身份；结束时还将每个变更文件的原始 Git blob 与执行位逐项核对。实现者的 collector 另保留其完整源码 before/after 快照。审查不伪造本地未采集的历史逐文件日志。

v4 仍有 **1024-byte policy、8192 个 scalar arguments、128 KiB arguments** 的传输边界。Python 能接受的足够大正整数仍会在这个有限接口拒绝；nominal normalization 仍由 Python 执行。因此，完整 Python API parity 和 Rust 生产权威切换都没有关闭。

Python 仍为生产权威，优化政策仍为 `no_change`。所有 P0–P7 严格阶段保留 OPEN；本审查不提供全语言健全性、完整 backend refinement、一般 ABI、独立真实模型效率或物理设备资格。
