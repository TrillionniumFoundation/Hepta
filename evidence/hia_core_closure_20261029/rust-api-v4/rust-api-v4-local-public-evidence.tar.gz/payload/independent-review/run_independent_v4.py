from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / 'hepta-api'
COMMIT = 'bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7'
TREE = '04b70dccc157af470aa2b5bdeb74e6f88dbff5bf'
BINARY = BASE.parent / 'rust-api-target/debug/hia-core-shadow'
BINARY_SHA = '5c39bec4def3b274487c4dce5f37475d7c2e0ac0c1e14634f5fa906f87c15abc'
WIDE = (1 << 192) + (1 << 65) + 2
sys.path.insert(0, str(REPO))
from hepta import hia_rust_crosscheck as crosscheck
from hepta.hia_program import verify_program

def require(condition, reason):
    if not condition:
        raise AssertionError(reason)

def save(path, value):
    with path.open('x') as output:
        output.write(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n')

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def git(*args):
    run = subprocess.run(['git', '-C', str(REPO), *args], capture_output=True, check=True)
    return run.stdout

def source_state():
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('status', '--porcelain').decode()
    require((head, tree, status) == (COMMIT, TREE, ''), 'Frozen source differs')
    paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT).decode().splitlines()
    selected = {path: {'bytes': (REPO / path).stat().st_size,
                       'sha256': sha256((REPO / path).read_bytes()).hexdigest()}
                for path in paths}
    return {'head': head, 'tree': tree, 'status': status, 'changed_source_files': selected}

def p(name, typ):
    return {'name': name, 'type': typ}

def op(name, args=(), outputs=(), **attrs):
    return {'op': name, 'args': list(args), 'out': [p(*item) for item in outputs], 'attrs': attrs}

def block(name, params, ops, term):
    return {'id': name, 'params': [p(*item) for item in params], 'ops': ops, 'term': term}

def function(name, params, returns, effects, blocks):
    return {'name': name, 'params': [p(*item) for item in params], 'returns': returns,
            'effects': effects, 'entry': blocks[0]['id'], 'blocks': blocks}

def ret(*names):
    return {'op': 'ret', 'values': list(names)}

def document(*functions):
    return {'schema': 'hepta.hia.program.v1', 'module': 'independent_api_v4', 'functions': list(functions)}

def heterogeneous_program():
    params = [('wide', 'u64'), ('signed', 'i64'), ('flag', 'bool'), ('nil', 'unit'), ('tail', 'u64')]
    returns = ['u64', 'u64', 'i64', 'bool', 'unit']
    relay = function('rotate', params, returns, [], [block('entry', params, [], ret('tail', 'wide', 'signed', 'flag', 'nil'))])
    outputs = list(zip(('a', 'b', 'c', 'd', 'e'), returns))
    main = function('ordered', params, returns, [], [block('entry', params,
        [op('call', [name for name, _ in params], outputs, function='rotate')], ret('a', 'b', 'c', 'd', 'e'))])
    return document(relay, main)

def allocating_program():
    helper_params = [('size', 'usize')]
    helper = function('allocate_once', helper_params, ['usize'], ['alloc'], [block('entry', helper_params, [
        op('buffer.try_new', ['size'], [('owner', 'buffer'), ('ok', 'bool')]),
        op('buffer.len', ['owner'], [('length', 'usize')]),
        op('owner.drop', ['owner']),
    ], ret('length'))])
    params = [('first', 'usize'), ('second', 'usize'), ('stop', 'bool')]
    main = function('call_pair', params, ['usize'], ['alloc', 'trap'], [
        block('entry', params, [
            op('call', ['first'], [('left', 'usize')], function='allocate_once'),
            op('call', ['second'], [('right', 'usize')], function='allocate_once'),
            op('int.add.wrap', ['left', 'right'], [('sum', 'usize')]),
        ], {'op': 'branch', 'cond': 'stop', 'then': {'target': 'trap', 'args': []},
            'else': {'target': 'done', 'args': ['sum']}}),
        block('done', [('total', 'usize')], [], ret('total')),
        block('trap', [], [], {'op': 'trap', 'code': 'user'}),
    ])
    return document(helper, main)

started = datetime.now(timezone.utc).isoformat()
before = source_state()
require(sha256(BINARY.read_bytes()).hexdigest() == BINARY_SHA, 'Binary differs before review')
(BASE / 'observations').mkdir(exist_ok=False)
(BASE / 'programs').mkdir(exist_ok=False)
save(BASE / 'source-before.json', before)
(BASE / 'frozen-source.patch').write_bytes(git('diff', '--binary', COMMIT + '^', COMMIT))
records = []
programs = {}

def observe(name, source, entry, arguments, *, fail=WIDE, steps=100):
    checked = verify_program(source)
    if checked.sha256 not in programs:
        path = BASE / 'programs' / (checked.sha256 + '.json')
        path.write_bytes(checked.canonical_bytes)
        programs[checked.sha256] = str(path.relative_to(BASE))
    calls = []
    original = crosscheck._run_pinned_shadow
    def captured(binary, argv, stdin, timeout, **kwargs):
        stdout, stderr, code = original(binary, argv, stdin, timeout, **kwargs)
        calls.append({'argv_after_pinned_executable': argv,
                      'binary_sha256': sha256(binary).hexdigest(), 'stdin_sha256': sha256(stdin).hexdigest(),
                      'returncode': code, 'stdout': stdout.decode(), 'stderr': stderr.decode()})
        return stdout, stderr, code
    with patch.object(crosscheck, '_run_pinned_shadow', captured):
        result = crosscheck.crosscheck_rust_execution_v4(source, entry, arguments, BINARY,
            executable_sha256=BINARY_SHA, max_steps=steps, max_heap_bytes=64,
            max_call_depth=4, allocation_fail_at=fail)
    record = {'name': name, 'argument_container': type(arguments).__name__, 'crosscheck': result, 'processes': calls}
    # Retain the actual observation before checking the independent expectations.
    save(BASE / 'observations' / (name + '.json'), record)
    require(len(calls) == 1, 'Each observation must execute exactly one pinned native process')
    require(calls[0]['binary_sha256'] == BINARY_SHA and calls[0]['stdin_sha256'] == checked.sha256,
            'Actual process identity differs')
    require(calls[0]['returncode'] == 0 and calls[0]['stderr'] == '', 'Native execution failed or emitted diagnostics')
    require(result['request_sha256'] == sha256(canonical(result['request'])).hexdigest(), 'Request digest differs')
    require(result['request']['arguments'] == list(arguments), 'Invocation argument order differs')
    require(result['request']['policy']['allocation_fail_at'] == hex(fail), 'Requested integer encoding differs')
    require(result['rust_report']['allocation_fail_at'] == hex(fail), 'Report lost the exact failure index')
    require(result['rust_report']['schema'] == 'hepta.hia.rust-byte-owner-execution.v2', 'Wrong inner report version')
    require(result['claims']['rust_is_production_admission_authority'] is False, 'Authority was promoted')
    records.append(record)
    return result

heterogeneous = heterogeneous_program()
for flag in (False, True):
    values = [(1 << 53) + 1, -(1 << 63), flag, None, (1 << 64) - 1]
    expected = [(1 << 64) - 1, (1 << 53) + 1, -(1 << 63), flag, None]
    listed = observe('heterogeneous-%s-list' % str(flag).lower(), heterogeneous, 'ordered', values)
    tupled = observe('heterogeneous-%s-tuple' % str(flag).lower(), heterogeneous, 'ordered', tuple(values))
    for result in (listed, tupled):
        require(result['rust_report']['status'] == 'returned' and result['rust_report']['values'] == expected,
                'Heterogeneous multi-result ordering or exact integer value differs')
        require(result['rust_report']['resources']['allocation_attempts'] == 0, 'Pure program allocated language memory')
    require(listed['request'] == tupled['request'] and listed['request_sha256'] == tupled['request_sha256'],
            'Equivalent ordered list/tuple invocations differ')

allocated = allocating_program()
for fail, label in ((2, 'word-two'), (WIDE, 'wide-low-two')):
    for stop in (False, True):
        result = observe(label + ('-trap' if stop else '-return'), allocated, 'call_pair', (11, 13, stop), fail=fail)
        report = result['rust_report']
        require(report['status'] == ('trapped' if stop else 'returned'), 'Internal-call outcome differs')
        if stop:
            require(report['error'] == {'code': 'user'}, 'Explicit user trap differs')
        else:
            require(report['values'] == ([11] if fail == 2 else [24]), 'Failure index was narrowed or allocation order changed')
        memory = report['resources']
        require(memory['allocation_attempts'] == 2 and memory['live_bytes'] == 0 and memory['live_owners'] == 0,
                'Call pair attempts or cleanup ledger differs')
        require(memory['allocations'] == (1 if fail == 2 else 2), 'Wide target aliased a finite allocation attempt')

for fail, label, args in ((WIDE, 'wide-stop-list', [11, 13, False]),
                           (WIDE, 'wide-stop-tuple', (11, 13, False)),
                           (2, 'word-two-stop', (11, 13, False))):
    report = observe(label, allocated, 'call_pair', args, fail=fail, steps=10)['rust_report']
    require(report['status'] == 'budget_exceeded' and report['error'] == {'code': 'steps'} and report['steps'] == 11,
            'Stopped prefix tick/status differs')
    memory = report['resources']
    require(memory['allocation_attempts'] == 2 and memory['live_owners'] == 1,
            'Second internal call did not preserve its stopped owner ledger')
    require(memory['live_bytes'] == (0 if fail == 2 else 13), 'Stopped owner bytes or failure injection differs')
    require(memory['allocations'] == (1 if fail == 2 else 2) and memory['frees'] == 1,
            'Stopped allocation/free history differs')

after = source_state()
require(before == after, 'Source changed during independent executions')
require(sha256(BINARY.read_bytes()).hexdigest() == BINARY_SHA, 'Binary changed during review')
require(len(records) == 11, 'Independent execution denominator differs')
save(BASE / 'source-after.json', after)
summary = {'schema': 'hepta.rust-api-v4-independent-execution-review.v1',
    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'source_commit': COMMIT, 'source_tree': TREE, 'source_unchanged': True,
    'binary_path': str(BINARY), 'binary_sha256': BINARY_SHA, 'binary_unchanged': True,
    'python': sys.version, 'ok': True, 'findings': [],
    'native_process_invocations': len(records), 'distinct_programs': len(programs),
    'observation_counts': {'heterogeneous_ordered_list_tuple_multi_result': 4,
        'internal_allocating_calls_return_and_user_trap': 4, 'internal_call_stopped_prefix': 3},
    'wide_failure_index_hex': hex(WIDE), 'wide_failure_index_bits': WIDE.bit_length(),
    'word_failure_control': 2, 'programs_by_sha256': programs,
    'language_test_methods_claimed': 0, 'existing_collector_observations_repeated': False,
    'cargo_build_performed': False, 'source_edits_performed': False,
    'production_authority': 'Python', 'optimization_policy': 'no_change',
    'all_P0_P7_closed': False, 'complete_python_api_parity': False,
    'scope': 'Independent finite executions on the frozen v4 source. These do not replace full integration, independent model tasks, physical devices or refinement proofs.'}
save(BASE / 'execution-review.json', summary)
print(json.dumps(summary, ensure_ascii=False))
