from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys
import time

CHECKOUT = Path('/workspace/scratch/b484d4086829/hepta-composition-public')
FOLDER = Path('/workspace/scratch/b484d4086829/composite-v4-public-evidence-99cf106')
PUBLIC_HEAD = '99cf106586509b08bb2b9890ed29cf042336d69e'
TREE = 'c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2'
sys.path.insert(0, str(CHECKOUT))
from tools.qualify_hia_integrated import _source_state

output = FOLDER / 'execution'
output.mkdir(exist_ok=False)
before = _source_state()
if before['head'] != PUBLIC_HEAD or before['status']:
    raise ValueError('exact clean public source required')
if subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=CHECKOUT).decode().strip() != TREE:
    raise ValueError('exported public tree required')
env = dict(os.environ)
env.update({
    'PATH': '/workspace/scratch/b484d4086829/toolchains/rust-1.90.0/bin:/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/llvm-20/bin:' + env['PATH'],
    'RUSTC': '/workspace/scratch/b484d4086829/toolchains/rust-1.90.0/bin/rustc',
    'CARGO_HOME': '/workspace/scratch/b484d4086829/toolchains/cargo-home',
    'CARGO_TARGET_DIR': '/workspace/scratch/b484d4086829/rust-composition-public-target',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'CLANG': '/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/llvm-20/bin/clang',
    'LD_LIBRARY_PATH': '/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/x86_64-linux-gnu:/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/llvm-20/lib',
})
export = Path('/workspace/scratch/b484d4086829/composite-v4-publication-export-e21d672')
provided_script = (export / 'rerun-public.sh').read_bytes()
legacy_code = provided_script.split(b"<<'PY'\n", 1)[1].split(b'\nPY\n', 1)[0] + b'\n'
commands = [
    ('composition', [sys.executable, 'tools/qualify_hia_composite_returned_loans.py',
        '--expected-head', PUBLIC_HEAD, '--output-directory', str(output / 'composition')], None),
    ('rust-api-v4', [sys.executable, 'tools/qualify_hia_rust_api_v4.py',
        '--expected-head', PUBLIC_HEAD, '--output-directory', str(output / 'rust-api-v4')], None),
    ('legacy-regression', [sys.executable, '-', PUBLIC_HEAD, str(output)], legacy_code),
    ('example-verify', [sys.executable, '-m', 'hepta', 'hia', 'verify',
        'examples/hia_program/composite_returned_loans_v4.hia'], None),
    ('example-run', [sys.executable, '-m', 'hepta', 'hia', 'run',
        'examples/hia_program/composite_returned_loans_v4.hia', '--function', 'partial_result',
        '--arguments', '[37]'], None),
]
selected_env = {name: env[name] for name in ('PATH', 'RUSTC', 'CARGO_HOME', 'CARGO_TARGET_DIR',
    'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'CLANG', 'LD_LIBRARY_PATH')}
processes = []
for index, (label, argv, stdin) in enumerate(commands):
    started = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    try:
        process = subprocess.run(argv, cwd=CHECKOUT, env=env, input=stdin,
                                 capture_output=True, timeout=600)
        record = {'returncode': process.returncode, 'stdout': process.stdout.decode(),
                  'stderr': process.stderr.decode(), 'timeout': False}
    except subprocess.TimeoutExpired as exc:
        record = {'returncode': None, 'stdout': (exc.stdout or b'').decode(errors='replace'),
                  'stderr': (exc.stderr or b'').decode(errors='replace'), 'timeout': True}
    record.update({'label': label, 'argv': argv, 'cwd': str(CHECKOUT),
        'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - tick, 'environment': selected_env,
        'stdin_utf8': None if stdin is None else stdin.decode(),
        'stdin_sha256': None if stdin is None else sha256(stdin).hexdigest()})
    (FOLDER / f'process-{index}-{label}.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    (FOLDER / f'process-{index}-{label}.stdout').write_text(record['stdout'])
    (FOLDER / f'process-{index}-{label}.stderr').write_text(record['stderr'])
    if label.startswith('example-'):
        (output / (label + '.json')).write_text(record['stdout'])
    processes.append(record)
    print(json.dumps({'label': label, 'returncode': record['returncode'],
                      'elapsed_seconds': record['elapsed_seconds'],
                      'stdout_summary': record['stdout'][:800]}), flush=True)
    if record['returncode'] != 0:
        break
after = _source_state()
ok = len(processes) == 5 and all(row['returncode'] == 0 for row in processes) and before == after
summary = {'schema': 'hepta.hia.composite-v4.public-execution-processes.v1',
    'public_commit': PUBLIC_HEAD, 'public_tree': TREE, 'source_before': before,
    'source_after': after, 'source_unchanged': before == after, 'ok': bool(ok),
    'runner_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
    'supplied_public_rerun_script_sha256': sha256(provided_script).hexdigest(),
    'processes': processes,
    'limits': ['13 composition, 8 stacked API and 98 legacy methods are distinct overlapping scopes, not additive language completeness.',
               'Existing local receipts keep their e21 commit identity; these are fresh 99cf public executions.',
               'Full 116-method safety qualification and integrated release have not been run by this process wrapper.']}
(FOLDER / 'public-execution-processes.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
raise SystemExit(0 if ok else 1)
