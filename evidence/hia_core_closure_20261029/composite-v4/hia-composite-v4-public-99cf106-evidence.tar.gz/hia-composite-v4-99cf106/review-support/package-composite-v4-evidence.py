from datetime import datetime, timezone
from hashlib import sha1, sha256
from pathlib import Path
import gzip
import io
import json
import shutil
import stat
import tarfile

BASE = Path('/workspace/scratch/b484d4086829')
STAGE = BASE / 'composite-v4-combined-evidence-99cf106'
ARCHIVE = BASE / 'hia-composite-v4-public-99cf106-evidence.tar.gz'
PUBLIC = '99cf106586509b08bb2b9890ed29cf042336d69e'
LOCAL = 'e21d672eb1bc588e248f72b0217b922671a869a5'
TREE = 'c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2'
PEER_ARCHIVE = BASE / 'core-composition-independent-review/composite-v4-independent-review-e21d672.tar.gz'
PEER_DIGEST = '6cd2bd58ae7a7546b5d7e5f80e4ce77cec75cc0f8e83b8ff0150546a552b0fb8'


def checksum(path):
    return sha256(path.read_bytes()).hexdigest()


def inventory(folder):
    result = {}
    for path in sorted(folder.rglob('*')):
        if path.is_symlink():
            raise ValueError('symlink outside evidence file scope: ' + str(path))
        if path.is_file():
            result[str(path.relative_to(folder))] = {
                'sha256': checksum(path), 'bytes': path.stat().st_size,
                'mode': oct(stat.S_IMODE(path.stat().st_mode)),
            }
        elif not path.is_dir():
            raise ValueError('nonregular evidence member: ' + str(path))
    return result


assert not STAGE.exists() and not ARCHIVE.exists()
STAGE.mkdir()
source_bindings = {}
for source_name, destination in (
    ('composite-v4-qualification-e21d672', 'local/composition'),
    ('composite-v4-legacy-regression-e21d672', 'local/legacy-regression'),
    ('composite-v4-public-evidence-99cf106', 'public'),
    ('composite-v4-publication-export-e21d672', 'source-export'),
    ('composition-development-20261029', 'development'),
):
    source = BASE / source_name
    before = inventory(source)
    shutil.copytree(source, STAGE / destination)
    after, copied = inventory(source), inventory(STAGE / destination)
    assert before == after == copied
    source_bindings[source_name] = {'destination': destination, 'before_after_and_copy_equal': True,
                                  'files': len(before), 'bytes': sum(row['bytes'] for row in before.values())}

peer = STAGE / 'peer-review'
peer.mkdir()
assert PEER_ARCHIVE.stat().st_size == 2622021 and checksum(PEER_ARCHIVE) == PEER_DIGEST
shutil.copy2(PEER_ARCHIVE, peer / PEER_ARCHIVE.name)
assert checksum(peer / PEER_ARCHIVE.name) == PEER_DIGEST
for name in ('review.json', 'public-equivalent-tree-binding.json', 'README.md'):
    source = PEER_ARCHIVE.parent / name
    if source.is_file():
        shutil.copy2(source, peer / name)
        assert checksum(source) == checksum(peer / name)
review = json.loads((peer / 'review.json').read_bytes())
assert review['ok'] is True and not review['blocking_defects_found']

publication = STAGE / 'source-publication'
publication.mkdir()
original_receipt = BASE / 'progress-publication-20261029/composite-v4-source-publication.json'
shutil.copy2(original_receipt, publication / original_receipt.name)
assert checksum(original_receipt) == checksum(publication / original_receipt.name)
publication_receipt = json.loads(original_receipt.read_bytes())
assert publication_receipt['public_commit'] == PUBLIC
assert publication_receipt['public_execution_performed_at_this_snapshot'] is False

local = json.loads((STAGE / 'local/composition/qualification.json').read_bytes())
public = json.loads((STAGE / 'public/execution/composition/qualification.json').read_bytes())
api = json.loads((STAGE / 'public/execution/rust-api-v4/qualification.json').read_bytes())
processes = json.loads((STAGE / 'public/public-execution-processes.json').read_bytes())
assert local['ok'] and public['ok'] and api['ok'] and processes['ok']
assert local['expected_head'] == LOCAL and public['expected_head'] == PUBLIC and api['expected_head'] == PUBLIC
assert local['tests']['run'] == public['tests']['run'] == 13 and api['tests']['run'] == 8
assert local['rust_observations'] == public['rust_observations'] == 153
assert local['native_calls'] == public['native_calls'] == 31

executables = STAGE / 'executables'
executables.mkdir()
binary_bindings = []
for label, report in (('local-composition', local), ('public-composition', public), ('public-rust-api-v4', api)):
    binary = Path(report['binary']['path'])
    identity = report['binary']['sha256_before']
    assert identity == report['binary']['sha256_after'] == checksum(binary)
    destination = executables / ('hia-core-shadow-' + identity)
    if not destination.exists():
        shutil.copy2(binary, destination)
    assert checksum(destination) == identity
    binary_bindings.append({'run': label, 'original_path': str(binary),
        'retained_path': str(destination.relative_to(STAGE)), 'sha256': identity,
        'bytes': destination.stat().st_size})

for report in (local, public):
    for row in report['native']:
        artifact = Path(row['build']['output'])
        assert checksum(artifact) == row['build']['artifact_sha256']

support = STAGE / 'review-support'
support.mkdir()
pr = (STAGE / 'source-export/PR_BODY.md').read_text()
pr = pr.replace(
    'Frozen local component: `e21d672eb1bc588e248f72b0217b922671a869a5`.\nExact source tree: `c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2`.',
    'Freshly executed public component: `99cf106586509b08bb2b9890ed29cf042336d69e`, parent `adbe4a1168a84d0696749ef54f933994b5dc554c`.\nExact source tree: `c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2`.\nThe separately retained local component is `e21d672eb1bc588e248f72b0217b922671a869a5`; its reports keep that identity.')
pr = pr.replace(
    'The new public commit requires an exact-head rerun using the supplied commands.\nThe local observations above retain their local commit identity; tree equality\nalone does not rename them as observations of a new public commit.',
    'A new, clean detached checkout of public `99cf106` was fetched and independently compared against all 14 exported blobs and modes. Its fresh exact-head 13-method composition and 98-method legacy runs passed, and the stacked Rust API v4 qualification passed 8/8 with 155 actual comparisons, 37 raw refusals and eight legacy-version sets. Per-command argv, UTC start/end, elapsed time, stdout and stderr are retained. The CLI example returned 37 with balanced owners and loans. These overlapping denominators remain separate.\n\nIndependent review at original local `e21d672` found no blocking defect within its finite scope. Its distinct zero-width/expanded partial-result, two loan-origin, mutual-recursion, CFG-origin-refusal and allocator-precondition controls remain identified as independent local observations. The original public-source publication receipt retains its historical `public_execution_performed_at_this_snapshot=false`; later public execution receipts record the new successful runs.')
(support / 'PR_BODY_PUBLIC_VERIFIED.md').write_text(pr)
shutil.copy2(Path(__file__), support / 'package-composite-v4-evidence.py')

readme = '''# Composite v4: public source and finite execution evidence

Public commit: `99cf106586509b08bb2b9890ed29cf042336d69e`.
Public parent: `adbe4a1168a84d0696749ef54f933994b5dc554c`.
Exact tree: `c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2`.
Local component: `e21d672eb1bc588e248f72b0217b922671a869a5`.
Local parent: `bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7`.
Both parent trees: `04b70dccc157af470aa2b5bdeb74e6f88dbff5bf`.

## Included evidence

- `public/`: fresh exact-public source comparison of all 14 changed raw blobs,
  modes and SHA256 values; per-command argv, environment whitelist, UTC time,
  elapsed time, stdout/stderr; actual public composition 13/13, Rust API v4
  8/8, legacy regression 98/98 and the CLI example returning 37.
- `local/`: original exact-local composition 13/13 and legacy 98/98 receipts.
  Local source identities are unchanged and are not relabeled as public runs.
- Both composition receipts have 153 actual Rust comparisons, four raw Rust
  refusals and 31 native calls. The public stacked API receipt independently
  retains 155 comparisons, 37 raw refusals and eight legacy-version sets.
  Method and observation counts describe separate overlapping scopes.
- `peer-review/`: the immutable independent review archive plus readable review
  and public-tree mapping. Independent executions remain bound to local e21:
  two Python/two Rust/two LLVM mixed-result/mutual-recursion cases, four Python
  refusals, one raw Rust refusal, and four actual allocator calls on two
  distinct failure indices (two initial observations plus two identity-bound
  replays). This is a finite review, not a second full release.
- `source-export/`: 14 changed raw UTF-8 files, exact modes and old/new Git blob
  IDs, SHA256 identities, full-index patch and an independently reconstructed
  final tree. Original PR draft and public-rerun script are retained unchanged.
- `source-publication/`: original public-source receipt. Its false execution
  flag is explicitly a historical snapshot taken before the new public runs.
- `development/`: preliminary test records and the seven-byte observer
  investigation. The original diagnostic is a labeled copy from the tool
  transcript; reproduction.json contains new actual process observations.
  The observer classifies only 1-byte payloads and 24-byte nodes. Size7 caused
  unknown_sizes=1 while every result/allocation/free/live/peak counter matched
  Python. The allocator case now uses the declared size1 fixture; nine-module
  native scalar calls retain sizes1,7,19. No backend change hid a discrepancy.
- `executables/`: actual Rust executable bytes, bound by the original local and
  public receipts. Identical executable bytes are stored once; run identities
  and compilation source identities remain separate in the manifest.
- `review-support/PR_BODY_PUBLIC_VERIFIED.md`: ready public PR description with
  the new execution observations. It does not mutate the earlier export.

The reviewed safety registry selects 116 unique methods, retaining all previous
103 and adding 13. This package does not claim that the full 116-method safety
gate or integrated release was executed. Current LLVM20 execution used the
isolated Ubuntu20.1.2 package build on a Debian13/GCC14 host, distinct from prior
Ubuntu-host qualification. Raw reports retain compiler, Rust and source hashes.

This increment closes the finite nominal partial-record/primitive returned-loan
composition gap. Python remains production admission authority; optimization
policy is no_change. All historical routes, general memory/provenance, arbitrary
recursive ADTs, complete partial initialization, escaping stored loans,
external lifetimes, full cancellation/error cleanup, callback/reentrant/thread
ABI, process-memory/performance/device and refinement/soundness claims remain
outside this finite qualification. Whole P0/P1/P2 and P0–P7 closure is false.
'''
(STAGE / 'README.md').write_text(readme)
members = inventory(STAGE)
manifest = {'schema': 'hepta.hia.composite-v4.combined-evidence.v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'public_commit': PUBLIC, 'local_commit': LOCAL, 'source_tree': TREE,
    'source_inputs_copied_without_drift': source_bindings,
    'peer_archive': {'path': 'peer-review/' + PEER_ARCHIVE.name, 'sha256': PEER_DIGEST,
                     'bytes': PEER_ARCHIVE.stat().st_size, 'original_execution_commit': LOCAL},
    'rust_binary_bindings': binary_bindings,
    'historical_source_receipt_execution_flag_value': False,
    'historical_source_receipt_bytes_preserved': True,
    'fresh_public_execution_receipts_passed': True,
    'public_method_denominators': {'composition': 13, 'stacked_rust_api_v4': 8, 'legacy_regression': 98},
    'denominators_are_separate_overlapping_scopes': True,
    'safety_methods_selected': 116, 'full_116_safety_executed': False,
    'full_integrated_release_executed': False,
    'claims': {'finite_partial_returned_loan_composition_observed': True,
               'full_P0_closed': False, 'full_P1_closed': False, 'full_P2_closed': False,
               'full_P0_P7_closed': False, 'rust_production_authority': False,
               'whole_language_soundness_proved': False, 'backend_refinement_proved': False},
    'files': members}
(STAGE / 'manifest.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
(STAGE / 'SHA256SUMS').write_text(''.join(row['sha256'] + '  ' + name + '\n' for name, row in members.items()))
pack_members = inventory(STAGE)
with ARCHIVE.open('xb') as target:
    with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for name, row in pack_members.items():
                path = STAGE / name
                data = path.read_bytes()
                assert sha256(data).hexdigest() == row['sha256']
                info = tarfile.TarInfo('hia-composite-v4-99cf106/' + name)
                info.size = len(data)
                info.mode = int(row['mode'], 8)
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(data))

uncompressed = gzip.decompress(ARCHIVE.read_bytes())
with tarfile.open(fileobj=io.BytesIO(uncompressed), mode='r:') as archive:
    actual_members = archive.getmembers()
    assert len(actual_members) == len(pack_members)
    for member in actual_members:
        assert member.isfile()
        name = member.name.removeprefix('hia-composite-v4-99cf106/')
        expected = pack_members[name]
        data = archive.extractfile(member).read()
        assert len(data) == expected['bytes'] and sha256(data).hexdigest() == expected['sha256']
        assert member.mode == int(expected['mode'], 8)

assert ARCHIVE.stat().st_size < 12 * 1024 * 1024
raw = ARCHIVE.read_bytes()
receipt = {'schema': 'hepta.hia.composite-v4.combined-evidence-archive.v1',
    'archive': str(ARCHIVE), 'sha256': sha256(raw).hexdigest(),
    'git_blob_sha1': sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
    'bytes': len(raw), 'members': len(pack_members), 'all_members_read_back': True,
    'all_member_hashes_and_modes_match': True, 'gzip_crc_verified': True,
    'manifest_sha256': checksum(STAGE / 'manifest.json'),
    'public_commit': PUBLIC, 'local_commit': LOCAL, 'source_tree': TREE,
    'no_source_edits': True, 'no_github_writes_by_packager': True}
(BASE / 'hia-composite-v4-public-99cf106-evidence.receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(receipt, sort_keys=True))
