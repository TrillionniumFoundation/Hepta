# Composite v4 独立复核

**结论：在本次有限审查范围内，没有发现需要阻止该增量的缺陷；独立控制均通过。** 本结论不代表全语言无缺陷、健全性或后端 refinement 证明。P0–P7 的广义关闭条件仍然开放。

审查的精确身份：

```text
commit e21d672eb1bc588e248f72b0217b922671a869a5
tree   c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2
parent bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7
```

独立复核未修改源码、工具链或 GitHub 状态。执行前后，全部 **4,393 个已跟踪文件、281,738,139 字节**的 Git blob 身份、SHA-256、文件模式均与冻结提交一致，工作区状态为空。记录见 `source-binding/source-before.json`、`source-after.json`。审查补丁及原始 commit 对象也保留在该目录。

随后单独读取了已抓取的公开工作区，其提交具有同一个 `c2afb20...` Git tree；精确公开提交及原始对象见 `public-equivalent-tree-binding.json`。这是源码树相等的映射，本次原始执行身份仍然是上述 `e21d672...`，未改写为公开提交号。

## 源码审查结论

| 审查对象 | 结论与依据 |
| --- | --- |
| 名义返回位置与展开 | `return_loans` 在展开前按名义结果检查长度；非借用结果只能为 null。展开后，每个实际 primitive 槽位继承对应的 null 或来源，部分状态的私有 owner token 也在该规则内。 |
| 原始借用形参 | 来源必须是原始、primitive 类型的 `readbuf` / `mutbuf` 形参；`mutbuf` 结果要求可变形参。primitive 名称在展开中保留；名义形参、字段路径和生成名称不能变成合法来源。 |
| 部分记录与借用 | 在筛选已初始化字段之前检查完整基类型是否包含存储借用。借用的是原始字段的 primitive capability，最终 Core 检查仍拒绝借用期间的 owner 移动或提前结束父借用。 |
| CFG 与递归 | Core 边转移同时保留来源和权限；汇合时要求一致。所有函数签名先建立，函数体分别核验，递归调用没有获得跳过来源检查的路径。 |
| 旧版本与畸形输入 | 只有显式 composite v4 进入 primitive v8；v1/v2/v3 保留原目标。v3 的 `return_loans` 仍违反严格字段集合；对象形式的来源被正常拒绝。 |
| 公开边界 | 原始非 primitive 签名不能因展开而获得公开 ABI。独立原生模块的动态导出只有标量入口 `independent_mix`。 |

核心审查位置为 `hepta/hia_program_composite.py` 的类型解析、部分状态、函数合同检查和返回展开，以及 `hepta/hia_program.py` 的函数接口、借用、CFG 转移和返回验证。`hia_schema.py`、`hia_routes.py` 的版本变化与显式路线相符。

## 独立正例：扩大和缩小结果宽度，同时保留不同来源

本次独立编写 JSON 构造器，没有导入新增测试模块的 fixture builder。一个程序同时组合：

- 零宽的 `Empty` 名义结果；
- 三槽部分状态 `Meta`：一个私有 owner token，加 `usize` 和 `u8`；
- 来自右侧可变形参的共享借用，以及来自左侧形参的可变借用；
- 保留在调用者部分记录中的两个不同 buffer owner；
- CFG 形参重命名和 `mix_a` / `mix_b` 相互递归。

名义结果 `[Empty, readbuf, Meta_partial, mutbuf]` 的实际展开为：

```json
{
  "returns": ["readbuf", "buffer", "usize", "u8", "mutbuf"],
  "return_loans": ["right_a", null, null, null, "left_a"]
}
```

这同时检查了零槽删除、多个 null 槽扩展、不同形式参数的来源排列和递归转发。

| 参数：深度、左初值、右初值、左新值 | Python | 实际 Rust | 实际 LLVM |
| --- | ---: | ---: | ---: |
| `[0, 11, 87, 37]` | 124 | 124 | 124 |
| `[4, 253, 250, 19]` | 13 | 13 | 13 |

Python 和 Rust 的完整资源账本及执行步数一致：分别为 38 / 70 步；两个调用均有 2 次分配、2 次释放，4 次借用开始与结束，4 个 owner 创建与释放，峰值 payload 为 26 字节，返回时所有 live 项为零。LLVM 行验证的是实际共享库返回值；该正例的 native loan / owner 账本没有被独立测量。

Rust 使用实际冻结的 `hia-core-shadow` 进程，直接提交 canonical Core；请求、策略、输入摘要、原始 stdout / stderr、返回码全部保留。所用 Rust 二进制原始字节已复制到 `retained-binaries/`，SHA-256 为：

```text
5c39bec4def3b274487c4dce5f37475d7c2e0ac0c1e14634f5fa906f87c15abc
```

## 独立反例

| 控制 | 实际结果 |
| --- | --- |
| 给零宽 `Empty` 结果填写非 null 来源 | `E_HIA_LOAN`；无效来源在零槽展开前拒绝 |
| 来源填写为 JSON 对象 | `E_HIA_LOAN`；没有异常崩溃或伪造来源 |
| 同一输入显式改为 composite v3 | `E_HIA_FORMAT`；严格拒绝新合同字段 |
| CFG 两条边把不同 primitive 形参来源汇合为同一返回借用 | Python `E_HIA_LOAN`；实际 Rust 也在一步策略下、无关入口执行前拒绝 |

反例源码、可展开反例的 Core、Python 错误和 Rust 原始输出全部保留。这些控制对应新增审查风险，没有重跑规定的 13 方法验收或完整回归。

## 七字节分配观察器的判定

保留的旧观察器明确只将 **1 字节**归类为 payload、**24 字节**归类为 node。其余成功分配都增加 `unknown_sizes`。这个字段不改变实际分配和释放逻辑。

本次从旧复现的名义输入出发，在冻结提交上重新核验并编译：canonical Core、LLVM IR、目标文件和后端实现摘要均与旧复现对应记录一致。随后用原观察器驱动源码重新链接并实际运行。

| 注入失败序号 | 返回值 | 分配 / 释放 | 峰值 / 返回时 live 字节 | `unknown_sizes` |
| --- | ---: | ---: | ---: | ---: |
| 0，无注入失败 | 42 | 1 / 1 | 7 / 0 | 1 |
| 1，第一次分配失败 | 250 | 0 / 0 | 0 / 0 | 0 |

上述结果与实际 Python 执行一致，`bad_frees` 和 `null_frees` 都为零。因此，这次 `unknown_sizes == 0` 断言失败来自观察器的固定分类前提；在此复现中没有观察到后端结果、分配、释放或字节账本不一致。改用 1 字节只修正了这个专用观察器的调用条件；已有独立标量 native 调用仍覆盖 7 和 19 字节。

保留的旧复现仍标明它来自 **dirty 的 parent bf143a7**，没有改写为当前提交的原始记录。新执行记录单独位于 `observer-seven/independent-observations.json`。为了完整保留所链接观察器可执行文件的执行前后身份，又进行了相同两组输入的身份绑定重放：因此这里共有 **4 次实际观察器执行、2 组不同失败序号**，不计作四种独立测试。

## 原验收和本次审查分别保留

原作者的精确提交验收记录为 **13 / 13 方法、153 次 Rust 对照、4 个 raw Rust 拒绝、31 次 native 调用**；另有 **98 / 98** 旧范围回归，均无失败、错误或跳过。这些原始记录及测试日志复制在 `producer-evidence/`，复制前后大小和摘要一致。本次没有重跑这些套件，也没有把它们加到独立控制的分母中。

本次独立计数是：2 次 Python 正例、2 次 Rust 正例、2 次 LLVM 正例、4 个 Python 拒绝、1 个 raw Rust 拒绝，以及上述 4 次观察器执行。进程记录不是新增的语言测试方法。

## 证据与边界

- `review.json`：总审查结论、范围和计数。
- `review_controls.py`：独立构造器、断言和实际执行记录器。
- `mixed-python-rust.json`、`native/`、`processes/`：源码、Core、IR、对象 / 共享库、实际进程输出。
- `source-binding/`：完整已跟踪文件身份，执行前后检查和冻结提交原文。
- `tool-binary-before.json`、`tool-binary-after.json`、`native-artifact-bindings-*.json`：工具、Rust 二进制及原生生成物身份。
- `observer-seven/`：带原始身份标签的旧复现和本次新复现。

Python 仍是生产准入权威，优化政策仍为 `no_change`。这个有限增量没有关闭一般内存 / provenance、任意递归 ADT、全部部分初始化、外部或存储逃逸生命周期、完整取消 / 错误清理、通用 callback ABI、物理设备验收或全语言证明等广义 blocker。
