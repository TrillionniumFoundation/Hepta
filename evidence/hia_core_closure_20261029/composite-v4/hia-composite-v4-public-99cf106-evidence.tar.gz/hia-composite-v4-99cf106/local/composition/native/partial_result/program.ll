; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal { %hia.buffer, i64, %hia.buffer } @__hia_fn_0(%hia.buffer %p_0_0, i64 %p_0_1, %hia.buffer %p_0_2) {
b0:
  %t1 = insertvalue { %hia.buffer, i64, %hia.buffer } zeroinitializer, %hia.buffer %p_0_0, 0
  %t2 = insertvalue { %hia.buffer, i64, %hia.buffer } %t1, i64 %p_0_1, 1
  %t3 = insertvalue { %hia.buffer, i64, %hia.buffer } %t2, %hia.buffer %p_0_2, 2
  ret { %hia.buffer, i64, %hia.buffer } %t3
}

define internal i8 @__hia_fn_1(i8 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 1, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 1, 1
  %t6 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 0, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  %t11 = extractvalue %hia.buffer %t5, 0
  %t12 = extractvalue %hia.buffer %t5, 1
  %t13 = icmp ult i64 0, %t12
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = getelementptr i8, ptr %t11, i64 0
  store i8 %p_0_0, ptr %t15, align 1
  %t16 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t17 = extractvalue %hia.alloc %t16, 0
  %t18 = extractvalue %hia.alloc %t16, 1
  %t19 = select i1 %t18, i64 0, i64 0
  %t20 = insertvalue %hia.buffer %t17, i64 %t19, 1
  %t21 = call { %hia.buffer, i64, %hia.buffer } @__hia_fn_0(%hia.buffer %t20, i64 1, %hia.buffer %t5)
  %t22 = extractvalue { %hia.buffer, i64, %hia.buffer } %t21, 0
  %t23 = extractvalue { %hia.buffer, i64, %hia.buffer } %t21, 1
  %t24 = extractvalue { %hia.buffer, i64, %hia.buffer } %t21, 2
  %t25 = extractvalue %hia.buffer %t24, 0
  %t26 = extractvalue %hia.buffer %t24, 1
  %t27 = icmp ult i64 0, %t26
  br i1 %t27, label %ok_28, label %trap_28
trap_28:
  call void @abort()
  unreachable
ok_28:
  %t29 = getelementptr i8, ptr %t25, i64 0
  %t30 = load i8, ptr %t29, align 1
  %t31 = extractvalue %hia.buffer %t22, 0
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %drop_nonnull_33, label %drop_after_33
drop_nonnull_33:
  call void @free(ptr %t31) nobuiltin
  br label %drop_after_33
drop_after_33:
  %t34 = extractvalue %hia.buffer %t5, 0
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %drop_nonnull_36, label %drop_after_36
drop_nonnull_36:
  call void @free(ptr %t34) nobuiltin
  br label %drop_after_36
drop_after_36:
  %t37 = extractvalue %hia.buffer %t10, 0
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %drop_nonnull_39, label %drop_after_39
drop_nonnull_39:
  call void @free(ptr %t37) nobuiltin
  br label %drop_after_39
drop_after_39:
  ret i8 %t30
}

define zeroext i8 @partial_result(i8 zeroext %a0) {
entry:
  %result = call i8 @__hia_fn_1(i8 %a0)
  ret i8 %result
}
