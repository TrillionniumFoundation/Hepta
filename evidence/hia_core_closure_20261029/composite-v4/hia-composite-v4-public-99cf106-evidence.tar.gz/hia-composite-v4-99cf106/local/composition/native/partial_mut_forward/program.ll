; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal %hia.buffer @__hia_fn_0(%hia.buffer %p_0_0) {
b0:
  ret %hia.buffer %p_0_0
}

define internal i8 @__hia_fn_1(i64 %p_0_0, i8 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  %t6 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 %p_0_0, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  br i1 %t8, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %t10, %edge_0 ]
  %p_1_2 = phi i8 [ %p_0_1, %edge_0 ]
  %t11 = extractvalue %hia.buffer %p_1_1, 0
  %t12 = extractvalue %hia.buffer %p_1_1, 1
  %t13 = icmp ult i64 0, %t12
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = getelementptr i8, ptr %t11, i64 0
  store i8 %p_1_2, ptr %t15, align 1
  %t16 = call %hia.buffer @__hia_fn_0(%hia.buffer %p_1_1)
  %t17 = add i8 %p_1_2, 5
  %t18 = extractvalue %hia.buffer %t16, 0
  %t19 = extractvalue %hia.buffer %t16, 1
  %t20 = icmp ult i64 0, %t19
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  %t22 = getelementptr i8, ptr %t18, i64 0
  store i8 %t17, ptr %t22, align 1
  %t23 = extractvalue %hia.buffer %t16, 0
  %t24 = extractvalue %hia.buffer %t16, 1
  %t25 = icmp ult i64 0, %t24
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = getelementptr i8, ptr %t23, i64 0
  %t28 = load i8, ptr %t27, align 1
  %t29 = extractvalue %hia.buffer %p_1_1, 0
  %t30 = extractvalue %hia.buffer %p_1_1, 1
  %t31 = icmp ult i64 0, %t30
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  %t33 = getelementptr i8, ptr %t29, i64 0
  %t34 = load i8, ptr %t33, align 1
  %t35 = extractvalue %hia.buffer %p_1_0, 0
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %drop_nonnull_37, label %drop_after_37
drop_nonnull_37:
  call void @free(ptr %t35) nobuiltin
  br label %drop_after_37
drop_after_37:
  %t38 = extractvalue %hia.buffer %p_1_1, 0
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %drop_nonnull_40, label %drop_after_40
drop_nonnull_40:
  call void @free(ptr %t38) nobuiltin
  br label %drop_after_40
drop_after_40:
  ret i8 %t28
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t10, %edge_1 ]
  %t41 = extractvalue %hia.buffer %p_2_1, 0
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %drop_nonnull_43, label %drop_after_43
drop_nonnull_43:
  call void @free(ptr %t41) nobuiltin
  br label %drop_after_43
drop_after_43:
  %t44 = extractvalue %hia.buffer %p_2_0, 0
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %drop_nonnull_46, label %drop_after_46
drop_nonnull_46:
  call void @free(ptr %t44) nobuiltin
  br label %drop_after_46
drop_after_46:
  ret i8 250
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define zeroext i8 @partial_mut_forward(i64 %a0, i8 zeroext %a1) {
entry:
  %result = call i8 @__hia_fn_1(i64 %a0, i8 %a1)
  ret i8 %result
}
