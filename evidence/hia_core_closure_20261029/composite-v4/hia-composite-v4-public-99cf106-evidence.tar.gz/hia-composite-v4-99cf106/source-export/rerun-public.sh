#!/usr/bin/env bash
set -euo pipefail

HIA_COMPOSITION_PUBLIC_HEAD="${1:?exact public commit SHA required}"
HIA_COMPOSITION_EVIDENCE_ROOT="${2:?new external evidence root required}"
HIA_COMPOSITION_CHECKOUT="${3:?clean public checkout required}"
cd "$HIA_COMPOSITION_CHECKOUT"
test "$(git rev-parse HEAD)" = "$HIA_COMPOSITION_PUBLIC_HEAD"
test "$(git rev-parse HEAD^{tree})" = c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2
test -z "$(git status --porcelain)"
mkdir "$HIA_COMPOSITION_EVIDENCE_ROOT"

python tools/qualify_hia_composite_returned_loans.py \
  --expected-head "$HIA_COMPOSITION_PUBLIC_HEAD" \
  --output-directory "$HIA_COMPOSITION_EVIDENCE_ROOT/composition"

python tools/qualify_hia_rust_api_v4.py \
  --expected-head "$HIA_COMPOSITION_PUBLIC_HEAD" \
  --output-directory "$HIA_COMPOSITION_EVIDENCE_ROOT/rust-api-v4"

python - "$HIA_COMPOSITION_PUBLIC_HEAD" "$HIA_COMPOSITION_EVIDENCE_ROOT" <<'PY'
from datetime import datetime, timezone
from pathlib import Path
import io, json, sys, unittest
from tools.qualify_hia_integrated import _source_state
from tools.qualify_hia_rust_budget_v3 import _complete_test_success, _test_counts

expected, output = sys.argv[1], Path(sys.argv[2])
names = ['tests.test_hia_program_composite', 'tests.test_hia_partial_record',
         'tests.test_hia_returned_loans.ReturnedLoans',
         'tests.test_hia_returned_loans.ReturnedLoanSemantics', 'tests.test_hia_routes']
before = _source_state()
if before['head'] != expected or before['status']:
    raise ValueError('fresh exact clean public source required')
started = datetime.now(timezone.utc).isoformat()
log = io.StringIO()
result = unittest.TextTestRunner(stream=log, verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromNames(names))
after = _source_state()
report = {'schema': 'hepta.hia.composite-v4.legacy-regression-observation.v1',
    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'selection': names, 'tests': _test_counts(result), 'source_before': before,
    'source_after': after, 'source_unchanged': before == after, 'test_log': log.getvalue(),
    'ok': bool(_complete_test_success(result, 98) and before == after)}
(output / 'legacy-regression.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
(output / 'legacy-regression.log').write_text(log.getvalue())
print(json.dumps({key: report[key] for key in ('ok', 'tests', 'source_unchanged')}))
raise SystemExit(0 if report['ok'] else 1)
PY

python -m hepta hia verify examples/hia_program/composite_returned_loans_v4.hia \
  > "$HIA_COMPOSITION_EVIDENCE_ROOT/example-verify.json"
python -m hepta hia run examples/hia_program/composite_returned_loans_v4.hia \
  --function partial_result --arguments '[37]' \
  > "$HIA_COMPOSITION_EVIDENCE_ROOT/example-run.json"
test "$(git rev-parse HEAD)" = "$HIA_COMPOSITION_PUBLIC_HEAD"
test -z "$(git status --porcelain)"
