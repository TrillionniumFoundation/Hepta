# Public exact-head rerun

Publish the exported UTF-8 files and modes on public parent
`adbe4a1168a84d0696749ef54f933994b5dc554c`. The resulting source tree must be
`c2afb20ce0eb14ff3a7750ff123d8f9bfa8842e2`. The local component remains
`e21d672eb1bc588e248f72b0217b922671a869a5`, whose parent is
`bf143a7ebf12e4a7013c0dd41fe23d14ad3e5ec7`; both parent trees are recorded as
`04b70dccc157af470aa2b5bdeb74e6f88dbff5bf`.

Use a clean checkout of the newly returned full public commit SHA. The
qualification must run in that checkout, and its evidence directory must be
new and outside the checkout. Do not replace local receipt commit fields or
infer the public run from tree equality.

The current restored environment can be selected with these exact commands:

```sh
export PATH=/workspace/scratch/b484d4086829/toolchains/rust-1.90.0/bin:/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/llvm-20/bin:"$PATH"
export RUSTC=/workspace/scratch/b484d4086829/toolchains/rust-1.90.0/bin/rustc
export CARGO_HOME=/workspace/scratch/b484d4086829/toolchains/cargo-home
export CARGO_TARGET_DIR=/workspace/scratch/b484d4086829/rust-composition-target
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CLANG=/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/llvm-20/bin/clang
export LD_LIBRARY_PATH=/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/x86_64-linux-gnu:/workspace/scratch/b484d4086829/toolchains/llvm20-evening/usr/lib/llvm-20/lib

# Arguments: exact public SHA, new evidence root, clean public checkout.
bash /workspace/scratch/b484d4086829/composite-v4-publication-export-e21d672/rerun-public.sh \
  EXACT_PUBLIC_COMMIT NEW_EVIDENCE_DIRECTORY CLEAN_PUBLIC_CHECKOUT
```

The script runs the focused 13-method composition qualification, the stacked
eight-method Rust API v4 qualification, the 98-method legacy regression and the
checked-in CLI example. These are separate, overlapping qualification scopes;
do not sum their method or observation counts into a language-completeness
number. The 116-method reviewed safety matrix and full integrated release are
additional gates, with their full existing dependencies and evidence inputs.

Current LLVM is the isolated Ubuntu `20.1.2-0ubuntu1~24.04.3` package build on
this Debian 13/GCC 14 host. This is a new host execution observation and does not
inherit prior Ubuntu-host or cross-target/physical-device qualification.
