#pragma once
#include "/home/runner/work/Hepta/Hepta/tests/fixtures/cpp_upgrade/3.11.3/json.hpp"
#include "/home/runner/work/Hepta/Hepta/examples/cpp/upgrade/adapter.hpp"
