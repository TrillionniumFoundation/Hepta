#pragma once
#include "D:\\a\\Hepta\\Hepta\\tests\\fixtures\\cpp_upgrade\\3.11.3\\json.hpp"
#include "D:\\a\\Hepta\\Hepta\\examples\\cpp\\upgrade\\adapter.hpp"
