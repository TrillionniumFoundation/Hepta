#pragma once
#include "D:\\a\\Hepta\\Hepta\\tests\\fixtures\\cpp_upgrade\\3.12.0\\json.hpp"
#include "D:\\a\\Hepta\\Hepta\\examples\\cpp\\upgrade\\adapter.hpp"
