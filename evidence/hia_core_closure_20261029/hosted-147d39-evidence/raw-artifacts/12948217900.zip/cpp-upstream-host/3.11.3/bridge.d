D:\a\Hepta\Hepta\artifacts\cpp-upstream-host\3.11.3\bridge.obj: \
  D:\a\Hepta\Hepta\artifacts\cpp-upstream-host\3.11.3\bridge\bridge.cpp \
  D:\a\Hepta\Hepta\artifacts\cpp-upstream-host\3.11.3\bridge\bridge.h \
  D:\\a\\Hepta\\Hepta\\artifacts\\cpp-upstream-host\\3.11.3\\selected.hpp \
  D:\\a\\Hepta\\Hepta\\tests\\fixtures\\cpp_upgrade\\3.11.3\\json.hpp \
  D:\\a\\Hepta\\Hepta\\examples\\cpp\\upgrade\\adapter.hpp
