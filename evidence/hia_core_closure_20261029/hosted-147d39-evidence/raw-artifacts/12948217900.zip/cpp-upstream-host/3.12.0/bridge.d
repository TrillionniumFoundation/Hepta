D:\a\Hepta\Hepta\artifacts\cpp-upstream-host\3.12.0\bridge.obj: \
  D:\a\Hepta\Hepta\artifacts\cpp-upstream-host\3.12.0\bridge\bridge.cpp \
  D:\a\Hepta\Hepta\artifacts\cpp-upstream-host\3.12.0\bridge\bridge.h \
  D:\\a\\Hepta\\Hepta\\artifacts\\cpp-upstream-host\\3.12.0\\selected.hpp \
  D:\\a\\Hepta\\Hepta\\tests\\fixtures\\cpp_upgrade\\3.12.0\\json.hpp \
  D:\\a\\Hepta\\Hepta\\examples\\cpp\\upgrade\\adapter.hpp
