#!/usr/bin/env python3
"""Download one original official ZIP; retain private signing transport separately."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import time
import urllib.request

HERE = Path(__file__).resolve().parent
artifact = json.loads((HERE/'artifact.json').read_text())
assert artifact['workflow_run']['head_sha'] == '147d39c4a9d3ded00fb5d22439493bc006a8b76d'
assert artifact['workflow_run']['id'] == 40989068148
private = HERE.parent.parent/'hosted-147d39-private-transport'/f"{artifact['id']}.json"
transport = json.loads(private.read_text())
destination = HERE/'official-full-release-147d39.zip'
assert not destination.exists()
partial = destination.with_suffix('.zip.partial')
free_before = shutil.disk_usage(HERE).free
assert free_before > artifact['size_in_bytes'] + 64*1024*1024, 'Insufficient working space for one original ZIP plus audit metadata'
begin = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
digest = hashlib.sha256()
count = 0
with urllib.request.urlopen(transport['download_url'], timeout=60) as response:
    status = response.status
    headers = {name: response.headers.get(name) for name in ('Content-Length','Content-Type','Last-Modified','ETag')}
    with partial.open('xb') as output:
        for chunk in iter(lambda: response.read(1024*1024), b''):
            count += len(chunk)
            assert count <= artifact['size_in_bytes'], 'Download exceeded official artifact size'
            output.write(chunk)
            digest.update(chunk)
assert count == artifact['size_in_bytes']
assert 'sha256:' + digest.hexdigest() == artifact['digest']
partial.rename(destination)
receipt = {'schema':'hepta.hosted147-official-full-download.v1','artifact_id':artifact['id'],
           'run_id':40989068148,'source_commit':artifact['workflow_run']['head_sha'],
           'path':destination.name,'bytes':count,'sha256':digest.hexdigest(),
           'official_size_and_digest_match':True,'started_utc':started,'wall_seconds':time.monotonic()-begin,
           'http_status':status,'safe_response_headers':headers,'free_bytes_before':free_before,
           'free_bytes_after':shutil.disk_usage(HERE).free,'private_transport_excluded':True,
           'duplicate_original_zip_created':False}
(HERE/'download-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,indent=2))
