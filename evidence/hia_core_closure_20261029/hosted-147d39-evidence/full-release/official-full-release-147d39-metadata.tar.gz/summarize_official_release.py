#!/usr/bin/env python3
"""Summarize verified original reports without rerunning a producer or native code."""
from pathlib import Path
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


audit = read(HERE/'audit.json')
assert audit['audit_integrity_ok'] is True
inventory = read(HERE/'zip-inventory.json')
members = {row['path']: row for row in inventory['members']}
run = read(HERE/'metadata/observation05/run.json')
job = read(HERE/'metadata/observation05/jobs.json')['jobs'][0]
assert run['head_sha'] == job['head_sha'] == audit['source_commit']
assert run['conclusion'] == job['conclusion'] == 'success'
assert all(step['conclusion'] == 'success' for step in job['steps'])
gate_rows = []
supplement = []
with zipfile.ZipFile(HERE/'official-full-release-147d39.zip') as archive:
    reports = {name: json.loads(archive.read(path)) for name, path in audit['report_paths'].items()}
    for scope, report in reports.items():
        for gate in report['gates']:
            gate_rows.append({'scope': scope, 'name': gate['name'],
                              'status': gate.get('status'), 'passed': gate.get('passed', gate.get('status') == 'passed'),
                              'exit_code': gate.get('exit_code', gate.get('returncode', gate.get('execution', {}).get('returncode'))),
                              'tests_run': gate.get('tests_run'), 'test_binaries': gate.get('test_binaries'),
                              'evidence_reference': gate.get('evidence'), 'log_reference': gate.get('log')})
    tool_gate = next(row for row in reports['integrated']['gates'] if row['name'] == 'actual_tools_and_linux_seals')
    tools = {}
    external = reports['integrated']['external_inventory_before']
    for name, row in tool_gate['tools'].items():
        assert row['execution']['returncode'] == 0
        assert external[row['path']] == row['sha256']
        tools[name] = {**row, 'actual_first_version_line': row['execution']['stdout'].splitlines()[0],
                       'recorded_external_before_after_identity': True,
                       'tool_bytes_independently_reacquired_by_auditor': False}
    for path in ['Hepta/Hepta/artifacts/selected-rustc.json',
                 'Hepta/Hepta/artifacts/bwrap-profile.sha256',
                 'Hepta/Hepta/artifacts/sandbox-startup.json']:
        if path not in members:
            continue
        raw = archive.read(path)
        assert hashlib.sha256(raw).hexdigest() == members[path]['sha256']
        target = HERE/'retained'/path
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == raw
        else:
            target.write_bytes(raw)
        supplement.append(members[path])
    performance_path = 'Hepta/Hepta/artifacts/hia-unified/performance.json'
    performance = json.loads(archive.read(performance_path))
    tool_summary = {'schema': 'hepta.hosted147-full-actual-tool-summary.v1',
                    'source_commit': audit['source_commit'], 'report_path': audit['report_paths']['integrated'],
                    'tools': tools, 'solver': tool_gate['solver'],
                    'original_type_reader': tool_gate['original_type_reader'],
                    'linux_seals': tool_gate['linux_seals'],
                    'environment': performance['environment'],
                    'scope': 'Actual original version commands, hashes and before/after identities. Unuploaded tools were not re-downloaded or executed by this auditor.'}
    save(HERE/'actual-tools.json', tool_summary)
    scope_summary = {'schema': 'hepta.hosted147-full-scope-observations.v1',
                     'report_statuses': {name: report.get('status') for name, report in reports.items()},
                     'report_boolean_claims': {name: {k: v for k, v in report.items() if isinstance(v, bool)} for name, report in reports.items()},
                     'standalone_scope_limits': reports['standalone']['scope_limits'],
                     'ndu_gate_names': [row['name'] for row in reports['ndu']['gates']],
                     'performance': {'original_report': performance_path,
                                     'status': performance['status'], 'ok': performance['ok'],
                                     'claims': performance['claims'], 'environment': performance['environment'],
                                     'interference_observations': performance['interference_observations'],
                                     'resource_observation': performance['resource_observation']},
                     'ndu_binary_bindings': audit['ndu_binary_bindings'],
                     'no_optimization_policy_switch_inferred_from_gate_pass': True,
                     'P0_P7_fully_closed': False}
    save(HERE/'scope-observations.json', scope_summary)
save(HERE/'gate-statuses.json', {'schema': 'hepta.hosted147-full-actual-gate-statuses.v1', 'rows': gate_rows})
save(HERE/'supplemental-retained-members.json', {'members': supplement})
summary = {'schema': 'hepta.hosted147-full-release-audit-summary.v1',
           'source_commit': audit['source_commit'], 'source_tree': audit['source_tree'],
           'run_id': run['id'], 'job_id': job['id'], 'workflow_status': run['status'],
           'workflow_conclusion': run['conclusion'], 'workflow_completed_at': job['completed_at'],
           'artifact_id': audit['artifact_id'], 'artifact_bytes': inventory['archive']['bytes'],
           'artifact_sha256': inventory['archive']['sha256'], 'all_zip_crc_passed': True,
           'zip_member_count': inventory['member_count'], 'decoded_bytes': inventory['decoded_bytes'],
           'zip_scope_counts': inventory['scope_counts'], 'actual_content_audit_passed': True,
           'audit_checks': len(audit['checks']), 'gate_counts': audit['gate_counts'],
           'python': audit['python_raw_outcomes'],
           'rust': {name: {'tests': row['tests'], 'harnesses': row['harnesses'],
                           'failed': sum(r['failed'] for r in row['rows']),
                           'ignored': sum(r['ignored'] for r in row['rows']),
                           'measured': sum(r['measured'] for r in row['rows']),
                           'filtered_out': sum(r['filtered_out'] for r in row['rows'])} for name, row in audit['rust_raw_outcomes'].items()},
           'coverage': audit['coverage'], 'source_scopes': audit['source_scopes'],
           'external_identity_counts': {'actual_reported_entries': audit['external_inventory']['entries'],
                                        'retained_bytes_independently_verified': len(audit['external_inventory']['actual_retained_bytes_verified']),
                                        'raw_public_source_verified': len(audit['external_inventory']['raw_public_source_verified']),
                                        'unretained_reported_identities': len(audit['external_inventory']['unretained_recorded_identities_only'])},
           'nonordinary_test_statuses': [],
           'production_rust_authority_switch_qualified': False,
           'whole_language_soundness_or_backend_refinement_proved': False,
           'P0_P7_fully_closed': False,
           'tests_or_native_processes_reexecuted_by_auditor': 0,
           'github_mutations_by_auditor': 0,
           'full_qualification_applies_only_to_exact_147_source': True,
           'subsequent_integration_commits_not_qualified_by_this_run': True}
save(HERE/'summary.json', summary)
print(json.dumps({'summary_ok': True, 'gates': summary['gate_counts'], 'coverage': summary['coverage'],
                  'tool_version_records': len(tools), 'supplemental_retained': len(supplement)}, indent=2))
