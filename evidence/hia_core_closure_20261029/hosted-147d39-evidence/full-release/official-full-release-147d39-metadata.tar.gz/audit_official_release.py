#!/usr/bin/env python3
"""Independent, read-only audit of the actually downloaded official release."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import ast, collections, hashlib, json, re, subprocess, zipfile

HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent/'hepta-rust-records-public'
ARTIFACT=json.loads((HERE/'artifact.json').read_text())
HEAD='147d39c4a9d3ded00fb5d22439493bc006a8b76d'
TREE='2050ec5e447ae5191ac2e685ba463292b2d2d3fe'
PREFIX='Hepta/Hepta/'
TOP={
 'candidate':PREFIX+'artifacts/candidate/release-validation.json',
 'standalone':PREFIX+'artifacts/hia-unified/qualification.json',
 'ndu':PREFIX+'artifacts/hia-ndu/qualification.json',
 'integrated':'_temp/hepta-integrated/qualification.json',
}
CHECKS=[]

def check(name, condition, **detail):
 CHECKS.append({'name':name,'passed':bool(condition),**detail})
 if not condition: raise AssertionError(name)

def pairs(items):
 d={}
 for k,v in items:
  if k in d: raise ValueError('duplicate decoded JSON key')
  d[k]=v
 return d

def decode(raw):
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))

def identity(raw):
 return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
         'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}

def git(*args):
 return subprocess.check_output(['git','--no-replace-objects','-C',str(REPO),*args])

def git_inventory():
 check('source_commit_tree',git('rev-parse',HEAD+'^{tree}').decode().strip()==TREE)
 rows=[]
 for row in git('ls-tree','-rz',HEAD).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,sha=meta.decode().split()
  check('git_object_regular_'+str(len(rows)),kind=='blob' and mode in ('100644','100755'))
  rows.append({'path':path.decode(),'mode':mode,'git_blob_sha1':sha})
 # Pinned raw Git blobs, not mutable working-tree files or imported producer code.
 proc=subprocess.Popen(['git','--no-replace-objects','-C',str(REPO),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 result={}
 for row in rows:
  proc.stdin.write((row['git_blob_sha1']+'\n').encode());proc.stdin.flush()
  header=proc.stdout.readline().decode().strip().split();assert header[1]=='blob'
  raw=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n'
  actual=identity(raw);assert actual['git_blob_sha1']==row['git_blob_sha1']
  result[row['path']]={**row,**actual}
 proc.stdin.close();assert proc.wait()==0
 return result

def unittest_summary(text):
 match=re.search(r'(?m)^Ran ([0-9]+) tests? in ([0-9.]+)s\r?\n\r?\n(OK(?: \([^\n]*\))?|FAILED[^\n]*)\r?\n?\Z',text)
 check('terminal_unittest_summary_'+str(len(CHECKS)),match is not None)
 count=int(match.group(1));terminal=match.group(3)
 check('unittest_clean_terminal_'+str(len(CHECKS)),terminal=='OK',actual=terminal)
 return {'tests_run':count,'terminal':terminal,'seconds':float(match.group(2)),
         'failures':0,'errors':0,'skipped':0,'expected_failures':0,'unexpected_successes':0}

def methods(text):
 starts=list(re.finditer(r'(?m)^(test\w+) \(((?:tests\.)?test_[^\s)]+)\)',text))
 rows=[]
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else len(text)
  block=text[m.end():end]
  statuses=re.findall(r'(?m)(?:\.\.\. |^)(ok|ERROR|FAIL|expected failure|unexpected success|skipped[^\r\n]*)\r?$',block)
  check('method_terminal_'+str(len(CHECKS)),bool(statuses),method=m.group(2))
  name=m.group(2).removeprefix('tests.')
  rows.append({'id':name,'method_name':m.group(1),'status':statuses[-1],
               'interleaved_diagnostics':not bool(re.match(r' \.\.\. (?:ok|ERROR|FAIL)\r?\n',block))})
 check('unique_verbose_methods_'+str(len(CHECKS)),len(rows)==len({r['id'] for r in rows}))
 check('all_verbose_methods_ok_'+str(len(CHECKS)),all(r['status']=='ok' for r in rows))
 return rows

def cargo(text):
 chunks=re.findall(r'(?m)^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
 rows=[{'status':r[0],**dict(zip(('passed','failed','ignored','measured','filtered_out'),map(int,r[1:])))} for r in chunks]
 check('cargo_harnesses_present_'+str(len(CHECKS)),bool(rows))
 check('cargo_clean_harnesses_'+str(len(CHECKS)),all(r['status']=='ok' and all(r[k]==0 for k in ('failed','ignored','measured','filtered_out')) for r in rows))
 actual=re.findall(r'(?m)^test (.+?) \.\.\. (ok|FAILED|ignored)(?:\r)?$',text)
 check('cargo_actual_methods_'+str(len(CHECKS)),len(actual)==sum(r['passed'] for r in rows) and all(s=='ok' for _,s in actual))
 return {'tests':sum(r['passed'] for r in rows),'harnesses':len(rows),'rows':rows,'method_statuses':[{'name':n,'status':s} for n,s in actual]}

def main():
 source_expectations=decode((HERE/'expected-source-declarations.json').read_bytes())
 check('expected_source_identity',source_expectations['source_commit']==HEAD and source_expectations['source_tree']==TREE)
 integrated_source=git('show',HEAD+':tools/qualify_hia_integrated.py')
 check('expected_integrated_source_hash',identity(integrated_source)['sha256']==source_expectations['integrated_source_sha256'])
 declarations={}
 for node in ast.parse(integrated_source).body:
  if isinstance(node,ast.Assign):
   for target in node.targets:
    if isinstance(target,ast.Name) and target.id in ('EXPECTED_GATE_NAMES','CRITICAL_MODULES'):
     declarations[target.id]=ast.literal_eval(node.value)
 check('expected_critical_group_declarations',{k:list(v) for k,v in declarations['CRITICAL_MODULES'].items()}==source_expectations['critical_groups'])
 check('expected_integrated_gate_declarations',list(declarations['EXPECTED_GATE_NAMES'])==source_expectations['integrated_gate_names'])
 inv=decode((HERE/'zip-inventory.json').read_bytes()); members={r['path']:r for r in inv['members']}
 check('complete_zip_crc_inventory',inv['all_members_streamed_to_eof_and_crc_checked'] and len(members)==inv['member_count'] and len(members)>0)
 check('official_digest',inv['archive']['bytes']==ARTIFACT['size_in_bytes'] and inv['archive']['sha256']==ARTIFACT['digest'].removeprefix('sha256:'))
 scan=decode((HERE/'zip-credential-scan.json').read_bytes())
 check('finite_scan_no_findings',not scan['findings'])
 source=git_inventory();check('all_raw_git_source_files',len(source)==4398)
 # Collapse per-blob validation details into the separate complete source binding.
 blob_checks=[r for r in CHECKS if r['name'].startswith('git_object_regular_')]
 CHECKS[:]=[r for r in CHECKS if not r['name'].startswith('git_object_regular_')]
 check('all_git_object_kinds_and_modes',all(r['passed'] for r in blob_checks),files=len(blob_checks))
 (HERE/'source-git-binding.json').write_text(json.dumps({'source_commit':HEAD,'source_tree':TREE,'files':source},indent=2)+'\n')
 retained={};refs=[]; method_sets={};outcomes={};rust={};standalone_streams={}
 with zipfile.ZipFile(HERE/'official-full-release-147d39.zip') as z:
  def read(path, keep=True):
   raw=z.read(path);row=members[path]
   check('retained_member_identity_'+str(len(CHECKS)),all(identity(raw)[k]==row[k] for k in ('bytes','sha256','git_blob_sha1')),path=path)
   if keep:
    dest=HERE/'retained'/path;dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():check('retained_copy_unchanged_'+str(len(CHECKS)),dest.read_bytes()==raw)
    else:dest.write_bytes(raw);dest.chmod(int(row['zip_mode_octal'],8)&0o777)
    retained[path]=row
   return raw
  def doc(path):return decode(read(path))
  reports={name:doc(path) for name,path in TOP.items()}
  candidate,standalone,ndu,integrated=(reports[k] for k in ('candidate','standalone','ndu','integrated'))
  def link(path,digest,kind):
   raw=read(path);check('report_reference_'+str(len(CHECKS)),identity(raw)['sha256']==digest,path=path,kind=kind)
   refs.append({'path':path,'sha256':digest,'kind':kind})
   return raw
  workflow=doc(PREFIX+'artifacts/workflow-source.json')
  check('workflow_exact_head',all(workflow[k]==HEAD for k in ('expected_head_sha','checkout_head_sha','event_sha')))
  check('four_report_commits',candidate['source_git_commit']==standalone['git_commit']==ndu['source_revision']==ndu['source_revision_after']==integrated['source_before']['head']==integrated['source_after']['head']==HEAD)
  check('candidate_gate_denominator',candidate['status']=='passed' and len(candidate['gates'])==len(candidate['planned_gates'])==50 and [g['name'] for g in candidate['gates']]==candidate['planned_gates'] and all(g['status']=='passed' and g['exit_code']==0 for g in candidate['gates']))
  check('standalone_gate_denominator',standalone['ok'] and standalone['passed_gates']==standalone['completed_gates']==len(standalone['planned_gates'])==len(standalone['gates'])==37 and [g['name'] for g in standalone['gates']]==standalone['planned_gates'] and all(g['passed'] and g['returncode']==0 for g in standalone['gates']))
  check('ndu_gate_denominator',ndu['ok'] and len(ndu['gates'])==len(ndu['planned_gates'])==9 and [g['name'] for g in ndu['gates']]==ndu['planned_gates'] and all(g['passed'] and g['execution']['returncode']==0 for g in ndu['gates']))
  check('integrated_gate_denominator',integrated['ok'] and len(integrated['gates'])==8 and all(g['passed'] for g in integrated['gates']))
  check('integrated_exact_declared_gates',[g['name'] for g in integrated['gates']]==source_expectations['integrated_gate_names'])
  snapshots={
   'candidate':(candidate['source_snapshot'],candidate['source_snapshot_after']),
   'standalone':(standalone['source_snapshot_before'],standalone['source_snapshot_after']),
   'ndu':({'files':ndu['source_inventory_before']},{'files':ndu['source_inventory_after']}),
   'integrated':(integrated['source_before'],integrated['source_after'])}
  scopes={}
  excluded={'.git','__pycache__','artifacts','evidence','build','.venv'}
  expected_release={p for p in source if not excluded.intersection(PurePosixPath(p).parts) and PurePosixPath(p).suffix not in ('.pyc','.bundle') and not PurePosixPath(p).name.endswith('.hepta-lock')}
  ndu_roots=('hepta','tests','tools','rust','.github/workflows')
  expected_ndu={p for p in source if p in ('pyproject.toml','toolchain-lock.json') or any(p.startswith(r+'/') for r in ndu_roots)}
  for name,(before,after) in snapshots.items():
   check(name+'_snapshot_unchanged',before==after)
   files=before['files'];expected=expected_release if name in ('candidate','standalone') else expected_ndu if name=='ndu' else set(source)
   check(name+'_exact_declared_path_scope',set(files)==expected,files=len(files))
   check(name+'_all_source_hashes_match_git',all(source[p]['sha256']==h for p,h in files.items()),files=len(files))
   if 'sha256' in before:check(name+'_snapshot_digest',before['sha256']==hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest())
   scopes[name]={'files':len(files),'all_declared_paths_match_raw_git':True,'before_after_equal':True,'full_tracked_tree':name=='integrated'}
  check('integrated_source_tree_and_clean',integrated['source_before']['tree']==TREE and integrated['source_before']['status']=='' and integrated['source_unchanged'])
  check('external_input_before_after',integrated['external_inventory_before']==integrated['external_inventory_after'] and integrated['external_inputs_unchanged'])
  for gate in candidate['gates']:
   link(PREFIX+gate['log'],gate['log_sha256'],'candidate_gate_log')
   if 'evidence' in gate:
    path=PREFIX+gate['evidence']; raw=read(path);decode(raw)
    ev=candidate['evidence'][gate['evidence']]
    check('candidate_report_fresh_'+str(len(CHECKS)),ev['fresh'] is True and ev['gate']==gate['name'] and ev['bytes']==len(raw) and ev['validation_status']=='passed')
    link(path,ev['sha256'],'candidate_gate_report')
  for gate in standalone['gates']:
   for channel in ('stdout','stderr'):
    stream=gate[channel]
    check('standalone_declared_stream_path_'+str(len(CHECKS)),stream['path']==gate['name']+'.'+channel+'.log')
    raw=link(PREFIX+'artifacts/hia-unified/'+stream['path'],stream['sha256'],'standalone_raw_stream')
    check('standalone_exact_stream_length_'+str(len(CHECKS)),len(raw)==stream['bytes'],gate=gate['name'],channel=channel)
    standalone_streams[(gate['name'],channel)]=raw.decode()
   if 'evidence' in gate:
    ev=gate['evidence'];path=PREFIX+'artifacts/hia-unified/'+ev['path']
    link(path,ev['sha256'],'standalone_gate_report');decode(read(path))
  for gate in ndu['gates']:
   if 'evidence' in gate:
    path=gate['evidence'].removeprefix('/home/runner/work/')
    link(path,gate['evidence_sha256'],'ndu_gate_report');decode(read(path))
  cg=next(g for g in candidate['gates'] if g['name']=='unit_and_integration')
  candidate_text=read(PREFIX+cg['log']).decode()
  outcomes['candidate_full']=unittest_summary(candidate_text)
  method_sets['candidate_full']=methods(candidate_text)
  sg=next(g for g in standalone['gates'] if g['name']=='unit_regression')
  outcomes['standalone_full']=unittest_summary(standalone_streams[('unit_regression','stderr')])
  check('standalone_no_verbose_method_claim',not re.search(r'(?m)^test\w+ \(',standalone_streams[('unit_regression','stderr')]))
  ig=next(g for g in integrated['gates'] if g['name']=='full_regression')
  check('integrated_full_raw_copy',ig==doc('_temp/hepta-integrated/full_regression-execution.json'))
  outcomes['integrated_full']=unittest_summary(ig['execution']['stderr'])
  method_sets['integrated_full']=methods(ig['execution']['stderr'])
  ng=next(g for g in ndu['gates'] if g['name']=='focused_regression')
  outcomes['ndu_focused']=unittest_summary(ng['execution']['stderr'])
  method_sets['ndu_focused']=methods(ng['execution']['stderr'])
  check('full_python_counts',outcomes['candidate_full']['tests_run']>0 and len({outcomes[k]['tests_run'] for k in ('candidate_full','standalone_full','integrated_full')})==1)
  check('complete_verbose_denominators',len(method_sets['candidate_full'])==len(method_sets['integrated_full'])==outcomes['candidate_full']['tests_run'] and len(method_sets['ndu_focused'])==outcomes['ndu_focused']['tests_run'] and outcomes['ndu_focused']['tests_run']>0)
  check('two_complete_verbose_sets_equal',{r['id'] for r in method_sets['candidate_full']}=={r['id'] for r in method_sets['integrated_full']})
  full_ids={r['id'] for r in method_sets['integrated_full']}
  check('focused_is_subset',{r['id'] for r in method_sets['ndu_focused']}<=full_ids)
  safety=decode(git('show',HEAD+':docs/HIA_SAFETY_CONTRACT.json'))
  safety_ids={s.removeprefix('tests.') for c in safety['capabilities'] for s in c['regression_selectors']}
  expected=decode((HERE/'expected-source-declarations.json').read_bytes())
  check('current_safety_subset',safety_ids==set(expected['safety_selectors']) and safety_ids<=full_ids and len(safety['capabilities'])==expected['safety_capabilities'])
  cov=next(g for g in integrated['gates'] if g['name']=='merge_and_profile_coverage')
  check('coverage_raw_copy',cov==doc('_temp/hepta-integrated/merge-and-profile-coverage.json'))
  modules={m for g in cov['groups'].values() for m in g}
  check('critical_group_denominators',{name:set(rows) for name,rows in cov['groups'].items()}=={name:set(rows) for name,rows in expected['critical_groups'].items()} and not cov['missing_modules'])
  check('critical_exact_method_membership',all(ids==sorted(i for i in full_ids if i.startswith(module+'.')) for group in cov['groups'].values() for module,ids in group.items()))
  for name,gate in [('standalone',next(g for g in standalone['gates'] if g['name']=='rust_shadow_cargo')),('ndu',next(g for g in ndu['gates'] if g['name']=='rust_resource_crate')),('integrated',next(g for g in integrated['gates'] if g['name']=='rust_resource_crate'))]:
   execution=gate.get('execution',gate)
   rust[name]=cargo(standalone_streams[('rust_shadow_cargo','stdout')] if name=='standalone' else execution['stdout'])
   check(name+'_rust_denominator',rust[name]['tests']==gate['tests_run'] and rust[name]['harnesses']==gate['test_binaries'] and rust[name]['tests']>0)
  check('integrated_rust_raw_copy',next(g for g in integrated['gates'] if g['name']=='rust_resource_crate')==doc('_temp/hepta-integrated/rust_resource_crate-execution.json'))
  check('three_rust_corpora_match',len({(row['tests'],row['harnesses']) for row in rust.values()})==1 and all(collections.Counter(m['name'] for m in row['method_statuses'])==collections.Counter(m['name'] for m in rust['integrated']['method_statuses']) for row in rust.values()))
  binary_bindings=[]
  pins={'ranking':'d3c2d760eca5065fc966820379c35c6e8d56e855','recursive':'2590c0c94c5bf9a9004caeeb7b75edd6faf3eb8b','finite':'4b6391e116949af0c7e59776baead67271856bdb','stream':'c4a1bbed3a39beba43a6abf1a18b6f75c5725c21'}
  for name in ('ranking','recursive','finite','stream'):
   gate=next(g for g in integrated['gates'] if g['name']==name+'_bridge_identity')
   bpath=gate['binary'].removeprefix('/home/runner/work/');rpath=gate['receipt'].removeprefix('/home/runner/work/')
   receipt=doc(rpath);raw=read(bpath);expected=receipt['binary_sha256']
   check(name+'_binary_actual_hash',identity(raw)['sha256']==expected)
   if name=='ranking':pin=receipt['upstream']['commit'];check('ranking_no_production_activation',receipt['production_activation'] is False)
   else:
    pin=receipt['identity']['source_commit'];check(name+'_advisory_authority',receipt['authority']=='DENY_ALL' and receipt['safety_certificate'] is False)
    check(name+'_gate_receipt_hash',members[rpath]['sha256']==gate['receipt_sha256'])
   check(name+'_pinned_source',pin==pins[name])
   binary_bindings.append({'profile':name,'source_commit':pin,'binary_member':bpath,'binary_sha256':expected,'receipt_member':rpath,'source_bodies_independently_reacquired':False})
  external_retained=[]; external_source=[]; external_unretained=[]
  for path,digest in integrated['external_inventory_before'].items():
   relative=path.removeprefix('/home/runner/work/')
   if relative in members:
    check('retained_external_hash_'+str(len(CHECKS)),members[relative]['sha256']==digest,path=path)
    external_retained.append({'path':path,'zip_member':relative,'sha256':digest})
   elif path.startswith('/home/runner/work/Hepta/hepta-integrated-source/'):
    p=path.removeprefix('/home/runner/work/Hepta/hepta-integrated-source/')
    check('source_external_hash_'+str(len(CHECKS)),p in source and source[p]['sha256']==digest,path=path)
    external_source.append({'path':path,'source_path':p,'sha256':digest})
   else:external_unretained.append({'path':path,'sha256':digest})
  check('nonpromotional_claims',candidate['whole_project_blockers_closed'] is False and standalone['full_six_deliverables_complete'] is False and standalone['full_seven_deliverables_complete'] is False and all(ndu[k] is False and integrated[k] is False for k in ('whole_language_soundness_proved','six_stages_closed','scientific_incremental_advantage_established','global_optimality_established')))
  check('no_historical_evidence_promoted',integrated['historical_evidence_reused_as_current'] is False)
  read('_temp/hepta-integrated.log');read('_temp/hepta-integrated-worktree.log')
  for path in members:
   if path.startswith(('_temp/hepta-recursive-ndu-build/','_temp/hepta-finite-ndu-build/','_temp/hepta-stream-ndu-build/')):read(path)
  report={'schema':'hepta.official-release-independent-content-audit.v1','created_utc':datetime.now(timezone.utc).isoformat(),'source_commit':HEAD,'source_tree':TREE,'run_id':40989068148,'artifact_id':ARTIFACT['id'],'audit_integrity_ok':True,'bounded_qualification_passed':True,'broad_P0_P7_closed':False,'native_or_test_executions_by_auditor':0,'report_paths':TOP,'gate_counts':{'candidate':50,'standalone':37,'ndu':9,'integrated':8},'source_scopes':scopes,'python_raw_outcomes':outcomes,'python_method_denominator_policy':'Candidate and integrated retain matching complete verbose method IDs. Standalone retains a terminal count without its own per-method ID list. Actual counts are in python_raw_outcomes; overlapping runs, focused subsets, safety selectors and critical coverage are not summed.','rust_raw_outcomes':rust,'coverage':{'groups':len(cov['groups']),'unique_modules':len(modules),'safety_subset':len(safety_ids),'safety_capabilities':len(safety['capabilities'])},'ndu_binary_bindings':binary_bindings,'external_inventory':{'entries':len(integrated['external_inventory_before']),'before_after_equal':True,'actual_retained_bytes_verified':external_retained,'raw_public_source_verified':external_source,'unretained_recorded_identities_only':external_unretained},'report_reference_checks':refs,'retained_copies':len(retained),'checks':CHECKS,'limits':['Finite current-source qualification does not establish all P0-P7 closure, whole-language soundness, Rust production authority or native refinement.','Upstream source bodies and unuploaded tools are reported identities, not independently reacquired or rerun by this audit.','Historical/other artifact members remain original bytes and are not relabelled as current execution.','This official execution is not a reconstruction of pruned local qualification records.','The credential scan covers ten finite patterns over original ZIP member bytes, not a general secret-absence proof.']}
  (HERE/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
  (HERE/'method-statuses.json').write_text(json.dumps(method_sets,indent=2)+'\n')
  (HERE/'retained-members.json').write_text(json.dumps({'members':list(retained.values())},indent=2)+'\n')
  print(json.dumps({'audit_integrity_ok':True,'gates':report['gate_counts'],'python':{k:v['tests_run'] for k,v in outcomes.items()},'rust':{k:{'tests':v['tests'],'harnesses':v['harnesses']} for k,v in rust.items()},'checks':len(CHECKS),'source_scopes':scopes,'external':{'total':len(integrated['external_inventory_before']),'retained':len(external_retained),'source':len(external_source),'unretained':len(external_unretained)}}))

if __name__=='__main__':
 try:main()
 except Exception as e:
  (HERE/'audit-failure.json').write_text(json.dumps({'schema':'hepta.official-release-audit-refusal.v1','error_type':type(e).__name__,'error':str(e),'checks':CHECKS},indent=2)+'\n')
  raise
