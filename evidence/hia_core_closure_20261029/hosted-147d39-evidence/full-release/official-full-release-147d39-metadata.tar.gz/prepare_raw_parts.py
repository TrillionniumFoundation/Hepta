#!/usr/bin/env python3
"""Bind ordered slices of the single official ZIP without duplicating its bytes."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
archive = HERE/'official-full-release-147d39.zip'
artifact = json.loads((HERE/'artifact.json').read_text())
chunk_bytes = 4*1024*1024
before = archive.stat()
whole = hashlib.sha256()
whole_blob = hashlib.sha1(f'blob {before.st_size}\0'.encode())
parts = []
offset = 0
with archive.open('rb') as source:
    while True:
        raw = source.read(chunk_bytes)
        if not raw:
            break
        number = len(parts) + 1
        parts.append({'part': number, 'path': f"raw-artifacts/{artifact['id']}.zip.part{number:04d}",
                      'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                      'git_blob_sha1': hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
                      'mode': '100644'})
        whole.update(raw)
        whole_blob.update(raw)
        offset += len(raw)
after = archive.stat()
assert (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
assert offset == artifact['size_in_bytes']
assert 'sha256:' + whole.hexdigest() == artifact['digest']
assert sum(row['bytes'] for row in parts) == offset
assert all(row['offset'] == sum(previous['bytes'] for previous in parts[:index]) for index, row in enumerate(parts))
manifest = {'schema': 'hepta.hosted147-official-zip-offset-parts.v1',
            'artifact_id': artifact['id'], 'run_id': 40989068148,
            'source_commit': artifact['workflow_run']['head_sha'],
            'source_archive': {'path': archive.name, 'local_path': str(archive),
                               'bytes': offset, 'sha256': whole.hexdigest(), 'git_blob_sha1': whole_blob.hexdigest()},
            'chunk_bytes': chunk_bytes, 'part_count': len(parts), 'parts': parts,
            'ordered_ranges_cover_original_exactly': True, 'original_unchanged_during_hashing': True,
            'physical_part_files_created': False, 'remote_part_publication_verified_by_this_agent': False,
            'publication_method': 'Root may read each exact offset/length from source_archive and upload that immutable blob. Part files need not exist locally. Restore helper expects the named downloaded part files.'}
(HERE/'raw-parts.json').write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
print(json.dumps({key: value for key, value in manifest.items() if key != 'parts'}, indent=2))
