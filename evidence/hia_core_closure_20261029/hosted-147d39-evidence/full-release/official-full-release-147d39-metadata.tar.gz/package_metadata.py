#!/usr/bin/env python3
"""Archive read-only full-release metadata without duplicating the original ZIP."""
from pathlib import Path
import gzip
import hashlib
import json
import stat
import tarfile

HERE = Path(__file__).resolve().parent
NAME = 'official-full-release-147d39-metadata.tar.gz'
EXCLUDED = {'official-full-release-147d39.zip', NAME, 'metadata-retention.json',
            'metadata-archive-receipt.json', 'publication-metadata.json',
            'package.stdout.log', 'package.stderr.log'}


def identity(path):
    st = path.stat()
    h = hashlib.sha256()
    g = hashlib.sha1(f'blob {st.st_size}\0'.encode())
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
            g.update(chunk)
    return {'bytes': st.st_size, 'sha256': h.hexdigest(), 'git_blob_sha1': g.hexdigest(),
            'mode': oct(stat.S_IMODE(st.st_mode))}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


rows = []
for path in sorted(HERE.rglob('*')):
    if path.is_dir():
        continue
    rel = str(path.relative_to(HERE))
    if rel in EXCLUDED:
        continue
    assert path.is_file() and not path.is_symlink(), rel
    assert not rel.endswith('.partial'), 'Unfinished download/restoration must be classified before packaging'
    rows.append({'path': rel, **identity(path)})
manifest = {'schema': 'hepta.hosted147-official-full-metadata-retention.v1',
            'source_commit': '147d39c4a9d3ded00fb5d22439493bc006a8b76d',
            'source_tree': '2050ec5e447ae5191ac2e685ba463292b2d2d3fe',
            'run_id': 40989068148, 'artifact_id': 12952846418,
            'files': rows, 'files_count': len(rows), 'total_bytes': sum(row['bytes'] for row in rows),
            'original_zip_retained_separately_by_ordered_offset_parts': True,
            'private_signed_transport_excluded': True,
            'actual_current_and_historical_observations_preserved_separately': True}
save(HERE/'metadata-retention.json', manifest)
members = rows + [{'path': 'metadata-retention.json', **identity(HERE/'metadata-retention.json')}]
with (HERE/NAME).open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for row in members:
                item = tarfile.TarInfo(row['path'])
                item.size, item.mode, item.mtime = row['bytes'], int(row['mode'], 8), 0
                with (HERE/row['path']).open('rb') as stream:
                    archive.addfile(item, stream)
expected = {row['path']: row for row in members}
seen = set()
with tarfile.open(HERE/NAME, 'r:gz') as archive:
    for item in archive:
        assert item.isfile() and item.name in expected and item.name not in seen
        raw = archive.extractfile(item).read()
        row = expected[item.name]
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest() == row['git_blob_sha1']
        assert oct(item.mode) == row['mode']
        seen.add(item.name)
assert seen == set(expected)
decoded = 0
with gzip.open(HERE/NAME, 'rb') as stream:
    for chunk in iter(lambda: stream.read(1024*1024), b''):
        decoded += len(chunk)
for row in members:
    assert identity(HERE/row['path']) == {k: v for k, v in row.items() if k != 'path'}
receipt = {'schema': 'hepta.hosted147-official-full-metadata-archive.v1', 'archive': NAME,
           **identity(HERE/NAME), 'archive_members': len(members), 'input_files': len(rows),
           'uncompressed_member_bytes': sum(row['bytes'] for row in members),
           'decoded_tar_bytes': decoded,
           'all_paths_modes_bytes_sha256_git_blob_readbacks_passed': True,
           'gzip_eof_crc_consumed': True, 'all_selected_inputs_unchanged_after_readback': True}
save(HERE/'metadata-archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
