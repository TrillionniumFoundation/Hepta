#!/usr/bin/env python3
"""Package immutable host metadata; retain original ZIPs separately without duplication."""
from pathlib import Path
import gzip
import hashlib
import json
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
NAME = 'hosted-147d39-host-audit-metadata.tar.gz'
EXCLUDED = {NAME, 'host-metadata-retention.json', 'host-metadata-archive-receipt.json',
            'host-publication-metadata.json', 'package-host.stdout.log', 'package-host.stderr.log'}
DIRECTORIES = {'metadata', 'job-logs', 'download-receipts', 'inventories', 'host-report-audits', 'auditor-development'}


def identity(path):
    metadata = path.stat()
    sha = hashlib.sha256()
    blob = hashlib.sha1(f'blob {metadata.st_size}\0'.encode())
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            sha.update(chunk)
            blob.update(chunk)
    return {'bytes': metadata.st_size, 'sha256': sha.hexdigest(), 'git_blob_sha1': blob.hexdigest(),
            'mode': oct(stat.S_IMODE(metadata.st_mode))}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


rows = []
for path in sorted(ROOT.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT)
    if str(rel) in EXCLUDED:
        continue
    selected = len(rel.parts) == 1 or rel.parts[0] in DIRECTORIES
    if rel.parts[0] == 'extracted':
        selected = path.suffix in {'.json', '.log', '.stdout', '.stderr', '.bin'}
    if not selected:
        continue
    assert not path.is_symlink()
    rows.append({'path': str(rel), **identity(path)})
manifest = {'schema': 'hepta.hosted147-host-metadata-retention.v1',
            'source_commit': '147d39c4a9d3ded00fb5d22439493bc006a8b76d',
            'source_tree': '2050ec5e447ae5191ac2e685ba463292b2d2d3fe',
            'files': rows, 'files_count': len(rows), 'total_bytes': sum(row['bytes'] for row in rows),
            'original_zip_files_retained_separately': True, 'private_signed_transport_excluded': True,
            'only_completed_host_scopes_audited': True, 'full_release_not_yet_audited': True}
save(ROOT/'host-metadata-retention.json', manifest)
members = rows + [{'path': 'host-metadata-retention.json', **identity(ROOT/'host-metadata-retention.json')}]
with (ROOT/NAME).open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for row in members:
                info = tarfile.TarInfo(row['path'])
                info.size, info.mode, info.mtime = row['bytes'], int(row['mode'], 8), 0
                with (ROOT/row['path']).open('rb') as stream:
                    archive.addfile(info, stream)
expected = {row['path']: row for row in members}
seen = set()
with tarfile.open(ROOT/NAME, 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name in expected and member.name not in seen
        raw = archive.extractfile(member).read()
        row = expected[member.name]
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest() == row['git_blob_sha1']
        assert oct(member.mode) == row['mode']
        seen.add(member.name)
assert seen == set(expected)
decoded = 0
with gzip.open(ROOT/NAME, 'rb') as stream:
    for chunk in iter(lambda: stream.read(1024*1024), b''):
        decoded += len(chunk)
for row in members:
    assert identity(ROOT/row['path']) == {k: v for k, v in row.items() if k != 'path'}
receipt = {'schema': 'hepta.hosted147-host-metadata-archive.v1', 'archive': NAME, **identity(ROOT/NAME),
           'archive_members': len(members), 'input_files': len(rows),
           'uncompressed_member_bytes': sum(row['bytes'] for row in members), 'decoded_tar_bytes': decoded,
           'all_paths_modes_bytes_sha256_git_blob_readbacks_passed': True,
           'gzip_eof_crc_consumed': True, 'all_selected_inputs_unchanged_after_readback': True}
save(ROOT/'host-metadata-archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
