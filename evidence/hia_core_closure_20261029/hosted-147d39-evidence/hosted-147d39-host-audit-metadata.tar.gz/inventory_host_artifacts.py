#!/usr/bin/env python3
"""Inventory and retain every original host ZIP member without executing payloads."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
PRIVATE = ROOT.parent / 'hosted-147d39-private-transport'


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


signed_urls = [json.loads(path.read_text())['download_url'].encode() for path in PRIVATE.glob('*.json')]
summary = []
for path in sorted((ROOT / 'raw-artifacts').glob('*.zip')):
    aid = int(path.stem)
    expected = json.loads((ROOT / 'download-receipts' / f'{aid}.json').read_text())
    original = identity(path.read_bytes())
    assert original['bytes'] == expected['bytes'] and original['sha256'] == expected['sha256']
    members = []
    names = set()
    with zipfile.ZipFile(path) as archive:
        for member in archive.infolist():
            name = member.filename
            parts = PurePosixPath(name).parts
            assert name not in names and not name.startswith('/') and '..' not in parts and '\\' not in name
            assert not member.flag_bits & 1, name
            names.add(name)
            mode = member.external_attr >> 16
            assert not stat.S_ISLNK(mode), name
            if member.is_dir():
                continue
            raw = archive.read(member)  # zipfile consumes and checks each member CRC.
            assert len(raw) == member.file_size
            assert not any(url in raw for url in signed_urls), name
            info = {'path': name, **identity(raw), 'crc32': f'{member.CRC:08x}',
                    'compressed_bytes': member.compress_size, 'original_external_attr': member.external_attr,
                    'original_unix_mode': oct(mode), 'zip_crc_passed': True}
            members.append(info)
            destination = ROOT / 'extracted' / str(aid) / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as output:
                output.write(raw)
            assert identity(destination.read_bytes()) == {key: info[key] for key in ('bytes', 'sha256', 'git_blob_sha1')}
    result = {'schema': 'hepta.hosted147-zip-inventory.v1', 'artifact_id': aid,
              'scope': expected['scope'], 'zip': {**original, 'path': str(path.relative_to(ROOT))},
              'members': members, 'members_count': len(members),
              'uncompressed_bytes': sum(row['bytes'] for row in members),
              'all_member_crc_and_extracted_readbacks_passed': True,
              'no_private_signed_download_url_in_members': True}
    (ROOT / 'inventories').mkdir(exist_ok=True)
    (ROOT / 'inventories' / f'{aid}.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    summary.append({key: result[key] for key in result if key != 'members'})
    print(json.dumps({key: result[key] for key in ('artifact_id', 'scope', 'members_count', 'uncompressed_bytes')}), flush=True)
(ROOT / 'host-zip-inventory-summary.json').write_text(json.dumps({'artifacts': summary,
    'artifacts_count': len(summary), 'all_crc_readbacks_passed': True,
    'total_original_zip_bytes': sum(row['zip']['bytes'] for row in summary),
    'total_members': sum(row['members_count'] for row in summary),
    'total_uncompressed_bytes': sum(row['uncompressed_bytes'] for row in summary)}, indent=2, sort_keys=True) + '\n')
