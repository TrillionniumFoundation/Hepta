#!/usr/bin/env python3
"""Retain original official ZIP bytes; signed transport stays outside evidence."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import datetime
import hashlib
import json
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
PRIVATE = ROOT.parent / 'hosted-147d39-private-transport'
HEAD = '147d39c4a9d3ded00fb5d22439493bc006a8b76d'


def download(item):
    scope, artifact = item
    aid = artifact['id']
    assert artifact['workflow_run']['head_sha'] == HEAD
    transport = json.loads((PRIVATE / f'{aid}.json').read_text())
    destination = ROOT / 'raw-artifacts' / f'{aid}.zip'
    assert not destination.exists(), destination
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    sha = hashlib.sha256()
    count = 0
    partial = destination.with_suffix('.zip.partial')
    with urllib.request.urlopen(transport['download_url'], timeout=60) as response:
        status = response.status
        headers = {key: response.headers.get(key) for key in ('Content-Length', 'Content-Type', 'Last-Modified', 'ETag')}
        with partial.open('wb') as output:
            for chunk in iter(lambda: response.read(1024 * 1024), b''):
                output.write(chunk)
                sha.update(chunk)
                count += len(chunk)
    assert count == artifact['size_in_bytes'], (aid, count, artifact['size_in_bytes'])
    assert 'sha256:' + sha.hexdigest() == artifact['digest'], aid
    partial.rename(destination)
    return {'scope': scope, 'artifact_id': aid, 'artifact_name': artifact['name'],
            'source_head': HEAD, 'path': str(destination.relative_to(ROOT)),
            'bytes': count, 'sha256': sha.hexdigest(), 'official_size_and_digest_match': True,
            'http_status': status, 'safe_response_headers': headers,
            'started_utc': started, 'wall_seconds': time.monotonic() - begin,
            'private_signed_transport_excluded': True}


items = []
for scope in ('cpp', 'abi'):
    metadata = json.loads((ROOT / 'metadata' / 'observation01' / f'{scope}-artifacts.json').read_text())
    items += [(scope, artifact) for artifact in metadata['artifacts']]
results = []
with ThreadPoolExecutor(max_workers=4) as pool:
    pending = {pool.submit(download, item): item for item in items}
    for task in as_completed(pending):
        result = task.result()
        results.append(result)
        (ROOT / 'download-receipts').mkdir(exist_ok=True)
        (ROOT / 'download-receipts' / f"{result['artifact_id']}.json").write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
        print(json.dumps({key: result[key] for key in ('scope', 'artifact_id', 'bytes', 'official_size_and_digest_match')}), flush=True)
(ROOT / 'download-summary.json').write_text(json.dumps({'schema': 'hepta.hosted147-original-zip-downloads.v1', 'artifacts': sorted(results, key=lambda row: row['artifact_id']), 'count': len(results), 'total_bytes': sum(row['bytes'] for row in results), 'all_official_digests_match': True}, indent=2, sort_keys=True) + '\n')
