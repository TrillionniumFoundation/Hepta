#!/usr/bin/env python3
"""Read-only audit of original hosted records, bytes, scopes and finite outputs."""
from pathlib import Path
from collections import Counter
import base64
import datetime
import hashlib
import json
import re
import struct
import subprocess
import traceback

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'hepta-rust-records-public'
HEAD = '147d39c4a9d3ded00fb5d22439493bc006a8b76d'
TREE = '2050ec5e447ae5191ac2e685ba463292b2d2d3fe'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def norm(path):
    return re.sub('/+', '/', str(path).replace('\\', '/'))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE
tree_raw = git('ls-tree', '-r', '-z', HEAD)
entries = {}
for record in tree_raw.split(b'\0'):
    if not record:
        continue
    identity, name = record.split(b'\t', 1)
    mode, kind, blob = identity.decode().split()
    assert kind == 'blob'
    entries[name.decode()] = {'mode': mode, 'git_blob_sha1': blob}
source_reads = {}
cache = {}
batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=SOURCE,
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE)


def source_bytes(path):
    path = norm(path)
    if path not in cache:
        item = entries[path]
        batch.stdin.write((item['git_blob_sha1'] + '\n').encode())
        batch.stdin.flush()
        blob, kind, size = batch.stdout.readline().split()
        size = int(size)
        assert kind == b'blob' and blob.decode() == item['git_blob_sha1']
        raw = batch.stdout.read(size)
        assert len(raw) == size and batch.stdout.read(1) == b'\n'
        assert hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + raw).hexdigest() == blob.decode()
        cache[path] = raw
        source_reads[path] = {**item, 'bytes': size, 'sha256': sha(raw)}
    return cache[path]


compiler = hashlib.sha256()
for path in sorted(p for p in entries if p.startswith('hepta/') and p.count('/') == 1 and p.endswith('.py')):
    compiler.update(Path(path).name.encode() + b'\0' + source_bytes(path) + b'\0')
compiler_sha = compiler.hexdigest()


WINDOWS_EXAMPLE_CRLF_PATHS = {
    'examples/cpp/upgrade/adapter.hpp', 'examples/cpp/upgrade/consumer.hepta',
    'examples/cpp/upgrade/contract.json', 'examples/cpp/upgrade/harness.cpp',
    'examples/cpp/upstream_host/README.md', 'examples/cpp/upstream_host/consumer.hepta',
    'examples/cpp/upstream_host/harness.cpp',
}


def check_source_map(mapping, prefix='', windows_crlf_bindings=None):
    for name, digest in mapping.items():
        path = prefix + norm(name)
        raw = source_bytes(path)
        if sha(raw) != digest:
            assert windows_crlf_bindings is not None and path in WINDOWS_EXAMPLE_CRLF_PATHS, (name, 'source differs from public Git blob')
            assert b'\r' not in raw and sha(raw.replace(b'\n', b'\r\n')) == digest, name
            windows_crlf_bindings.append({'path': path, 'raw_git_sha256': sha(raw), 'raw_git_bytes': len(raw),
                'reported_host_sha256': digest, 'matching_crlf_representation_bytes': len(raw.replace(b'\n', b'\r\n')),
                'representation': 'public Git LF bytes transformed to CRLF',
                'raw_worktree_equals_git_blob': False,
                'actual_host_file_bytes_separately_retained': False,
                'evidence': 'exact report digest matches the explicit CRLF representation; checkout log names exact public commit; tracked status is reported clean; these example paths have no fixed eol attribute'})
    return len(mapping)


def check_inventory_files(directory, prefix, rows, inventory):
    count = 0
    if isinstance(rows, dict):
        rows = [{'path': name, **identity} for name, identity in rows.items()]
    for row in rows:
        name = prefix + norm(row['path'])
        assert name in inventory, name
        actual = inventory[name]
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), name
        assert sha((directory / name).read_bytes()) == row['sha256'], name
        count += 1
    return count


def artifact_path(path):
    path = norm(path)
    return path.split('/artifacts/', 1)[1] if '/artifacts/' in path else None


def check_streams(node, directory, counts):
    if isinstance(node, dict):
        for channel in ('stdout', 'stderr'):
            if channel + '_bytes_base64' in node:
                raw = base64.b64decode(node[channel + '_bytes_base64'], validate=True)
                assert sha(raw) == node[channel + '_sha256']
                name = artifact_path(node[channel + '_path'])
                assert name is not None and (directory / name).read_bytes() == raw, node[channel + '_path']
                assert raw.decode('utf-8', errors='replace') == node[channel]
                counts['original_process_stream_bindings'] += 1
            elif channel + '_raw_base64' in node:
                raw = base64.b64decode(node[channel + '_raw_base64'], validate=True)
                assert sha(raw) == node[channel + '_raw_sha256'] and len(raw) == node[channel + '_raw_bytes']
                counts['embedded_raw_failure_stream_bindings'] += 1
        for value in node.values():
            check_streams(value, directory, counts)
    elif isinstance(node, list):
        for value in node:
            check_streams(value, directory, counts)


def executable_shape(raw, system, machine):
    if system == 'Linux':
        assert raw[:6] == b'\x7fELF\x02\x01'
        assert struct.unpack_from('<H', raw, 18)[0] == {'x86_64': 62, 'aarch64': 183}[machine]
        return 'ELF64'
    if system == 'Darwin':
        assert raw[:4] == b'\xcf\xfa\xed\xfe'
        assert struct.unpack_from('<I', raw, 4)[0] == {'x86_64': 0x1000007, 'aarch64': 0x100000c}[machine]
        return 'Mach-O64'
    assert system == 'Windows' and raw[:2] == b'MZ'
    offset = struct.unpack_from('<I', raw, 60)[0]
    assert raw[offset:offset+4] == b'PE\0\0'
    assert struct.unpack_from('<H', raw, offset+4)[0] == {'x86_64': 0x8664, 'aarch64': 0xaa64}[machine]
    return 'PE32+'


def tests(directory):
    rows = []
    for path in sorted(directory.glob('*-tests.log')):
        text = path.read_text(errors='replace')
        counts = re.findall(r'Ran (\d+) tests? in ([\d.]+)s', text)
        verdict = re.findall(r'^OK(?: \([^\n]*\))?$', text, re.M)
        assert len(counts) == len(verdict) == 1, path
        rows.append({'path': path.name, 'tests': int(counts[0][0]), 'seconds': float(counts[0][1]),
                     'verdict': verdict[0], 'nonordinary_lines': [line for line in text.splitlines()
                         if re.search(r'\.\.\. (skipped|expected failure|unexpected success|FAIL|ERROR)', line)]})
    return rows


def audit_cpp(directory, inventory):
    report = read(directory / 'cpp-upstream-host.json')
    assert report == read(directory / 'cpp-upstream-host/qualification.json')
    assert report['ok'] is True and report['status'] == 'passed'
    assert report['source_commit'] == HEAD and report['tracked_source_status'] == ''
    assert report['inputs_unchanged'] is True and report['compiler_sha256'] == compiler_sha
    crlf_bindings = [] if report['host']['system'] == 'Windows' else None
    selected = check_source_map(report['source_inputs'], windows_crlf_bindings=crlf_bindings)
    retained = check_inventory_files(directory, 'cpp-upstream-host/', report['retained_files'], inventory)
    stream_counts = Counter()
    check_streams(report, directory, stream_counts)
    host = report['host']
    identity = report['cxx']['identity']
    assert (host['system'], host['machine']) == (identity['system'], identity['machine'])
    assert report['cxx']['macro_probe']['exit_code'] == 0
    assert report['claims']['actual_reported_host_executed'] is True
    versions = []
    for row in report['versions']:
        observed, process = row['observed'], row['execution']
        assert row['status'] == 'passed' and process['exit_code'] == 0
        assert json.loads(process['stdout']) == observed
        assert observed['version'] == row['version']
        for case in observed['cases']:
            assert (case['direct_status'], case['direct_value']) == (case['hepta_status'], case['hepta_value'])
            assert case['live_delta'] == 0
        for key, value in {'lifecycle_cases': 32, 'borrowed_input_overwritten': 32, 'stale_reads': 32,
                           'duplicate_destroys': 32, 'refused_mutations': 64, 'pointer_guards': 4,
                           'malformed_constructor': 1, 'concurrent_calls': 1024, 'ordinary_live_delta': 0}.items():
            assert observed[key] == value, (row['version'], key)
        assert observed['cancellation'] == {'requested': 7, 'committed': 3, 'value': 107, 'replayed': 0}
        assert observed['registry_ordinary_allocations_retained'] > 0
        raw = (directory / artifact_path(process['argv'][0])).read_bytes()
        assert len(raw) == row['executable']['bytes'] and sha(raw) == row['executable']['sha256']
        fmt = executable_shape(raw, host['system'], host['machine'])
        assert fmt == row['executable']['format']
        for name, digest in row['generated_identity'].items():
            assert sha((directory / 'cpp-upstream-host' / row['version'] / 'bridge' / name).read_bytes()) == digest
        upstream = row['source_and_license']
        fixture = 'tests/fixtures/cpp_upgrade/'
        possible = [p for p in entries if p.endswith('/' + upstream['header'])]
        assert len(possible) == 1
        raw_header = source_bytes(possible[0])
        assert sha(raw_header) == upstream['sha256'] and len(raw_header) == upstream['bytes']
        license_paths = [p for p in entries if p.endswith('/' + upstream['license'])]
        assert len(license_paths) == 1 and sha(source_bytes(license_paths[0])) == upstream['license_sha256']
        versions.append({'version': row['version'], 'cases': len(observed['cases']),
                         'observed_control_counts': {k: v for k, v in observed.items() if k != 'cases'},
                         'actual_retained_executable_format': fmt, 'executable': row['executable'],
                         'native_build': row['native'], 'upstream': upstream})
    wrong = report['wrong_code']
    assert wrong['status'] == 'rejected' and wrong['process']['exit_code'] == 2
    assert 'actual direct/Hepta result mismatch' in wrong['process']['stderr']
    failure = report['incompatible_signature']
    assert failure['status'] == 'rejected' and failure['ok'] is False
    rejected_process = failure['failure']['process']
    assert rejected_process['exit_code'] > 0
    assert 'HEPTA_CPP_METHOD_RESULT:hepta_cpp_json_upgrade_Document_sum' in rejected_process['stdout'] + rejected_process['stderr']
    return {'ok': True, 'scope': 'cpp_upstream_reuse', 'host': host, 'cxx': report['cxx'],
            'selected_source_file_hashes_match_public_git': selected - len(crlf_bindings or []),
            'selected_source_files_checked': selected,
            'windows_source_representation_bindings': crlf_bindings or [],
            'all_selected_worktree_file_hashes_equal_raw_git': not crlf_bindings,
            'report_inputs_unchanged': True,
            'separate_after_source_map_retained': False, 'retained_file_bindings_checked': retained,
            'process_stream_bindings': dict(stream_counts), 'versions': versions,
            'wrong_code_exit': wrong['process']['exit_code'], 'incompatible_signature_exit': rejected_process['exit_code'],
            'claims': report['claims'], 'tests': tests(directory),
            'tool_binaries_independently_read_from_host_zip': False}


def scalar_oracle(a, b):
    assert b != 0 and (a, b) != (-2147483648, -1)
    q = abs(a) // abs(b)
    q = -q if (a < 0) != (b < 0) else q
    floor = a // b
    rem = a % abs(b)
    euclid = (a - rem) // b
    return [q, floor, euclid, a - q*b, a % b, rem]


def audit_abi(directory, inventory):
    report = read(directory / 'native-host.json')
    assert report['status'] == 'passed' and report['compiler_sha256'] == compiler_sha
    assert report['frontend']['ok'] is True
    assert report['frontend']['backend']['crate_type'] == report['native_object']['crate_type'] == 'obj'
    assert report['frontend']['backend']['check_only'] is True and report['native_object']['check_only'] is False
    assert report['native_object']['ok'] is True
    expected = report['matrix']['expected_foreign_calls_per_run']
    raw_executions = []
    for command in report['commands']:
        try:
            value = json.loads(command['stdout'])
        except (ValueError, TypeError):
            continue
        if isinstance(value, dict) and value.get('status') == 'passed' and 'foreign_calls' in value:
            assert command['returncode'] == 0 and value['foreign_calls'] == expected
            raw_executions.append(value)
    assert len(raw_executions) == len(report['executions']) == 2
    for row in report['executions']:
        assert row['returncode'] == 0 and row['layout_checked'] is True and row['observed'] in raw_executions
    assert report['negative_control']['status'] == 'rejected_as_expected'
    assert report['negative_control']['returncode'] != 0
    assert len(report['type_negative_controls']) == 3
    for control in report['type_negative_controls']:
        assert control['status'] == 'rejected_as_expected' and control['returncode'] != 0
        assert any(control['diagnostic_marker'] in command['stdout'] + command['stderr'] and
                   command['returncode'] == control['returncode'] for command in report['commands'])
    available_hashes = {row['sha256'] for row in inventory.values()}
    abi_binaries = [report['native_object']['artifact_sha256'], *report['executable_sha256s'], report['negative_control']['artifact_sha256']]
    preflight = read(directory / 'original-type-preflight/qualification.json')
    assert preflight == read(directory / 'original-type-preflight.json')
    assert preflight['ok'] is True and preflight['native_program_executions'] == 0
    assert preflight['rust_compiler_invocations'] == 0
    for row in preflight['cases']:
        assert row['passed'] is True
        assert sha((directory / artifact_path(row['report'])).read_bytes()) == row['report_sha256']
    worker = preflight['reader_identity']['worker']
    assert sha(source_bytes('hepta/c_parameter_types.py')) == worker['sha256']
    stb = read(directory / 'stb-divide-host/qualification.json')
    assert stb == read(directory / 'stb-divide-host.json')
    assert stb['ok'] is True and stb['source_unchanged_during_run'] is True
    assert stb['source_before'] == stb['source_after']
    binding = stb['source_before']
    assert binding['commit'] == HEAD and binding['tree'] == TREE and binding['status'] == ''
    selected = check_source_map(binding['implementation_files'])
    fixtures = check_source_map(binding['fixture_files'], 'tests/fixtures/c_migration/stb_divide/')
    retained = check_inventory_files(directory, 'stb-divide-host/', stb['artifacts'], inventory)
    corpus = [json.loads(line) for line in (directory / 'stb-divide-host/cases.jsonl').read_text().splitlines()]
    assert len(corpus) == stb['corpus']['unique_inputs']
    assert Counter(row['category'] for row in corpus) == stb['corpus']['categories']
    assert len({(row['a'], row['b']) for row in corpus}) == len(corpus)
    for row in corpus:
        assert row['expected'] == scalar_oracle(row['a'], row['b'])
    variants = []
    observed_calls = 0
    traps = 0
    for variant in stb['variants']:
        assert variant['migration']['ok'] is True and variant['migration']['declaration_inventory_complete'] is True
        executions = []
        for execution in variant['executions']:
            for key in ('caller_sha256', 'target_sha256', 'observations_sha256'):
                assert execution[key] in available_hashes, (variant['name'], key)
            matching = [name for name, ident in inventory.items() if ident['sha256'] == execution['observations_sha256']
                        and name.startswith('stb-divide-host/' + variant['name'] + '/')]
            assert len(matching) == 1
            raw_rows = (directory / matching[0]).read_text().splitlines()
            assert len(raw_rows) == len(corpus)
            for original, actual in zip(corpus, raw_rows):
                values = list(map(int, actual.split('\t')))
                assert values == [original['a'], original['b']] + original['expected'] * 3
            summary = execution['summary']
            assert summary['cases'] == len(corpus)
            assert summary['native_function_observations'] == len(corpus) * 12
            assert summary['allocation_probe'] is True and summary['resource_before'] == summary['resource_after']
            assert any(p['returncode'] == 0 and p['stdout'].strip() == json.dumps(summary, separators=(',', ':'))
                       for p in stb['processes']) or any(p['returncode'] == 0 and _json_equal(p['stdout'], summary)
                                                       for p in stb['processes'])
            observed_calls += summary['native_function_observations']
            executions.append({**execution, 'actual_tsv_path': matching[0], 'actual_tsv_rows_checked': len(raw_rows)})
        for trap in variant['traps']:
            assert trap['original_c_called'] is False and trap['exit_code'] != 0
            traps += 1
        variants.append({'name': variant['name'], 'flags': variant['flags'], 'executions': executions,
                         'hia': variant['hia'], 'traps_count': len(variant['traps'])})
    assert observed_calls == stb['totals']['native_function_observations']
    assert traps == stb['totals']['native_target_only_trap_processes']
    assert stb['wrong_code_control']['actual_native_executed'] is True and stb['wrong_code_control']['rejected_by_functional_oracle'] is True
    assert stb['wrong_code_control']['exit_code'] != 0
    return {'ok': True, 'scope': 'finite_frontend_rust_object_abi_and_scalar_c_component',
            'host': report['host'], 'c_compiler': report['c_compiler'],
            'rust_toolchain': report['native_object']['toolchain'],
            'matrix_dimensions': {k: v for k, v in report['matrix'].items() if k not in ('aggregate_fields', 'pointer_types')},
            'actual_raw_success_outputs': raw_executions, 'executions': report['executions'],
            'native_matrix_binary_hashes_present_in_zip': sum(digest in available_hashes for digest in abi_binaries),
            'native_matrix_binary_hashes_declared': len(abi_binaries),
            'native_matrix_bytes_retention_scope': 'Commands and output reports retained; original temporary ABI object/executables may be absent. C-component caller/target bytes are separately retained and checked.',
            'abi_negative_control': report['negative_control'], 'type_negative_controls': report['type_negative_controls'],
            'abi_claims': report['claims'], 'abi_limits': report['limits'],
            'preflight': {'status': preflight['status'], 'cases': preflight['cases'], 'reader_identity': preflight['reader_identity'],
                          'process_limits': preflight['process_limits'], 'claims': preflight['claims'], 'limits': preflight['limits'],
                          'native_program_executions': preflight['native_program_executions']},
            'stb': {'source_before_after_equal': True, 'source_commit': binding['commit'], 'source_tree': binding['tree'],
                    'selected_implementation_files_matched_to_public_git': selected, 'fixture_files_matched_to_public_git': fixtures,
                    'retained_file_bindings_checked': retained, 'variants': variants, 'totals': stb['totals'], 'scope': stb['scope'],
                    'claims': stb['claims'], 'resource_scope': stb['resource_scope'],
                    'canonical_corpus_sha256': sha(json.dumps(corpus, sort_keys=True, separators=(',', ':')).encode()),
                    'raw_input_sha256': stb['corpus']['input_sha256'], 'wrong_code_control': stb['wrong_code_control'],
                    'refusal_controls': stb['refusal_controls'], 'cpp_entry_refusal': stb['cpp_entry_refusal']},
            'tests': tests(directory), 'tool_binaries_independently_read_from_host_zip': False}


def _json_equal(text, expected):
    try:
        return json.loads(text) == expected
    except (ValueError, TypeError):
        return False


receipts = read(ROOT / 'download-summary.json')['artifacts']
all_results = []
for item in receipts:
    aid = item['artifact_id']
    directory = ROOT / 'extracted' / str(aid)
    inventory = {row['path']: row for row in read(ROOT / 'inventories' / f'{aid}.json')['members']}
    setup = (directory / 'native-host-setup.log').read_text(errors='replace')
    assert HEAD in setup
    try:
        result = audit_cpp(directory, inventory) if item['scope'] == 'cpp' else audit_abi(directory, inventory)
        result.update({'artifact_id': aid, 'artifact_name': item['artifact_name'], 'source_head': HEAD,
                       'zip_sha256': item['sha256'], 'setup_log_exact_head_present': True})
    except Exception as error:
        result = {'artifact_id': aid, 'artifact_name': item['artifact_name'], 'ok': False,
                  'auditor_exception': repr(error), 'traceback': traceback.format_exc()}
    save(ROOT / 'host-report-audits' / f'{aid}.json', result)
    all_results.append(result)
    print(json.dumps({'artifact_id': aid, 'ok': result['ok'], 'scope': item['scope'], 'error': result.get('auditor_exception')}), flush=True)
batch.stdin.close()
batch.wait()
source_binding = {'public_commit': HEAD, 'public_tree': TREE, 'git_tracked_files': len(entries),
                  'compiler_python_source_aggregate_sha256': compiler_sha,
                  'source_objects_read_from_immutable_git': source_reads,
                  'local_worktree_modified': False, 'hosted_whole_tree_bytes_not_claimed': True}
save(ROOT / 'host-source-git-binding.json', source_binding)
(ROOT / 'source-commit.raw').write_bytes(git('cat-file', 'commit', HEAD))
result = {'schema': 'hepta.hosted147-actual-host-audit.v1', 'source_head': HEAD, 'source_tree': TREE,
          'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'ok': all(row['ok'] for row in all_results), 'artifacts_audited': len(all_results),
          'audit_results': [{k: row[k] for k in ('artifact_id', 'artifact_name', 'ok')} for row in all_results],
          'native_processes_reexecuted_by_auditor': 0, 'source_edits': False,
          'source_scope': 'Actual hosted selected source sets checked against immutable public Git objects; not an invented full per-host working-tree digest.',
          'full_release_audited_in_this_report': False,
          'P0_P7_fully_closed': False, 'general_abi_foreign_lifetime_or_cpp_migration_proved': False}
save(ROOT / 'host-audit-summary.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'audit_results'}, indent=2))
raise SystemExit(0 if result['ok'] else 1)
