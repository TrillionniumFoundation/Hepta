#!/usr/bin/env python3
"""Restore exact original Actions ZIP bytes; never execute archive contents."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
PRIVATE_TRANSFERS = Path('/tmp/hepta-recovered-fresh-downloads.json')
PART_BYTES = 4 * 1024 * 1024

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def recover(item):
    a = item['artifact']
    aid = a['id']
    source = a['workflow_run']['head_sha']
    url = TRANSFERS[aid]['file_uri']['download_url']
    assert url.startswith('https://')
    dest = ROOT / 'original-zips' / source / f'{aid}.zip'
    dest.parent.mkdir(parents=True, exist_ok=True)
    expected = a['digest'].removeprefix('sha256:')
    if dest.exists():
        data = dest.read_bytes()
    else:
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read(a['size_in_bytes'] + 1)
        assert len(data) == a['size_in_bytes'], (aid, 'size mismatch')
        assert digest(data) == expected, (aid, 'official digest mismatch')
        dest.write_bytes(data)
    assert len(data) == a['size_in_bytes'] and digest(data) == expected
    members = []
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None, (aid, 'CRC mismatch')
        for info in archive.infolist():
            name = PurePosixPath(info.filename)
            assert not name.is_absolute() and '..' not in name.parts, (aid, 'unsafe member path')
            member_data = archive.read(info)
            members.append({'name':info.filename, 'bytes':len(member_data), 'sha256':digest(member_data), 'crc32':info.CRC})
    logical = {'artifact_id':aid,'family':item['family'],'source_commit':source,
               'run_id':a['workflow_run']['id'],'artifact_name':a['name'],
               'bytes':len(data),'sha256':digest(data),'official_digest':a['digest'],
               'git_blob_sha':git_blob(data),'original_zip_path':str(dest.relative_to(ROOT)),
               'members':members,'member_count':len(members),
               'uncompressed_bytes':sum(m['bytes'] for m in members)}
    payloads = []
    if len(data) > 12 * 1024 * 1024:
        parts=[]
        for idx, offset in enumerate(range(0,len(data),PART_BYTES)):
            chunk=data[offset:offset+PART_BYTES]
            rel=f'raw-artifacts/{source}/{aid}.zip.parts/part-{idx:05d}.bin'
            target=ROOT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(chunk)
            record={'publication_path':rel,'local_path':str(target),'artifact_id':aid,'source_commit':source,
                    'part_index':idx,'offset':offset,'bytes':len(chunk),'sha256':digest(chunk),
                    'git_blob_sha':git_blob(chunk),'storage_representation':'raw-byte-part'}
            payloads.append(record);parts.append(record)
        rebuilt=b''.join((ROOT/p['publication_path']).read_bytes() for p in parts)
        assert rebuilt==data
        logical.update(storage_representation='raw-byte-parts-v1', parts=parts,
                       monolithic_zip_published=False, reassembly_verified=True)
    else:
        rel=f'raw-artifacts/{source}/{aid}.zip'
        target=ROOT/rel;target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():target.hardlink_to(dest)
        payloads.append({'publication_path':rel,'local_path':str(target),'artifact_id':aid,'source_commit':source,
                         'bytes':len(data),'sha256':digest(data),'git_blob_sha':git_blob(data),
                         'storage_representation':'whole-zip'})
        logical.update(storage_representation='whole-zip', publication_path=rel, monolithic_zip_published=True)
    return logical,payloads

if __name__=='__main__':
    ITEMS=json.loads((ROOT/'original-official-metadata.json').read_text())
    TRANSFERS={r['artifact_id']:r for r in json.loads(PRIVATE_TRANSFERS.read_text())}
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(recover,item):item['artifact']['id'] for item in ITEMS}
        for future in concurrent.futures.as_completed(futures):
            result=future.result();results.append(result)
            print(json.dumps({'recovered_artifact':result[0]['artifact_id'],'bytes':result[0]['bytes'],
                              'sha256':result[0]['sha256'],'members':result[0]['member_count']}),flush=True)
    logical=sorted([x[0] for x in results],key=lambda x:x['artifact_id'])
    physical=sorted([p for x in results for p in x[1]],key=lambda p:p['publication_path'])
    summary={'status':'passed','ok':True,'recovered_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'claim':'Byte recovery and integrity inspection only; no new test or native execution.',
             'logical_zip_count':len(logical),'physical_payload_count':len(physical),
             'original_zip_bytes':sum(x['bytes'] for x in logical),
             'zip_member_count':sum(x['member_count'] for x in logical),
             'uncompressed_bytes':sum(x['uncompressed_bytes'] for x in logical),
             'all_official_digests_matched':True,'all_zip_crc_checks_passed':True,
             'all_split_zip_reassemblies_byte_identical':True,
             'local_integrated_3614_run_raw_recovered':False,
             'frozen_supplement_archive_recovered':False,
             'missing_frozen_supplement_sha256':'f393f5872d4b602f523ff35268a658d5c3b81f59e5cfcdcb9f267bef8712fb67'}
    (ROOT/'recovered-archives.json').write_text(json.dumps(logical,indent=2)+'\n')
    (ROOT/'recovered-publication-payloads.json').write_text(json.dumps(physical,indent=2)+'\n')
    (ROOT/'recovery-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)
