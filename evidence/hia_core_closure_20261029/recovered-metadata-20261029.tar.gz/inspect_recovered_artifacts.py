#!/usr/bin/env python3
"""Read-only inspection of recovered original reports and raw Git source bytes."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'hepta'
SOURCE='1669ddc05a918e7c01b17e9262d4461130d44aaa'
PATTERNS={
 'github_classic':rb'gh[pousr]_[A-Za-z0-9]{30,}',
 'github_finegrained':rb'github_pat_[A-Za-z0-9_]{60,}',
 'openai_project':rb'sk-proj-[A-Za-z0-9_-]{40,}',
 'openai_legacy':rb'sk-[A-Za-z0-9]{40,}',
 'aws_access_key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'slack_token':rb'xox[baprs]-[A-Za-z0-9-]{20,}',
 'private_key':rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
 'azure_signed_url':rb'[?&]sig=[A-Za-z0-9%+/=_-]{30,}',
 'google_api_key':rb'AIza[0-9A-Za-z_-]{35}',
 'bearer_credential':rb'Authorization:\s*Bearer\s+[A-Za-z0-9._-]{30,}',
}
RX={k:re.compile(v) for k,v in PATTERNS.items()}
CACHE={}
def sha(data):return hashlib.sha256(data).hexdigest()
def original(path):
 path=path.replace('\\','/')
 if path not in CACHE:
  CACHE[path]=subprocess.check_output(['git','--no-replace-objects','-C',str(REPO),'show',f'{SOURCE}:{path}'])
 return CACHE[path]
def source_check(mapping):
 raw_count=0;crlf=[]
 for path,expected in mapping.items():
  data=original(path)
  if sha(data)==expected:raw_count+=1
  else:
   converted=data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
   assert sha(converted)==expected,('source mismatch beyond recorded CRLF conversion',path)
   crlf.append({'path':path.replace('\\','/'),'raw_git_sha256':sha(data),'report_sha256':expected,
                'mapping':'LF/CRLF-normalized text converted to CRLF; exact bytes hashed, not executed'})
 return {'bindings':len(mapping),'exact_raw_git_byte_matches':raw_count,
         'exact_crlf_checkout_matches':len(crlf),'all_bindings_raw_git_byte_identical':not crlf,
         'crlf_checkout_differences':crlf}
def walk(value):
 if isinstance(value,dict):
  yield value
  for v in value.values():yield from walk(v)
 elif isinstance(value,list):
  for v in value:yield from walk(v)

if __name__=='__main__':
 archives=json.loads((ROOT/'recovered-archives.json').read_text())
 checks=[];scan_hits=[];scanned=0;scan_bytes=0;copies=[]
 for a in archives:
  with zipfile.ZipFile(ROOT/a['original_zip_path']) as z:
   for info in z.infolist():
    data=z.read(info);scanned+=1;scan_bytes+=len(data)
    for name,rx in RX.items():
     if rx.search(data):scan_hits.append({'artifact_id':a['artifact_id'],'member':info.filename,'pattern':name})
   if a['source_commit']!=SOURCE:continue
   reports={n:json.loads(z.read(n)) for n in z.namelist() if n.endswith('qualification.json')}
   for name,report in reports.items():
    data=z.read(name);dest=ROOT/'reports'/str(a['artifact_id'])/name
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    copies.append({'path':str(dest.relative_to(ROOT)),'artifact_id':a['artifact_id'],
                   'member':name,'bytes':len(data),'sha256':sha(data)})
   row={'artifact_id':a['artifact_id'],'family':a['family'],'source_commit':SOURCE}
   if a['family']=='cpp':
    r=reports['cpp-upstream-host/qualification.json']
    assert r['ok'] is True and r['status']=='passed' and r['source_commit']==SOURCE
    assert r['inputs_unchanged'] is True
    assert [v['version'] for v in r['versions']]==['3.11.3','3.12.0']
    assert all(v['status']=='passed' for v in r['versions'])
    assert r['wrong_code']['status']=='rejected' and r['incompatible_signature']['status']=='rejected'
    for name,identity in r['retained_files'].items():
     data=z.read('cpp-upstream-host/'+name.replace('\\','/'))
     assert len(data)==identity['bytes'] and sha(data)==identity['sha256'],name
    row.update(status=r['status'],source_bindings=source_check(r['source_inputs']),
               retained_files_verified=len(r['retained_files']),versions=['3.11.3','3.12.0'],
               wrong_code_rejected=True,incompatible_signature_rejected=True)
   elif a['family']=='abi':
    r=reports['stb-divide-host/qualification.json'];pre=reports['original-type-preflight/qualification.json']
    assert r['ok'] is True and pre['ok'] is True
    assert r['source_before']==r['source_after'] and r['source_before']['commit']==SOURCE
    assert r['source_unchanged_during_run'] is True
    assert all(r['checks'].values())
    row.update(status=r['status'],source_bindings=source_check(r['source_before']['implementation_files']),
               original_type_preflight_status=pre['status'],checks=r['checks'],totals=r['totals'])
   elif a['family'].startswith('source-app'):
    r=reports['filecheck/qualification.json']
    assert r['ok'] is True and r['git']==SOURCE and r['status']=='prepared_not_measured'
    assert r['prepare_only'] is True and r['samples']==[]
    assert r['differential']['cases']==96 and r['differential']['native_calls']==768
    assert r['differential']['routes']==8 and len(r['resource_cases'])==48
    assert len(r['maintenance']['cases'])==4 and len(r['maintenance']['application'])==2
    assert r['maintenance']['human_effort_or_agent_productivity_measured'] is False
    assert all(v is False for v in r['claims'].values())
    refs=[]
    for value in walk(r):
     if not isinstance(value.get('path'),str) or not isinstance(value.get('sha256'),str):continue
     path=value['path'].replace('\\','/')
     marker='/artifacts/six-outcomes/'
     if marker not in path:continue
     member=path.split(marker,1)[1]
     if member not in z.namelist():continue
     data=z.read(member)
     assert sha(data)==value['sha256'],member
     if 'bytes' in value:assert len(data)==value['bytes'],member
     refs.append({'member':member,'sha256':sha(data),'bytes':len(data)})
    row.update(status=r['status'],source_bindings=source_check(r['source_bindings']),
               embedded_artifact_references_verified=len(refs),artifact_references=refs,
               differential_routes=8,differential_inputs=96,native_calls=768,resource_cases=48,
               maintenance_cases=4,whole_applications=2,samples=0,performance_improvement_claimed=False,
               human_effort_or_agent_productivity_measured=False,claims=r['claims'])
   checks.append(row)
 for path in sorted((ROOT/'job-logs').glob('*.log')):
  data=path.read_bytes();scanned+=1;scan_bytes+=len(data)
  for name,rx in RX.items():
   if rx.search(data):scan_hits.append({'path':str(path.relative_to(ROOT)),'pattern':name})
 assert len(checks)==16 and len([x for x in checks if x['family']=='abi'])==7
 assert len([x for x in checks if x['family']=='cpp'])==7
 summary={'status':'passed' if not scan_hits else 'credential_review_required','ok':not scan_hits,
          'source_commit':SOURCE,'inspected_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'claim':'Independent read-only recovered-byte consistency review; no new test/native execution.',
          'artifact_count':16,'abi_host_artifacts':7,'cpp_host_artifacts':7,'source_app_artifacts':2,
          'unique_raw_git_source_files_compared':len(CACHE),'checks':checks,
          'all_source_bindings_raw_git_byte_identical':all(x['source_bindings']['all_bindings_raw_git_byte_identical'] for x in checks),
          'all_bindings_exact_raw_or_recorded_crlf':True,
          'unaltered_report_copies':copies,'credential_scan':{'pattern_count':len(RX),
          'objects_scanned':scanned,'bytes_scanned':scan_bytes,'match_count':len(scan_hits),'matches':scan_hits},
          'local_integrated_3614_run_raw_recovered':False,'frozen_supplement_archive_recovered':False}
 (ROOT/'recovered-report-inspection.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k not in ('checks','unaltered_report_copies')},indent=2))
