#!/usr/bin/env python3
"""Exercise exact original/repaired JSON reader and C++ source-map methods.

Inputs are raw JSON members from synthetic ZIPs derived from the two real
Windows artifact JSON members. No host compiler, artifact or test suite runs.
"""
from pathlib import Path
import ast
import copy
import hashlib
import json
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / 'ci-current-699de39'
REPO = ROOT.parent / 'hepta'
HEAD = '699de39a8e92e0f083df316ecc5333fb3ecf8571'
WINDOWS_IDS = (12891623518, 12891739355)
OUT = ROOT / 'raw-json-controls'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def decode_inspect(raw):
    duplicates = []
    object_pair_counts = []
    def pairs(rows):
        value = {}
        object_pair_counts.append(len(rows))
        for key, item in rows:
            if key in value:
                duplicates.append({'key': key, 'previous_value': value[key], 'next_value': item})
            value[key] = item
        return value
    decoded = json.loads(raw, object_pairs_hook=pairs)
    return decoded, duplicates


def source_span(raw):
    text = raw.decode('utf-8')
    matches = list(re.finditer(r'"source_inputs"\s*:\s*\{', text))
    assert len(matches) == 1
    start = text.index('{', matches[0].start())
    mapping, end = json.JSONDecoder().raw_decode(text, start)
    assert isinstance(mapping, dict) and text[end - 1] == '}'
    return text, start, end


def inject_source_entry(raw, key, value, *, before=False):
    text, start, end = source_span(raw)
    entry = json.dumps(key) + ': ' + json.dumps(value)
    if before:
        result = text[:start + 1] + '\n  ' + entry + ',' + text[start + 1:]
    else:
        result = text[:end - 1] + ',\n  ' + entry + '\n' + text[end - 1:]
    return result.encode('utf-8')


def make_reader(path, blobs, label):
    raw = path.read_bytes()
    tree = ast.parse(raw, filename=str(path))
    wanted = {'read', 'report', 'source', 'cpp_sources'}
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Audit')
    methods = [copy.deepcopy(node) for node in cls.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
    assert {node.name for node in methods} == wanted
    helpers = [copy.deepcopy(node) for node in tree.body if isinstance(node, ast.FunctionDef)
               and node.name in {'digest', 'canonical', 'require', 'strict_json', 'strict_abi_observations'}]
    whitelist = next(ast.literal_eval(node.value) for node in tree.body
                     if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'WINDOWS_CRLF_EXAMPLES' for t in node.targets))
    module = ast.Module(body=helpers + [ast.ClassDef(name='Audit', bases=[], keywords=[], body=methods, decorator_list=[])], type_ignores=[])
    ast.fix_missing_locations(module)
    namespace = {'Path': Path, 'hashlib': hashlib, 'json': json, 're': re,
                 'ROOT': OUT / 'reader-output' / label,
                 'BLOBS': blobs, 'SOURCE_HASHES': {name: sha(data) for name, data in blobs.items()},
                 'WINDOWS_CRLF_EXAMPLES': whitelist, 'SHA': re.compile(r'[0-9a-f]{64}\Z')}
    exec(compile(module, str(path) + ':exact_reader_methods', 'exec'), namespace)
    return namespace['Audit'], namespace.get('strict_abi_observations'), {'source_path': str(path), 'source_sha256': sha(raw),
                                'exact_methods': sorted(wanted), 'exact_helpers': sorted(node.name for node in helpers)}


def observe(cls, fixture, label, abi_guard=None):
    record = {'implementation': label, 'phase': 'artifact_member_read_and_json_decode'}
    obj = cls()
    obj.artifact = {'id': int(sha(fixture['label'].encode())[:12], 16) + 1}
    obj.source_checks = []
    obj.report_names = []
    with zipfile.ZipFile(OUT / fixture['zip']) as archive:
        obj.z = archive
        obj.files = {item.filename: {'bytes': item.file_size} for item in archive.infolist()}
        try:
            report = obj.report(fixture['member'])
            obj.windows_paths = report['host']['system'] == 'Windows'
            if fixture['family'] == 'cpp':
                record['phase'] = 'cpp_source_map_admission'
                obj.cpp_sources(report['source_inputs'])
                record.update(status='accepted', parsed_source_entries=len(report['source_inputs']),
                              source_checks=obj.source_checks)
            else:
                record['phase'] = 'embedded_abi_stdout_json_admission'
                if abi_guard is not None:
                    abi_guard(report)
                # This is the frozen ABI reader's existing native=False frontend
                # validator, with child process creation prohibited as in Audit.abi.
                from tools.validate_native_host import validate_report
                original_popen = subprocess.Popen
                def no_native(*args, **kwargs):
                    raise RuntimeError('Native/compiler/test process prohibited in auditor control')
                try:
                    subprocess.Popen = no_native
                    validate_report(report)
                finally:
                    subprocess.Popen = original_popen
                record.update(status='accepted', native_programs_executed=0)
        except Exception as exc:
            record.update(status='rejected', error_type=type(exc).__name__, reason=str(exc))
    return record


def main():
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(REPO))
    OUT.mkdir(exist_ok=False)
    originals = []
    wanted = set()
    for artifact_id in WINDOWS_IDS:
        archive_path = INPUT / 'raw-artifacts' / (str(artifact_id) + '.zip')
        audit = json.loads((INPUT / 'content-audits' / (str(artifact_id) + '.json')).read_text())
        with archive_path.open('rb') as stream:
            archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert archive_sha == audit['official_archive']['sha256']
        with zipfile.ZipFile(archive_path) as archive:
            raw = archive.read('cpp-upstream-host.json')
        assert sha(raw) == audit['retained_members']['cpp-upstream-host.json']['sha256']
        report, duplicate_keys = decode_inspect(raw)
        assert not duplicate_keys
        mapping = report['source_inputs']
        normalized = [name.replace('\\', '/') for name in mapping]
        assert len(mapping) == len(set(normalized)) == 157
        wanted.update(normalized)
        original_name = 'inputs/' + str(artifact_id) + '-cpp-upstream-host.original.json'
        (OUT / original_name).parent.mkdir(exist_ok=True)
        (OUT / original_name).write_bytes(raw)
        originals.append({'artifact_id': artifact_id, 'raw': raw, 'report': report,
                          'archive_sha256': archive_sha, 'original_json': original_name,
                          'original_json_sha256': sha(raw), 'raw_decoded_duplicate_keys': duplicate_keys,
                          'raw_source_entries': len(mapping), 'normalized_unique_paths': len(set(normalized))})

    names = sorted(wanted)
    raw = subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), 'cat-file', '--batch'],
                                  input=''.join(HEAD + ':' + name + '\n' for name in names).encode())
    blobs, identities, offset = {}, [], 0
    for name in names:
        end = raw.index(b'\n', offset)
        blob, kind, size = raw[offset:end].decode().split()
        assert kind == 'blob'
        size = int(size)
        data = raw[end + 1:end + 1 + size]
        assert hashlib.sha1(('blob ' + str(size) + '\0').encode() + data).hexdigest() == blob
        blobs[name] = data
        identities.append({'path': name, 'git_blob': blob, 'bytes': size, 'sha256': sha(data)})
        offset = end + 2 + size
    assert offset == len(raw)
    dump(OUT / 'exact-source-blob-identities.json', {'source_commit': HEAD, 'files': identities})
    old_cls, old_guard, old_identity = make_reader(ROOT / 'audit_artifact_contents.original.py', blobs, 'original')
    new_cls, new_guard, new_identity = make_reader(ROOT / 'audit_artifact_contents.py', blobs, 'corrected')

    original = originals[0]
    mapping = original['report']['source_inputs']
    exact_key = next(name for name, digest in mapping.items() if name.replace('\\', '/').startswith('hepta/')
                     and sha(blobs[name.replace('\\', '/')]) == digest)
    exact_alias = exact_key.replace('\\', '/')
    assert exact_alias != exact_key and exact_alias not in mapping
    crlf_key = next(name for name in mapping if name.replace('\\', '/') == 'examples/cpp/upstream_host/consumer.hepta')
    crlf_alias = crlf_key.replace('\\', '/')
    assert crlf_alias != crlf_key and crlf_alias not in mapping
    assert mapping[crlf_key] != sha(blobs[crlf_alias])
    variants = [(f'actual-windows-{item["artifact_id"]}', item['raw'], False,
                 {'source_artifact_id': item['artifact_id'], 'mutation': None}) for item in originals]
    variants += [
        ('normalized-exact-same-value', inject_source_entry(original['raw'], exact_alias, mapping[exact_key]), True,
         {'original_key': exact_key, 'added_key': exact_alias, 'original_value': mapping[exact_key], 'added_value': mapping[exact_key]}),
        ('normalized-crlf-same-value', inject_source_entry(original['raw'], crlf_alias, mapping[crlf_key]), True,
         {'original_key': crlf_key, 'added_key': crlf_alias, 'original_value': mapping[crlf_key], 'added_value': mapping[crlf_key]}),
        ('normalized-crlf-conflicting-valid-lf-value', inject_source_entry(original['raw'], crlf_alias, sha(blobs[crlf_alias])), True,
         {'original_key': crlf_key, 'added_key': crlf_alias, 'original_value': mapping[crlf_key], 'added_value': sha(blobs[crlf_alias])}),
        ('duplicate-json-key-same-value', inject_source_entry(original['raw'], exact_key, mapping[exact_key]), True,
         {'original_key': exact_key, 'added_key': exact_key, 'original_value': mapping[exact_key], 'added_value': mapping[exact_key]}),
        ('duplicate-json-key-conflicting-earlier-value', inject_source_entry(original['raw'], exact_key, '0' * 64, before=True), True,
         {'original_key': exact_key, 'added_key': exact_key, 'original_value': mapping[exact_key], 'added_value': '0' * 64,
          'insertion': 'before existing valid value; old JSON decoder silently keeps the final value'}),
    ]
    variants = [(label, payload, changed, detail, 'cpp', 'cpp-upstream-host.json')
                for label, payload, changed, detail in variants]
    abi_id = 12891733575
    abi_archive_path = INPUT / 'raw-artifacts' / (str(abi_id) + '.zip')
    abi_audit = json.loads((INPUT / 'content-audits' / (str(abi_id) + '.json')).read_text())
    with abi_archive_path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == abi_audit['official_archive']['sha256']
    with zipfile.ZipFile(abi_archive_path) as archive:
        abi_raw = archive.read('native-host.json')
    assert sha(abi_raw) == abi_audit['retained_members']['native-host.json']['sha256']
    abi_report, duplicates = decode_inspect(abi_raw)
    assert not duplicates
    (OUT / 'inputs' / (str(abi_id) + '-native-host.original.json')).write_bytes(abi_raw)
    variants.append(('actual-abi-' + str(abi_id), abi_raw, False,
                     {'source_artifact_id': abi_id, 'mutation': None}, 'abi', 'native-host.json'))
    slot = (1 if abi_report['c_compiler']['family'] == 'msvc' else 3) + 1
    original_stdout = abi_report['commands'][slot]['stdout']
    original_observation, duplicates = decode_inspect(original_stdout)
    assert not duplicates and original_observation == abi_report['executions'][0]['observed']
    for name, key, injected in [('abi-stdout-duplicate-status-same-value', 'status', 'passed'),
                                ('abi-stdout-duplicate-status-conflicting-earlier-value', 'status', 'failed'),
                                ('abi-stdout-duplicate-foreign-calls-conflicting-earlier-value', 'foreign_calls', 0)]:
        text = original_stdout
        start = text.index('{')
        duplicate_stdout = text[:start + 1] + json.dumps(key) + ':' + json.dumps(injected) + ',' + text[start + 1:]
        value = copy.deepcopy(abi_report)
        value['commands'][slot]['stdout'] = duplicate_stdout
        payload = json.dumps(value, indent=2, sort_keys=True).encode() + b'\n'
        variants.append((name, payload, True,
                         {'source_artifact_id': abi_id, 'command_slot': slot, 'duplicate_embedded_key': key,
                          'earlier_value': injected, 'final_original_value': original_observation[key],
                          'embedded_stdout_raw': duplicate_stdout}, 'abi', 'native-host.json'))
    cases = []
    for label, payload, is_mutation, mutation, family, member_name in variants:
        json_path = OUT / 'inputs' / (label + '.json')
        json_path.write_bytes(payload)
        zip_path = OUT / 'fixtures' / (label + '.zip')
        zip_path.parent.mkdir(exist_ok=True)
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            member = zipfile.ZipInfo(member_name, date_time=(2026, 10, 29, 0, 0, 0))
            member.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(member, payload)
        decoded, duplicate_keys = decode_inspect(payload)
        fixture = {'label': label, 'family': family, 'member': member_name,
                   'zip': str(zip_path.relative_to(OUT)), 'json': str(json_path.relative_to(OUT)),
                   'raw_json_sha256': sha(payload), 'raw_json_bytes': len(payload),
                   'zip_sha256': sha(zip_path.read_bytes()), 'synthetic_mutation': is_mutation,
                   'mutation': mutation, 'raw_decoded_duplicate_keys': duplicate_keys}
        if family == 'cpp':
            fixture.update(old_decoder_visible_source_entries=len(decoded['source_inputs']),
                           old_decoder_normalized_unique_paths=len({k.replace('\\', '/') for k in decoded['source_inputs']}))
        else:
            fixture['embedded_decoded_duplicate_keys'] = decode_inspect(decoded['commands'][slot]['stdout'])[1]
        observations = [observe(old_cls, fixture, 'original', old_guard),
                        observe(new_cls, fixture, 'corrected', new_guard)]
        assert observations[0]['status'] == 'accepted', (label, observations)
        assert observations[1]['status'] == ('rejected' if is_mutation else 'accepted'), (label, observations)
        if is_mutation:
            expected = ('duplicate JSON key:' if label.startswith(('duplicate-json', 'abi-stdout'))
                        else 'ambiguous normalized C++ source path')
            assert expected in observations[1]['reason'], (label, observations)
        elif family == 'cpp':
            assert [r['count'] for r in observations[1]['source_checks']] == [150, 7]
        fixture['observations'] = observations
        cases.append(fixture)
        print(json.dumps({'case': label, 'original': observations[0]['status'], 'corrected': observations[1]['status'],
                          'synthetic_auditor_control': is_mutation}), flush=True)

    summary = {'schema': 'hepta.offline-auditor-raw-json-controls.v1', 'source_commit': HEAD,
               'entry_path': 'ZIP member -> exact Audit.read/report decoder -> exact C++ source methods or legacy ABI validator with repaired strict embedded-stdout guard',
               'original_implementation': old_identity, 'corrected_implementation': new_identity,
               'actual_windows_maps': [{k: v for k, v in item.items() if k not in ('raw', 'report')} for item in originals],
               'synthetic_negative_control_count': sum(c['synthetic_mutation'] for c in cases),
               'actual_unmodified_windows_control_count': 2,
               'actual_unmodified_abi_control_count': 1,
               'original_accepts_all_eight_synthetic_cases': True, 'corrected_rejects_all_eight_synthetic_cases': True,
               'cases': cases, 'native_programs_executed': 0, 'language_or_host_tests_added': 0,
               'original_zip_modified': False, 'ok': True}
    dump(OUT / 'controls.json', summary)
    print(json.dumps({'ok': True, 'synthetic_negative_controls': 8, 'unchanged_actual_windows_maps': 2,
                      'unchanged_actual_abi_report': 1,
                      'language_or_host_tests': 0}), flush=True)


if __name__ == '__main__':
    main()
