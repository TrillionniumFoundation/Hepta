#!/usr/bin/env python3
"""Freeze the offline auditor supplement without reading private transport files."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import re
import stat
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = 'hepta_699de39_offline_auditor_path_supplement_20261029.tar.gz'
GENERATED = {ARCHIVE, 'retention.json', 'credential-scan.json', 'archive-receipt.json', 'publication-payloads.json'}


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()}


def dump(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def main():
    source = ROOT.parent / 'evidence-next-20261029/collect_components.py'
    tree = ast.parse(source.read_bytes())
    patterns = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'PATTERNS' for t in n.targets))
    selected = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.parent != ROOT or
                      p.is_file() and p.name not in GENERATED)
    # The output log is deliberately outside this directory, so inputs cannot
    # grow while the archive is being built.
    assert all(not p.is_symlink() for p in selected)
    findings, file_bytes, zip_members, zip_bytes = [], 0, 0, 0
    def scan(label, data):
        for name, pattern in patterns.items():
            if re.search(pattern, data):
                findings.append({'path': label, 'pattern': name})
    for path in selected:
        data = path.read_bytes(); file_bytes += len(data)
        scan(str(path.relative_to(ROOT)), data)
        if path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                for member in archive.infolist():
                    raw = archive.read(member); zip_members += 1; zip_bytes += len(raw)
                    scan(str(path.relative_to(ROOT)) + '!' + member.filename, raw)
    assert not findings, findings
    dump('credential-scan.json', {'schema': 'hepta.auditor-supplement-credential-scan.v1',
         'pattern_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
         'pattern_count': len(patterns), 'pattern_names': sorted(patterns),
         'payload_files_scanned': len(selected), 'payload_bytes_scanned': file_bytes,
         'synthetic_zip_members_decoded': zip_members, 'synthetic_zip_bytes_scanned': zip_bytes,
         'findings': findings, 'private_transport_metadata_read': False,
         'scope': 'all retained payload files and decoded synthetic fixture ZIP members; derived hash-only manifests and this scan record are generated afterwards'})
    selected.append(ROOT / 'credential-scan.json')
    rows = []
    for path in sorted(selected):
        name = str(path.relative_to(ROOT)); safe = PurePosixPath(name)
        assert not safe.is_absolute() and '..' not in safe.parts and '\\' not in name
        data = path.read_bytes()
        rows.append({'path': name, 'mode': stat.S_IMODE(path.stat().st_mode), **identity(data)})
    dump('retention.json', {'schema': 'hepta.auditor-supplement-retention.v1', 'files': rows,
                           'files_excluding_this_manifest': len(rows),
                           'bytes_excluding_this_manifest': sum(r['bytes'] for r in rows)})
    retained = ROOT / 'retention.json'
    rows.append({'path': 'retention.json', 'mode': stat.S_IMODE(retained.stat().st_mode), **identity(retained.read_bytes())})
    archive_path = ROOT / ARCHIVE
    with tarfile.open(archive_path, 'w:gz') as archive:
        for row in sorted(rows, key=lambda item: item['path']):
            path = ROOT / row['path']
            info = archive.gettarinfo(str(path), arcname=row['path'])
            info.uid = info.gid = 0; info.uname = info.gname = ''; info.mtime = 0
            with path.open('rb') as stream:
                archive.addfile(info, stream)
    expected = {row['path']: row for row in rows}
    seen = set()
    with tarfile.open(archive_path, 'r|gz') as archive:
        for member in archive:
            assert member.isfile() and member.name not in seen and member.name in expected
            data = archive.extractfile(member).read(); row = expected[member.name]
            assert all(identity(data)[key] == row[key] for key in ('bytes', 'sha256', 'git_blob'))
            assert member.mode == row['mode']
            seen.add(member.name)
    assert seen == set(expected)
    for row in rows:
        path = ROOT / row['path']; observed = identity(path.read_bytes())
        assert all(observed[key] == row[key] for key in ('bytes', 'sha256', 'git_blob'))
        assert stat.S_IMODE(path.stat().st_mode) == row['mode']
    receipt = {'schema': 'hepta.auditor-supplement-archive-receipt.v1', 'archive': ARCHIVE,
               **identity(archive_path.read_bytes()), 'members': len(rows),
               'uncompressed_file_bytes': sum(row['bytes'] for row in rows),
               'all_member_bytes_hashes_modes_matched': True,
               'selected_input_files_unchanged_after_packaging': True,
               'single_blob_under_12000000_bytes': archive_path.stat().st_size < 12000000,
               'source_changes': False, 'native_programs_executed': 0, 'new_host_tests': 0, 'ok': True}
    dump('archive-receipt.json', receipt)
    payload_names = [ARCHIVE, 'archive-receipt.json', 'README.md', 'summary.json',
                     'retention.json', 'credential-scan.json', 'implementation-receipt.json']
    public = [{'path': name, **identity((ROOT / name).read_bytes())} for name in payload_names]
    dump('publication-payloads.json', {'schema': 'hepta.auditor-supplement-publication.v1',
         'recommended_prefix': 'evidence/hia_core_closure_20261029/offline-auditor-path-supplement/',
         'files': public, 'also_publish_this_map': True,
         'all_payloads_under_12000000_bytes': all(row['bytes'] < 12000000 for row in public)})
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
