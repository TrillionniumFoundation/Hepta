#!/usr/bin/env python3
"""Run the corrected offline auditor against the frozen original input files."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / 'ci-current-699de39'


def identity(path):
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
    return {'bytes': before.st_size, 'sha256': digest}


def main():
    selected = {INPUT / 'audit_artifact_contents.py', INPUT / 'content-audit-index.json'}
    selected.update(INPUT.glob('artifacts-*-snapshot-03.json'))
    selected.update((INPUT / 'raw-artifacts').glob('*.zip'))
    selected.update((INPUT / 'content-audits').glob('*.json'))
    selected.update(INPUT / 'selected-raw-reports' / str(aid) / 'cpp-upstream-host.json'
                    for aid in (12891623518, 12891739355))
    before = {str(path.relative_to(INPUT)): identity(path) for path in sorted(selected)}
    (ROOT / 'frozen-inputs-before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    original = (ROOT / 'audit_artifact_contents.original.py').read_bytes()
    corrected = (ROOT / 'audit_artifact_contents.py').read_bytes()
    assert original == (INPUT / 'audit_artifact_contents.py').read_bytes()
    (ROOT / 'auditor-fix.diff').write_text(''.join(difflib.unified_diff(
        original.decode().splitlines(keepends=True), corrected.decode().splitlines(keepends=True),
        fromfile='frozen/audit_artifact_contents.py', tofile='supplement/audit_artifact_contents.py')))
    implementation = json.loads((ROOT / 'implementation-receipt.json').read_text())
    implementation['corrected_sha256'] = hashlib.sha256(corrected).hexdigest()
    implementation['changes'] += [
        'strictly parse the two nested ABI execution stdout JSON records before the unchanged legacy validator',
        'require positive exact integer artifact/run ids before input and exception-output path construction']
    (ROOT / 'implementation-receipt.json').write_text(json.dumps(implementation, indent=2, sort_keys=True) + '\n')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    command = [sys.executable, str(ROOT / 'audit_artifact_contents.py')]
    with (ROOT / 'offline-reaudit.stdout.log').open('wb') as stdout, (ROOT / 'offline-reaudit.stderr.log').open('wb') as stderr:
        process = subprocess.run(command, cwd=ROOT.parent, stdout=stdout, stderr=stderr,
                                 env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=600)
    after = {str(path.relative_to(INPUT)): identity(path) for path in sorted(selected)}
    (ROOT / 'frozen-inputs-after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    assert before == after, 'Frozen original files changed'
    index = json.loads((ROOT / 'content-audit-index.json').read_text())
    original_index = json.loads((INPUT / 'content-audit-index.json').read_text())
    assert len(index['artifacts']) == 18
    assert process.returncode == 0 and all(row['status'] == 'passed_with_explicit_scope_limits' for row in index['artifacts'])
    assert index['source'] == original_index['source'] and index['artifacts'] == original_index['artifacts']
    content_comparisons = []
    for row in index['artifacts']:
        name = str(row['artifact_id']) + '.json'
        old, new = INPUT / 'content-audits' / name, ROOT / 'content-audits' / name
        old_id, new_id = identity(old), identity(new)
        assert old_id == new_id
        content_comparisons.append({'artifact_id': row['artifact_id'], **new_id, 'byte_identical_to_original_result': True})
    record = {'schema': 'hepta.offline-auditor-reexecution.v1', 'argv': command,
              'returncode': process.returncode, 'started_utc': started,
              'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'wall_seconds': time.monotonic() - tick, 'original_inputs_unchanged': before == after,
              'original_input_files_checked': len(before), 'artifacts_reaudited': len(index['artifacts']),
              'same_original_result_rows': True, 'content_audit_comparisons': content_comparisons,
              'stdout': identity(ROOT / 'offline-reaudit.stdout.log'),
              'stderr': identity(ROOT / 'offline-reaudit.stderr.log'),
              'native_programs_executed': 0, 'host_tests_rerun': 0, 'source_changed': False,
              'new_package_downloads': 0, 'ok': True}
    (ROOT / 'offline-reaudit-execution.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'ok': True, 'artifacts': len(index['artifacts']),
                      'original_inputs_unchanged': True, 'all_original_result_bytes_unchanged': True}))


if __name__ == '__main__':
    main()
