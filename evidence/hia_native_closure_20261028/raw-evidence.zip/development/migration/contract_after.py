from pathlib import Path
import contextlib, io, json, tempfile
from hepta.c_contracts import decode_contracts, snapshot_contracts
from hepta.c_migrate import MigrationRejected, migrate_c_project
from hepta.cli import main

ROOT = Path('/workspace/scratch/7e691a7ff65f/hepta')
OUT = ROOT.parent / 'validation-next-migration'
before = json.loads((OUT/'contract-before.json').read_text())
raw = before['duplicate_contract_raw']
with tempfile.TemporaryDirectory(prefix='hepta-contract-after-') as temporary:
    work = Path(temporary)
    path = work/'contracts.json';path.write_text(raw)
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        status = main(['migrate-c-project',str(work/'database-never-opened.json'),'--output',str(work/'output'),'--contracts',str(path),'--clang','compiler-never-executed','--frontend-only'])
    cli = json.loads(output.getvalue())
    try:
        decode_contracts(raw)
    except MigrationRejected as error:
        decoder = {'accepted':False,'code':error.code,'message':str(error)}
    empty = migrate_c_project(work/'database-never-opened.json',work/'empty',contracts={})
    report = {'duplicate_contract_raw':raw,'public_cli_returncode':status,'duplicate_cli':cli,'shared_decoder':decoder,'explicit_empty_contract':empty,'API_None_snapshot':snapshot_contracts(None),'output_created':(work/'output').exists(),'scope':'Duplicate source JSON can only be rejected before a caller discards duplicate-key information; ordinary dict API receives already parsed obligations.'}
    (OUT/'contract-after.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'duplicate_cli_ok':cli['ok'],'decoder_code':decoder['code'],'explicit_empty_ok':empty['ok'],'output_created':report['output_created']}))
