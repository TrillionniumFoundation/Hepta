from pathlib import Path
import json, subprocess, tempfile
from hepta.c_migrate import migrate_c_project

ROOT = Path('/workspace/scratch/7e691a7ff65f/hepta')
OUT = ROOT.parent / 'validation-next-migration'
RAW = '{"schema":"hepta.c-contracts.v1","functions":{"write_one":{"slices":{"p":{"length":1,"access":"read","access":"mut"}}}}}'
with tempfile.TemporaryDirectory(prefix='hepta-contract-before-') as temporary:
    work = Path(temporary)
    (work/'input.c').write_text('void write_one(unsigned int *p) { *p = 7u; }\n')
    (work/'contracts.json').write_text(RAW)
    database = work/'compile_commands.json'
    database.write_text(json.dumps([{'directory':str(work),'file':'input.c','arguments':['clang','-std=c11','-c','input.c']}]))
    cli = subprocess.run(['/usr/bin/python3','-m','hepta','migrate-c-project',str(database),'--output',str(work/'cli'),'--contracts',str(work/'contracts.json'),'--clang','/usr/bin/clang-20','--frontend-only'],cwd=ROOT,capture_output=True,text=True)
    cli_report = json.loads(cli.stdout)
    accepted = migrate_c_project(database,work/'api',contracts=json.loads(RAW),clang='/usr/bin/clang-20')
    changed = json.loads(RAW)
    changed['functions']['write_one']['slices']['p']['access'] = 'read'
    read_only = migrate_c_project(database,work/'read-only',contracts=changed,clang='/usr/bin/clang-20')
    scalar = work/'scalar.c';scalar.write_text('unsigned int identity(unsigned int x) { return x; }\n')
    database.write_text(json.dumps([{'directory':str(work),'file':'scalar.c','arguments':['clang','-std=c11','-c','scalar.c']}]))
    empty = migrate_c_project(database,work/'empty',contracts={},clang='/usr/bin/clang-20')
    result = {'duplicate_contract_raw':RAW,'cli_returncode':cli.returncode,'duplicate_cli':cli_report,'duplicate_api_after_last_wins_json_loads':accepted,'unambiguous_read_contract':read_only,'explicit_empty_contract':empty}
    (OUT/'contract-before.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'duplicate_cli_ok':cli_report['ok'],'duplicate_api_ok':accepted['ok'],'read_only_ok':read_only['ok'],'read_only_diagnostics':read_only['diagnostics'],'explicit_empty_ok':empty['ok']}))
