from pathlib import Path
import ctypes, hashlib, json, os, struct, subprocess, tempfile
from hepta.c_migrate import migrate_c_project
ROOT=Path('/workspace/scratch/7e691a7ff65f/hepta')
OUT=ROOT.parent/'validation-next-migration'
CLANG='/usr/bin/clang-20'
RUSTC=str(ROOT.parent/'toolchains/rustup/toolchains/1.90.0-x86_64-unknown-linux-gnu/bin/rustc')
SOURCE='#pragma STDC FENV_ACCESS ON\ndouble fraction(void) { return 1.0 / 10.0; }\n'
with tempfile.TemporaryDirectory(prefix='hepta-next-fenv-') as temporary:
 w=Path(temporary);src=w/'input.c';src.write_text(SOURCE)
 db=w/'compile_commands.json';db.write_text(json.dumps([{'directory':str(w),'file':'input.c','arguments':['clang','-std=c11','-O2','-c','input.c']}]))
 ast=subprocess.run([CLANG,'-std=c11','-O2','-fsyntax-only','-Xclang','-ast-dump=json','input.c'],cwd=w,capture_output=True,text=True,check=True).stdout
 (OUT/'fenv-before-ast.json').write_text(ast)
 migrated=migrate_c_project(db,w/'translated',clang=CLANG,rustc=RUSTC,verify_native=True)
 report={'source':SOURCE,'migration':migrated,'observations':[]}
 if migrated['ok']:
  helper=w/'rounding.c';helper.write_text('#include <fenv.h>\nint select_rounding(int mode) { return fesetround(mode == 1 ? FE_DOWNWARD : mode == 2 ? FE_UPWARD : FE_TONEAREST); }\n')
  command=[CLANG,'-std=c11','-O2','-shared','-fPIC',str(src),str(helper),'-lm','-o',str(w/'original.so')]
  result=subprocess.run(command,cwd=w,capture_output=True,text=True,check=True)
  report['original_build']={'command':command,'stdout':result.stdout,'stderr':result.stderr,'returncode':result.returncode}
  c=ctypes.CDLL(str(w/'original.so'));h=ctypes.CDLL(str(w/'translated/libtranslated.so'))
  c.fraction.argtypes=h.fraction.argtypes=[];c.fraction.restype=h.fraction.restype=ctypes.c_double
  c.select_rounding.argtypes=[ctypes.c_int];c.select_rounding.restype=ctypes.c_int
  try:
   for mode in [0,1,2]:
    assert c.select_rounding(mode)==0
    a,b=c.fraction(),h.fraction()
    report['observations'].append({'rounding':mode,'original_bits':struct.pack('=d',a).hex(),'translated_bits':struct.pack('=d',b).hex(),'equal':a==b})
  finally:c.select_rounding(0)
  report['generated_hepta']=(w/'translated/source.hepta').read_text()
  report['generated_rust']=(w/'translated/generated.rs').read_text()
 (OUT/'fenv-before.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'migration_ok':migrated['ok'],'diagnostics':migrated['diagnostics'],'observations':report['observations']}))
