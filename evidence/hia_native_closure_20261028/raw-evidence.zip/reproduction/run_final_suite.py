#!/usr/bin/env python3
"""Record a local, source-bound integration run; --run is required to execute tests.

This scratch runner is not the repository's 35-gate qualification and never
asserts production readiness, whole-language safety or multi-platform execution.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import stat
import subprocess
import sys
import time


BASE = Path(__file__).resolve().parent
REPO = BASE / "hepta"
TOOLCHAINS = BASE / "toolchains"
SOURCE_RUST = TOOLCHAINS / "rustup/toolchains/1.90.0-x86_64-unknown-linux-gnu/bin"
SHADOW_RUST = TOOLCHAINS / "rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin"
LLVM = Path("/usr/lib/llvm-20/bin")
PYTHON = Path("/usr/bin/python3")
CARGO = BASE / "p7-suite-bin/cargo"
LEAN = TOOLCHAINS / "lean-4.19.0/bin/lean"
PYTHON_PACKAGES = "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages"
EXCLUDED_PARTS = frozenset({
    ".git", "evidence", "artifacts", "upstream", "target", "__pycache__",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".cache", ".venv",
    "venv", "node_modules",
})
EXCLUDED_SUFFIXES = (".pyc", ".pyo")
ENVIRONMENT_KEYS = (
    "PATH", "PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "RUSTUP_HOME", "CARGO_HOME",
    "RUSTC", "CLANG", "CC", "CXX", "LEAN", "HEPTA_LLD", "HEPTA_LLVM_READOBJ",
    "HEPTA_QEMU_AARCH64", "HEPTA_QEMU_RISCV64", "CARGO_NET_OFFLINE",
    "CARGO_TARGET_DIR", "LD_LIBRARY_PATH", "LD_PRELOAD",
)
UNSET_CHILD_ENVIRONMENT = (
    "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "RUSTC_WRAPPER",
    "RUSTC_WORKSPACE_WRAPPER", "CARGO_BUILD_RUSTFLAGS", "CARGO_BUILD_RUSTC_WRAPPER",
    "RUSTUP_TOOLCHAIN",
)


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def canonical_hash(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def make_environment():
    env = dict(os.environ)
    for name in UNSET_CHILD_ENVIRONMENT:
        env.pop(name, None)
    env.update({
        "PATH": os.pathsep.join((str(CARGO.parent), str(SOURCE_RUST), str(LLVM), env.get("PATH", ""))),
        "PYTHONPATH": PYTHON_PACKAGES,
        "PYTHONDONTWRITEBYTECODE": "1",
        "RUSTUP_HOME": str(TOOLCHAINS / "rustup"),
        "CARGO_HOME": str(TOOLCHAINS / "cargo"),
        "RUSTC": str(SOURCE_RUST / "rustc"),
        "CLANG": str(LLVM / "clang"), "CC": "/usr/bin/gcc", "CXX": "/usr/bin/g++",
        "LEAN": str(LEAN), "HEPTA_LLD": str(LLVM / "ld.lld"),
        "HEPTA_LLVM_READOBJ": str(LLVM / "llvm-readobj"),
        "HEPTA_QEMU_AARCH64": "/usr/bin/qemu-aarch64-static",
        "HEPTA_QEMU_RISCV64": "/usr/bin/qemu-riscv64-static",
        "CARGO_NET_OFFLINE": "true",
        # Reuse the already-built shadow target; do not allocate another cache.
        "CARGO_TARGET_DIR": str(REPO / "rust/hia-core-shadow/target"),
    })
    return env


def inspection(argv, *, env=None, timeout=60):
    argv = list(map(str, argv))
    try:
        proc = subprocess.run(argv, cwd=REPO, env=env, capture_output=True,
                              text=True, errors="replace", timeout=timeout)
        return {"argv": argv, "returncode": proc.returncode,
                "stdout": proc.stdout, "stderr": proc.stderr}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"argv": argv, "returncode": None, "error": str(exc)}


def source_snapshot():
    # No --exclude-standard: ignored untracked inputs are also inventoried,
    # then the explicitly documented generated/cache directory policy applies.
    proc = subprocess.run(["git", "ls-files", "--cached", "--others", "-z"],
                          cwd=REPO, capture_output=True, check=True)
    names = sorted({os.fsdecode(name) for name in proc.stdout.split(b"\0") if name})
    tracked = set(subprocess.run(["git", "ls-files", "--cached", "-z"],
                                cwd=REPO, capture_output=True, check=True).stdout.split(b"\0"))
    entries = []
    excluded = 0
    for name in names:
        relative = Path(name)
        if EXCLUDED_PARTS.intersection(relative.parts) or name.endswith(EXCLUDED_SUFFIXES):
            excluded += 1
            continue
        path = REPO / relative
        entry = {"path": name, "git_tracked": os.fsencode(name) in tracked}
        try:
            metadata = path.lstat()
        except FileNotFoundError:
            entry["kind"] = "missing"
        else:
            entry["mode"] = stat.S_IMODE(metadata.st_mode)
            if stat.S_ISLNK(metadata.st_mode):
                target = os.readlink(path)
                entry.update(kind="symlink", target=target,
                             sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
            elif stat.S_ISREG(metadata.st_mode):
                entry.update(kind="regular", bytes=metadata.st_size, sha256=digest(path))
            else:
                raise ValueError("Unsupported nonregular repository input: " + name)
        entries.append(entry)
    head = inspection(["git", "rev-parse", "HEAD"])
    status = inspection(["git", "status", "--porcelain=v1", "--untracked-files=all"])
    return {"captured_utc": utc(), "git_head": head.get("stdout", "").strip(),
            "git_status": status.get("stdout", ""),
            "working_tree_clean": status.get("returncode") == 0 and not status.get("stdout", ""),
            "sha256": canonical_hash(entries), "files": entries, "file_count": len(entries),
            "untracked_file_count": sum(not entry["git_tracked"] for entry in entries),
            "regular_file_bytes": sum(entry.get("bytes", 0) for entry in entries),
            "excluded_inventory_entries": excluded,
            "excluded_path_components": sorted(EXCLUDED_PARTS),
            "excluded_suffixes": list(EXCLUDED_SUFFIXES),
            "symlink_policy": "hash link target bytes; never follow links for source content"}


def file_identity(path):
    path = Path(path)
    result = {"selected_path": str(path), "resolved_path": str(path.resolve())}
    if not path.is_file():
        return dict(result, available=False)
    result.update(available=True, bytes=path.stat().st_size, sha256=digest(path))
    if path.is_symlink():
        result["symlink_target"] = os.readlink(path)
    return result


def tool_inventory(env):
    selections = {
        "python": (PYTHON, ["--version"]),
        "source_rustc": (SOURCE_RUST / "rustc", ["-vV"]),
        "shadow_rustc": (SHADOW_RUST / "rustc", ["-vV"]),
        "shadow_rustdoc": (SHADOW_RUST / "rustdoc", ["--version"]),
        "shadow_cargo": (SHADOW_RUST / "cargo", ["-Vv"]),
        "cargo_wrapper": (CARGO, ["-Vv"]),
        "clang": (LLVM / "clang", ["--version"]),
        "clangxx": (LLVM / "clang++", ["--version"]),
        "cc": (Path("/usr/bin/gcc"), ["--version"]),
        "cxx": (Path("/usr/bin/g++"), ["--version"]),
        "linker": (LLVM / "ld.lld", ["--version"]),
        "readobj": (LLVM / "llvm-readobj", ["--version"]),
        "lean": (LEAN, ["--version"]),
        "qemu_aarch64": (Path(env["HEPTA_QEMU_AARCH64"]), ["--version"]),
        "qemu_riscv64": (Path(env["HEPTA_QEMU_RISCV64"]), ["--version"]),
        "qemu_system_arm": (Path("/usr/bin/qemu-system-arm"), ["--version"]),
        "gdb": (Path("/usr/bin/gdb"), ["--version"]),
    }
    result = {}
    for name, (path, flags) in selections.items():
        item = file_identity(path)
        item["version_process"] = inspection([path, *flags], env=env)
        result[name] = item
    lock_path = REPO / "formal/toolchain-lock.json"
    dependencies_path = REPO / "formal/proof-dependencies.txt"
    lean_lock = json.loads(lock_path.read_text())
    selected = {"bin/lean", "lib/lean/libInit_shared.so", "lib/lean/libleanshared.so", "lib/lean/libleanshared_1.so"}
    selected.update("lib/lean/" + name for name in dependencies_path.read_text().splitlines())
    components = [{"relative_path": name, **file_identity(LEAN.parent.parent / name)} for name in sorted(selected)]
    result["lean_locked_installation"] = {
        "lock": lean_lock, "lock_sha256": digest(lock_path),
        "dependencies_manifest_sha256": digest(dependencies_path),
        "all_selected_components_present": all(item["available"] for item in components),
        "binary_matches_lock": result["lean"].get("sha256") == lean_lock["lean_binary_sha256"],
        "components": components, "components_sha256": canonical_hash(components),
    }
    result["runner"] = file_identity(__file__)
    result["environment_probes"] = inspection([PYTHON, "-c", '''
import fcntl,json,os,sys
from hepta.backend import toolchain_info
out={"python":sys.version,"source_rust_toolchain":toolchain_info(os.environ["RUSTC"])}
try:
 import zstandard
 raw=b"hepta-p7-environment"
 out["zstandard"]={"version":zstandard.__version__,"path":zstandard.__file__,"round_trip_ok":zstandard.ZstdDecompressor().decompress(zstandard.ZstdCompressor().compress(raw))==raw}
except Exception as exc:out["zstandard"]={"error":str(exc)}
fd=None
try:
 fd=os.memfd_create("hepta-p7-preflight",os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING)
 os.write(fd,b"sealed")
 flags=fcntl.F_SEAL_SEAL|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_GROW|fcntl.F_SEAL_WRITE
 fcntl.fcntl(fd,fcntl.F_ADD_SEALS,flags)
 out["memfd_sealing"]={"requested":flags,"observed":fcntl.fcntl(fd,fcntl.F_GET_SEALS)}
except Exception as exc:out["memfd_sealing"]={"error":str(exc)}
finally:
 if fd is not None:os.close(fd)
print(json.dumps(out,sort_keys=True))
'''], env=env)
    result["identity_sha256"] = canonical_hash({name: item for name, item in result.items() if name != "environment_probes"})
    return result


def discover(env):
    process = inspection([PYTHON, "-c", '''
import collections,json,unittest
loader=unittest.TestLoader();suite=loader.discover("tests")
def flatten(node):
 for item in node:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item
cases=list(flatten(suite));skips=[]
for case in cases:
 method=getattr(case,case._testMethodName,None)
 if getattr(case,"__unittest_skip__",False):skips.append({"id":case.id(),"reason":getattr(case,"__unittest_skip_why__","")})
 elif getattr(method,"__unittest_skip__",False):skips.append({"id":case.id(),"reason":getattr(method,"__unittest_skip_why__","")})
print(json.dumps({"count":suite.countTestCases(),"modules":len({case.__class__.__module__ for case in cases}),"ids":[case.id() for case in cases],"loader_errors":loader.errors,"decorator_skips":skips},sort_keys=True))
'''], env=env, timeout=120)
    if process.get("returncode") != 0:
        return {"process": process, "ok": False}
    try:
        result = json.loads(process["stdout"])
    except ValueError:
        return {"process": process, "ok": False, "error": "discovery did not emit one JSON document"}
    return {"process": process, **result, "ok": not result["loader_errors"] and result["count"] > 0}


def stop_group(process):
    if process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()


def interrupted(signum, frame):
    raise KeyboardInterrupt("integration runner interrupted by signal " + str(signum))


def run_gate(name, argv, output, env, timeout):
    argv = list(map(str, argv))
    stdout = output / (name + ".stdout.log")
    stderr = output / (name + ".stderr.log")
    started = time.monotonic()
    result = {"name": name, "argv": argv, "cwd": str(REPO), "started_utc": utc(),
              "timeout_seconds": timeout, "returncode": None, "completed": False}
    try:
        with stdout.open("xb") as out, stderr.open("xb") as err:
            process = subprocess.Popen(argv, cwd=REPO, env=env, stdout=out, stderr=err,
                                       stdin=subprocess.DEVNULL, start_new_session=True)
            try:
                result["returncode"] = process.wait(timeout=timeout)
                result["completed"] = True
            except subprocess.TimeoutExpired:
                result["timed_out"] = True
                stop_group(process)
                result["returncode"] = process.returncode
            except BaseException:
                stop_group(process)
                raise
    except OSError as exc:
        result["launch_error"] = str(exc)
    finally:
        result.update(finished_utc=utc(), seconds=time.monotonic() - started)
        result["stdout"] = file_identity(stdout)
        result["stderr"] = file_identity(stderr)
    return result


def unittest_outcome(stderr, returncode):
    match = re.search(r"(?m)^Ran ([0-9]+) tests? in ([0-9.]+)s\s+(OK|FAILED)(?: \(([^\n]*)\))?\s*\Z", stderr)
    result = {"tests_run": None, "skipped": None, "failures": None, "errors": None, "passed": False}
    if match is None:
        return result
    result.update(tests_run=int(match.group(1)), runner_seconds=float(match.group(2)), skipped=0, failures=0, errors=0)
    if match.group(4):
        for detail in match.group(4).split(", "):
            field = re.fullmatch(r"(skipped|failures|errors)=([0-9]+)", detail)
            if field is None:
                result["unaccepted_summary_detail"] = detail
                return result
            result[field.group(1)] = int(field.group(2))
    result["passed"] = (returncode == 0 and match.group(3) == "OK" and result["tests_run"] > 0
                        and result["skipped"] == result["failures"] == result["errors"] == 0)
    return result


def cargo_outcome(stdout, returncode):
    matches = list(re.finditer(r"(?m)^test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out; finished in [0-9.]+s\s*$", stdout))
    result = {"tests_run": None, "skipped": None, "failures": None, "filtered_out": None,
              "measured": None, "test_binaries": len(matches), "passed": False}
    if not matches:
        return result
    passed, failed, ignored, measured, filtered = (sum(int(match.group(index)) for match in matches) for index in range(2, 7))
    result.update(tests_run=passed + failed, skipped=ignored, failures=failed, measured=measured, filtered_out=filtered)
    result["passed"] = (returncode == 0 and passed > 0 and failed == ignored == measured == filtered == 0
                        and all(match.group(1) == "ok" for match in matches)
                        and not stdout[matches[-1].end():].strip())
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="new scratch directory outside the repository")
    parser.add_argument("--run", action="store_true", help="execute tests; without this option only preflight is recorded")
    parser.add_argument("--unit-timeout", type=int, default=1800)
    args = parser.parse_args()
    output = args.output.resolve()
    if output == REPO or REPO in output.parents:
        parser.error("evidence output must be outside the tested repository")
    if output.exists():
        parser.error("output directory already exists; choose a new directory to preserve evidence")
    output.mkdir(parents=True)
    env = make_environment()
    report = {"schema": "hepta.local-p7-integration-suite.v1", "started_utc": utc(),
              "repository": str(REPO), "output_directory": str(output), "status": "preflight",
              "host": {"system": platform.system(), "machine": platform.machine(),
                       "release": platform.release(), "uid": os.getuid()},
              "suite_execution_requested": args.run, "suite_started": False, "ok": False,
              "environment": {key: env[key] for key in ENVIRONMENT_KEYS if key in env},
              "removed_inherited_environment_names": [name for name in UNSET_CHILD_ENVIRONMENT if name in os.environ],
              "scope": "one local Linux x86-64 Cargo suite and repository Python unittest discovery",
              "full_35_gate_qualification_executed": False, "full_seven_deliverables_complete": False,
              "whole_language_soundness_proved": False, "production_admission_qualified": False,
              "multi_platform_native_execution_claimed": False,
              "disk_before": shutil.disk_usage(BASE)._asdict(), "gates": []}
    write_json(output / "summary.json", report)
    before = source_snapshot()
    write_json(output / "source-before.json", before)
    tools_before = tool_inventory(env)
    write_json(output / "tools-before.json", tools_before)
    tool_launch_failures = [name for name, item in tools_before.items()
                           if isinstance(item, dict) and "version_process" in item
                           and item["version_process"].get("returncode") != 0]
    probes = tools_before["environment_probes"]
    probe_values = json.loads(probes["stdout"]) if probes.get("returncode") == 0 else {}
    environment_ready = (not tool_launch_failures
                         and tools_before["lean_locked_installation"]["binary_matches_lock"]
                         and tools_before["lean_locked_installation"]["all_selected_components_present"]
                         and probe_values.get("zstandard", {}).get("round_trip_ok") is True
                         and probe_values.get("memfd_sealing", {}).get("observed") == 15)
    discovery = discover(env)
    write_json(output / "discovery.json", discovery)
    plan = [
        {"name": "rust_shadow_cargo", "argv": [str(CARGO), "test", "--locked", "--offline", "--manifest-path", "rust/hia-core-shadow/Cargo.toml"], "timeout": 600},
        {"name": "unit_regression", "argv": [str(PYTHON), "-m", "unittest", "discover", "-s", "tests", "-q"], "timeout": args.unit_timeout},
    ]
    report.update(source_before_sha256=before["sha256"], git_head_before=before["git_head"],
                  source_was_committed=before["working_tree_clean"] and before["untracked_file_count"] == 0,
                  discovery_count=discovery.get("count"), discovery_ok=discovery["ok"], plan=plan,
                  expected_rust_test_count=52,
                  environment_ready=environment_ready, tool_launch_failures=tool_launch_failures,
                  tools_before_identity_sha256=tools_before["identity_sha256"])
    print(json.dumps({"stage": "preflight", "discovered_tests": discovery.get("count"),
                      "decorator_skip_count": len(discovery.get("decorator_skips", [])),
                      "environment_ready": environment_ready,
                      "source_sha256": before["sha256"], "execute_requested": args.run}), flush=True)
    if args.run:
        report.update(status="running", suite_started=True)
        write_json(output / "summary.json", report)
        for gate in plan:
            print(json.dumps({"stage": "gate_started", "name": gate["name"], "utc": utc()}), flush=True)
            result = run_gate(gate["name"], gate["argv"], output, env, gate["timeout"])
            if gate["name"] == "rust_shadow_cargo":
                text = (output / (gate["name"] + ".stdout.log")).read_text(errors="replace")
                outcome = cargo_outcome(text, result["returncode"])
                outcome["count_matches_frozen_baseline"] = outcome["tests_run"] == report["expected_rust_test_count"]
            else:
                text = (output / (gate["name"] + ".stderr.log")).read_text(errors="replace")
                outcome = unittest_outcome(text, result["returncode"])
                outcome["count_matches_discovery"] = outcome["tests_run"] == discovery.get("count")
            result["outcome"] = outcome
            result["passed"] = result["completed"] and outcome["passed"] and all(value for key, value in outcome.items() if key.startswith("count_matches_"))
            report["gates"].append(result)
            write_json(output / "summary.json", report)
            print(json.dumps({"stage": "gate_finished", "name": gate["name"], "seconds": result["seconds"], "outcome": outcome}), flush=True)
    after = source_snapshot()
    write_json(output / "source-after.json", after)
    tools_after = tool_inventory(env)
    write_json(output / "tools-after.json", tools_after)
    report.update(status="completed" if args.run else "preflight_only", finished_utc=utc(),
                  source_after_sha256=after["sha256"], git_head_after=after["git_head"],
                  source_unchanged=before["sha256"] == after["sha256"],
                  git_head_unchanged=before["git_head"] == after["git_head"],
                  tools_after_identity_sha256=tools_after["identity_sha256"],
                  tools_unchanged=tools_before["identity_sha256"] == tools_after["identity_sha256"],
                  disk_after=shutil.disk_usage(BASE)._asdict())
    report["ok"] = (args.run and environment_ready and discovery["ok"] and len(report["gates"]) == len(plan)
                    and all(gate["passed"] for gate in report["gates"])
                    and report["source_unchanged"] and report["git_head_unchanged"] and report["tools_unchanged"])
    write_json(output / "summary.json", report)
    print(json.dumps({"stage": report["status"], "ok": report["ok"], "source_unchanged": report["source_unchanged"],
                      "tools_unchanged": report["tools_unchanged"], "summary": str(output / "summary.json")}), flush=True)
    return 0 if not args.run or report["ok"] else 1


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, interrupted)
    raise SystemExit(main())
