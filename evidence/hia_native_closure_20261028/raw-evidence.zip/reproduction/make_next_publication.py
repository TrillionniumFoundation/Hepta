#!/usr/bin/env python3
"""Describe exactly the staged tree; no remote mutation or commit occurs here."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/7e691a7ff65f/hepta')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def main():
    output = Path(sys.argv[1])
    subprocess.run(['git','diff','--exit-code','--no-ext-diff'],cwd=ROOT,check=True)
    files=[]
    for name in git('diff','--cached','--name-only','-z').split(b'\0'):
        if not name:
            continue
        name=name.decode()
        raw=(ROOT/name).read_bytes()
        metadata=git('ls-files','--stage','--',name).decode().split()
        blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if blob != metadata[1]:
            raise RuntimeError('staged content differs: '+name)
        try:
            raw.decode('utf-8')
            encoding='utf-8'
        except UnicodeDecodeError:
            encoding='base64'
        files.append({'path':name,'mode':metadata[0],'blob_sha':blob,'bytes':len(raw),
                      'sha256':hashlib.sha256(raw).hexdigest(),'encoding':encoding})
    plan={'repository':'TrillionniumFoundation/Hepta',
          'branch':git('branch','--show-current').decode().strip(),
          'parent_sha':git('rev-parse','HEAD').decode().strip(),
          'base_tree_sha':git('rev-parse','HEAD^{tree}').decode().strip(),
          'tree_sha':git('write-tree').decode().strip(),'files':files}
    output.write_text(json.dumps(plan,indent=2)+'\n')
    print(json.dumps({'manifest':str(output),'files':len(files),'bytes':sum(item['bytes'] for item in files),
                      'parent_sha':plan['parent_sha'],'tree_sha':plan['tree_sha']}))

if __name__=='__main__':main()
