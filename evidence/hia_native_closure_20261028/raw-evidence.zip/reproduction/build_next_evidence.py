#!/usr/bin/env python3
"""Package retained continuation evidence without relabelling previous runs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / "hepta"
OUT = ROOT / "evidence/hia_native_closure_20261028"
COMMIT = "581c55cc2f14af38a7486e125d5c33496ca95f0a"


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n")


def main():
    functional = read(BASE / "validation-next-frozen/summary.json")
    performance = read(BASE / "validation-next-performance/summary.json")
    assert functional["ok"] and performance["ok"]
    assert functional["git_head"] == performance["git_head"] == COMMIT
    assert all(report["source_unchanged"] and report["tools_unchanged"]
               for report in (functional, performance))
    ring = read(BASE / "validation-next-frozen/ring-buffer.json")
    OUT.mkdir(parents=True, exist_ok=False)
    runs = []
    for name in ("fill-loop-1", "fill-loop-2", "swap-control"):
        report = read(BASE / "validation-next-performance" / (name + ".json"))
        process = read(BASE / "validation-next-performance" / (name + ".process.json"))
        measure, assessment = report["measurement"], report["assessment"]
        item = {"id": name, "qualification_status": report["status"], "decision": report["decision"],
                "ndu_advisory_recommendation": report["ndu"]["response"]["advisory_recommendation"],
                "counts": measure["counts"], "measurement_summary": measure["summary"],
                "assessment": assessment, "costs": report["costs"],
                "total_cli_wall_ns": process["total_cli_wall_ns"],
                "protocol_check": process["protocol_check"],
                "core_sha256": {role: report["candidate"][role + "_sha256"] for role in ("baseline", "candidate")},
                "llvm_ir_sha256": {role: measure["reproduction"][role]["llvm_ir_sha256"] for role in ("baseline", "candidate")},
                "native_artifacts": {role: {key: measure["native"][role][key]
                    for key in ("artifact_sha256", "artifact_bytes")} for role in ("baseline", "candidate")},
                "relative_mad_percent": {role: 100 * assessment[role + "_mad_ns"] / assessment[role + "_median_ns"]
                    for role in ("baseline", "candidate")},
                "raw_report_sha256": sha(BASE / "validation-next-performance" / (name + ".json"))}
        assert item["decision"] == "no_change" and item["ndu_advisory_recommendation"] == "abstain"
        assert not assessment["eligible"] and assessment["native_artifact_changed"] is False
        runs.append(item)
    python_gates = [gate for gate in functional["gates"] if gate["name"] in functional["selected_modules"]]
    py_count = sum(gate["outcome"]["tests_run"] for gate in python_gates)
    assert py_count == 310 and functional["gates"][0]["outcome"]["tests_run"] == 54
    ledger = (BASE / "validation-next-frozen/independent_rust.stdout.log").read_text()
    ledger_counts = [int(value) for value in re.findall(r"full-ledger parity observations: (\d+)", ledger)]
    assert ledger_counts == [124, 105, 1231]
    native_count = int(re.search(r"native result and allocator observations: (\d+)", ledger).group(1))
    assert native_count == 60
    ring_measurements = []
    for measurement in ring["performance"]["measurements"]:
        derived = {route: 100 * statistics.median(abs(value-statistics.median(values)) for value in values)
                            / statistics.median(values)
                   for route, values in measurement["samples_nanoseconds"].items()}
        ring_measurements.append({**measurement, "derived_relative_mad_percent": derived,
                                  "accepted_performance_gain": False})
    ring_process = read(BASE / "validation-next-frozen/ring_buffer.process.json")
    summary = {
        "schema": "hepta.hia.native-closure-continuation-evidence.v1",
        "tested_commit": COMMIT, "tested_tree": "0a02e3f958b787faef6df5d4bc8860793db95f4f",
        "parent_delivery_commit": "46bcef9e1458ab7cdfca83feee40c0e23bcd45e2",
        "draft_pr": "https://github.com/TrillionniumFoundation/Hepta/pull/333",
        "scope": "one frozen Linux x86-64 continuation; targeted tests, real upstream module and fixed NDU searches",
        "frozen_functional_integration_passed": True,
        "rust_tests_passed": 54, "python_tests_passed": py_count, "skipped_tests": 0,
        "python_module_groups": {gate["name"]: gate["outcome"] for gate in python_gates},
        "repository_discovery_count": functional["repository_discovery_count"],
        "complete_repository_suite_executed": False, "full_35_gate_qualification_executed": False,
        "rust_python_full_ledger_observations": sum(ledger_counts),
        "rust_python_ledger_components": ledger_counts,
        "bulk_native_execution_controls": native_count,
        "native_control_input_overlap_with_ledger_corpus": True,
        "native_dispatch_unique_test_methods": 9,
        "native_dispatch_tests_already_in_python_count": True,
        "source_unchanged_during_each_frozen_run": True,
        "selected_tools_unchanged_during_each_frozen_run": True,
        "performance": {
            "runs": runs,
            "timed_native_calls_total": sum(row["counts"]["timed_calls_total"] for row in runs),
            "untimed_native_correctness_calls": sum(row["counts"]["untimed_correctness_calls"] for row in runs),
            "internal_paid_wall_ns_total": sum(row["costs"]["total_paid_wall_ns"] for row in runs),
            "complete_cli_wall_ns_total": sum(row["total_cli_wall_ns"] for row in runs),
            "all_native_pairs_identical": True, "accepted_native_gain": False,
            "no_change_runs": len(runs), "baseline_retained": True,
        },
        "real_module_migration": {
            "upstream": ring["upstream"], "disposition": ring["migration_disposition"],
            "execution": ring["execution"], "boundary_controls": ring["boundary_controls"],
            "owned_client_calls": ring["owned_client"]["calls"],
            "actual_allocator_refusal": ring["owned_client"]["actual_allocator_refusal"],
            "layout_probe": ring["layout_probe"], "wrong_implementation_control": ring["wrong_implementation_control"],
            "authored_contract_input": ring["authored_contract_input"],
            "cost": ring["cost"], "complete_cli_wall_ns": ring_process["wall_ns"],
            "performance_measurements": ring_measurements,
            "performance_claim": "descriptive noisy seven-sample controls; no qualified gain or general Rust comparison",
        },
        "claims": {"full_p0_p7_closed": False, "p4_closed": False, "p7_closed": False,
            "whole_language_soundness_proved": False, "general_backend_refinement_proved": False,
            "all_input_equivalence_proved": False, "global_optimum_proved": False,
            "universal_rust_performance_superiority_proved": False, "code_activated": False,
            "external_borrow_callback_state_migration_qualified": False,
            "industrial_migration_rate_qualified": False, "human_cost_measured": False,
            "independent_agent_productivity_experiment_executed_this_round": False,
            "physical_dot_host_identity_established": False,
        },
        "history": "All earlier delivery evidence remains unchanged. Development failures and fixture repairs are retained separately from the frozen pass.",
    }
    assert summary["performance"]["timed_native_calls_total"] == 32240000
    write("results.json", summary)
    shutil.copyfile(BASE / "validation-next-frozen/summary.json", OUT / "frozen-integration-summary.json")
    shutil.copyfile(BASE / "validation-next-performance/summary.json", OUT / "frozen-performance-summary.json")
    shutil.copyfile(ROOT / "experiments/hia_ndu_native_20261027/protocol.json", OUT / "protocol.json")
    members = []
    folders = {
        "validation-next-root": "development/root",
        "validation-next-rust": "development/rust",
        "validation-next-native-dispatch": "development/native-dispatch",
        "validation-next-migration": "development/migration",
        "validation-next-deadline": "development/deadline",
        "validation-next-frozen": "frozen/integration",
        "validation-next-performance": "frozen/performance",
        "validation-next-audits": "independent-audits",
    }
    for directory, prefix in folders.items():
        for path in sorted((BASE / directory).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                members.append((path, prefix + "/" + path.relative_to(BASE / directory).as_posix()))
    for name in ("run_next_frozen_validation.py", "run_final_suite.py", "next-source-publication.json",
                 "continuation-cache-cleanup.json", "build_next_evidence.py", "make_next_publication.py"):
        members.append((BASE / name, "reproduction/" + name))
    members.append((ROOT / "rust/hia-ndu-bridge/build-provenance.json", "reproduction/ndu-build-provenance.json"))
    records = [{"member": name, "original_path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}
               for path, name in members]
    with zipfile.ZipFile(OUT / "raw-evidence.zip", "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name in members:
            archive.write(path, name)
    with zipfile.ZipFile(OUT / "raw-evidence.zip") as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(records)
        for item in records:
            data = archive.read(item["member"])
            assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
    write("raw-evidence-manifest.json", {
        "schema": "hepta.hia.native-closure-evidence-archive.v1", "tested_commit": COMMIT,
        "archive": {"path": "raw-evidence.zip", "bytes": (OUT / "raw-evidence.zip").stat().st_size,
                    "sha256": sha(OUT / "raw-evidence.zip"), "members": len(records)},
        "all_members_read_and_hash_verified": True,
        "members": records,
        "note": "Original absolute paths are historical execution locations; member paths resolve inside this archive. Development failures and repaired fixtures are not relabelled as frozen passes.",
    })
    table = "\n".join(f"| {row['id']} | {row['measurement_summary']['baseline_median_ns_per_call']:.6f} | {row['measurement_summary']['candidate_median_ns_per_call']:.6f} | {row['relative_mad_percent']['baseline']:.3f}% / {row['relative_mad_percent']['candidate']:.3f}% | {row['costs']['total_paid_wall_ns']/1e9:.6f} / {row['total_cli_wall_ns']/1e9:.6f} | no_change |" for row in runs)
    english = f"""# Native closure continuation evidence

Frozen source: `{COMMIT}`. Frozen tree: `0a02e3f958b787faef6df5d4bc8860793db95f4f`.
Draft [PR #333](https://github.com/TrillionniumFoundation/Hepta/pull/333) is stacked on #326.
The later evidence-only delivery commit does not replace the tested source identity.

## Actual results

- 54 Rust tests and 310 targeted Python tests passed, with zero skips. Python groups: 149 Core/NDU/lifecycle, 68 independent Rust, 93 migration.
- Repository discovery found 2,643 tests. This was not a full repository run or the full 35-gate qualification.
- Independent Rust/Python execution compared 1,460 complete resource ledgers: 124 + 105 + 1,231. The last count already includes 168 fill-loop observations. Sixty bulk native controls reuse inputs from that corpus; do not count them as 60 additional disjoint Rust/Python observations.
- Nine native dispatcher methods are included in the 149-test group. PID-FD pause/resume observes in-flight native children and artifact lifetime, without an internal active-loan handshake.
- Actual pinned upstream Ring-Buffer execution completed 16,384 state transitions, 65,544 paired comparisons, and 131,088 native entry invocations.
- Its one captured configuration converted all 9 function bodies, accounted for all 22 active declarations, and retained 9 separately counted C ABI wrappers. This route uses the Hepta checked core/Rust backend and caller-authored record-view obligations; it does not establish arbitrary standalone-HIA C translation or inferred foreign ownership.
- All three fixed NDU searches completed with actual evaluator `abstain` and host `no_change`. All native baseline/candidate pairs were byte-identical. No performance gain was admitted.
- Source and selected tool identities remained unchanged during each frozen invocation. The host was the shared Linux x86-64 container, without physical dot-host attestation.

## Fixed native experiment

Exactly 31 paired samples per search, 10,000 complete-corpus repeats per side/sample, 16 fill cases or 20 swap cases; **32,240,000 timed native calls** total. Thresholds remained MAD <=5%, relative gain >=2%, three paired-saving MADs, 60s search admission ceiling and 2s decision reserve, with a 100,000,000-call assumed horizon.

The medians below are descriptive observations. Artifact equality alone refuses eligibility; noise and unrecovered cost provide additional rejection reasons.

| Run | Baseline median ns/call | Candidate median ns/call | Relative MAD B / C | Paid internal / complete CLI seconds | Decision |
| --- | ---: | ---: | ---: | ---: | --- |
{table}

Different fill Core and LLVM IR documents produced the same 15,480-byte native library under the selected Clang: `9060fcb2df0d51a45c12ff426bc02bcbf0553c6ac3cf3c5f8d77c6534b9f8b73`. Swap produced the same 15,432-byte library on both sides: `527992d971d479b12a0a8ef033745527f36764df081bc78ba4ac3d0ee94421d1`. No particular compiler pass is attributed without further evidence. Total internal paid search time was 9.864484806s; complete CLI time was 10.325908494s. Neither includes engineering, evaluator build, tool installation, model, energy or maintenance costs.

The temporary native .so files were removed by the instrument after execution. Artifact equality is supported by the instrument's actual before/after hashing and compiled/executed receipts; the later read-only audit did not reopen those deleted files. Core and LLVM IR texts are retained. Selected tool identity is not an independent attestation of every host library or the complete operating environment.

Ring-Buffer's three descriptive Hepta/C median ratios were 0.740983, 0.625515 and 1.589138. Relative MADs across those samples ranged from 24.007% to 49.971%; these seven-sample, different-backend controls do not qualify a speedup. Both favorable and regressive results remain retained. Automatic module qualification cost 19.441098545s internally and 20.440977547s for the enclosing CLI. Manual contract authoring, review and maintenance hours remain null.

## Evidence and reproduction

`results.json` provides the derived summary. `raw-evidence.zip` contains all retained development logs including failures, frozen command plans, source/tool snapshots, raw timing reports, the real module's generated sources/contracts/bridge, and independent read-only audits. `raw-evidence-manifest.json` lists every member and its verified SHA-256. Original paths inside reports describe the historical invocation; archive-relative member paths are portable.

The committed experiment is `experiments/hia_ndu_native_20261027/run_frozen.py`; its protocol was committed before timing. The source-bound functional runner and its exact environment helper are retained in `reproduction/`. Adapt tool paths for a new host, use a new output directory, preserve the same protocol and retain failures. The NDU bridge was built from upstream `f8c9419df6ddeb36ff8b522a50219981fb8d9345`; the retained build receipt binds its executable and inputs. No private upstream production source is vendored here.

## Acceptance status

The finite implementation and evidence improve P0/P1/P2/P3/P5/P6. P4 remains open: these candidates delivered no new native bytes or accepted net gain. P7 remains open: no full 35-gate run, new physical/multi-OS execution, long-lived workload or independent Agent productivity experiment was performed here. Whole-language soundness, full backend refinement, global optimality, universal Rust superiority, automatic C/C++ contract recovery, representative migration/human cost, and external-borrow/callback/shared-state native migration are not claimed. No candidate was activated or merged.

See [the Chinese report](REPORT.zh-CN.md) and the exact [machine-readable results](results.json).
"""
    (OUT / "README.md").write_text(english)
    chinese = f"""# Hepta P0–P7 本轮实现与冻结验收记录

## 交付结论

本轮源码已提交到 `{COMMIT}`，对应树 `0a02e3f958b787faef6df5d4bc8860793db95f4f`；[Draft PR #333](https://github.com/TrillionniumFoundation/Hepta/pull/333) 接续 #326。之后的证据提交只保存报告与原始记录，不把未测试的新源码归入本次验收。

冻结版 **54 项 Rust 测试、310 项 Python 定向测试全部通过，零跳过**。真实 Ring-Buffer 模块迁移、原生状态对照和固定三轮 NDU 搜索均实际执行。三轮 NDU 都返回 `abstain`，宿主保留 `no_change`。**P4 没有达标，完整 P0–P7 完成标志保持 false。**

## 本轮实际修改

### P0：版本身份与统一准入

公共 byte-swap 变换保留 primitive v7，拒绝静默丢掉 composite 的结构化身份。NDU 的准入范围仍明确限定 primitive v1–v6，不能因为公共 API 扩大支持就自动扩大候选合约。变换前后都经过同一 Core 验证入口，v1 的 fill-loop 只有实际引入 v2 操作时才升级，v2–v6 保留原版本。

C 资源契约新增统一、有界的文本/文件入口。原先普通 JSON 解析会把重复的 `access: read` / `access: mut` 静默变成后者；实际修复前探针确实因此接受了写指针函数。新入口在创建值图前拒绝重复键及转义后的同名键。API 区分 `None` 与显式空对象；复制时只接受内建 JSON 类型，用身份比较避开自定义 metaclass 方法，并只序列化脱离调用者的新图。它不承诺对并发修改提供原子时点快照，也无法恢复调用者事先用其他解析器丢掉的重复键。

### P1、P2：独立资源执行

Rust 复用既有 Machine，新增 fill、copy、move_within、swap、copy_range、fill_range 六类字节操作。范围检查先检查 offset，再用 extent-offset 检查 count，防止加法溢出；空区间仍验证端点；同 owner 移动覆盖重叠方向，跨 owner 复制使用安全 Rust 引用，未加入 unsafe 或随复制长度增长的临时缓冲。

执行 profile 为 `cfg-call-byte-owner-bulk-v3`。整个模块先检查能力集，未执行的 helper 也不能夹带不支持操作。chain 运行、直接 nominal/composite 输入和公共资源句柄仍未纳入此执行 profile。正常、trap、预算终止和分配失败继续使用既有账本语义；宿主容器释放不会冒充语言层 owner.drop。

冻结运行完成 **1,460 次 Rust/Python 单 Core 完整账本对照**，分解为 124 + 105 + 1,231；1,231 已含新增 fill-loop 的 168 次，不重复加总。另有 **60 次真实 native bulk 结果/分配器/abort 控制**，输入与上述账本语料部分重合。步骤数在同一 Core 的两个解释器之间比较；优化前后不要求相同步骤预算行为。这些是有限实际执行证据，未被称为全语言 soundness 或后端精化定理。

### P3：第二个真实候选及 no-change

新增注册规则 `full-view-fill-loop.v1`。它只接受从真实零常量开始、以同一 mutable view 的实际长度为上界、单位 checked 步长、写入不变 u8、唯一入口/回边且没有其他 body 副作用的循环。最终 index/condition 不能逃逸，length 可以逃逸并被保留。完整 Core 重验，模型的声明不能替代匹配条件或执行证据。指令预算、宿主中断和宿主分配失败等价性明确排除。

NDU 准入记录 pass、基线/候选 Core、实际原生产物、验证/测量 evidence digest、真实上游 evaluator 结果和付费成本。测量策略升级为 v2：**两个完整原生产物相同就拒绝 eligibility**。旧 v1 报告保持原样。

实验执行器还修复了外层先杀 CLI、可能遗留独立进程组的问题。新的同步 ContextVar 期限在工具轮询及阶段边界检查，由实际进程管理者清理和保留可取得的部分输出。没有异步 SIGALRM 抢占，没有硬实时保证；缺失、中断、过期或偏离固定协议的报告会停止后续轮次。相关 52 项开发控制测试通过后，又包含在冻结集成回归中。

### P5：真实模块与成本分母

实际使用固定上游 `AndersKaloer/Ring-Buffer@8de8fff55a0baee4fef2a1c6a82d258a27c3c0ba`，原始 C 和头文件保持不变。其一种列出的构建配置下，**9/9 函数体完成 Hepta 迁移，22/22 活跃项目声明有处置；9 个 C ABI wrapper 单独计数；留在原 C 中的函数体、拒绝和未处置函数体均为 0**。这条路径使用 Hepta 受检核心、Rust 后端和调用者声明的 record-view 契约，未声称自动恢复任意外部指针所有权。

状态测试覆盖 8 个容量，每个 2,048 步，共 **16,384 次转换**。**65,544 对入口比较 = 原 C 65,544 次 + Hepta 65,544 次 = 131,088 次实际 native 调用**；比较返回、独立 deque oracle、持久字段、每个 backing-store 字节、哨兵、输入不变性和指针身份。另有 9 个边界拒绝、6 个 owner 客户端样例（含 2 次真实分配拒绝，最终 live allocation 全为 0），布局核对及已实际编译的错误实现负控；错误实现被完整 oracle 拒绝。

人工契约原文 1,989 字节、canonical 1,028 字节均保留并绑定 hash。自动资格耗时内部 **19.441099 秒**、完整 CLI **20.440978 秒**。人工契约编写、审查、维护工时仍为未知，不能由自动工具耗时推导低人工成本。

### P6：实际原生版本生命周期

新增 NativeVersionDispatcher：真实后台 Clang 编译、verified Core/LLVM/ELF 身份检查、sealed memfd、generation CAS、逐调用 pin、旧候选排空、回退、取消发布和关闭。最多两个版本、一个后台编译任务，入口限定同质 i32/u32 标量；候选为基线或 exact swap rewrite。取消会撤回发布，已有编译依照原超时边界清理，不声称瞬时抢占。

**9 项实际 native 生命周期测试已计入 149 项 Core/NDU 组，不额外加到总数。** PID FD 暂停/恢复真实子进程，观察切换期间的版本与文件描述符生命周期；没有内部 loan 事件握手，因此不声称已经观测任意活动借用时点。每次调用在独立子进程中执行，资源私有；跨调用外部借用、回调、共享状态、持久 worker、进程内热补丁和生产更新开销尚未资格化。

## 固定性能实验：收益未成立

协议在源码提交前固定：两轮 fill-loop、一轮 swap；每轮 31 对样本，每侧每样本重复完整语料 10,000 次；fill 16 输入，swap 20 输入。共 **32,240,000 次 timed native 调用**，另有 104 次 untimed 单例正确性调用。没有去掉样本、放宽 MAD 5%/收益 2% 门槛或重跑直到通过。

| 实验 | 基线中位数 ns/调用 | 候选中位数 ns/调用 | 相对 MAD：基线/候选 | 内部付费/完整 CLI 秒 | 决策 |
| --- | ---: | ---: | ---: | ---: | --- |
{table}

以上只是描述性计时。两轮 fill 的不同 Core 和不同 LLVM IR，在相同 Clang 下得到完全相同的 15,480 字节产物，SHA-256 为 `9060fcb2df0d51a45c12ff426bc02bcbf0553c6ac3cf3c5f8d77c6534b9f8b73`。swap 两侧也相同，为 15,432 字节、`527992d971d479b12a0a8ef033745527f36764df081bc78ba4ac3d0ee94421d1`。这不能归因到未经观察的某个特定 LLVM pass，但能确定本轮变换没有带来不同的原生程序。

临时 .so 已由测量器在执行后清理；产物相等依据的是测量器实际执行前后取 hash、编译和执行回执。之后的只读审计没有重新读取已删除的二进制。完整 Core/LLVM IR 文本保留；所选工具身份也不代表整个宿主及所有动态库都已得到独立认证。

三轮各自的两侧 MAD 全超过 5%，固定调用 horizon 下也没有覆盖搜索成本。NDU 均实际返回 abstain。内部付费时间合计 **9.864485 秒**，完整 CLI 合计 **10.325908 秒**；工程实现、模型推理、工具安装、evaluator 构建、能耗及维护成本不在该数字中。新规则正确保留基线，**没有原生加速结论**。

真实 Ring-Buffer 的三个描述性 Hepta/C 中位数比值分别为 **0.740983、0.625515、1.589138**。第三项为退化方向；三组相对 MAD 范围 **24.007%–49.971%**，且是 GCC -O2 对受检 Rust -O3 路径的七样本对照。因此前两项也不能当作可重复加速或 Rust 优势证据，全部样本原样保留。

## P0–P7 验收状态

| 阶段 | 本轮已落地并实跑 | 仍未达到的完整验收 |
| --- | --- | --- |
| P0 | 版本身份保留、转换后重验、歧义契约拒绝、旧捕获语义回归 | 整个仓库兼容矩阵与全部旧测试未在本轮重跑 |
| P1 | 六类 bulk 操作的资源执行、边界/重叠/失败账本一致 | 完整 typed place、布局、复杂析构、并发及逃逸借用模型 |
| P2 | Python/Rust/native 的限定资源、返回、trap 及 allocator 控制 | 全语言与所有后端精化、完整可信基础的形式证明 |
| P3 | 两个注册规则、真实编译测量、真实 NDU advisory/no-change | 广泛候选空间和全程序优化正确性；全局最优未证明 |
| P4 | 固定等预算实验完整执行并保留反结果 | 未取得新的原生产物或可重复净收益；工业热函数仍缺证据 |
| P5 | 固定真实模块的完整处置、ABI、状态和自动成本 | 任意 C/C++、自动契约恢复、生产项目比例、人工与维护成本 |
| P6 | 实际后台编译、原生子进程 pin/CAS/排空/回退 | 外部借用、回调、任务、共享状态及生产热更新开销 |
| P7 | 同一冻结提交的定向验证、全输入与失败记录、只读独立审计 | 全 35 门槛、多 OS/实机、长期负载及独立 Agent 成本实验 |

仓库发现数为 **2,643 项 Python 测试**；本轮定向执行了其中 310 项。没有把发现数、之前提交的历史通过数或只读审查混入本次执行总数。主机是当前共享 Linux x86-64 容器，没有将其标为 dot 实机证据。

## 文件与复现

[results.json](results.json) 为机器可读汇总；[冻结集成摘要](frozen-integration-summary.json) 和 [冻结性能摘要](frozen-performance-summary.json) 绑定同一源码；[协议](protocol.json) 保留预设预算；[完整原始证据](raw-evidence.zip) 与 [逐文件清单](raw-evidence-manifest.json) 保留成功、早期 fixture/实现失败、修复后的验证、命令、源码/工具身份、实际 evaluator 回复、native 样本及真实模块生成物。压缩包所有成员已重新读取并逐个核对 SHA-256。

复现需要取冻结源码、准备记录中的工具与固定 NDU 上游版本，并使用全新的输出目录。实验入口为 `experiments/hia_ndu_native_20261027/run_frozen.py`；定向集成 runner 及环境构造脚本位于压缩包 `reproduction/`。旧证据未改写，代码未激活、未合并，完整验收标志保持 false。
"""
    (OUT / "REPORT.zh-CN.md").write_text(chinese)
    print(json.dumps({"output": str(OUT), "archive_members": len(records),
                      "archive_bytes": (OUT / "raw-evidence.zip").stat().st_size,
                      "archive_sha256": sha(OUT / "raw-evidence.zip"), "files": len(list(OUT.iterdir()))}))


if __name__ == "__main__":
    main()
