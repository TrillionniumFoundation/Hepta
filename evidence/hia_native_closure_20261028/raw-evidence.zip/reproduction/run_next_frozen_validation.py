#!/usr/bin/env python3
"""Source-bound targeted integration, including a real upstream C module.

Not the complete repository suite and not the 35-gate P7 qualification.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE / "hepta"
OUTPUT = BASE / "validation-next-frozen"
HELPER = runpy.run_path(str(BASE / "run_final_suite.py"), run_name="env_only")
FROZEN = runpy.run_path(str(ROOT / "experiments/hia_ndu_native_20261027/run_frozen.py"), run_name="snapshot_only")

GROUPS = {
    "core_and_ndu": [
        "tests.test_hia_fill_loop_opt", "tests.test_hia_ndu", "tests.test_hia_ndu_measure",
        "tests.test_hia_ndu_builder", "tests.test_hia_swap_opt", "tests.test_hia_swap_schema_retain",
        "tests.test_hia_swap_v4", "tests.test_hia_json_preflight", "tests.test_hia_schema_unification",
        "tests.test_hia_schema_collision", "tests.test_hia_schema_binding_audit",
        "tests.test_hia_unified_qualification", "tests.test_clang_capture",
        "tests.test_clang_capture_integration", "tests.test_hia_version_dispatch",
        "tests.test_hia_native_version_dispatch",
    ],
    "independent_rust": [
        "tests.test_hia_rust_shadow", "tests.test_hia_rust_owned_shadow",
        "tests.test_hia_rust_calls_shadow", "tests.test_hia_rust_chain_shadow",
        "tests.test_hia_rust_scalar_vm", "tests.test_hia_rust_crosscheck",
        "tests.test_hia_rust_crosscheck_cli", "tests.test_hia_rust_owned_vm",
        "tests.test_hia_rust_owned_cfg", "tests.test_hia_rust_owned_bulk",
    ],
    "migration": [
        "tests.test_c_contracts", "tests.test_c_ring_qualification_evidence",
        "tests.test_c_record_views", "tests.test_c_project", "tests.test_c_project_matrix",
        "tests.test_c_project_semantic_flags", "tests.test_c_project_source_arguments",
    ],
}


def save(name, value):
    FROZEN["save"](OUTPUT / name, value)


def actual(name, argv, env):
    before = time.perf_counter_ns()
    row = {"name": name, "argv": list(map(str, argv)), "cwd": str(ROOT),
           "started_utc": datetime.now(timezone.utc).isoformat(),
           "timeout_scope": "each underlying tool keeps its own bounded capture; outer coordinator does not kill child owners first"}
    with (OUTPUT / (name + ".stdout.log")).open("xb") as stdout, \
            (OUTPUT / (name + ".stderr.log")).open("xb") as stderr:
        proc = subprocess.Popen(row["argv"], cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            row["returncode"] = proc.wait()
        except BaseException:
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                proc.wait()
            raise
        finally:
            row["wall_ns"] = time.perf_counter_ns() - before
            row["finished_utc"] = datetime.now(timezone.utc).isoformat()
            save(name + ".process.json", row)
    for stream in ("stdout", "stderr"):
        path = OUTPUT / (name + "." + stream + ".log")
        row[stream] = {"path": str(path), "sha256": FROZEN["digest"](path), "bytes": path.stat().st_size}
    if name == "cargo":
        row["outcome"] = HELPER["cargo_outcome"]((OUTPUT / "cargo.stdout.log").read_text(), row["returncode"])
    elif name in GROUPS:
        row["outcome"] = HELPER["unittest_outcome"]((OUTPUT / (name + ".stderr.log")).read_text(), row["returncode"])
    else:
        report = json.loads((OUTPUT / "ring-buffer.json").read_text())
        row["outcome"] = {"passed": row["returncode"] == 0 and report.get("ok") is True,
                          "stage": report.get("stage"), "execution": report.get("execution"),
                          "report_sha256": FROZEN["digest"](OUTPUT / "ring-buffer.json")}
    save(name + ".process.json", row)
    return row


def main():
    OUTPUT.mkdir(exist_ok=False)
    source_before = FROZEN["snapshot"]()
    save("source-before.json", source_before)
    if not source_before["worktree_clean"] or not source_before["tracked_files_match_commit"]:
        raise RuntimeError("Final integration requires committed clean sources")
    env = HELPER["make_environment"]()
    env["CARGO_INCREMENTAL"] = "0"
    discovery = HELPER["discover"](env)
    save("repository-discovery.json", discovery)
    tool_paths = {"python": "/usr/bin/python3", "clang": "/usr/bin/clang-20", "gcc": "/usr/bin/gcc",
                  "source_rustc": env["RUSTC"], "cargo_wrapper": BASE / "p7-suite-bin/cargo",
                  "shadow_cargo": HELPER["SHADOW_RUST"] / "cargo",
                  "shadow_rustc": HELPER["SHADOW_RUST"] / "rustc",
                  "shadow_rustdoc": HELPER["SHADOW_RUST"] / "rustdoc",
                  "ndu_bridge": ROOT / "rust/hia-ndu-bridge/target/release/hia-ndu-bridge",
                  "ndu_build_provenance": ROOT / "rust/hia-ndu-bridge/build-provenance.json",
                  "runner": Path(__file__), "environment_helper": BASE / "run_final_suite.py"}
    tools_before = {key: FROZEN["tool"](value) for key, value in tool_paths.items()}
    save("tools-before.json", tools_before)
    plan = [{"name": "cargo", "argv": [str(BASE / "p7-suite-bin/cargo"), "test", "--locked", "--offline",
                                         "--manifest-path", "rust/hia-core-shadow/Cargo.toml"]}]
    for name, modules in GROUPS.items():
        plan.append({"name": name, "argv": ["/usr/bin/python3", "-m", "unittest", *modules, "-v"]})
    plan.append({"name": "ring_buffer", "argv": ["/usr/bin/python3", "tools/qualify_c_ring_buffer.py",
        "--clang", "/usr/bin/clang-20", "--rustc", env["RUSTC"], "--output", str(OUTPUT / "ring-buffer.json")]})
    save("command-plan.json", plan)
    report = {"schema": "hepta.hia.continuation-frozen-integration.v1", "git_head": source_before["git_head"],
              "source_was_committed": True, "ok": False, "status": "running", "gates": [],
              "source_scope": source_before["scope"], "repository_discovery_count": discovery.get("count"),
              "selected_modules": GROUPS, "complete_repository_suite_executed": False,
              "full_35_gate_qualification_executed": False, "p0_p7_fully_closed": False,
              "environment": {key: env[key] for key in HELPER["ENVIRONMENT_KEYS"] if key in env}}
    save("summary.json", report)
    try:
        for step in plan:
            print(json.dumps({"started": step["name"]}), flush=True)
            row = actual(step["name"], step["argv"], env)
            report["gates"].append(row)
            save("summary.json", report)
            print(json.dumps({"finished": step["name"], "seconds": row["wall_ns"] / 1e9,
                              "outcome": row["outcome"]}), flush=True)
        report["status"] = "completed"
    finally:
        after = FROZEN["snapshot"]()
        tools_after = {key: FROZEN["tool"](value) for key, value in tool_paths.items()}
        save("source-after.json", after)
        save("tools-after.json", tools_after)
        report.update(source_unchanged=source_before == after, tools_unchanged=tools_before == tools_after,
                      finished_utc=datetime.now(timezone.utc).isoformat())
        report["ok"] = (report["status"] == "completed" and report["source_unchanged"] and report["tools_unchanged"]
                        and len(report["gates"]) == len(plan) and all(row["outcome"]["passed"] for row in report["gates"]))
        save("summary.json", report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
