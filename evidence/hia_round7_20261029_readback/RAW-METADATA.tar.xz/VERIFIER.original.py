#!/usr/bin/env python3
"""Read one published commit into a new independent Git object database.

All repository bytes come from one HTTPS fetch of the explicitly supplied
published commit. The local plan supplies expected identities, never payloads.
Only a plan-matched, downloaded RESTORE.py is executed, in verify-only mode.
This program never reads the main checkout's object database or writes GitHub.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import time


REMOTE = "https://github.com/TrillionniumFoundation/Hepta.git"
REPOSITORY = "TrillionniumFoundation/Hepta"
SOURCE = "e57f440c32b54ffc8da795370fc288652f3c3319"
SOURCE_TREE = "c5f098feb0cd1d9e465a364088b49f2568ceea31"
SELECTION_SHA256 = "4feab6e6941d5fd62766de64eeb0c6e7ed12377c30a5456ac8a6d560f3d26482"
RAW_FILES, RAW_BYTES, PUBLIC_ZIPS = 3064, 376682379, 32
HEX40, HEX64 = re.compile(r"[0-9a-f]{40}"), re.compile(r"[0-9a-f]{64}")
CHUNK = 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def object_oid(kind, data):
    return hashlib.sha1(kind.encode("ascii") + b" " + str(len(data)).encode("ascii")
                        + b"\0" + data).hexdigest()


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def json_value(data):
    return json.loads(data.decode("utf-8"), object_pairs_hook=unique_pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def safe_path(value):
    require(isinstance(value, str) and bool(value), "empty/nontext path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and str(path) == value
            and not any(p.casefold() in {"", ".", "..", ".git"} for p in path.parts), "unsafe path")
    require("\\" not in value and ":" not in value
            and all(ord(c) >= 32 and ord(c) != 127 for c in value), "unsafe path syntax")
    return path


def regular_bytes(path, maximum=64 * CHUNK):
    # No-follow and nonblocking prevent a special file from blocking before fstat.
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                and before.st_size <= maximum, "nonregular/linked/oversized input")
        data = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
        identity = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size,
                              s.st_mtime_ns, s.st_ctime_ns)
        require(identity(before) == identity(after) and len(data) == before.st_size,
                "input changed during read")
        return data


def new_directory(path):
    path = Path(os.path.abspath(path))
    require(path.parent.is_dir(), "output parent does not exist")
    for ancestor in (path.parent, *path.parent.parents):
        require(stat.S_ISDIR(ancestor.lstat().st_mode), "symlink/non-directory output ancestor")
    path.mkdir(mode=0o700, exist_ok=False)
    return path


def write_bytes(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def write_json(path, value):
    write_bytes(path, (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode())


def validate_plan(raw, args):
    require(sha256(raw) == args.plan_sha256, "frozen publication plan SHA256 differs")
    plan = json_value(raw)
    require(plan["schema"] == "hepta.round7.evidence-publication-plan.v1", "wrong plan schema")
    require(plan["repository"] == REPOSITORY and plan["parent_sha"] == args.parent == SOURCE,
            "repository/parent differs")
    require(plan["source_commit"] == SOURCE and plan["source_tree"] == SOURCE_TREE
            and plan["base_tree_sha"] == SOURCE_TREE, "source identity differs")
    require(plan["expected_tree"] == args.tree, "published tree must match frozen plan")
    prefix = str(safe_path(plan["prefix"]))
    rows = plan["files"]
    require(isinstance(rows, list) and 1 <= len(rows) <= 1000, "invalid plan file count")
    names, nodes = set(), {}
    for row in rows:
        relative = safe_path(row["relative"])
        require(row["path"] == prefix + "/" + str(relative), "plan path/prefix differs")
        require(type(row["bytes"]) is int and 0 <= row["bytes"] <= 128 * CHUNK,
                "invalid plan byte count")
        require(HEX64.fullmatch(row["sha256"]) and HEX40.fullmatch(row["git_blob_sha"]),
                "invalid expected hash")
        require(row["path"] not in names, "duplicate planned file")
        names.add(row["path"])
        for number in range(1, len(relative.parts) + 1):
            name = "/".join(relative.parts[:number])
            kind = "file" if number == len(relative.parts) else "directory"
            old = nodes.setdefault(name.casefold(), (name, kind))
            require(old == (name, kind), "case alias or file/directory collision")
    require(plan["file_count"] == len(rows) and plan["bytes"] == sum(r["bytes"] for r in rows),
            "plan totals differ")
    required = {"ARCHIVE.json", "RAW-INDEX.json", "INPUT_SELECTION.json", "RESTORE.py",
                "PACKAGER.py", "VERIFY_ONLY.json", "ASSEMBLY-VERIFICATION.json",
                "README.md", "FINAL_SUMMARY.json", "FINAL_SUMMARY.md",
                "INDEPENDENT-RESTORE.json", "INDEPENDENT-COMPARE.json"}
    require(required <= {r["relative"] for r in rows}, "incomplete publication bundle")
    selection = next(r for r in rows if r["relative"] == "INPUT_SELECTION.json")
    require(selection["sha256"] == SELECTION_SHA256, "frozen input selection differs")
    return plan


class Commands:
    def __init__(self, output, environment):
        self.output, self.environment, self.rows = output, environment, []

    def run(self, label, argv, *, cwd, stdout_path=None, timeout=900):
        started = utc()
        start = time.monotonic_ns()
        path = stdout_path or self.output / "commands" / (label + ".stdout")
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as target:
            result = subprocess.run(argv, cwd=cwd, env=self.environment, stdout=target,
                                    stderr=subprocess.PIPE, timeout=timeout, check=False)
        stderr_path = self.output / "commands" / (label + ".stderr")
        write_bytes(stderr_path, result.stderr)
        row = {"label": label, "argv": argv, "cwd": str(cwd), "started_utc": started,
               "finished_utc": utc(), "wall_ns": time.monotonic_ns() - start,
               "returncode": result.returncode,
               "stdout": str(path.relative_to(self.output)),
               "stderr": str(stderr_path.relative_to(self.output))}
        self.rows.append(row)
        write_json(self.output / "commands" / (label + ".json"), row)
        require(result.returncode == 0, "command failed; original logs retained: " + label)
        return path


def check_object_database(repo, *, must_be_empty=False):
    require(not (repo / "objects/info/alternates").exists()
            and not (repo / "objects/info/http-alternates").exists(), "Git alternates forbidden")
    files = []
    for path in repo.rglob("*"):
        mode = path.lstat().st_mode
        require(stat.S_ISDIR(mode) or stat.S_ISREG(mode), "nonregular Git database entry")
        if stat.S_ISREG(mode):
            require(path.stat().st_nlink == 1, "linked Git database entry")
            if path.is_relative_to(repo / "objects"):
                files.append({"path": str(path.relative_to(repo)), "bytes": path.stat().st_size})
    require(not must_be_empty or not files, "fresh object database was not empty")
    return {"object_files": files, "object_file_count": len(files),
            "object_file_bytes": sum(r["bytes"] for r in files),
            "alternates_present": False, "symlinks_or_hardlinked_files_present": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--commit", required=True, help="Explicitly published evidence commit")
    parser.add_argument("--tree", required=True, help="Published commit's expected Git tree")
    parser.add_argument("--parent", required=True)
    parser.add_argument("--output", type=Path, required=True, help="New directory; must not exist")
    args = parser.parse_args()
    require(all(HEX40.fullmatch(v) for v in (args.commit, args.tree, args.parent))
            and HEX64.fullmatch(args.plan_sha256), "invalid pinned identity")
    raw_plan = regular_bytes(args.plan)
    plan = validate_plan(raw_plan, args)
    output_candidate = Path(os.path.abspath(args.output))
    allowed_parent = Path(os.path.abspath(__file__)).parent
    require(output_candidate != allowed_parent and output_candidate.is_relative_to(allowed_parent),
            "output must be a new descendant of this remote-readback directory")
    output = new_directory(args.output)
    commands = None
    try:
        write_bytes(output / "PUBLICATION-PLAN.original.json", raw_plan)
        write_bytes(output / "VERIFIER.original.py", regular_bytes(Path(__file__)))
        env = {k: v for k, v in os.environ.items() if not k.startswith(("GIT_", "PYTHON"))}
        env.update({"GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_SYSTEM": "/dev/null",
                    "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0",
                    "GIT_NO_REPLACE_OBJECTS": "1", "GIT_NO_LAZY_FETCH": "1",
                    "LC_ALL": "C", "LANG": "C"})
        for name in ("empty-template", "empty-hooks", "verify-tmp"):
            (output / name).mkdir(mode=0o700)
        env["TMPDIR"] = str(output / "verify-tmp")
        git = shutil.which("git")
        require(git is not None, "git executable unavailable")
        common = [git, "--no-replace-objects", "-c", "core.hooksPath=" + str(output / "empty-hooks"),
                  "-c", "gc.auto=0", "-c", "maintenance.auto=false", "-c", "fetch.fsckObjects=true",
                  "-c", "transfer.fsckObjects=true", "-c", "protocol.allow=never",
                  "-c", "protocol.https.allow=always", "-c", "http.followRedirects=false",
                  "-c", "credential.helper=", "-c", "core.attributesFile=/dev/null"]
        commands = Commands(output, env)
        commands.run("git-version", [git, "--version"], cwd=output)
        repo = output / "repository.git"
        commands.run("init", common + ["init", "--bare", "--object-format=sha1",
                     "--initial-branch=unused-readback", "--template=" + str(output / "empty-template"),
                     str(repo)], cwd=output)
        before = check_object_database(repo, must_be_empty=True)
        write_json(output / "OBJECT-DATABASE.before.json", before)
        config = commands.run("git-config", common + ["--git-dir=" + str(repo), "config",
                              "--local", "--list", "--show-origin"], cwd=output)
        require(not re.search(rb"alternates|promisor|partialclone|include|url\..*insteadof",
                              config.read_bytes(), re.I), "unexpected repository configuration")
        print(json.dumps({"stage": "fetch", "remote": REMOTE, "commit": args.commit,
                          "new_empty_object_database": str(repo)}), flush=True)
        commands.run("fetch", common + ["--git-dir=" + str(repo), "fetch", "--no-tags",
                     "--no-recurse-submodules", "--depth=1", REMOTE, args.commit], cwd=output)
        after = check_object_database(repo)
        write_json(output / "OBJECT-DATABASE.after.json", after)
        require(after["object_file_count"] > 0, "fetch left no Git objects")
        git_read = common + ["--git-dir=" + str(repo)]
        fetched = commands.run("fetch-head", git_read + ["rev-parse", "--verify", "FETCH_HEAD"], cwd=output)
        require(fetched.read_text().strip() == args.commit, "fetched commit differs")
        commit_path = commands.run("commit-object", git_read + ["cat-file", "commit", args.commit], cwd=output)
        commit = commit_path.read_bytes()
        require(object_oid("commit", commit) == args.commit, "commit bytes do not match Git object ID")
        headers = commit.split(b"\n\n", 1)[0].splitlines()
        trees = [x[5:].decode("ascii") for x in headers if x.startswith(b"tree ")]
        parents = [x[7:].decode("ascii") for x in headers if x.startswith(b"parent ")]
        require(trees == [args.tree] and parents == [args.parent], "published tree/parent differs")
        tree_path = commands.run("tree-object", git_read + ["cat-file", "tree", args.tree], cwd=output)
        require(object_oid("tree", tree_path.read_bytes()) == args.tree, "tree bytes differ from object ID")
        listing = commands.run("evidence-tree", git_read + ["ls-tree", "-r", "-z", "--full-tree",
                              args.commit, "--", plan["prefix"]], cwd=output)
        entries = {}
        for record in listing.read_bytes().split(b"\0"):
            if not record:
                continue
            metadata, name = record.split(b"\t", 1)
            mode, kind, oid = metadata.decode("ascii").split()
            name = name.decode("utf-8")
            require(mode == "100644" and kind == "blob" and name not in entries,
                    "unexpected Git tree mode/type/duplicate")
            entries[name] = oid
        require(set(entries) == {r["path"] for r in plan["files"]},
                "remote evidence directory has extra or missing files")
        bundle = output / "fetched-bundle"
        bundle.mkdir(mode=0o700)
        observations = []
        for number, row in enumerate(plan["files"], 1):
            path = bundle / row["relative"]
            commands.run("blob-" + str(number).zfill(4), git_read + ["show", "--no-ext-diff",
                         "--no-textconv", args.commit + ":" + row["path"]], cwd=output, stdout_path=path)
            data = regular_bytes(path, 128 * CHUNK)
            actual = {"path": row["path"], "relative": row["relative"], "bytes": len(data),
                      "sha256": sha256(data), "git_blob_sha": object_oid("blob", data),
                      "git_tree_entry_blob_sha": entries[row["path"]]}
            require(all(actual[k] == row[k] for k in ("bytes", "sha256", "git_blob_sha"))
                    and actual["git_blob_sha"] == entries[row["path"]],
                    "remote file identity differs: " + row["relative"])
            observations.append(actual)
        write_json(output / "REMOTE-FILE-COMPARISON.json", {
            "all_passed": True, "complete_directory_set_checked": True,
            "files": observations, "file_count": len(observations),
            "bytes": sum(r["bytes"] for r in observations),
            "payload_origin": "git show from the initially empty HTTPS-fetched independent object database",
            "local_plan_payloads_or_main_checkout_objects_used": False})
        require(sha256(regular_bytes(bundle / "INPUT_SELECTION.json")) == SELECTION_SHA256,
                "downloaded frozen selection differs")
        print(json.dumps({"stage": "remote_files_verified", "files": len(observations),
                          "bytes": plan["bytes"], "next": "downloaded RESTORE.py --verify-only"}), flush=True)
        verified_path = commands.run("restore-verify-only", [sys.executable, "-I", "-B",
                        str(bundle / "RESTORE.py"), "--verify-only"], cwd=bundle,
                        stdout_path=output / "RESTORE-VERIFY.stdout.json")
        verified = json_value(regular_bytes(verified_path))
        require(verified["all_passed"] is True and verified["source_commit"] == SOURCE
                and verified["source_tree"] == SOURCE_TREE, "restorer source/status differs")
        require(verified["raw_files"] == RAW_FILES and verified["raw_file_bytes"] == RAW_BYTES
                and verified["original_public_ci_zips_verified"] == PUBLIC_ZIPS,
                "restored frozen inventory differs")
        require(verified["project_code_executed"] is False and verified["output"] is None
                and verified["ci_expanded_files"] == verified["ci_expanded_bytes"] == 0,
                "restorer did not remain verify-only")
        require(not list((output / "verify-tmp").iterdir()), "temporary verification data remains")
        # The downloaded reader must not have changed the fetched bundle.
        for row in observations:
            data = regular_bytes(bundle / row["relative"], 128 * CHUNK)
            require(len(data) == row["bytes"] and sha256(data) == row["sha256"],
                    "bundle changed during standalone verification")
        check_object_database(repo)
        write_json(output / "COMMANDS.json", commands.rows)
        write_json(output / "HANDOFF.json", {
            "schema": "hepta.round7.independent-remote-readback.v1", "all_passed": True,
            "finished_utc": utc(), "remote": REMOTE, "published_commit": args.commit,
            "published_tree": args.tree, "parent": args.parent,
            "source_commit": SOURCE, "source_tree": SOURCE_TREE,
            "publication_plan_sha256": args.plan_sha256,
            "input_selection_sha256": SELECTION_SHA256,
            "fresh_empty_independent_object_database": True,
            "local_checkout_objects_used": False, "alternates_used": False,
            "inherited_git_environment_and_global_system_config_disabled": True,
            "initial_https_fetch_target": args.commit, "fetch_depth": 1,
            "subsequent_lazy_fetch_disabled": True,
            "remote_files": len(observations), "remote_file_bytes": plan["bytes"],
            "all_plan_size_sha256_and_git_blob_identities_match": True,
            "complete_remote_evidence_directory_matches_plan": True,
            "downloaded_bundle_unchanged_by_reader": True,
            "reader": "fetched-bundle/RESTORE.py", "reader_mode": "--verify-only",
            "reader_verification": verified, "public_ci_zips_verified": PUBLIC_ZIPS,
            "raw_files_verified": RAW_FILES, "raw_file_bytes_verified": RAW_BYTES,
            "project_native_compiler_or_performance_execution": False,
            "github_write_performed": False, "frozen_evidence_directory_modified": False,
            "file_comparison": "REMOTE-FILE-COMPARISON.json", "file_inventory": "FILES.json",
            "scope": "Remote publication transport/content verification; does not add scientific trials or change qualification denominators."})
        inventory = []
        for path in sorted(output.rglob("*")):
            mode = path.lstat().st_mode
            require(stat.S_ISDIR(mode) or stat.S_ISREG(mode), "nonregular readback output")
            if stat.S_ISREG(mode):
                size, digest = 0, hashlib.sha256()
                with path.open("rb") as stream:
                    while chunk := stream.read(CHUNK):
                        size += len(chunk)
                        digest.update(chunk)
                inventory.append({"path": str(path.relative_to(output)), "bytes": size,
                                  "sha256": digest.hexdigest()})
        write_json(output / "FILES.json", {"scope": "Every regular file except this manifest.",
                   "file_count_excluding_manifest": len(inventory),
                   "bytes_excluding_manifest": sum(r["bytes"] for r in inventory), "files": inventory})
        print(json.dumps({"all_passed": True, "handoff": str(output / "HANDOFF.json"),
                          "handoff_sha256": sha256((output / "HANDOFF.json").read_bytes()),
                          "remote_files": len(observations), "raw_files": RAW_FILES,
                          "raw_bytes": RAW_BYTES, "public_zips": PUBLIC_ZIPS}), flush=True)
    except BaseException as error:
        failure = {"all_passed": False, "failed_utc": utc(), "error_type": type(error).__name__,
                   "error": str(error), "requested_commit": args.commit,
                   "no_automatic_retry_or_reference_fallback": True,
                   "commands_completed": commands.rows if commands else []}
        write_json(output / "FAILURE.json", failure)
        raise


if __name__ == "__main__":
    main()
