# Performance protocol v2: fixed build layout and exact retention

The performance harness now builds under `/tmp/hepta-hia-perf-????????` for both retained and non-retained attempts. The caller's retention directory and `TMPDIR` no longer select the build location. Compiler flags, checked overflow and panic behavior, kernels, sample order, 63-sample inventory, acceptance thresholds and outlier policy are unchanged.

After the attempt, including a failed attempt, exact files are copied to the requested new evidence directory. A manifest maps each original absolute path to its retained copy and records verified sizes and SHA-256 values. Measured and observed native files must additionally match the identities previously recorded in `report.artifacts` and `resource_observation.artifacts`. A mismatch preserves the actual copied failure files and rejects qualification; it cannot produce a success manifest. This is file provenance, not compiler source-path remapping.

## Focused regression

Ten tests passed with zero skips. No benchmark timing sample ran. The build-path probe compiled both unchanged Rust references under retention parents of 18 and 371 characters, while actual build directories stayed 28 characters and actual compiler source paths stayed 62 characters. All three measured kernels and every defined allocation-named function—119 functions in each library—had exactly equal instruction bytes and addresses across the two locations. The `.text` section address and size also matched.

The retained JSON includes actual compiler commands, source/tool identities, complete ELF hashes, whole `.text` hashes, per-function hashes and exact whole-section byte differences. This test pair happened to have identical whole `.text` sections; the generated Rust ELF hashes differed because the embedded random path strings differ. The handwritten Rust ELF hash remained `123d8d5d9c20b23e9dc6f06ea43a52f018ef6690a5d9e20fd4257d17f40b9a77`.

## Why whole ELF or whole `.text` reproducibility is not claimed

The preceding literal-whole-section equality regression failed and was investigated without running timing samples. Its exact binaries, sources and assembly remain in `../hia_perf_layout_probe_20261026/`. The generated Rust sections differed in three RIP-relative operand bytes, each referencing a pooled empty string from unrelated standard-library filesystem, backtrace and UTF-8 functions. Every measured kernel and allocation helper still had the same bytes and address. Random source-path contents can change pooled data ordering even at equal path length. This diagnosis is preserved; it is not discarded in favor of the later matching pair.

The implemented invariant is independent measured-kernel code placement and content across retention-parent lengths, with every whole-file and whole-section identity disclosed. No remapping flag or backend API was added. This build-only regression does not assign a causal fraction of any prior timing difference to alignment and does not establish general performance superiority. The original timed run remains immutable; a separate run under protocol v2 is required.

Unit-test temporary directories were removed after assertions. This directory retains the full metadata; the earlier static probe retains actual diagnosis binaries. The forthcoming timed qualification separately retains its exact measured binaries through the verified copying mechanism.
