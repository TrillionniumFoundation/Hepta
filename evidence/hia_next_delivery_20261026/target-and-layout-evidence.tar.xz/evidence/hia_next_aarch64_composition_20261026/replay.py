#!/usr/bin/env python3
"""Retained same-compiler HIA composition replay on pinned AArch64 QEMU.

This supplemental evidence script does not modify compiler/qualifier sources.
It reuses the exact reviewed finite arena runtime and calloc adapter. Actual
allocator refusals are induced by holding one harness reservation while HIA
requests its single nonzero owner. Harness allocations are separately counted.
"""
from __future__ import annotations

import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
import traceback


def sha(data):
    return hashlib.sha256(data).hexdigest()


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


# Independent expected results, fixed before any native execution. These are
# the same 18 semantic cases as the host composite qualification. They do not
# derive expected results from emitted code or an interpreter result.
CASES = (
    ("stored", (False,), False, 91), ("stored", (True,), False, 91),
    ("choose", (False, 0), False, 10), ("choose", (False, 7), False, 17),
    ("choose", (False, (1 << 64) - 1), False, 10), ("choose", (False, 7), True, 10),
    ("choose", (True, 0), False, 0), ("choose", (True, 7), False, 7),
    ("choose", (True, (1 << 64) - 1), False, 0), ("choose", (True, 7), True, 0),
    ("task_case", (0,), False, 33), ("task_case", (0,), True, 250),
    ("task_case", (1,), False, 13), ("task_case", (1,), True, 250),
    ("task_case", (2,), False, 28), ("task_case", (2,), True, 250),
    ("task_case", (255,), False, 28), ("task_case", (255,), True, 250),
)
EXPORTS = ("choose", "stored", "task_case")
SIGNATURES = {"stored": (["bool"], ["u8"]), "choose": (["bool", "usize"], ["usize"]),
              "task_case": (["u8"], ["usize"])}
CTYPES = {"bool": "_Bool", "usize": "hepta_size", "u8": "hepta_u8"}


ROW_WRITER = r'''
static void write_case_row(hepta_size index, hepta_size result) {
    char text[192]; hepta_size used=0;
    const char prefix[]="HIA_COMPOSITE ";
    for(hepta_size i=0;i<sizeof(prefix)-1;i++)text[used++]=prefix[i];
    hepta_u64 values[6]={index,result,successful_allocations,releases,outstanding,denied_allocations};
    for(hepta_size i=0;i<6;i++) {
        char digits[20]; hepta_size n=0; hepta_u64 value=values[i];
        do {digits[n++]=(char)('0'+value%10);value/=10;} while(value);
        while(n)text[used++]=digits[--n];
        text[used++]=i==5?'\n':' ';
    }
    register long x0 __asm__("x0")=1;
    register const char *x1 __asm__("x1")=text;
    register hepta_size x2 __asm__("x2")=used;
    register long x8 __asm__("x8")=64;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x8) : "memory");
    if(x0!=(long)used)hepta_exit(40);
}
'''


def literal(value, typ):
    return "((_Bool)" + str(int(value)) + ")" if typ == "bool" else (
        "((" + CTYPES[typ] + ")" + str(value) + "ULL)")


def expected_rows():
    allocations = releases = refusals = 0
    rows = []
    for index, (function, args, fail, expected) in enumerate(CASES):
        if fail:
            # A one-byte harness reservation forces actual NULL from the
            # unchanged single-live-allocation target arena.
            allocations += 1
            releases += 1
            refusals += 1
        elif function != "choose" or args[1] == 7:
            allocations += 1
            releases += 1
        rows.append([index, expected, allocations, releases, 0, refusals])
    assert (allocations, releases, refusals) == (14, 14, 6)
    return rows


def matrix_driver(runtime_prefix, adapter):
    declarations = ["extern " + CTYPES[result[0]] + " " + name + "(" +
                    ", ".join(CTYPES[typ] for typ in parameters) + ");"
                    for name, (parameters, result) in sorted(SIGNATURES.items())]
    lines = ["static int smoke(void) {", "  if(!memory_primitives_ok())return 39;"]
    for index, (name, args, fail, expected) in enumerate(CASES):
        parameters, result = SIGNATURES[name]
        expression = name + "(" + ",".join(literal(value, typ) for value, typ in zip(args, parameters)) + ")"
        lines.append("  {")
        if fail:
            lines += ["    void *reservation=malloc(1);if(!reservation)return 80;",
                      "    hepta_size value=" + expression + ";",
                      "    if(outstanding!=1)return 81;", "    free(reservation);"]
        else:
            lines.append("    hepta_size value=" + expression + ";")
        lines += ["    write_case_row(" + str(index) + ",value);",
                  "    if(value!=" + literal(expected, result[0]) + ")return " + str(31 + index) + ";",
                  "    if(outstanding!=0)return 82;", "  }"]
    lines += ["  write_counters();",
              "  if(successful_allocations!=14 || releases!=14 || outstanding!=0 || denied_allocations!=6)return 83;",
              "  return 0;", "}",
              "__attribute__((noreturn)) void _start(void){hepta_exit((hepta_u32)smoke());}"]
    return runtime_prefix + adapter + ROW_WRITER + "\n".join(declarations + lines) + "\n"


def trap_driver(runtime_prefix, adapter, mode):
    return runtime_prefix + adapter + "\n" + (
        "extern hepta_size task_case(hepta_u8);\n"
        "static int smoke(void){if(!memory_primitives_ok())return 39;"
        "(void)task_case(" + str(mode) + ");write_counters();return 84;}\n"
        "__attribute__((noreturn)) void _start(void){hepta_exit((hepta_u32)smoke());}\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--clang", default="/usr/lib/llvm-20/bin/clang")
    parser.add_argument("--linker", default="/tmp/hepta-ai-rust-1.90.0/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld")
    parser.add_argument("--qemu", default="/tmp/hepta-ai-verification/qemu-8.2.2/qemu-aarch64-static")
    args = parser.parse_args()
    root = args.repo.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        parser.error("output must be new and have an existing parent")
    sys.path.insert(0, str(root))
    from hepta.clang_capture import run_bounded
    from hepta.hia_program import execute_program, verify_core
    from hepta.hia_program_runtime import HIAProgramTrap
    from hepta.hia_program_llvm import (HIAProgramLLVMRejected, TARGET_AARCH64,
                                       compile_program_llvm, emit_program_llvm)
    from hepta.hia_program_aarch64 import (QEMU_SHA256, REVIEWED_RUNTIME_SHA256, _ADAPTER,
                                          _RUNTIME_EXPORTS, _runtime_prefix)
    from hepta.native_tool_identity import digest_executable
    from hepta.object_symbols import inspect_object_symbols
    from hepta.owned_aarch64_link import inspect_synthetic_aarch64_elf
    from hepta.pipeline import compiler_hash
    from tools.release_check import snapshot
    from tools.qualify_hia_program_composite import combined_program, protocol_controls

    output.mkdir()
    script = Path(__file__).read_bytes()
    (output / "replay.py").write_bytes(script)
    report = {"schema": "hepta.hia.composite-aarch64-supplement.v1", "ok": False, "status": "blocked",
              "script_sha256": sha(script), "expected_commit": args.expected_commit,
              "processes": [], "positive_runs": [], "controls": [],
              "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              "claims": {"physical_hardware_executed": False, "general_allocator_qualified": False,
                         "backend_refinement_proved": False, "whole_language_soundness_proved": False,
                         "rust_frontend_used": False, "high_level_source_required": False,
                         "finite_composed_aarch64_execution_passed": False}}

    def run(command, *, timeout=60, expected=0):
        index = len(report["processes"])
        command = list(map(str, command))
        result = run_bounded(command, timeout=timeout, stdout_limit=65536, stderr_limit=1048576)
        stdout, stderr = output / f"process-{index:02d}.stdout", output / f"process-{index:02d}.stderr"
        stdout.write_text(result.stdout); stderr.write_text(result.stderr)
        row = {"argv": command, "returncode": result.returncode,
               "stdout": stdout.name, "stdout_sha256": sha(stdout.read_bytes()),
               "stderr": stderr.name, "stderr_sha256": sha(stderr.read_bytes())}
        report["processes"].append(row)
        if expected is not None and result.returncode != expected:
            raise ValueError("actual subprocess exit differs: " + repr(row) + "\n" + result.stderr[:3000])
        return index, result

    def require(condition, message):
        if not condition:
            raise ValueError(message)

    try:
        _, git = run(["git", "-C", root, "rev-parse", "HEAD"])
        report["git_commit"] = git.stdout.strip()
        require(report["git_commit"] == args.expected_commit, "unexpected source commit")
        _, dirty = run(["git", "-C", root, "status", "--porcelain", "--untracked-files=no"])
        require(not dirty.stdout.strip(), "tracked source is not frozen")
        report["source_before"] = snapshot()
        report["compiler_tree_sha256"] = compiler_hash()
        runtime_prefix = _runtime_prefix()
        report["reviewed_runtime_sha256"] = REVIEWED_RUNTIME_SHA256
        report["runtime_prefix_sha256"] = sha(runtime_prefix.encode())
        report["calloc_adapter_sha256"] = sha(_ADAPTER.encode())
        tools = {}
        for role, supplied in (("clang", args.clang), ("linker", args.linker), ("qemu", args.qemu)):
            found = shutil.which(supplied)
            require(found is not None, "missing tool: " + role)
            path = Path(found).resolve(strict=True)
            tools[role] = {"path": str(path), "sha256": digest_executable(path)}
        require(tools["qemu"]["sha256"] == QEMU_SHA256, "QEMU is not the exact reviewed executable")
        report["tools"] = tools
        for role, command in (("clang", [tools["clang"]["path"], "--version"]),
                              ("linker", [tools["linker"]["path"], "-flavor", "gnu", "--version"]),
                              ("qemu", [tools["qemu"]["path"], "--version"])):
            process, version = run(command, timeout=10)
            tools[role].update(version=version.stdout.splitlines()[0], version_process=process)

        program = verify_core(combined_program())
        normalized = verify_core(program.canonical_bytes)
        require(tuple(sorted(program.scalar_entrypoints)) == EXPORTS and
                normalized.scalar_entrypoints == program.scalar_entrypoints, "canonical public interface changed")
        (output / "input.hia.json").write_bytes(program.structured_bytes)
        (output / "normalized.hia.json").write_bytes(program.canonical_bytes)
        write_json(output / "fixed-cases.json", [
            {"function": name, "arguments": list(values), "refuse": refusal, "expected": expected}
            for name, values, refusal, expected in CASES])
        report["input_sha256"], report["core_sha256"] = program.input_sha256, program.sha256
        report["expected_rows"] = expected_rows()

        def build_and_run(label, core, runtime, *, required, expected_exit=0, raw_ir=None):
            directory = output / label
            directory.mkdir()
            (directory / "input.hia.json").write_bytes(core.structured_bytes or core.canonical_bytes)
            (directory / "normalized.hia.json").write_bytes(core.canonical_bytes)
            ir = emit_program_llvm(core, target=TARGET_AARCH64)
            (directory / "program.ll").write_text(raw_ir if raw_ir is not None else ir.text)
            object_path = directory / "core.o"
            if raw_ir is None:
                receipt = compile_program_llvm(ir, program=core, output=object_path,
                                               clang=tools["clang"]["path"], kind="object")
            else:
                compile_process, _ = run([tools["clang"]["path"], "--target=" + TARGET_AARCH64,
                    "-x", "ir", "-O3", "-fPIC", "-c", directory / "program.ll", "-o", object_path])
                receipt = {"qualified_hia_artifact": False, "compile_process": compile_process,
                           "artifact_sha256": sha(object_path.read_bytes()), "exports": list(ir.exports)}
            runtime_c, runtime_o, executable = directory / "runtime.c", directory / "runtime.o", directory / "program.elf"
            runtime_c.write_text(runtime)
            compile_process, _ = run([tools["clang"]["path"], "--target=" + TARGET_AARCH64,
                "-x", "c", "-std=c11", "-ffreestanding", "-nostdinc", "-fno-builtin", "-fno-stack-protector",
                "-O2", "-Wall", "-Wextra", "-Werror", "-c", runtime_c, "-o", runtime_o])
            symbols = inspect_object_symbols(runtime_o.read_bytes(), "ELF64", 183)
            require(symbols["defined"] == _RUNTIME_EXPORTS and symbols["undefined"] == frozenset(required),
                    "target runtime public/undefined inventory mismatch")
            link_process, _ = run([tools["linker"]["path"], "-flavor", "gnu", "-m", "aarch64linux",
                "-static", "-z", "noexecstack", "-e", "_start", object_path, runtime_o, "-o", executable])
            payload = executable.read_bytes()
            shape = inspect_synthetic_aarch64_elf(payload, tuple(ir.exports) + ("calloc",))
            process, actual = run([tools["qemu"]["path"], executable], timeout=25, expected=expected_exit)
            require(executable.read_bytes() == payload and sha(object_path.read_bytes()) == receipt["artifact_sha256"],
                    "compiled/executed artifact changed")
            require(emit_program_llvm(core, target=TARGET_AARCH64) == ir, "emitter identity changed during execution")
            return {"label": label, "core_sha256": core.sha256, "input_sha256": core.input_sha256,
                    "llvm_sha256": sha((raw_ir if raw_ir is not None else ir.text).encode()),
                    "core_object": receipt, "runtime_compile_process": compile_process,
                    "runtime_inventory": {key: sorted(value) for key, value in symbols.items()},
                    "link_process": link_process, "elf_sha256": sha(payload), "elf_bytes": len(payload),
                    "elf_inventory": shape, "execution_process": process,
                    "execution": {"returncode": actual.returncode, "stdout": actual.stdout, "stderr": actual.stderr}}

        runtime = matrix_driver(runtime_prefix, _ADAPTER)
        for label, core in (("structured", program), ("normalized", normalized)):
            references = []
            for name, values, refusal, expected in CASES:
                reference = execute_program(core, name, list(values), allocation_fail_at=1 if refusal else None)
                require(reference["result"] == expected and reference["resources"]["live_owners"] == 0,
                        "independent reference differs from fixed expected result/cleanup")
                references.append(reference)
            observed = build_and_run(label, core, runtime, required=EXPORTS)
            lines = observed["execution"]["stdout"].splitlines()
            require(len(lines) == len(CASES) + 1 and lines[-1] == "HIA_AARCH64 resources 14 14 0 6",
                    "actual target output or allocator totals differ")
            rows = []
            for line in lines[:-1]:
                require(line.startswith("HIA_COMPOSITE "), "unexpected target output prefix")
                rows.append([int(value) for value in line.split()[1:]])
            require(rows == expected_rows(), "actual target result/counter row differs from fixed oracle")
            observed.update(reference_cases=references, observed_rows=rows,
                allocator={"total_allocations": 14, "total_frees": 14, "outstanding": 0, "null_refusals": 6,
                           "hia_allocations": 8, "hia_frees": 8, "harness_reservations": 6, "harness_releases": 6})
            report["positive_runs"].append(observed)

        wrong = program.as_dict()
        function = next(fn for fn in wrong["functions"] if fn["name"] == "stored")
        candidates = [operation for block in function["blocks"] for operation in block["ops"]
                      if operation["op"] == "const" and operation["out"][0]["type"] == "u8"
                      and operation["attrs"]["value"] == 91]
        require(len(candidates) == 1, "wrong-Core mutation site changed")
        candidates[0]["attrs"]["value"] = 90
        changed = verify_core(wrong)
        require(execute_program(changed, "stored", [False])["result"] == 90, "wrong Core did not change behavior")
        wrong_result = build_and_run("wrong-core-result", changed, runtime, required=EXPORTS, expected_exit=31)
        require(wrong_result["execution"]["stdout"] == "HIA_COMPOSITE 0 90 1 1 0 0\n",
                "wrong-Core failure did not come from the intended result difference")
        report["controls"].append(wrong_result)

        ir = emit_program_llvm(program, target=TARGET_AARCH64)
        missing_free = "\n".join(line for line in ir.text.splitlines() if "call void @free(" not in line) + "\n"
        require(missing_free != ir.text, "missing-free control changed no instructions")
        forged = replace(ir, text=missing_free, sha256=sha(missing_free.encode()))
        try:
            compile_program_llvm(forged, program=program, output=output / "forbidden.o",
                                 clang=tools["clang"]["path"], kind="object")
        except HIAProgramLLVMRejected as error:
            require(str(error).startswith("E_HIA_PROGRAM_ORIGIN:"), "unrelated rejection of forged LLVM")
            report["rehashed_native_ir_rejected"] = {"code": "E_HIA_PROGRAM_ORIGIN", "output_absent": not (output / "forbidden.o").exists()}
        else:
            raise ValueError("public compiler accepted changed LLVM")
        leaked = build_and_run("unqualified-missing-free", program, runtime, required=EXPORTS,
                               expected_exit=82, raw_ir=missing_free)
        require(leaked["execution"]["stdout"] == "HIA_COMPOSITE 0 91 1 0 1 0\n",
                "allocator observer did not catch exact correct-result/missing-free control")
        report["controls"].append(leaked)

        for name, document, mode in protocol_controls():
            core = verify_core(document)
            try:
                execute_program(core, "task_case", [mode])
            except HIAProgramTrap as trap:
                require(trap.code == "user", "protocol failure used an unrelated trap")
                reference = trap.report
            else:
                raise ValueError("protocol control did not trap in interpreter")
            observed = build_and_run(name, core, trap_driver(runtime_prefix, _ADAPTER, mode),
                                     required=("task_case",), expected_exit=134)
            require(observed["execution"]["stdout"] == "" and observed["execution"]["stderr"] == "",
                    "protocol abort produced unexpected output")
            observed["reference_trap"] = reference
            report["controls"].append(observed)

        report["source_after"] = snapshot()
        require(report["source_after"] == report["source_before"] and compiler_hash() == report["compiler_tree_sha256"],
                "source changed during target replay")
        require(_runtime_prefix() == runtime_prefix and all(digest_executable(Path(tool["path"])) == tool["sha256"]
                for tool in tools.values()), "target runtime/tool changed")
        report.update(ok=True, status="finite_composed_aarch64_qemu_passed",
                      counts={"structured_return_cases": 18, "normalized_return_cases": 18,
                              "actual_null_refusals": 12, "actual_wrong_core_result_controls": 1,
                              "actual_missing_free_controls": 1, "actual_protocol_abort_controls": 4})
        report["claims"]["finite_composed_aarch64_execution_passed"] = True
        report["scope"] = {"runtime": "exact reviewed4096-byte one-live-owner allocator plus exact calloc adapter",
                           "refusal": "real NULL from unchanged arena while one harness reservation is held",
                           "execution": "pinned QEMU8.2.2 Linux userspace; no physical board/device protocol claim",
                           "traps": "reviewed runtime exits134; no post-trap cleanup promised",
                           "native_codegen": "same verified canonical core and direct LLVM backend as host qualification"}
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()[-8000:]}
    finally:
        report["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        write_json(output / "qualification.json", report)
        files = {}
        for path in sorted(output.rglob("*")):
            if path.is_file():
                files[path.relative_to(output).as_posix()] = {"bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
        write_json(output / "manifest.json", {"schema": "hepta.hia.composite-aarch64-files.v1", "files": files})
    print(json.dumps({"ok": report["ok"], "status": report["status"], "output": str(output),
                      "counts": report.get("counts"), "error": report.get("error")}, sort_keys=True))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
