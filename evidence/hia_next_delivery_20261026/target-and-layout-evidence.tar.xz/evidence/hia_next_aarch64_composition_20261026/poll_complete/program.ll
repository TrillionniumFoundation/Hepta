; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "aarch64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal { i32, %hia.buffer, i64, i64 } @__hia_fn_0(%hia.buffer %p_0_0, i64 %p_0_1) {
b0:
  %t1 = icmp eq i64 %p_0_1, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_0, 1
  %t3 = extractvalue %hia.buffer %p_1_0, 0
  %t4 = extractvalue %hia.buffer %p_1_0, 1
  %t5 = icmp ult i64 0, %t4
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = getelementptr i8, ptr %t3, i64 0
  %t8 = load i8, ptr %t7, align 1
  %t9 = zext i8 %t8 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t2, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = extractvalue %hia.buffer %p_1_0, 0
  call void @free(ptr %t15) nobuiltin
  %t16 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t17 = extractvalue %hia.alloc %t16, 0
  %t18 = extractvalue %hia.alloc %t16, 1
  %t19 = select i1 %t18, i64 0, i64 0
  %t20 = insertvalue %hia.buffer %t17, i64 %t19, 1
  %t21 = insertvalue { i32, %hia.buffer, i64, i64 } zeroinitializer, i32 1, 0
  %t22 = insertvalue { i32, %hia.buffer, i64, i64 } %t21, %hia.buffer %t20, 1
  %t23 = insertvalue { i32, %hia.buffer, i64, i64 } %t22, i64 0, 2
  %t24 = insertvalue { i32, %hia.buffer, i64, i64 } %t23, i64 %t11, 3
  ret { i32, %hia.buffer, i64, i64 } %t24
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %t25 = extractvalue %hia.buffer %p_2_0, 0
  %t26 = extractvalue %hia.buffer %p_2_0, 1
  %t27 = icmp ult i64 0, %t26
  br i1 %t27, label %ok_28, label %trap_28
trap_28:
  call void @abort()
  unreachable
ok_28:
  %t29 = getelementptr i8, ptr %t25, i64 0
  %t30 = load i8, ptr %t29, align 1
  %t31 = trunc i64 %p_2_1 to i8
  %t32 = extractvalue %hia.buffer %p_2_0, 0
  %t33 = extractvalue %hia.buffer %p_2_0, 1
  %t34 = icmp ult i64 0, %t33
  br i1 %t34, label %ok_35, label %trap_35
trap_35:
  call void @abort()
  unreachable
ok_35:
  %t36 = getelementptr i8, ptr %t32, i64 0
  store i8 %t31, ptr %t36, align 1
  %t37 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %p_2_1, i64 1)
  %t38 = extractvalue { i64, i1 } %t37, 0
  %t39 = extractvalue { i64, i1 } %t37, 1
  %t40 = xor i1 %t39, true
  br i1 %t40, label %ok_41, label %trap_41
trap_41:
  call void @abort()
  unreachable
ok_41:
  %t42 = insertvalue { i32, %hia.buffer, i64, i64 } zeroinitializer, i32 0, 0
  %t43 = insertvalue { i32, %hia.buffer, i64, i64 } %t42, %hia.buffer %p_2_0, 1
  %t44 = insertvalue { i32, %hia.buffer, i64, i64 } %t43, i64 %t38, 2
  %t45 = insertvalue { i32, %hia.buffer, i64, i64 } %t44, i64 0, 3
  ret { i32, %hia.buffer, i64, i64 } %t45
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal void @__hia_fn_1(%hia.buffer %p_0_0, i64 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 0
  call void @free(ptr %t1) nobuiltin
  ret void
}

define internal i64 @__hia_fn_2(i8 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 7, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 7, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_1_0, 0
  call void @free(ptr %t6) nobuiltin
  ret i64 250
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_2_1 = phi i8 [ %p_0_0, %edge_0 ]
  %t7 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t8 = extractvalue %hia.alloc %t7, 0
  %t9 = extractvalue %hia.alloc %t7, 1
  %t10 = select i1 %t9, i64 0, i64 0
  %t11 = insertvalue %hia.buffer %t8, i64 %t10, 1
  %t12 = icmp eq i8 %p_2_1, 0
  br i1 %t12, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ 0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t11, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_3_3 = phi i64 [ 2, %edge_2 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ]
  %t13 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_3(i8 %p_3_0, %hia.buffer %p_3_1, %hia.buffer %p_3_2, i64 %p_3_3, i64 %p_3_4)
  %t14 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, 0
  %t15 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, 1
  %t16 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, 2
  %t17 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, 3
  %t18 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, 4
  %t19 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_3(i8 %t14, %hia.buffer %t15, %hia.buffer %t16, i64 %t17, i64 %t18)
  %t20 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t19, 0
  %t21 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t19, 1
  %t22 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t19, 2
  %t23 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t19, 3
  %t24 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t19, 4
  call void @__hia_fn_4(i8 %t20, %hia.buffer %t21, %hia.buffer %t22, i64 %t23, i64 %t24)
  %t25 = zext i8 %t20 to i64
  %t26 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 30, i64 %t25)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  %t29 = xor i1 %t28, true
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  ret i64 %t27
b4:
  %p_4_0 = phi i8 [ 0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %t11, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_4_3 = phi i64 [ 2, %edge_3 ]
  %p_4_4 = phi i64 [ 0, %edge_3 ]
  %p_4_5 = phi i8 [ %p_2_1, %edge_3 ]
  %t31 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %p_4_0, %hia.buffer %p_4_1, %hia.buffer %p_4_2, i64 %p_4_3, i64 %p_4_4)
  %t32 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t31, 0
  %t33 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t31, 1
  %t34 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t31, 2
  %t35 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t31, 3
  %t36 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t31, 4
  %t37 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(i8 %t32, %hia.buffer %t33, %hia.buffer %t34, i64 %t35, i64 %t36)
  %t38 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t37, 0
  %t39 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t37, 1
  %t40 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t37, 2
  %t41 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t37, 3
  %t42 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t37, 4
  %t43 = icmp eq i8 %p_4_5, 1
  br i1 %t43, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i8 [ %t38, %edge_4 ]
  %p_5_1 = phi %hia.buffer [ %t39, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %t40, %edge_4 ]
  %p_5_3 = phi i64 [ %t41, %edge_4 ]
  %p_5_4 = phi i64 [ %t42, %edge_4 ]
  %t44 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_3(i8 %p_5_0, %hia.buffer %p_5_1, %hia.buffer %p_5_2, i64 %p_5_3, i64 %p_5_4)
  %t45 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t44, 0
  %t46 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t44, 1
  %t47 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t44, 2
  %t48 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t44, 3
  %t49 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t44, 4
  call void @__hia_fn_4(i8 %t45, %hia.buffer %t46, %hia.buffer %t47, i64 %t48, i64 %t49)
  %t50 = zext i8 %t45 to i64
  %t51 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 10, i64 %t50)
  %t52 = extractvalue { i64, i1 } %t51, 0
  %t53 = extractvalue { i64, i1 } %t51, 1
  %t54 = xor i1 %t53, true
  br i1 %t54, label %ok_55, label %trap_55
trap_55:
  call void @abort()
  unreachable
ok_55:
  ret i64 %t52
b6:
  %p_6_0 = phi i8 [ %t38, %edge_5 ], [ %t58, %edge_8 ]
  %p_6_1 = phi %hia.buffer [ %t39, %edge_5 ], [ %t59, %edge_8 ]
  %p_6_2 = phi %hia.buffer [ %t40, %edge_5 ], [ %t60, %edge_8 ]
  %p_6_3 = phi i64 [ %t41, %edge_5 ], [ %t61, %edge_8 ]
  %p_6_4 = phi i64 [ %t42, %edge_5 ], [ %t62, %edge_8 ]
  %t56 = icmp eq i8 %p_6_0, 2
  br i1 %t56, label %edge_6, label %edge_7
b7:
  %p_7_0 = phi i8 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi %hia.buffer [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %t57 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(i8 %p_7_0, %hia.buffer %p_7_1, %hia.buffer %p_7_2, i64 %p_7_3, i64 %p_7_4)
  %t58 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t57, 0
  %t59 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t57, 1
  %t60 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t57, 2
  %t61 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t57, 3
  %t62 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t57, 4
  br label %edge_8
b8:
  %p_8_0 = phi i8 [ %p_6_0, %edge_6 ]
  %p_8_1 = phi %hia.buffer [ %p_6_1, %edge_6 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_6 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_6 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_6 ]
  %t63 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(i8 %p_8_0, %hia.buffer %p_8_1, %hia.buffer %p_8_2, i64 %p_8_3, i64 %p_8_4)
  %t64 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t63, 0
  %t65 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t63, 1
  %t66 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t63, 2
  %t67 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t63, 3
  %t68 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t63, 4
  %t69 = call i64 @__hia_fn_7(i8 %t64, %hia.buffer %t65, %hia.buffer %t66, i64 %t67, i64 %t68)
  %t70 = zext i8 %t64 to i64
  %t71 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %t70, i64 10)
  %t72 = extractvalue { i64, i1 } %t71, 0
  %t73 = extractvalue { i64, i1 } %t71, 1
  %t74 = xor i1 %t73, true
  br i1 %t74, label %ok_75, label %trap_75
trap_75:
  call void @abort()
  unreachable
ok_75:
  %t76 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t72, i64 %t69)
  %t77 = extractvalue { i64, i1 } %t76, 0
  %t78 = extractvalue { i64, i1 } %t76, 1
  %t79 = xor i1 %t78, true
  br i1 %t79, label %ok_80, label %trap_80
trap_80:
  call void @abort()
  unreachable
ok_80:
  ret i64 %t77
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b8
edge_7:
  br label %b7
edge_8:
  br label %b6
}

define internal { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_3(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp ult i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  call void @__hia_fn_1(%hia.buffer %p_1_2, i64 %p_1_3)
  %t2 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  %t7 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 3, 0
  %t8 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t7, %hia.buffer %p_1_1, 1
  %t9 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t8, %hia.buffer %t6, 2
  %t10 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t9, i64 0, 3
  %t11 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t10, i64 0, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t11
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %t12 = icmp ule i8 %p_2_0, 3
  br i1 %t12, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_2_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_2 ]
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %p_3_0, 0
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, %hia.buffer %p_3_1, 1
  %t15 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t14, %hia.buffer %p_3_2, 2
  %t16 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, i64 %p_3_3, 3
  %t17 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t16, i64 %p_3_4, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t17
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal void @__hia_fn_4(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 3
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  call void @free(ptr %t2) nobuiltin
  %t3 = extractvalue %hia.buffer %p_1_2, 0
  call void @free(ptr %t3) nobuiltin
  ret void
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 1, 0
  %t3 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t2, %hia.buffer %p_1_1, 1
  %t4 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t3, %hia.buffer %p_1_2, 2
  %t5 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t4, i64 %p_1_3, 3
  %t6 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t5, i64 %p_1_4, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t6
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 1
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = call { i32, %hia.buffer, i64, i64 } @__hia_fn_0(%hia.buffer %p_1_2, i64 %p_1_3)
  %t3 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 0
  %t4 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 1
  %t5 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 2
  %t6 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 3
  %t7 = icmp ule i32 %t3, 1
  br i1 %t7, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_1_1, %edge_2 ]
  %p_2_1 = phi i32 [ %t3, %edge_2 ]
  %p_2_2 = phi %hia.buffer [ %t4, %edge_2 ]
  %p_2_3 = phi i64 [ %t5, %edge_2 ]
  %p_2_4 = phi i64 [ %t6, %edge_2 ]
  %t8 = icmp eq i32 %p_2_1, 1
  %t9 = select i1 %t8, i8 2, i8 1
  %t10 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %t9, 0
  %t11 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t10, %hia.buffer %p_2_0, 1
  %t12 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t11, %hia.buffer %p_2_2, 2
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t12, i64 %p_2_3, 3
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, i64 %p_2_4, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t14
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_1, %edge_3 ]
  %p_3_1 = phi i32 [ %t3, %edge_3 ]
  %p_3_2 = phi %hia.buffer [ %t4, %edge_3 ]
  %p_3_3 = phi i64 [ %t5, %edge_3 ]
  %p_3_4 = phi i64 [ %t6, %edge_3 ]
  call void @abort()
  unreachable
b4:
  %p_4_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_4_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_4_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_4_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_4_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b4
edge_2:
  br label %b2
edge_3:
  br label %b3
}

define internal i64 @__hia_fn_7(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  call void @free(ptr %t2) nobuiltin
  %t3 = extractvalue %hia.buffer %p_1_2, 0
  call void @free(ptr %t3) nobuiltin
  ret i64 %p_1_4
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define i64 @task_case(i8 %a0) {
entry:
  %result = call i64 @__hia_fn_2(i8 %a0)
  ret i64 %result
}
