# Same-Core composed resources on AArch64 QEMU

This supplemental replay passed against frozen compiler source
`83cbd102ce3f94d95e51a94e446f2a0ff639816c`, with unchanged source snapshots
before and after execution. The input/Core identity exactly matches the host
composite qualification:

- Structured input: `a1fe2477c7917f3c6b6346adca828710883c9204560eecdf63c90aab357ab17e`.
- Executable Core: `0c0b858d29798fc7ab025d5a802d3b0105b868685fede7643abc34269b538cf6`.

Both the structured v2 input and the independently reloaded normalized v1
input execute the same 18 fixed cases through direct LLVM, actual Clang
AArch64 objects, LLD and the pinned QEMU 8.2.2 executable. The corpus combines
generic owned enums, locally stored owner/mutable/read loans, task polling,
pending/running cancellation, completed-result joining and allocator failure.

## Actual results

| Check | Observed result |
| --- | --- |
| Structured input | 18 correct target results |
| Normalized source-free input | 18 correct target results |
| Controlled actual allocator NULL refusals | 12 across both positive runs |
| Wrong-result valid Core | Target exits 31 after printing actual result 90 instead of 91 |
| Compiled missing-free mutation | Correct first result 91, one outstanding allocation, target exits 82 |
| Rehashed changed LLVM through public compiler | `E_HIA_PROGRAM_ORIGIN`, no output published |
| Four invalid task-state transitions | Each target runtime exits 134, matching interpreter protocol traps |

The reviewed 4096-byte arena and its calloc adapter are reused unchanged.
For a requested refusal case, the harness first holds a one-byte allocation.
The unchanged arena's one-live-allocation rule then returns a real NULL to
HIA. After HIA returns, the harness releases its own reservation.

Each positive run therefore reports **14 allocations / 14 frees / 6 refusals /
zero outstanding allocations**. Those totals comprise **8 HIA allocations and
8 HIA frees**, plus **6 harness reservations and 6 harness releases**. Harness
allocations are not presented as HIA resource activity. Empty task tokens and
inactive enum owners make no allocator call.

`replay.py`, fixed expected inputs, both program representations, generated
LLVM, all object files, C runtime/drivers, linked ELF files, tool identities,
commands and raw stdout/stderr are retained. `qualification.json` contains the
actual observations; `manifest.json` binds the retained files. The ELF parser
also checks exact global/undefined inventories and a static executable shape.
Only its structural parser is reused from the synthetic-link module; the
nonfunctional synthetic runtime is never used.

This is Linux userspace QEMU execution. It does not qualify a physical board,
device timing, DMA, GPU, a production allocator, concurrent task scheduling or
whole-compiler refinement. Runtime abort exits 134 and does not promise
destructor cleanup after a trap.
