/* Experimental finite, single-owner Linux runtime for one fixed Owned LLVM ABI.
 * Not a general malloc, production libc, DMA driver or concurrent runtime.
 * No libc dependency and no target execution without an explicit runner.
 */
typedef __SIZE_TYPE__ hepta_size;
typedef __UINT8_TYPE__ hepta_u8;
typedef __UINT32_TYPE__ hepta_u32;
typedef __UINT64_TYPE__ hepta_u64;
typedef __UINTPTR_TYPE__ hepta_uintptr;
#if !defined(__BYTE_ORDER__) || (__BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__)
#error requires little endian
#endif
_Static_assert(__CHAR_BIT__ == 8 && sizeof(void *) == 8 && sizeof(hepta_size) == 8,
               "strict LP64 test ABI");
#define HEPTA_CAPACITY 4096u
static _Alignas(16) hepta_u8 arena[HEPTA_CAPACITY];
static volatile hepta_u32 outstanding;
static volatile hepta_u32 successful_allocations;
static volatile hepta_u32 releases;
static volatile hepta_u32 denied_allocations;

__attribute__((noreturn)) static void hepta_exit(hepta_u32 code) {
#if defined(__aarch64__)
    register long x0 __asm__("x0") = (long)code;
    register long x8 __asm__("x8") = 93;
    __asm__ volatile("svc 0" : : "r"(x0), "r"(x8) : "memory");
#elif defined(__x86_64__)
    __asm__ volatile("syscall" : : "a"(60L), "D"((long)code) : "rcx", "r11", "memory");
#else
#error unsupported test execution architecture
#endif
    __builtin_unreachable();
}

__attribute__((noreturn)) void abort(void) { hepta_exit(134); }
__attribute__((noinline)) void *malloc(hepta_size n) {
    if (n == 0 || n > HEPTA_CAPACITY || outstanding) {
        ++denied_allocations;
        return (void *)0;
    }
    outstanding = 1;
    ++successful_allocations;
    return (void *)arena;
}
__attribute__((noinline)) void free(void *p) {
    if (p == 0) return;
    if (p != (void *)arena || !outstanding) abort();
    outstanding = 0;
    ++releases;
}
__attribute__((noinline)) void *memset(void *dest, int value, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)dest;
    for (hepta_size i = 0; i < n; ++i) d[i] = (hepta_u8)value;
    return dest;
}
__attribute__((noinline)) void *memcpy(void *dest, const void *src, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)dest;
    const hepta_u8 *s = (const hepta_u8 *)src;
    for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    return dest;
}
__attribute__((noinline)) void *memmove(void *dest, const void *src, hepta_size n) {
    hepta_u8 *d = (hepta_u8 *)dest;
    const hepta_u8 *s = (const hepta_u8 *)src;
    if (d == s || n == 0) return dest;
    /* Flat LP64 addresses: do not relationally compare unrelated C pointers. */
    if ((hepta_uintptr)d < (hepta_uintptr)s) {
        for (hepta_size i = 0; i < n; ++i) d[i] = s[i];
    }
    else { for (hepta_size i = n; i > 0; --i) d[i - 1] = s[i - 1]; }
    return dest;
}

/* Independently exercise both directions of overlap and disjoint objects. */
static int memory_primitives_ok(void) {
    hepta_u8 a[8], b[8];
    memset(a, 0, 8);
    for (hepta_size i = 0; i < 8; ++i) a[i] = (hepta_u8)(i + 1);
    memcpy(b, a, 8);
    memmove(b + 1, b, 7);
    for (hepta_size i = 0; i < 7; ++i) {
        if (b[i + 1] != a[i]) return 0;
    }
    memmove(b, b + 1, 7);
    for (hepta_size i = 0; i < 7; ++i) {
        if (b[i] != a[i]) return 0;
    }
    memmove(b, a, 8);
    for (hepta_size i = 0; i < 8; ++i) {
        if (b[i] != a[i]) return 0;
    }
    return 1;
}


/* The standalone Core requests zero-filled bytes through this exact adapter. */
__attribute__((noinline)) void *calloc(hepta_size count, hepta_size width) {
    if (width && count > ((hepta_size)-1) / width) {
        ++denied_allocations;
        return (void *)0;
    }
    hepta_size bytes = count * width;
    void *result = malloc(bytes);
    if (result) memset(result, 0, bytes);
    return result;
}

static void write_counters(void) {
    char text[96];
    hepta_size used = 0;
    const char prefix[] = "HIA_AARCH64 resources ";
    for (hepta_size i = 0; i < sizeof(prefix) - 1; ++i) text[used++] = prefix[i];
    hepta_u32 values[4] = {successful_allocations, releases, outstanding, denied_allocations};
    for (hepta_size i = 0; i < 4; ++i) {
        char digits[10];
        hepta_size n = 0;
        hepta_u32 v = values[i];
        do { digits[n++] = (char)('0' + v % 10); v /= 10; } while (v);
        while (n) text[used++] = digits[--n];
        text[used++] = i == 3 ? '\n' : ' ';
    }
    register long x0 __asm__("x0") = 1;
    register const char *x1 __asm__("x1") = text;
    register hepta_size x2 __asm__("x2") = used;
    register long x8 __asm__("x8") = 64;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x8) : "memory");
    if (x0 != (long)used) hepta_exit(40);
}

static void write_case_row(hepta_size index, hepta_size result) {
    char text[192]; hepta_size used=0;
    const char prefix[]="HIA_COMPOSITE ";
    for(hepta_size i=0;i<sizeof(prefix)-1;i++)text[used++]=prefix[i];
    hepta_u64 values[6]={index,result,successful_allocations,releases,outstanding,denied_allocations};
    for(hepta_size i=0;i<6;i++) {
        char digits[20]; hepta_size n=0; hepta_u64 value=values[i];
        do {digits[n++]=(char)('0'+value%10);value/=10;} while(value);
        while(n)text[used++]=digits[--n];
        text[used++]=i==5?'\n':' ';
    }
    register long x0 __asm__("x0")=1;
    register const char *x1 __asm__("x1")=text;
    register hepta_size x2 __asm__("x2")=used;
    register long x8 __asm__("x8")=64;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x8) : "memory");
    if(x0!=(long)used)hepta_exit(40);
}
extern hepta_size choose(_Bool, hepta_size);
extern hepta_u8 stored(_Bool);
extern hepta_size task_case(hepta_u8);
static int smoke(void) {
  if(!memory_primitives_ok())return 39;
  {
    hepta_size value=stored(((_Bool)0));
    write_case_row(0,value);
    if(value!=((hepta_u8)91ULL))return 31;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=stored(((_Bool)1));
    write_case_row(1,value);
    if(value!=((hepta_u8)91ULL))return 32;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=choose(((_Bool)0),((hepta_size)0ULL));
    write_case_row(2,value);
    if(value!=((hepta_size)10ULL))return 33;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=choose(((_Bool)0),((hepta_size)7ULL));
    write_case_row(3,value);
    if(value!=((hepta_size)17ULL))return 34;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=choose(((_Bool)0),((hepta_size)18446744073709551615ULL));
    write_case_row(4,value);
    if(value!=((hepta_size)10ULL))return 35;
    if(outstanding!=0)return 82;
  }
  {
    void *reservation=malloc(1);if(!reservation)return 80;
    hepta_size value=choose(((_Bool)0),((hepta_size)7ULL));
    if(outstanding!=1)return 81;
    free(reservation);
    write_case_row(5,value);
    if(value!=((hepta_size)10ULL))return 36;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=choose(((_Bool)1),((hepta_size)0ULL));
    write_case_row(6,value);
    if(value!=((hepta_size)0ULL))return 37;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=choose(((_Bool)1),((hepta_size)7ULL));
    write_case_row(7,value);
    if(value!=((hepta_size)7ULL))return 38;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=choose(((_Bool)1),((hepta_size)18446744073709551615ULL));
    write_case_row(8,value);
    if(value!=((hepta_size)0ULL))return 39;
    if(outstanding!=0)return 82;
  }
  {
    void *reservation=malloc(1);if(!reservation)return 80;
    hepta_size value=choose(((_Bool)1),((hepta_size)7ULL));
    if(outstanding!=1)return 81;
    free(reservation);
    write_case_row(9,value);
    if(value!=((hepta_size)0ULL))return 40;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=task_case(((hepta_u8)0ULL));
    write_case_row(10,value);
    if(value!=((hepta_size)33ULL))return 41;
    if(outstanding!=0)return 82;
  }
  {
    void *reservation=malloc(1);if(!reservation)return 80;
    hepta_size value=task_case(((hepta_u8)0ULL));
    if(outstanding!=1)return 81;
    free(reservation);
    write_case_row(11,value);
    if(value!=((hepta_size)250ULL))return 42;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=task_case(((hepta_u8)1ULL));
    write_case_row(12,value);
    if(value!=((hepta_size)13ULL))return 43;
    if(outstanding!=0)return 82;
  }
  {
    void *reservation=malloc(1);if(!reservation)return 80;
    hepta_size value=task_case(((hepta_u8)1ULL));
    if(outstanding!=1)return 81;
    free(reservation);
    write_case_row(13,value);
    if(value!=((hepta_size)250ULL))return 44;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=task_case(((hepta_u8)2ULL));
    write_case_row(14,value);
    if(value!=((hepta_size)28ULL))return 45;
    if(outstanding!=0)return 82;
  }
  {
    void *reservation=malloc(1);if(!reservation)return 80;
    hepta_size value=task_case(((hepta_u8)2ULL));
    if(outstanding!=1)return 81;
    free(reservation);
    write_case_row(15,value);
    if(value!=((hepta_size)250ULL))return 46;
    if(outstanding!=0)return 82;
  }
  {
    hepta_size value=task_case(((hepta_u8)255ULL));
    write_case_row(16,value);
    if(value!=((hepta_size)28ULL))return 47;
    if(outstanding!=0)return 82;
  }
  {
    void *reservation=malloc(1);if(!reservation)return 80;
    hepta_size value=task_case(((hepta_u8)255ULL));
    if(outstanding!=1)return 81;
    free(reservation);
    write_case_row(17,value);
    if(value!=((hepta_size)250ULL))return 48;
    if(outstanding!=0)return 82;
  }
  write_counters();
  if(successful_allocations!=14 || releases!=14 || outstanding!=0 || denied_allocations!=6)return 83;
  return 0;
}
__attribute__((noreturn)) void _start(void){hepta_exit((hepta_u32)smoke());}
