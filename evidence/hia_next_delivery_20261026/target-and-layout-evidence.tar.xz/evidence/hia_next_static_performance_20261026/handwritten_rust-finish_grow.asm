
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/handwritten_rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012930 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>:
   12930:	41 57                	push   %r15
   12932:	41 56                	push   %r14
   12934:	53                   	push   %rbx
   12935:	48 89 d3             	mov    %rdx,%rbx
   12938:	49 89 f7             	mov    %rsi,%r15
   1293b:	49 89 fe             	mov    %rdi,%r14
   1293e:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
   12943:	74 1a                	je     1295f <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x2f>
   12945:	48 8b 71 10          	mov    0x10(%rcx),%rsi
   12949:	48 85 f6             	test   %rsi,%rsi
   1294c:	74 11                	je     1295f <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x2f>
   1294e:	48 8b 39             	mov    (%rcx),%rdi
   12951:	4c 89 fa             	mov    %r15,%rdx
   12954:	48 89 d9             	mov    %rbx,%rcx
   12957:	ff 15 23 e0 03 00    	call   *0x3e023(%rip)        # 50980 <_DYNAMIC+0x200>
   1295d:	eb 1c                	jmp    1297b <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x4b>
   1295f:	48 85 db             	test   %rbx,%rbx
   12962:	74 14                	je     12978 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x48>
   12964:	ff 15 2e e0 03 00    	call   *0x3e02e(%rip)        # 50998 <_DYNAMIC+0x218>
   1296a:	48 89 df             	mov    %rbx,%rdi
   1296d:	4c 89 fe             	mov    %r15,%rsi
   12970:	ff 15 fa df 03 00    	call   *0x3dffa(%rip)        # 50970 <_DYNAMIC+0x1f0>
   12976:	eb 03                	jmp    1297b <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x4b>
   12978:	4c 89 f8             	mov    %r15,%rax
   1297b:	31 c9                	xor    %ecx,%ecx
   1297d:	48 85 c0             	test   %rax,%rax
   12980:	4c 0f 45 f8          	cmovne %rax,%r15
   12984:	0f 94 c1             	sete   %cl
   12987:	4d 89 7e 08          	mov    %r15,0x8(%r14)
   1298b:	49 89 5e 10          	mov    %rbx,0x10(%r14)
   1298f:	49 89 0e             	mov    %rcx,(%r14)
   12992:	5b                   	pop    %rbx
   12993:	41 5e                	pop    %r14
   12995:	41 5f                	pop    %r15
   12997:	c3                   	ret

Disassembly of section .plt:
