
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012990 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>:
   12990:	41 57                	push   %r15
   12992:	41 56                	push   %r14
   12994:	53                   	push   %rbx
   12995:	48 89 d3             	mov    %rdx,%rbx
   12998:	49 89 f7             	mov    %rsi,%r15
   1299b:	49 89 fe             	mov    %rdi,%r14
   1299e:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
   129a3:	74 1a                	je     129bf <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x2f>
   129a5:	48 8b 71 10          	mov    0x10(%rcx),%rsi
   129a9:	48 85 f6             	test   %rsi,%rsi
   129ac:	74 11                	je     129bf <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x2f>
   129ae:	48 8b 39             	mov    (%rcx),%rdi
   129b1:	4c 89 fa             	mov    %r15,%rdx
   129b4:	48 89 d9             	mov    %rbx,%rcx
   129b7:	ff 15 a3 df 03 00    	call   *0x3dfa3(%rip)        # 50960 <_DYNAMIC+0x200>
   129bd:	eb 1c                	jmp    129db <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x4b>
   129bf:	48 85 db             	test   %rbx,%rbx
   129c2:	74 14                	je     129d8 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x48>
   129c4:	ff 15 ae df 03 00    	call   *0x3dfae(%rip)        # 50978 <_DYNAMIC+0x218>
   129ca:	48 89 df             	mov    %rbx,%rdi
   129cd:	4c 89 fe             	mov    %r15,%rsi
   129d0:	ff 15 7a df 03 00    	call   *0x3df7a(%rip)        # 50950 <_DYNAMIC+0x1f0>
   129d6:	eb 03                	jmp    129db <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E+0x4b>
   129d8:	4c 89 f8             	mov    %r15,%rax
   129db:	31 c9                	xor    %ecx,%ecx
   129dd:	48 85 c0             	test   %rax,%rax
   129e0:	4c 0f 45 f8          	cmovne %rax,%r15
   129e4:	0f 94 c1             	sete   %cl
   129e7:	4d 89 7e 08          	mov    %r15,0x8(%r14)
   129eb:	49 89 5e 10          	mov    %rbx,0x10(%r14)
   129ef:	49 89 0e             	mov    %rcx,(%r14)
   129f2:	5b                   	pop    %rbx
   129f3:	41 5e                	pop    %r14
   129f5:	41 5f                	pop    %r15
   129f7:	c3                   	ret

Disassembly of section .plt:
