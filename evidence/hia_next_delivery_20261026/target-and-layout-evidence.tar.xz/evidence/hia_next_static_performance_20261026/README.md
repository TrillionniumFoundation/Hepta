# Exact measured performance artifacts: static follow-up

The frozen source is `83cbd102ce3f94d95e51a94e446f2a0ff639816c`.
The recorded 63-sample performance gate passed its unchanged thresholds; all
samples are retained and the largest relative MAD is 3.7749657743%.
This follow-up disassembles the exact retained measured binaries. It runs no
kernel, collects no additional timing sample and rebuilds no substitute binary.

## Allocation normalization addresses the observed HIA code-generation gap

All three measured `full_lifecycle` implementations now have a 16-byte vector
fill loop, a four-byte vector epilogue, and a scalar checksum loop with checked
addition. No extra per-byte bounds branch remains in the HIA checksum loop.
The HIA emitter still generates its ordinary bounds guards: exposing the
allocation helper's exact length invariant lets LLVM remove redundant ones.

The final paired HIA/handwritten-Rust ratio is **0.9939908961**. That supports
parity for this finite measured artifact/workload on this host. The retained
handwritten Rust binary is byte-for-byte identical to the earlier measured
binary. The earlier run was noisy, so the two runs do not establish a causal
cross-run speedup percentage.

## The generated Rust comparison has a layout-sensitive reproducibility risk

The final paired HIA/generated-Rust ratio is **0.5648864069**. It must not be
presented as a general compiler or language speedup. The generated Rust source,
pinned compiler and recorded flags match the preceding report, while its
binary differs. Its panic metadata contains the actual longer temporary
`program.rs` path inside the new artifact-retention directory.

The exact measured generated-Rust and handwritten-Rust checksum loops have
**identical 21 machine-code bytes**. Their placement differs:

| Measured artifact | Checksum loop start | Start modulo 32 | Crosses a 32-byte boundary |
| --- | --- | --- | --- |
| HIA | `0x1300` | 0 | No |
| Generated Rust | `0x12bf0` | 16 | Yes |
| Handwritten Rust | `0x12ba0` | 0 | No |

Code layout is therefore a concrete difference to investigate. Whether this
alignment difference causes the observed timing gap, and how much it explains,
is **not established** by disassembly. No alignment-only experiment or hardware
counter study was performed. Different embedded path lengths are a plausible
contributor to changed linked placement, not a proved sole cause.

The seven full-lifecycle CPU/wall ratios have medians 0.99674 (HIA), 0.99670
(generated Rust) and 0.99666 (handwritten Rust), with zero sampled major/minor
page faults. These observations do not isolate code layout, CPU frequency,
cache effects or host interference. They do not replace the original wall-time
acceptance calculation.

## A reproducible-build follow-up is proposed, not executed

The pinned `rustc 1.90.0 --help -v` advertises `--remap-path-prefix FROM=TO`.
The current `compile_rust` API does not expose it: non-debug builds write source
to a random `.hepta-native-*` directory under the artifact parent. A declared
mapping of that actual directory to `/hepta-native` would make the virtual
source filename identical for both Rust baselines while retaining the physical
path and full command in the build receipt.

`two-path-build-protocol.json` fixes a two-location, two-repeat comparison of
the existing and remapped path policies before any additional build or timing.
Its status is **not executed**. It requires reproducible binary hashes before
any separate timing phase and never replaces this run's original evidence.

## Files and limits

`summary.json` binds every disassembly to the actual measured binary hash and
records exact loop bytes, source/toolchain equality and scheduling data.
`commands.json` records the actual disassembler commands. `collect_static.py`
replays this static collection without compiling or executing the kernels.
The older generated-Rust diagnostic was already labeled as a reconstruction,
not the exact old measured binary; it cannot repair that missing identity.

The successful performance gate remains finite and artifact-scoped. These
results do not prove universal Rust superiority, whole-language safety,
backend refinement or physical-device performance.
