#!/usr/bin/env python3
"""Inspect exact retained performance artifacts without rebuilding/executing."""
from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess

ROOT = Path('/workspace/scratch/06ad8295a712/hepta-unified')
OUT = ROOT / 'evidence/hia_next_static_performance_20261026'
PERF = ROOT / 'evidence/hia_next_20261026_run1/performance.json'
PREVIOUS = ROOT / 'evidence/hia_unified_delivery_20261026/performance.json'
sha = lambda data: hashlib.sha256(data).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    report, previous = json.loads(PERF.read_text()), json.loads(PREVIOUS.read_text())
    commands, loops, identities = [], {}, {}
    for name in ('llvm', 'rust', 'handwritten_rust'):
        artifact = Path(report['artifacts'][name]['path'])
        data = artifact.read_bytes()
        if sha(data) != report['artifacts'][name]['sha256']:
            raise RuntimeError('measured binary identity differs: ' + name)
        command = ['/usr/bin/objdump', '-d', '--disassemble=full_lifecycle', str(artifact)]
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        dest = OUT / (name + '-full_lifecycle.asm')
        dest.write_text(result.stdout)
        commands.append({'argv': command, 'returncode': result.returncode, 'stdout_file': dest.name,
                         'stdout_sha256': sha(dest.read_bytes()), 'stderr': result.stderr})
        instructions = []
        for line in result.stdout.splitlines():
            match = re.match(r'^\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}\s+)+)\s*([a-z][a-z0-9]*)\s*(.*?)\s*$', line)
            if match:
                instructions.append({'address': int(match[1], 16), 'bytes': ''.join(match[2].split()),
                                     'opcode': match[3], 'operands': match[4]})
        matches = []
        for index in range(len(instructions) - 6):
            candidate = instructions[index:index + 7]
            if [row['opcode'] for row in candidate] == ['mov', 'movzbl', 'add', 'jb', 'inc', 'cmp', 'jne']:
                if int(candidate[-1]['operands'].split()[0], 16) == candidate[0]['address']:
                    matches.append(candidate)
        if len(matches) != 1:
            raise RuntimeError('checksum loop inventory differs: ' + name)
        sequence = matches[0]
        start = sequence[0]['address']
        raw = bytes.fromhex(''.join(row['bytes'] for row in sequence))
        end = start + len(raw)
        loops[name] = {'start': hex(start), 'end_exclusive': hex(end), 'bytes': len(raw),
                       'machine_bytes_hex': raw.hex(), 'machine_bytes_sha256': sha(raw),
                       'start_mod_32': start % 32, 'crosses_32_byte_boundary': start // 32 != (end - 1) // 32,
                       'instructions': sequence}
        embedded = [row.decode() for row in re.findall(rb'[ -~]{10,}', data)
                    if b'.hepta-native-' in row and b'program.rs' in row]
        identities[name] = {'measured_artifact_sha256': sha(data), 'measured_artifact_bytes': len(data),
                            'matches_report': True,
                            'previous_report_artifact_sha256': previous['artifacts'][name]['sha256'],
                            'same_as_previous_report': sha(data) == previous['artifacts'][name]['sha256'],
                            'embedded_generated_source_paths': embedded}
        if name != 'llvm':
            # Inspect the helper actually called by this exact measured kernel,
            # not another monomorphized finish_grow in the standard library.
            names = set(re.findall(r'<(_ZN5alloc7raw_vec11finish_grow[^>]+)>', result.stdout))
            if len(names) != 1:
                raise RuntimeError('called allocator helper inventory differs')
            command = ['/usr/bin/objdump', '-d', '--disassemble=' + next(iter(names)), str(artifact)]
            result = subprocess.run(command, capture_output=True, text=True, check=True)
            dest = OUT / (name + '-finish_grow.asm')
            dest.write_text(result.stdout)
            commands.append({'argv': command, 'returncode': result.returncode, 'stdout_file': dest.name,
                             'stdout_sha256': sha(dest.read_bytes()), 'stderr': result.stderr})
    context = {}
    for kernel in ('constructor_error', 'full_lifecycle', 'two_stage'):
        context[kernel] = {}
        for backend in ('llvm', 'rust', 'handwritten_rust'):
            samples = [row for row in report['raw_samples'] if row['kernel'] == kernel and row['backend'] == backend]
            fractions = [row['process_cpu_ns'] / row['elapsed_ns'] for row in samples]
            context[kernel][backend] = {'samples': len(samples), 'median_cpu_wall': statistics.median(fractions),
                'min_cpu_wall': min(fractions), 'max_cpu_wall': max(fractions),
                **{field: sum(row[field] for row in samples) for field in
                   ('involuntary_context_switches', 'voluntary_context_switches', 'major_page_faults', 'minor_page_faults')}}
    summary = {
        'schema': 'hepta.hia.exact-measured-static-diagnosis.v3', 'git_commit': report['git_commit'],
        'performance_report': str(PERF.relative_to(ROOT)), 'performance_report_sha256': sha(PERF.read_bytes()),
        'performance_status': report['status'], 'samples': len(report['raw_samples']),
        'maximum_relative_mad': max(row['relative_mad'] for kernel in report['evaluation']['summary'].values()
                                   for row in kernel['implementations'].values()),
        'artifact_identities': identities, 'checksum_loops': loops,
        'generated_and_handwritten_checksum_loop_bytes_identical': loops['rust']['machine_bytes_hex'] == loops['handwritten_rust']['machine_bytes_hex'],
        'source_identity': {'hia_source_sha256': report['source_sha256'],
            'hia_source_matches_previous': report['source_sha256'] == previous['source_sha256'],
            'generated_rust_sha256': report['generated_rust_sha256'],
            'generated_rust_source_matches_previous': report['generated_rust_sha256'] == previous['generated_rust_sha256'],
            'rust_toolchain_and_flags_match_previous': all(report['native_receipts']['rust'][key] == previous['native_receipts']['rust'][key]
                                                         for key in ('flags', 'toolchain', 'link_args', 'target'))},
        'full_lifecycle': report['evaluation']['summary']['full_lifecycle'], 'scheduling_context': context,
        'new_native_kernel_executions': 0, 'new_timing_samples': 0, 'causal_fraction_of_timing_difference_established': False,
        'observations': [
            'All three exact measured checksum loops are scalar with checked-add carry branches and no extra per-byte bounds branch.',
            'All three exact measured fill loops have a 16-byte main vector loop and 4-byte vector epilogue.',
            'Generated and handwritten Rust checksum loops have identical 21 machine-code bytes. Placement differs: generated starts 16 mod 32 and crosses a 32-byte boundary; handwritten and HIA start 0 mod 32.',
            'Generated Rust source, pinned toolchain and flags match the prior report but its binary differs. Panic metadata embeds the new longer temporary source path. Handwritten Rust is byte-identical to the prior measured binary.'],
        'inferences': [
            'Instruction/code layout sensitivity is a plausible contributor to generated-Rust versus handwritten-Rust timings, but no controlled alignment-only timing experiment was run.',
            'Changed embedded source-path length is a plausible contributor to changed linked placement; this static follow-up does not establish it as the sole cause.'],
        'not_established': [
            'No universal speedup over Rust.',
            'No causal percentage or confirmed microarchitectural explanation for the 0.564886 HIA/generated-Rust ratio.',
            'No causal cross-run speedup: the prior run was noisy and its exact generated-Rust measured binary was not retained.',
            'No additional samples, rebuilt substitute binaries or modified benchmark inputs.']}
    for name, value in (('summary.json', summary), ('commands.json', commands)):
        (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    version = subprocess.run(['/usr/bin/objdump', '--version'], capture_output=True, text=True, check=True).stdout.splitlines()[0]
    metadata = {'objdump': {'path': '/usr/bin/objdump', 'version': version,
                           'sha256': sha(Path('/usr/bin/objdump').resolve().read_bytes())},
                'cpu_model_observed': next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                                           if line.startswith('model name'))}
    (OUT / 'tools.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    (OUT / 'collect_static.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'directory': str(OUT), 'rust_loops_byte_identical': summary['generated_and_handwritten_checksum_loop_bytes_identical'],
        'loops': {name: {key: value[key] for key in ('start', 'bytes', 'start_mod_32', 'crosses_32_byte_boundary')}
                  for name, value in loops.items()}}, sort_keys=True))


if __name__ == '__main__':
    main()
