#include <stddef.h>
#include <stdint.h>
extern uint64_t owned_case(size_t, uint8_t, size_t, uint32_t, uint32_t);
