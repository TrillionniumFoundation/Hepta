; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal { i1, %hia.buffer, i8 } @__hia_fn_0(i64 %p_0_0, i1 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i1 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br i1 %p_1_1, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i1 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  call void @free(ptr %t6) nobuiltin
  %t7 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t8 = extractvalue %hia.alloc %t7, 0
  %t9 = extractvalue %hia.alloc %t7, 1
  br i1 %t9, label %ok_10, label %trap_10
trap_10:
  call void @abort()
  unreachable
ok_10:
  %t11 = insertvalue %hia.buffer %t8, i64 0, 1
  %t12 = insertvalue { i1, %hia.buffer, i8 } zeroinitializer, i1 false, 0
  %t13 = insertvalue { i1, %hia.buffer, i8 } %t12, %hia.buffer %t11, 1
  %t14 = insertvalue { i1, %hia.buffer, i8 } %t13, i8 %p_2_4, 2
  ret { i1, %hia.buffer, i8 } %t14
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i1 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %t15 = extractvalue %hia.buffer %p_3_2, 0
  call void @free(ptr %t15) nobuiltin
  %t16 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t17 = extractvalue %hia.alloc %t16, 0
  %t18 = extractvalue %hia.alloc %t16, 1
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = insertvalue %hia.buffer %t17, i64 0, 1
  %t21 = insertvalue { i1, %hia.buffer, i8 } zeroinitializer, i1 false, 0
  %t22 = insertvalue { i1, %hia.buffer, i8 } %t21, %hia.buffer %t20, 1
  %t23 = insertvalue { i1, %hia.buffer, i8 } %t22, i8 2, 2
  ret { i1, %hia.buffer, i8 } %t23
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i1 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %t24 = insertvalue { i1, %hia.buffer, i8 } zeroinitializer, i1 true, 0
  %t25 = insertvalue { i1, %hia.buffer, i8 } %t24, %hia.buffer %p_4_2, 1
  %t26 = insertvalue { i1, %hia.buffer, i8 } %t25, i8 0, 2
  ret { i1, %hia.buffer, i8 } %t26
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal %hia.buffer @__hia_fn_1(%hia.buffer %p_0_0) {
b0:
  ret %hia.buffer %p_0_0
}

define internal void @__hia_fn_2(%hia.buffer %p_0_0) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 0
  call void @free(ptr %t1) nobuiltin
  ret void
}

define internal i64 @__hia_fn_3(%hia.buffer %p_0_0) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  ret i64 %t1
}

define internal void @__hia_fn_4(%hia.buffer %p_0_0, i8 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  br label %edge_0
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ], [ %p_2_1, %edge_3 ]
  %p_1_2 = phi i64 [ %t1, %edge_0 ], [ %p_2_2, %edge_3 ]
  %p_1_3 = phi i64 [ 0, %edge_0 ], [ %t9, %edge_3 ]
  %t2 = icmp ult i64 %p_1_3, %p_1_2
  br i1 %t2, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi %hia.buffer [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_1_3, %edge_1 ]
  %t3 = extractvalue %hia.buffer %p_2_0, 0
  %t4 = extractvalue %hia.buffer %p_2_0, 1
  %t5 = icmp ult i64 %p_2_3, %t4
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = getelementptr i8, ptr %t3, i64 %p_2_3
  store i8 %p_2_1, ptr %t7, align 1
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_2_3, i64 1)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  br label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_3, %edge_2 ]
  ret void
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal i8 @__hia_fn_5(%hia.buffer %p_0_0, i64 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 0
  %t2 = extractvalue %hia.buffer %p_0_0, 1
  %t3 = icmp ult i64 %p_0_1, %t2
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = getelementptr i8, ptr %t1, i64 %p_0_1
  %t6 = load i8, ptr %t5, align 1
  ret i8 %t6
}

define internal void @__hia_fn_6(%hia.buffer %p_0_0, i64 %p_0_1, i8 %p_0_2) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 0
  %t2 = extractvalue %hia.buffer %p_0_0, 1
  %t3 = icmp ult i64 %p_0_1, %t2
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = getelementptr i8, ptr %t1, i64 %p_0_1
  store i8 %p_0_2, ptr %t5, align 1
  ret void
}

define internal i64 @__hia_fn_7(i64 %p_0_0, i8 %p_0_1, i64 %p_0_2, i1 %p_0_3, i1 %p_0_4) {
b0:
  %t1 = call { i1, %hia.buffer, i8 } @__hia_fn_0(i64 %p_0_0, i1 %p_0_3)
  %t2 = extractvalue { i1, %hia.buffer, i8 } %t1, 0
  %t3 = extractvalue { i1, %hia.buffer, i8 } %t1, 1
  %t4 = extractvalue { i1, %hia.buffer, i8 } %t1, 2
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i1 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i1 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i1 [ %t2, %edge_0 ]
  %p_1_6 = phi %hia.buffer [ %t3, %edge_0 ]
  %p_1_7 = phi i8 [ %t4, %edge_0 ]
  call void @__hia_fn_4(%hia.buffer %p_1_6, i8 %p_1_1)
  %t5 = icmp ne i64 %p_1_0, 0
  br i1 %t5, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i8 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i1 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i1 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i1 [ %t2, %edge_1 ]
  %p_2_6 = phi %hia.buffer [ %t3, %edge_1 ]
  %p_2_7 = phi i8 [ %t4, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_6, 0
  call void @free(ptr %t6) nobuiltin
  %t7 = zext i8 %p_2_7 to i64
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t7)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  ret i64 %t9
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i1 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i1 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi %hia.buffer [ %p_1_6, %edge_2 ]
  %t13 = xor i8 %p_3_1, 90
  call void @__hia_fn_6(%hia.buffer %p_3_5, i64 0, i8 %t13)
  br label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i8 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i1 [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i1 [ %p_1_4, %edge_3 ]
  %p_4_5 = phi %hia.buffer [ %p_1_6, %edge_3 ]
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ], [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i8 [ %p_3_1, %edge_4 ], [ %p_4_1, %edge_5 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_4 ], [ %p_4_2, %edge_5 ]
  %p_5_3 = phi i1 [ %p_3_3, %edge_4 ], [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i1 [ %p_3_4, %edge_4 ], [ %p_4_4, %edge_5 ]
  %p_5_5 = phi %hia.buffer [ %p_3_5, %edge_4 ], [ %p_4_5, %edge_5 ]
  %t14 = call %hia.buffer @__hia_fn_1(%hia.buffer %p_5_5)
  br i1 %p_5_4, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i8 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi i64 [ %p_5_2, %edge_6 ]
  %p_6_3 = phi i1 [ %p_5_3, %edge_6 ]
  %p_6_4 = phi i1 [ %p_5_4, %edge_6 ]
  %p_6_5 = phi %hia.buffer [ %t14, %edge_6 ]
  call void @__hia_fn_2(%hia.buffer %p_6_5)
  ret i64 2002
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i8 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi i64 [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i1 [ %p_5_3, %edge_7 ]
  %p_7_4 = phi i1 [ %p_5_4, %edge_7 ]
  %p_7_5 = phi %hia.buffer [ %t14, %edge_7 ]
  %t15 = call i64 @__hia_fn_3(%hia.buffer %p_7_5)
  %t16 = icmp uge i64 %p_7_2, %t15
  br i1 %t16, label %edge_8, label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_8 ]
  %p_8_1 = phi i8 [ %p_7_1, %edge_8 ]
  %p_8_2 = phi i64 [ %p_7_2, %edge_8 ]
  %p_8_3 = phi i1 [ %p_7_3, %edge_8 ]
  %p_8_4 = phi i1 [ %p_7_4, %edge_8 ]
  %p_8_5 = phi %hia.buffer [ %p_7_5, %edge_8 ]
  call void @__hia_fn_2(%hia.buffer %p_8_5)
  ret i64 2003
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_9 ]
  %p_9_1 = phi i8 [ %p_7_1, %edge_9 ]
  %p_9_2 = phi i64 [ %p_7_2, %edge_9 ]
  %p_9_3 = phi i1 [ %p_7_3, %edge_9 ]
  %p_9_4 = phi i1 [ %p_7_4, %edge_9 ]
  %p_9_5 = phi %hia.buffer [ %p_7_5, %edge_9 ]
  %t17 = extractvalue %hia.buffer %p_9_5, 0
  %t18 = extractvalue %hia.buffer %p_9_5, 1
  %t19 = icmp ult i64 %p_9_2, %t18
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = getelementptr i8, ptr %t17, i64 %p_9_2
  %t22 = load i8, ptr %t21, align 1
  %t23 = zext i8 %t22 to i64
  %t24 = call i8 @__hia_fn_5(%hia.buffer %p_9_5, i64 %p_9_2)
  %t25 = zext i8 %t24 to i64
  %t26 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t23, i64 %t25)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  %t29 = xor i1 %t28, true
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  %t31 = call i64 @__hia_fn_3(%hia.buffer %p_9_5)
  %t32 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t27, i64 %t31)
  %t33 = extractvalue { i64, i1 } %t32, 0
  %t34 = extractvalue { i64, i1 } %t32, 1
  %t35 = xor i1 %t34, true
  br i1 %t35, label %ok_36, label %trap_36
trap_36:
  call void @abort()
  unreachable
ok_36:
  call void @__hia_fn_2(%hia.buffer %p_9_5)
  ret i64 %t33
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
}

define internal i64 @__hia_fn_8(i64 %p_0_0, i8 %p_0_1, i64 %p_0_2, i32 %p_0_3, i32 %p_0_4) {
b0:
  %t1 = icmp ne i32 %p_0_3, 0
  %t2 = icmp ne i32 %p_0_4, 0
  %t3 = call i64 @__hia_fn_7(i64 %p_0_0, i8 %p_0_1, i64 %p_0_2, i1 %t1, i1 %t2)
  ret i64 %t3
}

define i64 @Mcf03d00758734ee2_run_owned(i64 %a0, i8 zeroext %a1, i64 %a2, i1 zeroext %a3, i1 zeroext %a4) {
entry:
  %result = call i64 @__hia_fn_7(i64 %a0, i8 %a1, i64 %a2, i1 %a3, i1 %a4)
  ret i64 %result
}

define i64 @owned_case(i64 %a0, i8 zeroext %a1, i64 %a2, i32 %a3, i32 %a4) {
entry:
  %result = call i64 @__hia_fn_8(i64 %a0, i8 %a1, i64 %a2, i32 %a3, i32 %a4)
  ret i64 %result
}
