
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
void *__real_calloc(size_t,size_t);
void *__real_malloc(size_t);
void __real_free(void *);
static volatile size_t attempts=0, allocations=0, frees=0, live=0, fail_at=0;
void *__wrap_calloc(size_t n,size_t size) {
    ++attempts;
    if (fail_at && attempts==fail_at) return NULL;
    void *p=__real_calloc(n,size);
    if(p){++allocations;++live;}
    return p;
}
void *__wrap_malloc(size_t n) {
    ++attempts;
    if (fail_at && attempts==fail_at) return NULL;
    void *p=__real_malloc(n);
    if(p){++allocations;++live;}
    return p;
}
void __wrap_free(void *p) {
    if(p){++frees;--live;}
    __real_free(p);
}
extern uint64_t ENTRY(size_t,size_t,unsigned char,unsigned int);
int main(int argc,char **argv) {
    if(argc!=6)return 80;
    size_t left=(size_t)strtoull(argv[1],NULL,10),right=(size_t)strtoull(argv[2],NULL,10);
    unsigned char seed=(unsigned char)strtoul(argv[3],NULL,10);
    unsigned int early=(unsigned int)strtoul(argv[4],NULL,10);
    fail_at=(size_t)strtoull(argv[5],NULL,10);
    uint64_t result=ENTRY(left,right,seed,early);
    printf("%" PRIu64 " %zu %zu %zu %zu\n",result,attempts,allocations,frees,live);
    return live ? 81 : 0;
}
