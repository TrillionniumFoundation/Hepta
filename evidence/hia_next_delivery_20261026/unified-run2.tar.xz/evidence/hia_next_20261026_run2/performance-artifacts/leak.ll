; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal %hia.buffer @__hia_fn_0(%hia.buffer %p_0_0) {
b0:
  ret %hia.buffer %p_0_0
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  ; intentionally removed actual free
  %t7 = zext i8 %p_2_4 to i64
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t7)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  ret i64 %t9
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t23, %edge_5 ]
  %t13 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t13, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t14 = trunc i64 %p_4_4 to i32
  %t15 = add i32 %t14, %p_4_1
  %t16 = trunc i32 %t15 to i8
  %t17 = extractvalue %hia.buffer %p_4_2, 0
  %t18 = extractvalue %hia.buffer %p_4_2, 1
  %t19 = icmp ult i64 %p_4_4, %t18
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = getelementptr i8, ptr %t17, i64 %p_4_4
  store i8 %t16, ptr %t21, align 1
  %t22 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t23 = extractvalue { i64, i1 } %t22, 0
  %t24 = extractvalue { i64, i1 } %t22, 1
  %t25 = xor i1 %t24, true
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %t27 = call %hia.buffer @__hia_fn_0(%hia.buffer %p_5_2)
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %t27, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t37, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t42, %edge_9 ]
  %t28 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t28, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t29 = extractvalue %hia.buffer %p_7_2, 0
  %t30 = extractvalue %hia.buffer %p_7_2, 1
  %t31 = icmp ult i64 %p_7_5, %t30
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  %t33 = getelementptr i8, ptr %t29, i64 %p_7_5
  %t34 = load i8, ptr %t33, align 1
  %t35 = zext i8 %t34 to i64
  %t36 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_3, i64 %t35)
  %t37 = extractvalue { i64, i1 } %t36, 0
  %t38 = extractvalue { i64, i1 } %t36, 1
  %t39 = xor i1 %t38, true
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_5, i64 1)
  %t42 = extractvalue { i64, i1 } %t41, 0
  %t43 = extractvalue { i64, i1 } %t41, 1
  %t44 = xor i1 %t43, true
  br i1 %t44, label %ok_45, label %trap_45
trap_45:
  call void @abort()
  unreachable
ok_45:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t46 = extractvalue %hia.buffer %p_8_2, 0
  ; intentionally removed actual free
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  %t6 = extractvalue %hia.buffer %p_1_3, 0
  ; intentionally removed actual free
  %t7 = zext i32 %p_1_1 to i64
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1002, i64 %t7)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  ret i64 %t9
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t13 = extractvalue %hia.buffer %p_2_3, 0
  ; intentionally removed actual free
  %t14 = zext i8 %p_2_4 to i64
  %t15 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t14)
  %t16 = extractvalue { i64, i1 } %t15, 0
  %t17 = extractvalue { i64, i1 } %t15, 1
  %t18 = xor i1 %t17, true
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = zext i32 %p_2_1 to i64
  %t21 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t16, i64 %t20)
  %t22 = extractvalue { i64, i1 } %t21, 0
  %t23 = extractvalue { i64, i1 } %t21, 1
  %t24 = xor i1 %t23, true
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  ret i64 %t22
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i64 @__hia_fn_3(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  ; intentionally removed actual free
  %t7 = zext i8 %p_2_4 to i64
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t7)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  ret i64 %t9
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t21, %edge_5 ]
  %t13 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t13, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t14 = trunc i32 %p_4_1 to i8
  %t15 = extractvalue %hia.buffer %p_4_2, 0
  %t16 = extractvalue %hia.buffer %p_4_2, 1
  %t17 = icmp ult i64 %p_4_4, %t16
  br i1 %t17, label %ok_18, label %trap_18
trap_18:
  call void @abort()
  unreachable
ok_18:
  %t19 = getelementptr i8, ptr %t15, i64 %p_4_4
  store i8 %t14, ptr %t19, align 1
  %t20 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  %t23 = xor i1 %t22, true
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %t25 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_5_0, i64 17)
  %t26 = extractvalue { i64, i1 } %t25, 0
  %t27 = extractvalue { i64, i1 } %t25, 1
  %t28 = xor i1 %t27, true
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  %t30 = call %hia.alloc @__hia_allocate(i64 %t26, i1 true)
  %t31 = extractvalue %hia.alloc %t30, 0
  %t32 = extractvalue %hia.alloc %t30, 1
  %t33 = select i1 %t32, i64 %t26, i64 0
  %t34 = insertvalue %hia.buffer %t31, i64 %t33, 1
  br i1 %t32, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ]
  %p_6_3 = phi i1 [ %t32, %edge_6 ]
  %p_6_4 = phi %hia.buffer [ %t34, %edge_6 ]
  %p_6_5 = phi i8 [ 1, %edge_6 ]
  br label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i1 [ %t32, %edge_7 ]
  %p_7_4 = phi %hia.buffer [ %t34, %edge_7 ]
  %p_7_5 = phi i8 [ 1, %edge_7 ]
  %t35 = extractvalue %hia.buffer %p_7_4, 0
  ; intentionally removed actual free
  %t36 = extractvalue %hia.buffer %p_7_2, 0
  ; intentionally removed actual free
  %t37 = zext i8 %p_7_5 to i64
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t37)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  ret i64 %t39
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ], [ %p_9_0, %edge_11 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ], [ %p_9_1, %edge_11 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ], [ %p_9_2, %edge_11 ]
  %p_8_3 = phi %hia.buffer [ %p_6_4, %edge_8 ], [ %p_9_3, %edge_11 ]
  %p_8_4 = phi i64 [ %p_6_0, %edge_8 ], [ %p_9_4, %edge_11 ]
  %p_8_5 = phi i64 [ 0, %edge_8 ], [ %t57, %edge_11 ]
  %t43 = icmp ult i64 %p_8_5, %p_8_4
  br i1 %t43, label %edge_9, label %edge_10
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_9 ]
  %p_9_1 = phi i32 [ %p_8_1, %edge_9 ]
  %p_9_2 = phi %hia.buffer [ %p_8_2, %edge_9 ]
  %p_9_3 = phi %hia.buffer [ %p_8_3, %edge_9 ]
  %p_9_4 = phi i64 [ %p_8_4, %edge_9 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_9 ]
  %t44 = extractvalue %hia.buffer %p_9_2, 0
  %t45 = extractvalue %hia.buffer %p_9_2, 1
  %t46 = icmp ult i64 %p_9_5, %t45
  br i1 %t46, label %ok_47, label %trap_47
trap_47:
  call void @abort()
  unreachable
ok_47:
  %t48 = getelementptr i8, ptr %t44, i64 %p_9_5
  %t49 = load i8, ptr %t48, align 1
  %t50 = xor i8 %t49, 90
  %t51 = extractvalue %hia.buffer %p_9_3, 0
  %t52 = extractvalue %hia.buffer %p_9_3, 1
  %t53 = icmp ult i64 %p_9_5, %t52
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  %t55 = getelementptr i8, ptr %t51, i64 %p_9_5
  store i8 %t50, ptr %t55, align 1
  %t56 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_9_5, i64 1)
  %t57 = extractvalue { i64, i1 } %t56, 0
  %t58 = extractvalue { i64, i1 } %t56, 1
  %t59 = xor i1 %t58, true
  br i1 %t59, label %ok_60, label %trap_60
trap_60:
  call void @abort()
  unreachable
ok_60:
  br label %edge_11
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_10 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_10 ]
  %p_10_2 = phi %hia.buffer [ %p_8_2, %edge_10 ]
  %p_10_3 = phi %hia.buffer [ %p_8_3, %edge_10 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_10 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ]
  %t61 = extractvalue %hia.buffer %p_10_3, 1
  br label %edge_12
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_12 ], [ %p_12_0, %edge_15 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ], [ %p_12_1, %edge_15 ]
  %p_11_2 = phi %hia.buffer [ %p_10_2, %edge_12 ], [ %p_12_2, %edge_15 ]
  %p_11_3 = phi %hia.buffer [ %p_10_3, %edge_12 ], [ %p_12_3, %edge_15 ]
  %p_11_4 = phi i64 [ 0, %edge_12 ], [ %t71, %edge_15 ]
  %p_11_5 = phi i64 [ %t61, %edge_12 ], [ %p_12_5, %edge_15 ]
  %p_11_6 = phi i64 [ 0, %edge_12 ], [ %t76, %edge_15 ]
  %t62 = icmp ult i64 %p_11_6, %p_11_5
  br i1 %t62, label %edge_13, label %edge_14
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_11_1, %edge_13 ]
  %p_12_2 = phi %hia.buffer [ %p_11_2, %edge_13 ]
  %p_12_3 = phi %hia.buffer [ %p_11_3, %edge_13 ]
  %p_12_4 = phi i64 [ %p_11_4, %edge_13 ]
  %p_12_5 = phi i64 [ %p_11_5, %edge_13 ]
  %p_12_6 = phi i64 [ %p_11_6, %edge_13 ]
  %t63 = extractvalue %hia.buffer %p_12_3, 0
  %t64 = extractvalue %hia.buffer %p_12_3, 1
  %t65 = icmp ult i64 %p_12_6, %t64
  br i1 %t65, label %ok_66, label %trap_66
trap_66:
  call void @abort()
  unreachable
ok_66:
  %t67 = getelementptr i8, ptr %t63, i64 %p_12_6
  %t68 = load i8, ptr %t67, align 1
  %t69 = zext i8 %t68 to i64
  %t70 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_12_4, i64 %t69)
  %t71 = extractvalue { i64, i1 } %t70, 0
  %t72 = extractvalue { i64, i1 } %t70, 1
  %t73 = xor i1 %t72, true
  br i1 %t73, label %ok_74, label %trap_74
trap_74:
  call void @abort()
  unreachable
ok_74:
  %t75 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_12_6, i64 1)
  %t76 = extractvalue { i64, i1 } %t75, 0
  %t77 = extractvalue { i64, i1 } %t75, 1
  %t78 = xor i1 %t77, true
  br i1 %t78, label %ok_79, label %trap_79
trap_79:
  call void @abort()
  unreachable
ok_79:
  br label %edge_15
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_14 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_13_2 = phi %hia.buffer [ %p_11_2, %edge_14 ]
  %p_13_3 = phi %hia.buffer [ %p_11_3, %edge_14 ]
  %p_13_4 = phi i64 [ %p_11_4, %edge_14 ]
  %p_13_5 = phi i64 [ %p_11_5, %edge_14 ]
  %p_13_6 = phi i64 [ %p_11_6, %edge_14 ]
  %t80 = extractvalue %hia.buffer %p_13_3, 0
  ; intentionally removed actual free
  %t81 = extractvalue %hia.buffer %p_13_2, 0
  ; intentionally removed actual free
  ret i64 %p_13_4
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b8
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b11
}

define internal i64 @__hia_fn_4(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 7, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 7, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  %t6 = extractvalue %hia.buffer %p_1_3, 0
  %t7 = extractvalue %hia.buffer %p_1_3, 1
  %t8 = icmp ult i64 0, %t7
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = getelementptr i8, ptr %t6, i64 0
  store i8 19, ptr %t10, align 1
  %t11 = call %hia.alloc @__hia_allocate(i64 %p_1_0, i1 true)
  %t12 = extractvalue %hia.alloc %t11, 0
  %t13 = extractvalue %hia.alloc %t11, 1
  %t14 = select i1 %t13, i64 %p_1_0, i64 0
  %t15 = insertvalue %hia.buffer %t12, i64 %t14, 1
  br i1 %t13, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t16 = extractvalue %hia.buffer %p_2_3, 0
  ; intentionally removed actual free
  %t17 = zext i8 %p_2_4 to i64
  %t18 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 100, i64 %t17)
  %t19 = extractvalue { i64, i1 } %t18, 0
  %t20 = extractvalue { i64, i1 } %t18, 1
  %t21 = xor i1 %t20, true
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  ret i64 %t19
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_3 = phi i1 [ %t13, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %t15, %edge_2 ]
  %p_3_5 = phi i8 [ 1, %edge_2 ]
  %t23 = call %hia.buffer @__hia_fn_0(%hia.buffer %p_3_4)
  %t24 = icmp ne i32 %p_3_1, 0
  br i1 %t24, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_3 = phi i1 [ %t13, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %t15, %edge_3 ]
  %p_4_5 = phi i8 [ 1, %edge_3 ]
  %t25 = extractvalue %hia.buffer %p_4_4, 0
  ; intentionally removed actual free
  %t26 = extractvalue %hia.buffer %p_4_2, 0
  ; intentionally removed actual free
  %t27 = zext i8 %p_4_5 to i64
  ret i64 %t27
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %t23, %edge_4 ]
  %t28 = extractvalue %hia.buffer %p_5_3, 0
  ; intentionally removed actual free
  %t29 = extractvalue %hia.buffer %p_5_2, 0
  ; intentionally removed actual free
  ret i64 2
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi %hia.buffer [ %p_3_2, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %t23, %edge_5 ]
  %t30 = extractvalue %hia.buffer %p_6_3, 1
  %t31 = extractvalue %hia.buffer %p_6_2, 0
  %t32 = extractvalue %hia.buffer %p_6_2, 1
  %t33 = icmp ult i64 0, %t32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = getelementptr i8, ptr %t31, i64 0
  %t36 = load i8, ptr %t35, align 1
  %t37 = zext i8 %t36 to i64
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t30, i64 %t37)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = extractvalue %hia.buffer %p_6_3, 0
  ; intentionally removed actual free
  %t44 = extractvalue %hia.buffer %p_6_2, 0
  ; intentionally removed actual free
  ret i64 %t39
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define i64 @full_lifecycle(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_1(i64 %a0, i32 %a1)
  ret i64 %result
}

define i64 @constructor_error(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_2(i64 %a0, i32 %a1)
  ret i64 %result
}

define i64 @two_stage(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_3(i64 %a0, i32 %a1)
  ret i64 %result
}

define i64 @two_alloc(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_4(i64 %a0, i32 %a1)
  ret i64 %result
}
