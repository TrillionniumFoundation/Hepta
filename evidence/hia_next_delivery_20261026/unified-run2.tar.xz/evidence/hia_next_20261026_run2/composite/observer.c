
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/resource.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[64];
static size_t attempts,allocations,frees,live,refusals,invalid_frees;
static bool refuse_next;
static void *remember(void *p) {
  if(p){size_t i;for(i=0;i<64 && addresses[i];i++);if(i==64)exit(89);
    addresses[i]=p;allocations++;live++;}return p;
}
void *__wrap_malloc(size_t n) {
  attempts++;if(refuse_next){refuse_next=false;refusals++;return NULL;}
  return remember(__real_malloc(n));
}
void *__wrap_calloc(size_t n,size_t width) {
  attempts++;if(refuse_next){refuse_next=false;refusals++;return NULL;}
  return remember(__real_calloc(n,width));
}
void __wrap_free(void *p) {
  if(p){size_t i;for(i=0;i<64 && addresses[i]!=p;i++);
    if(i==64){invalid_frees++;exit(90);}addresses[i]=NULL;frees++;live--;}
  __real_free(p);
}
extern uint8_t stored(bool);
extern size_t choose(bool,size_t);
extern size_t task_case(uint8_t);
struct input {unsigned kind;uint64_t first,second;bool fail;};
static const struct input inputs[]={{0,UINT64_C(0),UINT64_C(0),false},
{0,UINT64_C(1),UINT64_C(0),false},
{1,UINT64_C(0),UINT64_C(0),false},
{1,UINT64_C(0),UINT64_C(7),false},
{1,UINT64_C(0),UINT64_C(18446744073709551615),false},
{1,UINT64_C(0),UINT64_C(7),true},
{1,UINT64_C(1),UINT64_C(0),false},
{1,UINT64_C(1),UINT64_C(7),false},
{1,UINT64_C(1),UINT64_C(18446744073709551615),false},
{1,UINT64_C(1),UINT64_C(7),true},
{2,UINT64_C(0),UINT64_C(0),false},
{2,UINT64_C(0),UINT64_C(0),true},
{2,UINT64_C(1),UINT64_C(0),false},
{2,UINT64_C(1),UINT64_C(0),true},
{2,UINT64_C(2),UINT64_C(0),false},
{2,UINT64_C(2),UINT64_C(0),true},
{2,UINT64_C(255),UINT64_C(0),false},
{2,UINT64_C(255),UINT64_C(0),true}};
int main(void) {
  struct rlimit no_core={0,0}; if(setrlimit(RLIMIT_CORE,&no_core))return 88;
  for(size_t index=0;index<sizeof(inputs)/sizeof(inputs[0]);index++) {
    struct input c=inputs[index];refuse_next=c.fail;size_t value;
    if(c.kind==0)value=stored((bool)c.first);
    else if(c.kind==1)value=choose((bool)c.first,(size_t)c.second);
    else value=task_case((uint8_t)c.first);
    if(refuse_next)return 92;
    printf("{\"index\":%zu,\"result\":%zu}\n",index,value);
  }
  printf("{\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,\"live\":%zu,\"refusals\":%zu,\"invalid_frees\":%zu}\n",
    attempts,allocations,frees,live,refusals,invalid_frees);
  return live || invalid_frees ? 91 : 0;
}
