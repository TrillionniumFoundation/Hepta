#include <stddef.h>
#include <stdint.h>
#include <sys/resource.h>
extern size_t task_case(uint8_t);int main(void){struct rlimit c={0,0};if(setrlimit(RLIMIT_CORE,&c))return 88;return (int)task_case(0);}
