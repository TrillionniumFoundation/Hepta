# Independent review of performance protocol V3

Status: **source review complete; run3 result pending at review**. Date: 2026-10-26.

Commit: `ae0c0f8b467b401e22efdb18ffbb15ab32da0eb9`  
Tree: `b83bcfbecaf380ba6369ce01128389175e59f7f8`

This is an independent review by the resource-core agent of the optimizer agent's implementation. It is not an external human review or an independently sampled experiment. Only source reads, Git identity checks, and static schedule-count recomputation were performed. No compilation, native execution, timing, or new test execution occurred in this review.

## Findings

No blocking defect was found in the reviewed V3 schedule or evaluator binding. The schedule uses the group and the kernel's original index, independently of its rotated execution position. All 63 `(group, kernel, backend)` identities are unique. Every kernel uses all six backend permutations over seven groups.

Each vector below gives counts in execution positions **first, middle, last**:

| Kernel | Generated Rust | HIA / LLVM | Handwritten Rust |
| --- | --- | --- | --- |
| `full_lifecycle` | [3, 2, 2] | [2, 3, 2] | [2, 2, 3] |
| `constructor_error` | [2, 2, 3] | [3, 2, 2] | [2, 3, 2] |
| `two_stage` | [2, 3, 2] | [2, 2, 3] | [3, 2, 2] |

The HIA measurement loop and its local evaluation wrapper call the same fixed schedule. The wrapper offers no caller-supplied schedule override. The shared evaluator retains the historical default; an explicit schedule must preserve all 63 fixed group/kernel slots, legal backends, and unique identities. Each result is checked against the expected tuple, original sample index, and oracle checksum. Reordering results and rewriting indices cannot authorize a different HIA schedule.

The reviewed regression tests cover the historical fixed-middle defect, six permutations, position counts, old/new schedule cross-rejection, resealed row swaps, duplicates, truncation, malformed plans, and attempted HIA override. This review inspected those tests; their execution evidence belongs to the separate test run.

## Invariants

Relative to the preceding commit, only the protocol identifier and ordering fields changed. Static native inputs remain byte-identical: both drivers, the Hepta benchmark source, handwritten Rust reference, and allocator observer. Native call counts remain 8,388,608 for `constructor_error` and 1,048,576 for each other kernel; buffer size remains 4,093, warmup remains 8,192 calls per process, and the seed sequence is unchanged.

Seven groups and 63 samples remain mandatory. Sample bounds remain 0.05–30 seconds; maximum relative MAD is 5%; maximum per-kernel paired ratio is 1.20; maximum geometric mean paired ratio is 1.10. Every sample is retained, with no clipping, retries, calibration, or best-run selection. Fixed build-layout and artifact-retention rules remain unchanged.

## Interpretation

V3 is a prospectively frozen correction after the V2 ordering defect was discovered. It fixes a demonstrated confound independently of whether that confound explains earlier MAD. Run1 and run2 must remain visible with their original results. A subsequent V3 pass would establish only the specified finite host qualification; it would not by itself establish the cause of V2 variation, an independent experiment, physical-device qualification, or a general advantage over Rust.

The companion [review.json](review.json) contains pinned source hashes, complete static schedule, counts, unchanged constants, and explicit false claims. Run3 was still pending when this review was written; no result is anticipated or substituted.
