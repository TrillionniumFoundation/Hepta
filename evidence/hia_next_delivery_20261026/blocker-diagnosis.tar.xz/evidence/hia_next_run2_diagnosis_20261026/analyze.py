from pathlib import Path
import hashlib,json,math,re,statistics,struct,subprocess
ROOT=Path('/workspace/scratch/06ad8295a712/hepta-unified')
OUT=ROOT/'evidence/hia_next_run2_diagnosis_20261026'
OUT.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
KERNELS=('constructor_error','full_lifecycle','two_stage')
BACKENDS=('llvm','rust','handwritten_rust')
def corr(a,b):
 a=[x-statistics.mean(a) for x in a];b=[x-statistics.mean(b) for x in b]
 den=math.sqrt(sum(x*x for x in a)*sum(x*x for x in b))
 return sum(x*y for x,y in zip(a,b))/den if den else None
def stats(xs):
 m=statistics.median(xs)
 return {'minimum':min(xs),'median':m,'maximum':max(xs),'relative_mad':statistics.median(abs(x-m) for x in xs)/m}
def functions(raw):
 off=struct.unpack_from('<Q',raw,40)[0];size,num,ni=struct.unpack_from('<HHH',raw,58)
 heads=[struct.unpack_from('<IIQQQQIIQQ',raw,off+i*size) for i in range(num)]
 namesh=heads[ni];names=raw[namesh[4]:namesh[4]+namesh[5]]
 ti,th=next((i,h) for i,h in enumerate(heads) if names[h[0]:].split(b'\0',1)[0]==b'.text')
 result={}
 for h in heads:
  if h[1]!=2:continue
  nh=heads[h[6]];n=raw[nh[4]:nh[4]+nh[5]]
  for i in range(0,h[5],h[9]):
   nn,info,other,sec,addr,length=struct.unpack_from('<IBBHQQ',raw,h[4]+i)
   name=n[nn:].split(b'\0',1)[0].decode()
   if info&15!=2 or sec!=ti or name not in KERNELS:continue
   code=raw[th[4]+addr-th[3]:th[4]+addr-th[3]+length]
   result[name]={'address':addr,'bytes':length,'sha256':sha(code)}
 return result
reports={};commands=[];static={};samples={};bindings={}
for run in (1,2):
 key='run'+str(run);p=ROOT/f'evidence/hia_next_20261026_run{run}/performance.json';j=json.loads(p.read_text());reports[key]=j
 bindings[key]={'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes()),'git_commit':j['git_commit'],'protocol':j['protocol']['id'],'compiler_tree_sha256':j['compiler_tree_sha256'],'source_sha256':j['source_sha256'],'core_sha256':j['core_sha256'],'llvm_sha256':j['llvm_sha256'],'generated_rust_sha256':j['generated_rust_sha256'],'status':j['status'],'started_utc':j['started_utc'],'finished_utc':j['finished_utc']}
 samples[key]={}
 for kernel in KERNELS:
  samples[key][kernel]={}
  for backend in BACKENDS:
   rows=[r for r in j['raw_samples'] if r['kernel']==kernel and r['backend']==backend]
   for r in rows:
    observed=json.loads(r['execution']['stdout']);assert all(r[k]==v for k,v in observed.items())
    assert r['execution']['returncode']==0 and r['library_sha256']==j['artifacts'][backend]['sha256']
   samples[key][kernel][backend]={'wall_ns':stats([r['elapsed_ns'] for r in rows]),'cpu_ns':stats([r['process_cpu_ns'] for r in rows]),'cpu_to_wall':stats([r['process_cpu_ns']/r['elapsed_ns'] for r in rows]),'wall_minus_cpu_ns':stats([r['elapsed_ns']-r['process_cpu_ns'] for r in rows]),'correlation_with_group_index':corr(list(range(7)),[r['elapsed_ns'] for r in rows]),'observations':[{k:r[k] for k in ('sample_index','group','elapsed_ns','process_cpu_ns','clock_resolution_ns','involuntary_context_switches','voluntary_context_switches','minor_page_faults','major_page_faults')} for r in rows]}
 static[key]={}
 for backend in BACKENDS:
  p=Path(j['artifact_retention']['directory'])/(backend+'.so');raw=p.read_bytes();expected=j['artifacts'][backend]
  assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
  static[key][backend]={'retained_path':str(p.relative_to(ROOT)),'sha256':sha(raw),'bytes':len(raw),'functions':functions(raw),'checksum_loops':{}}
  for kernel in KERNELS:
   argv=['/usr/bin/objdump','-d','--disassemble='+kernel,str(p)]
   process=subprocess.run(argv,capture_output=True,text=True,check=True)
   fn=key+'-'+backend+'-'+kernel+'.asm';(OUT/fn).write_text(process.stdout)
   commands.append({'argv':argv,'returncode':process.returncode,'stdout_file':fn,'stdout_sha256':sha((OUT/fn).read_bytes()),'stderr':process.stderr})
   inst=[]
   for line in process.stdout.splitlines():
    m=re.match(r'^\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}\s+)+)\s*([a-z][a-z0-9]*)\s*(.*?)\s*$',line)
    if m:inst.append({'address':int(m[1],16),'bytes':''.join(m[2].split()),'opcode':m[3],'operands':m[4]})
   loops=[]
   for i in range(len(inst)-6):
    seq=inst[i:i+7]
    if [x['opcode'] for x in seq]==['mov','movzbl','add','jb','inc','cmp','jne'] and int(seq[-1]['operands'].split()[0],16)==seq[0]['address']:
     code=bytes.fromhex(''.join(x['bytes'] for x in seq));addr=seq[0]['address'];loops.append({'address':addr,'address_hex':hex(addr),'bytes':len(code),'sha256':sha(code),'machine_bytes_hex':code.hex(),'start_mod_32':addr%32,'crosses_32_byte_boundary':addr//32!=(addr+len(code)-1)//32})
   static[key][backend]['checksum_loops'][kernel]=loops
# Independently validate retained copies and original-path mapping.
retention_checks={}
for key,j in reports.items():
 directory=Path(j['artifact_retention']['directory']);manifest=json.loads((directory/'artifact-retention.json').read_text())
 assert sha((directory/'artifact-retention.json').read_bytes())==j['artifact_retention']['manifest_sha256']
 for name,item in manifest['files'].items():
  p=directory/name;assert p.stat().st_size==item['bytes'] and sha(p.read_bytes())==item['sha256']
 for name,item in j['artifacts'].items():
  rel='driver' if name=='driver' else name+'.so'
  if key=='run2':assert manifest['path_mapping'][rel]['original']==item['path']
  assert manifest['files'][rel]=={'bytes':item['bytes'],'sha256':item['sha256']}
 retention_checks[key]={'files_rehashed':len(manifest['files']),'manifest_sha256':j['artifact_retention']['manifest_sha256'],'all_measured_identities_match':True}
correlations={}
for kernel in KERNELS:
 series={b:[x['elapsed_ns'] for x in samples['run2'][kernel][b]['observations']] for b in BACKENDS}
 correlations[kernel]={a+'/'+b:corr(series[a],series[b]) for a,b in [('llvm','rust'),('llvm','handwritten_rust'),('rust','handwritten_rust')]}
comparisons={}
for backend in BACKENDS:
 a,b=static['run1'][backend],static['run2'][backend]
 comparisons[backend]={'whole_binary_equal':a['sha256']==b['sha256'],'functions':{k:{'run1':a['functions'][k],'run2':b['functions'][k],'same_address':a['functions'][k]['address']==b['functions'][k]['address'],'same_bytes':a['functions'][k]['sha256']==b['functions'][k]['sha256']} for k in KERNELS}}
summary={'schema':'hepta.hia.run2-static-sample-diagnosis.v1','reports':bindings,'retention_checks':retention_checks,'sample_statistics':samples,'run2_pairwise_group_correlations':correlations,'correlation_scope':'Descriptive Pearson correlations over seven ordered groups; no independence or causal inference claimed.','run2_evaluation':reports['run2']['evaluation'],'static_comparisons':comparisons,'static_artifacts':static,'source_tool_flags_unchanged':all(reports['run1']['native_receipts']['rust'][k]==reports['run2']['native_receipts']['rust'][k] for k in ('toolchain','flags','link_args','target')),'all_constructor_samples_have_zero_page_faults_and_voluntary_switches':all(all(r[k]==0 for k in ('minor_page_faults','major_page_faults','voluntary_context_switches')) for r in reports['run2']['raw_samples'] if r['kernel']=='constructor_error'),'new_native_workload_executions':0,'new_timing_samples':0,'qualification_status':'measurement_inconclusive','physical_cause_identified':False,'causal_percentage_from_layout_established':False,'longer_interval_replication_executed':False,'decision':'Preserve run2 as inconclusive; no new protocol or timing replication. Additional controlled-host evidence is required before the performance blocker can close.'}
(OUT/'diagnosis.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
(OUT/'commands.json').write_text(json.dumps(commands,sort_keys=True,indent=2)+'\n')
(OUT/'analyze.py').write_bytes(Path(__file__).read_bytes())
(OUT/'tool.json').write_text(json.dumps({'objdump':{'path':'/usr/bin/objdump','sha256':sha(Path('/usr/bin/objdump').resolve().read_bytes())}},sort_keys=True,indent=2)+'\n')
print(json.dumps({'directory':str(OUT),'loops':{run:{b:static[run][b]['checksum_loops'] for b in BACKENDS} for run in static},'correlations':correlations},indent=2))
