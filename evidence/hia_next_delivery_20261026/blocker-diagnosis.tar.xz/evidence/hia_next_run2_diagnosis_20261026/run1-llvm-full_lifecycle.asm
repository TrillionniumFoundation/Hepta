
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/llvm.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001150 <full_lifecycle>:
    1150:	55                   	push   %rbp
    1151:	41 56                	push   %r14
    1153:	53                   	push   %rbx
    1154:	48 85 ff             	test   %rdi,%rdi
    1157:	74 4c                	je     11a5 <full_lifecycle+0x55>
    1159:	89 f5                	mov    %esi,%ebp
    115b:	48 89 fb             	mov    %rdi,%rbx
    115e:	78 26                	js     1186 <full_lifecycle+0x36>
    1160:	bf 01 00 00 00       	mov    $0x1,%edi
    1165:	48 89 de             	mov    %rbx,%rsi
    1168:	e8 f3 fe ff ff       	call   1060 <calloc@plt>
    116d:	48 85 c0             	test   %rax,%rax
    1170:	74 14                	je     1186 <full_lifecycle+0x36>
    1172:	48 89 c7             	mov    %rax,%rdi
    1175:	b0 01                	mov    $0x1,%al
    1177:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    117d:	a8 01                	test   $0x1,%al
    117f:	75 17                	jne    1198 <full_lifecycle+0x48>
    1181:	e9 8f 01 00 00       	jmp    1315 <full_lifecycle+0x1c5>
    1186:	31 ff                	xor    %edi,%edi
    1188:	31 c0                	xor    %eax,%eax
    118a:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1190:	a8 01                	test   $0x1,%al
    1192:	0f 84 7d 01 00 00    	je     1315 <full_lifecycle+0x1c5>
    1198:	48 83 fb 03          	cmp    $0x3,%rbx
    119c:	77 11                	ja     11af <full_lifecycle+0x5f>
    119e:	31 c0                	xor    %eax,%eax
    11a0:	e9 36 01 00 00       	jmp    12db <full_lifecycle+0x18b>
    11a5:	31 ff                	xor    %edi,%edi
    11a7:	45 31 f6             	xor    %r14d,%r14d
    11aa:	e9 66 01 00 00       	jmp    1315 <full_lifecycle+0x1c5>
    11af:	66 0f 6e c5          	movd   %ebp,%xmm0
    11b3:	48 83 fb 10          	cmp    $0x10,%rbx
    11b7:	73 07                	jae    11c0 <full_lifecycle+0x70>
    11b9:	31 c0                	xor    %eax,%eax
    11bb:	e9 b4 00 00 00       	jmp    1274 <full_lifecycle+0x124>
    11c0:	48 89 d8             	mov    %rbx,%rax
    11c3:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    11c7:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    11cc:	66 0f 6f 15 2c 0e 00 	movdqa 0xe2c(%rip),%xmm2        # 2000 <_fini+0xa30>
    11d3:	00 
    11d4:	66 0f 6f 1d 34 0e 00 	movdqa 0xe34(%rip),%xmm3        # 2010 <_fini+0xa40>
    11db:	00 
    11dc:	66 0f 6f 25 3c 0e 00 	movdqa 0xe3c(%rip),%xmm4        # 2020 <_fini+0xa50>
    11e3:	00 
    11e4:	66 0f 6f 2d 44 0e 00 	movdqa 0xe44(%rip),%xmm5        # 2030 <_fini+0xa60>
    11eb:	00 
    11ec:	31 c9                	xor    %ecx,%ecx
    11ee:	66 0f 6f 35 4a 0e 00 	movdqa 0xe4a(%rip),%xmm6        # 2040 <_fini+0xa70>
    11f5:	00 
    11f6:	66 0f 6f 3d 52 0e 00 	movdqa 0xe52(%rip),%xmm7        # 2050 <_fini+0xa80>
    11fd:	00 
    11fe:	66 90                	xchg   %ax,%ax
    1200:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    1205:	66 44 0f fe c2       	paddd  %xmm2,%xmm8
    120a:	66 44 0f 6f c9       	movdqa %xmm1,%xmm9
    120f:	66 44 0f fe cb       	paddd  %xmm3,%xmm9
    1214:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    1219:	66 44 0f fe d4       	paddd  %xmm4,%xmm10
    121e:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    1223:	66 44 0f fe dd       	paddd  %xmm5,%xmm11
    1228:	66 44 0f db de       	pand   %xmm6,%xmm11
    122d:	66 44 0f db d6       	pand   %xmm6,%xmm10
    1232:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    1237:	66 44 0f db ce       	pand   %xmm6,%xmm9
    123c:	66 44 0f db c6       	pand   %xmm6,%xmm8
    1241:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    1246:	66 45 0f 67 d9       	packuswb %xmm9,%xmm11
    124b:	f3 44 0f 7f 1c 0f    	movdqu %xmm11,(%rdi,%rcx,1)
    1251:	48 83 c1 10          	add    $0x10,%rcx
    1255:	66 0f fe ef          	paddd  %xmm7,%xmm5
    1259:	66 0f fe e7          	paddd  %xmm7,%xmm4
    125d:	66 0f fe df          	paddd  %xmm7,%xmm3
    1261:	66 0f fe d7          	paddd  %xmm7,%xmm2
    1265:	48 39 c8             	cmp    %rcx,%rax
    1268:	75 96                	jne    1200 <full_lifecycle+0xb0>
    126a:	48 39 c3             	cmp    %rax,%rbx
    126d:	74 7f                	je     12ee <full_lifecycle+0x19e>
    126f:	f6 c3 0c             	test   $0xc,%bl
    1272:	74 67                	je     12db <full_lifecycle+0x18b>
    1274:	48 89 c1             	mov    %rax,%rcx
    1277:	48 89 d8             	mov    %rbx,%rax
    127a:	66 0f 6e c9          	movd   %ecx,%xmm1
    127e:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
    1283:	66 0f eb 0d a5 0d 00 	por    0xda5(%rip),%xmm1        # 2030 <_fini+0xa60>
    128a:	00 
    128b:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
    128f:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1294:	66 0f 6f 15 a4 0d 00 	movdqa 0xda4(%rip),%xmm2        # 2040 <_fini+0xa70>
    129b:	00 
    129c:	66 0f 6f 1d bc 0d 00 	movdqa 0xdbc(%rip),%xmm3        # 2060 <_fini+0xa90>
    12a3:	00 
    12a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    12ab:	00 00 00 00 00 
    12b0:	66 0f 6f e0          	movdqa %xmm0,%xmm4
    12b4:	66 0f fe e1          	paddd  %xmm1,%xmm4
    12b8:	66 0f db e2          	pand   %xmm2,%xmm4
    12bc:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    12c0:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    12c4:	66 0f 7e 24 0f       	movd   %xmm4,(%rdi,%rcx,1)
    12c9:	48 83 c1 04          	add    $0x4,%rcx
    12cd:	66 0f fe cb          	paddd  %xmm3,%xmm1
    12d1:	48 39 c8             	cmp    %rcx,%rax
    12d4:	75 da                	jne    12b0 <full_lifecycle+0x160>
    12d6:	48 39 c3             	cmp    %rax,%rbx
    12d9:	74 13                	je     12ee <full_lifecycle+0x19e>
    12db:	89 e9                	mov    %ebp,%ecx
    12dd:	0f 1f 00             	nopl   (%rax)
    12e0:	8d 14 01             	lea    (%rcx,%rax,1),%edx
    12e3:	88 14 07             	mov    %dl,(%rdi,%rax,1)
    12e6:	48 ff c0             	inc    %rax
    12e9:	48 39 c3             	cmp    %rax,%rbx
    12ec:	75 f2                	jne    12e0 <full_lifecycle+0x190>
    12ee:	31 c0                	xor    %eax,%eax
    12f0:	45 31 f6             	xor    %r14d,%r14d
    12f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    12fa:	84 00 00 00 00 00 
    1300:	4c 89 f1             	mov    %r14,%rcx
    1303:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1308:	49 01 ce             	add    %rcx,%r14
    130b:	72 15                	jb     1322 <full_lifecycle+0x1d2>
    130d:	48 ff c0             	inc    %rax
    1310:	48 39 c3             	cmp    %rax,%rbx
    1313:	75 eb                	jne    1300 <full_lifecycle+0x1b0>
    1315:	e8 16 fd ff ff       	call   1030 <free@plt>
    131a:	4c 89 f0             	mov    %r14,%rax
    131d:	5b                   	pop    %rbx
    131e:	41 5e                	pop    %r14
    1320:	5d                   	pop    %rbp
    1321:	c3                   	ret
    1322:	e8 19 fd ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
