
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012c40 <constructor_error>:
   12c40:	55                   	push   %rbp
   12c41:	41 56                	push   %r14
   12c43:	53                   	push   %rbx
   12c44:	48 83 ec 30          	sub    $0x30,%rsp
   12c48:	41 be ea 03 00 00    	mov    $0x3ea,%r14d
   12c4e:	48 85 ff             	test   %rdi,%rdi
   12c51:	74 5c                	je     12caf <constructor_error+0x6f>
   12c53:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
   12c59:	78 54                	js     12caf <constructor_error+0x6f>
   12c5b:	48 89 fb             	mov    %rdi,%rbx
   12c5e:	89 f5                	mov    %esi,%ebp
   12c60:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   12c67:	00 00 
   12c69:	48 89 e7             	mov    %rsp,%rdi
   12c6c:	48 8d 4c 24 18       	lea    0x18(%rsp),%rcx
   12c71:	be 01 00 00 00       	mov    $0x1,%esi
   12c76:	48 89 da             	mov    %rbx,%rdx
   12c79:	e8 12 fd ff ff       	call   12990 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12c7e:	83 3c 24 01          	cmpl   $0x1,(%rsp)
   12c82:	74 29                	je     12cad <constructor_error+0x6d>
   12c84:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   12c89:	48 83 fb 01          	cmp    $0x1,%rbx
   12c8d:	48 8d 44 1f ff       	lea    -0x1(%rdi,%rbx,1),%rax
   12c92:	48 0f 44 c7          	cmove  %rdi,%rax
   12c96:	c6 00 00             	movb   $0x0,(%rax)
   12c99:	ba 01 00 00 00       	mov    $0x1,%edx
   12c9e:	48 89 de             	mov    %rbx,%rsi
   12ca1:	ff 15 b1 dc 03 00    	call   *0x3dcb1(%rip)        # 50958 <_DYNAMIC+0x1f8>
   12ca7:	41 be ea 03 00 00    	mov    $0x3ea,%r14d
   12cad:	89 ee                	mov    %ebp,%esi
   12caf:	89 f0                	mov    %esi,%eax
   12cb1:	4c 01 f0             	add    %r14,%rax
   12cb4:	48 83 c4 30          	add    $0x30,%rsp
   12cb8:	5b                   	pop    %rbx
   12cb9:	41 5e                	pop    %r14
   12cbb:	5d                   	pop    %rbp
   12cbc:	c3                   	ret

Disassembly of section .plt:
