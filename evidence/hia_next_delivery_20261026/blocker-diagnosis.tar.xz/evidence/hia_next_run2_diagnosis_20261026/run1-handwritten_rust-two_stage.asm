
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/handwritten_rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012c70 <two_stage>:
   12c70:	55                   	push   %rbp
   12c71:	41 57                	push   %r15
   12c73:	41 56                	push   %r14
   12c75:	41 55                	push   %r13
   12c77:	41 54                	push   %r12
   12c79:	53                   	push   %rbx
   12c7a:	48 83 ec 38          	sub    $0x38,%rsp
   12c7e:	48 89 fb             	mov    %rdi,%rbx
   12c81:	48 85 ff             	test   %rdi,%rdi
   12c84:	0f 84 94 00 00 00    	je     12d1e <two_stage+0xae>
   12c8a:	41 bc e9 03 00 00    	mov    $0x3e9,%r12d
   12c90:	78 7a                	js     12d0c <two_stage+0x9c>
   12c92:	89 f5                	mov    %esi,%ebp
   12c94:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12c9b:	00 00 
   12c9d:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12ca2:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12ca7:	be 01 00 00 00       	mov    $0x1,%esi
   12cac:	48 89 da             	mov    %rbx,%rdx
   12caf:	e8 7c fc ff ff       	call   12930 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12cb4:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
   12cb9:	74 51                	je     12d0c <two_stage+0x9c>
   12cbb:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   12cc0:	48 83 fb 01          	cmp    $0x1,%rbx
   12cc4:	0f 84 db 00 00 00    	je     12da5 <two_stage+0x135>
   12cca:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
   12cce:	4c 8b 3d f3 dc 03 00 	mov    0x3dcf3(%rip),%r15        # 509c8 <memset@GLIBC_2.2.5>
   12cd5:	4c 89 f7             	mov    %r14,%rdi
   12cd8:	31 f6                	xor    %esi,%esi
   12cda:	41 ff d7             	call   *%r15
   12cdd:	41 c6 44 1e ff 00    	movb   $0x0,-0x1(%r14,%rbx,1)
   12ce3:	4c 89 f7             	mov    %r14,%rdi
   12ce6:	89 ee                	mov    %ebp,%esi
   12ce8:	48 89 da             	mov    %rbx,%rdx
   12ceb:	41 ff d7             	call   *%r15
   12cee:	49 89 df             	mov    %rbx,%r15
   12cf1:	49 83 c7 11          	add    $0x11,%r15
   12cf5:	0f 89 c2 00 00 00    	jns    12dbd <two_stage+0x14d>
   12cfb:	ba 01 00 00 00       	mov    $0x1,%edx
   12d00:	4c 89 f7             	mov    %r14,%rdi
   12d03:	48 89 de             	mov    %rbx,%rsi
   12d06:	ff 15 6c dc 03 00    	call   *0x3dc6c(%rip)        # 50978 <_DYNAMIC+0x1f8>
   12d0c:	4c 89 e0             	mov    %r12,%rax
   12d0f:	48 83 c4 38          	add    $0x38,%rsp
   12d13:	5b                   	pop    %rbx
   12d14:	41 5c                	pop    %r12
   12d16:	41 5d                	pop    %r13
   12d18:	41 5e                	pop    %r14
   12d1a:	41 5f                	pop    %r15
   12d1c:	5d                   	pop    %rbp
   12d1d:	c3                   	ret
   12d1e:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12d25:	00 00 
   12d27:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12d2c:	41 be 01 00 00 00    	mov    $0x1,%r14d
   12d32:	41 bf 11 00 00 00    	mov    $0x11,%r15d
   12d38:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12d3d:	be 01 00 00 00       	mov    $0x1,%esi
   12d42:	ba 11 00 00 00       	mov    $0x11,%edx
   12d47:	e8 e4 fb ff ff       	call   12930 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12d4c:	f6 44 24 08 01       	testb  $0x1,0x8(%rsp)
   12d51:	74 08                	je     12d5b <two_stage+0xeb>
   12d53:	41 bc e9 03 00 00    	mov    $0x3e9,%r12d
   12d59:	eb b1                	jmp    12d0c <two_stage+0x9c>
   12d5b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   12d60:	0f 57 c0             	xorps  %xmm0,%xmm0
   12d63:	0f 11 07             	movups %xmm0,(%rdi)
   12d66:	c6 47 10 00          	movb   $0x0,0x10(%rdi)
   12d6a:	45 31 e4             	xor    %r12d,%r12d
   12d6d:	31 c0                	xor    %eax,%eax
   12d6f:	90                   	nop
   12d70:	4c 89 e1             	mov    %r12,%rcx
   12d73:	44 0f b6 24 07       	movzbl (%rdi,%rax,1),%r12d
   12d78:	49 01 cc             	add    %rcx,%r12
   12d7b:	0f 82 9b 01 00 00    	jb     12f1c <two_stage+0x2ac>
   12d81:	48 ff c0             	inc    %rax
   12d84:	49 39 c7             	cmp    %rax,%r15
   12d87:	75 e7                	jne    12d70 <two_stage+0x100>
   12d89:	ba 01 00 00 00       	mov    $0x1,%edx
   12d8e:	4c 89 fe             	mov    %r15,%rsi
   12d91:	ff 15 e1 db 03 00    	call   *0x3dbe1(%rip)        # 50978 <_DYNAMIC+0x1f8>
   12d97:	48 85 db             	test   %rbx,%rbx
   12d9a:	0f 85 5b ff ff ff    	jne    12cfb <two_stage+0x8b>
   12da0:	e9 67 ff ff ff       	jmp    12d0c <two_stage+0x9c>
   12da5:	41 c6 06 00          	movb   $0x0,(%r14)
   12da9:	4c 89 f7             	mov    %r14,%rdi
   12dac:	89 ee                	mov    %ebp,%esi
   12dae:	48 89 da             	mov    %rbx,%rdx
   12db1:	ff 15 11 dc 03 00    	call   *0x3dc11(%rip)        # 509c8 <memset@GLIBC_2.2.5>
   12db7:	41 bf 12 00 00 00    	mov    $0x12,%r15d
   12dbd:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12dc4:	00 00 
   12dc6:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12dcb:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12dd0:	be 01 00 00 00       	mov    $0x1,%esi
   12dd5:	4c 89 fa             	mov    %r15,%rdx
   12dd8:	e8 53 fb ff ff       	call   12930 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12ddd:	f6 44 24 08 01       	testb  $0x1,0x8(%rsp)
   12de2:	0f 85 13 ff ff ff    	jne    12cfb <two_stage+0x8b>
   12de8:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   12ded:	48 8d 53 10          	lea    0x10(%rbx),%rdx
   12df1:	45 31 ed             	xor    %r13d,%r13d
   12df4:	4c 89 e7             	mov    %r12,%rdi
   12df7:	31 f6                	xor    %esi,%esi
   12df9:	ff 15 c9 db 03 00    	call   *0x3dbc9(%rip)        # 509c8 <memset@GLIBC_2.2.5>
   12dff:	4c 89 e7             	mov    %r12,%rdi
   12e02:	41 c6 44 1c 10 00    	movb   $0x0,0x10(%r12,%rbx,1)
   12e08:	48 83 fb 04          	cmp    $0x4,%rbx
   12e0c:	0f 82 92 00 00 00    	jb     12ea4 <two_stage+0x234>
   12e12:	48 89 f8             	mov    %rdi,%rax
   12e15:	4c 29 f0             	sub    %r14,%rax
   12e18:	48 83 f8 1f          	cmp    $0x1f,%rax
   12e1c:	0f 86 82 00 00 00    	jbe    12ea4 <two_stage+0x234>
   12e22:	48 b8 e0 ff ff ff ff 	movabs $0x7fffffffffffffe0,%rax
   12e29:	ff ff 7f 
   12e2c:	48 83 fb 20          	cmp    $0x20,%rbx
   12e30:	73 05                	jae    12e37 <two_stage+0x1c7>
   12e32:	45 31 ed             	xor    %r13d,%r13d
   12e35:	eb 40                	jmp    12e77 <two_stage+0x207>
   12e37:	49 89 dd             	mov    %rbx,%r13
   12e3a:	49 21 c5             	and    %rax,%r13
   12e3d:	31 c9                	xor    %ecx,%ecx
   12e3f:	0f 28 05 7a 1d ff ff 	movaps -0xe286(%rip),%xmm0        # 4bc0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4b78>
   12e46:	41 0f 10 0c 0e       	movups (%r14,%rcx,1),%xmm1
   12e4b:	41 0f 10 54 0e 10    	movups 0x10(%r14,%rcx,1),%xmm2
   12e51:	0f 57 c8             	xorps  %xmm0,%xmm1
   12e54:	0f 57 d0             	xorps  %xmm0,%xmm2
   12e57:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
   12e5b:	0f 11 54 0f 10       	movups %xmm2,0x10(%rdi,%rcx,1)
   12e60:	48 83 c1 20          	add    $0x20,%rcx
   12e64:	49 39 cd             	cmp    %rcx,%r13
   12e67:	75 dd                	jne    12e46 <two_stage+0x1d6>
   12e69:	4c 39 eb             	cmp    %r13,%rbx
   12e6c:	0f 84 f8 fe ff ff    	je     12d6a <two_stage+0xfa>
   12e72:	f6 c3 1c             	test   $0x1c,%bl
   12e75:	74 2d                	je     12ea4 <two_stage+0x234>
   12e77:	4c 89 e9             	mov    %r13,%rcx
   12e7a:	48 83 c0 1c          	add    $0x1c,%rax
   12e7e:	49 89 c5             	mov    %rax,%r13
   12e81:	49 21 dd             	and    %rbx,%r13
   12e84:	b8 5a 5a 5a 5a       	mov    $0x5a5a5a5a,%eax
   12e89:	41 8b 14 0e          	mov    (%r14,%rcx,1),%edx
   12e8d:	31 c2                	xor    %eax,%edx
   12e8f:	89 14 0f             	mov    %edx,(%rdi,%rcx,1)
   12e92:	48 83 c1 04          	add    $0x4,%rcx
   12e96:	49 39 cd             	cmp    %rcx,%r13
   12e99:	75 ee                	jne    12e89 <two_stage+0x219>
   12e9b:	4c 39 eb             	cmp    %r13,%rbx
   12e9e:	0f 84 c6 fe ff ff    	je     12d6a <two_stage+0xfa>
   12ea4:	48 89 d9             	mov    %rbx,%rcx
   12ea7:	4c 89 e8             	mov    %r13,%rax
   12eaa:	48 83 e1 03          	and    $0x3,%rcx
   12eae:	74 1c                	je     12ecc <two_stage+0x25c>
   12eb0:	4c 89 ea             	mov    %r13,%rdx
   12eb3:	48 8d 42 01          	lea    0x1(%rdx),%rax
   12eb7:	41 0f b6 34 16       	movzbl (%r14,%rdx,1),%esi
   12ebc:	40 80 f6 5a          	xor    $0x5a,%sil
   12ec0:	40 88 34 17          	mov    %sil,(%rdi,%rdx,1)
   12ec4:	48 89 c2             	mov    %rax,%rdx
   12ec7:	48 ff c9             	dec    %rcx
   12eca:	75 e7                	jne    12eb3 <two_stage+0x243>
   12ecc:	49 29 dd             	sub    %rbx,%r13
   12ecf:	49 83 fd fc          	cmp    $0xfffffffffffffffc,%r13
   12ed3:	0f 87 91 fe ff ff    	ja     12d6a <two_stage+0xfa>
   12ed9:	41 0f b6 0c 06       	movzbl (%r14,%rax,1),%ecx
   12ede:	80 f1 5a             	xor    $0x5a,%cl
   12ee1:	88 0c 07             	mov    %cl,(%rdi,%rax,1)
   12ee4:	41 0f b6 4c 06 01    	movzbl 0x1(%r14,%rax,1),%ecx
   12eea:	80 f1 5a             	xor    $0x5a,%cl
   12eed:	88 4c 07 01          	mov    %cl,0x1(%rdi,%rax,1)
   12ef1:	41 0f b6 4c 06 02    	movzbl 0x2(%r14,%rax,1),%ecx
   12ef7:	80 f1 5a             	xor    $0x5a,%cl
   12efa:	88 4c 07 02          	mov    %cl,0x2(%rdi,%rax,1)
   12efe:	41 0f b6 4c 06 03    	movzbl 0x3(%r14,%rax,1),%ecx
   12f04:	80 f1 5a             	xor    $0x5a,%cl
   12f07:	88 4c 07 03          	mov    %cl,0x3(%rdi,%rax,1)
   12f0b:	48 8d 48 04          	lea    0x4(%rax),%rcx
   12f0f:	48 89 c8             	mov    %rcx,%rax
   12f12:	48 39 cb             	cmp    %rcx,%rbx
   12f15:	75 c2                	jne    12ed9 <two_stage+0x269>
   12f17:	e9 4e fe ff ff       	jmp    12d6a <two_stage+0xfa>
   12f1c:	48 8d 3d 75 b7 03 00 	lea    0x3b775(%rip),%rdi        # 4e698 <__frame_dummy_init_array_entry+0x8>
   12f23:	ff 15 a7 da 03 00    	call   *0x3daa7(%rip)        # 509d0 <_DYNAMIC+0x250>

Disassembly of section .plt:
