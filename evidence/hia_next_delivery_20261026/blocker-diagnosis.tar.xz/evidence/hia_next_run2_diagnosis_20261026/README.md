# Run2 diagnosis: performance qualification remains inconclusive

Run2 completed 63 samples and all fixed time-ratio limits passed, but two of nine measurement-quality groups exceeded the unchanged 5% relative-MAD limit. The complete unified result is 10/11 gates, with 1,784 tests and zero skips. This diagnosis does not change that result and does not run any new benchmark sample.

## What actually failed

| Constructor implementation | Wall median | Wall range | Wall relative MAD | CPU relative MAD |
|---|---:|---:|---:|---:|
| HIA / LLVM | 170.803 ms | 160.324–205.021 ms | 4.693% | 4.544% |
| Generated Rust | 207.176 ms | 194.384–266.793 ms | **6.175%** | **6.031%** |
| Handwritten Rust | 201.993 ms | 187.588–236.869 ms | **7.131%** | **6.991%** |

Every constructor sample performs the frozen 8,388,608 calls. These 0.16–0.27 second intervals are above the existing 0.05-second floor; there was no minimum-duration violation. All seven samples per implementation remain included.

Constructor process CPU time divided by wall time is 0.992984–0.997868. Every constructor interval reports zero minor and major page faults and zero voluntary context switches; involuntary switches are 15–26. CPU-time MAD also fails for both Rust baselines. Thus, subtracting ordinary recorded off-CPU delay would not repair the instability, and the recorded 1 ns clock resolution is far too small to explain millisecond variation. CPU time is diagnostic only: no wall-time sample or acceptance rule is replaced.

## Ordering and shared variation

The HIA and handwritten constructor group times co-vary (descriptive Pearson r=0.935, seven groups). Generated Rust co-varies less closely: r=0.543 with HIA and r=0.401 with handwritten Rust. Group 5 is slow in all three constructors, while generated Rust also has distinctly slow observations in groups 0 and 2. Constructor correlations with increasing group index are −0.324 for generated Rust, +0.198 for HIA and +0.041 for handwritten Rust; there is no single consistent monotonic trend.

These are descriptive observations over seven sequential groups, not independent causal experiments. The frozen order places handwritten Rust in the middle constructor position in every group, while HIA and generated Rust exchange the ends. It is therefore not fully counterbalanced within this kernel. This schedule is retained unchanged and is an explicit limitation of inference.

Full-lifecycle HIA/generated-Rust group times are also strongly correlated (r=0.980). This is consistent with a time-varying execution factor, but it does not identify CPU frequency, thermal conditions, host contention, virtual-machine accounting, allocator state, ASLR effects or cache state. None of those candidate causes was directly measured here. Host load averages and affinity do not establish exclusive CPU access.

## Exact binary and layout observations

Every retained run1/run2 manifest entry was independently rehashed, and run2 original-to-retained path mappings were checked against the measured identities. The HIA library, handwritten Rust library and driver are byte-identical between runs. Their fixed code cannot explain why constructor samples differ within run2. Generated Rust has unchanged source, pinned compiler and safety/optimization flags, but the v2 fixed-length build path produces a different linked artifact.

The generated Rust checksum loop instruction bytes remain exactly the same across the two builds. Their locations change as follows:

| Kernel | Run1 loop | Run2 loop | Observed placement change |
|---|---|---|---|
| full_lifecycle | 0x12bf0, 21 bytes | 0x12ba0, 21 bytes | 32-byte boundary crossing becomes non-crossing |
| two_stage | 0x12e80, 22 bytes | 0x12e30, 22 bytes | Non-crossing becomes 32-byte boundary crossing |

The HIA loops stay at 0x1300 and 0x14e0. Handwritten Rust stays unchanged. The full-lifecycle HIA/generated-Rust median paired ratio changes from 0.565 to 1.008, while two-stage changes from 1.027 to 0.544. These shifts accompany the layout changes, but no controlled alignment-only experiment was performed: neither a causal percentage nor a general compiler speedup follows from them. The 18 exact disassemblies, full function identities and loop bytes are retained here.

## Decision and remaining blocker

Run2 remains **measurement_inconclusive**. Root elected not to run a longer-interval replication or modify the protocol. A longer interval could test whether transient variation averages out, but it is not established as a cure, especially because CPU-time variability remains and slower full-lifecycle samples also occur. A later duration study should be a separately preregistered, balanced experiment using the same measured libraries and an explicitly identified driver; it must retain short and long results and every failure. Simply rerunning until a passing set appears would not close this blocker.

Controlled-host evidence sufficient to distinguish measurement instability from stable execution cost remains missing. Both prior candidates, all raw samples, both layouts and this diagnosis are retained. No frequency explanation, physical-device claim or performance qualification pass is asserted.

`diagnosis.json` contains the exact numeric observations, report hashes, manifest checks, order, correlations, source/tool identity comparison and static details. `commands.json` records only read-only disassembly commands; `analyze.py` records the analysis procedure. No measured library was rebuilt or executed by this diagnosis.
