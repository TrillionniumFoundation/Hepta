
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/llvm.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001330 <constructor_error>:
    1330:	41 56                	push   %r14
    1332:	53                   	push   %rbx
    1333:	50                   	push   %rax
    1334:	89 f3                	mov    %esi,%ebx
    1336:	41 b6 01             	mov    $0x1,%r14b
    1339:	48 85 ff             	test   %rdi,%rdi
    133c:	74 18                	je     1356 <constructor_error+0x26>
    133e:	78 0f                	js     134f <constructor_error+0x1f>
    1340:	e8 2b fd ff ff       	call   1070 <malloc@plt>
    1345:	48 85 c0             	test   %rax,%rax
    1348:	74 05                	je     134f <constructor_error+0x1f>
    134a:	48 89 c7             	mov    %rax,%rdi
    134d:	eb 09                	jmp    1358 <constructor_error+0x28>
    134f:	31 ff                	xor    %edi,%edi
    1351:	45 31 f6             	xor    %r14d,%r14d
    1354:	eb 02                	jmp    1358 <constructor_error+0x28>
    1356:	31 ff                	xor    %edi,%edi
    1358:	e8 d3 fc ff ff       	call   1030 <free@plt>
    135d:	89 d8                	mov    %ebx,%eax
    135f:	41 0f b6 ce          	movzbl %r14b,%ecx
    1363:	83 e1 01             	and    $0x1,%ecx
    1366:	48 01 c8             	add    %rcx,%rax
    1369:	48 05 e9 03 00 00    	add    $0x3e9,%rax
    136f:	48 83 c4 08          	add    $0x8,%rsp
    1373:	5b                   	pop    %rbx
    1374:	41 5e                	pop    %r14
    1376:	c3                   	ret

Disassembly of section .fini:
