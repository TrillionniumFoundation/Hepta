# Independent methodological review of performance run 2

Date: 2026-10-26. Reviewer: resource-core agent, independently reading retained data. This is a review of the same experiment, not an independently sampled replication. No builds, native executions, timing retries, protocol changes, sample exclusions, or score changes were performed for this review.

## Decision

Keep run 2 at **`measurement_inconclusive`**. Its correctness checks and all configured time-ratio thresholds pass, but two of nine kernel/backend stability checks exceed the preregistered 5% relative median absolute deviation (MAD) limit. A failed measurement-quality condition is not repaired by favorable ratios. The unified gate therefore remains 10/11; performance qualification is open.

The root's decision to preserve this result without a data-dependent longer-duration retry is methodologically sound. No threshold should be loosened and no favorable later observation should replace any of the 63 retained samples.

## Independently checked observations

Source: [`../hia_next_20261026_run2/performance.json`](../hia_next_20261026_run2/performance.json), SHA-256 `5745a319c1b7387c45a0c44dfb48a937f492fd6ad505d1a93b883aff325e5683`. Protocol: `hepta.hia.program.perf.v2`, seven paired groups, 63 samples, with every observation retained. The following statistics were recomputed directly from the raw rows.

| Constructor implementation | Wall-time relative MAD | Process-CPU-time relative MAD | CPU/wall range |
| --- | ---: | ---: | ---: |
| Standalone HIA / LLVM | 4.6931% | 4.5438% | 0.993719–0.997535 |
| Generated Rust | 6.1748% | 6.0314% | 0.993973–0.997323 |
| Handwritten Rust | 7.1313% | 6.9910% | 0.992984–0.997868 |

All six stability groups for the other two kernels satisfy 5%. Constructor samples span approximately 0.160–0.267 seconds and already exceed the protocol's 0.05-second minimum. Their recorded clock resolution is 1 nanosecond. Constructor rows record no minor/major page faults and no voluntary context switches. Involuntary switches range from 15 to 26 per sample. The process-CPU interval brackets the wall interval, so their difference is not a perfectly isolated measure of scheduler delay.

The reported median paired HIA/generated-Rust and HIA/handwritten-Rust ratios are respectively 0.83745 and 0.83988 for `constructor_error`, 1.00812 and 1.01731 for `full_lifecycle`, and 0.54431 and 0.53459 for `two_stage`. Both geometric means are below the fixed 1.10 limit. These are descriptive results of this retained run, not a qualified general speed advantage.

## What the data can and cannot explain

CPU-time MAD remains almost as large as wall-time MAD for both failing groups. Accordingly, the data do not support a claim that the observed instability is solely time spent descheduled. Recorded timer resolution is also too small, relative to the measured intervals, to substantiate a timer-resolution explanation. The cause of the on-CPU variation is not identified by these observations; no frequency, allocator, cache, virtualization, or host-load explanation has been established.

The constructor interval is shorter than the other kernels' intervals, making duration a reasonable hypothesis to test prospectively. Different kernels also perform different work, however, so their different MAD values do not isolate the effect of interval length. A correlation between elapsed time and context-switch count is likewise not causal evidence: a longer-running sample also has more opportunity to be interrupted.

Ordering is only partly balanced within this kernel. Sorting its rows by `sample_index` shows handwritten Rust in the middle backend position in every group. HIA and generated Rust alternate the two end positions, with four versus three occurrences. The seven group observations cannot independently identify backend, position, host-time, or interval effects. Rotation and alternation mitigate some ordering effects; they do not justify declaring all such effects removed. No post-hoc subgroup or order adjustment should alter the gate result.

## What a future experiment could establish

A future experiment may compare fixed short and long constructor intervals, but should be declared before collecting its observations. Its scope, exact call counts, sample counts, balanced backend and duration order, seed sequence, warmup, affinity, artifact hashes, stopping rule, quality thresholds, and reporting rules should all be fixed. Both intervals should be interleaved within the same host-time blocks and all three backends included. A controlled host and a separately scheduled replication would strengthen the interpretation. Every observation and failed attempt must remain visible; there should be no repeated sampling until MAD happens to fall below 5%.

The current [`perf_driver.c`](../../examples/hia_program/perf_driver.c) hardcodes 8,388,608 constructor calls. A true longer interval therefore requires a revised driver or an explicitly different harness. Exact retained kernel libraries can be reused, but it would be inaccurate to claim that the entire executable measurement artifact was unchanged. The revised driver, its diff, and its hash must be retained. Aggregating several existing short-process runs is a different measurement design from one longer in-process interval and should not be described as interchangeable.

Such a comparison could test whether longer intervals reduce observed dispersion under its specified conditions. A later long-only pass would not distinguish interval length from a different host/time window. Even a balanced comparison would not by itself identify the physical mechanism. Longer execution can also change steady-state behavior; normalized time per call and CPU-time observations should be examined alongside dispersion.

If the project later adopts a different default interval, it should version the protocol and run a complete prospectively specified qualification. New constructor observations should not be spliced into old results and presented as a pass under the unchanged protocol. Passing a revised finite host gate would not imply universal Rust superiority, physical-device qualification, or completion of every project blocker.

## Claims retained as false

- Run 2 passed the complete performance gate: **false**.
- The exact cause of constructor instability has been established: **false**.
- A longer interval has been shown to resolve this run's failure: **false**; no such experiment was performed.
- This review is an independent experiment or a new performance replication: **false**.
- These data justify a general performance advantage over Rust: **false**.
