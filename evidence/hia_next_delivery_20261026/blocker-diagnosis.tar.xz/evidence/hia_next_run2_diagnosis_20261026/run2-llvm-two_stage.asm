
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run2/performance-artifacts/llvm.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001380 <two_stage>:
    1380:	55                   	push   %rbp
    1381:	41 57                	push   %r15
    1383:	41 56                	push   %r14
    1385:	41 54                	push   %r12
    1387:	53                   	push   %rbx
    1388:	49 89 fe             	mov    %rdi,%r14
    138b:	48 85 ff             	test   %rdi,%rdi
    138e:	74 1d                	je     13ad <two_stage+0x2d>
    1390:	78 2b                	js     13bd <two_stage+0x3d>
    1392:	89 f5                	mov    %esi,%ebp
    1394:	bf 01 00 00 00       	mov    $0x1,%edi
    1399:	4c 89 f6             	mov    %r14,%rsi
    139c:	e8 bf fc ff ff       	call   1060 <calloc@plt>
    13a1:	48 85 c0             	test   %rax,%rax
    13a4:	74 2a                	je     13d0 <two_stage+0x50>
    13a6:	48 89 c3             	mov    %rax,%rbx
    13a9:	b0 01                	mov    $0x1,%al
    13ab:	eb 27                	jmp    13d4 <two_stage+0x54>
    13ad:	31 db                	xor    %ebx,%ebx
    13af:	4d 89 f4             	mov    %r14,%r12
    13b2:	49 83 c4 11          	add    $0x11,%r12
    13b6:	73 44                	jae    13fc <two_stage+0x7c>
    13b8:	e9 56 01 00 00       	jmp    1513 <two_stage+0x193>
    13bd:	31 db                	xor    %ebx,%ebx
    13bf:	31 c0                	xor    %eax,%eax
    13c1:	41 bf e9 03 00 00    	mov    $0x3e9,%r15d
    13c7:	a8 01                	test   $0x1,%al
    13c9:	75 19                	jne    13e4 <two_stage+0x64>
    13cb:	e9 2f 01 00 00       	jmp    14ff <two_stage+0x17f>
    13d0:	31 db                	xor    %ebx,%ebx
    13d2:	31 c0                	xor    %eax,%eax
    13d4:	89 ee                	mov    %ebp,%esi
    13d6:	41 bf e9 03 00 00    	mov    $0x3e9,%r15d
    13dc:	a8 01                	test   $0x1,%al
    13de:	0f 84 1b 01 00 00    	je     14ff <two_stage+0x17f>
    13e4:	48 89 df             	mov    %rbx,%rdi
    13e7:	4c 89 f2             	mov    %r14,%rdx
    13ea:	e8 61 fc ff ff       	call   1050 <memset@plt>
    13ef:	4d 89 f4             	mov    %r14,%r12
    13f2:	49 83 c4 11          	add    $0x11,%r12
    13f6:	0f 82 17 01 00 00    	jb     1513 <two_stage+0x193>
    13fc:	78 19                	js     1417 <two_stage+0x97>
    13fe:	bf 01 00 00 00       	mov    $0x1,%edi
    1403:	4c 89 e6             	mov    %r12,%rsi
    1406:	e8 55 fc ff ff       	call   1060 <calloc@plt>
    140b:	48 85 c0             	test   %rax,%rax
    140e:	74 07                	je     1417 <two_stage+0x97>
    1410:	48 89 c7             	mov    %rax,%rdi
    1413:	b1 01                	mov    $0x1,%cl
    1415:	eb 04                	jmp    141b <two_stage+0x9b>
    1417:	31 ff                	xor    %edi,%edi
    1419:	31 c9                	xor    %ecx,%ecx
    141b:	31 c0                	xor    %eax,%eax
    141d:	41 bf e9 03 00 00    	mov    $0x3e9,%r15d
    1423:	f6 c1 01             	test   $0x1,%cl
    1426:	49 0f 45 c4          	cmovne %r12,%rax
    142a:	0f 84 ca 00 00 00    	je     14fa <two_stage+0x17a>
    1430:	4d 85 f6             	test   %r14,%r14
    1433:	0f 84 8e 00 00 00    	je     14c7 <two_stage+0x147>
    1439:	49 8d 4e ff          	lea    -0x1(%r14),%rcx
    143d:	48 39 c8             	cmp    %rcx,%rax
    1440:	48 0f 42 c8          	cmovb  %rax,%rcx
    1444:	48 ff c1             	inc    %rcx
    1447:	31 d2                	xor    %edx,%edx
    1449:	48 83 f9 21          	cmp    $0x21,%rcx
    144d:	72 61                	jb     14b0 <two_stage+0x130>
    144f:	48 89 fe             	mov    %rdi,%rsi
    1452:	48 29 de             	sub    %rbx,%rsi
    1455:	48 83 fe 1f          	cmp    $0x1f,%rsi
    1459:	76 55                	jbe    14b0 <two_stage+0x130>
    145b:	89 ca                	mov    %ecx,%edx
    145d:	83 e2 1f             	and    $0x1f,%edx
    1460:	be 20 00 00 00       	mov    $0x20,%esi
    1465:	48 0f 45 f2          	cmovne %rdx,%rsi
    1469:	48 29 f1             	sub    %rsi,%rcx
    146c:	31 d2                	xor    %edx,%edx
    146e:	0f 28 05 fb 0b 00 00 	movaps 0xbfb(%rip),%xmm0        # 2070 <_fini+0xaa0>
    1475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    147c:	00 00 00 00 
    1480:	0f 10 0c 13          	movups (%rbx,%rdx,1),%xmm1
    1484:	0f 10 54 13 10       	movups 0x10(%rbx,%rdx,1),%xmm2
    1489:	0f 57 c8             	xorps  %xmm0,%xmm1
    148c:	0f 57 d0             	xorps  %xmm0,%xmm2
    148f:	0f 11 0c 17          	movups %xmm1,(%rdi,%rdx,1)
    1493:	0f 11 54 17 10       	movups %xmm2,0x10(%rdi,%rdx,1)
    1498:	48 83 c2 20          	add    $0x20,%rdx
    149c:	48 39 d1             	cmp    %rdx,%rcx
    149f:	75 df                	jne    1480 <two_stage+0x100>
    14a1:	48 89 ca             	mov    %rcx,%rdx
    14a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    14ab:	00 00 00 00 00 
    14b0:	48 39 d0             	cmp    %rdx,%rax
    14b3:	74 5e                	je     1513 <two_stage+0x193>
    14b5:	0f b6 0c 13          	movzbl (%rbx,%rdx,1),%ecx
    14b9:	80 f1 5a             	xor    $0x5a,%cl
    14bc:	88 0c 17             	mov    %cl,(%rdi,%rdx,1)
    14bf:	48 ff c2             	inc    %rdx
    14c2:	49 39 d6             	cmp    %rdx,%r14
    14c5:	75 e9                	jne    14b0 <two_stage+0x130>
    14c7:	48 85 c0             	test   %rax,%rax
    14ca:	74 2b                	je     14f7 <two_stage+0x177>
    14cc:	31 c9                	xor    %ecx,%ecx
    14ce:	45 31 ff             	xor    %r15d,%r15d
    14d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    14d8:	0f 1f 84 00 00 00 00 
    14df:	00 
    14e0:	4c 89 fa             	mov    %r15,%rdx
    14e3:	44 0f b6 3c 0f       	movzbl (%rdi,%rcx,1),%r15d
    14e8:	49 01 d7             	add    %rdx,%r15
    14eb:	72 26                	jb     1513 <two_stage+0x193>
    14ed:	48 ff c1             	inc    %rcx
    14f0:	48 39 c8             	cmp    %rcx,%rax
    14f3:	75 eb                	jne    14e0 <two_stage+0x160>
    14f5:	eb 03                	jmp    14fa <two_stage+0x17a>
    14f7:	45 31 ff             	xor    %r15d,%r15d
    14fa:	e8 31 fb ff ff       	call   1030 <free@plt>
    14ff:	48 89 df             	mov    %rbx,%rdi
    1502:	e8 29 fb ff ff       	call   1030 <free@plt>
    1507:	4c 89 f8             	mov    %r15,%rax
    150a:	5b                   	pop    %rbx
    150b:	41 5c                	pop    %r12
    150d:	41 5e                	pop    %r14
    150f:	41 5f                	pop    %r15
    1511:	5d                   	pop    %rbp
    1512:	c3                   	ret
    1513:	e8 28 fb ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
