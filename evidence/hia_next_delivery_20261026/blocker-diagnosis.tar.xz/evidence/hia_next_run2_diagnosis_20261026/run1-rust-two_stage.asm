
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012cc0 <two_stage>:
   12cc0:	55                   	push   %rbp
   12cc1:	41 57                	push   %r15
   12cc3:	41 56                	push   %r14
   12cc5:	41 55                	push   %r13
   12cc7:	41 54                	push   %r12
   12cc9:	53                   	push   %rbx
   12cca:	48 83 ec 38          	sub    $0x38,%rsp
   12cce:	48 89 fb             	mov    %rdi,%rbx
   12cd1:	48 85 ff             	test   %rdi,%rdi
   12cd4:	74 79                	je     12d4f <two_stage+0x8f>
   12cd6:	41 bd e9 03 00 00    	mov    $0x3e9,%r13d
   12cdc:	0f 88 bf 00 00 00    	js     12da1 <two_stage+0xe1>
   12ce2:	89 f5                	mov    %esi,%ebp
   12ce4:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12ceb:	00 00 
   12ced:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12cf2:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12cf7:	be 01 00 00 00       	mov    $0x1,%esi
   12cfc:	48 89 da             	mov    %rbx,%rdx
   12cff:	e8 8c fc ff ff       	call   12990 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12d04:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
   12d09:	0f 84 92 00 00 00    	je     12da1 <two_stage+0xe1>
   12d0f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   12d14:	4c 89 f0             	mov    %r14,%rax
   12d17:	48 83 fb 01          	cmp    $0x1,%rbx
   12d1b:	74 16                	je     12d33 <two_stage+0x73>
   12d1d:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
   12d21:	4c 89 f7             	mov    %r14,%rdi
   12d24:	31 f6                	xor    %esi,%esi
   12d26:	ff 15 7c dc 03 00    	call   *0x3dc7c(%rip)        # 509a8 <memset@GLIBC_2.2.5>
   12d2c:	49 8d 04 1e          	lea    (%r14,%rbx,1),%rax
   12d30:	48 ff c8             	dec    %rax
   12d33:	c6 00 00             	movb   $0x0,(%rax)
   12d36:	4c 89 f7             	mov    %r14,%rdi
   12d39:	89 ee                	mov    %ebp,%esi
   12d3b:	48 89 da             	mov    %rbx,%rdx
   12d3e:	ff 15 64 dc 03 00    	call   *0x3dc64(%rip)        # 509a8 <memset@GLIBC_2.2.5>
   12d44:	49 89 df             	mov    %rbx,%r15
   12d47:	49 83 c7 11          	add    $0x11,%r15
   12d4b:	78 38                	js     12d85 <two_stage+0xc5>
   12d4d:	eb 0f                	jmp    12d5e <two_stage+0x9e>
   12d4f:	41 be 01 00 00 00    	mov    $0x1,%r14d
   12d55:	49 89 df             	mov    %rbx,%r15
   12d58:	49 83 c7 11          	add    $0x11,%r15
   12d5c:	78 27                	js     12d85 <two_stage+0xc5>
   12d5e:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12d65:	00 00 
   12d67:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12d6c:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12d71:	be 01 00 00 00       	mov    $0x1,%esi
   12d76:	4c 89 fa             	mov    %r15,%rdx
   12d79:	e8 12 fc ff ff       	call   12990 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12d7e:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
   12d83:	75 2e                	jne    12db3 <two_stage+0xf3>
   12d85:	41 bd e9 03 00 00    	mov    $0x3e9,%r13d
   12d8b:	48 85 db             	test   %rbx,%rbx
   12d8e:	74 11                	je     12da1 <two_stage+0xe1>
   12d90:	ba 01 00 00 00       	mov    $0x1,%edx
   12d95:	4c 89 f7             	mov    %r14,%rdi
   12d98:	48 89 de             	mov    %rbx,%rsi
   12d9b:	ff 15 b7 db 03 00    	call   *0x3dbb7(%rip)        # 50958 <_DYNAMIC+0x1f8>
   12da1:	4c 89 e8             	mov    %r13,%rax
   12da4:	48 83 c4 38          	add    $0x38,%rsp
   12da8:	5b                   	pop    %rbx
   12da9:	41 5c                	pop    %r12
   12dab:	41 5d                	pop    %r13
   12dad:	41 5e                	pop    %r14
   12daf:	41 5f                	pop    %r15
   12db1:	5d                   	pop    %rbp
   12db2:	c3                   	ret
   12db3:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   12db8:	48 8d 53 10          	lea    0x10(%rbx),%rdx
   12dbc:	4c 89 e7             	mov    %r12,%rdi
   12dbf:	31 f6                	xor    %esi,%esi
   12dc1:	ff 15 e1 db 03 00    	call   *0x3dbe1(%rip)        # 509a8 <memset@GLIBC_2.2.5>
   12dc7:	41 c6 44 1c 10 00    	movb   $0x0,0x10(%r12,%rbx,1)
   12dcd:	48 85 db             	test   %rbx,%rbx
   12dd0:	0f 84 93 00 00 00    	je     12e69 <two_stage+0x1a9>
   12dd6:	48 8d 4b ff          	lea    -0x1(%rbx),%rcx
   12dda:	4c 39 f9             	cmp    %r15,%rcx
   12ddd:	49 0f 43 cf          	cmovae %r15,%rcx
   12de1:	31 c0                	xor    %eax,%eax
   12de3:	48 83 f9 20          	cmp    $0x20,%rcx
   12de7:	72 67                	jb     12e50 <two_stage+0x190>
   12de9:	4c 89 e2             	mov    %r12,%rdx
   12dec:	4c 29 f2             	sub    %r14,%rdx
   12def:	48 83 fa 1f          	cmp    $0x1f,%rdx
   12df3:	76 5b                	jbe    12e50 <two_stage+0x190>
   12df5:	48 ff c1             	inc    %rcx
   12df8:	89 c8                	mov    %ecx,%eax
   12dfa:	83 e0 1f             	and    $0x1f,%eax
   12dfd:	ba 20 00 00 00       	mov    $0x20,%edx
   12e02:	48 0f 45 d0          	cmovne %rax,%rdx
   12e06:	48 89 c8             	mov    %rcx,%rax
   12e09:	48 29 d0             	sub    %rdx,%rax
   12e0c:	31 c9                	xor    %ecx,%ecx
   12e0e:	0f 28 05 db 1d ff ff 	movaps -0xe225(%rip),%xmm0        # 4bf0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4ba8>
   12e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   12e1c:	00 00 00 00 
   12e20:	41 0f 10 0c 0e       	movups (%r14,%rcx,1),%xmm1
   12e25:	41 0f 10 54 0e 10    	movups 0x10(%r14,%rcx,1),%xmm2
   12e2b:	0f 57 c8             	xorps  %xmm0,%xmm1
   12e2e:	0f 57 d0             	xorps  %xmm0,%xmm2
   12e31:	41 0f 11 0c 0c       	movups %xmm1,(%r12,%rcx,1)
   12e36:	41 0f 11 54 0c 10    	movups %xmm2,0x10(%r12,%rcx,1)
   12e3c:	48 83 c1 20          	add    $0x20,%rcx
   12e40:	48 39 c8             	cmp    %rcx,%rax
   12e43:	75 db                	jne    12e20 <two_stage+0x160>
   12e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   12e4c:	00 00 00 00 
   12e50:	49 39 c7             	cmp    %rax,%r15
   12e53:	74 6d                	je     12ec2 <two_stage+0x202>
   12e55:	41 0f b6 0c 06       	movzbl (%r14,%rax,1),%ecx
   12e5a:	80 f1 5a             	xor    $0x5a,%cl
   12e5d:	41 88 0c 04          	mov    %cl,(%r12,%rax,1)
   12e61:	48 ff c0             	inc    %rax
   12e64:	48 39 c3             	cmp    %rax,%rbx
   12e67:	75 e7                	jne    12e50 <two_stage+0x190>
   12e69:	48 c7 c0 ef ff ff ff 	mov    $0xffffffffffffffef,%rax
   12e70:	45 31 ed             	xor    %r13d,%r13d
   12e73:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   12e7a:	84 00 00 00 00 00 
   12e80:	4c 89 e9             	mov    %r13,%rcx
   12e83:	45 0f b6 6c 04 11    	movzbl 0x11(%r12,%rax,1),%r13d
   12e89:	49 01 cd             	add    %rcx,%r13
   12e8c:	72 27                	jb     12eb5 <two_stage+0x1f5>
   12e8e:	48 ff c0             	inc    %rax
   12e91:	48 39 c3             	cmp    %rax,%rbx
   12e94:	75 ea                	jne    12e80 <two_stage+0x1c0>
   12e96:	ba 01 00 00 00       	mov    $0x1,%edx
   12e9b:	4c 89 e7             	mov    %r12,%rdi
   12e9e:	4c 89 fe             	mov    %r15,%rsi
   12ea1:	ff 15 b1 da 03 00    	call   *0x3dab1(%rip)        # 50958 <_DYNAMIC+0x1f8>
   12ea7:	48 85 db             	test   %rbx,%rbx
   12eaa:	0f 85 e0 fe ff ff    	jne    12d90 <two_stage+0xd0>
   12eb0:	e9 ec fe ff ff       	jmp    12da1 <two_stage+0xe1>
   12eb5:	48 8d 3d a4 b7 03 00 	lea    0x3b7a4(%rip),%rdi        # 4e660 <__frame_dummy_init_array_entry+0x20>
   12ebc:	ff 15 ee da 03 00    	call   *0x3daee(%rip)        # 509b0 <_DYNAMIC+0x250>
   12ec2:	48 8d 15 af b7 03 00 	lea    0x3b7af(%rip),%rdx        # 4e678 <__frame_dummy_init_array_entry+0x38>
   12ec9:	4c 89 ff             	mov    %r15,%rdi
   12ecc:	4c 89 fe             	mov    %r15,%rsi
   12ecf:	ff 15 e3 da 03 00    	call   *0x3dae3(%rip)        # 509b8 <_DYNAMIC+0x258>

Disassembly of section .plt:
