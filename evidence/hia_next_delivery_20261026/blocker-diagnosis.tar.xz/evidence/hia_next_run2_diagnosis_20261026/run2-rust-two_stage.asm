
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run2/performance-artifacts/rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012c70 <two_stage>:
   12c70:	55                   	push   %rbp
   12c71:	41 57                	push   %r15
   12c73:	41 56                	push   %r14
   12c75:	41 55                	push   %r13
   12c77:	41 54                	push   %r12
   12c79:	53                   	push   %rbx
   12c7a:	48 83 ec 38          	sub    $0x38,%rsp
   12c7e:	48 89 fb             	mov    %rdi,%rbx
   12c81:	48 85 ff             	test   %rdi,%rdi
   12c84:	74 79                	je     12cff <two_stage+0x8f>
   12c86:	41 bd e9 03 00 00    	mov    $0x3e9,%r13d
   12c8c:	0f 88 bf 00 00 00    	js     12d51 <two_stage+0xe1>
   12c92:	89 f5                	mov    %esi,%ebp
   12c94:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12c9b:	00 00 
   12c9d:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12ca2:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12ca7:	be 01 00 00 00       	mov    $0x1,%esi
   12cac:	48 89 da             	mov    %rbx,%rdx
   12caf:	e8 8c fc ff ff       	call   12940 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12cb4:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
   12cb9:	0f 84 92 00 00 00    	je     12d51 <two_stage+0xe1>
   12cbf:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   12cc4:	4c 89 f0             	mov    %r14,%rax
   12cc7:	48 83 fb 01          	cmp    $0x1,%rbx
   12ccb:	74 16                	je     12ce3 <two_stage+0x73>
   12ccd:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
   12cd1:	4c 89 f7             	mov    %r14,%rdi
   12cd4:	31 f6                	xor    %esi,%esi
   12cd6:	ff 15 7c dc 03 00    	call   *0x3dc7c(%rip)        # 50958 <memset@GLIBC_2.2.5>
   12cdc:	49 8d 04 1e          	lea    (%r14,%rbx,1),%rax
   12ce0:	48 ff c8             	dec    %rax
   12ce3:	c6 00 00             	movb   $0x0,(%rax)
   12ce6:	4c 89 f7             	mov    %r14,%rdi
   12ce9:	89 ee                	mov    %ebp,%esi
   12ceb:	48 89 da             	mov    %rbx,%rdx
   12cee:	ff 15 64 dc 03 00    	call   *0x3dc64(%rip)        # 50958 <memset@GLIBC_2.2.5>
   12cf4:	49 89 df             	mov    %rbx,%r15
   12cf7:	49 83 c7 11          	add    $0x11,%r15
   12cfb:	78 38                	js     12d35 <two_stage+0xc5>
   12cfd:	eb 0f                	jmp    12d0e <two_stage+0x9e>
   12cff:	41 be 01 00 00 00    	mov    $0x1,%r14d
   12d05:	49 89 df             	mov    %rbx,%r15
   12d08:	49 83 c7 11          	add    $0x11,%r15
   12d0c:	78 27                	js     12d35 <two_stage+0xc5>
   12d0e:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12d15:	00 00 
   12d17:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12d1c:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12d21:	be 01 00 00 00       	mov    $0x1,%esi
   12d26:	4c 89 fa             	mov    %r15,%rdx
   12d29:	e8 12 fc ff ff       	call   12940 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12d2e:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
   12d33:	75 2e                	jne    12d63 <two_stage+0xf3>
   12d35:	41 bd e9 03 00 00    	mov    $0x3e9,%r13d
   12d3b:	48 85 db             	test   %rbx,%rbx
   12d3e:	74 11                	je     12d51 <two_stage+0xe1>
   12d40:	ba 01 00 00 00       	mov    $0x1,%edx
   12d45:	4c 89 f7             	mov    %r14,%rdi
   12d48:	48 89 de             	mov    %rbx,%rsi
   12d4b:	ff 15 b7 db 03 00    	call   *0x3dbb7(%rip)        # 50908 <_DYNAMIC+0x1f8>
   12d51:	4c 89 e8             	mov    %r13,%rax
   12d54:	48 83 c4 38          	add    $0x38,%rsp
   12d58:	5b                   	pop    %rbx
   12d59:	41 5c                	pop    %r12
   12d5b:	41 5d                	pop    %r13
   12d5d:	41 5e                	pop    %r14
   12d5f:	41 5f                	pop    %r15
   12d61:	5d                   	pop    %rbp
   12d62:	c3                   	ret
   12d63:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   12d68:	48 8d 53 10          	lea    0x10(%rbx),%rdx
   12d6c:	4c 89 e7             	mov    %r12,%rdi
   12d6f:	31 f6                	xor    %esi,%esi
   12d71:	ff 15 e1 db 03 00    	call   *0x3dbe1(%rip)        # 50958 <memset@GLIBC_2.2.5>
   12d77:	41 c6 44 1c 10 00    	movb   $0x0,0x10(%r12,%rbx,1)
   12d7d:	48 85 db             	test   %rbx,%rbx
   12d80:	0f 84 93 00 00 00    	je     12e19 <two_stage+0x1a9>
   12d86:	48 8d 4b ff          	lea    -0x1(%rbx),%rcx
   12d8a:	4c 39 f9             	cmp    %r15,%rcx
   12d8d:	49 0f 43 cf          	cmovae %r15,%rcx
   12d91:	31 c0                	xor    %eax,%eax
   12d93:	48 83 f9 20          	cmp    $0x20,%rcx
   12d97:	72 67                	jb     12e00 <two_stage+0x190>
   12d99:	4c 89 e2             	mov    %r12,%rdx
   12d9c:	4c 29 f2             	sub    %r14,%rdx
   12d9f:	48 83 fa 1f          	cmp    $0x1f,%rdx
   12da3:	76 5b                	jbe    12e00 <two_stage+0x190>
   12da5:	48 ff c1             	inc    %rcx
   12da8:	89 c8                	mov    %ecx,%eax
   12daa:	83 e0 1f             	and    $0x1f,%eax
   12dad:	ba 20 00 00 00       	mov    $0x20,%edx
   12db2:	48 0f 45 d0          	cmovne %rax,%rdx
   12db6:	48 89 c8             	mov    %rcx,%rax
   12db9:	48 29 d0             	sub    %rdx,%rax
   12dbc:	31 c9                	xor    %ecx,%ecx
   12dbe:	0f 28 05 2b 1e ff ff 	movaps -0xe1d5(%rip),%xmm0        # 4bf0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4ba8>
   12dc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   12dcc:	00 00 00 00 
   12dd0:	41 0f 10 0c 0e       	movups (%r14,%rcx,1),%xmm1
   12dd5:	41 0f 10 54 0e 10    	movups 0x10(%r14,%rcx,1),%xmm2
   12ddb:	0f 57 c8             	xorps  %xmm0,%xmm1
   12dde:	0f 57 d0             	xorps  %xmm0,%xmm2
   12de1:	41 0f 11 0c 0c       	movups %xmm1,(%r12,%rcx,1)
   12de6:	41 0f 11 54 0c 10    	movups %xmm2,0x10(%r12,%rcx,1)
   12dec:	48 83 c1 20          	add    $0x20,%rcx
   12df0:	48 39 c8             	cmp    %rcx,%rax
   12df3:	75 db                	jne    12dd0 <two_stage+0x160>
   12df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   12dfc:	00 00 00 00 
   12e00:	49 39 c7             	cmp    %rax,%r15
   12e03:	74 6d                	je     12e72 <two_stage+0x202>
   12e05:	41 0f b6 0c 06       	movzbl (%r14,%rax,1),%ecx
   12e0a:	80 f1 5a             	xor    $0x5a,%cl
   12e0d:	41 88 0c 04          	mov    %cl,(%r12,%rax,1)
   12e11:	48 ff c0             	inc    %rax
   12e14:	48 39 c3             	cmp    %rax,%rbx
   12e17:	75 e7                	jne    12e00 <two_stage+0x190>
   12e19:	48 c7 c0 ef ff ff ff 	mov    $0xffffffffffffffef,%rax
   12e20:	45 31 ed             	xor    %r13d,%r13d
   12e23:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   12e2a:	84 00 00 00 00 00 
   12e30:	4c 89 e9             	mov    %r13,%rcx
   12e33:	45 0f b6 6c 04 11    	movzbl 0x11(%r12,%rax,1),%r13d
   12e39:	49 01 cd             	add    %rcx,%r13
   12e3c:	72 27                	jb     12e65 <two_stage+0x1f5>
   12e3e:	48 ff c0             	inc    %rax
   12e41:	48 39 c3             	cmp    %rax,%rbx
   12e44:	75 ea                	jne    12e30 <two_stage+0x1c0>
   12e46:	ba 01 00 00 00       	mov    $0x1,%edx
   12e4b:	4c 89 e7             	mov    %r12,%rdi
   12e4e:	4c 89 fe             	mov    %r15,%rsi
   12e51:	ff 15 b1 da 03 00    	call   *0x3dab1(%rip)        # 50908 <_DYNAMIC+0x1f8>
   12e57:	48 85 db             	test   %rbx,%rbx
   12e5a:	0f 85 e0 fe ff ff    	jne    12d40 <two_stage+0xd0>
   12e60:	e9 ec fe ff ff       	jmp    12d51 <two_stage+0xe1>
   12e65:	48 8d 3d a4 b7 03 00 	lea    0x3b7a4(%rip),%rdi        # 4e610 <__frame_dummy_init_array_entry+0x20>
   12e6c:	ff 15 ee da 03 00    	call   *0x3daee(%rip)        # 50960 <_DYNAMIC+0x250>
   12e72:	48 8d 15 af b7 03 00 	lea    0x3b7af(%rip),%rdx        # 4e628 <__frame_dummy_init_array_entry+0x38>
   12e79:	4c 89 ff             	mov    %r15,%rdi
   12e7c:	4c 89 fe             	mov    %r15,%rsi
   12e7f:	ff 15 e3 da 03 00    	call   *0x3dae3(%rip)        # 50968 <_DYNAMIC+0x258>

Disassembly of section .plt:
