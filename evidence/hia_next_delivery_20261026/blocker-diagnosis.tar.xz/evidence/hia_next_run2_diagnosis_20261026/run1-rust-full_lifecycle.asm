
/workspace/scratch/06ad8295a712/hepta-unified/evidence/hia_next_20261026_run1/performance-artifacts/rust.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000012a00 <full_lifecycle>:
   12a00:	55                   	push   %rbp
   12a01:	41 57                	push   %r15
   12a03:	41 56                	push   %r14
   12a05:	53                   	push   %rbx
   12a06:	48 83 ec 38          	sub    $0x38,%rsp
   12a0a:	48 85 ff             	test   %rdi,%rdi
   12a0d:	74 72                	je     12a81 <full_lifecycle+0x81>
   12a0f:	41 bf e9 03 00 00    	mov    $0x3e9,%r15d
   12a15:	0f 88 fb 01 00 00    	js     12c16 <full_lifecycle+0x216>
   12a1b:	48 89 fb             	mov    %rdi,%rbx
   12a1e:	89 f5                	mov    %esi,%ebp
   12a20:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   12a27:	00 00 
   12a29:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   12a2e:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
   12a33:	be 01 00 00 00       	mov    $0x1,%esi
   12a38:	48 89 da             	mov    %rbx,%rdx
   12a3b:	e8 50 ff ff ff       	call   12990 <_ZN5alloc7raw_vec11finish_grow17h7bea7c01440f6ee8E>
   12a40:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
   12a45:	0f 84 cb 01 00 00    	je     12c16 <full_lifecycle+0x216>
   12a4b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   12a50:	4c 89 f0             	mov    %r14,%rax
   12a53:	48 83 fb 01          	cmp    $0x1,%rbx
   12a57:	74 16                	je     12a6f <full_lifecycle+0x6f>
   12a59:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
   12a5d:	4c 89 f7             	mov    %r14,%rdi
   12a60:	31 f6                	xor    %esi,%esi
   12a62:	ff 15 40 df 03 00    	call   *0x3df40(%rip)        # 509a8 <memset@GLIBC_2.2.5>
   12a68:	49 8d 04 1e          	lea    (%r14,%rbx,1),%rax
   12a6c:	48 ff c8             	dec    %rax
   12a6f:	c6 00 00             	movb   $0x0,(%rax)
   12a72:	48 83 fb 03          	cmp    $0x3,%rbx
   12a76:	77 11                	ja     12a89 <full_lifecycle+0x89>
   12a78:	31 c0                	xor    %eax,%eax
   12a7a:	89 e9                	mov    %ebp,%ecx
   12a7c:	e9 4b 01 00 00       	jmp    12bcc <full_lifecycle+0x1cc>
   12a81:	45 31 ff             	xor    %r15d,%r15d
   12a84:	e9 8d 01 00 00       	jmp    12c16 <full_lifecycle+0x216>
   12a89:	48 ba f0 ff ff ff ff 	movabs $0x7ffffffffffffff0,%rdx
   12a90:	ff ff 7f 
   12a93:	89 e9                	mov    %ebp,%ecx
   12a95:	66 0f 6e c5          	movd   %ebp,%xmm0
   12a99:	48 83 fb 10          	cmp    $0x10,%rbx
   12a9d:	73 07                	jae    12aa6 <full_lifecycle+0xa6>
   12a9f:	31 c0                	xor    %eax,%eax
   12aa1:	e9 c2 00 00 00       	jmp    12b68 <full_lifecycle+0x168>
   12aa6:	48 89 d8             	mov    %rbx,%rax
   12aa9:	48 21 d0             	and    %rdx,%rax
   12aac:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
   12ab1:	66 0f 6f 15 67 21 ff 	movdqa -0xde99(%rip),%xmm2        # 4c20 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4bd8>
   12ab8:	ff 
   12ab9:	66 0f 6f 1d 6f 21 ff 	movdqa -0xde91(%rip),%xmm3        # 4c30 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4be8>
   12ac0:	ff 
   12ac1:	66 0f 6f 25 87 21 ff 	movdqa -0xde79(%rip),%xmm4        # 4c50 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4c08>
   12ac8:	ff 
   12ac9:	66 0f 6f 2d cf 21 ff 	movdqa -0xde31(%rip),%xmm5        # 4ca0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4c58>
   12ad0:	ff 
   12ad1:	31 f6                	xor    %esi,%esi
   12ad3:	66 0f 6f 35 05 23 ff 	movdqa -0xdcfb(%rip),%xmm6        # 4de0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4d98>
   12ada:	ff 
   12adb:	66 0f 6f 3d ad 22 ff 	movdqa -0xdd53(%rip),%xmm7        # 4d90 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4d48>
   12ae2:	ff 
   12ae3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   12aea:	84 00 00 00 00 00 
   12af0:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
   12af5:	66 44 0f fe c2       	paddd  %xmm2,%xmm8
   12afa:	66 44 0f 6f c9       	movdqa %xmm1,%xmm9
   12aff:	66 44 0f fe cb       	paddd  %xmm3,%xmm9
   12b04:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
   12b09:	66 44 0f fe d4       	paddd  %xmm4,%xmm10
   12b0e:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
   12b13:	66 44 0f fe dd       	paddd  %xmm5,%xmm11
   12b18:	66 44 0f db de       	pand   %xmm6,%xmm11
   12b1d:	66 44 0f db d6       	pand   %xmm6,%xmm10
   12b22:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
   12b27:	66 44 0f db ce       	pand   %xmm6,%xmm9
   12b2c:	66 44 0f db c6       	pand   %xmm6,%xmm8
   12b31:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
   12b36:	66 45 0f 67 d9       	packuswb %xmm9,%xmm11
   12b3b:	f3 45 0f 7f 1c 36    	movdqu %xmm11,(%r14,%rsi,1)
   12b41:	48 83 c6 10          	add    $0x10,%rsi
   12b45:	66 0f fe ef          	paddd  %xmm7,%xmm5
   12b49:	66 0f fe e7          	paddd  %xmm7,%xmm4
   12b4d:	66 0f fe df          	paddd  %xmm7,%xmm3
   12b51:	66 0f fe d7          	paddd  %xmm7,%xmm2
   12b55:	48 39 f0             	cmp    %rsi,%rax
   12b58:	75 96                	jne    12af0 <full_lifecycle+0xf0>
   12b5a:	48 39 c3             	cmp    %rax,%rbx
   12b5d:	0f 84 80 00 00 00    	je     12be3 <full_lifecycle+0x1e3>
   12b63:	f6 c3 0c             	test   $0xc,%bl
   12b66:	74 64                	je     12bcc <full_lifecycle+0x1cc>
   12b68:	48 89 c6             	mov    %rax,%rsi
   12b6b:	48 83 c2 0c          	add    $0xc,%rdx
   12b6f:	48 89 d0             	mov    %rdx,%rax
   12b72:	66 0f 6e ce          	movd   %esi,%xmm1
   12b76:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   12b7b:	66 0f eb 0d 1d 21 ff 	por    -0xdee3(%rip),%xmm1        # 4ca0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4c58>
   12b82:	ff 
   12b83:	48 21 d8             	and    %rbx,%rax
   12b86:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
   12b8b:	66 0f 6f 15 4d 22 ff 	movdqa -0xddb3(%rip),%xmm2        # 4de0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4d98>
   12b92:	ff 
   12b93:	66 0f 6f 1d 15 21 ff 	movdqa -0xdeeb(%rip),%xmm3        # 4cb0 <_ZN3std6thread7current7CURRENT17h069380daa18362bdE+0x4c68>
   12b9a:	ff 
   12b9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   12ba0:	66 0f 6f e0          	movdqa %xmm0,%xmm4
   12ba4:	66 0f fe e1          	paddd  %xmm1,%xmm4
   12ba8:	66 0f db e2          	pand   %xmm2,%xmm4
   12bac:	66 0f 67 e4          	packuswb %xmm4,%xmm4
   12bb0:	66 0f 67 e4          	packuswb %xmm4,%xmm4
   12bb4:	66 41 0f 7e 24 36    	movd   %xmm4,(%r14,%rsi,1)
   12bba:	48 83 c6 04          	add    $0x4,%rsi
   12bbe:	66 0f fe cb          	paddd  %xmm3,%xmm1
   12bc2:	48 39 f0             	cmp    %rsi,%rax
   12bc5:	75 d9                	jne    12ba0 <full_lifecycle+0x1a0>
   12bc7:	48 39 c3             	cmp    %rax,%rbx
   12bca:	74 17                	je     12be3 <full_lifecycle+0x1e3>
   12bcc:	89 c9                	mov    %ecx,%ecx
   12bce:	66 90                	xchg   %ax,%ax
   12bd0:	8d 14 01             	lea    (%rcx,%rax,1),%edx
   12bd3:	41 88 14 06          	mov    %dl,(%r14,%rax,1)
   12bd7:	48 8d 50 01          	lea    0x1(%rax),%rdx
   12bdb:	48 89 d0             	mov    %rdx,%rax
   12bde:	48 39 d3             	cmp    %rdx,%rbx
   12be1:	75 ed                	jne    12bd0 <full_lifecycle+0x1d0>
   12be3:	31 c0                	xor    %eax,%eax
   12be5:	45 31 ff             	xor    %r15d,%r15d
   12be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   12bef:	00 
   12bf0:	4c 89 f9             	mov    %r15,%rcx
   12bf3:	45 0f b6 3c 06       	movzbl (%r14,%rax,1),%r15d
   12bf8:	49 01 cf             	add    %rcx,%r15
   12bfb:	72 27                	jb     12c24 <full_lifecycle+0x224>
   12bfd:	48 ff c0             	inc    %rax
   12c00:	48 39 c3             	cmp    %rax,%rbx
   12c03:	75 eb                	jne    12bf0 <full_lifecycle+0x1f0>
   12c05:	ba 01 00 00 00       	mov    $0x1,%edx
   12c0a:	4c 89 f7             	mov    %r14,%rdi
   12c0d:	48 89 de             	mov    %rbx,%rsi
   12c10:	ff 15 42 dd 03 00    	call   *0x3dd42(%rip)        # 50958 <_DYNAMIC+0x1f8>
   12c16:	4c 89 f8             	mov    %r15,%rax
   12c19:	48 83 c4 38          	add    $0x38,%rsp
   12c1d:	5b                   	pop    %rbx
   12c1e:	41 5e                	pop    %r14
   12c20:	41 5f                	pop    %r15
   12c22:	5d                   	pop    %rbp
   12c23:	c3                   	ret
   12c24:	48 8d 3d 1d ba 03 00 	lea    0x3ba1d(%rip),%rdi        # 4e648 <__frame_dummy_init_array_entry+0x8>
   12c2b:	ff 15 7f dd 03 00    	call   *0x3dd7f(%rip)        # 509b0 <_DYNAMIC+0x250>

Disassembly of section .plt:
