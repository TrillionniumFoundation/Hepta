#![forbid(unsafe_code)]
fn repair(i:u32,n:u32)->u32{if i < n{1}else{0}}
fn main(){let values=[repair(0u32,0u32),repair(0u32,1u32),repair(1u32,1u32),repair(2u32,1u32),repair(17u32,18u32),repair(4294967295u32,4294967295u32)];println!("{:?}",values);}
