#![forbid(unsafe_code)]
fn repair(n:u32)->u32{let mut i=0u32;let mut sum=0u32;while i<n{sum=sum.wrapping_add(1);i=i.wrapping_add(1);}sum}
fn main(){let values=[repair(0u32),repair(1u32),repair(2u32),repair(3u32),repair(7u32),repair(19u32)];println!("{:?}",values);}
