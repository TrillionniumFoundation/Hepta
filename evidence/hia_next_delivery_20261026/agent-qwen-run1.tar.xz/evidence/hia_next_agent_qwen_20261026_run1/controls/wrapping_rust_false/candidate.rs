#![forbid(unsafe_code)]
fn repair(x:u32)->u32{x+1}
fn main(){let values=[repair(0u32),repair(1u32),repair(12345u32),repair(4294967294u32),repair(4294967295u32)];println!("{:?}",values);}
