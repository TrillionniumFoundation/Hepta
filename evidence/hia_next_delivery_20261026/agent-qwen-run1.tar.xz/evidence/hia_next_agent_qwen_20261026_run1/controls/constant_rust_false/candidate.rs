#![forbid(unsafe_code)]
fn repair(x:u32)->u32{x.wrapping_add(6)}
fn main(){let values=[repair(0u32),repair(1u32),repair(37u32),repair(4294967290u32),repair(4294967295u32)];println!("{:?}",values);}
