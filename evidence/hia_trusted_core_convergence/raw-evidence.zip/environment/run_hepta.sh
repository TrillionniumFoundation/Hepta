#!/bin/bash
set -euo pipefail
export PATH="/workspace/scratch/b574d7352fca/toolchains/llvm20/usr/lib/llvm-20/bin:/workspace/scratch/b574d7352fca/toolchains/rust-1.90.0/bin:$PATH"
export LD_LIBRARY_PATH="/workspace/scratch/b574d7352fca/toolchains/llvm20/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export CLANG="/workspace/scratch/b574d7352fca/toolchains/llvm20/usr/lib/llvm-20/bin/clang"
export HEPTA_CLANG="$CLANG"
export HEPTA_TEST_CLANG="$CLANG"
export CLANGXX="/workspace/scratch/b574d7352fca/toolchains/llvm20/usr/lib/llvm-20/bin/clang++"
export RUSTC="/workspace/scratch/b574d7352fca/toolchains/rust-1.90.0/bin/rustc"
export CARGO="/workspace/scratch/b574d7352fca/toolchains/rust-1.90.0/bin/cargo"
export CARGO_HOME="/workspace/scratch/b574d7352fca/cargo-home"
export CARGO_TARGET_DIR="/workspace/scratch/b574d7352fca/rust-core-target"
export PYTHONDONTWRITEBYTECODE=1
cd "/workspace/scratch/b574d7352fca/Hepta"
exec "$@"
