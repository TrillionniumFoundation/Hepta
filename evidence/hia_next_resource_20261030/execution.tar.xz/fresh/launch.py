#!/usr/bin/env python3
"""Run the frozen focused corpus once; retain failures, not new holdouts."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PLAN_PATH = HERE / "PLAN.json"


def wire(value):
    return json.dumps(value, sort_keys=True, indent=2, allow_nan=False).encode() + b"\n"


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path), "resolved_path": str(path.resolve(strict=True)),
            "bytes": len(data), "sha256": sha256(data).hexdigest()}


def write(path, value):
    temporary = path.with_name(path.name + ".pending")
    temporary.write_bytes(wire(value))
    temporary.replace(path)


def fail_unless(condition, message):
    if not condition:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def command(argv, directory, env, cwd, timeout, row):
    """Each command has an actual terminal receipt even when cleanup fails."""
    started = time.monotonic_ns()
    row.update({"argv": argv, "cwd": str(cwd), "timeout_seconds": timeout,
           "started_utc": utc(), "status": "starting", "cleanup_errors": [], "persistence_errors": [],
           "cleanup_scope": "reap the direct leader; on timeout/interruption signal its process group and wait for that leader",
           "all_descendant_completion_proved": False,
           "escaped_descendant_or_post_interrupt_work_ns": None})
    process = None
    created = False
    try:
        directory.mkdir(exist_ok=False)
        created = True
        write(directory / "execution.json", row)
        with (directory / "stdout").open("xb") as stdout, (directory / "stderr").open("xb") as stderr:
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout,
                                       stderr=stderr, start_new_session=True)
            row.update(pid=process.pid, status="running")
            write(directory / "execution.json", row)
            row["returncode"] = process.wait(timeout=timeout)
            row["status"] = "completed"
    except subprocess.TimeoutExpired as error:
        row.update(status="timed_out", error=str(error))
    except BaseException as error:
        row.update(status="failed", error=type(error).__name__ + ": " + str(error),
                   traceback=traceback.format_exc())
    finally:
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except BaseException as error:
                row["cleanup_errors"].append(type(error).__name__ + ": " + str(error))
            try:
                row["returncode"] = process.wait(timeout=10)
            except BaseException as error:
                row["cleanup_errors"].append(type(error).__name__ + ": " + str(error))
        for stream in ("stdout", "stderr"):
            try:
                if (directory / stream).exists():
                    row[stream] = identity(directory / stream)
            except BaseException as error:
                row["cleanup_errors"].append(stream + ": " + type(error).__name__ + ": " + str(error))
        row["command_wall_ns"] = time.monotonic_ns() - started
        row["finished_utc"] = utc()
        row["wall_scope"] = "includes initial receipt, process wait, cleanup and log hashing; excludes this terminal receipt write"
        if created:
            try:
                write(directory / "execution.json", row)
            except BaseException as error:
                row["persistence_errors"].append({"where": "terminal_execution_receipt",
                    "error": type(error).__name__ + ": " + str(error)})
    return row


def main():
    fail_unless(len(sys.argv) == 1, "No mutable runtime options; execute the frozen PLAN exactly")
    # The new output directory is one attempt. An existing attempt is never reused.
    output = HERE / "run"
    output.mkdir(exist_ok=False)
    started = time.monotonic_ns()
    receipt = {"schema": "hepta.rust-finite-heap.integrated-focused-attempt.v1",
               "status": "started", "started_utc": utc(), "stages": [], "errors": [],
               "new_holdout": False, "historical_results_relabelled_as_current": False,
               "whole_language_soundness_proved": False, "native_authority_granted": False,
               "full_human_development_review_cost": None,
               "full_human_development_review_cost_status": "unknown, not zero"}
    plan = None
    source_state = None
    before = None
    try:
        raw_plan = PLAN_PATH.read_bytes()
        plan = json.loads(raw_plan)
        receipt["expected_source_head"] = plan["source_head"]
        receipt["expected_source_tree"] = plan["source_tree"]
        receipt["historical_source_references"] = plan["historical_source_references"]
        receipt["plan"] = identity(PLAN_PATH)
        receipt["launcher"] = identity(Path(__file__))
        write(output / "RECEIPT.json", receipt)
        fail_unless(receipt["launcher"]["sha256"] == plan["launcher_sha256"], "launcher differs from frozen plan")
        fail_unless([(stage["id"], stage["kind"]) for stage in plan["stages"]] ==
                    [("rust", "cargo"), ("focused", "unittest")], "exact ordered Rust and focused stages required")
        repo = Path(plan["repository"])
        env = dict(os.environ)
        for name in list(env):
            if (name.startswith("CARGO_") or name.startswith("RUST") or
                    name in {"CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "LIBRARY_PATH",
                             "LD_PRELOAD", "LD_AUDIT", "PYTHONPATH", "PYTHONHOME"}):
                env.pop(name)
        env.update(plan["environment"])
        receipt["selected_environment"] = dict(plan["environment"])
        # Use the committed qualifier's exact raw-tree/blob/mode source check.
        fail_unless(identity(repo / "tools/qualify_hia_integrated.py")["sha256"] ==
                    plan["source_identity_checker_sha256"], "source checker differs from frozen plan")
        sys.path.insert(0, str(repo))
        from tools.qualify_hia_integrated import _source_state
        from tools.qualify_hia_unified import cargo_test_outcome, unittest_outcome
        source_state = _source_state
        before = source_state()
        write(output / "source-before.json", before)
        fail_unless(before["head"] == plan["source_head"] and before["tree"] == plan["source_tree"]
                    and not before["status"], "exact clean frozen source required")
        receipt["tools_before"] = {name: identity(path) for name, path in plan["tools"].items()}
        receipt["binary_before"] = (identity(plan["binary_path"])
                                    if Path(plan["binary_path"]).is_file() else None)
        receipt["versions"] = []
        for name, argv in plan["version_commands"].items():
            row = {"id": "version-" + name, "status": "registered"}
            receipt["versions"].append(row)
            write(output / "RECEIPT.json", receipt)
            command(argv, output / ("version-" + name), env, repo, 30, row)
            fail_unless(row.get("returncode") == 0 and row["status"] == "completed"
                        and not row["cleanup_errors"] and not row["persistence_errors"], "tool version probe failed: " + name)
        for stage in plan["stages"]:
            env_stage = dict(env)
            if stage["kind"] == "unittest":
                env_stage["HEPTA_RUST_FINITE_HEAP_EVIDENCE_DIR"] = str(output / stage["id"] / "raw")
            row = {"id": stage["id"], "status": "registered"}
            receipt["stages"].append(row)
            write(output / "RECEIPT.json", receipt)
            command(stage["argv"], output / stage["id"], env_stage, repo, stage["timeout_seconds"], row)
            stdout = (output / stage["id"] / "stdout").read_text()
            stderr = (output / stage["id"] / "stderr").read_text()
            row["outcome"] = (cargo_test_outcome(stdout, row.get("returncode")) if stage["kind"] == "cargo"
                              else unittest_outcome(stderr, row.get("returncode")))
            after_stage = source_state()
            write(output / stage["id"] / "source-after.json", after_stage)
            row["source_unchanged"] = before == after_stage
            row["binary_after"] = identity(plan["binary_path"])
            write(output / stage["id"] / "execution.json", row)
            fail_unless(row["status"] == "completed" and not row["cleanup_errors"] and not row["persistence_errors"] and row["outcome"]["passed"]
                        and row["source_unchanged"], "stage failed: " + stage["id"])
            if stage["kind"] == "unittest":
                fail_unless(row["outcome"]["tests_run"] == len(plan["focused_test_methods"]),
                            "focused method denominator differs from frozen source inventory")
                observed_methods = re.findall(r"(?m)^test\w+ \((tests\.[^\s)]+)\) \.\.\. ok$", stderr)
                fail_unless(sorted(observed_methods) == plan["focused_test_methods"],
                            "actual successful method IDs differ from the frozen source inventory")
                raw = json.loads((output / stage["id"] / "raw/actual.json").read_bytes())
                fail_unless(raw["executable_sha256"] == row["binary_after"]["sha256"],
                            "actual raw evidence binary differs from resulting artifact")
                receipt["finite_heap_observed_counts"] = {
                    "actual_direct_rust_processes": len(raw["processes"]),
                    "matched_bound_and_machine_observations": len(raw["observations"]),
                    "raw_refusal_controls": len(raw["refusals"]),
                    "isolated_python_child_processes": len(raw["isolated_child_processes"]),
                    "overlap": "observations and refusals are subsets of direct processes; do not add these counts"}
        receipt["status"] = "completed"
    except BaseException as error:
        receipt["status"] = "failed"
        receipt["errors"].append({"where": "main", "error": type(error).__name__ + ": " + str(error),
                                  "traceback": traceback.format_exc()})
    finally:
        # Failure in one postflight step must not suppress the other identities or cost.
        checks = {}
        if plan is not None:
            checks["tools_after"] = lambda: {name: identity(path) for name, path in plan["tools"].items()}
            checks["plan_after"] = lambda: identity(PLAN_PATH)
            checks["launcher_after"] = lambda: identity(Path(__file__))
        if source_state is not None:
            checks["source_after"] = source_state
        for name, action in checks.items():
            try:
                value = action()
                if name == "source_after":
                    write(output / "source-after.json", value)
                    receipt["source_unchanged"] = before is not None and before == value
                else:
                    receipt[name] = value
            except BaseException as error:
                receipt["errors"].append({"where": name, "error": type(error).__name__ + ": " + str(error)})
        receipt["tools_unchanged"] = ("tools_before" in receipt and
                                      receipt.get("tools_after") == receipt["tools_before"])
        receipt["plan_unchanged"] = "plan" in receipt and receipt.get("plan_after") == receipt["plan"]
        receipt["launcher_unchanged"] = "launcher" in receipt and receipt.get("launcher_after") == receipt["launcher"]
        try:
            fail_unless(not any(p.is_symlink() for p in output.rglob("*")), "retained output contains a symlink")
            receipt["retained_files"] = {str(p.relative_to(output)): identity(p)
                for p in sorted(output.rglob("*")) if p.is_file() and p != output / "RECEIPT.json"}
        except BaseException as error:
            receipt["errors"].append({"where": "retained_files", "error": type(error).__name__ + ": " + str(error)})
        if (receipt["errors"] or not receipt.get("source_unchanged") or not receipt["tools_unchanged"]
                or not receipt["plan_unchanged"] or not receipt["launcher_unchanged"]):
            receipt["status"] = "failed"
        receipt["outer_wall_ns"] = time.monotonic_ns() - started
        receipt["outer_wall_scope"] = "includes source/tool preflight, all recorded versions/stages, failures, postflight and retained-file hashing; excludes final RECEIPT serialization and shell/tool overhead"
        receipt["nested_cost_policy"] = "stage/build/test/individual-process times are nested inside outer wall; do not sum them into outer wall"
        receipt["finished_utc"] = utc()
        try:
            write(output / "RECEIPT.json", receipt)
        except BaseException as error:
            receipt["status"] = "failed"
            receipt["errors"].append({"where": "terminal_receipt", "error": type(error).__name__ + ": " + str(error)})
            receipt["wall_ns_through_failed_terminal_write"] = time.monotonic_ns() - started
            print(json.dumps({"terminal_receipt_write_failed": receipt}, sort_keys=True), file=sys.stderr)
        print(json.dumps({key: receipt.get(key) for key in ("status", "source_unchanged", "tools_unchanged", "outer_wall_ns", "finite_heap_observed_counts")}, sort_keys=True))
    return 0 if receipt["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
