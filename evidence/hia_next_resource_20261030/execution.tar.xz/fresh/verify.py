#!/usr/bin/env python3
"""Offline byte/count/observation consistency only; never run target code."""
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
import time


def require(condition, message):
    if not condition:
        raise ValueError(message)


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def matches(path, identity):
    data = path.read_bytes()
    require(len(data) == identity["bytes"] and sha256(data).hexdigest() == identity["sha256"],
            "retained bytes differ: " + str(path))
    return data


def verify(base):
    started = time.monotonic_ns()
    base = Path(base)
    run = base / "run"
    receipt = json.loads((run / "RECEIPT.json").read_bytes())
    require(receipt["schema"] == "hepta.rust-finite-heap.integrated-focused-attempt.v1"
            and receipt["status"] == "completed", "completed attempt required")
    plan = json.loads(matches(base / "PLAN.json", receipt["plan"]))
    matches(base / "launch.py", receipt["launcher"])
    require(plan["launcher_sha256"] == receipt["launcher"]["sha256"], "launcher plan mismatch")
    require(receipt["new_holdout"] is False and plan["new_holdout"] is False,
            "same-corpus execution cannot become new holdout")
    require(receipt["errors"] == [], "terminal errors retained")
    require(all(receipt[k] is True for k in ("source_unchanged", "tools_unchanged", "plan_unchanged", "launcher_unchanged")),
            "identity changed")
    files = receipt["retained_files"]
    for name, identity in files.items():
        path = Path(name)
        require(not path.is_absolute() and ".." not in path.parts and not (run / path).is_symlink(),
                "unsafe retained path")
        matches(run / path, identity)
    actual_files = {str(p.relative_to(run)) for p in run.rglob("*") if p.is_file() and p != run / "RECEIPT.json"}
    require(actual_files == set(files), "retained file inventory differs")
    before = json.loads((run / "source-before.json").read_bytes())
    after = json.loads((run / "source-after.json").read_bytes())
    require(before == after and before["head"] == plan["source_head"] and before["tree"] == plan["source_tree"]
            and before["status"] == "", "recorded exact-source binding differs")
    require(receipt["tools_before"] == receipt["tools_after"], "recorded tool identities differ")
    require([r["id"] for r in receipt["stages"]] == [s["id"] for s in plan["stages"]] == ["rust", "focused"],
            "ordered stage inventory differs")
    for stage, planned in zip(receipt["stages"], plan["stages"]):
        require(stage["argv"] == planned["argv"] and stage["returncode"] == 0
                and stage["status"] == "completed" and stage["cleanup_errors"] == []
                and stage["persistence_errors"] == [] and stage["outcome"]["passed"] is True,
                "stage did not pass completely")
        require(stage == json.loads((run / stage["id"] / "execution.json").read_bytes()),
                "outer and stage receipt differ")
        require(before == json.loads((run / stage["id"] / "source-after.json").read_bytes()),
                "stage source changed")
    rust, focused = receipt["stages"]
    rust_log = (run / "rust/stdout").read_text()
    require(sum(map(int, re.findall(r"test result: ok\. (\d+) passed", rust_log))) == rust["outcome"]["tests_run"],
            "Rust actual footer denominator differs")
    require(all(rust["outcome"][k] == 0 for k in ("failures", "filtered_out", "skipped")), "Rust exclusions changed")
    stderr = (run / "focused/stderr").read_text()
    methods = sorted(re.findall(r"(?m)^test\w+ \((tests\.[^\s)]+)\) \.\.\. ok$", stderr))
    require(methods == plan["focused_test_methods"] and len(methods) == focused["outcome"]["tests_run"],
            "focused actual method set differs")
    require(re.search(r"Ran " + str(len(methods)) + r" tests in [\d.]+s\n\nOK\s*$", stderr), "focused footer differs")
    raw = json.loads((run / "focused/raw/actual.json").read_bytes())
    binary = focused["binary_after"]
    require(raw["executable_sha256"] == binary["sha256"] == rust["binary_after"]["sha256"], "binary binding differs")
    require(raw["build"]["returncode"] == 0, "actual Cargo build failed")
    require(raw["claims"]["positive_native_responses_are_actual"] is True
            and raw["claims"]["new_holdout"] is False, "raw corpus scope differs")
    responses = set()
    processes = {wire(p) for p in raw["processes"]}
    for process in raw["processes"]:
        require(process["executable_sha256"] == binary["sha256"], "process binary differs")
        payload = raw["programs"][process["input_sha256"]].encode()
        require(sha256(payload).hexdigest() == process["input_sha256"], "actual process input differs")
        require(type(process["outer_wall_ns"]) is int and process["outer_wall_ns"] > 0, "process cost omitted")
        if process["returncode"] == 0:
            require(process["stderr"] == "", "successful process has diagnostics")
            responses.add(wire(json.loads(process["stdout"])))
    for observation in raw["observations"]:
        report = observation["rust_report"]
        require(observation["matched"] is True and wire(report) in responses, "observation lacks actual producer response")
        require(report["heap_bound"]["peak_bound_bytes"] == observation["python_bound"]["peak_bound_bytes"],
                "independent bound differs")
        actual, oracle = report["runtime"]["execution"], observation["python_execution"]
        require(all(wire(actual[k]) == wire(oracle[k]) for k in ("status", "steps", "resources")),
                "exact stopped runtime observation differs")
        require(wire(actual["values"]) == wire(oracle["values"]) if actual["status"] == "returned"
                else actual["error"]["code"] == oracle["error"]["code"], "values or trap code differ")
        require(actual["resources"]["peak_bytes"] <= report["heap_bound"]["peak_bound_bytes"], "observed payload exceeds bound")
    for refused in raw["refusals"]:
        require(wire(refused) in processes and refused["returncode"] == 1 and refused["stdout"] == ""
                and refused["stderr"].startswith("E_HIA_"), "refusal is not a retained actual process")
    counts = receipt["finite_heap_observed_counts"]
    for key, field in (("actual_direct_rust_processes", "processes"),
                       ("matched_bound_and_machine_observations", "observations"),
                       ("raw_refusal_controls", "refusals"),
                       ("isolated_python_child_processes", "isolated_child_processes")):
        require(counts[key] == len(raw[field]), "actual corpus count differs: " + key)
    return {"verified": True, "source_head": before["head"], "source_tree": before["tree"],
            "retained_files_rehashed": len(files), "rust_tests": rust["outcome"]["tests_run"],
            "focused_tests": len(methods), "actual_corpus_counts": counts,
            "binary_sha256": binary["sha256"], "new_holdout": False,
            "recorded_execution_outer_wall_ns": receipt["outer_wall_ns"],
            "verification_wall_ns": time.monotonic_ns() - started,
            "scope": "offline retained-byte, count and observed-comparison consistency; does not execute or admit code, reproduce toolchain builds, or authenticate a hostile producer"}


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent), sort_keys=True))
