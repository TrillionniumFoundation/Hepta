; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1 immarg)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i8 @__hia_fn_0(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2, i64 %p_0_3, i8 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = icmp eq i64 %t1, 0
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %t3 = extractvalue %hia.buffer %p_1_0, 0
  %t4 = extractvalue %hia.buffer %p_1_1, 0
  ret i8 0
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %t1, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_5 = phi i8 [ %p_0_4, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_5, %edge_1 ]
  %t5 = extractvalue %hia.buffer %p_2_0, 0
  %t6 = extractvalue %hia.buffer %p_2_0, 1
  %t7 = icmp ne i64 %t6, 0
  br i1 %t7, label %bulk_nonzero_8, label %bulk_after_8
bulk_nonzero_8:
  call void @llvm.memset.p0.i64(ptr align 1 %t5, i8 11, i64 %t6, i1 false)
  br label %bulk_after_8
bulk_after_8:
  %t9 = extractvalue %hia.buffer %p_2_0, 0
  %t10 = extractvalue %hia.buffer %p_2_0, 1
  %t11 = icmp ule i64 %p_2_3, %t10
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = sub i64 %t10, %p_2_3
  %t14 = icmp ule i64 %p_2_4, %t13
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t17 = icmp ne i64 %p_2_4, 0
  br i1 %t17, label %fill_nonempty_16, label %fill_after_16
fill_nonempty_16:
  %t18 = getelementptr i8, ptr %t9, i64 %p_2_3
  call void @llvm.memset.p0.i64(ptr align 1 %t18, i8 %p_2_5, i64 %p_2_4, i1 false)
  br label %fill_after_16
fill_after_16:
  %t19 = extractvalue %hia.buffer %p_2_0, 0
  %t20 = extractvalue %hia.buffer %p_2_0, 1
  %t21 = icmp ult i64 0, %t20
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  %t23 = icmp ult i64 %p_2_6, %t20
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  %t25 = getelementptr i8, ptr %t19, i64 0
  %t26 = getelementptr i8, ptr %t19, i64 %p_2_6
  %t27 = load i8, ptr %t25, align 1
  %t28 = load i8, ptr %t26, align 1
  store i8 %t28, ptr %t25, align 1
  store i8 %t27, ptr %t26, align 1
  %t29 = extractvalue %hia.buffer %p_2_0, 0
  %t30 = extractvalue %hia.buffer %p_2_0, 1
  %t31 = icmp ule i64 1, %t30
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  %t33 = icmp ule i64 0, %t30
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = sub i64 %t30, 1
  %t36 = sub i64 %t30, 0
  %t37 = icmp ule i64 %p_2_4, %t35
  br i1 %t37, label %ok_38, label %trap_38
trap_38:
  call void @abort()
  unreachable
ok_38:
  %t39 = icmp ule i64 %p_2_4, %t36
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = icmp ne i64 %p_2_4, 0
  br i1 %t41, label %bulk_nonzero_42, label %bulk_after_42
bulk_nonzero_42:
  %t43 = getelementptr i8, ptr %t29, i64 1
  %t44 = getelementptr i8, ptr %t29, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %t43, ptr align 1 %t44, i64 %p_2_4, i1 false)
  br label %bulk_after_42
bulk_after_42:
  %t45 = extractvalue %hia.buffer %p_2_1, 0
  %t46 = extractvalue %hia.buffer %p_2_1, 1
  %t47 = extractvalue %hia.buffer %p_2_0, 0
  %t48 = extractvalue %hia.buffer %p_2_0, 1
  %t49 = icmp ule i64 %p_2_2, %t46
  br i1 %t49, label %ok_50, label %trap_50
trap_50:
  call void @abort()
  unreachable
ok_50:
  %t51 = icmp ule i64 %p_2_2, %t48
  br i1 %t51, label %ok_52, label %trap_52
trap_52:
  call void @abort()
  unreachable
ok_52:
  %t53 = icmp ne i64 %p_2_2, 0
  br i1 %t53, label %bulk_nonzero_54, label %bulk_after_54
bulk_nonzero_54:
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %t45, ptr align 1 %t47, i64 %p_2_2, i1 false)
  br label %bulk_after_54
bulk_after_54:
  %t55 = extractvalue %hia.buffer %p_2_1, 0
  %t56 = extractvalue %hia.buffer %p_2_1, 1
  %t57 = extractvalue %hia.buffer %p_2_0, 0
  %t58 = extractvalue %hia.buffer %p_2_0, 1
  %t59 = icmp ule i64 0, %t56
  br i1 %t59, label %ok_60, label %trap_60
trap_60:
  call void @abort()
  unreachable
ok_60:
  %t61 = icmp ule i64 1, %t58
  br i1 %t61, label %ok_62, label %trap_62
trap_62:
  call void @abort()
  unreachable
ok_62:
  %t63 = sub i64 %t56, 0
  %t64 = sub i64 %t58, 1
  %t65 = icmp ule i64 %p_2_4, %t63
  br i1 %t65, label %ok_66, label %trap_66
trap_66:
  call void @abort()
  unreachable
ok_66:
  %t67 = icmp ule i64 %p_2_4, %t64
  br i1 %t67, label %ok_68, label %trap_68
trap_68:
  call void @abort()
  unreachable
ok_68:
  %t69 = icmp ne i64 %p_2_4, 0
  br i1 %t69, label %bulk_nonzero_70, label %bulk_after_70
bulk_nonzero_70:
  %t71 = getelementptr i8, ptr %t55, i64 0
  %t72 = getelementptr i8, ptr %t57, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %t71, ptr align 1 %t72, i64 %p_2_4, i1 false)
  br label %bulk_after_70
bulk_after_70:
  %t73 = extractvalue %hia.buffer %p_2_1, 0
  %t74 = extractvalue %hia.buffer %p_2_1, 1
  %t75 = icmp ult i64 %p_2_6, %t74
  br i1 %t75, label %ok_76, label %trap_76
trap_76:
  call void @abort()
  unreachable
ok_76:
  %t77 = getelementptr i8, ptr %t73, i64 %p_2_6
  %t78 = load i8, ptr %t77, align 1
  %t79 = extractvalue %hia.buffer %p_2_0, 0
  %t80 = extractvalue %hia.buffer %p_2_1, 0
  ret i8 %t78
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i8 @__hia_fn_1(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, i8 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_1_0, 0
  ret i8 251
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_2_1 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_2 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_3 = phi i64 [ %p_0_2, %edge_0 ]
  %p_2_4 = phi i8 [ %p_0_3, %edge_0 ]
  %p_2_5 = phi i64 [ %p_0_4, %edge_0 ]
  %t7 = call %hia.alloc @__hia_allocate(i64 %p_2_1, i1 true)
  %t8 = extractvalue %hia.alloc %t7, 0
  %t9 = extractvalue %hia.alloc %t7, 1
  %t10 = select i1 %t9, i64 %p_2_1, i64 0
  %t11 = insertvalue %hia.buffer %t8, i64 %t10, 1
  br i1 %t9, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %t11, %edge_3 ]
  %t12 = extractvalue %hia.buffer %p_3_0, 0
  %t13 = extractvalue %hia.buffer %p_3_1, 0
  ret i8 252
b4:
  %p_4_0 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_4_1 = phi %hia.buffer [ %t11, %edge_2 ]
  %p_4_2 = phi i64 [ %p_2_2, %edge_2 ]
  %p_4_3 = phi i64 [ %p_2_3, %edge_2 ]
  %p_4_4 = phi i8 [ %p_2_4, %edge_2 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_2 ]
  %t14 = call i8 @__hia_fn_0(%hia.buffer %p_4_0, %hia.buffer %p_4_1, i64 %p_4_2, i64 %p_4_3, i8 %p_4_4, i64 %p_4_5)
  ret i8 %t14
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b4
edge_3:
  br label %b3
}

define zeroext i8 @aggregate_bulk(i64 %a0, i64 %a1, i64 %a2, i8 zeroext %a3, i64 %a4) {
entry:
  %result = call i8 @__hia_fn_1(i64 %a0, i64 %a1, i64 %a2, i8 %a3, i64 %a4)
  ret i8 %result
}
