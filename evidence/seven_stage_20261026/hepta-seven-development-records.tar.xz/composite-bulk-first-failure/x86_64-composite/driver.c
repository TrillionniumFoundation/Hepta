
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
typedef size_t hepta_size; typedef uint8_t hepta_u8; typedef uint32_t hepta_u32;
typedef uint64_t hepta_u64;
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[64];
static hepta_u32 successful_allocations,releases,outstanding,denied_allocations;
static hepta_u32 failure_countdown,peak_outstanding;
static bool refuse(void) {
    if(failure_countdown && --failure_countdown == 0){denied_allocations++;return true;}return false;
}
static void *remember(void *p) {
    if(!p)return NULL;
    for(size_t i=0;i<64;i++)if(!addresses[i]) {
        addresses[i]=p;successful_allocations++;outstanding++;
        if(outstanding>peak_outstanding)peak_outstanding=outstanding;
        return p;
    }
    exit(89);
}
void *__wrap_malloc(size_t n) {if(refuse())return NULL;return remember(__real_malloc(n));}
void *__wrap_calloc(size_t n,size_t w) {if(refuse())return NULL;return remember(__real_calloc(n,w));}
void __wrap_free(void *p) {
    if(p){size_t i;for(i=0;i<64 && addresses[i]!=p;i++);if(i==64)exit(90);
        addresses[i]=NULL;outstanding--;releases++;}
    __real_free(p);
}
static void write_case(hepta_u32 index,hepta_u32 value){printf("HIA_BULK case %u %u\n",index,value);}
static void write_counters(void){printf("HIA_AARCH64 resources %u %u %u %u\n",
    successful_allocations,releases,outstanding,denied_allocations);}
extern hepta_u8 aggregate_bulk(hepta_size, hepta_size, hepta_size, hepta_u8, hepta_size);
static int smoke(void) {
    failure_countdown = 0;
    hepta_u8 value_0 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)0ULL));
    write_case(0, value_0);
    if (value_0 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_1 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)1ULL));
    write_case(1, value_1);
    if (value_1 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_2 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)2ULL));
    write_case(2, value_2);
    if (value_2 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_3 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)3ULL));
    write_case(3, value_3);
    if (value_3 != ((hepta_u8)77ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_4 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)4ULL));
    write_case(4, value_4);
    if (value_4 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_5 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)0ULL));
    write_case(5, value_5);
    if (value_5 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_6 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)1ULL));
    write_case(6, value_6);
    if (value_6 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_7 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)2ULL));
    write_case(7, value_7);
    if (value_7 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_8 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)3ULL));
    write_case(8, value_8);
    if (value_8 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_9 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)4ULL));
    write_case(9, value_9);
    if (value_9 != ((hepta_u8)255ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_10 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)5ULL));
    write_case(10, value_10);
    if (value_10 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_11 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)6ULL));
    write_case(11, value_11);
    if (value_11 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_12 = aggregate_bulk(((hepta_size)8ULL), ((hepta_size)2ULL), ((hepta_size)4ULL), ((hepta_u8)255ULL), ((hepta_size)7ULL));
    write_case(12, value_12);
    if (value_12 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_13 = aggregate_bulk(((hepta_size)1ULL), ((hepta_size)1ULL), ((hepta_size)0ULL), ((hepta_u8)99ULL), ((hepta_size)0ULL));
    write_case(13, value_13);
    if (value_13 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_14 = aggregate_bulk(((hepta_size)0ULL), ((hepta_size)0ULL), ((hepta_size)0ULL), ((hepta_u8)17ULL), ((hepta_size)0ULL));
    write_case(14, value_14);
    if (value_14 != ((hepta_u8)0ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 0;
    hepta_u8 value_15 = aggregate_bulk(((hepta_size)4096ULL), ((hepta_size)4096ULL), ((hepta_size)0ULL), ((hepta_u8)31ULL), ((hepta_size)4095ULL));
    write_case(15, value_15);
    if (value_15 != ((hepta_u8)11ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 1;
    hepta_u8 value_16 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)3ULL));
    write_case(16, value_16);
    if (value_16 != ((hepta_u8)251ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    failure_countdown = 2;
    hepta_u8 value_17 = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)77ULL), ((hepta_size)3ULL));
    write_case(17, value_17);
    if (value_17 != ((hepta_u8)252ULL)) return 41;
    if (outstanding) { write_counters(); return 91; }
    if (failure_countdown) return 92;
    write_counters();
    if (successful_allocations != 31 || releases != 31 || outstanding != 0 || denied_allocations != 2 || peak_outstanding != 2) return 93;
    return 0;
}

int main(void){struct rlimit c={0,0};if(setrlimit(RLIMIT_CORE,&c))return 88;return smoke();}
