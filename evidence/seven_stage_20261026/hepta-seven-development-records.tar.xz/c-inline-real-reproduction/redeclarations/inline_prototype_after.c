unsigned helper(unsigned x) {return x+1u;}
inline unsigned helper(unsigned x);
unsigned entry(unsigned x) {return helper(x);}
