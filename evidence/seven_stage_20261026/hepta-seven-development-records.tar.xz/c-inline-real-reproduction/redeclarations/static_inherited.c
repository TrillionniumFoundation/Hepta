static unsigned helper(unsigned x);
inline unsigned helper(unsigned x) {return x+1u;}
unsigned entry(unsigned x) {return helper(x);}
