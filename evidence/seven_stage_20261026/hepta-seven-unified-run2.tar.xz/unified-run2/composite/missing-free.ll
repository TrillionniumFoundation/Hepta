; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i8 @__hia_fn_0(i1 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 1, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 1, 1
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_0 ], [ %t5, %edge_1 ]
  %p_1_1 = phi %hia.buffer [ %t5, %edge_0 ], [ %t5, %edge_1 ]
  %p_1_2 = phi %hia.buffer [ %t5, %edge_0 ], [ %t5, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_1_2, 0
  %t7 = extractvalue %hia.buffer %p_1_2, 1
  %t8 = icmp ult i64 0, %t7
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = getelementptr i8, ptr %t6, i64 0
  %t11 = load i8, ptr %t10, align 1
  %t12 = extractvalue %hia.buffer %p_1_1, 0
  %t13 = extractvalue %hia.buffer %p_1_1, 1
  %t14 = icmp ult i64 0, %t13
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t16 = getelementptr i8, ptr %t12, i64 0
  store i8 91, ptr %t16, align 1
  %t17 = extractvalue %hia.buffer %p_1_0, 0
  %t18 = extractvalue %hia.buffer %p_1_0, 1
  %t19 = icmp ult i64 0, %t18
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = getelementptr i8, ptr %t17, i64 0
  %t22 = load i8, ptr %t21, align 1
  %t23 = extractvalue %hia.buffer %p_1_0, 0
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %drop_nonnull_25, label %drop_after_25
drop_nonnull_25:
  br label %drop_after_25
drop_after_25:
  ret i8 %t22
edge_0:
  br label %b1
edge_1:
  br label %b1
}

define internal i64 @__hia_fn_1(i1 %p_0_0, i64 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_1, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_1, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %t6 = call %hia.alloc @__hia_allocate(i64 0, i1 false)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 0, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  br label %edge_2
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %t11 = call %hia.alloc @__hia_allocate(i64 0, i1 false)
  %t12 = extractvalue %hia.alloc %t11, 0
  %t13 = extractvalue %hia.alloc %t11, 1
  %t14 = select i1 %t13, i64 0, i64 0
  %t15 = insertvalue %hia.buffer %t12, i64 %t14, 1
  br label %edge_3
b3:
  %p_3_0 = phi i32 [ 0, %edge_2 ], [ 1, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %p_1_0, %edge_2 ], [ %t15, %edge_3 ]
  %p_3_2 = phi %hia.buffer [ %t10, %edge_2 ], [ %p_2_0, %edge_3 ]
  %t16 = icmp eq i32 %p_3_0, 0
  br i1 %t16, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i32 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi %hia.buffer [ %p_3_1, %edge_4 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %t17 = extractvalue %hia.buffer %p_4_2, 0
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %drop_nonnull_19, label %drop_after_19
drop_nonnull_19:
  br label %drop_after_19
drop_after_19:
  br label %edge_6
b5:
  %p_5_0 = phi i32 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi %hia.buffer [ %p_3_1, %edge_5 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_5 ]
  %t20 = icmp eq i32 %p_5_0, 1
  br i1 %t20, label %edge_7, label %edge_8
b6:
  %p_6_0 = phi i32 [ %p_5_0, %edge_7 ]
  %p_6_1 = phi %hia.buffer [ %p_5_1, %edge_7 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %t21 = extractvalue %hia.buffer %p_6_1, 0
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %drop_nonnull_23, label %drop_after_23
drop_nonnull_23:
  br label %drop_after_23
drop_after_23:
  br label %edge_9
b7:
  %p_7_0 = phi i32 [ %p_5_0, %edge_8 ]
  %p_7_1 = phi %hia.buffer [ %p_5_1, %edge_8 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_8 ]
  call void @abort()
  unreachable
b8:
  %p_8_0 = phi %hia.buffer [ %p_4_1, %edge_6 ]
  %t24 = extractvalue %hia.buffer %p_8_0, 1
  %t25 = extractvalue %hia.buffer %p_8_0, 0
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %drop_nonnull_27, label %drop_after_27
drop_nonnull_27:
  br label %drop_after_27
drop_after_27:
  ret i64 %t24
b9:
  %p_9_0 = phi %hia.buffer [ %p_6_2, %edge_9 ]
  %t28 = extractvalue %hia.buffer %p_9_0, 1
  %t29 = extractvalue %hia.buffer %p_9_0, 0
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %drop_nonnull_31, label %drop_after_31
drop_nonnull_31:
  br label %drop_after_31
drop_after_31:
  %t32 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t28, i64 10)
  %t33 = extractvalue { i64, i1 } %t32, 0
  %t34 = extractvalue { i64, i1 } %t32, 1
  %t35 = xor i1 %t34, true
  br i1 %t35, label %ok_36, label %trap_36
trap_36:
  call void @abort()
  unreachable
ok_36:
  ret i64 %t33
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b8
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b9
}

define internal { i32, %hia.buffer, i64, i64 } @__hia_fn_2(%hia.buffer %p_0_0, i64 %p_0_1) {
b0:
  %t1 = icmp eq i64 %p_0_1, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_0, 1
  %t3 = extractvalue %hia.buffer %p_1_0, 0
  %t4 = extractvalue %hia.buffer %p_1_0, 1
  %t5 = icmp ult i64 0, %t4
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = getelementptr i8, ptr %t3, i64 0
  %t8 = load i8, ptr %t7, align 1
  %t9 = zext i8 %t8 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t2, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = extractvalue %hia.buffer %p_1_0, 0
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %drop_nonnull_17, label %drop_after_17
drop_nonnull_17:
  br label %drop_after_17
drop_after_17:
  %t18 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t19 = extractvalue %hia.alloc %t18, 0
  %t20 = extractvalue %hia.alloc %t18, 1
  %t21 = select i1 %t20, i64 0, i64 0
  %t22 = insertvalue %hia.buffer %t19, i64 %t21, 1
  %t23 = insertvalue { i32, %hia.buffer, i64, i64 } zeroinitializer, i32 1, 0
  %t24 = insertvalue { i32, %hia.buffer, i64, i64 } %t23, %hia.buffer %t22, 1
  %t25 = insertvalue { i32, %hia.buffer, i64, i64 } %t24, i64 0, 2
  %t26 = insertvalue { i32, %hia.buffer, i64, i64 } %t25, i64 %t11, 3
  ret { i32, %hia.buffer, i64, i64 } %t26
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %t27 = extractvalue %hia.buffer %p_2_0, 0
  %t28 = extractvalue %hia.buffer %p_2_0, 1
  %t29 = icmp ult i64 0, %t28
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  %t31 = getelementptr i8, ptr %t27, i64 0
  %t32 = load i8, ptr %t31, align 1
  %t33 = trunc i64 %p_2_1 to i8
  %t34 = extractvalue %hia.buffer %p_2_0, 0
  %t35 = extractvalue %hia.buffer %p_2_0, 1
  %t36 = icmp ult i64 0, %t35
  br i1 %t36, label %ok_37, label %trap_37
trap_37:
  call void @abort()
  unreachable
ok_37:
  %t38 = getelementptr i8, ptr %t34, i64 0
  store i8 %t33, ptr %t38, align 1
  %t39 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %p_2_1, i64 1)
  %t40 = extractvalue { i64, i1 } %t39, 0
  %t41 = extractvalue { i64, i1 } %t39, 1
  %t42 = xor i1 %t41, true
  br i1 %t42, label %ok_43, label %trap_43
trap_43:
  call void @abort()
  unreachable
ok_43:
  %t44 = insertvalue { i32, %hia.buffer, i64, i64 } zeroinitializer, i32 0, 0
  %t45 = insertvalue { i32, %hia.buffer, i64, i64 } %t44, %hia.buffer %p_2_0, 1
  %t46 = insertvalue { i32, %hia.buffer, i64, i64 } %t45, i64 %t40, 2
  %t47 = insertvalue { i32, %hia.buffer, i64, i64 } %t46, i64 0, 3
  ret { i32, %hia.buffer, i64, i64 } %t47
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal void @__hia_fn_3(%hia.buffer %p_0_0, i64 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 0
  %t2 = icmp ne ptr %t1, null
  br i1 %t2, label %drop_nonnull_3, label %drop_after_3
drop_nonnull_3:
  br label %drop_after_3
drop_after_3:
  ret void
}

define internal i64 @__hia_fn_4(i8 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 7, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 7, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_1_0, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  br label %drop_after_8
drop_after_8:
  ret i64 250
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_2_1 = phi i8 [ %p_0_0, %edge_0 ]
  %t9 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t10 = extractvalue %hia.alloc %t9, 0
  %t11 = extractvalue %hia.alloc %t9, 1
  %t12 = select i1 %t11, i64 0, i64 0
  %t13 = insertvalue %hia.buffer %t10, i64 %t12, 1
  %t14 = icmp eq i8 %p_2_1, 0
  br i1 %t14, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ 0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t13, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_3_3 = phi i64 [ 2, %edge_2 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ]
  %t15 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %p_3_0, %hia.buffer %p_3_1, %hia.buffer %p_3_2, i64 %p_3_3, i64 %p_3_4)
  %t16 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, 0
  %t17 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, 1
  %t18 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, 2
  %t19 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, 3
  %t20 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, 4
  %t21 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %t16, %hia.buffer %t17, %hia.buffer %t18, i64 %t19, i64 %t20)
  %t22 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t21, 0
  %t23 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t21, 1
  %t24 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t21, 2
  %t25 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t21, 3
  %t26 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t21, 4
  call void @__hia_fn_6(i8 %t22, %hia.buffer %t23, %hia.buffer %t24, i64 %t25, i64 %t26)
  %t27 = zext i8 %t22 to i64
  %t28 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 30, i64 %t27)
  %t29 = extractvalue { i64, i1 } %t28, 0
  %t30 = extractvalue { i64, i1 } %t28, 1
  %t31 = xor i1 %t30, true
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  ret i64 %t29
b4:
  %p_4_0 = phi i8 [ 0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %t13, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_4_3 = phi i64 [ 2, %edge_3 ]
  %p_4_4 = phi i64 [ 0, %edge_3 ]
  %p_4_5 = phi i8 [ %p_2_1, %edge_3 ]
  %t33 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_7(i8 %p_4_0, %hia.buffer %p_4_1, %hia.buffer %p_4_2, i64 %p_4_3, i64 %p_4_4)
  %t34 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t33, 0
  %t35 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t33, 1
  %t36 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t33, 2
  %t37 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t33, 3
  %t38 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t33, 4
  %t39 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %t34, %hia.buffer %t35, %hia.buffer %t36, i64 %t37, i64 %t38)
  %t40 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t39, 0
  %t41 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t39, 1
  %t42 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t39, 2
  %t43 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t39, 3
  %t44 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t39, 4
  %t45 = icmp eq i8 %p_4_5, 1
  br i1 %t45, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i8 [ %t40, %edge_4 ]
  %p_5_1 = phi %hia.buffer [ %t41, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %t42, %edge_4 ]
  %p_5_3 = phi i64 [ %t43, %edge_4 ]
  %p_5_4 = phi i64 [ %t44, %edge_4 ]
  %t46 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %p_5_0, %hia.buffer %p_5_1, %hia.buffer %p_5_2, i64 %p_5_3, i64 %p_5_4)
  %t47 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t46, 0
  %t48 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t46, 1
  %t49 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t46, 2
  %t50 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t46, 3
  %t51 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t46, 4
  call void @__hia_fn_6(i8 %t47, %hia.buffer %t48, %hia.buffer %t49, i64 %t50, i64 %t51)
  %t52 = zext i8 %t47 to i64
  %t53 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 10, i64 %t52)
  %t54 = extractvalue { i64, i1 } %t53, 0
  %t55 = extractvalue { i64, i1 } %t53, 1
  %t56 = xor i1 %t55, true
  br i1 %t56, label %ok_57, label %trap_57
trap_57:
  call void @abort()
  unreachable
ok_57:
  ret i64 %t54
b6:
  %p_6_0 = phi i8 [ %t40, %edge_5 ], [ %t60, %edge_8 ]
  %p_6_1 = phi %hia.buffer [ %t41, %edge_5 ], [ %t61, %edge_8 ]
  %p_6_2 = phi %hia.buffer [ %t42, %edge_5 ], [ %t62, %edge_8 ]
  %p_6_3 = phi i64 [ %t43, %edge_5 ], [ %t63, %edge_8 ]
  %p_6_4 = phi i64 [ %t44, %edge_5 ], [ %t64, %edge_8 ]
  %t58 = icmp eq i8 %p_6_0, 2
  br i1 %t58, label %edge_6, label %edge_7
b7:
  %p_7_0 = phi i8 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi %hia.buffer [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %t59 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %p_7_0, %hia.buffer %p_7_1, %hia.buffer %p_7_2, i64 %p_7_3, i64 %p_7_4)
  %t60 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t59, 0
  %t61 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t59, 1
  %t62 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t59, 2
  %t63 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t59, 3
  %t64 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t59, 4
  br label %edge_8
b8:
  %p_8_0 = phi i8 [ %p_6_0, %edge_6 ]
  %p_8_1 = phi %hia.buffer [ %p_6_1, %edge_6 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_6 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_6 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_6 ]
  %t65 = call { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %p_8_0, %hia.buffer %p_8_1, %hia.buffer %p_8_2, i64 %p_8_3, i64 %p_8_4)
  %t66 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t65, 0
  %t67 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t65, 1
  %t68 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t65, 2
  %t69 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t65, 3
  %t70 = extractvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t65, 4
  %t71 = call i64 @__hia_fn_9(i8 %t66, %hia.buffer %t67, %hia.buffer %t68, i64 %t69, i64 %t70)
  %t72 = zext i8 %t66 to i64
  %t73 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %t72, i64 10)
  %t74 = extractvalue { i64, i1 } %t73, 0
  %t75 = extractvalue { i64, i1 } %t73, 1
  %t76 = xor i1 %t75, true
  br i1 %t76, label %ok_77, label %trap_77
trap_77:
  call void @abort()
  unreachable
ok_77:
  %t78 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t74, i64 %t71)
  %t79 = extractvalue { i64, i1 } %t78, 0
  %t80 = extractvalue { i64, i1 } %t78, 1
  %t81 = xor i1 %t80, true
  br i1 %t81, label %ok_82, label %trap_82
trap_82:
  call void @abort()
  unreachable
ok_82:
  ret i64 %t79
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b8
edge_7:
  br label %b7
edge_8:
  br label %b6
}

define internal { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_5(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp ult i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  call void @__hia_fn_3(%hia.buffer %p_1_2, i64 %p_1_3)
  %t2 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  %t7 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 3, 0
  %t8 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t7, %hia.buffer %p_1_1, 1
  %t9 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t8, %hia.buffer %t6, 2
  %t10 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t9, i64 0, 3
  %t11 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t10, i64 0, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t11
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %t12 = icmp ule i8 %p_2_0, 3
  br i1 %t12, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_2_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_2 ]
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %p_3_0, 0
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, %hia.buffer %p_3_1, 1
  %t15 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t14, %hia.buffer %p_3_2, 2
  %t16 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t15, i64 %p_3_3, 3
  %t17 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t16, i64 %p_3_4, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t17
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal void @__hia_fn_6(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 3
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  br label %drop_after_4
drop_after_4:
  %t5 = extractvalue %hia.buffer %p_1_2, 0
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %drop_nonnull_7, label %drop_after_7
drop_nonnull_7:
  br label %drop_after_7
drop_after_7:
  ret void
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_7(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 1, 0
  %t3 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t2, %hia.buffer %p_1_1, 1
  %t4 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t3, %hia.buffer %p_1_2, 2
  %t5 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t4, i64 %p_1_3, 3
  %t6 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t5, i64 %p_1_4, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t6
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 1
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = call { i32, %hia.buffer, i64, i64 } @__hia_fn_2(%hia.buffer %p_1_2, i64 %p_1_3)
  %t3 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 0
  %t4 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 1
  %t5 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 2
  %t6 = extractvalue { i32, %hia.buffer, i64, i64 } %t2, 3
  %t7 = icmp ule i32 %t3, 1
  br i1 %t7, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_1_1, %edge_2 ]
  %p_2_1 = phi i32 [ %t3, %edge_2 ]
  %p_2_2 = phi %hia.buffer [ %t4, %edge_2 ]
  %p_2_3 = phi i64 [ %t5, %edge_2 ]
  %p_2_4 = phi i64 [ %t6, %edge_2 ]
  %t8 = icmp eq i32 %p_2_1, 1
  %t9 = select i1 %t8, i8 2, i8 1
  %t10 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %t9, 0
  %t11 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t10, %hia.buffer %p_2_0, 1
  %t12 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t11, %hia.buffer %p_2_2, 2
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t12, i64 %p_2_3, 3
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, i64, i64 } %t13, i64 %p_2_4, 4
  ret { i8, %hia.buffer, %hia.buffer, i64, i64 } %t14
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_1, %edge_3 ]
  %p_3_1 = phi i32 [ %t3, %edge_3 ]
  %p_3_2 = phi %hia.buffer [ %t4, %edge_3 ]
  %p_3_3 = phi i64 [ %t5, %edge_3 ]
  %p_3_4 = phi i64 [ %t6, %edge_3 ]
  call void @abort()
  unreachable
b4:
  %p_4_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_4_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_4_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_4_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_4_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b4
edge_2:
  br label %b2
edge_3:
  br label %b3
}

define internal i64 @__hia_fn_9(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = icmp eq i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  br label %drop_after_4
drop_after_4:
  %t5 = extractvalue %hia.buffer %p_1_2, 0
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %drop_nonnull_7, label %drop_after_7
drop_nonnull_7:
  br label %drop_after_7
drop_after_7:
  ret i64 %p_1_4
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define zeroext i8 @stored(i1 zeroext %a0) {
entry:
  %result = call i8 @__hia_fn_0(i1 %a0)
  ret i8 %result
}

define i64 @choose(i1 zeroext %a0, i64 %a1) {
entry:
  %result = call i64 @__hia_fn_1(i1 %a0, i64 %a1)
  ret i64 %result
}

define i64 @task_case(i8 zeroext %a0) {
entry:
  %result = call i64 @__hia_fn_4(i8 %a0)
  ret i64 %result
}
