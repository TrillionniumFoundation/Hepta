
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
typedef size_t hepta_size; typedef uint8_t hepta_u8; typedef uint32_t hepta_u32;
typedef uint64_t hepta_u64;
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[64];
static hepta_u32 successful_allocations,releases,outstanding,denied_allocations;
static hepta_u32 failure_countdown,peak_outstanding;
static bool refuse(void) {
    if(failure_countdown && --failure_countdown == 0){denied_allocations++;return true;}return false;
}
static void *remember(void *p) {
    if(!p)return NULL;
    for(size_t i=0;i<64;i++)if(!addresses[i]) {
        addresses[i]=p;successful_allocations++;outstanding++;
        if(outstanding>peak_outstanding)peak_outstanding=outstanding;
        return p;
    }
    exit(89);
}
void *__wrap_malloc(size_t n) {if(refuse())return NULL;return remember(__real_malloc(n));}
void *__wrap_calloc(size_t n,size_t w) {if(refuse())return NULL;return remember(__real_calloc(n,w));}
void __wrap_free(void *p) {
    if(p){size_t i;for(i=0;i<64 && addresses[i]!=p;i++){}if(i==64)exit(90);
        addresses[i]=NULL;outstanding--;releases++;}
    __real_free(p);
}
static void write_case(hepta_u32 index,hepta_u32 value){printf("HIA_BULK case %u %u\n",index,value);}
static void write_counters(void){printf("HIA_AARCH64 resources %u %u %u %u\n",
    successful_allocations,releases,outstanding,denied_allocations);}
extern hepta_u8 aggregate_bulk(hepta_size, hepta_size, hepta_size, hepta_u8, hepta_size);
static int smoke(void) {
    hepta_u8 unexpected = aggregate_bulk(((hepta_size)5ULL), ((hepta_size)1ULL), ((hepta_size)3ULL), ((hepta_u8)7ULL), ((hepta_size)5ULL));
    write_case(0, unexpected);
    write_counters();
    return 41;
}

int main(void){struct rlimit c={0,0};if(setrlimit(RLIMIT_CORE,&c))return 88;return smoke();}
