; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "aarch64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1 immarg)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i8 @__hia_fn_0(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2, i64 %p_0_3, i8 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = icmp eq i64 %t1, 0
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %t3 = extractvalue %hia.buffer %p_1_0, 0
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %drop_nonnull_5, label %drop_after_5
drop_nonnull_5:
  br label %drop_after_5
drop_after_5:
  %t6 = extractvalue %hia.buffer %p_1_1, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  br label %drop_after_8
drop_after_8:
  ret i8 0
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %t1, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_5 = phi i8 [ %p_0_4, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_5, %edge_1 ]
  %t9 = extractvalue %hia.buffer %p_2_0, 0
  %t10 = extractvalue %hia.buffer %p_2_0, 1
  %t11 = icmp ne i64 %t10, 0
  br i1 %t11, label %bulk_nonzero_12, label %bulk_after_12
bulk_nonzero_12:
  call void @llvm.memset.p0.i64(ptr align 1 %t9, i8 11, i64 %t10, i1 false)
  br label %bulk_after_12
bulk_after_12:
  %t13 = extractvalue %hia.buffer %p_2_0, 0
  %t14 = extractvalue %hia.buffer %p_2_0, 1
  %t15 = icmp ule i64 %p_2_3, %t14
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  %t17 = sub i64 %t14, %p_2_3
  %t18 = icmp ule i64 %p_2_4, %t17
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t21 = icmp ne i64 %p_2_4, 0
  br i1 %t21, label %fill_nonempty_20, label %fill_after_20
fill_nonempty_20:
  %t22 = getelementptr i8, ptr %t13, i64 %p_2_3
  call void @llvm.memset.p0.i64(ptr align 1 %t22, i8 %p_2_5, i64 %p_2_4, i1 false)
  br label %fill_after_20
fill_after_20:
  %t23 = extractvalue %hia.buffer %p_2_0, 0
  %t24 = extractvalue %hia.buffer %p_2_0, 1
  %t25 = icmp ult i64 0, %t24
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = icmp ult i64 %p_2_6, %t24
  br i1 %t27, label %ok_28, label %trap_28
trap_28:
  call void @abort()
  unreachable
ok_28:
  %t29 = getelementptr i8, ptr %t23, i64 0
  %t30 = getelementptr i8, ptr %t23, i64 %p_2_6
  %t31 = load i8, ptr %t29, align 1
  %t32 = load i8, ptr %t30, align 1
  store i8 %t32, ptr %t29, align 1
  store i8 %t31, ptr %t30, align 1
  %t33 = extractvalue %hia.buffer %p_2_0, 0
  %t34 = extractvalue %hia.buffer %p_2_0, 1
  %t35 = icmp ule i64 1, %t34
  br i1 %t35, label %ok_36, label %trap_36
trap_36:
  call void @abort()
  unreachable
ok_36:
  %t37 = icmp ule i64 0, %t34
  br i1 %t37, label %ok_38, label %trap_38
trap_38:
  call void @abort()
  unreachable
ok_38:
  %t39 = sub i64 %t34, 1
  %t40 = sub i64 %t34, 0
  %t41 = icmp ule i64 %p_2_4, %t39
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = icmp ule i64 %p_2_4, %t40
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = icmp ne i64 %p_2_4, 0
  br i1 %t45, label %bulk_nonzero_46, label %bulk_after_46
bulk_nonzero_46:
  %t47 = getelementptr i8, ptr %t33, i64 1
  %t48 = getelementptr i8, ptr %t33, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %t47, ptr align 1 %t48, i64 %p_2_4, i1 false)
  br label %bulk_after_46
bulk_after_46:
  %t49 = extractvalue %hia.buffer %p_2_1, 0
  %t50 = extractvalue %hia.buffer %p_2_1, 1
  %t51 = extractvalue %hia.buffer %p_2_0, 0
  %t52 = extractvalue %hia.buffer %p_2_0, 1
  %t53 = icmp ule i64 %p_2_2, %t50
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  %t55 = icmp ule i64 %p_2_2, %t52
  br i1 %t55, label %ok_56, label %trap_56
trap_56:
  call void @abort()
  unreachable
ok_56:
  %t57 = icmp ne i64 %p_2_2, 0
  br i1 %t57, label %bulk_nonzero_58, label %bulk_after_58
bulk_nonzero_58:
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %t49, ptr align 1 %t51, i64 %p_2_2, i1 false)
  br label %bulk_after_58
bulk_after_58:
  %t59 = extractvalue %hia.buffer %p_2_1, 0
  %t60 = extractvalue %hia.buffer %p_2_1, 1
  %t61 = extractvalue %hia.buffer %p_2_0, 0
  %t62 = extractvalue %hia.buffer %p_2_0, 1
  %t63 = icmp ule i64 0, %t60
  br i1 %t63, label %ok_64, label %trap_64
trap_64:
  call void @abort()
  unreachable
ok_64:
  %t65 = icmp ule i64 1, %t62
  br i1 %t65, label %ok_66, label %trap_66
trap_66:
  call void @abort()
  unreachable
ok_66:
  %t67 = sub i64 %t60, 0
  %t68 = sub i64 %t62, 1
  %t69 = icmp ule i64 %p_2_4, %t67
  br i1 %t69, label %ok_70, label %trap_70
trap_70:
  call void @abort()
  unreachable
ok_70:
  %t71 = icmp ule i64 %p_2_4, %t68
  br i1 %t71, label %ok_72, label %trap_72
trap_72:
  call void @abort()
  unreachable
ok_72:
  %t73 = icmp ne i64 %p_2_4, 0
  br i1 %t73, label %bulk_nonzero_74, label %bulk_after_74
bulk_nonzero_74:
  %t75 = getelementptr i8, ptr %t59, i64 0
  %t76 = getelementptr i8, ptr %t61, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %t75, ptr align 1 %t76, i64 %p_2_4, i1 false)
  br label %bulk_after_74
bulk_after_74:
  %t77 = extractvalue %hia.buffer %p_2_1, 0
  %t78 = extractvalue %hia.buffer %p_2_1, 1
  %t79 = icmp ult i64 %p_2_6, %t78
  br i1 %t79, label %ok_80, label %trap_80
trap_80:
  call void @abort()
  unreachable
ok_80:
  %t81 = getelementptr i8, ptr %t77, i64 %p_2_6
  %t82 = load i8, ptr %t81, align 1
  %t83 = extractvalue %hia.buffer %p_2_0, 0
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %drop_nonnull_85, label %drop_after_85
drop_nonnull_85:
  br label %drop_after_85
drop_after_85:
  %t86 = extractvalue %hia.buffer %p_2_1, 0
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %drop_nonnull_88, label %drop_after_88
drop_nonnull_88:
  br label %drop_after_88
drop_after_88:
  ret i8 %t82
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i8 @__hia_fn_1(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, i8 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_1_0, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  br label %drop_after_8
drop_after_8:
  ret i8 251
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_2_1 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_2 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_3 = phi i64 [ %p_0_2, %edge_0 ]
  %p_2_4 = phi i8 [ %p_0_3, %edge_0 ]
  %p_2_5 = phi i64 [ %p_0_4, %edge_0 ]
  %t9 = call %hia.alloc @__hia_allocate(i64 %p_2_1, i1 true)
  %t10 = extractvalue %hia.alloc %t9, 0
  %t11 = extractvalue %hia.alloc %t9, 1
  %t12 = select i1 %t11, i64 %p_2_1, i64 0
  %t13 = insertvalue %hia.buffer %t10, i64 %t12, 1
  br i1 %t11, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %t13, %edge_3 ]
  %t14 = extractvalue %hia.buffer %p_3_0, 0
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %drop_nonnull_16, label %drop_after_16
drop_nonnull_16:
  br label %drop_after_16
drop_after_16:
  %t17 = extractvalue %hia.buffer %p_3_1, 0
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %drop_nonnull_19, label %drop_after_19
drop_nonnull_19:
  br label %drop_after_19
drop_after_19:
  ret i8 252
b4:
  %p_4_0 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_4_1 = phi %hia.buffer [ %t13, %edge_2 ]
  %p_4_2 = phi i64 [ %p_2_2, %edge_2 ]
  %p_4_3 = phi i64 [ %p_2_3, %edge_2 ]
  %p_4_4 = phi i8 [ %p_2_4, %edge_2 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_2 ]
  %t20 = call i8 @__hia_fn_0(%hia.buffer %p_4_0, %hia.buffer %p_4_1, i64 %p_4_2, i64 %p_4_3, i8 %p_4_4, i64 %p_4_5)
  ret i8 %t20
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b4
edge_3:
  br label %b3
}

define i8 @aggregate_bulk(i64 %a0, i64 %a1, i64 %a2, i8 %a3, i64 %a4) {
entry:
  %result = call i8 @__hia_fn_1(i64 %a0, i64 %a1, i64 %a2, i8 %a3, i64 %a4)
  ret i8 %result
}
