; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i1 %p_0_0) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  ret i32 1
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  ret i32 0
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_1(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  br label %edge_0
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ], [ %p_2_1, %edge_3 ]
  %p_1_2 = phi i32 [ %p_0_0, %edge_0 ], [ %t7, %edge_3 ]
  %p_1_3 = phi i32 [ %p_0_1, %edge_0 ], [ %p_2_3, %edge_3 ]
  %p_1_4 = phi i32 [ %t1, %edge_0 ], [ %t10, %edge_3 ]
  %t2 = trunc i64 4 to i32
  %t3 = icmp slt i32 %p_1_4, %t2
  br i1 %t3, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_1_2, %edge_1 ]
  %p_2_3 = phi i32 [ %p_1_3, %edge_1 ]
  %p_2_4 = phi i32 [ %p_1_4, %edge_1 ]
  %t4 = trunc i64 33 to i32
  %t5 = mul i32 %p_2_2, %t4
  %t6 = add i32 %t5, %p_2_3
  %t7 = add i32 %t6, %p_2_4
  %t8 = trunc i64 1 to i32
  %t9 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_2_4, i32 %t8)
  %t10 = extractvalue { i32, i1 } %t9, 0
  %t11 = extractvalue { i32, i1 } %t9, 1
  %t12 = xor i1 %t11, true
  br i1 %t12, label %ok_13, label %trap_13
trap_13:
  call void @abort()
  unreachable
ok_13:
  br label %edge_3
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i32 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i32 [ %p_1_4, %edge_2 ]
  %t14 = trunc i64 17 to i32
  %t15 = add i32 %p_3_2, %t14
  ret i32 %t15
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i64 %p_0_1) {
b0:
  %t1 = trunc i64 0 to i32
  br label %edge_0
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ], [ %p_2_0, %edge_3 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ], [ %p_2_1, %edge_3 ]
  %p_1_2 = phi i64 [ %p_0_0, %edge_0 ], [ %t9, %edge_3 ]
  %p_1_3 = phi i64 [ %p_0_1, %edge_0 ], [ %p_2_3, %edge_3 ]
  %p_1_4 = phi i32 [ %t1, %edge_0 ], [ %t12, %edge_3 ]
  %t2 = trunc i64 4 to i32
  %t3 = icmp slt i32 %p_1_4, %t2
  br i1 %t3, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_1_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_1_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_1_3, %edge_1 ]
  %p_2_4 = phi i32 [ %p_1_4, %edge_1 ]
  %t4 = trunc i64 33 to i32
  %t5 = sext i32 %t4 to i64
  %t6 = mul i64 %p_2_2, %t5
  %t7 = add i64 %t6, %p_2_3
  %t8 = sext i32 %p_2_4 to i64
  %t9 = add i64 %t7, %t8
  %t10 = trunc i64 1 to i32
  %t11 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %p_2_4, i32 %t10)
  %t12 = extractvalue { i32, i1 } %t11, 0
  %t13 = extractvalue { i32, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  br label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i32 [ %p_1_4, %edge_2 ]
  %t16 = trunc i64 17 to i32
  %t17 = zext i32 %t16 to i64
  %t18 = add i64 %p_3_2, %t17
  ret i64 %t18
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b1
}

define internal i64 @__hia_fn_3(i32 %p_0_0, i64 %p_0_1) {
b0:
  %t1 = trunc i64 7 to i32
  %t2 = call i32 @__hia_fn_5(i32 %p_0_0, i32 %t1)
  %t3 = zext i32 %t2 to i64
  %t4 = call i64 @__hia_fn_4(i64 %p_0_1, i64 11)
  %t5 = xor i64 %t3, %t4
  ret i64 %t5
}

define internal i64 @__hia_fn_4(i64 %p_0_0, i64 %p_0_1) {
b0:
  %t1 = call i64 @__hia_fn_2(i64 %p_0_0, i64 %p_0_1)
  ret i64 %t1
}

define internal i32 @__hia_fn_5(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call i32 @__hia_fn_1(i32 %p_0_0, i32 %p_0_1)
  ret i32 %t1
}

define i32 @c_bool_to_int(i1 zeroext %a0) {
entry:
  %result = call i32 @__hia_fn_0(i1 %a0)
  ret i32 %result
}

define i32 @cpp_8a73790f305309673cf653df(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_1(i32 %a0, i32 %a1)
  ret i32 %result
}

define i64 @cpp_963e78ea936bf730a0dfbc22(i64 %a0, i64 %a1) {
entry:
  %result = call i64 @__hia_fn_2(i64 %a0, i64 %a1)
  ret i64 %result
}

define i64 @matrix_cross(i32 %a0, i64 %a1) {
entry:
  %result = call i64 @__hia_fn_3(i32 %a0, i64 %a1)
  ret i64 %result
}

define i64 @matrix_wide(i64 %a0, i64 %a1) {
entry:
  %result = call i64 @__hia_fn_4(i64 %a0, i64 %a1)
  ret i64 %result
}

define i32 @matrix_word(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_5(i32 %a0, i32 %a1)
  ret i32 %result
}
