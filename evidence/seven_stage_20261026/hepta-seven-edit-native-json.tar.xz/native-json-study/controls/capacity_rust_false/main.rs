#![forbid(unsafe_code)]
use std::io::Write;
mod kernel;
fn entrypoint(used:u32,capacity:u32)->u32{kernel::kernel(used,capacity)}
fn main(){println!("STUDY_READY");println!("STUDY_CALL 0");std::io::stdout().flush().unwrap();let value_0=entrypoint(0u32,0u32);println!("STUDY_VALUE 0 {}",value_0);println!("STUDY_CALL 1");std::io::stdout().flush().unwrap();let value_1=entrypoint(0u32,1u32);println!("STUDY_VALUE 1 {}",value_1);println!("STUDY_CALL 2");std::io::stdout().flush().unwrap();let value_2=entrypoint(1u32,1u32);println!("STUDY_VALUE 2 {}",value_2);println!("STUDY_CALL 3");std::io::stdout().flush().unwrap();let value_3=entrypoint(17u32,18u32);println!("STUDY_VALUE 3 {}",value_3);println!("STUDY_CALL 4");std::io::stdout().flush().unwrap();let value_4=entrypoint(19u32,18u32);println!("STUDY_VALUE 4 {}",value_4);println!("STUDY_CALL 5");std::io::stdout().flush().unwrap();let value_5=entrypoint(4294967295u32,4294967295u32);println!("STUDY_VALUE 5 {}",value_5);println!("STUDY_DONE");}
