#!/usr/bin/env python3
"""Bind the reviewed launcher to an explicitly supplied clean frozen commit; no test run."""
import sys
sys.dont_write_bytecode = True
import json, subprocess, hashlib
from pathlib import Path
from datetime import datetime, timezone
import unittest
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REPO = BASE / "hepta-integration"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    assert len(sys.argv) == 2, "exact frozen HEAD required"
    expected = sys.argv[1]
    assert len(expected) == 40 and all(c in "0123456789abcdef" for c in expected)
    assert not (HERE / "PLAN.json").exists() and not (HERE / "run").exists()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=REPO, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], cwd=REPO, text=True)
    assert head == expected and not status
    p = json.loads((BASE / "p1-p2-integrated-44e34b7-launches/PLAN.json").read_bytes())
    sys.path.insert(0, str(REPO))
    from tests.test_hia_rust_scoped_cleanup import RustScopedAbortCleanup
    names = unittest.TestLoader().getTestCaseNames(RustScopedAbortCleanup)
    assert len(names) == 20
    p.update(schema="hepta.rust-scoped-cleanup.integrated-focused-plan.v1",
        source_head=head, source_tree=tree, prepared_utc=datetime.now(timezone.utc).isoformat(),
        launcher_sha256=digest(HERE / "launch.py"),
        preparation_sha256=digest(Path(__file__)),
        source_identity_checker_sha256=digest(REPO / "tools/qualify_hia_integrated.py"),
        repository=str(REPO), expected_observations=260, expected_rust_tests=121,
        expected_rust_footers=21,
        focused_test_methods=["tests.test_hia_rust_scoped_cleanup.RustScopedAbortCleanup." + name for name in names],
        historical_source_references=p["historical_source_references"] + [
            {"source_commit":"44e34b7a9ecd6bf1b3ad6093d21bba10d2a18304",
             "scope":"historical finite-heap 253 observation matrix, 53 live-payload stops; preserved prefix observations, no cleanup guarantee, not this fresh qualification"},
            {"source_commit":"39ae13638170fad2fe3234f8e7ca989997ef69c4",
             "scope":"scoped cleanup development; six retained sequential commands, no fresh integrated qualification",
             "summary_sha256":digest(BASE / "p1-p2-scoped-cleanup-development-20261030/SUMMARY.json")}],
        cache_reused=True, clean_rebuild_claimed=False, cpu_performance_qualification=False,
        interpretation="same authored finite matrix plus explicit cleanup additions; no new holdout; original runtime prefix retained; logical Machine discharge is not host OOM/process termination recovery")
    p["stages"] = [
        {"id":"focused", "kind":"unittest", "timeout_seconds":300,
         "argv":[p["tools"]["python"],"-B","-m","unittest","-v","tests.test_hia_rust_scoped_cleanup"]},
        {"id":"rust", "kind":"cargo", "timeout_seconds":300,
         "argv":[p["tools"]["cargo"],"test","--locked","--offline","--manifest-path","rust/hia-core-shadow/Cargo.toml"]}]
    raw = (json.dumps(p,sort_keys=True,indent=2)+"\n").encode()
    (HERE / "PLAN.json").write_bytes(raw)
    print(json.dumps({"prepared":True,"source_head":head,"source_tree":tree,"plan_sha256":hashlib.sha256(raw).hexdigest(),"test_methods":len(names),"executed_tests":0}))
if __name__ == "__main__":
    main()
