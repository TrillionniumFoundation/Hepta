from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
BASE=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/f0c12f106c89/hepta-next-resource')
label,*argv=sys.argv[1:]
out=BASE/label;out.mkdir()
env=os.environ.copy()
plan=json.loads(Path('/workspace/scratch/f0c12f106c89/p1-p2-integrated-44e34b7-launches/PLAN.json').read_text())
env.update(plan['environment']);env['PYTHONPATH']=str(ROOT)
env['HEPTA_RUST_SCOPED_CLEANUP_EVIDENCE_DIR']=str(out/'actual')
record={'schema':'hepta.scoped-cleanup.development-run.v1','argv':argv,'cwd':str(ROOT),'environment':plan['environment']|{'PYTHONPATH':str(ROOT)},'formal_qualification':False,'new_holdout':False,'started_unix_ns':time.time_ns()}
record['source_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT);(out/'source.diff').write_bytes(patch)
record['source_patch_sha256']=hashlib.sha256(patch).hexdigest()
paths=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
record['untracked_source']={}
for name in paths:
 p=ROOT/name
 if p.is_file():
  b=p.read_bytes();q=out/'source_snapshot'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
  record['untracked_source'][name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(out/'RECEIPT.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
start=time.monotonic_ns();child=None;record['cleanup_errors']=[]
try:
 with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
  child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  record['returncode']=child.wait(timeout=300)
except BaseException as exc:
 record['error']={'type':type(exc).__name__,'message':str(exc)}
finally:
 if child is not None and child.poll() is None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except BaseException as exc:record['cleanup_errors'].append(repr(exc))
  try:record['returncode']=child.wait(timeout=10)
  except BaseException as exc:record['cleanup_errors'].append(repr(exc))
 record['outer_wall_ns']=time.monotonic_ns()-start
 record['cleanup_scope']='leader reaped; timeout group signaled; escaped descendants not independently proved absent'
 for name in ['stdout','stderr']:
  q=out/name
  if q.exists():
   b=q.read_bytes();record[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 record['binary_after']=None
 binary=Path(env['CARGO_TARGET_DIR'])/'debug/hia-core-shadow'
 if binary.is_file():
  b=binary.read_bytes();record['binary_after']={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 (out/'RECEIPT.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'label':label,'returncode':record.get('returncode'),'error':record.get('error'),'outer_wall_ns':record['outer_wall_ns'],'path':str(out)}))
sys.exit(0 if record.get('returncode')==0 and not record.get('error') and not record['cleanup_errors'] else 1)
