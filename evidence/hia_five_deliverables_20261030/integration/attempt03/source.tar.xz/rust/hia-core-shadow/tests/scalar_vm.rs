use hia_core_shadow::{decode_scalar_arguments, execute_scalar, MAX_SCALAR_ARGS, MAX_SCALAR_ARGS_BYTES};
use serde_json::{json, Value};

fn machine(op: &str, ty: &str, effects: Vec<&str>) -> Value {
    json!({
        "schema": "hepta.hia.program.v1", "module": "rust_vm_tests",
        "functions": [{
            "name":"calculate",
            "params":[{"name":"a","type":ty},{"name":"b","type":ty}],
            "returns":[ty], "effects":effects,
            "entry":"entry",
            "blocks":[{
                "id":"entry",
                "params":[{"name":"a","type":ty},{"name":"b","type":ty}],
                "ops":[{"op":op, "args":["a","b"],
                        "out":[{"name":"value","type":ty}], "attrs":{}}],
                "term":{"op":"ret","values":["value"]}
            }]
        }]
    })
}
fn run(document: &Value, function: &str, args: Vec<Value>, steps: u64) -> Value {
    execute_scalar(&serde_json::to_vec(document).unwrap(), function, &args, steps).unwrap()
}
#[test]
fn scalar_cli_argument_decoder_is_bounded_before_untrusted_value_materialization() {
    assert_eq!(
        decode_scalar_arguments("[2,3,true,null]").unwrap(),
        vec![json!(2), json!(3), json!(true), Value::Null]
    );
    assert_eq!(decode_scalar_arguments("[]").unwrap(), Vec::<Value>::new());
    // Shape, count and byte limits are independent of the function signature.
    for invalid in ["{}", "[{}]", "[[]]", "[\"opaque\"]", "3", "[1.5]"] {
        assert!(decode_scalar_arguments(invalid).is_err(), "{invalid}");
    }
    let oversized = format!("[{}]", "1".repeat(MAX_SCALAR_ARGS_BYTES));
    let byte_err = decode_scalar_arguments(&oversized).unwrap_err();
    assert_eq!(byte_err.code, "E_HIA_INPUT");

    // The delimiter/context may be short enough in bytes but must never
    // materialize more than the explicitly admitted element count.
    let many = format!("[{}]", vec!["0"; MAX_SCALAR_ARGS + 1].join(","));
    let count_err = decode_scalar_arguments(&many).unwrap_err();
    assert_eq!(count_err.code, "E_HIA_INPUT");
    // Depth is rejected by the EXISTING bounded UniqueJson decoder.
    let nested = format!("{}0{}", "[".repeat(100), "]".repeat(100));
    assert!(decode_scalar_arguments(&nested).is_err());
    // The original interpreter consumes typed scalars unchanged.
    let program = machine("int.add.wrap", "u32", vec![]);
    let passed = decode_scalar_arguments("[2,3]").unwrap();
    assert_eq!(run(&program, "calculate", passed, 100)["values"], json!([5]));
}

#[test]
fn checked_and_wrapping_u64_arithmetic_are_distinct() {
    let a = json!(u64::MAX);
    let doc = machine("int.add.wrap", "u64", vec![]);
    assert_eq!(run(&doc, "calculate", vec![a.clone(),json!(2)], 100)["values"], json!([1]));
    let doc = machine("int.add.checked", "u64", vec!["trap"]);
    let result = run(&doc, "calculate", vec![a,json!(2)], 100);
    assert_eq!(result["status"], "trapped");
    assert_eq!(result["error"]["code"], "overflow");
    let doc = machine("int.mul.wrap", "u64", vec![]);
    assert_eq!(run(&doc, "calculate", vec![json!(u64::MAX),json!(u64::MAX)], 100)["values"], json!([1]));
}
#[test]
fn v7_scalar_instructions_retain_v6_semantics_without_resource_admission() {
    let mut scalar = machine("int.add.wrap", "u32", vec![]);
    scalar["schema"] = json!("hepta.hia.program.v7");
    let args = vec![json!(2), json!(3)];
    assert_eq!(run(&scalar, "calculate", args.clone(), 100)["values"], json!([5]));
    scalar["functions"][0]["blocks"][0]["ops"][0]["op"] = json!("chain.empty");
    assert!(execute_scalar(&serde_json::to_vec(&scalar).unwrap(),
                           "calculate", &args, 100).is_err());
}

#[test]
fn explicit_scalar_exports_are_verified_and_private_entries_refused() {
    let mut doc = machine("int.add.wrap", "u32", vec![]);
    let args = vec![json!(2), json!(3)];

    // No explicit export list retains v1's historical scalar entry behavior.
    assert_eq!(run(&doc, "calculate", args.clone(), 100)["values"], json!([5]));
    doc["exports"] = json!(["calculate"]);
    assert_eq!(run(&doc, "calculate", args.clone(), 100)["values"], json!([5]));

    // This is a source-free public-call restriction, not a producer claim.
    doc["exports"] = json!([]);
    assert!(execute_scalar(&serde_json::to_vec(&doc).unwrap(),
                           "calculate", &args, 100).is_err());
    doc["exports"] = json!(["ghost"]);
    assert!(execute_scalar(&serde_json::to_vec(&doc).unwrap(),
                           "calculate", &args, 100).is_err());
    doc["exports"] = json!(["calculate", "calculate"]);
    assert!(execute_scalar(&serde_json::to_vec(&doc).unwrap(),
                           "calculate", &args, 100).is_err());
    doc["exports"] = json!([true]);
    assert!(execute_scalar(&serde_json::to_vec(&doc).unwrap(),
                           "calculate", &args, 100).is_err());
}

#[test]
fn signed_division_and_remainder_truncate_toward_zero() {
    let division = machine("int.div.checked","i64",vec!["trap"]);
    assert_eq!(run(&division,"calculate",vec![json!(-7),json!(3)],100)["values"],json!([-2]));
    let remainder = machine("int.rem.checked","i64",vec!["trap"]);
    assert_eq!(run(&remainder,"calculate",vec![json!(-7),json!(3)],100)["values"],json!([-1]));
    let result = run(&division,"calculate",vec![json!(i64::MIN),json!(-1)],100);
    assert_eq!(result["error"]["code"],"overflow");
    let zero = run(&division,"calculate",vec![json!(2),json!(0)],100);
    assert_eq!(zero["error"]["code"],"division_by_zero");
}
#[test]
fn signed_minimum_division_and_remainder_trap_for_each_width() {
    for (ty, low) in [
        ("i8", -128_i64), ("i16", -32_768_i64),
        ("i32", -2_147_483_648_i64), ("i64", i64::MIN),
    ] {
        for op in ["int.div.checked", "int.rem.checked"] {
            let doc = machine(op, ty, vec!["trap"]);
            let result = run(&doc, "calculate", vec![json!(low), json!(-1)], 100);
            assert_eq!(result["status"], "trapped", "{op} {ty}");
            assert_eq!(result["error"]["code"], "overflow", "{op} {ty}");
            // A nearby negative input is representable and may be divided
            // normally. The fix must not turn every /-1 into a false trap.
            let safe = run(&doc, "calculate", vec![json!(low + 1), json!(-1)], 100);
            assert_eq!(safe["status"], "returned", "{op} {ty}");
            let expected = if op == "int.rem.checked" { 0 } else { -(low + 1) };
            assert_eq!(safe["values"], json!([expected]), "{op} {ty}");
        }
    }
    // A signed-only guard must not change unsigned remainder semantics.
    let unsigned = machine("int.rem.checked", "u64", vec!["trap"]);
    assert_eq!(
        run(&unsigned, "calculate", vec![json!(u64::MAX), json!(1)], 100)["values"],
        json!([0])
    );
}
#[test]
fn signed_shift_arithmetic_and_count_traps() {
    let shr = machine("int.shr.checked","i64",vec!["trap"]);
    assert_eq!(run(&shr,"calculate",vec![json!(-9),json!(2)],100)["values"],json!([-3]));
    assert_eq!(run(&shr,"calculate",vec![json!(1),json!(64)],100)["error"]["code"],"overflow");
    let shl = machine("int.shl.checked","i64",vec!["trap"]);
    assert_eq!(run(&shl,"calculate",vec![json!(1_i64 << 62),json!(2)],100)["values"],json!([0]));
}
fn iterative() -> Value {
    json!({
        "schema":"hepta.hia.program.v1", "module":"loop", "functions":[{
          "name":"counter","params":[{"name":"n","type":"u32"}],
          "returns":["u32"], "effects":["trap"], "entry":"entry",
          "blocks":[
            {"id":"entry","params":[{"name":"n","type":"u32"}],
             "ops":[
               {"op":"const","args":[],"out":[{"name":"zero","type":"u32"}],"attrs":{"value":0}},
               {"op":"const","args":[],"out":[{"name":"one","type":"u32"}],"attrs":{"value":1}}
             ],
             "term":{"op":"jump","target":"loop","args":["n","zero","one"]}},
            {"id":"loop","params":[{"name":"remain","type":"u32"},{"name":"total","type":"u32"},{"name":"step","type":"u32"}],
             "ops":[
               {"op":"const","args":[],"out":[{"name":"zero_loop","type":"u32"}],"attrs":{"value":0}},
               {"op":"compare.gt","args":["remain","zero_loop"],"out":[{"name":"condition","type":"bool"}],"attrs":{}}
             ],
             "term":{"op":"branch","cond":"condition","then":{"target":"body","args":["remain","total","step"]},
                                          "else":{"target":"done","args":["total"]}}},
            {"id":"body","params":[{"name":"r","type":"u32"},{"name":"acc","type":"u32"},{"name":"s","type":"u32"}],
             "ops":[
               {"op":"int.sub.checked","args":["r","s"],"out":[{"name":"remaining","type":"u32"}],"attrs":{}},
               {"op":"int.add.checked","args":["acc","s"],"out":[{"name":"updated","type":"u32"}],"attrs":{}}
             ],
             "term":{"op":"jump","target":"loop","args":["remaining","updated","s"]}},
            {"id":"done","params":[{"name":"answer","type":"u32"}],"ops":[],"term":{"op":"ret","values":["answer"]}}
          ]
        }]
    })
}
#[test]
fn phi_block_arguments_and_loop_step_budget() {
    let doc = iterative();
    let done = run(&doc,"counter",vec![json!(5)],100);
    assert_eq!(done["status"],"returned");
    assert_eq!(done["values"],json!([5]));
    assert_eq!(done["steps"],json!(38));
    let timed = run(&doc,"counter",vec![json!(100)],5);
    assert_eq!(timed["status"],"budget_exceeded");
    assert_eq!(timed["error"]["code"],"steps");
}
#[test]
fn invalid_program_or_wrong_type_cannot_enter_oracle() {
    let doc=machine("int.add.checked","u32",vec!["trap"]);
    let raw=serde_json::to_vec(&doc).unwrap();
    assert!(execute_scalar(&raw,"calculate",&[json!(true),json!(4)],100).is_err());
    assert!(execute_scalar(&raw,"calculate",&[json!(2),json!(4)],0).is_err());
    let mut invalid=doc;
    invalid["functions"][0]["blocks"][0]["ops"][0]["op"] = json!("owner.drop");
    assert!(execute_scalar(&serde_json::to_vec(&invalid).unwrap(),
                           "calculate",&[json!(2),json!(4)],100).is_err());
}
#[test]
fn recursion_is_bounded_independently_of_step_budget() {
    let doc=json!({
        "schema":"hepta.hia.program.v1","module":"recursion",
        "functions":[{
            "name":"recur","params":[{"name":"value","type":"i32"}],
            "returns":["i32"],"effects":[],"entry":"entry",
            "blocks":[{"id":"entry","params":[{"name":"value","type":"i32"}],
                "ops":[{"op":"call","args":["value"],
                    "out":[{"name":"result","type":"i32"}],"attrs":{"function":"recur"}}],
                "term":{"op":"ret","values":["result"]}}
            ]
        }]
    });
    let status=run(&doc,"recur",vec![json!(8)],1000);
    assert_eq!(status["status"],"budget_exceeded");
    assert_eq!(status["error"]["code"],"calls");
    // Root-inclusive Python depth budget admits exactly 32 frames (0..31),
    // each ticking once at entry and once at its recursive call operation.
    assert_eq!(status["steps"], json!(64));
}

#[test]
fn finite_recursion_respects_root_inclusive_call_frame_limit() {
    let program = json!({
        "schema": "hepta.hia.program.v1", "module": "finite_depth",
        "functions": [{
            "name": "count", "params": [{"name": "n", "type": "u32"}],
            "returns": ["u32"], "effects": ["trap"], "entry": "entry",
            "blocks": [
                {"id": "entry", "params": [{"name": "n", "type": "u32"}],
                 "ops": [
                    {"op": "const", "args": [],
                     "out": [{"name": "zero", "type": "u32"}], "attrs": {"value": 0}},
                    {"op": "compare.eq", "args": ["n", "zero"],
                     "out": [{"name": "done", "type": "bool"}], "attrs": {}}
                 ],
                 "term": {"op": "branch", "cond": "done",
                          "then": {"target": "complete", "args": ["n"]},
                          "else": {"target": "work", "args": ["n"]}}},
                {"id": "complete", "params": [{"name": "answer", "type": "u32"}],
                 "ops": [], "term": {"op": "ret", "values": ["answer"]}},
                {"id": "work", "params": [{"name": "remain", "type": "u32"}],
                 "ops": [
                    {"op": "const", "args": [],
                     "out": [{"name": "one", "type": "u32"}], "attrs": {"value": 1}},
                    {"op": "int.sub.checked", "args": ["remain", "one"],
                     "out": [{"name": "previous", "type": "u32"}], "attrs": {}},
                    {"op": "call", "args": ["previous"],
                     "out": [{"name": "result", "type": "u32"}],
                     "attrs": {"function": "count"}}
                 ],
                 "term": {"op": "ret", "values": ["result"]}}
            ]
        }]
    });
    for n in [0_u32, 1, 30, 31] {
        let outcome = run(&program, "count", vec![json!(n)], 10_000);
        assert_eq!(outcome["status"], "returned", "n={n}");
        assert_eq!(outcome["values"], json!([0]), "n={n}");
    }
    for n in [32_u32, 33] {
        let outcome = run(&program, "count", vec![json!(n)], 10_000);
        assert_eq!(outcome["status"], "budget_exceeded", "n={n}");
        assert_eq!(outcome["error"]["code"], "calls", "n={n}");
    }
}
