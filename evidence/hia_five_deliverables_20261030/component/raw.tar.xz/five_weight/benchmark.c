#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <inttypes.h>
extern uint64_t composed_case(size_t, size_t, uint8_t, size_t, uint32_t, uint32_t);
static uint64_t tick(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) abort();
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}
int main(int argc, char** argv) {
    if (argc != 3) return 10;
    size_t iterations = (size_t)strtoull(argv[1], NULL, 10);
    unsigned family = (unsigned)strtoul(argv[2], NULL, 10);
    uint64_t digest = UINT64_C(14695981039346656037);
    uint64_t started = tick();
    for (size_t i = 0; i < iterations; ++i) {
        size_t left = 3 + i % 255, right = 5 + i % 511;
        size_t limit = left < right ? left : right;
        uint32_t reject = family ? (uint32_t)(i % 17 == 0 ? 1 + i % 3 : 0) : 0;
        uint32_t early = family ? (uint32_t)(i % 4) : 0;
        uint64_t actual = composed_case(left, right, (uint8_t)i, i % limit, reject, early);
        digest = (digest ^ actual) * UINT64_C(1099511628211);
    }
    uint64_t elapsed = tick() - started;
    printf("{\"iterations\":%zu,\"family\":%u,\"elapsed_ns\":%" PRIu64 ",\"digest\":\"%016" PRIx64 "\"}\n",
           iterations, family, elapsed, digest);
    return 0;
}
