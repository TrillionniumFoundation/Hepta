/* Hepta independent C11/GCC backend. No Rust compiler involved. */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <inttypes.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
_Static_assert(CHAR_BIT == 8 && sizeof(size_t) == 8 && sizeof(intptr_t) == 8, "C backend requires the qualified 64-bit data model");
typedef struct { uint8_t h_f_tail_index; uint8_t h_f_head_index; size_t h_f_hepta_inline_extent_buffer; } __hepta_cb_aggregate_0;
typedef struct { int8_t *data; size_t len; } __hepta_cb_slice_1;
typedef struct { const int8_t *data; size_t len; } __hepta_cb_slice_2;
static inline int32_t __hepta_cb_i32_bits(uint64_t x) { uint32_t bits = (uint32_t)x; int32_t out; memcpy(&out, &bits, sizeof out); return out; }
static inline int32_t __hepta_cb_i32_add(int32_t a, int32_t b) { int32_t r; if (__builtin_add_overflow(a,b,&r)) abort(); return r; }
static inline int32_t __hepta_cb_i32_sub(int32_t a, int32_t b) { int32_t r; if (__builtin_sub_overflow(a,b,&r)) abort(); return r; }
static inline int32_t __hepta_cb_i32_mul(int32_t a, int32_t b) { int32_t r; if (__builtin_mul_overflow(a,b,&r)) abort(); return r; }
static inline int32_t __hepta_cb_i32_div(int32_t a, int32_t b) { if (b == 0 || (a == INT32_MIN && b == -1)) abort(); return a / b; }
static inline int32_t __hepta_cb_i32_rem(int32_t a, int32_t b) { if (b == 0 || (a == INT32_MIN && b == -1)) abort(); return a % b; }
static inline int32_t __hepta_cb_i32_wrapping_add(int32_t a, int32_t b) { return __hepta_cb_i32_bits((uint64_t)a + (uint64_t)b); }
static inline int32_t __hepta_cb_i32_wrapping_sub(int32_t a, int32_t b) { return __hepta_cb_i32_bits((uint64_t)a - (uint64_t)b); }
static inline int32_t __hepta_cb_i32_wrapping_mul(int32_t a, int32_t b) { return __hepta_cb_i32_bits((uint64_t)a * (uint64_t)b); }
static inline int32_t __hepta_cb_i32_and(int32_t a, int32_t b) { return __hepta_cb_i32_bits((uint64_t)a & (uint64_t)b); }
static inline int32_t __hepta_cb_i32_or(int32_t a, int32_t b) { return __hepta_cb_i32_bits((uint64_t)a | (uint64_t)b); }
static inline int32_t __hepta_cb_i32_xor(int32_t a, int32_t b) { return __hepta_cb_i32_bits((uint64_t)a ^ (uint64_t)b); }
static inline int32_t __hepta_cb_i32_min(int32_t a, int32_t b) { return a < b ? a : b; }
static inline int32_t __hepta_cb_i32_max(int32_t a, int32_t b) { return a > b ? a : b; }
static inline int32_t __hepta_cb_i32_shl(int32_t a, int32_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); return __hepta_cb_i32_bits((uint64_t)a << b); }
static inline int32_t __hepta_cb_i32_shr(int32_t a, int32_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); uint64_t x = (uint64_t)(uint32_t)a >> b; if (a < 0 && b) x |= UINT64_MAX << (sizeof(a)*CHAR_BIT - b); return __hepta_cb_i32_bits(x); }
static inline uint64_t __hepta_cb_u64_bits(uint64_t x) { uint64_t bits = (uint64_t)x; uint64_t out; memcpy(&out, &bits, sizeof out); return out; }
static inline uint64_t __hepta_cb_u64_add(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_add_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_sub(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_sub_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_mul(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_mul_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_div(uint64_t a, uint64_t b) { if (b == 0) abort(); return a / b; }
static inline uint64_t __hepta_cb_u64_rem(uint64_t a, uint64_t b) { if (b == 0) abort(); return a % b; }
static inline uint64_t __hepta_cb_u64_wrapping_add(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a + (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_wrapping_sub(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a - (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_wrapping_mul(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a * (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_and(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a & (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_or(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a | (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_xor(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a ^ (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_min(uint64_t a, uint64_t b) { return a < b ? a : b; }
static inline uint64_t __hepta_cb_u64_max(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline uint64_t __hepta_cb_u64_shl(uint64_t a, uint64_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); return __hepta_cb_u64_bits((uint64_t)a << b); }
static inline uint64_t __hepta_cb_u64_shr(uint64_t a, uint64_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); uint64_t x = (uint64_t)(uint64_t)a >> b; return __hepta_cb_u64_bits(x); }
static inline uint8_t __hepta_cb_u8_bits(uint64_t x) { uint8_t bits = (uint8_t)x; uint8_t out; memcpy(&out, &bits, sizeof out); return out; }
static inline uint8_t __hepta_cb_u8_add(uint8_t a, uint8_t b) { uint8_t r; if (__builtin_add_overflow(a,b,&r)) abort(); return r; }
static inline uint8_t __hepta_cb_u8_sub(uint8_t a, uint8_t b) { uint8_t r; if (__builtin_sub_overflow(a,b,&r)) abort(); return r; }
static inline uint8_t __hepta_cb_u8_mul(uint8_t a, uint8_t b) { uint8_t r; if (__builtin_mul_overflow(a,b,&r)) abort(); return r; }
static inline uint8_t __hepta_cb_u8_div(uint8_t a, uint8_t b) { if (b == 0) abort(); return a / b; }
static inline uint8_t __hepta_cb_u8_rem(uint8_t a, uint8_t b) { if (b == 0) abort(); return a % b; }
static inline uint8_t __hepta_cb_u8_wrapping_add(uint8_t a, uint8_t b) { return __hepta_cb_u8_bits((uint64_t)a + (uint64_t)b); }
static inline uint8_t __hepta_cb_u8_wrapping_sub(uint8_t a, uint8_t b) { return __hepta_cb_u8_bits((uint64_t)a - (uint64_t)b); }
static inline uint8_t __hepta_cb_u8_wrapping_mul(uint8_t a, uint8_t b) { return __hepta_cb_u8_bits((uint64_t)a * (uint64_t)b); }
static inline uint8_t __hepta_cb_u8_and(uint8_t a, uint8_t b) { return __hepta_cb_u8_bits((uint64_t)a & (uint64_t)b); }
static inline uint8_t __hepta_cb_u8_or(uint8_t a, uint8_t b) { return __hepta_cb_u8_bits((uint64_t)a | (uint64_t)b); }
static inline uint8_t __hepta_cb_u8_xor(uint8_t a, uint8_t b) { return __hepta_cb_u8_bits((uint64_t)a ^ (uint64_t)b); }
static inline uint8_t __hepta_cb_u8_min(uint8_t a, uint8_t b) { return a < b ? a : b; }
static inline uint8_t __hepta_cb_u8_max(uint8_t a, uint8_t b) { return a > b ? a : b; }
static inline uint8_t __hepta_cb_u8_shl(uint8_t a, uint8_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); return __hepta_cb_u8_bits((uint64_t)a << b); }
static inline uint8_t __hepta_cb_u8_shr(uint8_t a, uint8_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); uint64_t x = (uint64_t)(uint8_t)a >> b; return __hepta_cb_u8_bits(x); }
static inline size_t __hepta_cb_usize_bits(uint64_t x) { size_t bits = (size_t)x; size_t out; memcpy(&out, &bits, sizeof out); return out; }
static inline size_t __hepta_cb_usize_add(size_t a, size_t b) { size_t r; if (__builtin_add_overflow(a,b,&r)) abort(); return r; }
static inline size_t __hepta_cb_usize_sub(size_t a, size_t b) { size_t r; if (__builtin_sub_overflow(a,b,&r)) abort(); return r; }
static inline size_t __hepta_cb_usize_mul(size_t a, size_t b) { size_t r; if (__builtin_mul_overflow(a,b,&r)) abort(); return r; }
static inline size_t __hepta_cb_usize_div(size_t a, size_t b) { if (b == 0) abort(); return a / b; }
static inline size_t __hepta_cb_usize_rem(size_t a, size_t b) { if (b == 0) abort(); return a % b; }
static inline size_t __hepta_cb_usize_wrapping_add(size_t a, size_t b) { return __hepta_cb_usize_bits((uint64_t)a + (uint64_t)b); }
static inline size_t __hepta_cb_usize_wrapping_sub(size_t a, size_t b) { return __hepta_cb_usize_bits((uint64_t)a - (uint64_t)b); }
static inline size_t __hepta_cb_usize_wrapping_mul(size_t a, size_t b) { return __hepta_cb_usize_bits((uint64_t)a * (uint64_t)b); }
static inline size_t __hepta_cb_usize_and(size_t a, size_t b) { return __hepta_cb_usize_bits((uint64_t)a & (uint64_t)b); }
static inline size_t __hepta_cb_usize_or(size_t a, size_t b) { return __hepta_cb_usize_bits((uint64_t)a | (uint64_t)b); }
static inline size_t __hepta_cb_usize_xor(size_t a, size_t b) { return __hepta_cb_usize_bits((uint64_t)a ^ (uint64_t)b); }
static inline size_t __hepta_cb_usize_min(size_t a, size_t b) { return a < b ? a : b; }
static inline size_t __hepta_cb_usize_max(size_t a, size_t b) { return a > b ? a : b; }
static inline size_t __hepta_cb_usize_shl(size_t a, size_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); return __hepta_cb_usize_bits((uint64_t)a << b); }
static inline size_t __hepta_cb_usize_shr(size_t a, size_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); uint64_t x = (uint64_t)(size_t)a >> b; return __hepta_cb_usize_bits(x); }



int32_t __hepta_cb_fn_c_bool_to_int(bool h_value);
size_t __hepta_cb_fn_c_view_index_unsigned(size_t h_offset, uint64_t h_index, size_t h_length);
size_t __hepta_cb_fn_c_view_index_signed(size_t h_offset, int64_t h_index, size_t h_length);
uint8_t __hepta_cb_fn_c_ring_buffer_dequeue(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_1 h_p_data, size_t h_p_data_offset);
uint8_t __hepta_cb_fn_c_ring_buffer_dequeue_arr(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_1 h_p_data, size_t h_p_data_offset, uint8_t h_p_len);
void __hepta_cb_fn_c_ring_buffer_init(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer);
uint8_t __hepta_cb_fn_c_ring_buffer_is_empty(const __hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_2 h_p_buffer_f_buffer);
uint8_t __hepta_cb_fn_c_ring_buffer_is_full(const __hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_2 h_p_buffer_f_buffer);
uint8_t __hepta_cb_fn_c_ring_buffer_num_items(const __hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_2 h_p_buffer_f_buffer);
uint8_t __hepta_cb_fn_c_ring_buffer_peek(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_1 h_p_data, size_t h_p_data_offset, uint8_t h_p_index);
void __hepta_cb_fn_c_ring_buffer_queue(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, int8_t h_p_data);
void __hepta_cb_fn_c_ring_buffer_queue_arr(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_2 h_p_data, size_t h_p_data_offset, uint8_t h_p_size);
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_fn_c_bool_to_int(bool h_value) {
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v1 = h_value;
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v1) { 
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v2 = (int32_t)INT64_C(1);
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v2; } else { 
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v3 = (int32_t)INT64_C(0);
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v3; }
#line 5 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 7 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_fn_c_view_index_unsigned(size_t h_offset, uint64_t h_index, size_t h_length) {
#line 8 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v4 = h_offset;
#line 8 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v5 = h_length;
#line 8 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v6 = (__hepta_cb_v4 < __hepta_cb_v5);
#line 8 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v6) abort();
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v7 = h_index;
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v8 = h_length;
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v9 = h_offset;
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v10 = __hepta_cb_usize_sub(__hepta_cb_v8, __hepta_cb_v9);
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v11 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v10);
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v12 = (__hepta_cb_v7 < __hepta_cb_v11);
#line 9 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v12) abort();
#line 10 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v13 = h_offset;
#line 10 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v14 = h_index;
#line 10 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v15 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v14);
#line 10 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v16 = __hepta_cb_usize_add(__hepta_cb_v13, __hepta_cb_v15);
#line 10 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v16;
#line 10 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 13 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_fn_c_view_index_signed(size_t h_offset, int64_t h_index, size_t h_length) {
#line 14 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v17 = h_index;
#line 14 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v18 = (int64_t)INT64_C(0);
#line 14 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v19 = (__hepta_cb_v17 >= __hepta_cb_v18);
#line 14 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v19) { 
#line 15 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v20 = h_offset;
#line 15 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v21 = h_length;
#line 15 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v22 = (__hepta_cb_v20 < __hepta_cb_v21);
#line 15 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v22) abort();
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v23 = h_index;
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v24 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v23);
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v25 = h_length;
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v26 = h_offset;
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v27 = __hepta_cb_usize_sub(__hepta_cb_v25, __hepta_cb_v26);
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v28 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v27);
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v29 = (__hepta_cb_v24 < __hepta_cb_v28);
#line 16 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v29) abort();
#line 17 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v30 = h_offset;
#line 17 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v31 = h_index;
#line 17 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v32 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v31);
#line 17 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v33 = __hepta_cb_usize_add(__hepta_cb_v30, __hepta_cb_v32);
#line 17 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v33; } else {  }
#line 19 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v34 = (int64_t)INT64_C(0);
#line 19 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v35 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v34);
#line 19 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v36 = h_index;
#line 19 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v37 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v36);
#line 19 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v38 = __hepta_cb_u64_wrapping_sub(__hepta_cb_v35, __hepta_cb_v37);
#line 19 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t h_magnitude = __hepta_cb_v38;
#line 20 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v39 = h_magnitude;
#line 20 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v40 = h_offset;
#line 20 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v41 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v40);
#line 20 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v42 = (__hepta_cb_v39 <= __hepta_cb_v41);
#line 20 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v42) abort();
#line 21 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v43 = h_offset;
#line 21 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v44 = h_magnitude;
#line 21 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v45 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v44);
#line 21 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v46 = __hepta_cb_usize_sub(__hepta_cb_v43, __hepta_cb_v45);
#line 21 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t h_absolute = __hepta_cb_v46;
#line 22 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v47 = h_absolute;
#line 22 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v48 = h_length;
#line 22 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v49 = (__hepta_cb_v47 < __hepta_cb_v48);
#line 22 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v49) abort();
#line 23 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v50 = h_absolute;
#line 23 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v50;
#line 23 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 28 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_fn_c_ring_buffer_dequeue(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_1 h_p_data, size_t h_p_data_offset) {
#line 29 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v51 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 29 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v52 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v51);
#line 29 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v53 = (h_p_buffer_f_buffer).len;
#line 29 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v54 = (__hepta_cb_v52 <= __hepta_cb_v53);
#line 29 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v54) abort();
#line 30 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v55 = h_p_data_offset;
#line 30 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v56 = (h_p_data).len;
#line 30 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v57 = (__hepta_cb_v55 <= __hepta_cb_v56);
#line 30 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v57) abort();
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v58 = (int64_t)INT64_C(1);
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v59 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v58);
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v60 = (h_p_data).len;
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v61 = h_p_data_offset;
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v62 = __hepta_cb_usize_sub(__hepta_cb_v60, __hepta_cb_v61);
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v63 = (__hepta_cb_v59 <= __hepta_cb_v62);
#line 31 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v63) abort();
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
const __hepta_cb_aggregate_0 * __hepta_cb_arg64 = &((*h_p_buffer));
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_slice_2 __hepta_cb_arg65 = (__hepta_cb_slice_2){(h_p_buffer_f_buffer).data, (h_p_buffer_f_buffer).len};
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v66 = __hepta_cb_fn_c_ring_buffer_is_empty(__hepta_cb_arg64, __hepta_cb_arg65);
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v67 = (int64_t)INT64_C(0);
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v68 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v67);
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v69 = (__hepta_cb_v66 != __hepta_cb_v68);
#line 32 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v69) { 
#line 33 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v70 = (int64_t)INT64_C(0);
#line 33 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v71 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v70);
#line 33 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v72 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v71);
#line 33 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v72; } else {  }
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v73 = (int64_t)INT64_C(0);
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v74 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v73);
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v75 = ((*h_p_buffer)).h_f_tail_index;
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v76 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v75);
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v77 = (h_p_buffer_f_buffer).len;
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v78 = __hepta_cb_fn_c_view_index_unsigned(__hepta_cb_v74, __hepta_cb_v76, __hepta_cb_v77);
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v78 >= (h_p_buffer_f_buffer).len) abort();
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int8_t __hepta_cb_v79 = ((h_p_buffer_f_buffer).data)[__hepta_cb_v78];
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v80 = h_p_data_offset;
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v80 >= (h_p_data).len) abort();
#line 35 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((h_p_data).data)[__hepta_cb_v80] = __hepta_cb_v79;
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v81 = ((*h_p_buffer)).h_f_tail_index;
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v82 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v81);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v83 = (int64_t)INT64_C(1);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v84 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v83);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v85 = __hepta_cb_i32_add(__hepta_cb_v82, __hepta_cb_v84);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v86 = (int64_t)INT64_C(128);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v87 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v86);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v88 = (int64_t)INT64_C(1);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v89 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v88);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v90 = __hepta_cb_i32_sub(__hepta_cb_v87, __hepta_cb_v89);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v91 = __hepta_cb_i32_and(__hepta_cb_v85, __hepta_cb_v90);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v92 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v91);
#line 36 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((*h_p_buffer)).h_f_tail_index = __hepta_cb_v92;
#line 37 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v93 = (int64_t)INT64_C(1);
#line 37 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v94 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v93);
#line 37 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v95 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v94);
#line 37 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v95;
#line 37 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 40 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_fn_c_ring_buffer_dequeue_arr(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_1 h_p_data, size_t h_p_data_offset, uint8_t h_p_len) {
#line 41 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v96 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 41 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v97 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v96);
#line 41 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v98 = (h_p_buffer_f_buffer).len;
#line 41 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v99 = (__hepta_cb_v97 <= __hepta_cb_v98);
#line 41 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v99) abort();
#line 42 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v100 = h_p_data_offset;
#line 42 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v101 = (h_p_data).len;
#line 42 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v102 = (__hepta_cb_v100 <= __hepta_cb_v101);
#line 42 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v102) abort();
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v103 = h_p_len;
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v104 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v103);
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v105 = (h_p_data).len;
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v106 = h_p_data_offset;
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v107 = __hepta_cb_usize_sub(__hepta_cb_v105, __hepta_cb_v106);
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v108 = (__hepta_cb_v104 <= __hepta_cb_v107);
#line 43 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v108) abort();
#line 44 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v109 = h_p_len;
#line 44 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t h_v_len = __hepta_cb_v109;
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
const __hepta_cb_aggregate_0 * __hepta_cb_arg110 = &((*h_p_buffer));
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_slice_2 __hepta_cb_arg111 = (__hepta_cb_slice_2){(h_p_buffer_f_buffer).data, (h_p_buffer_f_buffer).len};
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v112 = __hepta_cb_fn_c_ring_buffer_is_empty(__hepta_cb_arg110, __hepta_cb_arg111);
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v113 = (int64_t)INT64_C(0);
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v114 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v113);
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v115 = (__hepta_cb_v112 != __hepta_cb_v114);
#line 45 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v115) { 
#line 46 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v116 = (int64_t)INT64_C(0);
#line 46 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v117 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v116);
#line 46 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v118 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v117);
#line 46 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v118; } else {  }
#line 48 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v119 = h_p_data_offset;
#line 48 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t h_cursor_data_ptr_1_offset = __hepta_cb_v119;
#line 49 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v120 = (int64_t)INT64_C(0);
#line 49 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v121 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v120);
#line 49 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v122 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v121);
#line 49 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t h_v_cnt_2 = __hepta_cb_v122;
#line 50 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
while (true) { uint8_t __hepta_cb_v123 = h_v_cnt_2; int32_t __hepta_cb_v124 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v123); uint8_t __hepta_cb_v125 = h_v_len; int32_t __hepta_cb_v126 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v125); bool __hepta_cb_v127 = (__hepta_cb_v124 < __hepta_cb_v126); bool __hepta_cb_v128 = __hepta_cb_v127; if (__hepta_cb_v128) { __hepta_cb_aggregate_0 * __hepta_cb_arg129 = &((*h_p_buffer)); __hepta_cb_slice_1 __hepta_cb_arg130 = (__hepta_cb_slice_1){(h_p_buffer_f_buffer).data, (h_p_buffer_f_buffer).len}; __hepta_cb_slice_1 __hepta_cb_arg131 = (__hepta_cb_slice_1){(h_p_data).data, (h_p_data).len}; size_t __hepta_cb_v132 = h_cursor_data_ptr_1_offset; uint8_t __hepta_cb_v133 = __hepta_cb_fn_c_ring_buffer_dequeue(__hepta_cb_arg129, __hepta_cb_arg130, __hepta_cb_arg131, __hepta_cb_v132); int32_t __hepta_cb_v134 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v133); int64_t __hepta_cb_v135 = (int64_t)INT64_C(0); int32_t __hepta_cb_v136 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v135); bool __hepta_cb_v137 = (__hepta_cb_v134 != __hepta_cb_v136); __hepta_cb_v128 = __hepta_cb_v137; } if (!__hepta_cb_v128) break; 
#line 51 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v138 = h_v_cnt_2;
#line 51 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v139 = (int64_t)INT64_C(1);
#line 51 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v140 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v139);
#line 51 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v141 = __hepta_cb_u8_wrapping_add(__hepta_cb_v138, __hepta_cb_v140);
#line 51 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
h_v_cnt_2 = __hepta_cb_v141;
#line 52 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v142 = h_cursor_data_ptr_1_offset;
#line 52 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v143 = (int64_t)INT64_C(1);
#line 52 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v144 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v143);
#line 52 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v145 = __hepta_cb_usize_add(__hepta_cb_v142, __hepta_cb_v144);
#line 52 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
h_cursor_data_ptr_1_offset = __hepta_cb_v145;
#line 53 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v146 = h_cursor_data_ptr_1_offset;
#line 53 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v147 = (h_p_data).len;
#line 53 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v148 = (__hepta_cb_v146 <= __hepta_cb_v147);
#line 53 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v148) abort(); }
#line 55 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v149 = h_v_cnt_2;
#line 55 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v149;
#line 55 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 58 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
void __hepta_cb_fn_c_ring_buffer_init(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer) {
#line 59 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v150 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 59 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v151 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v150);
#line 59 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v152 = (h_p_buffer_f_buffer).len;
#line 59 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v153 = (__hepta_cb_v151 <= __hepta_cb_v152);
#line 59 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v153) abort();
#line 60 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v154 = (int64_t)INT64_C(0);
#line 60 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v155 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v154);
#line 60 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v156 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v155);
#line 60 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((*h_p_buffer)).h_f_tail_index = __hepta_cb_v156;
#line 61 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v157 = (int64_t)INT64_C(0);
#line 61 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v158 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v157);
#line 61 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v159 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v158);
#line 61 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((*h_p_buffer)).h_f_head_index = __hepta_cb_v159;
#line 61 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 64 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_fn_c_ring_buffer_is_empty(const __hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_2 h_p_buffer_f_buffer) {
#line 65 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v160 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 65 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v161 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v160);
#line 65 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v162 = (h_p_buffer_f_buffer).len;
#line 65 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v163 = (__hepta_cb_v161 <= __hepta_cb_v162);
#line 65 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v163) abort();
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v164 = ((*h_p_buffer)).h_f_head_index;
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v165 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v164);
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v166 = ((*h_p_buffer)).h_f_tail_index;
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v167 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v166);
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v168 = (__hepta_cb_v165 == __hepta_cb_v167);
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v169 = __hepta_cb_fn_c_bool_to_int(__hepta_cb_v168);
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v170 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v169);
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v170;
#line 66 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 69 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_fn_c_ring_buffer_is_full(const __hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_2 h_p_buffer_f_buffer) {
#line 70 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v171 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 70 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v172 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v171);
#line 70 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v173 = (h_p_buffer_f_buffer).len;
#line 70 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v174 = (__hepta_cb_v172 <= __hepta_cb_v173);
#line 70 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v174) abort();
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v175 = ((*h_p_buffer)).h_f_head_index;
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v176 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v175);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v177 = ((*h_p_buffer)).h_f_tail_index;
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v178 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v177);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v179 = __hepta_cb_i32_sub(__hepta_cb_v176, __hepta_cb_v178);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v180 = (int64_t)INT64_C(128);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v181 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v180);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v182 = (int64_t)INT64_C(1);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v183 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v182);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v184 = __hepta_cb_i32_sub(__hepta_cb_v181, __hepta_cb_v183);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v185 = __hepta_cb_i32_and(__hepta_cb_v179, __hepta_cb_v184);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v186 = (int64_t)INT64_C(128);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v187 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v186);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v188 = (int64_t)INT64_C(1);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v189 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v188);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v190 = __hepta_cb_i32_sub(__hepta_cb_v187, __hepta_cb_v189);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v191 = (__hepta_cb_v185 == __hepta_cb_v190);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v192 = __hepta_cb_fn_c_bool_to_int(__hepta_cb_v191);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v193 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v192);
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v193;
#line 71 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 74 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_fn_c_ring_buffer_num_items(const __hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_2 h_p_buffer_f_buffer) {
#line 75 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v194 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 75 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v195 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v194);
#line 75 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v196 = (h_p_buffer_f_buffer).len;
#line 75 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v197 = (__hepta_cb_v195 <= __hepta_cb_v196);
#line 75 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v197) abort();
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v198 = ((*h_p_buffer)).h_f_head_index;
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v199 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v198);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v200 = ((*h_p_buffer)).h_f_tail_index;
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v201 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v200);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v202 = __hepta_cb_i32_sub(__hepta_cb_v199, __hepta_cb_v201);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v203 = (int64_t)INT64_C(128);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v204 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v203);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v205 = (int64_t)INT64_C(1);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v206 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v205);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v207 = __hepta_cb_i32_sub(__hepta_cb_v204, __hepta_cb_v206);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v208 = __hepta_cb_i32_and(__hepta_cb_v202, __hepta_cb_v207);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v209 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v208);
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v209;
#line 76 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 79 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_fn_c_ring_buffer_peek(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_1 h_p_data, size_t h_p_data_offset, uint8_t h_p_index) {
#line 80 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v210 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 80 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v211 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v210);
#line 80 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v212 = (h_p_buffer_f_buffer).len;
#line 80 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v213 = (__hepta_cb_v211 <= __hepta_cb_v212);
#line 80 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v213) abort();
#line 81 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v214 = h_p_data_offset;
#line 81 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v215 = (h_p_data).len;
#line 81 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v216 = (__hepta_cb_v214 <= __hepta_cb_v215);
#line 81 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v216) abort();
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v217 = (int64_t)INT64_C(1);
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v218 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v217);
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v219 = (h_p_data).len;
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v220 = h_p_data_offset;
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v221 = __hepta_cb_usize_sub(__hepta_cb_v219, __hepta_cb_v220);
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v222 = (__hepta_cb_v218 <= __hepta_cb_v221);
#line 82 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v222) abort();
#line 83 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v223 = h_p_index;
#line 83 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t h_v_index = __hepta_cb_v223;
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v224 = h_v_index;
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v225 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v224);
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
const __hepta_cb_aggregate_0 * __hepta_cb_arg226 = &((*h_p_buffer));
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_slice_2 __hepta_cb_arg227 = (__hepta_cb_slice_2){(h_p_buffer_f_buffer).data, (h_p_buffer_f_buffer).len};
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v228 = __hepta_cb_fn_c_ring_buffer_num_items(__hepta_cb_arg226, __hepta_cb_arg227);
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v229 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v228);
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v230 = (__hepta_cb_v225 >= __hepta_cb_v229);
#line 84 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v230) { 
#line 85 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v231 = (int64_t)INT64_C(0);
#line 85 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v232 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v231);
#line 85 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v233 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v232);
#line 85 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v233; } else {  }
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v234 = ((*h_p_buffer)).h_f_tail_index;
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v235 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v234);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v236 = h_v_index;
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v237 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v236);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v238 = __hepta_cb_i32_add(__hepta_cb_v235, __hepta_cb_v237);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v239 = (int64_t)INT64_C(128);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v240 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v239);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v241 = (int64_t)INT64_C(1);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v242 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v241);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v243 = __hepta_cb_i32_sub(__hepta_cb_v240, __hepta_cb_v242);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v244 = __hepta_cb_i32_and(__hepta_cb_v238, __hepta_cb_v243);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v245 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v244);
#line 87 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t h_v_data_index_1 = __hepta_cb_v245;
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v246 = (int64_t)INT64_C(0);
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v247 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v246);
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v248 = h_v_data_index_1;
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v249 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v248);
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v250 = (h_p_buffer_f_buffer).len;
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v251 = __hepta_cb_fn_c_view_index_unsigned(__hepta_cb_v247, __hepta_cb_v249, __hepta_cb_v250);
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v251 >= (h_p_buffer_f_buffer).len) abort();
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int8_t __hepta_cb_v252 = ((h_p_buffer_f_buffer).data)[__hepta_cb_v251];
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v253 = h_p_data_offset;
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v253 >= (h_p_data).len) abort();
#line 88 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((h_p_data).data)[__hepta_cb_v253] = __hepta_cb_v252;
#line 89 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v254 = (int64_t)INT64_C(1);
#line 89 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v255 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v254);
#line 89 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v256 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v255);
#line 89 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
return __hepta_cb_v256;
#line 89 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 92 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
void __hepta_cb_fn_c_ring_buffer_queue(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, int8_t h_p_data) {
#line 93 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v257 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 93 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v258 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v257);
#line 93 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v259 = (h_p_buffer_f_buffer).len;
#line 93 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v260 = (__hepta_cb_v258 <= __hepta_cb_v259);
#line 93 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v260) abort();
#line 94 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int8_t __hepta_cb_v261 = h_p_data;
#line 94 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int8_t h_v_data = __hepta_cb_v261;
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
const __hepta_cb_aggregate_0 * __hepta_cb_arg262 = &((*h_p_buffer));
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_slice_2 __hepta_cb_arg263 = (__hepta_cb_slice_2){(h_p_buffer_f_buffer).data, (h_p_buffer_f_buffer).len};
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v264 = __hepta_cb_fn_c_ring_buffer_is_full(__hepta_cb_arg262, __hepta_cb_arg263);
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v265 = (int64_t)INT64_C(0);
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v266 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v265);
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v267 = (__hepta_cb_v264 != __hepta_cb_v266);
#line 95 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v267) { 
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v268 = ((*h_p_buffer)).h_f_tail_index;
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v269 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v268);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v270 = (int64_t)INT64_C(1);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v271 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v270);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v272 = __hepta_cb_i32_add(__hepta_cb_v269, __hepta_cb_v271);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v273 = (int64_t)INT64_C(128);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v274 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v273);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v275 = (int64_t)INT64_C(1);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v276 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v275);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v277 = __hepta_cb_i32_sub(__hepta_cb_v274, __hepta_cb_v276);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v278 = __hepta_cb_i32_and(__hepta_cb_v272, __hepta_cb_v277);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v279 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v278);
#line 96 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((*h_p_buffer)).h_f_tail_index = __hepta_cb_v279; } else {  }
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int8_t __hepta_cb_v280 = h_v_data;
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v281 = (int64_t)INT64_C(0);
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v282 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v281);
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v283 = ((*h_p_buffer)).h_f_head_index;
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v284 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v283);
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v285 = (h_p_buffer_f_buffer).len;
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v286 = __hepta_cb_fn_c_view_index_unsigned(__hepta_cb_v282, __hepta_cb_v284, __hepta_cb_v285);
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v286 >= (h_p_buffer_f_buffer).len) abort();
#line 98 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((h_p_buffer_f_buffer).data)[__hepta_cb_v286] = __hepta_cb_v280;
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v287 = ((*h_p_buffer)).h_f_head_index;
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v288 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v287);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v289 = (int64_t)INT64_C(1);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v290 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v289);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v291 = __hepta_cb_i32_add(__hepta_cb_v288, __hepta_cb_v290);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v292 = (int64_t)INT64_C(128);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v293 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v292);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v294 = (int64_t)INT64_C(1);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v295 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v294);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v296 = __hepta_cb_i32_sub(__hepta_cb_v293, __hepta_cb_v295);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v297 = __hepta_cb_i32_and(__hepta_cb_v291, __hepta_cb_v296);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v298 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v297);
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
((*h_p_buffer)).h_f_head_index = __hepta_cb_v298;
#line 99 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}
#line 102 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
void __hepta_cb_fn_c_ring_buffer_queue_arr(__hepta_cb_aggregate_0 *h_p_buffer, __hepta_cb_slice_1 h_p_buffer_f_buffer, __hepta_cb_slice_2 h_p_data, size_t h_p_data_offset, uint8_t h_p_size) {
#line 103 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v299 = ((*h_p_buffer)).h_f_hepta_inline_extent_buffer;
#line 103 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v300 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v299);
#line 103 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v301 = (h_p_buffer_f_buffer).len;
#line 103 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v302 = (__hepta_cb_v300 <= __hepta_cb_v301);
#line 103 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v302) abort();
#line 104 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v303 = h_p_data_offset;
#line 104 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v304 = (h_p_data).len;
#line 104 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v305 = (__hepta_cb_v303 <= __hepta_cb_v304);
#line 104 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v305) abort();
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v306 = h_p_size;
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v307 = __hepta_cb_usize_bits((uint64_t)__hepta_cb_v306);
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v308 = (h_p_data).len;
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v309 = h_p_data_offset;
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v310 = __hepta_cb_usize_sub(__hepta_cb_v308, __hepta_cb_v309);
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
bool __hepta_cb_v311 = (__hepta_cb_v307 <= __hepta_cb_v310);
#line 105 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (!__hepta_cb_v311) abort();
#line 106 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v312 = h_p_size;
#line 106 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t h_v_size = __hepta_cb_v312;
#line 107 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v313 = (int64_t)INT64_C(0);
#line 107 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int32_t __hepta_cb_v314 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v313);
#line 107 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v315 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v314);
#line 107 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t h_v_i_1 = __hepta_cb_v315;
#line 108 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
while (true) { uint8_t __hepta_cb_v316 = h_v_i_1; int32_t __hepta_cb_v317 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v316); uint8_t __hepta_cb_v318 = h_v_size; int32_t __hepta_cb_v319 = __hepta_cb_i32_bits((uint64_t)__hepta_cb_v318); bool __hepta_cb_v320 = (__hepta_cb_v317 < __hepta_cb_v319); if (!__hepta_cb_v320) break; 
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg321 = &((*h_p_buffer));
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_slice_1 __hepta_cb_arg322 = (__hepta_cb_slice_1){(h_p_buffer_f_buffer).data, (h_p_buffer_f_buffer).len};
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v323 = h_p_data_offset;
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v324 = h_v_i_1;
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint64_t __hepta_cb_v325 = __hepta_cb_u64_bits((uint64_t)__hepta_cb_v324);
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v326 = (h_p_data).len;
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
size_t __hepta_cb_v327 = __hepta_cb_fn_c_view_index_unsigned(__hepta_cb_v323, __hepta_cb_v325, __hepta_cb_v326);
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
if (__hepta_cb_v327 >= (h_p_data).len) abort();
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int8_t __hepta_cb_v328 = ((h_p_data).data)[__hepta_cb_v327];
#line 109 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
__hepta_cb_fn_c_ring_buffer_queue(__hepta_cb_arg321, __hepta_cb_arg322, __hepta_cb_v328);
#line 110 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v329 = h_v_i_1;
#line 110 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
int64_t __hepta_cb_v330 = (int64_t)INT64_C(1);
#line 110 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v331 = __hepta_cb_u8_bits((uint64_t)__hepta_cb_v330);
#line 110 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
uint8_t __hepta_cb_v332 = __hepta_cb_u8_wrapping_add(__hepta_cb_v329, __hepta_cb_v331);
#line 110 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
h_v_i_1 = __hepta_cb_v332; }
#line 110 "/dev/shm/hepta-continuation-793cbcdf54ed/migration/development-inline-03/after-translated/source.hepta"
}


/* Caller-unsafe C ABI; no byte payload is copied or initialized by this edge. */
typedef struct { uintptr_t lo, hi; } __hia_inline_range_t;
static __hia_inline_range_t __hia_inline_range(uintptr_t p, size_t n, size_t s, size_t a) {
    if ((n && (!p || p % a)) || n > (size_t)PTRDIFF_MAX / s || n > (UINTPTR_MAX - p) / s) abort();
    return (__hia_inline_range_t){p, p + n*s};
}
static void __hia_inline_disjoint(__hia_inline_range_t a, __hia_inline_range_t b) {
    if (a.lo < a.hi && b.lo < b.hi && a.lo < b.hi && b.lo < a.hi) abort();
}


typedef struct ring_buffer_t {
    char buffer[128];
    uint8_t tail_index;
    uint8_t head_index;
} ring_buffer_t;

typedef uint8_t ring_buffer_size_t;

uint8_t ring_buffer_dequeue(ring_buffer_t * b_buffer, char * b_data) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = 1;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    uint8_t result = __hepta_cb_fn_c_ring_buffer_dequeue(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_1){(int8_t *)b_data, n_b_data}, 0);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return result;
}

uint8_t ring_buffer_dequeue_arr(ring_buffer_t * b_buffer, char * b_data, ring_buffer_size_t b_len) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = (size_t)b_len;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    uint8_t result = __hepta_cb_fn_c_ring_buffer_dequeue_arr(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_1){(int8_t *)b_data, n_b_data}, 0, b_len);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return result;
}

void ring_buffer_init(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = 0, .h_f_head_index = 0, .h_f_hepta_inline_extent_buffer = 128};
    (void)__hepta_cb_fn_c_ring_buffer_init(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128});
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return;
}

uint8_t ring_buffer_is_empty(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    uint8_t result = __hepta_cb_fn_c_ring_buffer_is_empty(&s_b_buffer, (__hepta_cb_slice_2){(int8_t *)b_buffer->buffer, 128});
    return result;
}

uint8_t ring_buffer_is_full(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    uint8_t result = __hepta_cb_fn_c_ring_buffer_is_full(&s_b_buffer, (__hepta_cb_slice_2){(int8_t *)b_buffer->buffer, 128});
    return result;
}

ring_buffer_size_t ring_buffer_num_items(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    ring_buffer_size_t result = __hepta_cb_fn_c_ring_buffer_num_items(&s_b_buffer, (__hepta_cb_slice_2){(int8_t *)b_buffer->buffer, 128});
    return result;
}

uint8_t ring_buffer_peek(ring_buffer_t * b_buffer, char * b_data, ring_buffer_size_t b_index) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = 1;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    uint8_t result = __hepta_cb_fn_c_ring_buffer_peek(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_1){(int8_t *)b_data, n_b_data}, 0, b_index);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return result;
}

void ring_buffer_queue(ring_buffer_t * b_buffer, char b_data) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    (void)__hepta_cb_fn_c_ring_buffer_queue(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, b_data);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return;
}

void ring_buffer_queue_arr(ring_buffer_t * b_buffer, const char * b_data, ring_buffer_size_t b_size) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = (size_t)b_size;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    (void)__hepta_cb_fn_c_ring_buffer_queue_arr(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_2){(const int8_t *)b_data, n_b_data}, 0, b_size);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return;
}
