from hashlib import sha256
import json, os
from pathlib import Path
import subprocess, sys, time
configuration = json.loads(Path(__file__).with_suffix('.json').read_text())
def check(record):
    path = Path(record['path'])
    if not path.is_file() or path.stat().st_size != record['bytes'] or sha256(path.read_bytes()).hexdigest() != record['sha256']:
        raise SystemExit('CC integration input identity changed')
for key in ('compiler', 'original', 'replacement'):
    check(configuration[key])
arguments = sys.argv[1:]
original = Path(configuration['original']['path']).resolve()
hits = [i for i, value in enumerate(arguments) if not value.startswith('-') and Path(value).resolve() == original]
if len(hits) != 1 or '-c' in arguments or '-o' not in arguments:
    raise SystemExit('CC integration accepts exactly one expected implementation in a link invocation')
result = list(arguments)
result[hits[0]] = configuration['replacement']['path']
result.append('-Wl,-rpath,' + str(Path(configuration['replacement']['path']).parent))
command = [configuration['compiler']['path'], *result]
started = time.perf_counter_ns()
process = subprocess.run(command)
row = {'original_arguments': arguments, 'executed_argv': command, 'cwd': os.getcwd(),
       'replaced_original': configuration['original'], 'replacement': configuration['replacement'],
       'returncode': process.returncode, 'wall_ns': time.perf_counter_ns() - started}
with Path(configuration['log']).open('a') as stream:
    stream.write(json.dumps(row, sort_keys=True) + '\n')
for key in ('compiler', 'original', 'replacement'):
    check(configuration[key])
raise SystemExit(process.returncode)
