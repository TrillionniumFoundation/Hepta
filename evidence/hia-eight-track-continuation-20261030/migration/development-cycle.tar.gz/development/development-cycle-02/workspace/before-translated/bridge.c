
/* Caller-unsafe C ABI; no byte payload is copied or initialized by this edge. */
typedef struct { uintptr_t lo, hi; } __hia_inline_range_t;
static __hia_inline_range_t __hia_inline_range(uintptr_t p, size_t n, size_t s, size_t a) {
    if ((n && (!p || p % a)) || n > (size_t)PTRDIFF_MAX / s || n > (UINTPTR_MAX - p) / s) abort();
    return (__hia_inline_range_t){p, p + n*s};
}
static void __hia_inline_disjoint(__hia_inline_range_t a, __hia_inline_range_t b) {
    if (a.lo < a.hi && b.lo < b.hi && a.lo < b.hi && b.lo < a.hi) abort();
}


typedef struct ring_buffer_t {
    char buffer[128];
    uint8_t tail_index;
    uint8_t head_index;
} ring_buffer_t;

typedef uint8_t ring_buffer_size_t;

uint8_t ring_buffer_dequeue(ring_buffer_t * b_buffer, char * b_data) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = 1;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    uint8_t result = __hepta_cb_fn_c_ring_buffer_dequeue(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_1){(int8_t *)b_data, n_b_data}, 0);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return result;
}

uint8_t ring_buffer_dequeue_arr(ring_buffer_t * b_buffer, char * b_data, ring_buffer_size_t b_len) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    if ((size_t)b_len == SIZE_MAX) abort();
    size_t n_b_data = ((size_t)b_len + 1);
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    uint8_t result = __hepta_cb_fn_c_ring_buffer_dequeue_arr(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_1){(int8_t *)b_data, n_b_data}, 0, b_len);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return result;
}

void ring_buffer_init(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = 0, .h_f_head_index = 0, .h_f_hepta_inline_extent_buffer = 128};
    (void)__hepta_cb_fn_c_ring_buffer_init(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128});
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return;
}

uint8_t ring_buffer_is_empty(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    uint8_t result = __hepta_cb_fn_c_ring_buffer_is_empty(&s_b_buffer, (__hepta_cb_slice_2){(int8_t *)b_buffer->buffer, 128});
    return result;
}

uint8_t ring_buffer_is_full(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    uint8_t result = __hepta_cb_fn_c_ring_buffer_is_full(&s_b_buffer, (__hepta_cb_slice_2){(int8_t *)b_buffer->buffer, 128});
    return result;
}

ring_buffer_size_t ring_buffer_num_items(ring_buffer_t * b_buffer) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    ring_buffer_size_t result = __hepta_cb_fn_c_ring_buffer_num_items(&s_b_buffer, (__hepta_cb_slice_2){(int8_t *)b_buffer->buffer, 128});
    return result;
}

uint8_t ring_buffer_peek(ring_buffer_t * b_buffer, char * b_data, ring_buffer_size_t b_index) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = 1;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    uint8_t result = __hepta_cb_fn_c_ring_buffer_peek(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_1){(int8_t *)b_data, n_b_data}, 0, b_index);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return result;
}

void ring_buffer_queue(ring_buffer_t * b_buffer, char b_data) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    (void)__hepta_cb_fn_c_ring_buffer_queue(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, b_data);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return;
}

void ring_buffer_queue_arr(ring_buffer_t * b_buffer, const char * b_data, ring_buffer_size_t b_size) {
    __hia_inline_range_t r_b_buffer = __hia_inline_range((uintptr_t)b_buffer, 1, sizeof(ring_buffer_t), _Alignof(ring_buffer_t));
    __hepta_cb_aggregate_0 s_b_buffer = {.h_f_tail_index = b_buffer->tail_index, .h_f_head_index = b_buffer->head_index, .h_f_hepta_inline_extent_buffer = 128};
    size_t n_b_data = (size_t)b_size;
    __hia_inline_range_t r_b_data = __hia_inline_range((uintptr_t)b_data, n_b_data, sizeof(int8_t), _Alignof(int8_t));
    __hia_inline_disjoint(r_b_buffer, r_b_data);
    (void)__hepta_cb_fn_c_ring_buffer_queue_arr(&s_b_buffer, (__hepta_cb_slice_1){(int8_t *)b_buffer->buffer, 128}, (__hepta_cb_slice_2){(const int8_t *)b_data, n_b_data}, 0, b_size);
    b_buffer->tail_index = s_b_buffer.h_f_tail_index;
    b_buffer->head_index = s_b_buffer.h_f_head_index;
    return;
}
