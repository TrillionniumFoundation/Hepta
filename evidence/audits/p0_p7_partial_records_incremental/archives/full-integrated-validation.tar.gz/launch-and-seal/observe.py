import datetime,json,os,pathlib,re
out=pathlib.Path('/tmp/hepta-next-integrated-d942f18b-20261028')
now=datetime.datetime.now(datetime.timezone.utc)
p=out/'unit-discovery'
raw=(p/'stderr.log').read_text(errors='replace')
start=json.loads((p/'process.json').read_text())['started_utc']
rows=re.findall(r'(?m)^(test\S*) \(([^\n)]+)\) \.\.\. ([^\n]*)',raw)
ids=[q if q.rpartition('.')[2]==d else q+'.'+d for d,q,s in rows]
v=os.statvfs(out)
result={'observed_utc':now.isoformat(),'unit_elapsed_seconds':(now-datetime.datetime.fromisoformat(start)).total_seconds(),'canonical_starts':len(ids),'unique_starts':len(set(ids)),'direct_terminal_ok':sum(s.rstrip('\r')=='ok' for d,q,s in rows),'fail_error_lines':[{'id':q,'status':s} for d,q,s in rows if s.rstrip('\r') in {'FAIL','ERROR'}],'footer':re.findall(r'(?m)^(?:Ran [0-9]+ tests in .+|OK(?: .*)?|FAILED(?: .*)?)$',raw),'last_method':ids[-1] if ids else None,'native_available_bytes':v.f_bavail*v.f_frsize,'summary_exists':(out/'summary.json').exists()}
if (out/'summary.json').exists():
 summary=json.loads((out/'summary.json').read_text())
 result['summary_terminal']={k:summary[k] for k in ['ok','git_commit','source_unchanged','tools_unchanged','stages']}
print(json.dumps(result,indent=2))
