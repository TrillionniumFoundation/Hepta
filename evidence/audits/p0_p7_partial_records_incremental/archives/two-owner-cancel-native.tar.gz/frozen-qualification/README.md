# Finite two-owner cleanup qualification

This independent evidence set passed on frozen Hepta commit
`d942f18b07c8811aa1418b6f67fabc23212317d1`, tree
`44823c1858d52e9043edebb83f2414d91087d743`, source snapshot
`4a64e1a353585d0ee88985e4942c008bd82ec1482be7ce1158a60f24f550e8db`.
The repository source, index and HEAD were not modified. Source and tool hashes
were identical before and after execution.

## Fixed plan and actual executions

`plan.json` was written before executing any scenario and was not revised.
It declares 32 inputs: four explicit cleanup/cancellation modes crossed with
eight size, tag and allocation-failure configurations. Each fixture uses a
generic partial record containing two buffer fields and one scalar. Ownership
crosses control-flow edges, function calls and cooperative task state.

The first attempt completed all 64 Python nominal/Core executions, 32 runs of
the retained Rust VM, 64 positive native executions, and four native wrong-order
controls. Three LLVM objects were emitted, compiled, inspected and linked.
All 111 explicit compiler/inspection/Rust/native subprocesses retained both
streams. Each completed with exit status zero; the negative controls are valid
programs which the independent result oracle rejects by release order.

Actual scenario execution took 4.879643 seconds against a declared 180-second
budget. The longest child process took 0.327720 seconds against the 60-second
limit. This directory is below the declared 10,000,000-byte storage limit.

Representative cases allocate 7 and 11 bytes successfully:

| Path | Return | VM steps | Owners created and dropped | Peak live bytes | Observed native free order |
| --- | ---: | ---: | ---: | ---: | --- |
| explicit error cleanup | 1073 | 20 | 3 | 18 | [2, 1] |
| pending cancel | 2003 | 56 | 7 | 18 | [2, 1] |
| running cancel before poll | 3003 | 67 | 7 | 18 | [2, 1] |
| running cancel after pending poll | 4003 | 86 | 7 | 18 | [2, 1] |

Allocation IDs are assigned by successful allocation order. In every case with
two live payloads, the native observer sees `[2, 1]`: second payload, then first.
The four controls deliberately emit `[1, 2]`. Their return values, allocation
attempts, successful allocations, failures, frees, peak bytes, and final clean
resource state all match the positive expectation; each is nevertheless rejected
by the release-order comparison. Zero-length and failed-allocation owners remain
logical owners and are counted separately from physical allocations.

## Scope and independence

Expected results and resource counts come from the fixed scenario model, which
does not read VM results, Core operations or emitted LLVM. Python nominal/Core
and Rust reports agree on return values, status, steps and resource ledger. The
unchanged retained Rust executable has SHA256
`5ff3739ae9a03280d2a41adf82a7f4424853d5e03cfa7946409e652ac584c3ff`.
Their public reports have no ordered release-event stream, so direct order
observation is limited to the linked native allocator observer.

Native compilation uses public `emit_program_llvm`, then captured direct Clang
20 `-O3` object compilation, `llvm-readobj` object inspection and a linked C
allocator observer. This set does not invoke the production compile API. Both
nominal and canonical Core input routes use the same LLVM backend and compiler;
they are two public input routes, not two independent native implementations.

The running-task cases cover both cancellation after `task.start` before polling
and cancellation after one poll returns `pending` with both payloads still owned.
Explicit error cleanup is a selected error-return branch. This set does not
claim exception unwinding, asynchronous preemption, real concurrency, arbitrary
program coverage or a whole-language safety proof. The existing 94-case
qualification and its stated scope remain unchanged.

## Final sealing note

The collector created `attempt-01/manifest.json` before printing its terminal
summary. Because the caller redirected that summary to `execution.stdout`, the
intermediate manifest correctly saw that still-open file at zero bytes and its
entry became stale when the collector printed. The intermediate manifest and all
original reports remain unchanged. `seal.json` records that sole mismatch and
hashes every finished file, including both outer streams and the intermediate
manifest. Use the final seal for post-execution file-integrity checks.

No scenario was rerun and no optional test was started after the successful
attempt. `seal_evidence.py` only checks and packages already-produced artifacts.
