"""Independent finite two-owner partial-record cleanup qualification.

This external fixture does not modify Hepta. Prepare writes a fixed input plan
before any scenario is executed. Execute retains every explicit tool/program
attempt, compares all implementations, and binds the frozen repository/tools.
"""
from __future__ import annotations
import copy
import datetime
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
OUT = Path(__file__).resolve().parent
EXPECTED_COMMIT = 'd942f18b07c8811aa1418b6f67fabc23212317d1'
EXPECTED_TREE = '44823c1858d52e9043edebb83f2414d91087d743'
EXPECTED_VM = '5ff3739ae9a03280d2a41adf82a7f4424853d5e03cfa7946409e652ac584c3ff'
CLANG = Path('/usr/lib/llvm-20/bin/clang').resolve()
READOBJ = Path('/usr/lib/llvm-20/bin/llvm-readobj').resolve()
RUST_VM = Path('/tmp/hepta-final-integrated-e6379178/retained-vm/hia-core-shadow')
sys.path.insert(0, str(ROOT))
from hepta.hia_program import verify_core
from hepta.hia_program_runtime import execute_program
from hepta.hia_program_llvm import emit_program_llvm
from tools.release_check import snapshot
from tools.qualify_hia_partial_records import retained_process


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def identity():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=60).strip()
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'git_status': git('status', '--porcelain'), 'snapshot': snapshot()}


def tools_identity():
    return {name: digest(path) for name, path in [('clang', CLANG), ('llvm_readobj', READOBJ), ('rust_vm', RUST_VM)]}


def param(name, typ):
    return {'name': name, 'type': copy.deepcopy(typ)}


PAIR = {'name': 'Pair', 'args': ['buffer', 'usize']}


def partial(*fields):
    return {'partial': copy.deepcopy(PAIR), 'initialized': list(fields)}


def ins(op, args=(), out=(), **attrs):
    return {'op': op, 'args': list(args), 'out': [param(n, t) for n, t in out], 'attrs': attrs}


def const(name, typ, value):
    return ins('const', out=[(name, typ)], value=value)


def ret(*values):
    return {'op': 'ret', 'values': list(values)}


def block(name, params, ops, term):
    return {'id': name, 'params': [param(n, t) for n, t in params], 'ops': ops, 'term': term}


def fn(name, params, returns, effects, blocks):
    return {'name': name, 'params': [param(n, t) for n, t in params], 'returns': copy.deepcopy(returns),
            'effects': effects, 'entry': blocks[0]['id'], 'blocks': blocks}


def branch(cond, yes, no):
    return {'op': 'branch', 'cond': cond,
            'then': {'target': yes[0], 'args': list(yes[1:])},
            'else': {'target': no[0], 'args': list(no[1:])}}


def program(*, reverse=True):
    full = partial('first', 'second', 'tag')
    types = [
        {'name': 'Pair', 'params': ['T', 'U'], 'kind': 'record',
         'fields': [param('first', 'T'), param('second', 'T'), param('tag', 'U')]},
        {'name': 'Step', 'params': [], 'kind': 'enum', 'variants': [
            {'name': 'pending', 'fields': [param('state', full)]},
            {'name': 'ready', 'fields': [param('value', 'usize')]}]},
        {'name': 'TwoOwnerTask', 'params': [], 'kind': 'task', 'state': full,
         'result': 'usize', 'poll': 'poll', 'cancel': 'cancel_state'},
    ]
    ops = [ins('record.take', ['state'], [('tag', 'usize'), ('after_tag', partial('first', 'second'))], field='tag')]
    remaining, source = ['first', 'second'], 'after_tag'
    for field in (['second', 'first'] if reverse else ['first', 'second']):
        remaining.remove(field)
        value, rest = field + '_value', 'after_' + field
        ops += [ins('record.take', [source], [(value, 'buffer'), (rest, partial(*remaining))], field=field),
                ins('owner.drop', [value])]
        source = rest
    ops.append(ins('record.abandon', [source]))
    dispose = fn('dispose', [('state', full)], ['usize'], ['alloc'],
                 [block('entry', [('state', full)], ops, ret('tag'))])
    cancel = fn('cancel_state', [('state', full)], [], ['alloc'], [
        block('entry', [('state', full)], [ins('call', ['state'], [('discarded_tag', 'usize')], function='dispose')], ret())])
    poll = fn('poll', [('state', full)], ['Step'], ['alloc'], [
        block('entry', [('state', full)], [
            ins('enum.make', ['state'], [('pending_step', 'Step')], variant='pending'),
        ], ret('pending_step'))])
    signature = [('mode', 'u8'), ('first_size', 'usize'), ('second_size', 'usize'), ('byte', 'u8')]
    main = fn('cleanup_case', signature, ['usize'], ['alloc', 'trap'], [
        block('entry', signature, [
            ins('record.begin', out=[('empty', partial())]),
            ins('buffer.try_new', ['first_size'], [('first', 'buffer'), ('first_ok', 'bool')]),
            ins('record.insert', ['empty', 'first'], [('first_state', partial('first'))], field='first'),
            ins('buffer.try_new', ['second_size'], [('second', 'buffer'), ('second_ok', 'bool')]),
            ins('record.insert', ['first_state', 'second'], [('both_state', partial('first', 'second'))], field='second'),
            ins('int.cast', ['byte'], [('tag', 'usize')], mode='wrap'),
            ins('record.insert', ['both_state', 'tag'], [('state', full)], field='tag'),
            const('zero_mode', 'u8', 0), ins('compare.eq', ['mode', 'zero_mode'], [('error', 'bool')]),
        ], branch('error', ('error_path', 'state'), ('task_path', 'state', 'mode'))),
        block('error_path', [('error_state', full)], [
            ins('call', ['error_state'], [('error_tag', 'usize')], function='dispose'),
            const('error_base', 'usize', 1000),
            ins('int.add.checked', ['error_base', 'error_tag'], [('error_result', 'usize')]),
        ], ret('error_result')),
        block('task_path', [('task_state', full), ('task_mode', 'u8')], [
            ins('task.create', ['task_state'], [('pending', 'TwoOwnerTask')]),
            const('one_mode', 'u8', 1), ins('compare.eq', ['task_mode', 'one_mode'], [('is_pending', 'bool')]),
        ], branch('is_pending', ('pending_path', 'pending'), ('running_path', 'pending', 'task_mode'))),
        block('pending_path', [('pending_input', 'TwoOwnerTask')], [
            ins('task.cancel', ['pending_input'], [('pending_stopped', 'TwoOwnerTask')]),
            ins('task.state', ['pending_stopped'], [('pending_status', 'u8')]),
            ins('task.close', ['pending_stopped']),
            ins('int.cast', ['pending_status'], [('pending_wide', 'usize')], mode='wrap'),
            const('pending_base', 'usize', 2000),
            ins('int.add.checked', ['pending_base', 'pending_wide'], [('pending_result', 'usize')]),
        ], ret('pending_result')),
        block('running_path', [('running_input', 'TwoOwnerTask'), ('running_mode', 'u8')], [
            ins('task.start', ['running_input'], [('running', 'TwoOwnerTask')]),
            const('two_mode', 'u8', 2), ins('compare.eq', ['running_mode', 'two_mode'], [('unpolled', 'bool')]),
        ], branch('unpolled', ('cancel_unpolled', 'running'), ('poll_running', 'running'))),
        block('cancel_unpolled', [('unpolled_task', 'TwoOwnerTask')], [
            const('unpolled_base', 'usize', 3000),
        ], {'op': 'jump', 'target': 'cancel_running', 'args': ['unpolled_task', 'unpolled_base']}),
        block('poll_running', [('poll_input', 'TwoOwnerTask')], [
            ins('task.poll', ['poll_input'], [('yielded', 'TwoOwnerTask')]),
            const('polled_base', 'usize', 4000),
        ], {'op': 'jump', 'target': 'cancel_running', 'args': ['yielded', 'polled_base']}),
        block('cancel_running', [('cancel_input', 'TwoOwnerTask'), ('running_base', 'usize')], [
            ins('task.cancel', ['cancel_input'], [('running_stopped', 'TwoOwnerTask')]),
            ins('task.state', ['running_stopped'], [('running_status', 'u8')]),
            ins('task.close', ['running_stopped']),
            ins('int.cast', ['running_status'], [('running_wide', 'usize')], mode='wrap'),
            ins('int.add.checked', ['running_base', 'running_wide'], [('running_result', 'usize')]),
        ], ret('running_result')),
    ])
    return {'schema': 'hepta.hia.composite.v3', 'module': 'two_owner_cleanup',
            'types': types, 'functions': [dispose, cancel, poll, main]}


def cases():
    matrix = [(7, 11, 73, 0), (1, 3, 0, 0), (7, 11, 255, 1), (7, 11, 73, 2),
              (0, 11, 73, 0), (7, 0, 73, 0), (0, 0, 73, 0), (7, 11, 73, 3)]
    return [{'arguments': [mode, first, second, tag], 'allocation_fail_at': fail}
            for mode in (0, 1, 2, 3) for first, second, tag, fail in matrix]


def independent_spec(row):
    mode, first_size, second_size, tag = row['arguments']
    result = dict(result=1000 + tag if mode == 0 else (mode + 1) * 1000 + 3,
                  attempts=0, allocations=0, frees=0, failures=0, live=0,
                  live_bytes=0, peak_bytes=0, invalid_frees=0, null_frees=0, free_order=[])
    handles = []
    for size in (first_size, second_size):
        if size == 0:
            handles.append(None)
            continue
        result['attempts'] += 1
        if result['attempts'] == row['allocation_fail_at']:
            result['failures'] += 1
            handles.append(None)
        else:
            result['allocations'] += 1
            result['live'] += 1
            result['live_bytes'] += size
            result['peak_bytes'] = max(result['peak_bytes'], result['live_bytes'])
            handles.append((result['allocations'], size))
    for handle in reversed(handles):
        if handle is not None:
            ident, size = handle
            result['frees'] += 1
            result['live'] -= 1
            result['live_bytes'] -= size
            result['free_order'].append(ident)
    # Direct cleanup: partial token + two field owners. Task cancellation adds
    # its task token and three empty padding owners after consuming the state.
    return {'native': result, 'logical_owners': 3 if mode == 0 else 7}


OBSERVER = r'''
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/resource.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[8]; static size_t sizes[8], ids[8], releases[8];
static size_t attempts, allocations, frees, failures, live, live_bytes, peak_bytes, invalid_frees, null_frees, fail_at;
static void *remember(void *p,size_t n) {
  if(!p)return p;size_t i;for(i=0;i<8 && addresses[i];i++);if(i==8)exit(89);
  addresses[i]=p;sizes[i]=n;ids[i]=++allocations;live++;live_bytes+=n;
  if(live_bytes>peak_bytes)peak_bytes=live_bytes;return p;
}
void *__wrap_malloc(size_t n) {
  attempts++;if(attempts==fail_at){failures++;return NULL;}return remember(__real_malloc(n),n);
}
void *__wrap_calloc(size_t n,size_t width) {
  attempts++;if(attempts==fail_at){failures++;return NULL;}return remember(__real_calloc(n,width),n*width);
}
void __wrap_free(void *p) {
  if(!p){null_frees++;__real_free(p);return;}
  size_t i;for(i=0;i<8 && addresses[i]!=p;i++);if(i==8){invalid_frees++;return;}
  releases[frees++]=ids[i];live--;live_bytes-=sizes[i];addresses[i]=NULL;__real_free(p);
}
extern size_t cleanup_case(uint8_t,size_t,size_t,uint8_t);
struct input {uint8_t mode;size_t first,second;uint8_t tag;size_t fail;};
static const struct input inputs[]={@CASES@};
int main(int argc,char **argv) {
  struct rlimit no_core={0,0};if(setrlimit(RLIMIT_CORE,&no_core))return 88;
  if(sizeof(size_t)!=8 || argc!=2)return 87;size_t index=(size_t)strtoull(argv[1],NULL,10);
  if(index>=sizeof(inputs)/sizeof(inputs[0]))return 86;
  struct input c=inputs[index];fail_at=c.fail;
  size_t value=cleanup_case(c.mode,c.first,c.second,c.tag);
  printf("{\"result\":%zu,\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,\"failures\":%zu,\"live\":%zu,\"live_bytes\":%zu,\"peak_bytes\":%zu,\"invalid_frees\":%zu,\"null_frees\":%zu,\"free_order\":[",value,attempts,allocations,frees,failures,live,live_bytes,peak_bytes,invalid_frees,null_frees);
  for(size_t i=0;i<frees;i++)printf(i ? ",%zu" : "%zu",releases[i]);
  puts("]}");return live || invalid_frees || null_frees ? 91 : 0;
}
'''


def observer_source(rows):
    entries = []
    for row in rows:
        mode, a, b, tag = row['arguments']
        entries.append('{' + ','.join(str(x) for x in [mode, a, b, tag, row['allocation_fail_at']]) + '}')
    return OBSERVER.replace('@CASES@', ',\n'.join(entries))


def prepare():
    before, tools = identity(), tools_identity()
    assert before['commit'] == EXPECTED_COMMIT and before['tree'] == EXPECTED_TREE and not before['git_status']
    assert tools['rust_vm']['sha256'] == EXPECTED_VM
    rows = cases()
    assert len(rows) == len({canonical(row) for row in rows}) == 32
    write(OUT / 'input.json', program())
    write(OUT / 'wrong-order-input.json', program(reverse=False))
    (OUT / 'observer.c').write_text(observer_source(rows), encoding='ascii')
    plan = {'schema': 'hepta.partial-two-owner-plan.v1', 'prepared_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'source': before, 'tools': tools, 'collector': digest(__file__),
            'input': digest(OUT / 'input.json'), 'wrong_order_input': digest(OUT / 'wrong-order-input.json'),
            'observer': digest(OUT / 'observer.c'), 'cases': rows,
            'expected': [independent_spec(row) for row in rows],
            'negative_case_indexes': [0, 8, 16, 24], 'negative_expected_order': [1, 2],
            'budget': {'actual_run_seconds': 180, 'subprocess_seconds': 60, 'stdout_bytes': 100000,
                       'stderr_bytes': 100000, 'max_steps': 100000, 'max_heap_bytes': 1024,
                       'max_call_depth': 32, 'all_retained_artifact_bytes': 10000000},
            'planned_counts': {'requests': 32, 'python_executions': 64, 'rust_executions': 32,
                               'positive_native_executions': 64, 'negative_native_executions': 4,
                               'llvm_object_compiles': 3, 'links': 3, 'object_inspections': 3},
            'scope': 'Explicit error cleanup, pending cancellation, started-but-unpolled cancellation and cancellation after one poll returned pending, with two live payloads. Release order is directly observed only by the native allocator observer; Python/Rust public reports supply scalar results, steps and resource ledgers. No real concurrency, unwind recovery or whole-language proof.'}
    write(OUT / 'plan.json', plan)
    print(canonical({'prepared': True, 'plan': digest(OUT / 'plan.json'), 'commit': before['commit'],
                     'snapshot': before['snapshot']['sha256'], 'counts': plan['planned_counts']}))


def execute():
    plan = json.loads((OUT / 'plan.json').read_text())
    assert plan['collector'] == digest(__file__)
    for name, filename in [('input', 'input.json'), ('wrong_order_input', 'wrong-order-input.json'), ('observer', 'observer.c')]:
        assert plan[name] == digest(OUT / filename)
    assert plan['source'] == identity() and plan['tools'] == tools_identity()
    attempt = OUT / 'attempt-01'
    attempt.mkdir(exist_ok=False)
    started = time.monotonic()
    deadline = started + plan['budget']['actual_run_seconds']
    report = {'schema': 'hepta.partial-two-owner-qualification.v1', 'passed': False, 'status': 'running',
              'plan': digest(OUT / 'plan.json'), 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'source_before': plan['source'], 'tools_before': plan['tools'], 'processes': [],
              'differential': [], 'python': [], 'native': {}, 'negative_controls': [],
              'scope': plan['scope'], 'repository_modified': False,
              'production_compile_api_used': False,
              'llvm_route': 'Public reverified emit_program_llvm; captured direct Clang -O3 object compilation and object inspection.'}

    def remaining():
        value = deadline - time.monotonic()
        if value <= 0:
            raise TimeoutError('predeclared 180-second actual-run budget exhausted')
        return min(60, value)

    def run(argv, *, text=None):
        return retained_process(report, attempt, argv, input_text=text, timeout=remaining(),
                                stdout_limit=100000, stderr_limit=100000)

    def compile_object(name, value):
        remaining()
        ir = emit_program_llvm(value)
        path, artifact, executable = attempt / (name + '.ll'), attempt / (name + '.o'), attempt / name
        path.write_text(ir.text, encoding='ascii')
        compile_index, _ = run([CLANG, '--target=x86_64-unknown-linux-gnu', '-x', 'ir', '-O3', '-fPIC', '-c', path, '-o', artifact])
        inspection_index, headers = run([READOBJ, '--file-headers', artifact])
        assert 'elf64-x86-64' in headers and 'x86_64' in headers
        link_index, _ = run([CLANG, '-std=c11', '-O2', '-Werror=implicit-function-declaration', OUT / 'observer.c', artifact,
                             '-Wl,--wrap=malloc', '-Wl,--wrap=calloc', '-Wl,--wrap=free', '-o', executable])
        return executable, {'ir': digest(path), 'object': digest(artifact), 'executable': digest(executable),
                            'compile_process': compile_index, 'inspection_process': inspection_index, 'link_process': link_index}

    try:
        version_process, version = run([CLANG, '--version'])
        target_process, target = run([CLANG, '-dumpmachine'])
        assert 'clang version 20.' in version and target.strip() in {'x86_64-pc-linux-gnu', 'x86_64-unknown-linux-gnu'}
        report['compiler_preflight'] = [version_process, target_process]
        nominal = verify_core((OUT / 'input.json').read_text())
        core = verify_core(nominal.canonical_bytes)
        (attempt / 'core.json').write_bytes(core.canonical_bytes)
        report.update(input_sha256=nominal.input_sha256, core_sha256=core.sha256, normalization=nominal.normalization_report)
        for index, (row, expected) in enumerate(zip(plan['cases'], plan['expected'])):
            remaining()
            options = {'max_steps': 100000, 'max_heap_bytes': 1024, 'max_call_depth': 32}
            if row['allocation_fail_at']:
                options['allocation_fail_at'] = row['allocation_fail_at']
            outputs = []
            for route, program_value in [('nominal', nominal), ('core', core)]:
                python_attempt = {'index': index, 'route': route, 'status': 'attempted'}
                report['python'].append(python_attempt)
                output_value = execute_program(program_value, 'cleanup_case', row['arguments'], **options)
                python_attempt.update(status='completed', observed=output_value)
                outputs.append(output_value)
            first, second = outputs
            vm_options = {k:v for k,v in options.items() if k != 'max_call_depth'}
            process, output = run([RUST_VM, '--owned-run', 'cleanup_case', json.dumps(row['arguments']), json.dumps(vm_options)],
                                  text=core.canonical_bytes.decode())
            rust = json.loads(output)
            report['differential'].append({'index': index, 'case': row, 'expected': expected,
                    'python_nominal': first, 'python_core': second, 'rust': rust, 'rust_process': process})
            assert rust['schema'] == 'hepta.hia.rust-owned-execution.v2'
            for field in ['status', 'steps', 'resources', 'program_sha256', 'values']:
                assert canonical(first[field]) == canonical(second[field]) == canonical(rust[field]), (index, field)
            assert first['status'] == 'returned' and first['values'] == [expected['native']['result']]
            ledger = first['resources']
            for actual, wanted in [('allocation_attempts', 'attempts'), ('allocations', 'allocations'),
                                   ('frees', 'frees'), ('live_bytes', 'live_bytes'), ('peak_bytes', 'peak_bytes')]:
                assert ledger[actual] == expected['native'][wanted], (index, actual)
            assert ledger['allocation_attempts'] - ledger['allocations'] == expected['native']['failures']
            assert ledger['owners_created'] == ledger['owners_dropped'] == expected['logical_owners']
            assert ledger['live_owners'] == ledger['live_local_loans'] == ledger['live_chains'] == 0
        for name, value in [('nominal', nominal), ('core', core)]:
            executable, compiled = compile_object(name, value)
            group = {'compilation': compiled, 'cases': []}
            report['native'][name] = group
            for index, expected in enumerate(plan['expected']):
                process, output = run([executable, str(index)])
                observed = json.loads(output)
                group['cases'].append({'index': index, 'process': process, 'observed': observed})
                assert canonical(observed) == canonical(expected['native']), (name, index)
        wrong = verify_core((OUT / 'wrong-order-input.json').read_text())
        assert wrong.sha256 != core.sha256
        (attempt / 'wrong-order-core.json').write_bytes(wrong.canonical_bytes)
        executable, compiled = compile_object('wrong-order', wrong)
        report['wrong_order_compilation'] = compiled
        for index in plan['negative_case_indexes']:
            process, output = run([executable, str(index)])
            observed, expected = json.loads(output), plan['expected'][index]['native']
            assert expected['free_order'] == [2, 1]
            assert observed['free_order'] == plan['negative_expected_order']
            assert {k:v for k,v in observed.items() if k != 'free_order'} == {k:v for k,v in expected.items() if k != 'free_order'}
            assert observed != expected
            report['negative_controls'].append({'index': index, 'process': process, 'observed': observed,
                'expected': expected, 'detected': True, 'valid_core': True, 'equivalent_to_original': False,
                'reason': 'same scalar result, allocation/free counts and clean resources; observable release order reversed'})
        remaining()
        report['status'], report['passed'] = 'passed', True
    except BaseException as error:
        report['status'], report['passed'] = 'failed', False
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report['actual_run_seconds'] = time.monotonic() - started
        report['source_after'], report['tools_after'] = identity(), tools_identity()
        report['source_unchanged'] = report['source_before'] == report['source_after']
        report['tools_unchanged'] = report['tools_before'] == report['tools_after']
        if not report['source_unchanged'] or not report['tools_unchanged'] or report['actual_run_seconds'] > 180:
            report['status'], report['passed'] = 'failed_identity_or_budget', False
        report['counts'] = {'requests': len(report['differential']),
                            'python_executions': sum(row['status'] == 'completed' for row in report['python']),
                            'rust_executions': len(report['differential']),
                            'positive_native_executions': sum(len(group['cases']) for group in report['native'].values()),
                            'negative_native_executions': len(report['negative_controls'])}
        write(attempt / 'report.json', report)
        entries = [digest(path) for path in sorted(OUT.rglob('*')) if path.is_file()]
        total = sum(entry['bytes'] for entry in entries)
        write(attempt / 'manifest.json', {'schema': 'hepta.partial-two-owner-manifest.v1', 'files': entries, 'bytes': total,
                                         'budget_bytes': 10000000, 'within_budget': total < 10000000})
    assert report['passed'] and total < 10000000
    print(canonical({'status': report['status'], 'seconds': report['actual_run_seconds'], 'counts': report['counts'],
                     'source_unchanged': report['source_unchanged'], 'snapshot': report['source_after']['snapshot']['sha256'],
                     'report': digest(attempt / 'report.json'), 'retained_bytes_before_manifest': total}))


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif sys.argv[1:] == ['execute']:
        execute()
    else:
        raise SystemExit('choose prepare or execute')
