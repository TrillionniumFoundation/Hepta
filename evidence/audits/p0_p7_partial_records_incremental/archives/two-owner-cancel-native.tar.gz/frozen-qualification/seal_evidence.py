"""Seal finished evidence without rewriting the locked plan or first attempt."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def descriptor(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


report = json.loads((ROOT / "attempt-01/report.json").read_text())
intermediate = json.loads((ROOT / "attempt-01/manifest.json").read_text())
mismatches = []
for entry in intermediate["files"]:
    actual = descriptor(Path(entry["path"]))
    if entry != actual:
        mismatches.append({"recorded": entry, "finished": actual})
assert len(mismatches) == 1
assert Path(mismatches[0]["recorded"]["path"]).name == "execution.stdout"
assert mismatches[0]["recorded"]["bytes"] == 0
assert report["passed"] and report["source_unchanged"] and report["tools_unchanged"]
assert all(p["status"] == "completed" and p["returncode"] == 0 for p in report["processes"])
assert len(report["processes"]) == 111
assert (ROOT / "execution.stderr").read_bytes() == b""

rows = []
labels = ["explicit error cleanup", "pending cancel", "running cancel before poll", "running cancel after pending poll"]
for index, label in zip([0, 8, 16, 24], labels):
    vm = report["differential"][index]["python_nominal"]
    native = report["native"]["nominal"]["cases"][index]["observed"]
    rows.append("| " + " | ".join([label, str(vm["values"][0]), str(vm["steps"]),
        str(vm["resources"]["owners_created"]), str(native["peak_bytes"]), str(native["free_order"])]) + " |")

text = """# Finite two-owner cleanup qualification

This independent evidence set passed on frozen Hepta commit
`d942f18b07c8811aa1418b6f67fabc23212317d1`, tree
`44823c1858d52e9043edebb83f2414d91087d743`, source snapshot
`4a64e1a353585d0ee88985e4942c008bd82ec1482be7ce1158a60f24f550e8db`.
The repository source, index and HEAD were not modified. Source and tool hashes
were identical before and after execution.

## Fixed plan and actual executions

`plan.json` was written before executing any scenario and was not revised.
It declares 32 inputs: four explicit cleanup/cancellation modes crossed with
eight size, tag and allocation-failure configurations. Each fixture uses a
generic partial record containing two buffer fields and one scalar. Ownership
crosses control-flow edges, function calls and cooperative task state.

The first attempt completed all 64 Python nominal/Core executions, 32 runs of
the retained Rust VM, 64 positive native executions, and four native wrong-order
controls. Three LLVM objects were emitted, compiled, inspected and linked.
All 111 explicit compiler/inspection/Rust/native subprocesses retained both
streams. Each completed with exit status zero; the negative controls are valid
programs which the independent result oracle rejects by release order.

Actual scenario execution took 4.879643 seconds against a declared 180-second
budget. The longest child process took 0.327720 seconds against the 60-second
limit. This directory is below the declared 10,000,000-byte storage limit.

Representative cases allocate 7 and 11 bytes successfully:

| Path | Return | VM steps | Owners created and dropped | Peak live bytes | Observed native free order |
| --- | ---: | ---: | ---: | ---: | --- |
""" + "\n".join(rows) + """

Allocation IDs are assigned by successful allocation order. In every case with
two live payloads, the native observer sees `[2, 1]`: second payload, then first.
The four controls deliberately emit `[1, 2]`. Their return values, allocation
attempts, successful allocations, failures, frees, peak bytes, and final clean
resource state all match the positive expectation; each is nevertheless rejected
by the release-order comparison. Zero-length and failed-allocation owners remain
logical owners and are counted separately from physical allocations.

## Scope and independence

Expected results and resource counts come from the fixed scenario model, which
does not read VM results, Core operations or emitted LLVM. Python nominal/Core
and Rust reports agree on return values, status, steps and resource ledger. The
unchanged retained Rust executable has SHA256
`5ff3739ae9a03280d2a41adf82a7f4424853d5e03cfa7946409e652ac584c3ff`.
Their public reports have no ordered release-event stream, so direct order
observation is limited to the linked native allocator observer.

Native compilation uses public `emit_program_llvm`, then captured direct Clang
20 `-O3` object compilation, `llvm-readobj` object inspection and a linked C
allocator observer. This set does not invoke the production compile API. Both
nominal and canonical Core input routes use the same LLVM backend and compiler;
they are two public input routes, not two independent native implementations.

The running-task cases cover both cancellation after `task.start` before polling
and cancellation after one poll returns `pending` with both payloads still owned.
Explicit error cleanup is a selected error-return branch. This set does not
claim exception unwinding, asynchronous preemption, real concurrency, arbitrary
program coverage or a whole-language safety proof. The existing 94-case
qualification and its stated scope remain unchanged.

## Final sealing note

The collector created `attempt-01/manifest.json` before printing its terminal
summary. Because the caller redirected that summary to `execution.stdout`, the
intermediate manifest correctly saw that still-open file at zero bytes and its
entry became stale when the collector printed. The intermediate manifest and all
original reports remain unchanged. `seal.json` records that sole mismatch and
hashes every finished file, including both outer streams and the intermediate
manifest. Use the final seal for post-execution file-integrity checks.

No scenario was rerun and no optional test was started after the successful
attempt. `seal_evidence.py` only checks and packages already-produced artifacts.
"""
with (ROOT / "README.md").open("x", encoding="utf-8") as stream:
    stream.write(text)
files = [descriptor(path) for path in sorted(ROOT.rglob("*")) if path.is_file()]
total = sum(entry["bytes"] for entry in files)
assert total < 10_000_000
seal = {"schema": "hepta.partial-two-owner-seal.v1", "sealed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "report": descriptor(ROOT / "attempt-01/report.json"), "plan": descriptor(ROOT / "plan.json"),
        "files": files, "total_bytes_excluding_seal": total, "storage_budget_bytes": 10_000_000,
        "intermediate_manifest_mismatches": mismatches,
        "post_execution_scope": "Artifact inspection and hashing only; no further program or compiler executions.",
        "report_and_plan_unchanged": True}
write(ROOT / "seal.json", seal)
print(json.dumps({"seal": descriptor(ROOT / "seal.json"), "files": len(files), "bytes_before_seal": total,
                  "bytes_including_seal": total + (ROOT / "seal.json").stat().st_size}, sort_keys=True))
