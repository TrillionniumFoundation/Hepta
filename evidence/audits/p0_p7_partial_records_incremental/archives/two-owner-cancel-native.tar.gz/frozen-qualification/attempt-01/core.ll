; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal i64 @__hia_fn_0(%hia.buffer %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_2, 0
  %t2 = icmp ne ptr %t1, null
  br i1 %t2, label %drop_nonnull_3, label %drop_after_3
drop_nonnull_3:
  call void @free(ptr %t1) nobuiltin
  br label %drop_after_3
drop_after_3:
  %t4 = extractvalue %hia.buffer %p_0_1, 0
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %drop_nonnull_6, label %drop_after_6
drop_nonnull_6:
  call void @free(ptr %t4) nobuiltin
  br label %drop_after_6
drop_after_6:
  %t7 = extractvalue %hia.buffer %p_0_0, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  ret i64 %p_0_3
}

define internal void @__hia_fn_1(%hia.buffer %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3) {
b0:
  %t1 = call i64 @__hia_fn_0(%hia.buffer %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3)
  ret void
}

define internal { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_2(%hia.buffer %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3) {
b0:
  %t1 = insertvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i32 0, 0
  %t2 = insertvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t1, %hia.buffer %p_0_0, 1
  %t3 = insertvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, %hia.buffer %p_0_1, 2
  %t4 = insertvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t3, %hia.buffer %p_0_2, 3
  %t5 = insertvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t4, i64 %p_0_3, 4
  %t6 = insertvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t5, i64 0, 5
  ret { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t6
}

define internal i64 @__hia_fn_3(i8 %p_0_0, i64 %p_0_1, i64 %p_0_2, i8 %p_0_3) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  %t6 = call %hia.alloc @__hia_allocate(i64 %p_0_1, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 %p_0_1, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  %t11 = call %hia.alloc @__hia_allocate(i64 %p_0_2, i1 true)
  %t12 = extractvalue %hia.alloc %t11, 0
  %t13 = extractvalue %hia.alloc %t11, 1
  %t14 = select i1 %t13, i64 %p_0_2, i64 0
  %t15 = insertvalue %hia.buffer %t12, i64 %t14, 1
  %t16 = zext i8 %p_0_3 to i64
  %t17 = icmp eq i8 %p_0_0, 0
  br i1 %t17, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %t10, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %t15, %edge_0 ]
  %p_1_3 = phi i64 [ %t16, %edge_0 ]
  %t18 = call i64 @__hia_fn_0(%hia.buffer %p_1_0, %hia.buffer %p_1_1, %hia.buffer %p_1_2, i64 %p_1_3)
  %t19 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t18)
  %t20 = extractvalue { i64, i1 } %t19, 0
  %t21 = extractvalue { i64, i1 } %t19, 1
  %t22 = xor i1 %t21, true
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  ret i64 %t20
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t10, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %t15, %edge_1 ]
  %p_2_3 = phi i64 [ %t16, %edge_1 ]
  %p_2_4 = phi i8 [ %p_0_0, %edge_1 ]
  %t24 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t25 = extractvalue %hia.alloc %t24, 0
  %t26 = extractvalue %hia.alloc %t24, 1
  %t27 = select i1 %t26, i64 0, i64 0
  %t28 = insertvalue %hia.buffer %t25, i64 %t27, 1
  %t29 = icmp eq i8 %p_2_4, 1
  br i1 %t29, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ 0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t28, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_2_2, %edge_2 ]
  %p_3_5 = phi i64 [ %p_2_3, %edge_2 ]
  %p_3_6 = phi i64 [ 0, %edge_2 ]
  %t30 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_4(i8 %p_3_0, %hia.buffer %p_3_1, %hia.buffer %p_3_2, %hia.buffer %p_3_3, %hia.buffer %p_3_4, i64 %p_3_5, i64 %p_3_6)
  %t31 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 0
  %t32 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 1
  %t33 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 2
  %t34 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 3
  %t35 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 4
  %t36 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 5
  %t37 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, 6
  call void @__hia_fn_5(i8 %t31, %hia.buffer %t32, %hia.buffer %t33, %hia.buffer %t34, %hia.buffer %t35, i64 %t36, i64 %t37)
  %t38 = zext i8 %t31 to i64
  %t39 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 2000, i64 %t38)
  %t40 = extractvalue { i64, i1 } %t39, 0
  %t41 = extractvalue { i64, i1 } %t39, 1
  %t42 = xor i1 %t41, true
  br i1 %t42, label %ok_43, label %trap_43
trap_43:
  call void @abort()
  unreachable
ok_43:
  ret i64 %t40
b4:
  %p_4_0 = phi i8 [ 0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %t28, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_2_2, %edge_3 ]
  %p_4_5 = phi i64 [ %p_2_3, %edge_3 ]
  %p_4_6 = phi i64 [ 0, %edge_3 ]
  %p_4_7 = phi i8 [ %p_2_4, %edge_3 ]
  %t44 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(i8 %p_4_0, %hia.buffer %p_4_1, %hia.buffer %p_4_2, %hia.buffer %p_4_3, %hia.buffer %p_4_4, i64 %p_4_5, i64 %p_4_6)
  %t45 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 0
  %t46 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 1
  %t47 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 2
  %t48 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 3
  %t49 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 4
  %t50 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 5
  %t51 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t44, 6
  %t52 = icmp eq i8 %p_4_7, 2
  br i1 %t52, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i8 [ %t45, %edge_4 ]
  %p_5_1 = phi %hia.buffer [ %t46, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %t47, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %t48, %edge_4 ]
  %p_5_4 = phi %hia.buffer [ %t49, %edge_4 ]
  %p_5_5 = phi i64 [ %t50, %edge_4 ]
  %p_5_6 = phi i64 [ %t51, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i8 [ %t45, %edge_5 ]
  %p_6_1 = phi %hia.buffer [ %t46, %edge_5 ]
  %p_6_2 = phi %hia.buffer [ %t47, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %t48, %edge_5 ]
  %p_6_4 = phi %hia.buffer [ %t49, %edge_5 ]
  %p_6_5 = phi i64 [ %t50, %edge_5 ]
  %p_6_6 = phi i64 [ %t51, %edge_5 ]
  %t53 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_7(i8 %p_6_0, %hia.buffer %p_6_1, %hia.buffer %p_6_2, %hia.buffer %p_6_3, %hia.buffer %p_6_4, i64 %p_6_5, i64 %p_6_6)
  %t54 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 0
  %t55 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 1
  %t56 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 2
  %t57 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 3
  %t58 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 4
  %t59 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 5
  %t60 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t53, 6
  br label %edge_7
b7:
  %p_7_0 = phi i8 [ %p_5_0, %edge_6 ], [ %t54, %edge_7 ]
  %p_7_1 = phi %hia.buffer [ %p_5_1, %edge_6 ], [ %t55, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_6 ], [ %t56, %edge_7 ]
  %p_7_3 = phi %hia.buffer [ %p_5_3, %edge_6 ], [ %t57, %edge_7 ]
  %p_7_4 = phi %hia.buffer [ %p_5_4, %edge_6 ], [ %t58, %edge_7 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_6 ], [ %t59, %edge_7 ]
  %p_7_6 = phi i64 [ %p_5_6, %edge_6 ], [ %t60, %edge_7 ]
  %p_7_7 = phi i64 [ 3000, %edge_6 ], [ 4000, %edge_7 ]
  %t61 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_4(i8 %p_7_0, %hia.buffer %p_7_1, %hia.buffer %p_7_2, %hia.buffer %p_7_3, %hia.buffer %p_7_4, i64 %p_7_5, i64 %p_7_6)
  %t62 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 0
  %t63 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 1
  %t64 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 2
  %t65 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 3
  %t66 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 4
  %t67 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 5
  %t68 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t61, 6
  call void @__hia_fn_5(i8 %t62, %hia.buffer %t63, %hia.buffer %t64, %hia.buffer %t65, %hia.buffer %t66, i64 %t67, i64 %t68)
  %t69 = zext i8 %t62 to i64
  %t70 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_7, i64 %t69)
  %t71 = extractvalue { i64, i1 } %t70, 0
  %t72 = extractvalue { i64, i1 } %t70, 1
  %t73 = xor i1 %t72, true
  br i1 %t73, label %ok_74, label %trap_74
trap_74:
  call void @abort()
  unreachable
ok_74:
  ret i64 %t71
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b7
}

define internal { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_4(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = icmp ult i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  call void @__hia_fn_1(%hia.buffer %p_1_2, %hia.buffer %p_1_3, %hia.buffer %p_1_4, i64 %p_1_5)
  %t2 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  %t7 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t8 = extractvalue %hia.alloc %t7, 0
  %t9 = extractvalue %hia.alloc %t7, 1
  %t10 = select i1 %t9, i64 0, i64 0
  %t11 = insertvalue %hia.buffer %t8, i64 %t10, 1
  %t12 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t13 = extractvalue %hia.alloc %t12, 0
  %t14 = extractvalue %hia.alloc %t12, 1
  %t15 = select i1 %t14, i64 0, i64 0
  %t16 = insertvalue %hia.buffer %t13, i64 %t15, 1
  %t17 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 3, 0
  %t18 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t17, %hia.buffer %p_1_1, 1
  %t19 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, %hia.buffer %t6, 2
  %t20 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t19, %hia.buffer %t11, 3
  %t21 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t20, %hia.buffer %t16, 4
  %t22 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t21, i64 0, 5
  %t23 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t22, i64 0, 6
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t23
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_6, %edge_1 ]
  %t24 = icmp ule i8 %p_2_0, 3
  br i1 %t24, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_2_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_2_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_2_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_2_6, %edge_2 ]
  %t25 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %p_3_0, 0
  %t26 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t25, %hia.buffer %p_3_1, 1
  %t27 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, %hia.buffer %p_3_2, 2
  %t28 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t27, %hia.buffer %p_3_3, 3
  %t29 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t28, %hia.buffer %p_3_4, 4
  %t30 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t29, i64 %p_3_5, 5
  %t31 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t30, i64 %p_3_6, 6
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t31
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_2_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_2_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_2_6, %edge_3 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal void @__hia_fn_5(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = icmp eq i8 %p_0_0, 3
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  call void @free(ptr %t2) nobuiltin
  br label %drop_after_4
drop_after_4:
  %t5 = extractvalue %hia.buffer %p_1_2, 0
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %drop_nonnull_7, label %drop_after_7
drop_nonnull_7:
  call void @free(ptr %t5) nobuiltin
  br label %drop_after_7
drop_after_7:
  %t8 = extractvalue %hia.buffer %p_1_3, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  call void @free(ptr %t8) nobuiltin
  br label %drop_after_10
drop_after_10:
  %t11 = extractvalue %hia.buffer %p_1_4, 0
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %drop_nonnull_13, label %drop_after_13
drop_nonnull_13:
  call void @free(ptr %t11) nobuiltin
  br label %drop_after_13
drop_after_13:
  ret void
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_6, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = icmp eq i8 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  %t2 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 1, 0
  %t3 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, %hia.buffer %p_1_1, 1
  %t4 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t3, %hia.buffer %p_1_2, 2
  %t5 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t4, %hia.buffer %p_1_3, 3
  %t6 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t5, %hia.buffer %p_1_4, 4
  %t7 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t6, i64 %p_1_5, 5
  %t8 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t7, i64 %p_1_6, 6
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t8
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_6, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_7(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = icmp eq i8 %p_0_0, 1
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  %t2 = call { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_2(%hia.buffer %p_1_2, %hia.buffer %p_1_3, %hia.buffer %p_1_4, i64 %p_1_5)
  %t3 = extractvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, 0
  %t4 = extractvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, 1
  %t5 = extractvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, 2
  %t6 = extractvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, 3
  %t7 = extractvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, 4
  %t8 = extractvalue { i32, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, 5
  %t9 = icmp ule i32 %t3, 1
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_1_1, %edge_2 ]
  %p_2_1 = phi i32 [ %t3, %edge_2 ]
  %p_2_2 = phi %hia.buffer [ %t4, %edge_2 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_2 ]
  %p_2_4 = phi %hia.buffer [ %t6, %edge_2 ]
  %p_2_5 = phi i64 [ %t7, %edge_2 ]
  %p_2_6 = phi i64 [ %t8, %edge_2 ]
  %t10 = icmp eq i32 %p_2_1, 1
  %t11 = select i1 %t10, i8 2, i8 1
  %t12 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %t11, 0
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t12, %hia.buffer %p_2_0, 1
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t13, %hia.buffer %p_2_2, 2
  %t15 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t14, %hia.buffer %p_2_3, 3
  %t16 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t15, %hia.buffer %p_2_4, 4
  %t17 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t16, i64 %p_2_5, 5
  %t18 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t17, i64 %p_2_6, 6
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_1, %edge_3 ]
  %p_3_1 = phi i32 [ %t3, %edge_3 ]
  %p_3_2 = phi %hia.buffer [ %t4, %edge_3 ]
  %p_3_3 = phi %hia.buffer [ %t5, %edge_3 ]
  %p_3_4 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_3_5 = phi i64 [ %t7, %edge_3 ]
  %p_3_6 = phi i64 [ %t8, %edge_3 ]
  call void @abort()
  unreachable
b4:
  %p_4_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_4_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_4_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_4_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_4_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_4_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_4_6 = phi i64 [ %p_0_6, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b4
edge_2:
  br label %b2
edge_3:
  br label %b3
}

define i64 @cleanup_case(i8 zeroext %a0, i64 %a1, i64 %a2, i8 zeroext %a3) {
entry:
  %result = call i64 @__hia_fn_3(i8 %a0, i64 %a1, i64 %a2, i8 %a3)
  ret i64 %result
}
