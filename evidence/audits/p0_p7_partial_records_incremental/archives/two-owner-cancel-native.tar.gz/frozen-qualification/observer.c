
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/resource.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[8]; static size_t sizes[8], ids[8], releases[8];
static size_t attempts, allocations, frees, failures, live, live_bytes, peak_bytes, invalid_frees, null_frees, fail_at;
static void *remember(void *p,size_t n) {
  if(!p)return p;size_t i;for(i=0;i<8 && addresses[i];i++);if(i==8)exit(89);
  addresses[i]=p;sizes[i]=n;ids[i]=++allocations;live++;live_bytes+=n;
  if(live_bytes>peak_bytes)peak_bytes=live_bytes;return p;
}
void *__wrap_malloc(size_t n) {
  attempts++;if(attempts==fail_at){failures++;return NULL;}return remember(__real_malloc(n),n);
}
void *__wrap_calloc(size_t n,size_t width) {
  attempts++;if(attempts==fail_at){failures++;return NULL;}return remember(__real_calloc(n,width),n*width);
}
void __wrap_free(void *p) {
  if(!p){null_frees++;__real_free(p);return;}
  size_t i;for(i=0;i<8 && addresses[i]!=p;i++);if(i==8){invalid_frees++;return;}
  releases[frees++]=ids[i];live--;live_bytes-=sizes[i];addresses[i]=NULL;__real_free(p);
}
extern size_t cleanup_case(uint8_t,size_t,size_t,uint8_t);
struct input {uint8_t mode;size_t first,second;uint8_t tag;size_t fail;};
static const struct input inputs[]={{0,7,11,73,0},
{0,1,3,0,0},
{0,7,11,255,1},
{0,7,11,73,2},
{0,0,11,73,0},
{0,7,0,73,0},
{0,0,0,73,0},
{0,7,11,73,3},
{1,7,11,73,0},
{1,1,3,0,0},
{1,7,11,255,1},
{1,7,11,73,2},
{1,0,11,73,0},
{1,7,0,73,0},
{1,0,0,73,0},
{1,7,11,73,3},
{2,7,11,73,0},
{2,1,3,0,0},
{2,7,11,255,1},
{2,7,11,73,2},
{2,0,11,73,0},
{2,7,0,73,0},
{2,0,0,73,0},
{2,7,11,73,3},
{3,7,11,73,0},
{3,1,3,0,0},
{3,7,11,255,1},
{3,7,11,73,2},
{3,0,11,73,0},
{3,7,0,73,0},
{3,0,0,73,0},
{3,7,11,73,3}};
int main(int argc,char **argv) {
  struct rlimit no_core={0,0};if(setrlimit(RLIMIT_CORE,&no_core))return 88;
  if(sizeof(size_t)!=8 || argc!=2)return 87;size_t index=(size_t)strtoull(argv[1],NULL,10);
  if(index>=sizeof(inputs)/sizeof(inputs[0]))return 86;
  struct input c=inputs[index];fail_at=c.fail;
  size_t value=cleanup_case(c.mode,c.first,c.second,c.tag);
  printf("{\"result\":%zu,\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,\"failures\":%zu,\"live\":%zu,\"live_bytes\":%zu,\"peak_bytes\":%zu,\"invalid_frees\":%zu,\"null_frees\":%zu,\"free_order\":[",value,attempts,allocations,frees,failures,live,live_bytes,peak_bytes,invalid_frees,null_frees);
  for(size_t i=0;i<frees;i++)printf(i ? ",%zu" : "%zu",releases[i]);
  puts("]}");return live || invalid_frees || null_frees ? 91 : 0;
}
