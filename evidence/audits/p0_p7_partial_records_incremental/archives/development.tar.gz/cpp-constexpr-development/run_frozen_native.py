#!/usr/bin/python3
"""Execute only the predeclared finite constexpr native gate on a frozen head."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
HELPER = Path('/tmp/hepta-final-integrated-e6379178/runner.py')
HELPER_SHA = '990d86847853b9370a70ce370d7222ef0f287751f22d62cbe25c2593de8ea5c0'
TOOLS = {
    'python': '/usr/bin/python3',
    'clang': '/usr/lib/llvm-20/bin/clang',
    'clangxx': '/usr/lib/llvm-20/bin/clang++',
    'ld': '/usr/bin/ld',
    'nm': '/usr/bin/nm',
    'readelf': '/usr/bin/readelf',
    'llvm_readobj': '/usr/lib/llvm-20/bin/llvm-readobj',
}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--output-directory', required=True, type=Path)
    args = parser.parse_args()
    if sha(HELPER) != HELPER_SHA:
        raise ValueError('Previously reviewed process cleanup helper changed')
    spec = importlib.util.spec_from_file_location('hepta_reviewed_frozen_runner', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.TOOLS = TOOLS
    sys.path.insert(0, str(ROOT))
    from tools.release_check import snapshot

    def source():
        def git(*argv):
            return subprocess.check_output(['git', *argv], cwd=ROOT, text=True).strip()
        return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'status': git('status', '--porcelain'), 'snapshot': snapshot()}

    directory = args.output_directory.absolute()
    directory.mkdir(exist_ok=False, parents=True)
    before = source()
    if before['commit'] != args.expected_commit or before['status']:
        write(directory / 'preflight-rejection.json', {'expected_commit': args.expected_commit, 'actual': before})
        return 1
    tools_before = helper.tool_identity(True)
    if any('error' in row for row in tools_before.values()):
        write(directory / 'preflight-rejection.json', {'tools': tools_before})
        return 1
    env = os.environ.copy()
    controlled = {'PYTHONDONTWRITEBYTECODE': '1', 'CLANG': TOOLS['clang'], 'CLANGXX': TOOLS['clangxx'],
                  'PATH': '/usr/lib/llvm-20/bin:/usr/bin:/bin'}
    env.update(controlled)
    argv = [TOOLS['python'], 'tools/qualify_cpp_constexpr.py', '--output-directory', str(directory / 'native-80'),
            '--clang', TOOLS['clang'], '--clangxx', TOOLS['clangxx']]
    plan = {'schema': 'hepta.cpp-constexpr-frozen-run-plan.v1', 'expected_commit': args.expected_commit,
            'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': 180,
            'stdout_limit_bytes': 4_000_000, 'stderr_limit_bytes': 4_000_000,
            'controlled_environment': controlled, 'source_before': before, 'tools_before': tools_before,
            'runner_sha256': sha(__file__), 'cleanup_helper_sha256': HELPER_SHA,
            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(directory / 'plan.json', plan)
    start = time.monotonic()
    timed_out, output_exceeded, cleanup = False, False, None
    with (directory / 'stdout.log').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        original = helper.process(child.pid)
        write(directory / 'started.json', {'pid': child.pid, 'original_process': original})
        while child.poll() is None:
            timed_out = time.monotonic() - start >= 180
            output_exceeded = any(os.fstat(stream.fileno()).st_size > 4_000_000 for stream in (stdout, stderr))
            if timed_out or output_exceeded:
                cleanup = helper.stop_owned_tree(child, original, directory / 'cleanup-signals.jsonl')
                break
            time.sleep(.05)
        returncode = child.wait(timeout=10)
    after = source()
    tools_after = helper.tool_identity(False)
    native_file = directory / 'native-80/report.json'
    native = json.loads(native_file.read_text()) if native_file.is_file() else None
    passed = (returncode == 0 and not timed_out and not output_exceeded
              and before == after and helper.same_tools(tools_before, tools_after)
              and native is not None and native.get('ok') is True
              and native.get('case_count') == 80 and native.get('native_result_executions') == 160)
    report = {'schema': 'hepta.cpp-constexpr-frozen-run.v1', 'passed': passed,
              'returncode': returncode, 'timed_out': timed_out, 'output_exceeded': output_exceeded,
              'cleanup': cleanup, 'seconds': time.monotonic() - start,
              'source_before': before, 'source_after': after, 'source_unchanged': before == after,
              'tools_before': tools_before, 'tools_after': tools_after,
              'tools_unchanged': helper.same_tools(tools_before, tools_after),
              'native_report_sha256': sha(native_file) if native_file.is_file() else None,
              'case_count': None if native is None else native.get('case_count'),
              'native_result_executions': None if native is None else native.get('native_result_executions'),
              'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(directory / 'report.json', report)
    write(directory / 'manifest.json', {'schema': 'hepta.cpp-constexpr-frozen-manifest.v1',
        'files': [{'path': str(path.relative_to(directory)), 'bytes': path.stat().st_size, 'sha256': sha(path)}
                  for path in sorted(directory.rglob('*')) if path.is_file()]})
    print(json.dumps({key: report[key] for key in ('passed', 'returncode', 'seconds', 'source_unchanged',
        'tools_unchanged', 'case_count', 'native_result_executions')}, sort_keys=True))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
