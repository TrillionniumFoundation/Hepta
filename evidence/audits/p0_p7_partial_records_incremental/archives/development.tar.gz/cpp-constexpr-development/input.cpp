template<class T> T choose(T x) noexcept { if constexpr (sizeof(T)==4) { return x+3; } else { return x+5; } }
extern "C" unsigned pick32(unsigned x) noexcept { return choose(x); }
extern "C" unsigned long pick64(unsigned long x) noexcept { return choose(x); }
