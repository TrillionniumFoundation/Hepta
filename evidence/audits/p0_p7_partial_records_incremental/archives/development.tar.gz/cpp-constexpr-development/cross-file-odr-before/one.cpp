template<class T> T choose(T value) noexcept { if constexpr (sizeof(T)==4) {return value+3;} else {return value+7;} }
extern "C" unsigned one(unsigned value) noexcept {return choose(value);}
