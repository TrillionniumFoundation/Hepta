template<class T> T choose(T value) noexcept { if constexpr (sizeof(T)==4) {return value+3;} else {return value+11;} }
extern "C" unsigned two(unsigned value) noexcept {return choose(value);}
