import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
sys.path.insert(0, str(ROOT))
from hepta import hia_program as current
from hepta.hia_incremental import IncrementalVerifier
from tests.test_hia_incremental import graph
from tests.test_hia_program import resource_program, joined_loan_program, arithmetic
from tests.test_hia_edit_batch import loans
from tests.test_hia_bulk_memory import bulk_program
from tests.test_hia_offset_copy_v5 import copy_program
from tests.test_hia_range_fill_v6 import fill_program
from tests.test_hia_recursive_chain import doc as chain_program

OUT = Path(__file__).resolve().parent
OLD_COMMIT = 'e6379178a3e9a682f88c344aaa86b3d74932ffd7'
old_bytes = subprocess.check_output(['git', 'show', OLD_COMMIT + ':hepta/hia_program.py'], cwd=ROOT)
(OUT/'prior-hia_program.py').write_bytes(old_bytes)
baseline = types.ModuleType('hepta._p6_prior_verifier')
baseline.__package__ = 'hepta'
sys.modules[baseline.__name__] = baseline
exec(compile(old_bytes, str(OUT/'prior-hia_program.py'), 'exec'), baseline.__dict__)

def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def identity():
    names = ['hepta/hia_program.py', 'hepta/hia_incremental.py', 'hepta/hia_program_tools.py',
             'hepta/hia_schema.py', 'hepta/hia_json_preflight.py',
             'tests/test_hia_incremental.py', 'tests/test_hia_program.py',
             'tests/test_hia_edit_batch.py', 'tests/test_hia_bulk_memory.py',
             'tests/test_hia_offset_copy_v5.py', 'tests/test_hia_range_fill_v6.py',
             'tests/test_hia_recursive_chain.py']
    return {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names}

def result(call, doc):
    try:
        checked = call(doc)
        if type(checked) is tuple:
            checked = checked[0]
        return {'status': 'accepted', 'canonical_sha256': checked.sha256,
                'canonical_hex': checked.canonical_bytes.hex()}
    except (current.HIAProgramRejected, baseline.HIAProgramRejected) as exc:
        return {'status': 'rejected', 'code': exc.code, 'message': str(exc)}

before = identity()
bases = [(f'graph_v{v}', graph(v)) for v in range(1, 8)]
bases.extend([('resource', resource_program()), ('joined_loan', joined_loan_program()),
              ('loans', loans()), ('bulk', bulk_program()), ('range_copy', copy_program()),
              ('range_fill', fill_program()), ('chain', chain_program())])
rows = []
raw = []
for label, base in bases:
    assert result(current.verify_program, base)['status'] == 'accepted', label
    assert result(baseline.verify_program, base)['status'] == 'accepted', label
    candidates = [('unchanged', copy.deepcopy(base))]
    duplicate = copy.deepcopy(base)
    duplicate['functions'].append(copy.deepcopy(duplicate['functions'][0]))
    candidates.append(('duplicate_function', duplicate))
    unknown_export = copy.deepcopy(base)
    unknown_export['exports'] = ['not_present']
    candidates.append(('missing_export', unknown_export))
    for fi, fn in enumerate(base['functions']):
        effects = copy.deepcopy(base)
        effects['functions'][fi]['effects'] = []
        candidates.append((f'f{fi}_remove_effects', effects))
        for bi, block in enumerate(fn['blocks']):
            for oi, operation in enumerate(block['ops']):
                for mutation in ('opcode', 'attribute', 'operand', 'delete'):
                    changed = copy.deepcopy(base)
                    ops = changed['functions'][fi]['blocks'][bi]['ops']
                    if mutation == 'opcode':
                        ops[oi]['op'] = 'unsupported.control'
                    elif mutation == 'attribute':
                        ops[oi]['attrs']['unmodeled'] = True
                    elif mutation == 'operand':
                        ops[oi]['args'] = ['missing_value']
                    else:
                        del ops[oi]
                    candidates.append((f'f{fi}_b{bi}_o{oi}_{mutation}', changed))
    session = IncrementalVerifier(base)
    # Each candidate is compared against the same fully verified base; a new
    # session avoids changing the mutation meaning after an accepted case.
    for name, candidate in candidates:
        session = IncrementalVerifier(base)
        old = result(baseline.verify_program, candidate)
        full = result(current.verify_program, candidate)
        incremental = result(session.verify, candidate)
        same = old == full == incremental
        rows.append({'base': label, 'case': name, 'equal': same,
                     'prior': old, 'full': full, 'incremental': incremental})
        raw.append({'base_name': label, 'case': name, 'base': base, 'candidate': candidate})

after = identity()
raw_path = OUT/'prior-verifier-cases.jsonl'
raw_path.write_bytes(b''.join(wire(value)+b'\n' for value in raw))
report = {
    'schema': 'hepta.hia.incremental-development-comparison.v1',
    'kind': 'uncommitted_component_development_audit_not_frozen_qualification',
    'prior_verifier_source_commit': OLD_COMMIT,
    'prior_verifier_source_sha256': hashlib.sha256(old_bytes).hexdigest(),
    'dependency_scope': 'Prior verifier source uses current imported registry; only existing primitive v1-v7 inputs compared. This is not an execution relabeled as e6379178.',
    'source_before': before, 'source_after': after, 'selected_sources_unchanged': before == after,
    'cases': len(rows), 'accepted': sum(r['full']['status'] == 'accepted' for r in rows),
    'rejected': sum(r['full']['status'] == 'rejected' for r in rows),
    'mismatches': sum(not r['equal'] for r in rows),
    'cases_file_sha256': hashlib.sha256(raw_path.read_bytes()).hexdigest(),
    'records': rows,
}
(OUT/'prior-verifier-comparison.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
print(json.dumps({k: v for k, v in report.items() if k not in {'records', 'source_before', 'source_after'}}, indent=2))
assert report['mismatches'] == 0 and before == after
