import copy
import hashlib
import json
import subprocess
import sys
import types
from pathlib import Path

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
sys.path.insert(0, str(ROOT))
from hepta.hia_program import HIAProgramRejected, verify_core
from hepta.hia_program_composite import elaborate_program
from tests.test_hia_program import b, f, i, ret
from tests.test_hia_program_composite import (
    stored_loan_program, enum_owner_program, task_program, scalar_task_program,
    owned_result_task_program, module, record)
from tests.test_hia_composite_v6_resources import (
    composite_bulk_program, composite_range_task_program)
from tools.qualify_hia_composite_bulk import composite_bulk_program as qualification_bulk
from tests.test_hia_recursive_chain import doc

BASE = 'e6379178a3e9a682f88c344aaa86b3d74932ffd7'
blob = subprocess.check_output(['git', 'show', BASE + ':hepta/hia_program_composite.py'], cwd=ROOT)
old = types.ModuleType('hepta._partial_record_legacy_reference')
old.__file__ = str(ROOT / 'hepta/hia_program_composite.py')
old.__package__ = 'hepta'
sys.modules[old.__name__] = old
exec(compile(blob, old.__file__, 'exec'), old.__dict__)

def run(elaborator, source):
    try:
        core = verify_core(elaborator(copy.deepcopy(source)))
        return {'admitted': True, 'canonical_sha256': core.sha256,
                'canonical_bytes': core.canonical_bytes}
    except HIAProgramRejected as exc:
        return {'admitted': False, 'code': exc.code}

rows = []
def compare(name, source):
    before, after = run(old.elaborate_program, source), run(elaborate_program, source)
    assert before['admitted'] == after['admitted'], name
    if before['admitted']:
        assert before['canonical_bytes'] == after['canonical_bytes'], name
    rows.append({'name': name, 'schema': source['schema'],
                 'input_sha256': hashlib.sha256(json.dumps(source, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                 'before': {k:v for k,v in before.items() if k != 'canonical_bytes'},
                 'after': {k:v for k,v in after.items() if k != 'canonical_bytes'}})

factories = [stored_loan_program, enum_owner_program, task_program,
             scalar_task_program, owned_result_task_program, composite_bulk_program,
             composite_range_task_program, qualification_bulk]
for version in [1, 2]:
    schema = 'hepta.hia.composite.v' + str(version)
    for factory in factories:
        source = factory(); source['schema'] = schema
        compare(factory.__module__ + '.' + factory.__name__ + ':v' + str(version), source)
    for opcode in ['record.begin', 'record.take', 'record.insert', 'record.finish', 'record.abandon']:
        source = module([], f('main', [], [], ['alloc'], [b('entry', [], [i(opcode)], ret())]))
        source['schema'] = schema
        compare(opcode + ':old-op-negative:v' + str(version), source)
    typ = {'partial': 'R', 'initialized': []}
    source = module([record('R', [('value','buffer')])],
                    f('main', [('state', typ)], [], ['trap'],
                      [b('entry', [('state', typ)], [], {'op': 'trap', 'code': 'user'})]))
    source['schema'] = schema
    compare('partial-type-negative:v' + str(version), source)

compare('v2-chain', doc('composite_v2'))
report = {'schema':'hepta.partial-record-legacy-elaboration-comparison.v1',
          'base_commit':BASE, 'base_composite_source_sha256':hashlib.sha256(blob).hexdigest(),
          'scope':'finite v1/v2 elaboration canonical bytes and rejection outcomes; no native execution or whole-language proof',
          'cases':rows, 'case_count':len(rows),
          'admitted_equal':sum(r['before']['admitted'] for r in rows),
          'rejected_both':sum(not r['before']['admitted'] for r in rows), 'passed':True}
out=Path('/tmp/hepta-partial-v3-validation-20261028/legacy-comparison.json')
out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
