; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i1 %p_0_0) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  ret i32 1
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  ret i32 0
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_1(i32 %p_0_0) {
b0:
  %t1 = trunc i64 7 to i32
  %t2 = add i32 %p_0_0, %t1
  %t3 = add i32 %t2, %p_0_0
  ret i32 %t3
}

define internal i32 @__hia_fn_2(i32 %p_0_0) {
b0:
  %t1 = trunc i64 19 to i32
  %t2 = add i32 %p_0_0, %t1
  ret i32 %t2
}

define internal i64 @__hia_fn_3(i64 %p_0_0) {
b0:
  %t1 = trunc i64 11 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = add i64 %p_0_0, %t2
  ret i64 %t3
}

define internal i32 @__hia_fn_4(i32 %p_0_0) {
b0:
  %t1 = trunc i64 7 to i32
  %t2 = add i32 %p_0_0, %t1
  ret i32 %t2
}

define internal i32 @__hia_fn_5(i32 %p_0_0) {
b0:
  %t1 = trunc i64 11 to i32
  %t2 = add i32 %p_0_0, %t1
  %t3 = add i32 %t2, %p_0_0
  ret i32 %t3
}

define internal i32 @__hia_fn_6(i32 %p_0_0) {
b0:
  %t1 = trunc i64 3 to i32
  %t2 = add i32 %p_0_0, %t1
  ret i32 %t2
}

define internal i64 @__hia_fn_7(i64 %p_0_0) {
b0:
  %t1 = trunc i64 13 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = add i64 %p_0_0, %t2
  ret i64 %t3
}

define internal i32 @__hia_fn_8(i32 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_2(i32 %p_0_0)
  ret i32 %t1
}

define internal i32 @__hia_fn_9(i32 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_6(i32 %p_0_0)
  ret i32 %t1
}

define internal i32 @__hia_fn_10(i32 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_4(i32 %p_0_0)
  ret i32 %t1
}

define internal i32 @__hia_fn_11(i32 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_6(i32 %p_0_0)
  ret i32 %t1
}

define internal i32 @__hia_fn_12(i32 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_1(i32 %p_0_0)
  ret i32 %t1
}

define internal i32 @__hia_fn_13(i32 %p_0_0) {
b0:
  %t1 = call i32 @__hia_fn_5(i32 %p_0_0)
  ret i32 %t1
}

define internal i64 @__hia_fn_14(i64 %p_0_0) {
b0:
  %t1 = call i64 @__hia_fn_3(i64 %p_0_0)
  ret i64 %t1
}

define internal i64 @__hia_fn_15(i64 %p_0_0) {
b0:
  %t1 = call i64 @__hia_fn_7(i64 %p_0_0)
  ret i64 %t1
}

define i32 @c_bool_to_int(i1 zeroext %a0) {
entry:
  %result = call i32 @__hia_fn_0(i1 %a0)
  ret i32 %result
}

define i32 @cpp_0b57531b40d80e17e7593bbb(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_1(i32 %a0)
  ret i32 %result
}

define i32 @cpp_28ea7f2689d7011f56230177(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_2(i32 %a0)
  ret i32 %result
}

define i64 @cpp_314ca8c2eb9e21944e0fc856(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_3(i64 %a0)
  ret i64 %result
}

define i32 @cpp_3abcca0d17c01cf353183bcb(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_4(i32 %a0)
  ret i32 %result
}

define i32 @cpp_6efcf89e12c54a37f59c5439(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_5(i32 %a0)
  ret i32 %result
}

define i32 @cpp_d052a5119cda7379919635a9(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_6(i32 %a0)
  ret i32 %result
}

define i64 @cpp_e180dd4c4e3aa98f509b3820(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_7(i64 %a0)
  ret i64 %result
}

define i32 @discard_object(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_8(i32 %a0)
  ret i32 %result
}

define i32 @narrow0(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_9(i32 %a0)
  ret i32 %result
}

define i32 @narrow1(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_10(i32 %a0)
  ret i32 %result
}

define i32 @repeated_narrow(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_11(i32 %a0)
  ret i32 %result
}

define i32 @scope0(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_12(i32 %a0)
  ret i32 %result
}

define i32 @scope1(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_13(i32 %a0)
  ret i32 %result
}

define i64 @wide0(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_14(i64 %a0)
  ret i64 %result
}

define i64 @wide1(i64 %a0) {
entry:
  %result = call i64 @__hia_fn_15(i64 %a0)
  ret i64 %result
}
