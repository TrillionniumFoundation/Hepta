
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/resource.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void *);
static void *addresses[64]; static size_t sizes[64], ids[64], release_order[64];
static size_t attempts, allocations, frees, live, live_bytes, peak_bytes, refusals, invalid_frees, null_frees, fail_at;
static void *remember(void *p,size_t n) {
  if(!p)return p;
  size_t i;for(i=0;i<64 && addresses[i];i++);if(i==64)exit(89);
  addresses[i]=p;sizes[i]=n;ids[i]=++allocations;live++;live_bytes+=n;
  if(live_bytes>peak_bytes)peak_bytes=live_bytes;return p;
}
void *__wrap_malloc(size_t n) {
  attempts++;if(attempts==fail_at){refusals++;return NULL;}
  return remember(__real_malloc(n),n);
}
void *__wrap_calloc(size_t n,size_t width) {
  attempts++;if(attempts==fail_at){refusals++;return NULL;}
  return remember(__real_calloc(n,width),n*width);
}
void __wrap_free(void *p) {
  if(!p){null_frees++;__real_free(p);return;}
  size_t i;for(i=0;i<64 && addresses[i]!=p;i++);
  if(i==64){invalid_frees++;return;}
  release_order[frees++]=ids[i];live--;live_bytes-=sizes[i];addresses[i]=NULL;__real_free(p);
}
extern size_t partial_case(uint8_t,size_t,uint8_t);
extern size_t partial_task(uint8_t,size_t,uint8_t);
struct input {unsigned kind;uint8_t mode;uint64_t size;uint8_t byte;size_t fail;};
static const struct input inputs[]={{0,0,UINT64_C(0),0,0},
{0,0,UINT64_C(0),0,1},
{0,0,UINT64_C(0),0,2},
{0,0,UINT64_C(0),0,3},
{0,0,UINT64_C(0),73,0},
{0,0,UINT64_C(0),73,1},
{0,0,UINT64_C(0),73,2},
{0,0,UINT64_C(0),73,3},
{0,0,UINT64_C(0),255,0},
{0,0,UINT64_C(0),255,1},
{0,0,UINT64_C(0),255,2},
{0,0,UINT64_C(0),255,3},
{0,1,UINT64_C(0),0,0},
{0,1,UINT64_C(0),0,1},
{0,1,UINT64_C(0),0,2},
{0,1,UINT64_C(0),0,3},
{0,1,UINT64_C(0),73,0},
{0,1,UINT64_C(0),73,1},
{0,1,UINT64_C(0),73,2},
{0,1,UINT64_C(0),73,3},
{0,1,UINT64_C(0),255,0},
{0,1,UINT64_C(0),255,1},
{0,1,UINT64_C(0),255,2},
{0,1,UINT64_C(0),255,3},
{0,0,UINT64_C(1),0,0},
{0,0,UINT64_C(1),0,1},
{0,0,UINT64_C(1),0,2},
{0,0,UINT64_C(1),0,3},
{0,0,UINT64_C(1),73,0},
{0,0,UINT64_C(1),73,1},
{0,0,UINT64_C(1),73,2},
{0,0,UINT64_C(1),73,3},
{0,0,UINT64_C(1),255,0},
{0,0,UINT64_C(1),255,1},
{0,0,UINT64_C(1),255,2},
{0,0,UINT64_C(1),255,3},
{0,1,UINT64_C(1),0,0},
{0,1,UINT64_C(1),0,1},
{0,1,UINT64_C(1),0,2},
{0,1,UINT64_C(1),0,3},
{0,1,UINT64_C(1),73,0},
{0,1,UINT64_C(1),73,1},
{0,1,UINT64_C(1),73,2},
{0,1,UINT64_C(1),73,3},
{0,1,UINT64_C(1),255,0},
{0,1,UINT64_C(1),255,1},
{0,1,UINT64_C(1),255,2},
{0,1,UINT64_C(1),255,3},
{0,0,UINT64_C(7),0,0},
{0,0,UINT64_C(7),0,1},
{0,0,UINT64_C(7),0,2},
{0,0,UINT64_C(7),0,3},
{0,0,UINT64_C(7),73,0},
{0,0,UINT64_C(7),73,1},
{0,0,UINT64_C(7),73,2},
{0,0,UINT64_C(7),73,3},
{0,0,UINT64_C(7),255,0},
{0,0,UINT64_C(7),255,1},
{0,0,UINT64_C(7),255,2},
{0,0,UINT64_C(7),255,3},
{0,1,UINT64_C(7),0,0},
{0,1,UINT64_C(7),0,1},
{0,1,UINT64_C(7),0,2},
{0,1,UINT64_C(7),0,3},
{0,1,UINT64_C(7),73,0},
{0,1,UINT64_C(7),73,1},
{0,1,UINT64_C(7),73,2},
{0,1,UINT64_C(7),73,3},
{0,1,UINT64_C(7),255,0},
{0,1,UINT64_C(7),255,1},
{0,1,UINT64_C(7),255,2},
{0,1,UINT64_C(7),255,3},
{0,0,UINT64_C(9223372036854775808),73,0},
{0,1,UINT64_C(9223372036854775808),73,0},
{0,0,UINT64_C(18446744073709551615),73,0},
{0,1,UINT64_C(18446744073709551615),73,0},
{1,0,UINT64_C(0),73,0},
{1,0,UINT64_C(0),73,1},
{1,1,UINT64_C(0),73,0},
{1,1,UINT64_C(0),73,1},
{1,2,UINT64_C(0),73,0},
{1,2,UINT64_C(0),73,1},
{1,0,UINT64_C(1),73,0},
{1,0,UINT64_C(1),73,1},
{1,1,UINT64_C(1),73,0},
{1,1,UINT64_C(1),73,1},
{1,2,UINT64_C(1),73,0},
{1,2,UINT64_C(1),73,1},
{1,0,UINT64_C(7),73,0},
{1,0,UINT64_C(7),73,1},
{1,1,UINT64_C(7),73,0},
{1,1,UINT64_C(7),73,1},
{1,2,UINT64_C(7),73,0},
{1,2,UINT64_C(7),73,1}};
int main(int argc,char **argv) {
  struct rlimit no_core={0,0};if(setrlimit(RLIMIT_CORE,&no_core))return 88;
  if(argc!=2)return 87;size_t index=(size_t)strtoull(argv[1],NULL,10);
  if(index>=sizeof(inputs)/sizeof(inputs[0]))return 86;
  struct input c=inputs[index];fail_at=c.fail;
  size_t value=c.kind ? partial_task(c.mode,(size_t)c.size,c.byte) : partial_case(c.mode,(size_t)c.size,c.byte);
  printf("{\"result\":%zu,\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,\"live\":%zu,\"live_bytes\":%zu,\"peak_bytes\":%zu,\"refusals\":%zu,\"invalid_frees\":%zu,\"null_frees\":%zu,\"free_order\":[",value,attempts,allocations,frees,live,live_bytes,peak_bytes,refusals,invalid_frees,null_frees);
  for(size_t i=0;i<frees;i++)printf(i ? ",%zu" : "%zu",release_order[i]);
  puts("]}");return live || invalid_frees || null_frees ? 91 : 0;
}
