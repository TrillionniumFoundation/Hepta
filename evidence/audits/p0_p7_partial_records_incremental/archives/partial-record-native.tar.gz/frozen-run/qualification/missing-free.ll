; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1 immarg)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  br label %release_node
release_node:
  br label %loop
done:
  ret void
}
define internal void @__hia_fn_0(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_1, 0
  %t2 = icmp ne ptr %t1, null
  br i1 %t2, label %drop_nonnull_3, label %drop_after_3
drop_nonnull_3:
  br label %drop_after_3
drop_after_3:
  %t4 = extractvalue %hia.buffer %p_0_0, 0
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %drop_nonnull_6, label %drop_after_6
drop_nonnull_6:
  br label %drop_after_6
drop_after_6:
  ret void
}

define internal void @__hia_fn_1(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_1, 0
  %t2 = icmp ne ptr %t1, null
  br i1 %t2, label %drop_nonnull_3, label %drop_after_3
drop_nonnull_3:
  br label %drop_after_3
drop_after_3:
  %t4 = extractvalue %hia.buffer %p_0_0, 0
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %drop_nonnull_6, label %drop_after_6
drop_nonnull_6:
  br label %drop_after_6
drop_after_6:
  ret void
}

define internal void @__hia_fn_2(%hia.buffer %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_2, 0
  %t2 = icmp ne ptr %t1, null
  br i1 %t2, label %drop_nonnull_3, label %drop_after_3
drop_nonnull_3:
  br label %drop_after_3
drop_after_3:
  %t4 = extractvalue %hia.buffer %p_0_1, 0
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %drop_nonnull_6, label %drop_after_6
drop_nonnull_6:
  br label %drop_after_6
drop_after_6:
  %t7 = extractvalue %hia.buffer %p_0_0, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  br label %drop_after_9
drop_after_9:
  ret void
}

define internal { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } @__hia_fn_3(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2, i64 %p_0_3) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_3, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_3, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  %t6 = insertvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %p_0_0, 0
  %t7 = insertvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t6, %hia.buffer %p_0_1, 1
  %t8 = insertvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t7, %hia.buffer %t5, 2
  %t9 = insertvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t8, i64 %p_0_2, 3
  %t10 = insertvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t9, i1 %t3, 4
  ret { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t10
}

define internal i64 @__hia_fn_4(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = extractvalue %hia.buffer %p_0_1, 1
  %t3 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t1, i64 %t2)
  %t4 = extractvalue { i64, i1 } %t3, 0
  %t5 = extractvalue { i64, i1 } %t3, 1
  %t6 = xor i1 %t5, true
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t4, i64 %p_0_2)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = icmp eq i64 %t1, 0
  br i1 %t13, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %t9, %edge_0 ]
  %t14 = extractvalue %hia.buffer %p_1_0, 0
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %drop_nonnull_16, label %drop_after_16
drop_nonnull_16:
  br label %drop_after_16
drop_after_16:
  %t17 = extractvalue %hia.buffer %p_1_1, 0
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %drop_nonnull_19, label %drop_after_19
drop_nonnull_19:
  br label %drop_after_19
drop_after_19:
  ret i64 %p_1_2
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %t9, %edge_1 ]
  %t20 = extractvalue %hia.buffer %p_2_0, 0
  %t21 = extractvalue %hia.buffer %p_2_0, 1
  %t22 = icmp ult i64 0, %t21
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  %t24 = getelementptr i8, ptr %t20, i64 0
  %t25 = load i8, ptr %t24, align 1
  %t26 = extractvalue %hia.buffer %p_2_1, 0
  %t27 = extractvalue %hia.buffer %p_2_1, 1
  %t28 = icmp ult i64 0, %t27
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  %t30 = getelementptr i8, ptr %t26, i64 0
  %t31 = load i8, ptr %t30, align 1
  %t32 = zext i8 %t25 to i64
  %t33 = zext i8 %t31 to i64
  %t34 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_2_2, i64 %t32)
  %t35 = extractvalue { i64, i1 } %t34, 0
  %t36 = extractvalue { i64, i1 } %t34, 1
  %t37 = xor i1 %t36, true
  br i1 %t37, label %ok_38, label %trap_38
trap_38:
  call void @abort()
  unreachable
ok_38:
  %t39 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t35, i64 %t33)
  %t40 = extractvalue { i64, i1 } %t39, 0
  %t41 = extractvalue { i64, i1 } %t39, 1
  %t42 = xor i1 %t41, true
  br i1 %t42, label %ok_43, label %trap_43
trap_43:
  call void @abort()
  unreachable
ok_43:
  %t44 = extractvalue %hia.buffer %p_2_0, 0
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %drop_nonnull_46, label %drop_after_46
drop_nonnull_46:
  br label %drop_after_46
drop_after_46:
  %t47 = extractvalue %hia.buffer %p_2_1, 0
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %drop_nonnull_49, label %drop_after_49
drop_nonnull_49:
  br label %drop_after_49
drop_after_49:
  ret i64 %t40
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i64 @__hia_fn_5(i8 %p_0_0, i64 %p_0_1, i8 %p_0_2) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  %t6 = call %hia.alloc @__hia_allocate(i64 %p_0_1, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 %p_0_1, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  %t11 = zext i8 %p_0_2 to i64
  br i1 %t8, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_1_1 = phi %hia.buffer [ %t10, %edge_1 ]
  %p_1_2 = phi i64 [ %t11, %edge_1 ]
  call void @__hia_fn_0(%hia.buffer %p_1_0, %hia.buffer %p_1_1, i64 %p_1_2)
  ret i64 100
b2:
  %p_2_0 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_2_1 = phi %hia.buffer [ %t10, %edge_0 ]
  %p_2_2 = phi i64 [ %t11, %edge_0 ]
  %p_2_3 = phi i8 [ %p_0_0, %edge_0 ]
  %p_2_4 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_5 = phi i8 [ %p_0_2, %edge_0 ]
  %t12 = icmp eq i8 %p_2_3, 1
  br i1 %t12, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_2_2, %edge_2 ]
  call void @__hia_fn_0(%hia.buffer %p_3_0, %hia.buffer %p_3_1, i64 %p_3_2)
  ret i64 400
b4:
  %p_4_0 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_2_4, %edge_3 ]
  %p_4_4 = phi i8 [ %p_2_5, %edge_3 ]
  %t13 = call { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } @__hia_fn_3(%hia.buffer %p_4_0, %hia.buffer %p_4_1, i64 %p_4_2, i64 %p_4_3)
  %t14 = extractvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t13, 0
  %t15 = extractvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t13, 1
  %t16 = extractvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t13, 2
  %t17 = extractvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t13, 3
  %t18 = extractvalue { %hia.buffer, %hia.buffer, %hia.buffer, i64, i1 } %t13, 4
  br i1 %t18, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi %hia.buffer [ %t14, %edge_5 ]
  %p_5_1 = phi %hia.buffer [ %t15, %edge_5 ]
  %p_5_2 = phi %hia.buffer [ %t16, %edge_5 ]
  %p_5_3 = phi i64 [ %t17, %edge_5 ]
  call void @__hia_fn_2(%hia.buffer %p_5_0, %hia.buffer %p_5_1, %hia.buffer %p_5_2, i64 %p_5_3)
  ret i64 200
b6:
  %p_6_0 = phi %hia.buffer [ %t14, %edge_4 ]
  %p_6_1 = phi %hia.buffer [ %t15, %edge_4 ]
  %p_6_2 = phi %hia.buffer [ %t16, %edge_4 ]
  %p_6_3 = phi i64 [ %t17, %edge_4 ]
  %p_6_4 = phi i64 [ %p_4_3, %edge_4 ]
  %p_6_5 = phi i8 [ %p_4_4, %edge_4 ]
  %t19 = extractvalue %hia.buffer %p_6_0, 0
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %drop_nonnull_21, label %drop_after_21
drop_nonnull_21:
  br label %drop_after_21
drop_after_21:
  %t22 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t23 = extractvalue %hia.alloc %t22, 0
  %t24 = extractvalue %hia.alloc %t22, 1
  %t25 = select i1 %t24, i64 0, i64 0
  %t26 = insertvalue %hia.buffer %t23, i64 %t25, 1
  %t27 = extractvalue %hia.buffer %p_6_1, 0
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %drop_nonnull_29, label %drop_after_29
drop_nonnull_29:
  br label %drop_after_29
drop_after_29:
  %t30 = call %hia.alloc @__hia_allocate(i64 %p_6_4, i1 true)
  %t31 = extractvalue %hia.alloc %t30, 0
  %t32 = extractvalue %hia.alloc %t30, 1
  %t33 = select i1 %t32, i64 %p_6_4, i64 0
  %t34 = insertvalue %hia.buffer %t31, i64 %t33, 1
  br i1 %t32, label %edge_6, label %edge_7
b7:
  %p_7_0 = phi %hia.buffer [ %t26, %edge_7 ]
  %p_7_1 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_2 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_3 = phi %hia.buffer [ %t34, %edge_7 ]
  %t35 = extractvalue %hia.buffer %p_7_3, 0
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %drop_nonnull_37, label %drop_after_37
drop_nonnull_37:
  br label %drop_after_37
drop_after_37:
  call void @__hia_fn_1(%hia.buffer %p_7_0, %hia.buffer %p_7_1, i64 %p_7_2)
  ret i64 300
b8:
  %p_8_0 = phi %hia.buffer [ %t26, %edge_6 ]
  %p_8_1 = phi %hia.buffer [ %p_6_2, %edge_6 ]
  %p_8_2 = phi i64 [ %p_6_3, %edge_6 ]
  %p_8_3 = phi %hia.buffer [ %t34, %edge_6 ]
  %p_8_4 = phi i8 [ %p_6_5, %edge_6 ]
  %t38 = extractvalue %hia.buffer %p_8_3, 0
  %t39 = extractvalue %hia.buffer %p_8_3, 1
  %t40 = icmp ne i64 %t39, 0
  br i1 %t40, label %bulk_nonzero_41, label %bulk_after_41
bulk_nonzero_41:
  call void @llvm.memset.p0.i64(ptr align 1 %t38, i8 %p_8_4, i64 %t39, i1 false)
  br label %bulk_after_41
bulk_after_41:
  %t42 = extractvalue %hia.buffer %p_8_1, 0
  %t43 = extractvalue %hia.buffer %p_8_1, 1
  %t44 = icmp ne i64 %t43, 0
  br i1 %t44, label %bulk_nonzero_45, label %bulk_after_45
bulk_nonzero_45:
  call void @llvm.memset.p0.i64(ptr align 1 %t42, i8 17, i64 %t43, i1 false)
  br label %bulk_after_45
bulk_after_45:
  %t46 = extractvalue %hia.buffer %p_8_0, 0
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %drop_nonnull_48, label %drop_after_48
drop_nonnull_48:
  br label %drop_after_48
drop_after_48:
  %t49 = call i64 @__hia_fn_4(%hia.buffer %p_8_3, %hia.buffer %p_8_1, i64 %p_8_2)
  ret i64 %t49
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b6
edge_5:
  br label %b5
edge_6:
  br label %b8
edge_7:
  br label %b7
}

define internal { i32, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2) {
b0:
  call void @__hia_fn_0(%hia.buffer %p_0_0, %hia.buffer %p_0_1, i64 %p_0_2)
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  %t6 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 0, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  %t11 = insertvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i32 1, 0
  %t12 = insertvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t11, %hia.buffer %t5, 1
  %t13 = insertvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t12, %hia.buffer %t10, 2
  %t14 = insertvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t13, i64 0, 3
  %t15 = insertvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t14, i64 %p_0_2, 4
  ret { i32, %hia.buffer, %hia.buffer, i64, i64 } %t15
}

define internal i64 @__hia_fn_7(i8 %p_0_0, i64 %p_0_1, i8 %p_0_2) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  %t6 = call %hia.alloc @__hia_allocate(i64 %p_0_1, i1 true)
  %t7 = extractvalue %hia.alloc %t6, 0
  %t8 = extractvalue %hia.alloc %t6, 1
  %t9 = select i1 %t8, i64 %p_0_1, i64 0
  %t10 = insertvalue %hia.buffer %t7, i64 %t9, 1
  %t11 = zext i8 %p_0_2 to i64
  %t12 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t13 = extractvalue %hia.alloc %t12, 0
  %t14 = extractvalue %hia.alloc %t12, 1
  %t15 = select i1 %t14, i64 0, i64 0
  %t16 = insertvalue %hia.buffer %t13, i64 %t15, 1
  %t17 = icmp eq i8 %p_0_0, 0
  br i1 %t17, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ 0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %t16, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t10, %edge_0 ]
  %p_1_4 = phi i64 [ %t11, %edge_0 ]
  %p_1_5 = phi i64 [ 0, %edge_0 ]
  %t18 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %p_1_0, %hia.buffer %p_1_1, %hia.buffer %p_1_2, %hia.buffer %p_1_3, i64 %p_1_4, i64 %p_1_5)
  %t19 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, 0
  %t20 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, 1
  %t21 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, 2
  %t22 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, 3
  %t23 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, 4
  %t24 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t18, 5
  call void @__hia_fn_9(i8 %t19, %hia.buffer %t20, %hia.buffer %t21, %hia.buffer %t22, i64 %t23, i64 %t24)
  %t25 = zext i8 %t19 to i64
  ret i64 %t25
b2:
  %p_2_0 = phi i8 [ 0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t16, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t10, %edge_1 ]
  %p_2_4 = phi i64 [ %t11, %edge_1 ]
  %p_2_5 = phi i64 [ 0, %edge_1 ]
  %p_2_6 = phi i8 [ %p_0_0, %edge_1 ]
  %t26 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_10(i8 %p_2_0, %hia.buffer %p_2_1, %hia.buffer %p_2_2, %hia.buffer %p_2_3, i64 %p_2_4, i64 %p_2_5)
  %t27 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, 0
  %t28 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, 1
  %t29 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, 2
  %t30 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, 3
  %t31 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, 4
  %t32 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t26, 5
  %t33 = icmp eq i8 %p_2_6, 1
  br i1 %t33, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %t27, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %t28, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %t29, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %t30, %edge_2 ]
  %p_3_4 = phi i64 [ %t31, %edge_2 ]
  %p_3_5 = phi i64 [ %t32, %edge_2 ]
  %t34 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %p_3_0, %hia.buffer %p_3_1, %hia.buffer %p_3_2, %hia.buffer %p_3_3, i64 %p_3_4, i64 %p_3_5)
  %t35 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t34, 0
  %t36 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t34, 1
  %t37 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t34, 2
  %t38 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t34, 3
  %t39 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t34, 4
  %t40 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t34, 5
  call void @__hia_fn_9(i8 %t35, %hia.buffer %t36, %hia.buffer %t37, %hia.buffer %t38, i64 %t39, i64 %t40)
  %t41 = zext i8 %t35 to i64
  ret i64 %t41
b4:
  %p_4_0 = phi i8 [ %t27, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %t28, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %t29, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %t30, %edge_3 ]
  %p_4_4 = phi i64 [ %t31, %edge_3 ]
  %p_4_5 = phi i64 [ %t32, %edge_3 ]
  %t42 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_11(i8 %p_4_0, %hia.buffer %p_4_1, %hia.buffer %p_4_2, %hia.buffer %p_4_3, i64 %p_4_4, i64 %p_4_5)
  %t43 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t42, 0
  %t44 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t42, 1
  %t45 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t42, 2
  %t46 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t42, 3
  %t47 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t42, 4
  %t48 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t42, 5
  %t49 = call { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %t43, %hia.buffer %t44, %hia.buffer %t45, %hia.buffer %t46, i64 %t47, i64 %t48)
  %t50 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t49, 0
  %t51 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t49, 1
  %t52 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t49, 2
  %t53 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t49, 3
  %t54 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t49, 4
  %t55 = extractvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t49, 5
  %t56 = call i64 @__hia_fn_12(i8 %t50, %hia.buffer %t51, %hia.buffer %t52, %hia.buffer %t53, i64 %t54, i64 %t55)
  ret i64 %t56
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_8(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, i64 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = icmp ult i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  call void @__hia_fn_0(%hia.buffer %p_1_2, %hia.buffer %p_1_3, i64 %p_1_4)
  %t2 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  %t7 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t8 = extractvalue %hia.alloc %t7, 0
  %t9 = extractvalue %hia.alloc %t7, 1
  %t10 = select i1 %t9, i64 0, i64 0
  %t11 = insertvalue %hia.buffer %t8, i64 %t10, 1
  %t12 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 3, 0
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t12, %hia.buffer %p_1_1, 1
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t13, %hia.buffer %t6, 2
  %t15 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t14, %hia.buffer %t11, 3
  %t16 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t15, i64 0, 4
  %t17 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t16, i64 0, 5
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t17
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %t18 = icmp ule i8 %p_2_0, 3
  br i1 %t18, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi %hia.buffer [ %p_2_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_2_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_2_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_2_5, %edge_2 ]
  %t19 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %p_3_0, 0
  %t20 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t19, %hia.buffer %p_3_1, 1
  %t21 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t20, %hia.buffer %p_3_2, 2
  %t22 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t21, %hia.buffer %p_3_3, 3
  %t23 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t22, i64 %p_3_4, 4
  %t24 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t23, i64 %p_3_5, 5
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t24
b4:
  %p_4_0 = phi i8 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi %hia.buffer [ %p_2_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_2_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_3 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal void @__hia_fn_9(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, i64 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = icmp eq i8 %p_0_0, 3
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  br label %drop_after_4
drop_after_4:
  %t5 = extractvalue %hia.buffer %p_1_2, 0
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %drop_nonnull_7, label %drop_after_7
drop_nonnull_7:
  br label %drop_after_7
drop_after_7:
  %t8 = extractvalue %hia.buffer %p_1_3, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  br label %drop_after_10
drop_after_10:
  ret void
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_10(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, i64 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = icmp eq i8 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %t2 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 1, 0
  %t3 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t2, %hia.buffer %p_1_1, 1
  %t4 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t3, %hia.buffer %p_1_2, 2
  %t5 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t4, %hia.buffer %p_1_3, 3
  %t6 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t5, i64 %p_1_4, 4
  %t7 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t6, i64 %p_1_5, 5
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t7
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_11(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, i64 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = icmp eq i8 %p_0_0, 1
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %t2 = call { i32, %hia.buffer, %hia.buffer, i64, i64 } @__hia_fn_6(%hia.buffer %p_1_2, %hia.buffer %p_1_3, i64 %p_1_4)
  %t3 = extractvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t2, 0
  %t4 = extractvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t2, 1
  %t5 = extractvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t2, 2
  %t6 = extractvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t2, 3
  %t7 = extractvalue { i32, %hia.buffer, %hia.buffer, i64, i64 } %t2, 4
  %t8 = icmp ule i32 %t3, 1
  br i1 %t8, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_1_1, %edge_2 ]
  %p_2_1 = phi i32 [ %t3, %edge_2 ]
  %p_2_2 = phi %hia.buffer [ %t4, %edge_2 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_2 ]
  %p_2_4 = phi i64 [ %t6, %edge_2 ]
  %p_2_5 = phi i64 [ %t7, %edge_2 ]
  %t9 = icmp eq i32 %p_2_1, 1
  %t10 = select i1 %t9, i8 2, i8 1
  %t11 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } zeroinitializer, i8 %t10, 0
  %t12 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t11, %hia.buffer %p_2_0, 1
  %t13 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t12, %hia.buffer %p_2_2, 2
  %t14 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t13, %hia.buffer %p_2_3, 3
  %t15 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t14, i64 %p_2_4, 4
  %t16 = insertvalue { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t15, i64 %p_2_5, 5
  ret { i8, %hia.buffer, %hia.buffer, %hia.buffer, i64, i64 } %t16
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_1, %edge_3 ]
  %p_3_1 = phi i32 [ %t3, %edge_3 ]
  %p_3_2 = phi %hia.buffer [ %t4, %edge_3 ]
  %p_3_3 = phi %hia.buffer [ %t5, %edge_3 ]
  %p_3_4 = phi i64 [ %t6, %edge_3 ]
  %p_3_5 = phi i64 [ %t7, %edge_3 ]
  call void @abort()
  unreachable
b4:
  %p_4_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_4_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_4_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_4_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_4_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_4_5 = phi i64 [ %p_0_5, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b4
edge_2:
  br label %b2
edge_3:
  br label %b3
}

define internal i64 @__hia_fn_12(i8 %p_0_0, %hia.buffer %p_0_1, %hia.buffer %p_0_2, %hia.buffer %p_0_3, i64 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = icmp eq i8 %p_0_0, 2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %t2 = extractvalue %hia.buffer %p_1_1, 0
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %drop_nonnull_4, label %drop_after_4
drop_nonnull_4:
  br label %drop_after_4
drop_after_4:
  %t5 = extractvalue %hia.buffer %p_1_2, 0
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %drop_nonnull_7, label %drop_after_7
drop_nonnull_7:
  br label %drop_after_7
drop_after_7:
  %t8 = extractvalue %hia.buffer %p_1_3, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  br label %drop_after_10
drop_after_10:
  ret i64 %p_1_5
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define i64 @partial_case(i8 zeroext %a0, i64 %a1, i8 zeroext %a2) {
entry:
  %result = call i64 @__hia_fn_5(i8 %a0, i64 %a1, i8 %a2)
  ret i64 %result
}

define i64 @partial_task(i8 zeroext %a0, i64 %a1, i8 zeroext %a2) {
entry:
  %result = call i64 @__hia_fn_7(i8 %a0, i64 %a1, i8 %a2)
  ret i64 %result
}
