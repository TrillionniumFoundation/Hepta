#!/usr/bin/python3
"""Run the frozen partial-record corpus with retained native process evidence."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
OUT = Path('/tmp/hepta-partial-record-final-d942f18b-20261028')
EXPECTED = 'd942f18b07c8811aa1418b6f67fabc23212317d1'
EXPECTED_SNAPSHOT = '4a64e1a353585d0ee88985e4942c008bd82ec1482be7ce1158a60f24f550e8db'
HELPER = Path('/tmp/hepta-final-integrated-preparation-20261028/run_final_validation.py')
HELPER_SHA = '990d86847853b9370a70ce370d7222ef0f287751f22d62cbe25c2593de8ea5c0'
VM = Path('/tmp/hepta-final-integrated-e6379178/retained-vm/hia-core-shadow')
VM_SHA = '5ff3739ae9a03280d2a41adf82a7f4424853d5e03cfa7946409e652ac584c3ff'
TOOLS = {'python': '/usr/bin/python3', 'clang': '/usr/lib/llvm-20/bin/clang',
         'ld': '/usr/bin/ld', 'nm': '/usr/bin/nm', 'readelf': '/usr/bin/readelf'}
TIMEOUT = 300


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    assert sha(HELPER) == HELPER_SHA
    assert sha(VM) == VM_SHA
    spec = importlib.util.spec_from_file_location('reviewed_hepta_runner', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.TOOLS = TOOLS
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT))
    from tools.release_check import snapshot

    def source():
        def git(*args):
            return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
        return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'status': git('status', '--porcelain'), 'snapshot': snapshot()}

    def vm_identity():
        return {'path': str(VM), 'resolved_path': str(VM.resolve(strict=True)),
                'bytes': VM.stat().st_size, 'sha256': sha(VM)}

    OUT.mkdir(parents=True, exist_ok=False)
    before = source()
    assert before['commit'] == EXPECTED and not before['status']
    assert before['snapshot']['sha256'] == EXPECTED_SNAPSHOT
    tools_before = helper.tool_identity(True)
    tools_before['retained_rust_vm'] = vm_identity()
    assert all('error' not in row for row in tools_before.values())
    controlled = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
                  'PATH': '/usr/lib/llvm-20/bin:/usr/bin:/bin'}
    env = dict(os.environ, **controlled)
    argv = [TOOLS['python'], 'tools/qualify_hia_partial_records.py',
            '--output-directory', str(OUT / 'qualification'), '--clang', TOOLS['clang'],
            '--rust-vm', str(VM)]
    plan = {'schema': 'hepta.partial-record-frozen-run-plan.v1', 'expected_commit': EXPECTED,
            'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': TIMEOUT,
            'stdout_limit_bytes': 4_000_000, 'stderr_limit_bytes': 4_000_000,
            'controlled_environment': controlled, 'source_before': before,
            'tools_before': tools_before, 'runner_sha256': sha(__file__),
            'cleanup_helper_sha256': HELPER_SHA,
            'finite_plan': {'cases': 94, 'budget_cases': 11, 'budget_stops': 10,
                            'budget_return_controls': 1, 'positive_native_executions': 188,
                            'native_negative_controls': 2},
            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(OUT / 'plan.json', plan)
    start = time.monotonic()
    timed_out = output_exceeded = False
    cleanup = None
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                 start_new_session=True)
        original = helper.process(child.pid)
        write(OUT / 'started.json', {'pid': child.pid, 'original_process': original})
        while child.poll() is None:
            timed_out = time.monotonic() - start >= TIMEOUT
            output_exceeded = any(os.fstat(s.fileno()).st_size > 4_000_000 for s in (stdout, stderr))
            if timed_out or output_exceeded:
                cleanup = helper.stop_owned_tree(child, original, OUT / 'cleanup-signals.jsonl')
                break
            time.sleep(.05)
        code = child.wait(timeout=10)
    after = source()
    tools_after = helper.tool_identity(False)
    tools_after['retained_rust_vm'] = vm_identity()
    report_path = OUT / 'qualification/report.json'
    qualification = json.loads(report_path.read_text()) if report_path.is_file() else None
    counts = {} if qualification is None else {
        'differential_cases': len(qualification['differential']),
        'budget_cases': len(qualification['budgets']),
        'positive_native_executions': sum(len(x['cases']) for x in qualification['native'].values()),
        'native_negative_controls': len(qualification['negative_controls']),
        'budget_stops': sum(x['python']['status'] == 'budget_exceeded' for x in qualification['budgets']),
        'budget_return_controls': sum(x['python']['status'] == 'returned' for x in qualification['budgets'])}
    passed = (code == 0 and not timed_out and not output_exceeded and before == after
              and helper.same_tools(tools_before, tools_after)
              and qualification is not None and qualification['passed'] is True
              and qualification['git_commit'] == EXPECTED and not qualification['git_status']
              and counts == {'differential_cases': 94, 'budget_cases': 11,
                             'positive_native_executions': 188, 'native_negative_controls': 2,
                             'budget_stops': 10, 'budget_return_controls': 1})
    report = {'schema': 'hepta.partial-record-frozen-run.v1', 'passed': passed,
              'returncode': code, 'timed_out': timed_out, 'output_exceeded': output_exceeded,
              'cleanup': cleanup, 'seconds': time.monotonic() - start,
              'source_before': before, 'source_after': after, 'source_unchanged': before == after,
              'tools_before': tools_before, 'tools_after': tools_after,
              'tools_unchanged': helper.same_tools(tools_before, tools_after), 'counts': counts,
              'qualification_report_sha256': sha(report_path) if report_path.is_file() else None,
              'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(OUT / 'report.json', report)
    write(OUT / 'manifest.json', {'schema': 'hepta.partial-record-frozen-manifest.v1',
          'files': [{'path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                    for p in sorted(OUT.rglob('*')) if p.is_file()]})
    print(json.dumps({key: report[key] for key in ('passed', 'returncode', 'seconds',
                      'source_unchanged', 'tools_unchanged', 'counts')}, sort_keys=True))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
