#!/usr/bin/python3
"""Independently inspect sealed two-owner evidence without running any application."""
from pathlib import Path
import datetime
import hashlib
import json
import time

BASE = Path('/tmp/hepta-partial-two-owner-20261028')
ATTEMPT = BASE / 'attempt-01'
OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
COMMIT = 'd942f18b07c8811aa1418b6f67fabc23212317d1'
TREE = '44823c1858d52e9043edebb83f2414d91087d743'
SNAPSHOT = '4a64e1a353585d0ee88985e4942c008bd82ec1482be7ce1158a60f24f550e8db'
REPORT_HASH = 'aa014199d233845735ea6e12cba855710da01ce4184ef609bb5810b4a7f8af46'
SEAL_HASH = '94119f9672025c5157cb554f9328e92134ba759eead560bc4216cb9a1c922768'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def parse(data):
    return json.loads(data, object_pairs_hook=pairs)


def read(path):
    return parse(Path(path).read_bytes())


def descriptor(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def check_file(entry, base=BASE):
    path = Path(entry['path'])
    need(path.is_relative_to(base) and not path.is_symlink()
         and path.resolve().is_relative_to(base.resolve()), 'file escaped retained root')
    need(descriptor(path) == entry, 'retained file identity mismatch: ' + str(path))
    return path


def fixed_cases():
    configurations = [(7, 11, 73, 0), (1, 3, 0, 0), (7, 11, 255, 1), (7, 11, 73, 2),
                      (0, 11, 73, 0), (7, 0, 73, 0), (0, 0, 73, 0), (7, 11, 73, 3)]
    return [{'arguments': [mode, a, b, tag], 'allocation_fail_at': fail}
            for mode in range(4) for a, b, tag, fail in configurations]


def independent_expected(row):
    mode, a, b, tag = row['arguments']
    physical_sizes = [size for size in (a, b) if size > 0]
    successful_sizes = [size for attempt, size in enumerate(physical_sizes, 1)
                        if attempt != row['allocation_fail_at']]
    allocated = len(successful_sizes)
    return {'logical_owners': 3 if mode == 0 else 7,
            'native': {'result': 1000 + tag if mode == 0 else (mode + 1) * 1000 + 3,
                       'attempts': len(physical_sizes), 'allocations': allocated, 'frees': allocated,
                       'failures': len(physical_sizes) - allocated, 'live': 0, 'live_bytes': 0,
                       'peak_bytes': sum(successful_sizes), 'invalid_frees': 0, 'null_frees': 0,
                       'free_order': list(range(allocated, 0, -1))}}


def main():
    start = time.monotonic()
    review = {'schema': 'hepta.independent-two-owner-retained-review.v1', 'passed': False,
              'application_executions': 0, 'compiler_executions': 0, 'hepta_executor_imported': False,
              'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Finite selected cleanup/cancellation scenarios; public emit_program_llvm plus captured direct Clang/inspection/link. Production compile API was not invoked. Ordered release is observed by native C allocator instrumentation only.'}
    try:
        need(sha((BASE / 'seal.json').read_bytes()) == SEAL_HASH, 'wrong final seal identity')
        need(sha((ATTEMPT / 'report.json').read_bytes()) == REPORT_HASH, 'wrong qualification report identity')
        seal, plan, report = read(BASE / 'seal.json'), read(BASE / 'plan.json'), read(ATTEMPT / 'report.json')
        listed = [check_file(entry) for entry in seal['files']]
        actual = {p for p in BASE.rglob('*') if p.is_file() and p != BASE / 'seal.json'}
        need(len(listed) == len(set(listed)) == 276 and set(listed) == actual, 'final seal inventory mismatch')
        total = sum(entry['bytes'] for entry in seal['files'])
        need(total == seal['total_bytes_excluding_seal'] and total < seal['storage_budget_bytes'] == 10000000,
             'final sealed storage accounting mismatch')
        need(seal['report_and_plan_unchanged'] is True, 'report or plan changed before final sealing')
        need(check_file(seal['report']) == ATTEMPT / 'report.json'
             and check_file(seal['plan']) == BASE / 'plan.json', 'seal report/plan binding differs')
        old = read(ATTEMPT / 'manifest.json')
        differences = []
        for entry in old['files']:
            path = Path(entry['path'])
            need(path.is_relative_to(BASE), 'intermediate manifest path escaped root')
            now = descriptor(path)
            if now != entry:
                differences.append({'recorded': entry, 'finished': now})
        need(differences == seal['intermediate_manifest_mismatches'] and len(differences) == 1,
             'intermediate mismatch inventory differs')
        mismatch = differences[0]
        need(mismatch['recorded']['path'] == str(BASE / 'execution.stdout')
             and mismatch['recorded']['bytes'] == 0 and mismatch['recorded']['sha256'] == sha(b'')
             and mismatch['finished']['bytes'] == 495, 'unexpected intermediate mismatch')
        summary = read(BASE / 'execution.stdout')
        need(summary['report'] == descriptor(ATTEMPT / 'report.json')
             and summary['status'] == 'passed' and summary['counts'] == report['counts'], 'terminal summary not bound to report')
        need((BASE / 'execution.stderr').read_bytes() == b'', 'outer execution stderr nonempty')
        review['sealing'] = {'final_seal': descriptor(BASE / 'seal.json'), 'entries_checked': len(listed),
                             'physical_files_including_seal': len(actual) + 1, 'bytes_excluding_seal': total,
                             'intermediate_manifest': descriptor(ATTEMPT / 'manifest.json'),
                             'preserved_intermediate_mismatch': mismatch}
        need(report['passed'] is True and report['status'] == 'passed'
             and report['production_compile_api_used'] is False and report['repository_modified'] is False,
             'qualification status or claimed route mismatch')
        need(report['source_before'] == report['source_after'] == plan['source']
             and report['source_unchanged'] is True, 'recorded source identity changed')
        source = plan['source']
        need(source['commit'] == COMMIT and source['tree'] == TREE and source['git_status'] == '', 'wrong source binding')
        snapshot = source['snapshot']
        need(snapshot['sha256'] == SNAPSHOT and sha(canonical(snapshot['files'])) == SNAPSHOT
             and len(snapshot['files']) == 1065, 'official snapshot identity differs')
        for name, digest in snapshot['files'].items():
            path = ROOT / name
            need(path.resolve().is_relative_to(ROOT) and sha(path.read_bytes()) == digest, 'frozen source bytes differ')
        need(report['tools_before'] == report['tools_after'] == plan['tools']
             and report['tools_unchanged'] is True, 'recorded tool drift')
        for tool in plan['tools'].values():
            need(descriptor(tool['path']) == tool, 'current retained tool bytes differ')
        need(report['plan'] == descriptor(BASE / 'plan.json'), 'qualification used another plan')
        for name in ('collector', 'input', 'wrong_order_input', 'observer'):
            check_file(plan[name])
        need(report['actual_run_seconds'] == summary['seconds'] < plan['budget']['actual_run_seconds'] == 180,
             'actual-run budget or summary mismatch')
        review['source'] = {'commit': COMMIT, 'tree': TREE, 'snapshot_sha256': SNAPSHOT,
                            'actual_source_files_checked': 1065, 'before_after_equal': True}
        review['tools'] = plan['tools']

        rows = fixed_cases()
        expected = [independent_expected(row) for row in rows]
        need(len(rows) == len({canonical(row) for row in rows}) == 32
             and plan['cases'] == rows and plan['expected'] == expected, 'fixed independent scenario matrix differs')
        need(plan['negative_case_indexes'] == [0, 8, 16, 24] and plan['negative_expected_order'] == [1, 2],
             'negative plan differs')
        correct_document, wrong_document = read(BASE / 'input.json'), read(BASE / 'wrong-order-input.json')
        need({k:v for k,v in correct_document.items() if k != 'functions'}
             == {k:v for k,v in wrong_document.items() if k != 'functions'}, 'wrong-order control changes module/types')
        correct_functions = {fn['name']: fn for fn in correct_document['functions']}
        wrong_functions = {fn['name']: fn for fn in wrong_document['functions']}
        need(set(correct_functions) == set(wrong_functions), 'wrong-order control changes functions')
        for name, function in correct_functions.items():
            if name != 'dispose':
                need(function == wrong_functions[name], 'wrong-order control changes other function')
        for functions, order in ((correct_functions, ['tag', 'second', 'first']),
                                 (wrong_functions, ['tag', 'first', 'second'])):
            operations = functions['dispose']['blocks'][0]['ops']
            need([op['attrs']['field'] for op in operations if op['op'] == 'record.take'] == order,
                 'dispose does not encode specified field order')
            need([op['args'][0] for op in operations if op['op'] == 'owner.drop']
                 == [field + '_value' for field in order if field != 'tag'], 'drop order not tied to taken fields')

        processes = report['processes']
        need(len(processes) == 111, 'unexpected explicit process count')
        for process in processes:
            need(process['status'] == 'completed' and process['returncode'] == 0
                 and 0 <= process['seconds'] < plan['budget']['subprocess_seconds'], 'process status or budget differs')
            for stream in ('stdin', 'stdout', 'stderr'):
                if stream in process:
                    check_file(process[stream])
                    if stream != 'stdin':
                        need(process[stream]['bytes'] <= plan['budget'][stream + '_bytes'], 'process stream budget exceeded')
        mapped = set()

        def process_for(index, expected_argv):
            need(index not in mapped and processes[index]['argv'] == expected_argv, 'process reused or argv mismatch')
            mapped.add(index)
            return processes[index]

        def stdout(process):
            return check_file(process['stdout']).read_bytes()

        clang, readobj, vm = (plan['tools'][name]['path'] for name in ('clang', 'llvm_readobj', 'rust_vm'))
        version, target = report['compiler_preflight']
        need(b'clang version 20.' in stdout(process_for(version, [clang, '--version'])), 'wrong compiler version')
        need(stdout(process_for(target, [clang, '-dumpmachine'])).strip()
             in (b'x86_64-pc-linux-gnu', b'x86_64-unknown-linux-gnu'), 'wrong compiler target')
        core_bytes = (ATTEMPT / 'core.json').read_bytes()
        need(sha(core_bytes) == report['core_sha256'], 'Core bytes mismatch')
        need(len(report['differential']) == 32 and len(report['python']) == 64, 'interpreter count differs')
        python_rows = {(entry['index'], entry['route']): entry for entry in report['python']}
        need(len(python_rows) == 64, 'duplicate Python result record')
        representatives = []
        for index, entry in enumerate(report['differential']):
            row, spec = rows[index], expected[index]
            need(entry['index'] == index and entry['case'] == row and entry['expected'] == spec,
                 'differential request/spec mapping differs')
            options = {'max_steps': 100000, 'max_heap_bytes': 1024}
            if row['allocation_fail_at']:
                options['allocation_fail_at'] = row['allocation_fail_at']
            process = processes[entry['rust_process']]
            argv = process['argv']
            need(len(argv) == 5 and argv[:3] == [vm, '--owned-run', 'cleanup_case']
                 and parse(argv[3]) == row['arguments'] and parse(argv[4]) == options, 'Rust request mapping differs')
            process_for(entry['rust_process'], argv)
            need(check_file(process['stdin']).read_bytes() == core_bytes, 'Rust Core stdin differs')
            rust = parse(stdout(process))
            need(rust == entry['rust'] and rust['function'] == 'cleanup_case'
                 and rust['program_sha256'] == report['core_sha256']
                 and rust['schema'] == 'hepta.hia.rust-owned-execution.v2', 'Rust output binding differs')
            for route in ('nominal', 'core'):
                py = python_rows[index, route]
                need(py['status'] == 'completed' and py['observed'] == entry['python_' + route], 'Python result mapping differs')
                for field in ('status', 'steps', 'resources', 'program_sha256', 'values'):
                    need(py['observed'][field] == rust[field], 'Python/Rust result mismatch')
            need(rust['status'] == 'returned' and rust['values'] == [spec['native']['result']], 'independent scalar mismatch')
            ledger = rust['resources']
            for actual_name, expected_name in [('allocation_attempts', 'attempts'), ('allocations', 'allocations'),
                                                ('frees', 'frees'), ('peak_bytes', 'peak_bytes'), ('live_bytes', 'live_bytes')]:
                need(ledger[actual_name] == spec['native'][expected_name], 'independent resource count mismatch')
            need(ledger['allocation_attempts'] - ledger['allocations'] == spec['native']['failures'], 'failure count mismatch')
            need(ledger['owners_created'] == ledger['owners_dropped'] == spec['logical_owners']
                 and ledger['live_owners'] == ledger['live_local_loans'] == ledger['live_chains'] == 0,
                 'logical Owner accounting or cleanup mismatch')
            if index in (0, 8, 16, 24):
                representatives.append({'index': index, 'mode': row['arguments'][0], 'result': rust['values'][0],
                                        'steps': rust['steps'], 'logical_owners': spec['logical_owners'],
                                        'peak_bytes': spec['native']['peak_bytes']})

        def compilation(name, row):
            ir, obj, executable = (check_file(row[key]) for key in ('ir', 'object', 'executable'))
            need(ir == ATTEMPT / (name + '.ll') and obj == ATTEMPT / (name + '.o')
                 and executable == ATTEMPT / name, 'compilation artifact names differ')
            process_for(row['compile_process'], [clang, '--target=x86_64-unknown-linux-gnu', '-x', 'ir', '-O3', '-fPIC',
                                                '-c', str(ir), '-o', str(obj)])
            inspection = process_for(row['inspection_process'], [readobj, '--file-headers', str(obj)])
            need(b'elf64-x86-64' in stdout(inspection) and b'x86_64' in stdout(inspection), 'object inspection target differs')
            process_for(row['link_process'], [clang, '-std=c11', '-O2', '-Werror=implicit-function-declaration',
                                             str(BASE / 'observer.c'), str(obj), '-Wl,--wrap=malloc',
                                             '-Wl,--wrap=calloc', '-Wl,--wrap=free', '-o', str(executable)])
            return executable

        need(set(report['native']) == {'nominal', 'core'}, 'unexpected native route')
        two_live = 0
        for name, group in report['native'].items():
            executable = compilation(name, group['compilation'])
            need(len(group['cases']) == 32, 'native route missing cases')
            for index, entry in enumerate(group['cases']):
                need(entry['index'] == index, 'native case order differs')
                process = process_for(entry['process'], [str(executable), str(index)])
                observed = parse(stdout(process))
                need(observed == entry['observed'] == expected[index]['native'], 'native stdout disagrees with independent model')
                if observed['allocations'] == 2:
                    need(observed['free_order'] == [2, 1], 'two live payloads not released in reverse order')
                    two_live += 1
        wrong_executable = compilation('wrong-order', report['wrong_order_compilation'])
        need(len(report['negative_controls']) == 4, 'negative control count differs')
        controls = []
        for entry, index in zip(report['negative_controls'], (0, 8, 16, 24)):
            need(entry['index'] == index and entry['detected'] is True and entry['valid_core'] is True
                 and entry['equivalent_to_original'] is False, 'negative control claim/index differs')
            process = process_for(entry['process'], [str(wrong_executable), str(index)])
            observed = parse(stdout(process))
            spec = expected[index]['native']
            need(entry['expected'] == spec and observed == entry['observed']
                 and spec['free_order'] == [2, 1] and observed['free_order'] == [1, 2], 'wrong-order observation missing')
            need({k:v for k,v in observed.items() if k != 'free_order'}
                 == {k:v for k,v in spec.items() if k != 'free_order'}, 'negative differs beyond release order')
            controls.append({'index': index, 'process': entry['process'], 'observed': observed,
                             'expected_free_order': spec['free_order'], 'all_other_observables_equal': True})
        need(mapped == set(range(111)), 'unmapped process record')
        wanted_counts = {'requests': 32, 'python_executions': 64, 'rust_executions': 32,
                         'positive_native_executions': 64, 'negative_native_executions': 4}
        need(report['counts'] == wanted_counts and all(plan['planned_counts'][k] == v for k,v in wanted_counts.items()),
             'summary/planned counts differ')
        review['checked_counts'] = {**wanted_counts, 'explicit_process_argv_mappings': 111,
                                    'llvm_object_compiles': 3, 'object_inspections': 3, 'links': 3,
                                    'compiler_preflight': 2, 'positive_native_with_two_live_payloads': two_live}
        review['negative_controls'] = controls
        review['representatives'] = representatives
        review['actual_execution_seconds_as_recorded'] = report['actual_run_seconds']
        review['longest_child_seconds_as_recorded'] = max(p['seconds'] for p in processes)
        review['qualification_report'] = descriptor(ATTEMPT / 'report.json')
        review['plan'] = descriptor(BASE / 'plan.json')
        review['production_compile_api_used'] = False
        review['ordered_release_observed_by'] = ['native allocator observer']
        review['nominal_and_core_native_share_backend_and_compiler'] = True
        review['real_concurrency_qualified'] = False
        review['exception_unwind_qualified'] = False
        review['whole_language_soundness_proved'] = False
        review['passed'] = True
    except BaseException as error:
        review['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        review['read_only_review_seconds'] = time.monotonic() - start
        review['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        review['review_script'] = descriptor(__file__)
        with (OUT / 'review.json').open('x') as stream:
            json.dump(review, stream, sort_keys=True, indent=2, allow_nan=False)
            stream.write('\n')
        with (OUT / 'manifest.json').open('x') as stream:
            json.dump({'schema': 'hepta.independent-two-owner-review-manifest.v1',
                       'files': [descriptor(__file__), descriptor(OUT / 'review.json')]},
                      stream, sort_keys=True, indent=2, allow_nan=False)
            stream.write('\n')
    print(json.dumps({'passed': review['passed'], 'counts': review['checked_counts'],
                      'read_only_review_seconds': review['read_only_review_seconds'],
                      'new_application_executions': 0, 'new_compiler_executions': 0}, sort_keys=True))


if __name__ == '__main__':
    main()
