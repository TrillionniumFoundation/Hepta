#!/usr/bin/python3
"""Read-only verification of retained finite evidence; never execute an application."""
from pathlib import Path
import datetime
import hashlib
import json
import time

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
PARTIAL = Path('/tmp/hepta-partial-record-final-d942f18b-20261028')
CPP = Path('/tmp/hepta-cpp-constexpr-final-d942f18b-20261028')
OUT = Path(__file__).resolve().parent
COMMIT = 'd942f18b07c8811aa1418b6f67fabc23212317d1'
TREE = '44823c1858d52e9043edebb83f2414d91087d743'
SNAPSHOT = '4a64e1a353585d0ee88985e4942c008bd82ec1482be7ce1158a60f24f550e8db'


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def parse(data):
    return json.loads(data, object_pairs_hook=unique_object)


def load(path):
    return parse(Path(path).read_bytes())


def descriptor(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def retained_path(path, base):
    path = Path(path)
    path = path if path.is_absolute() else base / path
    require(path.is_relative_to(base) and not path.is_symlink(), 'retained path outside expected directory')
    require(path.resolve().is_relative_to(base.resolve()), 'resolved retained path escaped directory')
    return path


def check_descriptor(entry, base):
    path = retained_path(entry['path'], base)
    observed = descriptor(path)
    require(observed['bytes'] == entry['bytes'] and observed['sha256'] == entry['sha256'],
            'retained bytes/hash mismatch: ' + str(path))
    return path


def check_manifest(directory):
    path = directory / 'manifest.json'
    document = load(path)
    listed = [check_descriptor(row, directory) for row in document['files']]
    require(len(listed) == len(set(listed)), 'duplicate manifest path')
    actual = {p for p in directory.rglob('*') if p.is_file() and p != path}
    require(set(listed) == actual, 'manifest omits or adds retained files')
    return {'manifest': descriptor(path), 'entries_checked': len(listed),
            'physical_files_including_manifest': len(actual) + 1}


def expected_cases():
    return ([{'function': 'partial_case', 'arguments': [m, n, b], 'fail_at': f}
             for n in (0, 1, 7) for m in (0, 1) for b in (0, 73, 255) for f in (0, 1, 2, 3)]
            + [{'function': 'partial_case', 'arguments': [m, n, 73], 'fail_at': 0}
               for n in (2**63, 2**64 - 1) for m in (0, 1)]
            + [{'function': 'partial_task', 'arguments': [m, n, 73], 'fail_at': f}
               for n in (0, 1, 7) for m in (0, 1, 2) for f in (0, 1)])


def independent_expected(row):
    """Piecewise arithmetic from the scenario; no HIA, lowerer or VM imports."""
    mode, size, byte = row['arguments']
    failure = row['fail_at']
    result = dict(attempts=0, allocations=0, frees=0, live=0, live_bytes=0,
                  peak_bytes=0, refusals=0, invalid_frees=0, null_frees=0, free_order=[])
    if row['function'] == 'partial_task':
        result.update(result=3 if mode < 2 else byte, logical_owners=5)
        if size:
            result['attempts'] = 1
            if failure == 1:
                result['refusals'] = 1
            else:
                result.update(allocations=1, frees=1, peak_bytes=size, free_order=[1])
    elif size == 0:
        result.update(result=400 if mode == 1 else byte, logical_owners=2 if mode == 1 else 5)
    elif size >= 2**63:
        result.update(result=100, logical_owners=2)
    elif failure == 1:
        result.update(result=100, logical_owners=2, attempts=1, refusals=1)
    elif mode == 1:
        result.update(result=400, logical_owners=2, attempts=1, allocations=1,
                      frees=1, peak_bytes=size, free_order=[1])
    elif failure == 2:
        result.update(result=200, logical_owners=3, attempts=2, allocations=1,
                      frees=1, peak_bytes=size, refusals=1, free_order=[1])
    elif failure == 3:
        result.update(result=300, logical_owners=5, attempts=3, allocations=2,
                      frees=2, peak_bytes=2*size, refusals=1, free_order=[1, 2])
    else:
        result.update(result=2*size + 2*byte + 17, logical_owners=5, attempts=3,
                      allocations=3, frees=3, peak_bytes=2*size, free_order=[1, 3, 2])
    return result


def check_source(outer):
    before, after = outer['source_before'], outer['source_after']
    require(before == after and outer['source_unchanged'] is True, 'source changed during recorded run')
    require(before['commit'] == COMMIT and before['tree'] == TREE and before['status'] == '',
            'wrong frozen commit/tree/status')
    snapshot = before['snapshot']
    require(snapshot['sha256'] == SNAPSHOT and sha(canonical(snapshot['files'])) == SNAPSHOT,
            'official source snapshot digest mismatch')
    require(len(snapshot['files']) == 1065, 'wrong official source file count')
    for name, digest in snapshot['files'].items():
        path = retained_path(name, ROOT)
        require(sha(path.read_bytes()) == digest, 'current frozen source bytes differ: ' + name)
    for name, after_tool in outer['tools_after'].items():
        before_tool = outer['tools_before'][name]
        for key in ('path', 'resolved_path', 'bytes', 'sha256'):
            require(before_tool[key] == after_tool[key], 'recorded tool identity changed: ' + name)
    require(outer['tools_unchanged'] is True, 'outer tool stability flag false')
    require(outer['passed'] is True and outer['returncode'] == 0
            and not outer['timed_out'] and not outer['output_exceeded'], 'outer execution did not pass')
    return {'commit': COMMIT, 'tree': TREE, 'official_snapshot_sha256': SNAPSHOT,
            'official_source_files_checked': 1065, 'recorded_before_after_equal': True}


def main():
    start = time.monotonic()
    result = {'schema': 'hepta.independent-retained-native-review.v1', 'passed': False,
              'new_application_executions': 0, 'hepta_executor_imported': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        outer = load(PARTIAL / 'report.json')
        qdir = PARTIAL / 'qualification'
        report = load(qdir / 'report.json')
        plan = load(qdir / 'plan.json')
        result['partial_outer_manifest'] = check_manifest(PARTIAL)
        result['partial_inner_manifest'] = check_manifest(qdir)
        result['partial_source'] = check_source(outer)
        require(sha((qdir / 'report.json').read_bytes()) == outer['qualification_report_sha256'],
                'outer qualification report binding mismatch')
        require(report['git_commit'] == COMMIT and report['git_status'] == ''
                and report['passed'] is True and report['status'] == 'passed', 'inner qualification identity/status mismatch')
        require(report['source_before'] == report['source_after'], 'inner source drift')
        require(report['tools_before'] == report['tools_after'], 'inner tool drift')
        for name, digest in report['source_before'].items():
            require(outer['source_before']['snapshot']['files'][name] == digest, 'inner/outer source binding differs')
        rows = expected_cases()
        expected = [independent_expected(row) for row in rows]
        require(len(rows) == len({canonical(row) for row in rows}) == 94, 'scenario rows are not 94 unique requests')
        require(rows == report['cases'] == plan['cases'], 'scenario matrix differs from independent enumeration')
        require(expected == plan['expected'], 'predeclared expected values differ from independent formulas')
        core_bytes = (qdir / 'core.json').read_bytes()
        require(sha(core_bytes) == report['core_sha256'], 'Core digest mismatch')
        processes = report['processes']
        require(len(processes) == 300, 'unexpected explicit process count')
        for process in processes:
            require(process['status'] == 'completed', 'uncompleted retained process')
            for stream in ('stdin', 'stdout', 'stderr'):
                if stream in process:
                    check_descriptor(process[stream], qdir)
        rust_path = report['tools_before']['rust_vm']['path']
        require(report['tools_before']['rust_vm']['sha256'] == outer['tools_before']['retained_rust_vm']['sha256'],
                'Rust VM inner/outer identity mismatch')
        rust_ids = []

        def rust_observation(index, row, options):
            process = processes[index]
            require(process['returncode'] == 0, 'Rust process nonzero exit')
            argv = process['argv']
            require(len(argv) == 5 and argv[:3] == [rust_path, '--owned-run', row['function']]
                    and parse(argv[3]) == row['arguments'] and parse(argv[4]) == options,
                    'Rust argv/request mapping differs')
            require(check_descriptor(process['stdin'], qdir).read_bytes() == core_bytes,
                    'Rust did not receive exact retained Core bytes')
            require(check_descriptor(process['stderr'], qdir).read_bytes() == b'', 'Rust stderr was not empty')
            observed = load(check_descriptor(process['stdout'], qdir))
            require(observed['schema'] == 'hepta.hia.rust-owned-execution.v2'
                    and observed['program_sha256'] == report['core_sha256']
                    and observed['function'] == row['function']
                    and observed['max_steps'] == options['max_steps']
                    and observed['max_heap_bytes'] == options['max_heap_bytes'], 'Rust output identity/options differ')
            rust_ids.append(index)
            return observed

        require(len(report['differential']) == 94, 'wrong differential count')
        for index, entry in enumerate(report['differential']):
            row, spec = rows[index], expected[index]
            options = {'max_steps': 100000, 'max_heap_bytes': 16*1024*1024}
            if row['fail_at']:
                options['allocation_fail_at'] = row['fail_at']
            require(entry['index'] == index and entry['case'] == row and entry['options'] == options,
                    'differential row/options mapping mismatch')
            raw = rust_observation(entry['rust_process'], row, options)
            require(raw == entry['rust'] and spec == entry['independent_expected'], 'Rust output copy or spec mismatch')
            for field in ('status', 'steps', 'resources', 'program_sha256', 'values'):
                require(raw[field] == entry['python_nominal'][field] == entry['python_core'][field],
                        'reported Python/Rust differential differs: ' + field)
            require(raw['status'] == 'returned' and raw['values'] == [spec['result']], 'independent scalar mismatch')
            ledger = raw['resources']
            for actual, key in [('allocation_attempts', 'attempts'), ('allocations', 'allocations'),
                                ('frees', 'frees'), ('live_bytes', 'live_bytes'), ('peak_bytes', 'peak_bytes')]:
                require(ledger[actual] == spec[key], 'independent resource count mismatch')
            require(ledger['owners_created'] == ledger['owners_dropped'] == spec['logical_owners'],
                    'independent logical Owner mismatch')
            require(ledger['live_owners'] == ledger['live_local_loans'] == ledger['live_chains'] == 0,
                    'normal return retained resources')

        budgets = ([{'max_steps': n, 'max_heap_bytes': 1024} for n in (1, 3, 8, 15, 25, 40, 60)]
                   + [{'max_steps': 100000, 'max_heap_bytes': n} for n in (0, 6, 7, 13)])
        require(plan['budget_cases'] == budgets and len(report['budgets']) == 11, 'budget matrix differs')
        stops = returns = 0
        for entry, options in zip(report['budgets'], budgets):
            require(entry['options'] == options, 'budget request order mismatch')
            raw = rust_observation(entry['rust_process'], {'function': 'partial_case', 'arguments': [0, 7, 73]}, options)
            require(raw == entry['rust'], 'budget raw/summary output mismatch')
            for field in ('status', 'steps', 'resources', 'program_sha256'):
                require(raw[field] == entry['python'][field], 'budget Python/Rust mismatch')
            if options == {'max_steps': 60, 'max_heap_bytes': 1024}:
                require(raw['status'] == 'returned' and raw['values'] == entry['python']['values'] == [177],
                        'budget positive control did not return 177')
                returns += 1
            else:
                code = 'steps' if options['max_steps'] < 60 else 'heap'
                require(raw['status'] == 'budget_exceeded' and raw['error']['code'] == entry['python']['error']['code'] == code,
                        'expected budget stop/code absent')
                stops += 1
        require(len(rust_ids) == len(set(rust_ids)) == 105, 'Rust requests were omitted or reused')
        require(set(rust_ids) == {i for i, p in enumerate(processes) if '--owned-run' in p['argv']},
                'unmapped Rust process')

        native_ids = []
        require(set(report['native']) == {'core', 'nominal'}, 'unexpected native variants')
        for name, group in report['native'].items():
            executable = check_descriptor(group['executable'], qdir)
            require(executable == qdir / name and len(group['cases']) == 94, 'native group identity/count mismatch')
            require(group['compilation']['core_sha256'] == report['core_sha256'], 'native compiled wrong Core')
            for index, entry in enumerate(group['cases']):
                process = processes[entry['process']]
                require(entry['index'] == index and process['argv'] == [str(executable), str(index)]
                        and process['returncode'] == 0, 'native argv/index/exit mismatch')
                observed = load(check_descriptor(process['stdout'], qdir))
                spec = {key: value for key, value in expected[index].items() if key != 'logical_owners'}
                require(observed == entry['observed'] == spec, 'native stdout differs from independent specification')
                require(check_descriptor(process['stderr'], qdir).read_bytes() == b'', 'native positive stderr not empty')
                native_ids.append(entry['process'])
        require(len(native_ids) == len(set(native_ids)) == 188, 'native runs omitted or reused')
        selected = rows.index({'function': 'partial_case', 'arguments': [0, 7, 73], 'fail_at': 0})
        negatives = {}
        for entry in report['negative_controls']:
            process = processes[entry['run_process']]
            name = entry['name']
            require(name in ('missing_free', 'wrong_byte') and name not in negatives, 'unexpected negative control')
            executable = qdir / name.replace('_', '-')
            require(process['argv'] == [str(executable), str(selected)], 'negative control request mismatch')
            observed = load(check_descriptor(process['stdout'], qdir))
            require(observed == entry['observed'] and entry['detected'] is True, 'negative summary differs from raw stdout')
            if name == 'missing_free':
                wanted = dict(result=177, attempts=3, allocations=3, frees=0, live=3,
                              live_bytes=21, peak_bytes=21, refusals=0, invalid_frees=0,
                              null_frees=0, free_order=[])
                require(process['returncode'] == 91 and entry['qualified_hia_artifact'] is False,
                        'missing-free status/claim mismatch')
            else:
                wanted = {key: value for key, value in expected[selected].items() if key != 'logical_owners'}
                wanted['result'] = 178
                require(process['returncode'] == 0 and entry['equivalent_to_original'] is False,
                        'wrong-byte status/claim mismatch')
            require(observed == wanted, 'negative control did not expose intended defect')
            negatives[name] = {'process': entry['run_process'], 'exit_code': process['returncode'], 'raw_observed': observed}
        require(len(negatives) == 2, 'missing negative control')
        require(report['claims']['two_live_payload_cancel_order_qualified'] is False
                and report['claims']['whole_language_soundness_proved'] is False
                and report['claims']['llvm_refinement_proved'] is False, 'finite evidence claims expanded')
        result['partial_counts'] = {'explicit_process_records': 300, 'differential_requests': 94,
                                    'rust_raw_request_output_mappings': 105, 'budget_stops': stops,
                                    'budget_returns': returns, 'native_positive_stdout_checks': 188,
                                    'native_negative_stdout_checks': 2}
        result['partial_negative_controls'] = negatives
        result['partial_reports'] = [descriptor(PARTIAL / 'report.json'), descriptor(qdir / 'report.json')]

        cpp_outer = load(CPP / 'report.json')
        cpp = load(CPP / 'native-80/report.json')
        result['cpp_manifest'] = check_manifest(CPP)
        result['cpp_source'] = check_source(cpp_outer)
        require(sha((CPP / 'native-80/report.json').read_bytes()) == cpp_outer['native_report_sha256'], 'C++ report binding mismatch')
        require(cpp['ok'] is True and cpp['case_count'] == 80 and cpp['native_result_executions'] == 160,
                'C++ qualification count/status mismatch')
        require(cpp['original_cpp_link_inputs_in_target'] == [], 'target linked original C++ input')
        formulas = {'narrow0': (32, 1, 3), 'narrow1': (32, 1, 7),
                    'wide0': (64, 1, 11), 'wide1': (64, 1, 13),
                    'scope0': (32, 2, 7), 'scope1': (32, 2, 11),
                    'discard_object': (32, 1, 19), 'repeated_narrow': (32, 1, 3)}
        cpp_expected = []
        require(len(cpp['cases']) == len(cpp['interpreter_results']) == 80, 'wrong C++ report count')
        for case in cpp['cases']:
            bits, factor, offset = formulas[case['function']]
            require(len(case['arguments']) == 1 and 0 <= case['arguments'][0] < 2**bits, 'C++ argument out of domain')
            cpp_expected.append((factor * case['arguments'][0] + offset) % 2**bits)
        require(cpp_expected == cpp['expected'], 'C++ expected vector differs from independent formulas')
        interpreter_values = []
        for case, expected_value, frame in zip(cpp['cases'], cpp_expected, cpp['interpreter_results']):
            require(frame['status'] == 'returned' and frame['function'] == case['function']
                    and frame['program_sha256'] == cpp['program_sha256']
                    and frame['values'] == [expected_value] and frame['result'] == expected_value,
                    'C++ interpreter report identity/value mismatch')
            interpreter_values.append(frame['values'][0])
        for name, index in cpp['observation_processes'].items():
            process = cpp['processes'][index]
            raw = load(retained_path(process['stdout'], CPP))
            request = load(retained_path(process['stdin'], CPP))
            require(process['returncode'] == 0 and request['cases'] == cpp['cases']
                    and raw == cpp['observed'][name] == cpp_expected == interpreter_values
                    and len(raw) == 80, 'C++ retained observation/request mismatch')
        result['cpp_counts'] = {'cases': 80, 'native_result_executions': 160,
                                'constexpr_selections': len(cpp['constexpr_selections']),
                                'template_instances': sum(len(x['instances']) for x in cpp['template_instances'])}
        result['cpp_reports'] = [descriptor(CPP / 'report.json'), descriptor(CPP / 'native-80/report.json')]
        result['prior_review_attempt'] = {
            'report': descriptor(OUT.parent / 'review.json'),
            'script': descriptor(OUT.parent / 'review_retained.py'),
            'reason': 'Initial read-only checker compared full C++ interpreter report objects to scalar values; source/native evidence was unchanged.'}
        result['passed'] = True
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        result['seconds'] = time.monotonic() - start
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['review_script'] = descriptor(__file__)
        with (OUT / 'review.json').open('x') as stream:
            json.dump(result, stream, sort_keys=True, indent=2, allow_nan=False)
            stream.write('\n')
        with (OUT / 'manifest.json').open('x') as stream:
            json.dump({'schema': 'hepta.independent-retained-native-review-manifest.v1',
                       'files': [descriptor(OUT / 'review_retained.py'), descriptor(OUT / 'review.json')]},
                      stream, sort_keys=True, indent=2, allow_nan=False)
            stream.write('\n')
    print(json.dumps({'passed': result['passed'], 'seconds': result['seconds'],
                      'partial': result['partial_counts'], 'cpp': result['cpp_counts'],
                      'new_application_executions': 0}, sort_keys=True))


if __name__ == '__main__':
    main()
