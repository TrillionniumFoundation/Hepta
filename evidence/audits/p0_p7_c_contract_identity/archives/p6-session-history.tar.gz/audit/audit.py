#!/usr/bin/python3
"""Twelve fixed session transitions; no corpus traversal or native execution."""
import copy,datetime,hashlib,json,os,pathlib,subprocess,sys,time
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
OUT=pathlib.Path(__file__).parent
EXPECTED='1739484bbda1a49a39b05714e2017d35b5c2c7e9'
SELECTED=['hepta/hia_incremental.py','hepta/hia_program.py','hepta/hia_program_tools.py','hepta/hia_schema.py','tests/test_hia_incremental.py','tests/test_hia_incremental_independent.py','tests/test_hia_program.py']
sys.path.insert(0,str(ROOT))
from hepta import hia_program as core
from hepta.hia_incremental import IncrementalVerifier
from hepta.hia_program_tools import apply_program_patch
from tests.test_hia_incremental import graph
from tests.test_hia_incremental_independent import alias_module
from tests.test_hia_program import b,c,i,ret

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def wire(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(path):
 with pathlib.Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def source_identity():
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True,env=env,timeout=20).strip()
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'git_status':git('status','--porcelain=v1'),'selected_source_sha256':{p:sha(ROOT/p) for p in SELECTED}}
def invoke(fn,arg):
 try:
  result=fn(arg)
  if isinstance(result,tuple):result=result[0]
  return ('accepted',result.canonical_bytes,result.structured_bytes),result
 except Exception as exc:
  return ('rejected',type(exc).__module__+'.'+type(exc).__name__,getattr(exc,'code',None),str(exc)),None
def public(value):
 if value[0]=='accepted':return {'status':'accepted','canonical_sha256':hashlib.sha256(value[1]).hexdigest(),'structured_sha256':None if value[2] is None else hashlib.sha256(value[2]).hexdigest()}
 return {'status':value[0],'exception_type':value[1],'code':value[2],'message':value[3]}

started=now();clock=time.monotonic();before=source_identity()
if before['head']!=EXPECTED or before['git_status']:raise RuntimeError('Expected clean exact source')
prior_path=pathlib.Path('/tmp/hepta-p6-incremental-development-20261028/prior-verifier-cases.jsonl')
prior_pairs=set()
with prior_path.open() as f:
 for line in f:
  row=json.loads(line);prior_pairs.add((hashlib.sha256(wire(row['base'])).hexdigest(),hashlib.sha256(wire(row['candidate'])).hexdigest()))
plan={'schema':'hepta.p6.bounded-session-audit-plan.v1','started_utc':started,'source_before':before,'python_executable':sys.executable,'python_version':sys.version,'python_sha256':sha(sys.executable),'planned_transition_count':12,'histories':{'retarget_remove_readd':6,'loan_callee_retarget':3,'canonical_noop_and_stale_patch':3},'prior_corpus_path':str(prior_path),'prior_corpus_sha256':sha(prior_path),'prior_corpus_reexecuted':False,'native_compilation_or_execution':False,'models_or_full_suite_executed':False,'private_state_monkeypatched':False,'caller_supplied_receipt_trusted':False,'pythondontwritebytecode':sys.dont_write_bytecode}
write(OUT/'plan.json',plan);records=[]
stream=(OUT/'transitions.jsonl').open('x')
def run(label,session,current,candidate,expected,dependencies=None,patch=False):
 baseline=session.base_sha256
 full,verified=invoke((lambda request:apply_program_patch(current,request)) if patch else core.verify_program,candidate)
 inc,actual=invoke(session.apply_patch if patch else session.verify,candidate)
 report=session.last_report;after=session.base_sha256
 equal=full==inc
 baseline_ok=(after==baseline if expected=='rejected' else verified is not None and after==verified.sha256)
 deps_ok=dependencies is None or report['dependency_invalidations']==dependencies
 prior_pair=None if patch else (hashlib.sha256(wire(current.as_dict())).hexdigest(),hashlib.sha256(wire(candidate)).hexdigest())
 row={'index':len(records)+1,'label':label,'api':'apply_patch' if patch else 'verify','before_sha256':baseline,'after_sha256':after,'expected_status':expected,'full':public(full),'incremental':public(inc),'exact_outcome_equal':equal,'baseline_transition_correct':baseline_ok,'expected_dependency_invalidations':dependencies,'dependency_invalidations_match':deps_ok,'work_report':report,'current_base':current.as_dict(),'candidate_or_request':candidate,'same_base_candidate_pair_present_in_prior_957':None if patch else prior_pair in prior_pairs,'ok':equal and full[0]==expected and baseline_ok and deps_ok}
 records.append(row);stream.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n');stream.flush()
 return verified if verified is not None and row['ok'] else current

# History 1: accepted retarget updates dependencies; failed edits never seed state.
doc=graph(7);session=IncrementalVerifier(doc);current=core.verify_program(doc)
x=current.as_dict();x['functions'][1]['blocks'][0]['ops'][0]['attrs']['function']='separate'
current=run('retarget_middle_to_separate',session,current,x,'accepted',{})
x=current.as_dict();leaf=x['functions'][0];leaf['returns']=['bool'];leaf['blocks'][0]['ops']=[c('yes','bool',True)];leaf['blocks'][0]['term']=ret('yes')
current=run('change_retired_leaf_interface_does_not_invalidate_middle',session,current,x,'accepted',{})
x=current.as_dict();separate=x['functions'][3];separate['params'][0]['type']='bool';separate['blocks'][0]['params'][0]['type']='bool';separate['blocks'][0]['ops']=[c('v','u32',7)]
current=run('change_current_callee_parameter_invalidates_cached_middle',session,current,x,'rejected',{'middle':['separate']})
x=copy.deepcopy(x);middle=x['functions'][1];middle['blocks'][0]['ops']=[c('flag','bool',True),i('call',['flag'],[('v','u32')],function='separate')]
current=run('joint_repair_after_rejection_keeps_outer_interface',session,current,x,'accepted',{})
x=current.as_dict();x['functions']=[fn for fn in x['functions'] if fn['name']!='leaf']
current=run('delete_unreferenced_retired_leaf',session,current,x,'accepted',{})
x=current.as_dict();bad=copy.deepcopy(doc['functions'][0]);bad['blocks'][0]['ops'][0]['attrs']['value']=True;x['functions'].append(bad)
current=run('readd_deleted_name_with_invalid_body_must_recheck',session,current,x,'rejected',{})
session.close()

# History 2: permissions follow the new direct target, not a formerly used callee.
doc=alias_module();session=IncrementalVerifier(doc);current=core.verify_program(doc)
x=current.as_dict();clone=copy.deepcopy(x['functions'][1]);clone['name']='combine_copy';x['functions'].append(clone);x['functions'][0]['blocks'][0]['ops'][3]['attrs']['function']='combine_copy'
current=run('retarget_aliased_read_call_to_added_callee',session,current,x,'accepted',{})
x=current.as_dict();old=x['functions'][1];old['params'][1]['type']='mutbuf';old['blocks'][0]['params'][1]['type']='mutbuf'
current=run('retired_callee_becomes_exclusive_without_false_invalidation',session,current,x,'accepted',{})
x=current.as_dict();new=x['functions'][-1];new['params'][1]['type']='mutbuf';new['blocks'][0]['params'][1]['type']='mutbuf'
current=run('current_callee_becomes_exclusive_reject_cached_alias',session,current,x,'rejected',{'outer':['combine_copy']})
session.close()

# History 3: canonical no-op preserves validity of a digest; a real edit does not.
doc=graph(7);session=IncrementalVerifier(doc);current=core.verify_program(doc);original_digest=current.sha256
for label,value,expected in [('canonical_noop_keeps_digest',1,'accepted'),('old_digest_after_noop_accepts_real_edit',2,'accepted'),('old_digest_after_real_edit_is_stale',3,'rejected')]:
 request={'schema':'hepta.hia.patch.v1','expected_sha256':original_digest,'edits':[{'action':'replace_operation','function':'leaf','block':'entry','index':0,'operation':c('one','u32',value)}]}
 current=run(label,session,current,request,expected,{} if expected=='accepted' else None,patch=True)
session.close();stream.close();after=source_identity()
summary={'schema':'hepta.p6.bounded-session-audit-summary.v1','started_utc':started,'finished_utc':now(),'duration_seconds':time.monotonic()-clock,'source_before':before,'source_after':after,'selected_source_identity_unchanged':before==after,'transitions':len(records),'accepted':sum(r['full']['status']=='accepted' for r in records),'rejected':sum(r['full']['status']=='rejected' for r in records),'mismatches':[{'index':r['index'],'label':r['label'],'full':r['full'],'incremental':r['incremental'],'dependencies':r['work_report']['dependency_invalidations'],'expected_dependencies':r['expected_dependency_invalidations']} for r in records if not r['ok']],'prior_957_reexecuted':False,'verify_pairs_not_in_prior_957':sum(r['same_base_candidate_pair_present_in_prior_957'] is False for r in records),'patch_history_steps':3,'native_or_model_or_full_suite_executed':False,'private_state_monkeypatched':False,'all_language_soundness_proved':False,'coverage':'12 authored transitions in three session histories: retarget/interface change, deletion/readdition and rollback, loan permissions on retargeted calls, canonical no-op and stale patch. Only existing v7 primitive grammar and patch.v1. No randomized traversal or new syntax.','not_covered':['all inputs or all schedules','arbitrary in-process private-state/code mutation','new schemas or persistent/untrusted caches','performance or model productivity'],'ok':len(records)==12 and all(r['ok'] for r in records) and before==after}
write(OUT/'summary.json',summary)
manifest={'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in [OUT/'audit.py',OUT/'plan.json',OUT/'transitions.jsonl',OUT/'summary.json']]};write(OUT/'manifest.json',manifest)
print(json.dumps({k:summary[k] for k in ['transitions','accepted','rejected','mismatches','verify_pairs_not_in_prior_957','selected_source_identity_unchanged','duration_seconds','ok']},sort_keys=True))
sys.exit(0 if summary['ok'] else 1)
