#!/usr/bin/python3
"""Bound a single targeted-validation or exact-input replay process."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

PREPARATION = Path('/tmp/hepta-c-contract-identity-publication-20261028')
ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
HELPER = Path('/tmp/hepta-final-integrated-preparation-20261028/run_final_validation.py')


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True, timeout=30).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('kind', choices=('targeted', 'replay'))
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--output-directory', required=True, type=Path)
    parser.add_argument('--launch-directory', required=True, type=Path)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.expected_commit):
        parser.error('Full expected SHA required')
    output, launch = args.output_directory.absolute(), args.launch_directory.absolute()
    if (any(p.exists() or p.is_symlink() or p.resolve().is_relative_to(ROOT) for p in (output, launch))
            or output == launch or output.is_relative_to(launch) or launch.is_relative_to(output)):
        parser.error('Distinct new external output and launch directories required')
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('retained_process_helper', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    script = PREPARATION / ('run_targeted.py' if args.kind == 'targeted' else 'replay_original_cases.py')
    argv = ['/usr/bin/python3', '-u', str(script), '--expected-commit', args.expected_commit,
            '--output-directory', str(output)]
    argv += ['--new-test-module', 'test_c_contract_identity'] if args.kind == 'targeted' else ['--expected-error', 'E_C_FUNCTION']
    limit = 630 if args.kind == 'targeted' else 120
    controlled = {'PATH': '/tmp/hepta-toolchains/rust-1.90.0/bin:/usr/lib/llvm-20/bin:/usr/bin:/bin',
                  'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
                  'RUSTC': '/tmp/hepta-toolchains/rust-1.90.0/bin/rustc',
                  'CLANG': '/usr/lib/llvm-20/bin/clang', 'CLANGXX': '/usr/lib/llvm-20/bin/clang++',
                  'CARGO_HOME': '/tmp/hepta-cargo-home',
                  'CARGO_TARGET_DIR': '/tmp/hepta-p2-independent-v2-v7-target', 'CARGO_NET_OFFLINE': 'true'}
    env = dict(os.environ, **controlled)
    env.pop('PYTHONOPTIMIZE', None)
    launch.mkdir()
    (launch / 'launcher.py').write_bytes(Path(__file__).read_bytes())
    (launch / 'child.py').write_bytes(script.read_bytes())
    (launch / 'retained-process-helper.py').write_bytes(HELPER.read_bytes())
    before = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'git_status': git('status', '--porcelain')}
    write(launch / 'plan.json', {'schema': 'hepta.c-contract-identity.launch-plan.v1',
          'kind': args.kind, 'started_utc': utc(), 'argv': argv, 'cwd': str(ROOT),
          'source_before': before, 'expected_commit': args.expected_commit,
          'child_script_sha256': sha(script), 'launcher_sha256': sha(__file__),
          'process_helper_sha256': sha(HELPER), 'controlled_environment': controlled,
          'pythonoptimize_removed': True, 'outer_timeout_seconds': limit,
          'unit_timeout_seconds': 600 if args.kind == 'targeted' else None})
    child = None
    original = None
    error = None
    termination = None
    timed_out = False
    received_signal = None

    def note_signal(number, frame):
        nonlocal received_signal
        received_signal = number

    def cleanup(path):
        try:
            return helper.stop_owned_tree(child, original, path)
        except Exception as exc:
            return {'events': [], 'remaining': [{'pid': child.pid}],
                    'errors': ['Owned cleanup failed: ' + type(exc).__name__ + ': ' + str(exc)]}

    signal.signal(signal.SIGINT, note_signal)
    signal.signal(signal.SIGTERM, note_signal)
    start = time.monotonic()
    with (launch / 'stdout.log').open('xb', buffering=0) as stdout, (launch / 'stderr.log').open('xb', buffering=0) as stderr:
        try:
            if before['commit'] != args.expected_commit or before['git_status']:
                raise RuntimeError('Expected clean remote commit required; child not started')
            if received_signal is not None:
                raise RuntimeError('Interrupted before child start')
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            original = helper.process(child.pid)
            write(launch / 'process.json', {'child_pid': child.pid, 'launcher_pid': os.getpid(),
                  'identity': original, 'argv': argv, 'started_utc': utc()})
            print(json.dumps({'kind': args.kind, 'status': 'running', 'pid': child.pid,
                              'outer_timeout_seconds': limit}), flush=True)
            while child.poll() is None:
                if received_signal is not None:
                    error = {'type': 'SignalInterruption', 'signal_number': received_signal}
                    termination = cleanup(launch / 'interrupt-signals.jsonl')
                    break
                if time.monotonic() - start >= limit:
                    timed_out = True
                    termination = cleanup(launch / 'timeout-signals.jsonl')
                    break
                time.sleep(0.05)
        except Exception as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
            if child is not None and child.poll() is None:
                termination = cleanup(launch / 'error-signals.jsonl')
    code = None if child is None else child.poll()
    seconds = time.monotonic() - start
    child_reports = {}
    child_passed = False
    try:
        after = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                 'git_status': git('status', '--porcelain')}
        for name in ('report.json', 'manifest.json'):
            p = output / name
            if p.is_file():
                child_reports[name] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
        if len(child_reports) == 2:
            child_passed = json.loads((output / 'report.json').read_text()).get('passed') is True
    except Exception as exc:
        after = None
        error = {'type': type(exc).__name__, 'message': str(exc)}
    passed = (code == 0 and not timed_out and error is None and received_signal is None and child_passed
              and after == before and not (termination and (termination['remaining'] or termination['errors'])))
    write(launch / 'execution.json', {'schema': 'hepta.c-contract-identity.launch-result.v1',
          'kind': args.kind, 'passed': bool(passed), 'finished_utc': utc(),
          'returncode': code, 'seconds': seconds, 'timed_out': timed_out,
          'received_signal': received_signal,
          'error': error, 'termination': termination, 'source_before': before, 'source_after': after,
          'child_reports': child_reports, 'child_report_claims_passed': child_passed})
    files = [{'path': str(p.relative_to(launch)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(launch.rglob('*')) if p.is_file()]
    write(launch / 'manifest.json', {'schema': 'hepta.c-contract-identity.launch-manifest.v1', 'files': files})
    print(json.dumps({'kind': args.kind, 'passed': bool(passed), 'returncode': code, 'seconds': seconds}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
