#!/usr/bin/python3
"""Re-admit the exact sealed pre-fix inputs, without re-executing originals."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
BASE = Path('/tmp/hepta-c-contract-binding-audit-20261028')


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True, timeout=30).strip()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--expected-commit', required=True)
    p.add_argument('--expected-error', required=True)
    p.add_argument('--output-directory', required=True, type=Path)
    a = p.parse_args()
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT))
    from hepta.c_migrate import migrate_c_project
    from tools.release_check import snapshot

    def identity():
        return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'git_status': git('status', '--porcelain'), 'source': snapshot()}

    before = identity()
    require(before['head'] == a.expected_commit and not before['git_status'], 'Frozen clean source precondition failed')
    seal = json.loads((BASE / 'seal.json').read_text())
    require(sha(BASE / 'report.json') == 'dfc3e962d21843cce825d9f532e2c7a8fe3f9cc4347a5f292fa33e74267205d7', 'Baseline report identity mismatch')
    require(sha(BASE / 'seal.json') == '313eac864b2557b081c5d6c58d0667838d11b56c7108e493a36fe0da1f82f700', 'Baseline seal identity mismatch')
    for row in seal['files']:
        path = Path(row['path'])
        require(path.resolve().is_relative_to(BASE) and path.is_file() and not path.is_symlink(), 'Unsafe baseline member')
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'Baseline member identity mismatch: ' + str(path))
    output = a.output_directory.absolute()
    require(not output.exists() and not output.is_symlink() and not output.resolve().is_relative_to(ROOT)
            and not output.resolve().is_relative_to(BASE), 'Output must be new and outside source and baseline')
    output.mkdir()
    (output / 'replay.py').write_bytes(Path(__file__).read_bytes())
    old = json.loads((BASE / 'report.json').read_text())
    write(output / 'plan.json', {'schema': 'hepta.c-contract-identity.exact-replay-plan.v1',
          'source_before': before, 'baseline_report_sha256': sha(BASE / 'report.json'),
          'baseline_seal_sha256': sha(BASE / 'seal.json'),
          'cases': [x['name'] for x in old['results']], 'expected_error': a.expected_error,
          'original_native_execution_requested': False, 'target_native_execution_requested': False})
    rows = []
    started = time.monotonic()
    for original in old['results']:
        name = original['name']
        project = BASE / name
        case = output / name
        case.mkdir()
        write(case / 'start.json', {'name': name, 'input_directory': str(project),
                                  'expected_accepted': not original['swapped_names']})
        contracts = json.loads((project / 'contracts.json').read_text())
        result = migrate_c_project(project / 'compile_commands.json', case / 'translated',
                   contracts=contracts, clang='/usr/lib/llvm-20/bin/clang', verify_native=False)
        write(case / 'migration-result.json', result)
        positive = not original['swapped_names']
        exact = {}
        if positive and result['ok']:
            for filename in ('source.hepta', 'bridge.rs', 'generated.rs'):
                prior = project / 'translated' / filename
                current = case / 'translated' / filename
                exact[filename] = {'baseline_sha256': sha(prior), 'current_sha256': sha(current),
                                   'same_bytes': prior.read_bytes() == current.read_bytes()}
        codes = [d['code'] for d in result['diagnostics']]
        expected = (result['ok'] and len(exact) == 3 and all(x['same_bytes'] for x in exact.values())) if positive else (
                    not result['ok'] and a.expected_error in codes and not (case / 'translated').exists())
        row = {'name': name, 'baseline_accepted': original['accepted'],
                     'new_accepted': result['ok'], 'expected_accepted': positive,
                     'diagnostic_codes': codes, 'output_directory_exists': (case / 'translated').exists(),
                     'unchanged_accepted_lowering': exact, 'passed': bool(expected)}
        rows.append(row)
        write(case / 'completion.json', row)
    after = identity()
    unchanged = before == after
    baseline_unchanged = all(Path(row['path']).stat().st_size == row['bytes']
                             and sha(row['path']) == row['sha256'] for row in seal['files'])
    passed = unchanged and baseline_unchanged and len(rows) == 4 and all(x['passed'] for x in rows)
    write(output / 'report.json', {'schema': 'hepta.c-contract-identity.exact-replay-result.v1',
          'passed': bool(passed), 'seconds': time.monotonic() - started,
          'results': rows, 'source_before': before, 'source_after': after,
          'source_unchanged': unchanged, 'baseline_unchanged': baseline_unchanged, 'original_native_executions': 0,
          'target_native_executions': 0, 'scope': 'Exact pre-fix declaration-contract inputs; frontend admission and unchanged generated bytes only.'})
    files = [{'path': str(f.relative_to(output)), 'bytes': f.stat().st_size, 'sha256': sha(f)}
             for f in sorted(output.rglob('*')) if f.is_file()]
    write(output / 'manifest.json', {'schema': 'hepta.c-contract-identity.exact-replay-manifest.v1', 'files': files})
    print(json.dumps({'passed': bool(passed), 'cases': rows}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
