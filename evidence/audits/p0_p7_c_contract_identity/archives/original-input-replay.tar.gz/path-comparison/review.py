#!/usr/bin/python3
"""Inspect retained replay output; allow only exact diagnostic-path relocation.

This does not rerun migration or change the failed first byte-equality receipt.
"""
import hashlib
import json
from pathlib import Path
import re

BASE = Path('/tmp/hepta-c-contract-binding-audit-20261028')
REPLAY = Path('/tmp/hepta-c-contract-replay-e8c5da27-20261028')
OUTPUT = Path('/tmp/hepta-c-contract-emission-review-e8c5da27-20261028')


class Mismatch(ValueError):
    pass


def require(value, message):
    if not value:
        raise Mismatch(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate annotation key')
        result[key] = value
    return result


def annotation(line):
    found = re.fullmatch(rb'([ \t]*// hepta-source: )([^\r\n]+)(\n)', line)
    if found is None:
        return None
    value = json.loads(found[2].decode('utf-8'), object_pairs_hook=unique)
    require(isinstance(value, dict), 'Annotation must be an object')
    return value


def compare(original, current, old_path, new_path):
    old_lines, new_lines = original.splitlines(keepends=True), current.splitlines(keepends=True)
    require(len(old_lines) == len(new_lines), 'Line count changed')
    changes = []
    old_token = json.dumps(old_path, ensure_ascii=False).encode()
    new_token = json.dumps(new_path, ensure_ascii=False).encode()
    for index, (left, right) in enumerate(zip(old_lines, new_lines), 1):
        old, new = annotation(left), annotation(right)
        if old is None or new is None:
            require(left == right, 'Non-annotation bytes changed on line ' + str(index))
            continue
        if old.get('event') != 'begin' or new.get('event') != 'begin':
            require(left == right, 'Non-begin annotation changed')
            continue
        require(set(old) == {'event', 'kind', 'span'} and set(new) == set(old), 'Unexpected annotation shape')
        require(isinstance(old['span'], dict) and isinstance(new['span'], dict), 'Missing annotation span')
        require(set(old['span']) == {'start', 'end', 'line', 'column', 'path'}
                and set(new['span']) == set(old['span']), 'Unexpected span fields')
        require(old['span']['path'] == old_path and new['span']['path'] == new_path, 'Unexpected source path')
        restored = dict(new, span=dict(new['span'], path=old_path))
        require(old == restored, 'Annotation metadata other than path changed')
        require(left.count(old_token) == right.count(new_token) == 1, 'Ambiguous path token')
        require(right.replace(new_token, old_token, 1) == left, 'Other annotation bytes changed')
        if left != right:
            changes.append({'line': index, 'old_path': old_path, 'new_path': new_path,
                            'old_line_sha256': digest(left), 'new_line_sha256': digest(right)})
    require(changes, 'Expected separately retained destination paths were not observed')
    return changes


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write('\n')


def main():
    require(not OUTPUT.exists(), 'Output already exists')
    baseline_raw = (BASE / 'report.json').read_bytes()
    first_raw = (REPLAY / 'report.json').read_bytes()
    require(digest(baseline_raw) == 'dfc3e962d21843cce825d9f532e2c7a8fe3f9cc4347a5f292fa33e74267205d7', 'Baseline report changed')
    require(digest(first_raw) == '79226f461935837b3a820f29a06d7a638643b79052c1a8b42d54a1e186781b54', 'First failed receipt changed')
    baseline, first = json.loads(baseline_raw), json.loads(first_raw)
    require(first['passed'] is False and first['source_unchanged'] is True and first['baseline_unchanged'] is True,
            'Original failed comparison must remain failed and source-bound')
    require(first['source_before']['head'] == 'e8c5da272560cf1243b7113faa5b9868d24b136c', 'Unexpected executed implementation')
    require(len(first['results']) == 4, 'Four exact replay rows required')
    OUTPUT.mkdir()
    (OUTPUT / 'review.py').write_bytes(Path(__file__).read_bytes())
    inputs = {str(BASE / 'report.json'): baseline_raw, str(REPLAY / 'report.json'): first_raw}
    positive, negative, controls = [], [], []
    for row in first['results']:
        name = row['name']
        if not row['expected_accepted']:
            require(row['new_accepted'] is False and row['diagnostic_codes'] == ['E_C_FUNCTION']
                    and row['output_directory_exists'] is False and row['passed'] is True, 'Unexpected negative admission')
            negative.append({'name': name, 'rejected': True, 'code': 'E_C_FUNCTION'})
            continue
        require(row['new_accepted'] is True and row['diagnostic_codes'] == [], 'Positive admission failed')
        retained = {}
        for filename in ('source.hepta', 'bridge.rs', 'generated.rs'):
            a = BASE / name / 'translated' / filename
            b = REPLAY / name / 'translated' / filename
            left, right = a.read_bytes(), b.read_bytes()
            inputs[str(a)], inputs[str(b)] = left, right
            prior = row['unchanged_accepted_lowering'][filename]
            require(digest(left) == prior['baseline_sha256'] and digest(right) == prior['current_sha256'], 'Retained output identity mismatch')
            retained[filename] = (left, right)
        for filename in ('source.hepta', 'bridge.rs'):
            require(retained[filename][0] == retained[filename][1], 'Source or ABI bridge bytes changed')
        left, right = retained['generated.rs']
        old_path = str(BASE / name / 'translated/source.hepta')
        new_path = str(REPLAY / name / 'translated/source.hepta')
        changed = compare(left, right, old_path, new_path)
        positive.append({'name': name, 'accepted': True, 'hepta_and_bridge_byte_identical': True,
                         'raw_generated_rust_byte_identical': left == right,
                         'only_exact_diagnostic_span_paths_differ': True, 'changed_annotation_lines': changed})
        require(right.count(b'return 1i32;') == 1, 'Expected code-control anchor not unique')
        mutated = [('changed_return', right.replace(b'return 1i32;', b'return 2i32;', 1))]
        lines = right.splitlines(keepends=True)
        index = next(i for i, line in enumerate(lines) if annotation(line) and annotation(line).get('event') == 'begin')
        marker = annotation(lines[index])
        for label, value in (
                ('changed_span_start', dict(marker, span=dict(marker['span'], start=marker['span']['start'] + 1))),
                ('wrong_destination_path', dict(marker, span=dict(marker['span'], path='/unexpected/source.hepta'))),
                ('changed_annotation_kind', dict(marker, kind='unexpected'))):
            changed_lines = list(lines)
            prefix = lines[index].split(b'{', 1)[0]
            changed_lines[index] = prefix + json.dumps(value, separators=(',', ':')).encode() + b'\n'
            mutated.append((label, b''.join(changed_lines)))
        for label, candidate in mutated:
            rejected, reason = False, None
            try:
                compare(left, candidate, old_path, new_path)
            except Mismatch as exc:
                rejected, reason = True, str(exc)
            require(rejected, 'Comparator accepted control: ' + label)
            controls.append({'name': name, 'control': label, 'rejected': rejected, 'reason': reason,
                             'mutated_bytes_sha256': digest(candidate), 'in_memory_only': True})
    require(len(positive) == len(negative) == 2 and len(controls) == 8, 'Unexpected comparison scope')
    for path, data in inputs.items():
        require(Path(path).read_bytes() == data, 'Retained input changed during review')
    report = {'schema': 'hepta.c-contract-identity.emission-path-review.v1', 'passed': True,
              'original_replay_passed': False, 'original_failed_receipt_overwritten': False,
              'migration_or_compiler_reexecuted': False, 'original_native_executions': 0, 'target_native_executions': 0,
              'basis': 'Admission outcomes from the original completed replay, plus exact retained output comparison allowing only verified destination paths in generated diagnostic comment span.path.',
              'scope': 'No whole-source equivalence or native behavior qualification is established by this offline comparison.',
              'positive_cases': positive, 'negative_cases': negative, 'negative_controls': controls,
              'inputs': [{'path': path, 'bytes': len(data), 'sha256': digest(data)} for path, data in sorted(inputs.items())]}
    write(OUTPUT / 'report.json', report)
    write(OUTPUT / 'manifest.json', {'schema': 'hepta.c-contract-identity.emission-path-review-manifest.v1',
          'files': [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
                    for p in sorted(OUTPUT.iterdir()) if p.is_file()]})
    print(json.dumps({'passed': True, 'positive': 2, 'negative': 2, 'controls_rejected': 8,
                      'original_replay_passed': False, 'report_sha256': digest((OUTPUT / 'report.json').read_bytes())}))


if __name__ == '__main__':
    main()
