// Generated caller-unsafe C ABI bridge. NOT a proof of foreign pointer validity.

// SAFETY: nonempty buffers must be initialized, aligned, live within one allocation,

// stable throughout the call; a mutable slice additionally requires exclusive access.

// These are caller-supplied contracts and may narrow the original C input domain.

#[export_name = "probe"]
pub unsafe extern "C" fn __hepta_c_export_0(b_data: *const u32, b_n: u32, b_spare: u32) -> u32 {
    let n_b_data = b_n as usize;
    if n_b_data > (isize::MAX as usize) / core::mem::size_of::<u32>() { std::process::abort(); }
    if n_b_data != 0 && (b_data.is_null() || (b_data as usize) % core::mem::align_of::<u32>() != 0) { std::process::abort(); }
    let s_b_data = if n_b_data == 0 { &[] } else { unsafe { core::slice::from_raw_parts(b_data, n_b_data) } };
    h_c_probe(s_b_data, b_n, b_spare)
}
