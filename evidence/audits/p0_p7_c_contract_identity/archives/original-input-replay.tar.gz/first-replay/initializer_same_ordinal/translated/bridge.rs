// Caller-unsafe original C ABI. Initialized live disjoint storage is an external obligation.

// Numeric interval checks reject overlap; they do not prove provenance or allocation extent.

fn __hepta_view_range(address: usize, count: usize, size: usize, align: usize) -> (usize, usize) {
    if count > (isize::MAX as usize) / size || count != 0 && (address == 0 || address % align != 0) { std::process::abort(); }
    let bytes = count.checked_mul(size).unwrap_or_else(|| std::process::abort());
    (address, address.checked_add(bytes).unwrap_or_else(|| std::process::abort()))
}

fn __hepta_view_disjoint(a: (usize, usize), b: (usize, usize)) {
    if a.0 < a.1 && b.0 < b.1 && a.0 < b.1 && b.0 < a.1 { std::process::abort(); }
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct __HeptaAbi_C_State {
    f_data: *mut u32,
    f_n: u64,
}

#[export_name = "bind"]
pub unsafe extern "C" fn __hepta_c_view_export_0(b_state: *mut __HeptaAbi_C_State, b_a: *mut u32, b_spare: *mut u32, b_n: u64) -> () {
    let r_b_state = __hepta_view_range(b_state as usize, 1, core::mem::size_of::<__HeptaAbi_C_State>(), core::mem::align_of::<__HeptaAbi_C_State>());
    let mut s_b_state = H_C_State { h_f_n: 0 };
    let n_b_a = b_n as usize;
    let r_b_a = __hepta_view_range(b_a as usize, n_b_a, core::mem::size_of::<u32>(), core::mem::align_of::<u32>());
    let n_b_spare = b_n as usize;
    let r_b_spare = __hepta_view_range(b_spare as usize, n_b_spare, core::mem::size_of::<u32>(), core::mem::align_of::<u32>());
    __hepta_view_disjoint(r_b_state, r_b_a);
    __hepta_view_disjoint(r_b_state, r_b_spare);
    __hepta_view_disjoint(r_b_a, r_b_spare);
    let s_b_a = if n_b_a == 0 { &mut [] } else { unsafe { core::slice::from_raw_parts_mut(b_a, n_b_a) } };
    let s_b_spare = if n_b_spare == 0 { &mut [] } else { unsafe { core::slice::from_raw_parts_mut(b_spare, n_b_spare) } };
    let result = h_c_bind(&mut s_b_state, s_b_a, 0, s_b_spare, 0, b_n);
    unsafe { b_state.write(__HeptaAbi_C_State { f_data: b_a, f_n: s_b_state.h_f_n }); }
    result
}
