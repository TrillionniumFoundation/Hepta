#!/usr/bin/python3
"""Independent read-only comparison of the two retained positive Rust files."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import re
import time

OLD = Path('/tmp/hepta-c-contract-binding-audit-20261028')
NEW = Path('/tmp/hepta-c-contract-replay-e8c5da27-20261028')
OUT = Path(__file__).resolve().parent
MARKER = re.compile(rb'([ \t]*// hepta-source: )(\{.*\})(\r?\n)?\Z')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def descriptor(path):
    path = Path(path); data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def main():
    began = time.monotonic()
    original_report_bytes = (NEW / 'report.json').read_bytes()
    original = json.loads(original_report_bytes)
    need(sha(original_report_bytes) == '79226f461935837b3a820f29a06d7a638643b79052c1a8b42d54a1e186781b54',
         'unexpected first replay report')
    need(original['passed'] is False and original['baseline_unchanged'] is True
         and original['source_unchanged'] is True, 'first replay status/identity changed')
    review = {'schema': 'hepta.c-contract-independent-generated-rust-path-review.v1', 'passed': False,
              'original_replay_passed': False, 'original_replay_report': descriptor(NEW / 'report.json'),
              'new_migration_executions': 0, 'new_clang_executions': 0, 'new_native_executions': 0,
              'negative_controls_repeated': False, 'original_report_modified': False,
              'scope': 'Actual retained positive artifact pairs only. Raw generated.rs bytes remain different; this verifies exact destination-only changes in parsed source-location comments.',
              'cases': []}
    try:
        rows = {row['name']: row for row in original['results']}
        need(len(rows) == 4 and all(rows[name]['new_accepted'] == rows[name]['expected_accepted'] for name in rows),
             'replay admission did not match its planned result')
        for name in ('slice_same_ordinal', 'initializer_same_ordinal'):
            old_dir, new_dir = OLD / name / 'translated', NEW / name / 'translated'
            old_path, new_path = str(old_dir / 'source.hepta'), str(new_dir / 'source.hepta')
            receipts = []
            for filename in ('source.hepta', 'bridge.rs', 'generated.rs'):
                left, right = old_dir / filename, new_dir / filename
                receipts.append({'file': filename, 'baseline': descriptor(left), 'replay': descriptor(right)})
                expected = rows[name]['unchanged_accepted_lowering'][filename]
                need(receipts[-1]['baseline']['sha256'] == expected['baseline_sha256']
                     and receipts[-1]['replay']['sha256'] == expected['current_sha256'], 'artifact/report binding mismatch')
                if filename != 'generated.rs':
                    need(left.read_bytes() == right.read_bytes() and expected['same_bytes'] is True,
                         'non-Rust-source artifact changed')
            left_bytes, right_bytes = (old_dir / 'generated.rs').read_bytes(), (new_dir / 'generated.rs').read_bytes()
            left_lines, right_lines = left_bytes.splitlines(keepends=True), right_bytes.splitlines(keepends=True)
            need(len(left_lines) == len(right_lines) and left_bytes != right_bytes, 'unexpected raw generated Rust relation')
            changes, reconstructed = [], []
            for number, (left, right) in enumerate(zip(left_lines, right_lines), 1):
                if left == right:
                    reconstructed.append(left)
                    continue
                lm, rm = MARKER.fullmatch(left), MARKER.fullmatch(right)
                need(lm is not None and rm is not None and lm.group(1) == rm.group(1) and lm.group(3) == rm.group(3),
                     'difference outside exact source-comment framing')
                a, b = (json.loads(match.group(2), object_pairs_hook=pairs) for match in (lm, rm))
                need(isinstance(a, dict) and isinstance(b, dict) and isinstance(a.get('span'), dict)
                     and isinstance(b.get('span'), dict) and a['span'].get('path') == old_path
                     and b['span'].get('path') == new_path, 'changed comment does not use exact expected source paths')
                normalized = copy.deepcopy(a)
                normalized['span']['path'] = new_path
                need(normalized == b, 'JSON differs beyond span.path')
                old_quoted, new_quoted = json.dumps(old_path).encode(), json.dumps(new_path).encode()
                need(left.count(old_quoted) == 1 and right.count(new_quoted) == 1,
                     'source path literal is not unique on changed line')
                replaced = left.replace(old_quoted, new_quoted, 1)
                need(replaced == right, 'raw changed line differs beyond the exact path string')
                reconstructed.append(replaced)
                changes.append({'line': number, 'changed_json_field': ['span', 'path'],
                                'old_line_sha256': sha(left), 'new_line_sha256': sha(right),
                                'event': a.get('event'), 'kind': a.get('kind')})
            need(b''.join(reconstructed) == right_bytes, 'whole Rust file not reproduced by allowed comment path changes')
            left_non_marker = b''.join(line for line in left_lines if MARKER.fullmatch(line) is None)
            right_non_marker = b''.join(line for line in right_lines if MARKER.fullmatch(line) is None)
            need(left_non_marker == right_non_marker, 'non-source-comment Rust or metadata differs')
            raw_diff = ''.join(difflib.unified_diff(left_bytes.decode().splitlines(keepends=True),
                                                   right_bytes.decode().splitlines(keepends=True),
                                                   fromfile=str(old_dir / 'generated.rs'), tofile=str(new_dir / 'generated.rs')))
            diff_path = OUT / (name + '.raw.diff')
            with diff_path.open('x') as stream: stream.write(raw_diff)
            need(changes and len(changes) == (9 if name == 'slice_same_ordinal' else 17), 'changed-comment count differs')
            need(all(descriptor(Path(row[key]['path'])) == row[key] for row in receipts for key in ('baseline', 'replay')),
                 'artifact changed while reading')
            review['cases'].append({'name': name, 'raw_generated_bytes_equal': False,
                                    'source_hepta_bytes_equal': True, 'bridge_rs_bytes_equal': True,
                                    'generated_line_count': len(left_lines), 'changed_comment_count': len(changes),
                                    'exact_old_source_path': old_path, 'exact_new_source_path': new_path,
                                    'all_other_bytes_equal': True, 'non_source_comment_bytes_sha256': sha(left_non_marker),
                                    'compiler_metadata_changed': False, 'changes': changes, 'artifacts': receipts,
                                    'raw_diff': descriptor(diff_path)})
        need((NEW / 'report.json').read_bytes() == original_report_bytes, 'original failed report changed')
        review['admission_results'] = [{'name': row['name'], 'accepted': row['new_accepted'],
                                       'diagnostic_codes': row['diagnostic_codes']} for row in original['results']]
        review['passed'] = True
    except BaseException as error:
        review['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        review['seconds'] = time.monotonic() - began
        review['review_script'] = descriptor(__file__)
        with (OUT / 'report.json').open('x') as stream:
            json.dump(review, stream, indent=2, sort_keys=True); stream.write('\n')
        files = [descriptor(path) for path in sorted(OUT.iterdir()) if path.is_file()]
        with (OUT / 'manifest.json').open('x') as stream:
            json.dump({'schema': 'hepta.c-contract-rust-path-review-manifest.v1', 'files': files}, stream,
                      indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps({'passed': review['passed'], 'original_replay_passed': False,
                      'changes': {row['name']: row['changed_comment_count'] for row in review['cases']},
                      'new_application_executions': 0}, sort_keys=True))


if __name__ == '__main__': main()
