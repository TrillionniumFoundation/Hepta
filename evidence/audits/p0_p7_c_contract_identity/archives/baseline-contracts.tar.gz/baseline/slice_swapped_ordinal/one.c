#include "api.h"
unsigned probe(const unsigned *data, unsigned other, unsigned n){return data[0]+10u*n+other;}
