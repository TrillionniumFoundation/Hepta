#!/usr/bin/python3
"""Finite baseline admission probe; source programs contain no undefined inputs."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
OUT=Path(__file__).resolve().parent
CLANG='/usr/lib/llvm-20/bin/clang'
sys.path.insert(0,str(ROOT))
from hepta.c_migrate import migrate_c_project
from tools.release_check import snapshot


def descriptor(path):
    path=Path(path); data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def write(path,data):
    with Path(path).open('x') as stream:
        json.dump(data,stream,indent=2,sort_keys=True);stream.write('\n')


def state():
    return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),
            'status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip(),
            'snapshot':snapshot()}


def native(directory,arguments,name):
    with (directory/(name+'.stdout')).open('wb') as out,(directory/(name+'.stderr')).open('wb') as err:
        began=time.monotonic()
        result=subprocess.run(arguments,cwd=directory,stdout=out,stderr=err,timeout=20,check=False)
    record={'argv':arguments,'returncode':result.returncode,'seconds':time.monotonic()-began,
            'stdout':descriptor(directory/(name+'.stdout')),'stderr':descriptor(directory/(name+'.stderr'))}
    write(directory/(name+'.json'),record)
    if result.returncode: raise ValueError('original C process failed')
    return (directory/(name+'.stdout')).read_text()


def case(name,swapped,record):
    directory=OUT/name;directory.mkdir()
    if record:
        header='struct State { unsigned *data; unsigned long n; };\nvoid bind(struct State *ctx, unsigned *a, unsigned *b, unsigned long n);\n'
        params='struct State *state, unsigned *b, unsigned *a, unsigned long n' if swapped else 'struct State *state, unsigned *a, unsigned *spare, unsigned long n'
        definition='#include "api.h"\nvoid bind('+params+'){state->data=a;state->n=n;}\n'
        contracts={'schema':'hepta.c-record-views.v1','records':{'State':{'buffers':{'data':{'length_field':'n','add':0}}}},
                   'functions':{'bind':{'records':{'0':{'access':'mut','initialize':{'data':'a'}}},
                                        'slices':{'1':{'length':'n','access':'mut'},'2':{'length':'n','access':'mut'}}}}}
        driver='#include "api.h"\n#include <stdio.h>\nint main(void){unsigned a[4]={7,11,13,17};unsigned b[4]={23,29,31,37};struct State s;printf("[");for(unsigned long n=1;n<=3;n++){bind(&s,a,b,n);printf("%s[%u,%lu,%u]",n==1?"":",",s.data[0],s.n,s.data==a?1u:2u);}puts("]");return 0;}\n'
        expected=[[23 if swapped else 7,n,2 if swapped else 1] for n in (1,2,3)]
        function='bind';binding_kind='initializer_source'
    else:
        header='unsigned probe(const unsigned *p, unsigned n, unsigned other);\n'
        params='const unsigned *data, unsigned other, unsigned n' if swapped else 'const unsigned *data, unsigned n, unsigned spare'
        other='other' if swapped else 'spare'
        definition='#include "api.h"\nunsigned probe('+params+'){return data[0]+10u*n+'+other+';}\n'
        contracts={'schema':'hepta.c-contracts.v1','functions':{'probe':{'slices':{'0':{'length':'n','access':'read'}}}}}
        driver='#include "api.h"\n#include <stdio.h>\nint main(void){const unsigned data[4]={7,11,13,17};printf("[%u,%u,%u]\\n",probe(data,1,2),probe(data,2,1),probe(data,3,3));return 0;}\n'
        expected=[28,19,40] if swapped else [19,28,40]
        function='probe';binding_kind='slice_length'
    for filename,text in [('api.h',header),('one.c',definition),('two.c','#include "api.h"\n'),('driver.c',driver)]:
        (directory/filename).write_text(text)
    commands=[{'directory':str(directory),'file':filename,'arguments':[CLANG,'-std=c11','-O0','-c',filename,'-o',filename+'.o']}
              for filename in ('one.c','two.c')]
    write(directory/'compile_commands.json',commands);write(directory/'contracts.json',contracts)
    write(directory/'plan.json',{'binding_kind':binding_kind,'source_defined':True,'allocation_elements':4,
                               'original_native_calls':3,'expected':expected,'compiler':descriptor(CLANG),
                               'input_files':[descriptor(directory/f) for f in ('api.h','one.c','two.c','driver.c','compile_commands.json','contracts.json')]})
    native(directory,[CLANG,'-std=c11','-O0','-Werror','one.c','two.c','driver.c','-o','original'],'original-build')
    observed=json.loads(native(directory,[str(directory/'original')],'original-run'))
    if observed!=expected:raise ValueError('independent original C oracle differs from fixed result')
    migrated=migrate_c_project(directory/'compile_commands.json',directory/'translated',contracts=contracts,clang=CLANG,verify_native=False)
    write(directory/'migration-result.json',migrated)
    bindings=[]
    for receipt in migrated.get('source_type_admission',[]):
        for declaration in receipt['functions']:
            if declaration['declaration']['name']!=function:continue
            names=[p['name'] for p in declaration['parameters']]
            referenced='a' if record else 'n'
            bindings.append({'unit':receipt['unit'],'declaration':declaration['declaration'],
                             'parameter_names':names,'contract_name':referenced,
                             'bound_parameter_ordinal':names.index(referenced)})
    result={'name':name,'kind':binding_kind,'swapped_names':swapped,'accepted':migrated['ok'],
            'migration_status':migrated['status'],'diagnostics':migrated['diagnostics'],
            'original_observed':observed,'independent_expected':expected,'original_native_calls':3,
            'declaration_bindings':bindings,'distinct_bound_ordinals':sorted({r['bound_parameter_ordinal'] for r in bindings}),
            'target_native_execution':False,'classification':'contract declaration consistency probe; no source equivalence or runtime memory defect claimed'}
    write(directory/'result.json',result)
    return result


def main():
    before=state()
    write(OUT/'plan.json',{'source_before':before,'budget':{'outer_seconds':120,'native_process_seconds':20,'max_case_count':4,
                                                          'original_native_calls':12,'target_native_calls':0},
                          'cases':['slice_same_ordinal','slice_swapped_ordinal','initializer_same_ordinal','initializer_swapped_ordinal'],
                          'repository_mutation':False,'general_safety_or_equivalence_claim':False})
    began=time.monotonic();results=[]
    try:
        for name,swapped,record in [('slice_same_ordinal',False,False),('slice_swapped_ordinal',True,False),
                                    ('initializer_same_ordinal',False,True),('initializer_swapped_ordinal',True,True)]:
            results.append(case(name,swapped,record))
            print(json.dumps({k:results[-1][k] for k in ('name','accepted','distinct_bound_ordinals','original_observed')}),flush=True)
    finally:
        after=state()
        report={'schema':'hepta.c-contract-declaration-binding-audit.v1','source_before':before,'source_after':after,
                'source_unchanged':before==after,'seconds':time.monotonic()-began,'results':results,
                'original_native_calls':sum(r['original_native_calls'] for r in results),'target_native_calls':0,
                'no_defined_input_target_mismatch_proved':True}
        write(OUT/'report.json',report)


if __name__=='__main__':main()
