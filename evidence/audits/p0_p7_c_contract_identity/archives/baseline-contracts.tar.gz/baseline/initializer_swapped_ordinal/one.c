#include "api.h"
void bind(struct State *state, unsigned *b, unsigned *a, unsigned long n){state->data=a;state->n=n;}
