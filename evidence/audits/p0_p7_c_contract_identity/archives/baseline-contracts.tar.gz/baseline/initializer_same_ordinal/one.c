#include "api.h"
void bind(struct State *state, unsigned *a, unsigned *spare, unsigned long n){state->data=a;state->n=n;}
