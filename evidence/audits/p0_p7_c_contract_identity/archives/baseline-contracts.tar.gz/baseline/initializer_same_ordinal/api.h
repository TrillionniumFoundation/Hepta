struct State { unsigned *data; unsigned long n; };
void bind(struct State *ctx, unsigned *a, unsigned *b, unsigned long n);
