#include "api.h"
#include <stdio.h>
int main(void){unsigned a[4]={7,11,13,17};unsigned b[4]={23,29,31,37};struct State s;printf("[");for(unsigned long n=1;n<=3;n++){bind(&s,a,b,n);printf("%s[%u,%lu,%u]",n==1?"":",",s.data[0],s.n,s.data==a?1u:2u);}puts("]");return 0;}
