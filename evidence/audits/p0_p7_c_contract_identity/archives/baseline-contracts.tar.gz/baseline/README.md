# C declaration contract binding consistency probe

This is a bounded admission audit on published commit
`1739484bbda1a49a39b05714e2017d35b5c2c7e9`, tree
`8d1036a5384ea0d243053baea56f4e6204774179`, snapshot
`02048763eb93a39418e5ae2b64f3b1ce8acae9bb92dccb45cdd95f70a6f57e22`.
The source identity and clean working tree were equal before and after the run.
No repository source, tests or documentation were changed.

## Confirmed admission consistency gap

Each fixture has a shared header, one definition translation unit and another
translation unit that includes the header. Public `migrate_c_project` accepted
all four inputs and generated frontend-checked bundles.

| Fixture | Name resolved by contract | Parameter positions across declarations | Baseline admission |
|---|---|---|---|
| slice_same_ordinal | length `n` | 1 only | accepted, positive control |
| slice_swapped_ordinal | length `n` | 1 and 2 | accepted despite inconsistent binding |
| initializer_same_ordinal | initializer source `a` | 1 only | accepted, positive control |
| initializer_swapped_ordinal | initializer source `a` | 1 and 2 | accepted despite inconsistent binding |

Positions are zero-based. Original-type receipts retained by public migration
provide the per-declaration parameter names and locations used for these
observations. The shared `signature.shape` currently omits the slice-length
binding. The record-view override also omits it and compares raw initializer
source names instead of their parameter positions.

The scalar example declares `probe(p, n, other)` but defines
`probe(data, other, n)`. The same `length: "n"` therefore denotes two different
ABI argument positions. The initializer declares `bind(ctx, a, b, n)` but
defines `bind(state, b, a, n)`; `initialize.data: "a"` changes its binding.
The accepted definition still determines emitted behavior. No claim is made
that the emitted code differs from that definition or violates memory safety.

The positive controls retain the referenced length/source at the same position
while renaming the pointer/record parameter selected by ordinal and unrelated
parameters. They do not claim that the current schema supports arbitrary
renaming of the length/source name itself.

## Defined original-language observations

Four-element live initialized arrays are used for every native call. Arguments
are small unsigned values. Every original Clang build and execution exited 0.
The independent expected observations were saved before each execution.

- Ordinary same-position control: `[19, 28, 40]`.
- Ordinary swapped-position input: `[28, 19, 40]`.
- Initializer same-position control binds the first array: values 7, lengths
  1/2/3, argument position 1.
- Initializer swapped-position input binds the second array: values 23,
  lengths 1/2/3, argument position 2.

There were 12 original C function calls, zero target native calls, and no
full-suite or fuzz execution. The outer run completed in 28.068 seconds under
the declared 120-second bound; every native compile/run had a 20-second bound.
This is a contract identity blocker, not a demonstrated target-equivalence
failure, runtime memory vulnerability, or proof about every defined C input.

## Proposed repair boundary

Canonicalize every validated slice length as a fixed-length value or an actual
parameter ordinal before declaration signatures are merged. Canonicalize each
record initializer field-to-source relation the same way. Preserve source
names in diagnostics but compare the normalized relations. Apply the shared
rule to both `CTranslator.signature` and `CRecordViewTranslator.signature`,
whose existing override would otherwise erase the base rule. Reject differing
bindings and preserve the demonstrated same-position renaming controls.

Relevant implementation files are `hepta/c_translation.py` and
`hepta/c_record_views.py`; next-step tests should cover both profiles and the
record-view ordinary-slice override. No repair was made in this frozen batch.

`report.json` records each actual admission and original-language observation.
The generated Hepta/Rust artifacts, native original executables, original
compiler/run arguments, and both process streams are retained. `seal.json`
binds the finished evidence files; no old record is rewritten.
