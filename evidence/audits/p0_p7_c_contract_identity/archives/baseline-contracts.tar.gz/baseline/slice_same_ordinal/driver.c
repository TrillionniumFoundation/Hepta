#include "api.h"
#include <stdio.h>
int main(void){const unsigned data[4]={7,11,13,17};printf("[%u,%u,%u]\n",probe(data,1,2),probe(data,2,1),probe(data,3,3));return 0;}
