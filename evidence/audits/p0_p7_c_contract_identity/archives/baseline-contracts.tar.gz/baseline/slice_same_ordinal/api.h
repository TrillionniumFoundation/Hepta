unsigned probe(const unsigned *p, unsigned n, unsigned other);
