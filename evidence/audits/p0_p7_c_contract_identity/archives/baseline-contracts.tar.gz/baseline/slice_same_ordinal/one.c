#include "api.h"
unsigned probe(const unsigned *data, unsigned n, unsigned spare){return data[0]+10u*n+spare;}
