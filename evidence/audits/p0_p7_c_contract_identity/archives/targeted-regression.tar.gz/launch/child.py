#!/usr/bin/python3
"""Run the affected migration suites on one fetched, clean implementation."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/4bc91e0ee48c/hepta-followup-integration')
HELPER = Path('/tmp/hepta-final-integrated-preparation-20261028/run_final_validation.py')
MODULES = ['test_c_project', 'test_c_record_views', 'test_c_parameter_types',
           'test_cpp_project_hia', 'test_cpp_constexpr_migration',
           'test_c_project_matrix', 'test_c_project_source_arguments',
           'test_c_project_semantic_flags']
TOOLS = {'python': '/usr/bin/python3',
         'clang': '/usr/lib/llvm-20/bin/clang',
         'clangxx': '/usr/lib/llvm-20/bin/clang++',
         'gcc': '/usr/bin/gcc',
         'rustc': '/tmp/hepta-toolchains/rust-1.90.0/bin/rustc',
         'libclang': '/usr/lib/llvm-20/lib/libclang-20.so.1'}


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True, timeout=30).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--new-test-module', required=True)
    parser.add_argument('--output-directory', required=True, type=Path)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.expected_commit):
        parser.error('Full immutable commit required')
    if not re.fullmatch('test_c_[a-z_]+', args.new_test_module):
        parser.error('One explicitly selected C test module required')
    modules = MODULES + [args.new_test_module]
    if len(set(modules)) != len(modules):
        parser.error('Duplicate selected module')
    output = args.output_directory.absolute()
    if output.exists() or output.is_symlink() or output.resolve().is_relative_to(ROOT):
        parser.error('Output must be new and outside repository')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT))
    from tools.release_check import snapshot
    from tools.qualify_hia_unified import unittest_outcome
    spec = importlib.util.spec_from_file_location('retained_validation_helper', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.TOOLS = dict(TOOLS)

    def identity():
        return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'git_status': git('status', '--porcelain'), 'official_snapshot': snapshot()}

    before = identity()
    if before['commit'] != args.expected_commit or before['git_status']:
        raise RuntimeError('Frozen clean source precondition failed')
    output.mkdir()
    (output / 'runner.py').write_bytes(Path(__file__).read_bytes())
    (output / 'retained-helper.py').write_bytes(HELPER.read_bytes())
    controlled = {
        'PATH': '/tmp/hepta-toolchains/rust-1.90.0/bin:/usr/lib/llvm-20/bin:/usr/bin:/bin',
        'PYTHONPATH': str(ROOT / 'tests') + os.pathsep + str(ROOT),
        'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
        'RUSTC': TOOLS['rustc'], 'CLANG': TOOLS['clang'], 'CLANGXX': TOOLS['clangxx'],
        'CARGO_HOME': '/tmp/hepta-cargo-home',
        'CARGO_TARGET_DIR': '/tmp/hepta-p2-independent-v2-v7-target',
        'CARGO_NET_OFFLINE': 'true',
    }
    env = dict(os.environ, **controlled)
    tool_before = helper.tool_identity(versions=True)
    if any('error' in row for row in tool_before.values()):
        raise RuntimeError('Selected tool identity preflight failed')
    argv = [TOOLS['python'], '-m', 'unittest', '-v', *modules]
    limit = 600
    write(output / 'plan.json', {
        'schema': 'hepta.c-contract-identity.targeted-plan.v1',
        'started_utc': utc(), 'argv': argv, 'cwd': str(ROOT),
        'timeout_seconds': limit, 'selected_modules': modules,
        'controlled_environment': controlled, 'source_before': before,
        'tools_before': tool_before, 'runner_sha256': digest(__file__),
        'resolved_path_tools': {name: shutil.which(name, path=controlled['PATH'])
                                for name in ('clang', 'clang++', 'gcc', 'rustc', 'python3')},
        'retained_helper_sha256': digest(HELPER),
        'full_python_discovery_or_cargo_tests_requested': False,
        'remote_ci_performance_model_gpu_board_requested': False,
    })
    child = None
    child_identity = None
    termination = None
    error = None
    timed_out = False
    start = time.monotonic()
    with (output / 'stdout.log').open('xb', buffering=0) as stdout, (output / 'stderr.log').open('xb', buffering=0) as stderr:
        try:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            child_identity = helper.process(child.pid)
            write(output / 'process.json', {'pid': child.pid, 'runner_pid': os.getpid(),
                  'argv': argv, 'process_identity': child_identity, 'started_utc': utc()})
            print(json.dumps({'status': 'running', 'pid': child.pid, 'timeout_seconds': limit}), flush=True)
            try:
                child.wait(timeout=limit)
            except subprocess.TimeoutExpired:
                timed_out = True
                termination = helper.stop_owned_tree(child, child_identity, output / 'timeout-signals.jsonl')
        except Exception as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
            if child is not None and child.poll() is None:
                termination = helper.stop_owned_tree(child, child_identity, output / 'error-signals.jsonl')
    seconds = time.monotonic() - start
    code = None if child is None else child.poll()
    raw = (output / 'stderr.log').read_text(errors='replace')
    outcome = unittest_outcome(raw, code)
    ids = helper.canonical_python_tests(raw)
    (output / 'canonical-test-ids.txt').write_text(''.join(s + '\n' for s in ids['test_ids']))
    after = identity()
    tool_after = helper.tool_identity(versions=False)
    identical = before == after and not after['git_status']
    tools_identical = helper.same_tools(tool_before, tool_after)
    by_module = {name: sum(x.startswith(name + '.') for x in ids['test_ids']) for name in modules}
    passed = (outcome['passed'] and not error and not timed_out and identical and tools_identical
              and ids['unique_test_ids'] == ids['observed_test_starts'] == outcome['tests_run']
              and not ids['duplicate_test_ids'] and all(by_module.values())
              and not (termination and (termination['remaining'] or termination['errors'])))
    report = {'schema': 'hepta.c-contract-identity.targeted-result.v1',
              'passed': bool(passed), 'finished_utc': utc(), 'returncode': code,
              'seconds': seconds, 'timed_out': timed_out, 'error': error, 'termination': termination,
              'outcome': outcome, 'method_identity': ids, 'methods_by_module': by_module,
              'source_unchanged': identical, 'tools_unchanged': tools_identical,
              'source_before': before, 'source_after': after, 'tools_after': tool_after,
              'full_suite_claimed': False, 'native_calls_individually_counted': False}
    write(output / 'report.json', report)
    files = [{'path': str(p.relative_to(output)), 'bytes': p.stat().st_size, 'sha256': digest(p)}
             for p in sorted(output.rglob('*')) if p.is_file()]
    write(output / 'manifest.json', {'schema': 'hepta.c-contract-identity.targeted-manifest.v1', 'files': files})
    print(json.dumps({'passed': bool(passed), 'tests': outcome['tests_run'], 'seconds': seconds,
                      'returncode': code, 'source_unchanged': identical, 'tools_unchanged': tools_identical}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
