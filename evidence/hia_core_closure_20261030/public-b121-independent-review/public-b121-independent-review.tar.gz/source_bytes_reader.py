#!/usr/bin/env python3
"""Independently read the complete frozen integration tree and review its delta.

This script executes Git reads and local hashing only. No project imports,
test methods, native programs, builds, or remote writes are performed.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "hepta-core-rust-integration"
OUT = HERE / "common-f654018"
HEAD = "f6540186aa34c991b2082d59cd998b857f78ced4"
TREE = "7adcc2a0333b48374b4add2d8132d1998c5cc48c"
BASE = "192d2cbba7e49bde3b03af73685ecf96f6fb1b05"
OLD = "147d39c4a9d3ded00fb5d22439493bc006a8b76d"
P3 = "e6d5ccc2c5d1bfc8479f92b0385428ac578c358a"
CHECKS = []


def check(label, actual, expected=True):
    ok = actual == expected
    CHECKS.append({"check": label, "passed": ok})
    if not ok:
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def git(*args):
    return subprocess.check_output(["git", "--no-replace-objects", "-C", str(ROOT), *args])


def raw(revision, name):
    return git("show", revision + ":" + name)


def state():
    return {"head": git("rev-parse", "HEAD").decode().strip(),
            "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
            "status": git("status", "--porcelain=v1", "--untracked-files=all").decode()}


def tree():
    entries = {}
    for row in git("ls-tree", "-r", "-z", HEAD).split(b"\0"):
        if not row:
            continue
        metadata, path = row.split(b"\t", 1)
        mode, kind, blob = metadata.decode().split()
        check("tracked object is a blob: " + path.decode(), kind, "blob")
        entries[path.decode()] = {"mode": mode, "git_blob": blob}
    return entries


def snapshot(entries):
    """Compare actual bytes to raw Git blobs, streaming without a tree copy."""
    result = {}
    child = subprocess.Popen(["git", "--no-replace-objects", "-C", str(ROOT), "cat-file", "--batch"],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        for name, declared in entries.items():
            path = ROOT / name
            before = path.lstat()
            child.stdin.write((declared["git_blob"] + "\n").encode())
            child.stdin.flush()
            blob, kind, length = child.stdout.readline().decode().split()
            length = int(length)
            check("Git blob identity: " + name, (blob, kind), (declared["git_blob"], "blob"))
            mode = "120000" if stat.S_ISLNK(before.st_mode) else (
                "100755" if before.st_mode & 0o111 else "100644")
            check("filesystem mode matches Git: " + name, mode, declared["mode"])
            sha = hashlib.sha256()
            if mode == "120000":
                data = os.fsencode(os.readlink(path))
                expected = child.stdout.read(length)
                check("raw Git symlink bytes: " + name, data, expected)
                sha.update(data)
            else:
                check("tracked file is regular: " + name, stat.S_ISREG(before.st_mode))
                check("raw Git file size: " + name, before.st_size, length)
                remaining = length
                with path.open("rb") as stream:
                    while remaining:
                        amount = min(1024 * 1024, remaining)
                        expected, actual = child.stdout.read(amount), stream.read(amount)
                        check("raw Git chunk bytes: " + name, actual == expected and len(actual) == amount)
                        sha.update(actual)
                        remaining -= amount
                    check("tracked file has no extra bytes: " + name, stream.read(1), b"")
            check("Git batch separator: " + name, child.stdout.read(1), b"\n")
            after = path.lstat()
            check("source unchanged during read: " + name,
                  (before.st_dev, before.st_ino, before.st_mode, before.st_size, before.st_mtime_ns, before.st_ctime_ns),
                  (after.st_dev, after.st_ino, after.st_mode, after.st_size, after.st_mtime_ns, after.st_ctime_ns))
            result[name] = {**declared, "bytes": length, "sha256": sha.hexdigest()}
        child.stdin.close()
        check("no unexpected Git batch output", child.stdout.read(), b"")
        check("no Git batch errors", child.stderr.read(), b"")
        check("Git batch success", child.wait(timeout=30), 0)
    finally:
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=10)
    return result


def contract(rev):
    value = json.loads(raw(rev, "docs/HIA_SAFETY_CONTRACT.json"))
    references = [s for row in value["capabilities"] for s in row["regression_selectors"]]
    return value, references, set(references)


def classes(data):
    return {node.name: node for node in ast.parse(data).body if isinstance(node, ast.ClassDef)}


def definition(data, name):
    return next(node for node in ast.parse(data).body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name == name)


def dump(node):
    return ast.dump(node, include_attributes=False)


def main():
    OUT.mkdir(exist_ok=False)
    before = state()
    check("exact frozen identity", before, {"head": HEAD, "tree": TREE, "status": ""})
    check("exact parent405", git("rev-parse", "HEAD^").decode().strip(), BASE)
    changes = git("diff", "--name-only", BASE, HEAD).decode().splitlines()
    check("reviewed change count", len(changes), 32)
    (OUT / "source-change.patch").write_bytes(git("diff", BASE, HEAD))
    inventory = snapshot(tree())
    check("full materialized tracked source count", len(inventory), 7697)
    save("source-before.json", {"identity": before, "files": inventory,
                                "file_count": len(inventory), "bytes": sum(v["bytes"] for v in inventory.values()),
                                "all_raw_git_bytes_and_modes_verified": True})

    comparisons = []
    for name in ["rust/hia-core-shadow/src/composite_records.rs", "rust/hia-core-shadow/src/lib.rs",
                 "rust/hia-core-shadow/src/main.rs", "rust/hia-core-shadow/tests/composite_copy_records.rs",
                 "tests/test_hia_rust_copy_records.py"]:
        check("raw candidate restored exactly from147: " + name, raw(HEAD, name), raw(OLD, name))
        comparisons.append({"file": name, "equal_to": OLD, "basis": "raw Git bytes"})
    unchanged = ["rust/hia-core-shadow/src/scalar_vm.rs", "rust/hia-core-shadow/src/scalar_vm/byte_memory.rs",
                 "hepta/hia_rust_crosscheck.py", "hepta/hia_schema.py", "hepta/hia_routes.py",
                 "hepta/hia_program_runtime.py", "hepta/hia_program.py", "hepta/hia_program_llvm.py",
                 "tests/test_hia_filecheck_linker_dispatch.py"]
    for name in unchanged:
        check("new405 implementation retained unchanged: " + name, raw(HEAD, name), raw(BASE, name))
        comparisons.append({"file": name, "equal_to": BASE, "basis": "raw Git bytes"})
    for name in unchanged[:2]:
        check("same Machine already present in both source lines: " + name, raw(BASE, name), raw(OLD, name))
    for name in ["tools/c2hepta.py", "tests/test_c2hepta_source_provenance.py", ".github/workflows/hepta-migration.yml"]:
        check("P3 source exactly reviewed e6 slice: " + name, raw(HEAD, name), raw(P3, name))
        comparisons.append({"file": name, "equal_to": P3, "basis": "raw Git bytes"})

    candidate_source = raw(HEAD, "rust/hia-core-shadow/src/composite_records.rs").decode()
    check("same full primitive ownership verification before normalized result", "super::verify_owned(&bytes)?" in candidate_source)
    check("raw record execution invokes existing bound-v4", "super::execute_owned_bound_v4(&normalized.bytes, function, arguments, policy)?" in candidate_source)
    check("candidate authority remains false", '"rust_is_production_admission_authority":false' in candidate_source)
    composite_name = "tests/test_hia_composite_returned_loans.py"
    final_classes, base_classes = classes(raw(HEAD, composite_name)), classes(raw(BASE, composite_name))
    for name, node in base_classes.items():
        check("existing new-field test class AST preserved: " + name, dump(final_classes[name]), dump(node))
    support_name = "tests/hia_composite_primitive_returns.py"
    support_classes, old_classes = classes(raw(HEAD, support_name)), classes(raw(OLD, composite_name))
    old_method_ids = []
    for name, node in old_classes.items():
        check("old primitive-formal class AST preserved: " + name, dump(support_classes[name]), dump(node))
        wrapper = final_classes[name]
        check("wrapper keeps inherited actual test methods: " + name, len(wrapper.bases), 1)
        check("wrapper base is module-qualified: " + name, dump(wrapper.bases[0]),
              dump(ast.parse("_primitive_return_tests." + name, mode="eval").body))
        check("wrapper defines no duplicate methods: " + name, [n for n in wrapper.body if isinstance(n, ast.FunctionDef)], [])
        old_method_ids += ["tests.test_hia_composite_returned_loans." + name + "." + n.name
                           for n in node.body if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")]
    check("old method denominator", len(old_method_ids), 13)
    check("support file outside discovery", not Path(support_name).name.startswith("test_"))
    new_method_ids = ["tests.test_hia_composite_returned_loans." + name + "." + n.name
                      for name, node in base_classes.items() for n in node.body
                      if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")]
    check("new-field method denominator", len(new_method_ids), 15)
    mixed = "tests.test_hia_composite_returned_loans.CompositeOriginConvergenceTests.test_mixed_primitive_and_field_origins_share_exact_core_and_refusals"
    check("exact added composite classes", set(final_classes) - set(base_classes), set(old_classes) | {"CompositeOriginConvergenceTests"})

    before_contract, before_refs, before_selectors = contract(BASE)
    old_contract, old_refs, old_selectors = contract(OLD)
    current, refs, selectors = contract(HEAD)
    check("base405 selector denominator", len(before_selectors), 277)
    check("old147 selector denominator", len(old_selectors), 126)
    check("original union denominator", len(before_selectors | old_selectors), 323)
    check("old147 missing-on405 denominator", len(old_selectors - before_selectors), 46)
    check("current unique and total selectors", (len(refs), len(selectors)), (340, 340))
    check("current capabilities", len(current["capabilities"]), 36)
    check("all original405 and147 selectors retained", before_selectors | old_selectors <= selectors)
    extra = selectors - before_selectors - old_selectors
    p3_methods = {s for s in selectors if s.startswith("tests.test_c2hepta_source_provenance.")}
    field_extra = set(new_method_ids) - before_selectors - old_selectors
    check("ten newly selected existing field methods", len(field_extra), 10)
    check("six P3 provenance selectors", len(p3_methods), 6)
    check("exact seventeen extras", extra, field_extra | {mixed} | p3_methods)
    for field in ("authority", "unproved_claims", "boundaries", "registry"):
        check("unchanged qualification authority/registry boundary: " + field, current[field], before_contract[field])
    before_caps = {c["id"]: c for c in before_contract["capabilities"]}
    current_caps = {c["id"]: c for c in current["capabilities"]}
    for name, row in before_caps.items():
        check("original capability retained: " + name, name in current_caps)
        check("original guarantee retained: " + name, current_caps[name]["guarantee"], row["guarantee"])
        check("original capability selectors retained: " + name,
              set(row["regression_selectors"]) <= set(current_caps[name]["regression_selectors"]))
    reviewed_module = ast.parse(raw(HEAD, "tools/qualify_hia_safety_contract.py"))
    reviewed = next(ast.literal_eval(n.value) for n in reviewed_module.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "REVIEWED_CONTRACT_SHA256" for t in n.targets))
    canonical = json.dumps(current, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    check("current canonical matrix matches independent reviewed hash", hashlib.sha256(canonical).hexdigest(), reviewed)
    check("frozen canonical matrix hash", reviewed, "a60ea8fd8014500d6874f2eddb52ea4499a218063a13f2e98691dfd7a2957ae8")
    for name in ("validate_contract", "RecordedResult", "qualify"):
        check("qualification execution/antiweakening logic unchanged: " + name,
              dump(definition(raw(HEAD, "tools/qualify_hia_safety_contract.py"), name)),
              dump(definition(raw(BASE, "tools/qualify_hia_safety_contract.py"), name)))

    linker = "tools/hia_filecheck_target_profile.py"
    for name in ("elf_linker_driver", "elf_linker_version_argv"):
        check("original identity/lifetime helper restored exactly: " + name,
              dump(definition(raw(HEAD, linker), name)), dump(definition(raw(OLD, linker), name)))
    check("current synthetic dispatcher helper preserved",
          dump(definition(raw(HEAD, "tests/test_hia_filecheck_target_profile.py"), "_elf_lto_linker_profile")),
          dump(definition(raw(BASE, "tests/test_hia_filecheck_target_profile.py"), "_elf_lto_linker_profile")))
    for name in (".github/workflows/hepta-native-hosts.yml", ".github/workflows/hepta-cpp-upstream-hosts.yml"):
        now = raw(HEAD, name).decode().replace(
            "codex/hia-rust-record-normalization-20261030, codex/hia-core-rust-convergence-20261030, ", "", 1)
        check("host workflow change only adds the two branches: " + name, now, raw(BASE, name).decode())
    now = raw(HEAD, ".github/workflows/hepta-qualification.yml").decode().replace(
        "      - codex/hia-rust-record-normalization-20261030\n      - codex/hia-core-rust-convergence-20261030\n", "", 1)
    check("full workflow change only adds the two branches", now, raw(BASE, ".github/workflows/hepta-qualification.yml").decode())

    check("source identity remains frozen after read-only inspection", state(), before)
    save("selector-declarations.json", {"base405": sorted(before_selectors), "old147": sorted(old_selectors),
         "union323": sorted(before_selectors | old_selectors), "current340": sorted(selectors),
         "extra17": sorted(extra), "extra_field10": sorted(field_extra), "extra_mixed1": [mixed],
         "extra_p3_6": sorted(p3_methods), "old_primitive13": sorted(old_method_ids),
         "new_field15": sorted(new_method_ids), "capabilities": len(current_caps),
         "matrix_canonical_sha256": reviewed, "this_is_declaration_review_not_execution_evidence": True})
    summary = {"schema": "hepta.integration405-f654-frozen-source-peer-review.v1", "ok": True,
               "identity": before, "parent": BASE, "changed_files": changes, "file_count": len(inventory),
               "source_bytes": sum(v["bytes"] for v in inventory.values()), "raw_git_bytes_and_modes_match": True,
               "comparisons": comparisons, "safety_selectors": 340, "safety_capabilities": 36,
               "all_old_selectors_preserved": True, "selector_execution_not_claimed_by_this_static_stage": True,
               "native_or_test_reruns_by_peer": 0, "source_mutations_by_peer": 0, "github_writes_by_peer": 0,
               "new_blocking_static_findings": [], "audit_checks": len(CHECKS),
               "limits": ["Exact local f654 source; actual execution evidence is audited separately.",
                          "Raw CLI pre/post hashes and sealed production differential custody are distinct scopes.",
                          "LLD exit checks detect identity drift but are not sealed executable custody.",
                          "No full340, hosted CI, production-authority, whole-language or P0-P7 closure claim follows from source checks."]}
    save("static-review.json", summary)
    return summary


if __name__ == "__main__":
    started = time.time_ns()
    try:
        report = main()
    except BaseException as error:
        if OUT.exists():
            save("static-review-failure.json", {"error": type(error).__name__, "message": str(error),
                 "candidate_execution_failure_inferred": False})
        raise
    finally:
        if OUT.exists():
            save("static-checks.json", CHECKS)
    print(json.dumps({"ok": report["ok"], "head": HEAD, "source_files": report["file_count"],
                      "source_bytes": report["source_bytes"], "safety_selectors": 340, "capabilities": 36,
                      "audit_checks": report["audit_checks"], "elapsed_ns": time.time_ns() - started}, indent=2))
