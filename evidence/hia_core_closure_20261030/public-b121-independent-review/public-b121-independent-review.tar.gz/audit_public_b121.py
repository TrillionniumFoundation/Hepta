#!/usr/bin/env python3
"""Read original b121 qualification records and exact Git bytes; run no project code."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = WORK / "hepta-core-rust-ci-guards"
INPUT = WORK / "guard-fix-validation-20261030"
OUT = HERE / "audit"
HEAD = "b121c9b4a57a8a58e53360d1d67387d953348f57"
TREE = "8e39b41544b5fde725a6ed57cc104bfa2f3fa257"
PARENT = "e0b9012a249167b5bc5b0f3bd243899344621080"
LOCAL = "40ae7fa8c8d8c82cec0861e4f946e264329a984a"
MATRIX = "a60ea8fd8014500d6874f2eddb52ea4499a218063a13f2e98691dfd7a2957ae8"
COUNTS = Counter()
INPUTS = {}
METHODS = {}
SECTION = "preconditions"


def check(label, actual, expected=True):
    COUNTS[SECTION] += 1
    if actual != expected:
        raise AssertionError(f"{SECTION}: {label}: {actual!r} != {expected!r}")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    before = path.stat()
    digest = hashlib.sha256()
    blob = hashlib.sha1(b"blob " + str(before.st_size).encode() + b"\0")
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
            blob.update(block)
            size += len(block)
    after = path.stat()
    check("stable input while reading " + str(path),
          (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns),
          (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns))
    value = {"path": str(path), "bytes": size, "sha256": digest.hexdigest(),
             "git_blob": blob.hexdigest(), "mode": oct(before.st_mode & 0o777)}
    INPUTS[str(path)] = value
    return value


def read(path):
    path = Path(path)
    row = identity(path)
    data = path.read_bytes()
    check("input content digest " + str(path), sha(data), row["sha256"])
    return data


def load(path):
    return json.loads(read(path))


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def verify_file(path, row):
    observed = identity(path)
    for field in ("bytes", "sha256"):
        check("retained input " + field + " " + str(path), observed[field], row[field])
    if "mode" in row:
        check("retained input mode " + str(path), observed["mode"], row["mode"])


def ordinary_log(label, log, expected):
    headings = list(re.finditer(r"(?m)^test_[^ ]+ \(([^)]+)\)", log))
    names = [heading.group(1) for heading in headings]
    check(label + " exact event count", len(headings), len(expected))
    for index, heading in enumerate(headings):
        end = headings[index + 1].start() if index + 1 < len(headings) else len(log)
        check(label + " ordinary event " + names[index],
              re.findall(r"(?m)\.\.\. (.+)$", log[heading.end():end]), ["ok"])
    check(label + " unique methods", len(set(names)), len(names))
    check(label + " exact selection", Counter(names), Counter(expected))
    check(label + " terminal count", re.findall(r"(?m)^Ran ([0-9]+) tests? in .+$", log), [str(len(expected))])
    check(label + " terminal status", log.rstrip().splitlines()[-1], "OK")
    METHODS[label] = names
    return names


def source_record(label, row, expected):
    check(label + " exact head", row["head"], HEAD)
    check(label + " exact tree", row["tree"], TREE)
    check(label + " clean", row["status"], "")
    check(label + " full original bytes", row["files"], expected)


def ordinary_summary(label, row, count):
    check(label, row, {"run": count, "errors": 0, "failures": 0, "skipped": 0,
                       "expected_failures": 0, "unexpected_successes": 0})


def main():
    global SECTION
    OUT.mkdir(exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    helper_path = WORK / "integration-405-independent-review/review_f654_source.py"
    read(helper_path)
    spec = importlib.util.spec_from_file_location("source_bytes_reader", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.ROOT, helper.HEAD, helper.check = ROOT, HEAD, check
    before = helper.state()
    check("exact live checkout", before, {"head": HEAD, "tree": TREE, "status": ""})
    check("exact public parent", helper.git("rev-parse", HEAD + "^").decode().strip(), PARENT)
    check("local/public same tree", helper.git("rev-parse", LOCAL + "^{tree}").decode().strip(), TREE)

    SECTION = "raw_git_source_before"
    source = helper.snapshot(helper.tree())
    check("all tracked paths", len(source), 7697)
    hashes = {name: row["sha256"] for name, row in source.items()}
    save("source-inventory.json", {"identity": before, "files": source,
         "all_raw_git_bytes_and_modes_verified": True,
         "bytes": sum(row["bytes"] for row in source.values())})

    SECTION = "canonical_safety340"
    safety_dir = INPUT / "public-b121-safety340"
    safety = load(safety_dir / "qualification.json")
    receipt = load(safety_dir / "receipt.json")
    selected = load(safety_dir / "selected-methods.json")
    contract = json.loads(helper.raw(HEAD, "docs/HIA_SAFETY_CONTRACT.json"))
    declared = sorted({name for row in contract["capabilities"] for name in row["regression_selectors"]})
    check("canonical reviewed matrix", sha(canonical(contract)), MATRIX)
    check("reported original contract", safety["contract"], contract)
    check("reviewed digest", safety["reviewed_contract_sha256"], MATRIX)
    check("reported digest", safety["contract_sha256"], MATRIX)
    check("selected exact declarations", selected, declared)
    check("selected methods", len(selected), 340)
    check("capabilities", len(safety["capabilities"]), 36)
    for original, report in zip(contract["capabilities"], safety["capabilities"]):
        check("capability identity", report["id"], original["id"])
        check("capability selectors", report["regression_selectors"], original["regression_selectors"])
        check("actual capability evidence", report["regression_evidence_passed"])
        check("no proof from tests", report["soundness_or_refinement_proof_established_by_this_run"], False)
    check("actual count", (safety["expected_tests"], safety["tests_run"]), (340, 340))
    check("actual status", safety["status"], "passed")
    check("result keys", set(safety["tests"]), set(selected))
    check("all ordinary outcomes", {row["status"] for row in safety["tests"].values()}, {"passed"})
    events = ordinary_log("public_b121_safety340", safety["log"], selected)
    event_receipt = load(safety_dir / "method-event-readback.json")
    check("actual event stream", event_receipt["events"], events)
    check("exact once count", (event_receipt["count"], event_receipt["unique"]), (340, 340))
    for side in ("before", "after"):
        check("inner exact head " + side, safety[f"head_{side}"]["stdout"].strip(), HEAD)
        source_record("wrapper " + side, load(safety_dir / f"source-{side}.json"), hashes)
        check("inner source original " + side, safety[f"source_{side}"],
              {name: hashes[name] for name in safety[f"source_{side}"]})
    check("inner source stable", safety["source_before"], safety["source_after"])
    check("inner source count", len(safety["source_before"]), 1071)
    for field in ("ok", "exact_once_method_events", "source_unchanged", "tools_unchanged", "external_inputs_unchanged"):
        check("wrapper " + field, receipt[field])
    check("wrapper actual head", receipt["actual_public_head"], HEAD)
    check("wrapper actual tree", receipt["tree"], TREE)
    check("wrapper returncode", receipt["returncode"], 0)
    check("producer identity", sha(read(WORK / "integration-405-147-20261030/run-public-safety340.py")), receipt["producer_sha256"])
    launcher = load(safety_dir / "parameterization.json")
    check("parameterized actual source", (launcher["head"], launcher["tree"]), (HEAD, TREE))
    check("historical e0 original unchanged", launcher["historical_e0_source_or_evidence_modified"], False)
    check("launcher digest", sha(read(INPUT / "run-public-safety340.py")), launcher["launcher_sha256"])
    check("original producer stable", launcher["original_producer_sha256_before_after"], receipt["producer_sha256"])
    for name, row in receipt["raw"].items():
        verify_file(safety_dir / name, row)
    for name, value in safety["claims"].items():
        check("bounded claim " + name, value, name == "all_selected_boundary_regressions_passed_without_skips")

    SECTION = "external_inputs_and_tools"
    external = load(safety_dir / "external-before.json")
    check("external input original stability", external, load(safety_dir / "external-after.json"))
    kinds = Counter()
    for name, row in external.items():
        verify_file(name, row)
        kinds["NDU original" if "/original/" in name else "NDU transport-only receipt" if "transport-identity.json" in name else "Z3 retained file" if "/z3-4.15.4/" in name else "Rust executable"] += 1
    tools = load(safety_dir / "tools-before.json")
    check("tool original stability", tools, load(safety_dir / "tools-after.json"))
    check("actual environment", tools, safety["environment"])
    for name, row in tools["tools"].items():
        check("tool bytes " + name, identity(row["path"])["sha256"], row["sha256"])
        version = row.get("version", row)
        check("recorded version returncode " + name, version["returncode"], 0)
        check("recorded version output " + name, bool(version["stdout"].strip()))
    check("Python executable", identity(tools["python"]["executable"])["sha256"], tools["python"]["sha256"])
    check("Z3 native library", identity(tools["solver"]["library_path"])["sha256"], tools["solver"]["library_sha256"])
    check("no full transitive sysroot proof", tools["complete_transitive_toolchain_or_sysroot_closure_proved"], False)

    SECTION = "public_related13"
    related_dir = INPUT / "public-b121-related13"
    related = load(related_dir / "receipt.json")
    related_selected = load(related_dir / "selected-methods.json")
    results = load(related_dir / "method-results.json")
    ordinary_summary("actual 13 summary", related["tests"], 13)
    check("related actual identity", (related["actual_head"], related["tree"]), (HEAD, TREE))
    check("related method set", set(results), set(related_selected))
    check("related ordinary outcomes", {row["status"] for row in results.values()}, {"passed"})
    related_events = ordinary_log("public_b121_related13", read(related_dir / "stderr.log").decode(), related_selected)
    check("related exact events", related_events, related["actual_method_events"])
    for side in ("before", "after"):
        source_record("related source " + side, load(related_dir / f"source-{side}.json"), hashes)
    check("related tool stable", load(related_dir / "tools-before.json"), load(related_dir / "tools-after.json"))
    for name, row in related["raw"].items():
        verify_file(related_dir / name, row)

    SECTION = "public_controlled_delay"
    control_dir = INPUT / "public-b121-controlled-delay"
    controlled = load(control_dir / "receipt.json")
    check("control actual source", controlled["actual_head"], HEAD)
    ordinary_summary("actual control summary", controlled["tests"], 1)
    check("expected green observed", (controlled["expected"], controlled["expected_outcome_observed"]), ("green", True))
    control_id = "tests.test_hia_native_child_limits.NativeChildHardLimitTests.test_worker_timeout_and_normal_exit_both_reap_forked_descendants"
    ordinary_log("public_b121_controlled_delay", controlled["log"], [control_id])
    check("original control log", read(control_dir / "test.log").decode(), controlled["log"])
    for side in ("before", "after"):
        source_record("controlled source " + side, controlled[f"source_{side}"], hashes)
    returncodes = [child["returncode"] for child in controlled["children"]]
    check("actual child exit codes", returncodes, [-31, -31, -9])
    check("actual marker checks", [row["exists"] for row in controlled["marker_checks"]], [False, False, False])
    check("native timeouts retained", [row["timeout_seconds"] for row in controlled["observations"]], [3.0, 3.0, 0.2])
    check("cleanup stable", controlled["cleanup_before"], controlled["cleanup_after"])
    for field, expected in (("reserved_native_children", 0), ("unconfirmed_child_reaps", 0), ("children", [])):
        check("cleanup " + field, controlled["cleanup_after"][field], expected)
    original_worker = read(control_dir / "original-worker.py")
    delayed_worker = read(control_dir / "delayed-worker.py")
    check("worker original hash", sha(original_worker), controlled["original_worker_sha256"])
    check("worker delayed hash", sha(delayed_worker), controlled["delayed_worker_sha256"])
    check("original worker exact suffix", delayed_worker.endswith(original_worker))
    check("actual delay", controlled["controlled_delay_seconds"], 0.35)
    trace = [json.loads(line) for line in read(control_dir / "child-startup.jsonl").decode().splitlines()]
    check("retained trace", trace, controlled["startup_trace"])
    for symbol in ("fork_and_stall", "fork_and_return"):
        events = [row for row in trace if row["symbol"] == symbol]
        check("actual startup phases " + symbol, [row["phase"] for row in events], ["before_delay", "before_original_worker"])
        check("actual delay elapsed " + symbol, events[1]["monotonic_ns"] - events[0]["monotonic_ns"] >= 350_000_000)
    for row in controlled["pins"]:
        verify_file(control_dir / (row["sha256"] + ".so"), row)

    SECTION = "raw_git_source_after"
    after = helper.snapshot(helper.tree())
    check("full source and modes unchanged during audit", after, source)
    check("full checkout identity unchanged during audit", helper.state(), before)
    save("method-events.json", METHODS)
    save("input-manifest.json", list(INPUTS.values()))
    report = {"schema": "hepta.public-b121-independent-review.v1", "ok": True,
        "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "source": {"head": HEAD, "tree": TREE, "parent": PARENT,
                   "same_tree_local_commit": LOCAL, "tracked_files": len(source),
                   "tracked_bytes": sum(row["bytes"] for row in source.values()),
                   "all_raw_git_bytes_and_modes_verified_before_and_after": True},
        "actual_safety": {"methods": 340, "capabilities": 36, "exact_once_ordinary_pass": True,
                          "canonical_sha256": MATRIX, "inner_source_subset_files": len(safety["source_before"]),
                          "raw_qualification_sha256": receipt["raw"]["qualification.json"]["sha256"],
                          "started_utc": receipt["started_utc"], "finished_utc": receipt["finished_utc"]},
        "actual_related_methods": 13,
        "actual_controlled_delay": {"methods": 1, "child_exit_codes": returncodes,
                                    "absent_markers": 3, "reserved_children": 0, "unconfirmed_reaps": 0},
        "external_files": len(external), "external_breakdown": dict(kinds),
        "read_only_check_count": sum(COUNTS.values()), "check_sections": dict(COUNTS),
        "input_files": len(INPUTS), "new_native_test_or_build_invocations": 0,
        "earlier_e0_official_failure_reclassified": False,
        "limits": ["The 340, related13 and controlled1 method populations overlap; do not add them as independent coverage.",
                   "This audit reads original b121 execution records, exact source bytes, modes, raw result logs and retained external inputs. It reruns no native program, project test or build.",
                   "The earlier official e0 339-pass/1-failed-subtest result remains a failure. Its full original records and the separate local 40ae review are unchanged.",
                   "This does not audit later official hosted b121 workflows, qualify later P0 sources, switch Python authority, change no_change optimization policy, or close any of the 27 broad P0-P7 obligations."]}
    save("review.json", report)
    print(json.dumps({"ok": True, "head": HEAD, "read_only_checks": report["read_only_check_count"],
                      "actual_safety_methods": 340, "actual_related_methods": 13,
                      "actual_control_methods": 1, "new_native_tests_or_builds": 0}))


if __name__ == "__main__":
    main()
