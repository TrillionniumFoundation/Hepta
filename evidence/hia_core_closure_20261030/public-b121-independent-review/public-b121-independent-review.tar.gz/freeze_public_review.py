#!/usr/bin/env python3
"""Freeze this new read-only supplement without changing older owner or peer packages."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
PREFIX = "evidence/hia_core_closure_20261030/public-b121-independent-review/"


def info(path, relative=None):
    data = path.read_bytes()
    return {"path": relative or path.name, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
            "mode": "100644"}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def main():
    helper = HERE.parent / "integration-405-independent-review/review_f654_source.py"
    copied = HERE / "source_bytes_reader.py"
    assert not copied.exists()
    shutil.copyfile(helper, copied)
    assert copied.read_bytes() == helper.read_bytes()
    names = ["README.md", "audit_public_b121.py", "freeze_public_review.py", "source_bytes_reader.py",
             "audit.stdout.log", "audit.stderr.log", "audit/source-inventory.json",
             "audit/method-events.json", "audit/input-manifest.json", "audit/review.json"]
    rows = [info(HERE / name, name) for name in names]
    save(HERE / "archive-manifest.json", {"schema": "hepta.public-b121-peer-retention.v1", "files": rows,
        "owner_originals_are_in_separate_frozen_guard_package": True,
        "private_transport_included": False, "native_test_build_reruns": 0})
    names.append("archive-manifest.json")
    expected = {name: info(HERE / name, name) for name in names}
    archive = HERE / "public-b121-independent-review.tar.gz"
    assert not archive.exists()
    with archive.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as compressed:
            with tarfile.open(fileobj=compressed, mode="w|") as tar:
                for name in names:
                    data = (HERE / name).read_bytes()
                    member = tarfile.TarInfo(name)
                    member.size = len(data)
                    member.mode = 0o644
                    member.mtime = 0
                    tar.addfile(member, io.BytesIO(data))
    actual = {}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            assert member.isfile() and member.name not in actual
            data = tar.extractfile(member).read()
            actual[member.name] = {"path": member.name, "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                "mode": "100644"}
    assert actual == expected
    with gzip.open(archive, "rb") as stream:
        while stream.read(1024 * 1024):
            pass
    for name, row in expected.items():
        assert info(HERE / name, name) == row
    receipt = {"schema": "hepta.public-b121-peer-archive.v1", "archive": info(archive),
        "members": len(actual), "all_members_read_back_exactly": True,
        "complete_gzip_stream_crc_checked": True, "all_original_inputs_unchanged_during_packaging": True}
    save(HERE / "archive-receipt.json", receipt)
    payloads = [archive.name, "README.md", "audit/review.json", "archive-manifest.json", "archive-receipt.json"]
    entries = []
    for name in payloads:
        row = info(HERE / name, name)
        row.update({"local_path": str(HERE / name), "repository_path": PREFIX + name})
        entries.append(row)
    save(HERE / "publication-files.json", {"schema": "hepta.public-b121-peer-publication.v1",
        "source_head": "b121c9b4a57a8a58e53360d1d67387d953348f57", "files": entries,
        "also_publish_this_map": True, "map_repository_path": PREFIX + "publication-files.json",
        "older_guard_peer_and_owner_packages_unchanged": True,
        "root_is_only_remote_writer": True, "private_transport_included": False})
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
