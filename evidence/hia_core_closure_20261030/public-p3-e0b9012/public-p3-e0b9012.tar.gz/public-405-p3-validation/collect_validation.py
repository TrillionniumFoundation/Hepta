"""Run a named P3 selection once, retaining exact command and identity data."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

evidence = Path(__file__).resolve().parent
root = evidence.parent / "hepta-core-rust-public"
label, selection = sys.argv[1:3]
destination = evidence / label
destination.mkdir()
rust_bin = evidence.parent / "toolchains/rust-1.90.0/bin"
llvm = evidence.parent / "toolchains/llvm20-evening/usr"
env = dict(os.environ)
env["PATH"] = str(rust_bin) + ":" + str(llvm / "lib/llvm-20/bin") + ":" + env["PATH"]
env["LD_LIBRARY_PATH"] = str(llvm / "lib/x86_64-linux-gnu") + ":" + str(llvm / "lib/llvm-20/lib")
env["RUSTC"] = str(rust_bin / "rustc")
env["PYTHONDONTWRITEBYTECODE"] = "1"
env["PYTHONPATH"] = str(root)

def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
            "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}

def source_snapshot():
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=root).split(b"\0")
    paths = [root / os.fsdecode(p) for p in tracked if p and (root / os.fsdecode(p)).is_file()]
    candidate = root / "tests/test_c2hepta_source_provenance.py"
    if candidate not in paths:
        paths.append(candidate)
    return {str(p.relative_to(root)): identity(p) for p in sorted(paths)}

def tools_snapshot():
    result = {}
    for name, version_args in (("python3", ["--version"]), ("clang", ["--version"]),
                               ("gcc", ["--version"]), ("rustc", ["-vV"])):
        chosen = Path(shutil.which(name, path=env["PATH"])).resolve()
        command = [str(chosen)] + version_args
        started = time.time_ns()
        output = subprocess.run(command, env=env, capture_output=True, timeout=20)
        result[name] = {**identity(chosen), "argv": command, "started_ns": started,
                        "finished_ns": time.time_ns(), "returncode": output.returncode,
                        "stdout": output.stdout.decode(errors="replace"),
                        "stderr": output.stderr.decode(errors="replace")}
    return result

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=root, text=True).strip()
source_before = source_snapshot()
tools_before = tools_snapshot()
for name, value in (("source-before.json", source_before), ("tools-before.json", tools_before)):
    (destination / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
argv = [sys.executable, str(evidence / "run_suite.py"), str(root), str(destination), selection]
started = time.time_ns()
clock = time.monotonic_ns()
with (destination / "stdout.log").open("wb") as stdout, (destination / "stderr.log").open("wb") as stderr:
    execution = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr)
finished = time.time_ns()
elapsed = time.monotonic_ns() - clock
source_after = source_snapshot()
tools_after = tools_snapshot()
for name, value in (("source-after.json", source_after), ("tools-after.json", tools_after)):
    (destination / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
stable_tools = all({k: v for k, v in tools_before[n].items() if k not in ("started_ns", "finished_ns")}
                   == {k: v for k, v in tools_after[n].items() if k not in ("started_ns", "finished_ns")}
                   for n in tools_before)
receipt = {"schema": "hepta.p3-security-validation-receipt.v1", "label": label, "selection": selection,
           "argv": argv, "cwd": str(root), "head": head, "head_tree": tree,
           "worktree_status": subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True),
           "environment": {k: env[k] for k in ("PATH", "LD_LIBRARY_PATH", "RUSTC", "PYTHONPATH", "PYTHONDONTWRITEBYTECODE")},
           "started_ns": started, "finished_ns": finished, "elapsed_ns": elapsed,
           "returncode": execution.returncode, "source_scope": "all materialized tracked files in sparse worktree, plus the newly added regression module",
           "materialized_source_count": len(source_before), "source_stable": source_before == source_after,
           "tools_stable": stable_tools, "collector": identity(Path(__file__)),
           "runner": identity(evidence / "run_suite.py"),
           "stdout": identity(destination / "stdout.log"), "stderr": identity(destination / "stderr.log")}
(destination / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
summary = json.loads((destination / "tests.json").read_text())
print(json.dumps({"label": label, "head": head, "selection": selection, "tests_run": summary["tests_run"],
                  "failures": summary["failures"], "errors": summary["errors"], "skips": summary["skips"],
                  "clang_calls": len(summary["clang_calls"]), "migrations": len(summary["migration_calls"]),
                  "source_stable": receipt["source_stable"], "tools_stable": stable_tools,
                  "receipt": str(destination / "receipt.json")}, sort_keys=True))
