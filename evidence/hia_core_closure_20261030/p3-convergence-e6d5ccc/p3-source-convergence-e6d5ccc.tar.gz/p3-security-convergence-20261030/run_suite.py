"""External evidence collector; delegates all assertions to repository tests."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import re
import sys
import time
import unittest
from unittest import mock

root = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
selection = sys.argv[3]
sys.path.insert(0, str(root))
state = {"test": None}
events = []
captures = []
migrations = []

def save_bytes(name, value):
    path = destination / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value)
    return {"path": name, "bytes": len(value),
            "sha256": hashlib.sha256(value).hexdigest()}

class RecordedResult(unittest.TextTestResult):
    def startTest(self, test):
        super().startTest(test)
        state["test"] = test.id()
        events.append({"event": "start", "test": test.id(), "time_ns": time.time_ns()})

    def stopTest(self, test):
        events.append({"event": "stop", "test": test.id(), "time_ns": time.time_ns()})
        super().stopTest(test)
        state["test"] = None

    def addSuccess(self, test):
        events.append({"event": "success", "test": test.id()})
        super().addSuccess(test)

    def addFailure(self, test, err):
        events.append({"event": "failure", "test": test.id()})
        super().addFailure(test, err)

    def addError(self, test, err):
        events.append({"event": "error", "test": test.id()})
        super().addError(test, err)

if selection == "new":
    patterns = ("test_c2hepta_source_provenance.py",)
elif selection == "workflow":
    workflow = (root / ".github/workflows/hepta-migration.yml").read_text()
    patterns = ast.literal_eval(re.search(r"patterns = (\(.*?\))\s+suite", workflow, re.S).group(1))
else:
    raise ValueError(selection)

suite = unittest.TestSuite(unittest.defaultTestLoader.discover(str(root / "tests"), pattern=p)
                           for p in patterns)

def flatten(suite):
    for entry in suite:
        if isinstance(entry, unittest.TestSuite):
            yield from flatten(entry)
        else:
            yield entry.id()

selectors = list(flatten(suite))
(destination / "selected-tests.json").write_text(json.dumps(selectors, indent=2) + "\n")

from tools import c2hepta
real_clang = c2hepta._run_clang
real_migrate = c2hepta.migrate

def capture_clang(argv, **kwargs):
    index = len(captures)
    entry = {"index": index, "test": state["test"], "argv": argv,
             "timeout_seconds": kwargs.get("timeout"),
             "stdout_limit": kwargs.get("stdout_limit"), "started_ns": time.time_ns()}
    captures.append(entry)
    input_text = kwargs.get("input_text")
    if input_text is not None:
        entry["stdin"] = save_bytes(f"clang/{index:03d}.stdin", input_text.encode("utf-8"))
    started = time.monotonic_ns()
    try:
        result = real_clang(argv, **kwargs)
    except BaseException as exc:
        entry.update(exception=type(exc).__name__, message=str(exc))
        raise
    else:
        entry.update(returncode=result.returncode,
                     stdout=save_bytes(f"clang/{index:03d}.stdout", result.raw_stdout),
                     stderr=save_bytes(f"clang/{index:03d}.stderr", result.raw_stderr))
        return result
    finally:
        entry.update(elapsed_ns=time.monotonic_ns() - started, finished_ns=time.time_ns())

def capture_migrate(source, output, report, *args, **kwargs):
    index = len(migrations)
    entry = {"index": index, "test": state["test"], "requested_source": str(source),
             "resolved_before": str(source.resolve()), "started_ns": time.time_ns()}
    migrations.append(entry)
    started = time.monotonic_ns()
    try:
        result = real_migrate(source, output, report, *args, **kwargs)
    except BaseException as exc:
        entry.update(exception=type(exc).__name__, message=str(exc))
        raise
    else:
        entry["result"] = result
        if output.is_file():
            entry["output"] = save_bytes(f"migrations/{index:02d}.hepta", output.read_bytes())
        if report.is_file():
            entry["report"] = save_bytes(f"migrations/{index:02d}.json", report.read_bytes())
        return result
    finally:
        entry.update(elapsed_ns=time.monotonic_ns() - started, finished_ns=time.time_ns())

runner = unittest.TextTestRunner(verbosity=2, resultclass=RecordedResult)
if selection == "new":
    with (mock.patch.object(c2hepta, "_run_clang", side_effect=capture_clang),
          mock.patch.object(c2hepta, "migrate", side_effect=capture_migrate)):
        result = runner.run(suite)
else:
    result = runner.run(suite)

summary = {"schema": "hepta.p3-security-test-observation.v1", "selection": selection,
           "patterns": list(patterns), "tests_run": result.testsRun,
           "success": result.wasSuccessful(), "failures": len(result.failures),
           "errors": len(result.errors), "skips": len(result.skipped),
           "expected_failures": len(result.expectedFailures),
           "unexpected_successes": len(result.unexpectedSuccesses),
           "failed_tests": [test.id() for test, _ in result.failures],
           "error_tests": [test.id() for test, _ in result.errors],
           "events": events, "clang_calls": captures, "migration_calls": migrations,
           "collector_scope": "For the new regression selection, passive wrappers retain actual bounded Clang results and migration artifacts before test temporary-directory cleanup; compiler output is never synthesized."}
(destination / "tests.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
raise SystemExit(0 if result.testsRun and result.wasSuccessful() and not result.skipped else 1)
