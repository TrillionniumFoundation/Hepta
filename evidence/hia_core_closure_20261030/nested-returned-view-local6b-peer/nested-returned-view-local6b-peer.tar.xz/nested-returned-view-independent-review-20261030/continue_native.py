"""Run only the unexecuted native phase after retained IR-serialization error."""
from __future__ import annotations
from datetime import datetime, timezone
import ast
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
from unittest.mock import patch

BASE = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
ROOT = BASE / 'hepta-nested-returned-views'
OUT = HERE / 'native-continuation'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT))

def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),
            'mode': '100755' if path.stat().st_mode & stat.S_IXUSR else '100644'}

def write(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')

def git(*argv):
    return subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT),*argv])

def snapshot():
    files = {}
    rows = [r for r in git('ls-tree','-rz','HEAD').split(b'\0') if r]
    for row in rows:
        meta, raw = row.split(b'\t',1)
        mode, kind, blob = meta.decode().split()
        path = ROOT/raw.decode()
        if path.exists():
            assert kind=='blob' and stat.S_ISREG(path.lstat().st_mode)
            item = digest(path)
            assert item['mode']==mode and item['git_blob']==blob
            files[raw.decode()] = item
    return {'head':git('rev-parse','HEAD').decode().strip(),
            'tree':git('rev-parse','HEAD^{tree}').decode().strip(),
            'status':git('status','--porcelain','--untracked-files=all').decode(),
            'full_git_tree_files':len(rows),'materialized_source_files':len(files),'files':files}

def tool_snapshot():
    return {name:{'path':str(path),**digest(path)} for name,path in
            [('python',Path(sys.executable).resolve()),('clang',Path(os.environ['CLANG']).resolve())]}

before, tools_before = snapshot(), tool_snapshot()
producer_before = digest(Path(__file__))
assert before['head']=='6b83eae0aef1cfbc9654510b55f5c35ed0bd55d5' and not before['status']
write('source-before.json',before);write('tools-before.json',tools_before)
report = {'schema':'hepta.independent-nested-native-continuation.v1','ok':False,
          'started_unix':time.time(),'parent_control_failure_preserved':True,
          'python_rust_replayed':False,'owner_methods_rerun':0,'crate_builds':0}
compiler = []
try:
    old = json.loads((HERE/'candidate-green/report.json').read_text())
    assert old['exception']=={'type':'TypeError','message':'data must be str, not HIAProgramLLVM'}
    rows = json.loads((HERE/'candidate-green/python-rust.json').read_text())
    assert len(rows)==5
    for row in rows:
        assert row['rust_process']['returncode']==0 and json.loads(row['rust_process']['stdout'])==row['rust']
        for key in ['program_sha256','function','status','values','steps','resources']:
            assert row['python'][key]==row['rust'][key]
    core_path = HERE/'candidate-green/core.json'
    report['retained_core']={'path':str(core_path),**digest(core_path)}
    report['retained_python_rust']={'path':str(HERE/'candidate-green/python-rust.json'),
                                 **digest(HERE/'candidate-green/python-rust.json')}
    from hepta.hia_program import verify_program
    from hepta import hia_program_llvm as backend
    core = verify_program(core_path.read_bytes())
    ir = backend.emit_program_llvm(core)
    (OUT/'core.ll').write_text(ir.text)
    original_bounded = backend.run_bounded
    def observed(command,*args,**kwargs):
        row = {'argv':list(map(str,command)),'options':kwargs,'started_ns':time.time_ns(),'inputs':[]}
        directory = OUT/'compiler'/str(len(compiler)+1)
        directory.mkdir(parents=True)
        compiler.append(row)
        for item in command:
            path = Path(item)
            if str(item).endswith('.ll') and path.is_file():
                retained=directory/path.name;retained.write_bytes(path.read_bytes())
                row['inputs'].append({'original_path':str(path),'retained_path':str(retained.relative_to(OUT)),**digest(retained)})
        try:
            completed=original_bounded(command,*args,**kwargs)
        except BaseException as exc:
            row['exception']={'type':type(exc).__name__,'message':str(exc)}
            raise
        else:
            row.update(returncode=completed.returncode,stdout=completed.stdout,stderr=completed.stderr)
            return completed
        finally:
            row['finished_ns']=time.time_ns()
    artifact=OUT/'core.o'
    with patch.object(backend,'run_bounded',observed):
        receipt=backend.compile_program_llvm(ir,program=core,output=artifact,clang=os.environ['CLANG'],kind='object')
    write('llvm-receipt.json',receipt)
    assert receipt['ok'] and receipt['core_sha256']==old['core_sha256']
    # The already frozen C source literal is copied exactly, without executing
    # the earlier producer or replaying its completed Python/Rust phase.
    parsed=ast.parse((HERE/'controls-producer-used.py').read_text())
    matches=[n.value.value for n in ast.walk(parsed) if isinstance(n,ast.Assign)
             and any(isinstance(t,ast.Name) and t.id=='observer' for t in n.targets)
             and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)]
    assert len(matches)==1
    (OUT/'observer.c').write_text(matches[0])
    command=[os.environ['CLANG'],'-std=c11','-O2',str(OUT/'observer.c'),str(artifact),
             '-Wl,--wrap=malloc','-Wl,--wrap=calloc','-Wl,--wrap=free','-o',str(OUT/'observer')]
    linked=subprocess.run(command,capture_output=True,text=True,timeout=60,cwd=ROOT)
    report['link']={'argv':command,'returncode':linked.returncode,'stdout':linked.stdout,'stderr':linked.stderr}
    assert linked.returncode==0,linked.stderr
    observations=[]
    report['observations']=observations
    for source in rows:
        argv=[str(OUT/'observer'),str(source['enabled']),str(source['allocation_fail_at'] or 0)]
        result=subprocess.run(argv,capture_output=True,text=True,timeout=20,cwd=ROOT)
        expected={'value':source['expected'],'attempts':source['expected_attempts'],
                  'allocations':source['expected_allocations'],'frees':source['expected_allocations'],
                  'live_bytes':0,'peak_bytes':source['expected_peak_bytes']}
        actual={'argv':argv,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'expected':expected}
        observations.append(actual)
        assert result.returncode==0 and json.loads(result.stdout)==expected,actual
    report['artifacts']={p.name:digest(p) for p in [artifact,OUT/'observer',OUT/'observer.c',OUT/'core.ll']}
    report['ok']=True
except BaseException as exc:
    report['exception']={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    after,tools_after=snapshot(),tool_snapshot()
    write('source-after.json',after);write('tools-after.json',tools_after)
    write('compiler-processes.json',compiler)
    report.update(source_stable=before==after,tools_stable=tools_before==tools_after,
                  producer_before=producer_before,producer_after=digest(Path(__file__)),
                  finished_unix=time.time(),finished_utc=datetime.now(timezone.utc).isoformat())
    report['producer_stable']=report['producer_before']==report['producer_after']
    report['ok']=report['ok'] and report['source_stable'] and report['tools_stable'] and report['producer_stable']
    write('report.json',report)
    print(json.dumps({k:report[k] for k in ['ok','source_stable','tools_stable','producer_stable']}))
