"""Independent read-only reconstruction of frozen nested-origin evidence."""
from __future__ import annotations
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import time

BASE = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
OWNER = BASE/'nested-returned-view-composition-20261030'
ROOT = BASE/'hepta-nested-returned-views'
HEAD = '6b83eae0aef1cfbc9654510b55f5c35ed0bd55d5'
TREE = '0cac7421225a2f8bba1de07c08011d79410b8cdc'
PARENT = 'a6cfb7e00a1c08276d27459bdcc5628aa7622079'
checks = Counter()
inputs = {}

def require(value, label):
    if not value:
        raise AssertionError(label)
    checks[label.split(':')[0]] += 1

def digest(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def item(path):
    data=path.read_bytes()
    require(stat.S_ISREG(path.lstat().st_mode),'regular-file:'+str(path))
    return {**digest(data),'mode':'100755' if path.stat().st_mode & stat.S_IXUSR else '100644'}

def read(path):
    if not path.is_absolute(): path=OWNER/path
    inputs[str(path)]=item(path)
    return json.loads(path.read_text())

def git(*argv, env=None, input=None):
    return subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT),*argv],env=env,input=input)

def snapshot():
    rows={}
    for row in git('ls-tree','-rz',HEAD).split(b'\0'):
        if not row: continue
        meta,name=row.split(b'\t',1);mode,kind,blob=meta.decode().split()
        require(kind=='blob','git-kind')
        rows[name.decode()]={'mode':mode,'git_blob':blob}
    actual={}
    for name,row in rows.items():
        path=ROOT/name
        if path.exists():
            observed=item(path)
            require(all(observed[k]==v for k,v in row.items()),'materialized-raw-git:'+name)
            actual[name]=observed
    return {'head':git('rev-parse','HEAD').decode().strip(),
            'tree':git('rev-parse','HEAD^{tree}').decode().strip(),
            'status':git('status','--porcelain','--untracked-files=all').decode(),
            'full_git_tree_files':len(rows),'files':actual},rows

started=time.time()
before, git_rows=snapshot()
require(before['head']==HEAD and before['tree']==TREE and before['status']=='','candidate-identity')
require(git('rev-parse',HEAD+'^').decode().strip()==PARENT,'candidate-parent')
require(len(git_rows)==7701 and len(before['files'])==1459,'sparse-scope')
manifest=read(Path('owner-input-manifest.json'))
require(len(manifest['files'])==132 and manifest['bytes']==5437150,'owner-freeze-population')
for row in manifest['files']:
    path=OWNER/row['path'];actual=item(path)
    require(all(actual[k]==row[k] for k in ['bytes','mode','sha256']),'frozen-original:'+row['path'])
    inputs[str(path)]=actual
require(sum(r['bytes'] for r in manifest['files'])==manifest['bytes'],'owner-freeze-total')
export=read(Path('source-export/manifest.json'))
require(export['local_commit']==HEAD and export['local_parent']==PARENT and export['local_tree']==TREE,'export-identity')
changed=git('diff','--name-only',PARENT,HEAD).decode().splitlines()
require(set(changed)=={r['repository_path'] for r in export['files']} and len(changed)==10,'export-exact-ten')
for row in export['files']:
    path=Path(row['local_path']);actual=item(path)
    require(all(actual[k]==row[k] for k in ['bytes','mode','sha256','git_blob']),'export-bytes:'+row['repository_path'])
    require(actual['git_blob']==git_rows[row['repository_path']]['git_blob'],'export-tree:'+row['repository_path'])
patch=OWNER/'source-export/source.patch'
require(item(patch)['sha256']==export['patch_sha256'] and item(patch)['bytes']==export['patch_bytes'],'patch-exact-bytes')
# Read the two contracts directly from immutable Git blobs. No selector import,
# test execution, compiler, native program or old oracle is invoked here.
old=json.loads(git('show',PARENT+':docs/HIA_SAFETY_CONTRACT.json'))
new=json.loads(git('show',HEAD+':docs/HIA_SAFETY_CONTRACT.json'))
old_caps={r['id']:r for r in old['capabilities']};new_caps={r['id']:r for r in new['capabilities']}
require(set(old_caps)==set(new_caps) and len(new_caps)==36,'contract-capabilities')
old_sel=[s for c in old['capabilities'] for s in c['regression_selectors']]
new_sel=[s for c in new['capabilities'] for s in c['regression_selectors']]
require(len(set(old_sel))==len(old_sel)==349 and len(set(new_sel))==len(new_sel)==359,'contract-populations')
require(set(old_sel)<=set(new_sel),'contract-no-removal')
for name in old_caps:
    if name!='source_lowering': require(old_caps[name]==new_caps[name],'unchanged-capability:'+name)
for key in old:
    if key!='capabilities': require(old[key]==new[key],'unchanged-contract-top:'+key)
canonical=json.dumps(new,sort_keys=True,separators=(',',':')).encode()
canonical_sha=hashlib.sha256(canonical).hexdigest()
require(canonical_sha=='44c138659e8472a58db069c035d066feaaa5877680dc550b784802fe40ac9e76','contract-canonical-pin')
producer=(ROOT/'tools/qualify_hia_safety_contract.py').read_text()
require(canonical_sha in producer,'qualifier-pin')
summaries={}
for name,count,errors,source_count,rc in [('frozen6b-new10',10,0,1456,0),
                                       ('frozen6b-regressions92',92,3,1456,1),
                                       ('frozen6b-protocol3-retry',3,0,1459,0)]:
    summary=read(Path(name)/'summary.json');summaries[name]=summary
    require(summary['source_head']==HEAD and summary['source_tree']==TREE,'run-source:'+name)
    require(summary['counts']=={'tests':count,'failures':0,'errors':errors,'skips':0,'expected_failures':0,'unexpected_successes':0},'run-counts:'+name)
    require(summary['test_starts']==summary['test_stops'] and len(set(summary['test_starts']))==count,'exact-start-stop:'+name)
    require(len(summary['test_successes'])==count-errors and set(summary['test_successes'])<=set(summary['test_starts']),'ordinary-successes:'+name)
    require(summary['ok']==(rc==0),'original-status:'+name)
    for phase in ['before','after']:
        source=read(Path(name)/('source-'+phase+'.json'))
        require(source['head']==HEAD and source['tree']==TREE and not source['status'],'recorded-source-identity:'+name)
        require(source['full_git_tree_files']==7701 and source['materialized_files']==len(source['files'])==source_count,'recorded-source-population:'+name)
        for path,row in source['files'].items():
            require(row['tracked'] and row['matches_git'],'recorded-source-track:'+path)
            require(all(row[k]==before['files'][path][k] for k in ['bytes','sha256','git_blob','mode']),'recorded-source-byte:'+path)
            require(row['expected_blob']==git_rows[path]['git_blob'] and row['expected_mode']==git_rows[path]['mode'],'recorded-source-tree:'+path)
    require(read(Path(name)/'source-before.json')==read(Path(name)/'source-after.json'),'recorded-source-stable:'+name)
    tools=read(Path(name)/'tools-before.json')
    require(tools==read(Path(name)/'tools-after.json'),'recorded-tools-stable:'+name)
    for label,row in tools.items():
        current=item(Path(row['path']))
        require(all(current[k]==row[k] for k in ['bytes','sha256','git_blob','mode']),'actual-tools:'+label)
    frozen_collector=OWNER/(name+'.collector-used.py')
    require(item(frozen_collector)['sha256']=='1a8dd2f37018d2a40a82bf0b28f887573e104426f56ea591a46c28df2af3c042','collector-frozen:'+name)
    process=read(Path(name+'.process.json'))
    require(process['returncode']==rc and process['collector_stable'],'actual-process:'+name)
    require(process['started_unix']<=summary['started_unix']<summary['finished_unix']<=process['finished_unix'],'process-times:'+name)
    require(process['collector_sha256_before']==process['collector_sha256_after']==summary['producer_before']['sha256']==summary['producer_after']['sha256']==item(frozen_collector)['sha256'],'producer-binding:'+name)
    log=(OWNER/name/'tests.log').read_text()
    require(f'Ran {count} tests' in log and ('FAILED (errors=3)' in log if errors else '\nOK\n' in log),'original-log:'+name)
new10=summaries['frozen6b-new10'];reg=summaries['frozen6b-regressions92'];retry=summaries['frozen6b-protocol3-retry']
require(set(new10['test_starts'])==set(new_sel)-set(old_sel),'new-method-exact-contract')
require(set(reg['test_starts']).isdisjoint(new10['test_starts']),'disjoint-existing-and-new')
missing=set(reg['test_starts'])-set(reg['test_successes'])
require(missing==set(retry['test_starts'])==set(retry['test_successes']) and len(missing)==3,'exact-three-error-retry')
require(len(set(new10['test_successes'])|set(reg['test_successes'])|set(retry['test_successes']))==102,'distinct-success-population')
restore=read(Path('sparse-protocol-inputs-restored.json'))
sparse_before=read(Path('frozen6b-regressions92/source-before.json'))['files']
sparse_after=read(Path('frozen6b-protocol3-retry/source-before.json'))['files']
require(set(sparse_after)-set(sparse_before)=={r['path'] for r in restore['files']} and sum(r['bytes'] for r in restore['files'])==8846,'only-three-materialized-inputs')
require(all('FileNotFoundError' in (OWNER/'frozen6b-regressions92/tests.log').read_text() for _ in [0]),'recorded-missing-file-errors')
core=read(Path('frozen6b-new10/core_programs.json'))
for sha,document in core.items():
    require(hashlib.sha256(json.dumps(document,sort_keys=True,separators=(',',':')).encode()).hexdigest()==sha,'canonical-core-bytes')
rust=read(Path('frozen6b-new10/rust_observations.json'))
require(len(rust)==103,'rust-population')
statuses=Counter()
for row in rust:
    py,rr,process=row['python'],row['rust'],row['rust_process']
    require(process['returncode']==0 and not process['stderr'] and json.loads(process['stdout'])==rr,'rust-original-stdout')
    for key in ['status','steps','resources','function','program_sha256']:
        require(py[key]==rr[key],'full-python-rust-'+key)
    if rr['status']=='returned':
        require(py['values']==rr['values'],'full-python-rust-values')
    else:
        require(rr['status']=='budget_exceeded' and 'values' not in py and 'values' not in rr,'budget-has-no-return-value')
        require(py['error']['code']==rr['error']['code'],'same-budget-error-code')
    require(rr['program_sha256'] in core and rr['function']==row['entry'],'rust-core-and-entry')
    argv=process['argv']
    require(argv[1:3]==['--owned-run',row['entry']] and json.loads(argv[3])==row['arguments'],'rust-original-argv')
    require(int(argv[4])==row['policy']['max_steps'] and int(argv[5])==row['policy']['max_heap_bytes'],'rust-original-limits')
    require(argv[6]==('none' if row['policy']['allocation_fail_at'] is None else str(row['policy']['allocation_fail_at'])),'rust-original-failure-policy')
    ledger=rr['resources']
    require(ledger['owners_created']-ledger['owners_dropped']==ledger['live_owners'],'rust-owner-ledger')
    require(ledger['loans_started']-ledger['loans_ended']==ledger['live_local_loans'],'rust-loan-ledger')
    statuses[rr['status']]+=1
    if rr['status']=='returned':require(all(ledger[k]==0 for k in ['live_owners','live_local_loans','live_bytes']),'returned-cleanup')
require(statuses=={'returned':43,'budget_exceeded':60},'rust-status-denominator')
prefix=[r for r in rust if r['entry']=='mutable_case' and r['arguments']==[2,91,1] and r['policy']['max_steps']<=59]
require(sorted(r['policy']['max_steps'] for r in prefix)==list(range(1,60)),'all-59-prefixes-exact-once')
require([r['rust']['status'] for r in sorted(prefix,key=lambda r:r['policy']['max_steps'])]==['budget_exceeded']*58+['returned'],'prefix-outcomes')
refusals=read(Path('frozen6b-new10/rust_refusals.json'))
core_ref={r['name']:r for r in read(Path('frozen6b-new10/core_refusals.json'))}
require(len(refusals)==len(core_ref)==6,'refusal-populations')
for row in refusals:
    require(json.loads(row['raw'])==core_ref[row['name']]['document'],'raw-refused-document')
    require(row['returncode']!=0 and row['stderr'].startswith('E_HIA_LOAN:'),'raw-rust-specific-refusal')
    require(core_ref[row['name']]['message'].startswith('E_HIA_LOAN:'),'core-specific-refusal')
source_ref=read(Path('frozen6b-new10/source_refusals.json'))
require(len(source_ref)==len({r['name'] for r in source_ref})==14,'source-refusal-population')
require(sum(r['checked_frontend_and_resource_legal'] is True for r in source_ref)==4,'legal-profile-exclusions')
native=read(Path('frozen6b-new10/native.json'))
require(len(native)==1 and len(native[0]['observations'])==35,'native-population')
native=native[0]
for row in native['observations']:
    require(row['actual']==row['expected'],'native-expected-value')
    matches=[r for r in rust if r['entry']==row['entry'] and r['arguments']==row['arguments'] and r['policy']['allocation_fail_at'] is None and r['rust']['status']=='returned']
    require(any(r['python']['values']==[row['actual']] for r in matches),'native-same-core-parity')
alloc=read(Path('frozen6b-new10/native_allocator.json'))
require(len(alloc['observations'])==6 and alloc['link']['returncode']==0,'allocator-population-and-link')
expected=[(15,4,4,8),(113,4,3,8),(61,4,3,8),(109,4,3,6),(50,2,2,10),(41,2,1,3)]
for row,(value,attempts,allocations,peak) in zip(alloc['observations'],expected):
    require(row['returncode']==0 and json.loads(row['stdout'])=={'value':value,'attempts':attempts,'allocations':allocations,'frees':allocations,'live_bytes':0,'peak_bytes':peak},'actual-allocator-cleanup')
    require(row['argv'][1:]==[str(row['failure']),row['entry']],'allocator-argv')
bounded=read(Path('frozen6b-new10/bounded-compiler-processes.json'))
require(len(bounded)==6,'bounded-compiler-population')
for row in bounded:
    require(row['returncode']==0 and row['started_ns']<=row['finished_ns'],'bounded-original-process')
    for entry in row['inputs']+([row['output']] if 'output' in row else []):
        actual=item(OWNER/'frozen6b-new10'/entry['retained_path'])
        require(actual['bytes']==entry['bytes'] and actual['sha256']==entry['sha256'],'retained-compiler-bytes')
for receipt,index,name in [(native['receipt'],2,'native/direct-llvm/nested-returned-views.so'),
                           (alloc['object_receipt'],5,'native/allocator/core.o')]:
    artifact=item(OWNER/'frozen6b-new10'/name)
    require(receipt['ok'] and receipt['core_sha256'] in core,'native-reverified-core')
    require(artifact['bytes']==receipt['artifact_bytes'] and artifact['sha256']==receipt['artifact_sha256']==bounded[index]['output']['sha256'],'native-original-artifact')
    require(receipt['llvm_ir_sha256']==bounded[index]['inputs'][0]['sha256'],'native-original-ir')
    require(receipt['claims']['c_codegen_used'] is False and receipt['claims']['rust_codegen_used'] is False and receipt['claims']['fallback_used'] is False,'no-hidden-backend')
require((OWNER/'frozen6b-new10/native/allocator/observer.c').read_text()==alloc['observer'],'retained-observer-source')
owner=read(Path('owner-summary.json'))
require(owner['ok'] and owner['method_attempts']==105 and owner['distinct_methods_with_an_ordinary_success']==102,'owner-honest-population')
require(not owner['full359_executed'] and not owner['public_execution'] and owner['strict_blockers_closed']==0,'owner-qualified-scope')
require(owner['python_production_authority'] and not owner['rust_production_authority'] and owner['optimization_policy']=='no_change','authority-and-policy')
after,_=snapshot()
require(after==before,'audit-source-stable')
for path,expected in inputs.items():
    require(item(Path(path))==expected,'audit-original-stable:'+path)
report={'schema':'hepta.independent-nested-owner-review.v1','ok':True,
        'source_head':HEAD,'source_tree':TREE,'source_parent':PARENT,'public_execution':False,
        'started_unix':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
        'read_only_checks':sum(checks.values()),'checks_by_kind':dict(checks),
        'owner_frozen_originals':132,'owner_frozen_original_bytes':5437150,
        'source_identity_scope':{'full_git_tree_files':7701,'owner_focused_materialized_files':1456,
                                 'after_precise_three_input_restore':1459,'full_tree_execution_claimed':False},
        'owner_method_attempts':105,'owner_distinct_methods_with_success':102,
        'original92_batch_pass':False,'first_regression_batch':{'successes':89,'errors':3},
        'exact_failed_methods_retried':3,'new_methods':10,'contract':{'before':349,'after':359,'capabilities':36,'all359_executed':False},
        'rust':{'records':103,'statuses':dict(statuses),'raw_refusals':6,'prefixes':59},
        'llvm_calls':35,'allocator_calls':6,'bounded_compiler_records':6,
        'source_refusals':14,'core_refusals':6,
        'independent_audit_replayed_tests_native_or_oracles':0,
        'additional_independent_controls':'Separate parent-red/candidate-green/native-continuation original records; reviewer-authored, not claimed as an independent review of the reviewer.',
        'python_production_authority':True,'rust_production_authority':False,'optimization_policy':'no_change',
        'whole_language_soundness_proved':False,'backend_refinement_proved':False,'strict_blockers_closed':0}
(OUT/'owner-review.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
(OUT/'owner-review-inputs.json').write_text(json.dumps({'schema':'hepta.independent-review-inputs.v1','files':[{'path':path,**row} for path,row in sorted(inputs.items())]},sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['ok','read_only_checks','owner_method_attempts','owner_distinct_methods_with_success']}))
