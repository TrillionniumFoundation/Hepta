
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void*);
static void *addresses[16]; static size_t sizes[16], attempts, allocations, frees, live, peak, fail;
static void *remember(void *p,size_t n) {
  if (!p) return p; size_t i=0; while(i<16 && addresses[i]) ++i; if(i==16) exit(81);
  addresses[i]=p; sizes[i]=n; allocations++; live+=n; if(live>peak) peak=live; return p;
}
void *__wrap_malloc(size_t n) { attempts++; return attempts==fail?NULL:remember(__real_malloc(n),n); }
void *__wrap_calloc(size_t n,size_t s) { attempts++; return attempts==fail?NULL:remember(__real_calloc(n,s),n*s); }
void __wrap_free(void *p) {
  size_t i=0; while(i<16 && addresses[i]!=p) ++i; if(!p || i==16) exit(82);
  live-=sizes[i]; addresses[i]=NULL; frees++; __real_free(p);
}
extern uint64_t probe(uint8_t);
int main(int argc,char **argv) {
  if(argc!=3) return 83; fail=strtoull(argv[2],NULL,10);
  uint64_t value=probe((uint8_t)strtoul(argv[1],NULL,10));
  printf("{\"value\":%llu,\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,\"live_bytes\":%zu,\"peak_bytes\":%zu}\n",
    (unsigned long long)value,attempts,allocations,frees,live,peak);
  return live?84:0;
}
