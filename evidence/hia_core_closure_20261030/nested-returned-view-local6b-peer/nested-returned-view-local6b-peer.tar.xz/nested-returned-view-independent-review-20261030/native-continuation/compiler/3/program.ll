; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
%hia.chain.node = type { %hia.buffer, ptr }
%hia.chain.result = type { ptr, %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}


; v7 inductive owner: Nil | Node(buffer payload, chain tail).
; No raw pointer constructor is admitted. push consumes both input owners.
; Its failure returns both unchanged, while success returns an empty fallback.
define internal %hia.chain.result @__hia_chain_push(ptr %tail, %hia.buffer %payload) {
entry:
  %node = call ptr @malloc(i64 24) nobuiltin
  %ok = icmp ne ptr %node, null
  br i1 %ok, label %ready, label %failed
ready:
  store %hia.buffer %payload, ptr %node, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %node, i32 0, i32 1
  store ptr %tail, ptr %tail_slot, align 8
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %node, 0
  %r1 = insertvalue %hia.chain.result %r0, i1 true, 2
  ret %hia.chain.result %r1
failed:
  %f0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %f1 = insertvalue %hia.chain.result %f0, %hia.buffer %payload, 1
  ret %hia.chain.result %f1
}

; Empty pop returns Nil, an empty payload owner, and false. Nonempty pop
; deallocates exactly the header and transfers payload/tail ownership out.
define internal %hia.chain.result @__hia_chain_pop(ptr %head) {
entry:
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %none, label %some
none:
  ret %hia.chain.result zeroinitializer
some:
  %payload = load %hia.buffer, ptr %head, align 8
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  call void @free(ptr %head) nobuiltin
  %r0 = insertvalue %hia.chain.result zeroinitializer, ptr %tail, 0
  %r1 = insertvalue %hia.chain.result %r0, %hia.buffer %payload, 1
  %r2 = insertvalue %hia.chain.result %r1, i1 true, 2
  ret %hia.chain.result %r2
}

; Explicit loop bounds native stack usage independently of recursive length.
; Every nonempty payload and node receives one real free; empty payloads do not.
define internal void @__hia_chain_drop(ptr %initial) {
entry:
  br label %loop
loop:
  %head = phi ptr [ %initial, %entry ], [ %tail, %release_node ]
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %read_node
read_node:
  %payload = load %hia.buffer, ptr %head, align 8
  %payload_ptr = extractvalue %hia.buffer %payload, 0
  %tail_slot = getelementptr %hia.chain.node, ptr %head, i32 0, i32 1
  %tail = load ptr, ptr %tail_slot, align 8
  %has_payload = icmp ne ptr %payload_ptr, null
  br i1 %has_payload, label %release_payload, label %release_node
release_payload:
  call void @free(ptr %payload_ptr) nobuiltin
  br label %release_node
release_node:
  call void @free(ptr %head) nobuiltin
  br label %loop
done:
  ret void
}
define internal i1 @__hia_fn_0(i64 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i1 [ %t3, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_3 = phi i8 [ 1, %edge_0 ]
  %t6 = extractvalue %hia.buffer %p_1_2, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  call void @free(ptr %t6) nobuiltin
  br label %drop_after_8
drop_after_8:
  ret i1 true
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i1 [ %t3, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_3 = phi i8 [ 1, %edge_1 ]
  %t9 = extractvalue %hia.buffer %p_2_2, 0
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %drop_nonnull_11, label %drop_after_11
drop_nonnull_11:
  call void @free(ptr %t9) nobuiltin
  br label %drop_after_11
drop_after_11:
  ret i1 false
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal %hia.buffer @__hia_fn_1(i1 %p_0_0, %hia.buffer %p_0_1, i1 %p_0_2, i8 %p_0_3, i8 %p_0_4) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i8 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i8 [ %p_0_4, %edge_0 ]
  %t1 = extractvalue %hia.buffer %p_1_1, 0
  %t2 = extractvalue %hia.buffer %p_1_1, 1
  %t3 = icmp ult i64 0, %t2
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = getelementptr i8, ptr %t1, i64 0
  %t6 = load i8, ptr %t5, align 1
  %t7 = add i8 %t6, %p_1_3
  %t8 = extractvalue %hia.buffer %p_1_1, 0
  %t9 = extractvalue %hia.buffer %p_1_1, 1
  %t10 = icmp ult i64 0, %t9
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  %t12 = getelementptr i8, ptr %t8, i64 0
  store i8 %t7, ptr %t12, align 1
  br label %edge_2
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i8 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i8 [ %p_0_4, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi i1 [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i1 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i8 [ %p_1_3, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i8 [ %p_1_4, %edge_2 ], [ %p_2_4, %edge_3 ]
  br i1 %p_3_2, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i1 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi %hia.buffer [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i1 [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i8 [ %p_3_3, %edge_4 ]
  %p_4_4 = phi i8 [ %p_3_4, %edge_4 ]
  %t13 = extractvalue %hia.buffer %p_4_1, 0
  %t14 = extractvalue %hia.buffer %p_4_1, 1
  %t15 = icmp ult i64 0, %t14
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  %t17 = getelementptr i8, ptr %t13, i64 0
  %t18 = load i8, ptr %t17, align 1
  %t19 = add i8 %t18, %p_4_4
  %t20 = extractvalue %hia.buffer %p_4_1, 0
  %t21 = extractvalue %hia.buffer %p_4_1, 1
  %t22 = icmp ult i64 0, %t21
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  %t24 = getelementptr i8, ptr %t20, i64 0
  store i8 %t19, ptr %t24, align 1
  br label %edge_6
b5:
  %p_5_0 = phi i1 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi %hia.buffer [ %p_3_1, %edge_5 ]
  %p_5_2 = phi i1 [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i8 [ %p_3_3, %edge_5 ]
  %p_5_4 = phi i8 [ %p_3_4, %edge_5 ]
  br label %edge_7
b6:
  %p_6_0 = phi i1 [ %p_4_0, %edge_6 ], [ %p_5_0, %edge_7 ]
  %p_6_1 = phi %hia.buffer [ %p_4_1, %edge_6 ], [ %p_5_1, %edge_7 ]
  %p_6_2 = phi i1 [ %p_4_2, %edge_6 ], [ %p_5_2, %edge_7 ]
  %p_6_3 = phi i8 [ %p_4_3, %edge_6 ], [ %p_5_3, %edge_7 ]
  %p_6_4 = phi i8 [ %p_4_4, %edge_6 ], [ %p_5_4, %edge_7 ]
  ret %hia.buffer %p_6_1
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b6
}

define internal i64 @__hia_fn_2(i8 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 1, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 1, 1
  %t6 = extractvalue %hia.buffer %t5, 0
  %t7 = extractvalue %hia.buffer %t5, 1
  %t8 = icmp ult i64 0, %t7
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = getelementptr i8, ptr %t6, i64 0
  store i8 0, ptr %t10, align 1
  %t11 = icmp ne i8 %p_0_0, 0
  br i1 %t11, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_2 = phi i8 [ %p_0_0, %edge_0 ]
  %p_1_3 = phi i8 [ 0, %edge_0 ]
  %p_1_4 = phi i1 [ %t11, %edge_0 ]
  %p_1_5 = phi i1 [ %t11, %edge_0 ]
  %t12 = call i1 @__hia_fn_0(i64 2)
  br label %edge_2
b2:
  %p_2_0 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_2 = phi i8 [ %p_0_0, %edge_1 ]
  %p_2_3 = phi i8 [ 0, %edge_1 ]
  %p_2_4 = phi i1 [ %t11, %edge_1 ]
  %p_2_5 = phi i1 [ %t11, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi i8 [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi %hia.buffer [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i8 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i8 [ %p_1_3, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i1 [ %p_1_4, %edge_2 ], [ %p_2_4, %edge_3 ]
  %p_3_5 = phi i1 [ %t12, %edge_2 ], [ %p_2_4, %edge_3 ]
  %t13 = icmp ne i8 %p_3_0, 0
  br i1 %t13, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i8 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi %hia.buffer [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i8 [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i8 [ %p_3_3, %edge_4 ]
  %p_4_4 = phi i1 [ %p_3_4, %edge_4 ]
  %p_4_5 = phi i1 [ %p_3_5, %edge_4 ]
  %p_4_6 = phi i8 [ %p_3_0, %edge_4 ]
  %p_4_7 = phi i8 [ 0, %edge_4 ]
  %p_4_8 = phi i1 [ %t13, %edge_4 ]
  %p_4_9 = phi i1 [ %t13, %edge_4 ]
  %t14 = call i1 @__hia_fn_0(i64 3)
  br label %edge_6
b5:
  %p_5_0 = phi i8 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi %hia.buffer [ %p_3_1, %edge_5 ]
  %p_5_2 = phi i8 [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i8 [ %p_3_3, %edge_5 ]
  %p_5_4 = phi i1 [ %p_3_4, %edge_5 ]
  %p_5_5 = phi i1 [ %p_3_5, %edge_5 ]
  %p_5_6 = phi i8 [ %p_3_0, %edge_5 ]
  %p_5_7 = phi i8 [ 0, %edge_5 ]
  %p_5_8 = phi i1 [ %t13, %edge_5 ]
  %p_5_9 = phi i1 [ %t13, %edge_5 ]
  br label %edge_7
b6:
  %p_6_0 = phi i8 [ %p_4_0, %edge_6 ], [ %p_5_0, %edge_7 ]
  %p_6_1 = phi %hia.buffer [ %p_4_1, %edge_6 ], [ %p_5_1, %edge_7 ]
  %p_6_2 = phi i8 [ %p_4_2, %edge_6 ], [ %p_5_2, %edge_7 ]
  %p_6_3 = phi i8 [ %p_4_3, %edge_6 ], [ %p_5_3, %edge_7 ]
  %p_6_4 = phi i1 [ %p_4_4, %edge_6 ], [ %p_5_4, %edge_7 ]
  %p_6_5 = phi i1 [ %p_4_5, %edge_6 ], [ %p_5_5, %edge_7 ]
  %p_6_6 = phi i8 [ %p_4_6, %edge_6 ], [ %p_5_6, %edge_7 ]
  %p_6_7 = phi i8 [ %p_4_7, %edge_6 ], [ %p_5_7, %edge_7 ]
  %p_6_8 = phi i1 [ %p_4_8, %edge_6 ], [ %p_5_8, %edge_7 ]
  %p_6_9 = phi i1 [ %t14, %edge_6 ], [ %p_5_8, %edge_7 ]
  %t15 = icmp ne i8 %p_6_0, 0
  br i1 %t15, label %edge_8, label %edge_9
b7:
  %p_7_0 = phi i8 [ %p_6_0, %edge_8 ]
  %p_7_1 = phi %hia.buffer [ %p_6_1, %edge_8 ]
  %p_7_2 = phi i8 [ %p_6_2, %edge_8 ]
  %p_7_3 = phi i8 [ %p_6_3, %edge_8 ]
  %p_7_4 = phi i1 [ %p_6_4, %edge_8 ]
  %p_7_5 = phi i1 [ %p_6_5, %edge_8 ]
  %p_7_6 = phi i8 [ %p_6_6, %edge_8 ]
  %p_7_7 = phi i8 [ %p_6_7, %edge_8 ]
  %p_7_8 = phi i1 [ %p_6_8, %edge_8 ]
  %p_7_9 = phi i1 [ %p_6_9, %edge_8 ]
  %p_7_10 = phi i8 [ %p_6_0, %edge_8 ]
  %p_7_11 = phi i8 [ 0, %edge_8 ]
  %p_7_12 = phi i1 [ %t15, %edge_8 ]
  %p_7_13 = phi i1 [ %t15, %edge_8 ]
  %t16 = call i1 @__hia_fn_0(i64 4)
  br label %edge_10
b8:
  %p_8_0 = phi i8 [ %p_6_0, %edge_9 ]
  %p_8_1 = phi %hia.buffer [ %p_6_1, %edge_9 ]
  %p_8_2 = phi i8 [ %p_6_2, %edge_9 ]
  %p_8_3 = phi i8 [ %p_6_3, %edge_9 ]
  %p_8_4 = phi i1 [ %p_6_4, %edge_9 ]
  %p_8_5 = phi i1 [ %p_6_5, %edge_9 ]
  %p_8_6 = phi i8 [ %p_6_6, %edge_9 ]
  %p_8_7 = phi i8 [ %p_6_7, %edge_9 ]
  %p_8_8 = phi i1 [ %p_6_8, %edge_9 ]
  %p_8_9 = phi i1 [ %p_6_9, %edge_9 ]
  %p_8_10 = phi i8 [ %p_6_0, %edge_9 ]
  %p_8_11 = phi i8 [ 0, %edge_9 ]
  %p_8_12 = phi i1 [ %t15, %edge_9 ]
  %p_8_13 = phi i1 [ %t15, %edge_9 ]
  br label %edge_11
b9:
  %p_9_0 = phi i8 [ %p_7_0, %edge_10 ], [ %p_8_0, %edge_11 ]
  %p_9_1 = phi %hia.buffer [ %p_7_1, %edge_10 ], [ %p_8_1, %edge_11 ]
  %p_9_2 = phi i8 [ %p_7_2, %edge_10 ], [ %p_8_2, %edge_11 ]
  %p_9_3 = phi i8 [ %p_7_3, %edge_10 ], [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i1 [ %p_7_4, %edge_10 ], [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i1 [ %p_7_5, %edge_10 ], [ %p_8_5, %edge_11 ]
  %p_9_6 = phi i8 [ %p_7_6, %edge_10 ], [ %p_8_6, %edge_11 ]
  %p_9_7 = phi i8 [ %p_7_7, %edge_10 ], [ %p_8_7, %edge_11 ]
  %p_9_8 = phi i1 [ %p_7_8, %edge_10 ], [ %p_8_8, %edge_11 ]
  %p_9_9 = phi i1 [ %p_7_9, %edge_10 ], [ %p_8_9, %edge_11 ]
  %p_9_10 = phi i8 [ %p_7_10, %edge_10 ], [ %p_8_10, %edge_11 ]
  %p_9_11 = phi i8 [ %p_7_11, %edge_10 ], [ %p_8_11, %edge_11 ]
  %p_9_12 = phi i1 [ %p_7_12, %edge_10 ], [ %p_8_12, %edge_11 ]
  %p_9_13 = phi i1 [ %t16, %edge_10 ], [ %p_8_12, %edge_11 ]
  %t17 = icmp ne i8 %p_9_0, 0
  br i1 %t17, label %edge_12, label %edge_13
b10:
  %p_10_0 = phi i8 [ %p_9_0, %edge_12 ]
  %p_10_1 = phi %hia.buffer [ %p_9_1, %edge_12 ]
  %p_10_2 = phi i8 [ %p_9_2, %edge_12 ]
  %p_10_3 = phi i8 [ %p_9_3, %edge_12 ]
  %p_10_4 = phi i1 [ %p_9_4, %edge_12 ]
  %p_10_5 = phi i1 [ %p_9_5, %edge_12 ]
  %p_10_6 = phi i8 [ %p_9_6, %edge_12 ]
  %p_10_7 = phi i8 [ %p_9_7, %edge_12 ]
  %p_10_8 = phi i1 [ %p_9_8, %edge_12 ]
  %p_10_9 = phi i1 [ %p_9_9, %edge_12 ]
  %p_10_10 = phi i8 [ %p_9_10, %edge_12 ]
  %p_10_11 = phi i8 [ %p_9_11, %edge_12 ]
  %p_10_12 = phi i1 [ %p_9_12, %edge_12 ]
  %p_10_13 = phi i1 [ %p_9_13, %edge_12 ]
  %p_10_14 = phi i8 [ %p_9_0, %edge_12 ]
  %p_10_15 = phi i8 [ 0, %edge_12 ]
  %p_10_16 = phi i1 [ %t17, %edge_12 ]
  %p_10_17 = phi i1 [ %t17, %edge_12 ]
  %t18 = call i1 @__hia_fn_0(i64 5)
  br label %edge_14
b11:
  %p_11_0 = phi i8 [ %p_9_0, %edge_13 ]
  %p_11_1 = phi %hia.buffer [ %p_9_1, %edge_13 ]
  %p_11_2 = phi i8 [ %p_9_2, %edge_13 ]
  %p_11_3 = phi i8 [ %p_9_3, %edge_13 ]
  %p_11_4 = phi i1 [ %p_9_4, %edge_13 ]
  %p_11_5 = phi i1 [ %p_9_5, %edge_13 ]
  %p_11_6 = phi i8 [ %p_9_6, %edge_13 ]
  %p_11_7 = phi i8 [ %p_9_7, %edge_13 ]
  %p_11_8 = phi i1 [ %p_9_8, %edge_13 ]
  %p_11_9 = phi i1 [ %p_9_9, %edge_13 ]
  %p_11_10 = phi i8 [ %p_9_10, %edge_13 ]
  %p_11_11 = phi i8 [ %p_9_11, %edge_13 ]
  %p_11_12 = phi i1 [ %p_9_12, %edge_13 ]
  %p_11_13 = phi i1 [ %p_9_13, %edge_13 ]
  %p_11_14 = phi i8 [ %p_9_0, %edge_13 ]
  %p_11_15 = phi i8 [ 0, %edge_13 ]
  %p_11_16 = phi i1 [ %t17, %edge_13 ]
  %p_11_17 = phi i1 [ %t17, %edge_13 ]
  br label %edge_15
b12:
  %p_12_0 = phi i8 [ %p_10_0, %edge_14 ], [ %p_11_0, %edge_15 ]
  %p_12_1 = phi %hia.buffer [ %p_10_1, %edge_14 ], [ %p_11_1, %edge_15 ]
  %p_12_2 = phi i8 [ %p_10_2, %edge_14 ], [ %p_11_2, %edge_15 ]
  %p_12_3 = phi i8 [ %p_10_3, %edge_14 ], [ %p_11_3, %edge_15 ]
  %p_12_4 = phi i1 [ %p_10_4, %edge_14 ], [ %p_11_4, %edge_15 ]
  %p_12_5 = phi i1 [ %p_10_5, %edge_14 ], [ %p_11_5, %edge_15 ]
  %p_12_6 = phi i8 [ %p_10_6, %edge_14 ], [ %p_11_6, %edge_15 ]
  %p_12_7 = phi i8 [ %p_10_7, %edge_14 ], [ %p_11_7, %edge_15 ]
  %p_12_8 = phi i1 [ %p_10_8, %edge_14 ], [ %p_11_8, %edge_15 ]
  %p_12_9 = phi i1 [ %p_10_9, %edge_14 ], [ %p_11_9, %edge_15 ]
  %p_12_10 = phi i8 [ %p_10_10, %edge_14 ], [ %p_11_10, %edge_15 ]
  %p_12_11 = phi i8 [ %p_10_11, %edge_14 ], [ %p_11_11, %edge_15 ]
  %p_12_12 = phi i1 [ %p_10_12, %edge_14 ], [ %p_11_12, %edge_15 ]
  %p_12_13 = phi i1 [ %p_10_13, %edge_14 ], [ %p_11_13, %edge_15 ]
  %p_12_14 = phi i8 [ %p_10_14, %edge_14 ], [ %p_11_14, %edge_15 ]
  %p_12_15 = phi i8 [ %p_10_15, %edge_14 ], [ %p_11_15, %edge_15 ]
  %p_12_16 = phi i1 [ %p_10_16, %edge_14 ], [ %p_11_16, %edge_15 ]
  %p_12_17 = phi i1 [ %t18, %edge_14 ], [ %p_11_16, %edge_15 ]
  %t19 = icmp eq i8 %p_12_0, 0
  br i1 %t19, label %edge_16, label %edge_17
b13:
  %p_13_0 = phi i8 [ %p_12_0, %edge_17 ]
  %p_13_1 = phi %hia.buffer [ %p_12_1, %edge_17 ]
  %p_13_2 = phi i8 [ %p_12_2, %edge_17 ]
  %p_13_3 = phi i8 [ %p_12_3, %edge_17 ]
  %p_13_4 = phi i1 [ %p_12_4, %edge_17 ]
  %p_13_5 = phi i1 [ %p_12_5, %edge_17 ]
  %p_13_6 = phi i8 [ %p_12_6, %edge_17 ]
  %p_13_7 = phi i8 [ %p_12_7, %edge_17 ]
  %p_13_8 = phi i1 [ %p_12_8, %edge_17 ]
  %p_13_9 = phi i1 [ %p_12_9, %edge_17 ]
  %p_13_10 = phi i8 [ %p_12_10, %edge_17 ]
  %p_13_11 = phi i8 [ %p_12_11, %edge_17 ]
  %p_13_12 = phi i1 [ %p_12_12, %edge_17 ]
  %p_13_13 = phi i1 [ %p_12_13, %edge_17 ]
  %p_13_14 = phi i8 [ %p_12_14, %edge_17 ]
  %p_13_15 = phi i8 [ %p_12_15, %edge_17 ]
  %p_13_16 = phi i1 [ %p_12_16, %edge_17 ]
  %p_13_17 = phi i1 [ %p_12_17, %edge_17 ]
  %p_13_18 = phi %hia.buffer [ %p_12_1, %edge_17 ]
  %p_13_19 = phi i8 [ %p_12_0, %edge_17 ]
  %p_13_20 = phi i8 [ 0, %edge_17 ]
  %p_13_21 = phi i1 [ %t19, %edge_17 ]
  %p_13_22 = phi i1 [ %t19, %edge_17 ]
  %t20 = call i1 @__hia_fn_0(i64 6)
  br label %edge_18
b14:
  %p_14_0 = phi i8 [ %p_12_0, %edge_16 ]
  %p_14_1 = phi %hia.buffer [ %p_12_1, %edge_16 ]
  %p_14_2 = phi i8 [ %p_12_2, %edge_16 ]
  %p_14_3 = phi i8 [ %p_12_3, %edge_16 ]
  %p_14_4 = phi i1 [ %p_12_4, %edge_16 ]
  %p_14_5 = phi i1 [ %p_12_5, %edge_16 ]
  %p_14_6 = phi i8 [ %p_12_6, %edge_16 ]
  %p_14_7 = phi i8 [ %p_12_7, %edge_16 ]
  %p_14_8 = phi i1 [ %p_12_8, %edge_16 ]
  %p_14_9 = phi i1 [ %p_12_9, %edge_16 ]
  %p_14_10 = phi i8 [ %p_12_10, %edge_16 ]
  %p_14_11 = phi i8 [ %p_12_11, %edge_16 ]
  %p_14_12 = phi i1 [ %p_12_12, %edge_16 ]
  %p_14_13 = phi i1 [ %p_12_13, %edge_16 ]
  %p_14_14 = phi i8 [ %p_12_14, %edge_16 ]
  %p_14_15 = phi i8 [ %p_12_15, %edge_16 ]
  %p_14_16 = phi i1 [ %p_12_16, %edge_16 ]
  %p_14_17 = phi i1 [ %p_12_17, %edge_16 ]
  %p_14_18 = phi %hia.buffer [ %p_12_1, %edge_16 ]
  %p_14_19 = phi i8 [ %p_12_0, %edge_16 ]
  %p_14_20 = phi i8 [ 0, %edge_16 ]
  %p_14_21 = phi i1 [ %t19, %edge_16 ]
  %p_14_22 = phi i1 [ %t19, %edge_16 ]
  br label %edge_19
b15:
  %p_15_0 = phi i8 [ %p_13_0, %edge_18 ], [ %p_14_0, %edge_19 ]
  %p_15_1 = phi %hia.buffer [ %p_13_1, %edge_18 ], [ %p_14_1, %edge_19 ]
  %p_15_2 = phi i8 [ %p_13_2, %edge_18 ], [ %p_14_2, %edge_19 ]
  %p_15_3 = phi i8 [ %p_13_3, %edge_18 ], [ %p_14_3, %edge_19 ]
  %p_15_4 = phi i1 [ %p_13_4, %edge_18 ], [ %p_14_4, %edge_19 ]
  %p_15_5 = phi i1 [ %p_13_5, %edge_18 ], [ %p_14_5, %edge_19 ]
  %p_15_6 = phi i8 [ %p_13_6, %edge_18 ], [ %p_14_6, %edge_19 ]
  %p_15_7 = phi i8 [ %p_13_7, %edge_18 ], [ %p_14_7, %edge_19 ]
  %p_15_8 = phi i1 [ %p_13_8, %edge_18 ], [ %p_14_8, %edge_19 ]
  %p_15_9 = phi i1 [ %p_13_9, %edge_18 ], [ %p_14_9, %edge_19 ]
  %p_15_10 = phi i8 [ %p_13_10, %edge_18 ], [ %p_14_10, %edge_19 ]
  %p_15_11 = phi i8 [ %p_13_11, %edge_18 ], [ %p_14_11, %edge_19 ]
  %p_15_12 = phi i1 [ %p_13_12, %edge_18 ], [ %p_14_12, %edge_19 ]
  %p_15_13 = phi i1 [ %p_13_13, %edge_18 ], [ %p_14_13, %edge_19 ]
  %p_15_14 = phi i8 [ %p_13_14, %edge_18 ], [ %p_14_14, %edge_19 ]
  %p_15_15 = phi i8 [ %p_13_15, %edge_18 ], [ %p_14_15, %edge_19 ]
  %p_15_16 = phi i1 [ %p_13_16, %edge_18 ], [ %p_14_16, %edge_19 ]
  %p_15_17 = phi i1 [ %p_13_17, %edge_18 ], [ %p_14_17, %edge_19 ]
  %p_15_18 = phi %hia.buffer [ %p_13_18, %edge_18 ], [ %p_14_18, %edge_19 ]
  %p_15_19 = phi i8 [ %p_13_19, %edge_18 ], [ %p_14_19, %edge_19 ]
  %p_15_20 = phi i8 [ %p_13_20, %edge_18 ], [ %p_14_20, %edge_19 ]
  %p_15_21 = phi i1 [ %p_13_21, %edge_18 ], [ %p_14_21, %edge_19 ]
  %p_15_22 = phi i1 [ %t20, %edge_18 ], [ %p_14_21, %edge_19 ]
  %t21 = call %hia.buffer @__hia_fn_1(i1 %p_15_17, %hia.buffer %p_15_18, i1 %p_15_22, i8 64, i8 128)
  %t22 = icmp eq i8 %p_15_0, 0
  br i1 %t22, label %edge_20, label %edge_21
b16:
  %p_16_0 = phi i8 [ %p_15_0, %edge_21 ]
  %p_16_1 = phi %hia.buffer [ %p_15_1, %edge_21 ]
  %p_16_2 = phi i8 [ %p_15_2, %edge_21 ]
  %p_16_3 = phi i8 [ %p_15_3, %edge_21 ]
  %p_16_4 = phi i1 [ %p_15_4, %edge_21 ]
  %p_16_5 = phi i1 [ %p_15_5, %edge_21 ]
  %p_16_6 = phi i8 [ %p_15_6, %edge_21 ]
  %p_16_7 = phi i8 [ %p_15_7, %edge_21 ]
  %p_16_8 = phi i1 [ %p_15_8, %edge_21 ]
  %p_16_9 = phi i1 [ %p_15_9, %edge_21 ]
  %p_16_10 = phi i8 [ %p_15_10, %edge_21 ]
  %p_16_11 = phi i8 [ %p_15_11, %edge_21 ]
  %p_16_12 = phi i1 [ %p_15_12, %edge_21 ]
  %p_16_13 = phi i1 [ %p_15_13, %edge_21 ]
  %p_16_14 = phi i8 [ %p_15_14, %edge_21 ]
  %p_16_15 = phi i8 [ %p_15_15, %edge_21 ]
  %p_16_16 = phi i1 [ %p_15_16, %edge_21 ]
  %p_16_17 = phi i1 [ %p_15_17, %edge_21 ]
  %p_16_18 = phi %hia.buffer [ %p_15_18, %edge_21 ]
  %p_16_19 = phi i8 [ %p_15_19, %edge_21 ]
  %p_16_20 = phi i8 [ %p_15_20, %edge_21 ]
  %p_16_21 = phi i1 [ %p_15_21, %edge_21 ]
  %p_16_22 = phi i1 [ %p_15_22, %edge_21 ]
  %p_16_23 = phi i8 [ 64, %edge_21 ]
  %p_16_24 = phi i8 [ 128, %edge_21 ]
  %p_16_25 = phi %hia.buffer [ %t21, %edge_21 ]
  %p_16_26 = phi i8 [ %p_15_0, %edge_21 ]
  %p_16_27 = phi i8 [ 0, %edge_21 ]
  %p_16_28 = phi i1 [ %t22, %edge_21 ]
  %p_16_29 = phi i1 [ %t22, %edge_21 ]
  %t23 = call i1 @__hia_fn_0(i64 7)
  br label %edge_22
b17:
  %p_17_0 = phi i8 [ %p_15_0, %edge_20 ]
  %p_17_1 = phi %hia.buffer [ %p_15_1, %edge_20 ]
  %p_17_2 = phi i8 [ %p_15_2, %edge_20 ]
  %p_17_3 = phi i8 [ %p_15_3, %edge_20 ]
  %p_17_4 = phi i1 [ %p_15_4, %edge_20 ]
  %p_17_5 = phi i1 [ %p_15_5, %edge_20 ]
  %p_17_6 = phi i8 [ %p_15_6, %edge_20 ]
  %p_17_7 = phi i8 [ %p_15_7, %edge_20 ]
  %p_17_8 = phi i1 [ %p_15_8, %edge_20 ]
  %p_17_9 = phi i1 [ %p_15_9, %edge_20 ]
  %p_17_10 = phi i8 [ %p_15_10, %edge_20 ]
  %p_17_11 = phi i8 [ %p_15_11, %edge_20 ]
  %p_17_12 = phi i1 [ %p_15_12, %edge_20 ]
  %p_17_13 = phi i1 [ %p_15_13, %edge_20 ]
  %p_17_14 = phi i8 [ %p_15_14, %edge_20 ]
  %p_17_15 = phi i8 [ %p_15_15, %edge_20 ]
  %p_17_16 = phi i1 [ %p_15_16, %edge_20 ]
  %p_17_17 = phi i1 [ %p_15_17, %edge_20 ]
  %p_17_18 = phi %hia.buffer [ %p_15_18, %edge_20 ]
  %p_17_19 = phi i8 [ %p_15_19, %edge_20 ]
  %p_17_20 = phi i8 [ %p_15_20, %edge_20 ]
  %p_17_21 = phi i1 [ %p_15_21, %edge_20 ]
  %p_17_22 = phi i1 [ %p_15_22, %edge_20 ]
  %p_17_23 = phi i8 [ 64, %edge_20 ]
  %p_17_24 = phi i8 [ 128, %edge_20 ]
  %p_17_25 = phi %hia.buffer [ %t21, %edge_20 ]
  %p_17_26 = phi i8 [ %p_15_0, %edge_20 ]
  %p_17_27 = phi i8 [ 0, %edge_20 ]
  %p_17_28 = phi i1 [ %t22, %edge_20 ]
  %p_17_29 = phi i1 [ %t22, %edge_20 ]
  br label %edge_23
b18:
  %p_18_0 = phi i8 [ %p_16_0, %edge_22 ], [ %p_17_0, %edge_23 ]
  %p_18_1 = phi %hia.buffer [ %p_16_1, %edge_22 ], [ %p_17_1, %edge_23 ]
  %p_18_2 = phi i8 [ %p_16_2, %edge_22 ], [ %p_17_2, %edge_23 ]
  %p_18_3 = phi i8 [ %p_16_3, %edge_22 ], [ %p_17_3, %edge_23 ]
  %p_18_4 = phi i1 [ %p_16_4, %edge_22 ], [ %p_17_4, %edge_23 ]
  %p_18_5 = phi i1 [ %p_16_5, %edge_22 ], [ %p_17_5, %edge_23 ]
  %p_18_6 = phi i8 [ %p_16_6, %edge_22 ], [ %p_17_6, %edge_23 ]
  %p_18_7 = phi i8 [ %p_16_7, %edge_22 ], [ %p_17_7, %edge_23 ]
  %p_18_8 = phi i1 [ %p_16_8, %edge_22 ], [ %p_17_8, %edge_23 ]
  %p_18_9 = phi i1 [ %p_16_9, %edge_22 ], [ %p_17_9, %edge_23 ]
  %p_18_10 = phi i8 [ %p_16_10, %edge_22 ], [ %p_17_10, %edge_23 ]
  %p_18_11 = phi i8 [ %p_16_11, %edge_22 ], [ %p_17_11, %edge_23 ]
  %p_18_12 = phi i1 [ %p_16_12, %edge_22 ], [ %p_17_12, %edge_23 ]
  %p_18_13 = phi i1 [ %p_16_13, %edge_22 ], [ %p_17_13, %edge_23 ]
  %p_18_14 = phi i8 [ %p_16_14, %edge_22 ], [ %p_17_14, %edge_23 ]
  %p_18_15 = phi i8 [ %p_16_15, %edge_22 ], [ %p_17_15, %edge_23 ]
  %p_18_16 = phi i1 [ %p_16_16, %edge_22 ], [ %p_17_16, %edge_23 ]
  %p_18_17 = phi i1 [ %p_16_17, %edge_22 ], [ %p_17_17, %edge_23 ]
  %p_18_18 = phi %hia.buffer [ %p_16_18, %edge_22 ], [ %p_17_18, %edge_23 ]
  %p_18_19 = phi i8 [ %p_16_19, %edge_22 ], [ %p_17_19, %edge_23 ]
  %p_18_20 = phi i8 [ %p_16_20, %edge_22 ], [ %p_17_20, %edge_23 ]
  %p_18_21 = phi i1 [ %p_16_21, %edge_22 ], [ %p_17_21, %edge_23 ]
  %p_18_22 = phi i1 [ %p_16_22, %edge_22 ], [ %p_17_22, %edge_23 ]
  %p_18_23 = phi i8 [ %p_16_23, %edge_22 ], [ %p_17_23, %edge_23 ]
  %p_18_24 = phi i8 [ %p_16_24, %edge_22 ], [ %p_17_24, %edge_23 ]
  %p_18_25 = phi %hia.buffer [ %p_16_25, %edge_22 ], [ %p_17_25, %edge_23 ]
  %p_18_26 = phi i8 [ %p_16_26, %edge_22 ], [ %p_17_26, %edge_23 ]
  %p_18_27 = phi i8 [ %p_16_27, %edge_22 ], [ %p_17_27, %edge_23 ]
  %p_18_28 = phi i1 [ %p_16_28, %edge_22 ], [ %p_17_28, %edge_23 ]
  %p_18_29 = phi i1 [ %t23, %edge_22 ], [ %p_17_28, %edge_23 ]
  %t24 = call %hia.buffer @__hia_fn_1(i1 %p_18_13, %hia.buffer %p_18_25, i1 %p_18_29, i8 16, i8 32)
  %t25 = icmp eq i8 %p_18_0, 0
  br i1 %t25, label %edge_24, label %edge_25
b19:
  %p_19_0 = phi i8 [ %p_18_0, %edge_25 ]
  %p_19_1 = phi %hia.buffer [ %p_18_1, %edge_25 ]
  %p_19_2 = phi i8 [ %p_18_2, %edge_25 ]
  %p_19_3 = phi i8 [ %p_18_3, %edge_25 ]
  %p_19_4 = phi i1 [ %p_18_4, %edge_25 ]
  %p_19_5 = phi i1 [ %p_18_5, %edge_25 ]
  %p_19_6 = phi i8 [ %p_18_6, %edge_25 ]
  %p_19_7 = phi i8 [ %p_18_7, %edge_25 ]
  %p_19_8 = phi i1 [ %p_18_8, %edge_25 ]
  %p_19_9 = phi i1 [ %p_18_9, %edge_25 ]
  %p_19_10 = phi i8 [ %p_18_10, %edge_25 ]
  %p_19_11 = phi i8 [ %p_18_11, %edge_25 ]
  %p_19_12 = phi i1 [ %p_18_12, %edge_25 ]
  %p_19_13 = phi i1 [ %p_18_13, %edge_25 ]
  %p_19_14 = phi i8 [ %p_18_14, %edge_25 ]
  %p_19_15 = phi i8 [ %p_18_15, %edge_25 ]
  %p_19_16 = phi i1 [ %p_18_16, %edge_25 ]
  %p_19_17 = phi i1 [ %p_18_17, %edge_25 ]
  %p_19_18 = phi %hia.buffer [ %p_18_18, %edge_25 ]
  %p_19_19 = phi i8 [ %p_18_19, %edge_25 ]
  %p_19_20 = phi i8 [ %p_18_20, %edge_25 ]
  %p_19_21 = phi i1 [ %p_18_21, %edge_25 ]
  %p_19_22 = phi i1 [ %p_18_22, %edge_25 ]
  %p_19_23 = phi i8 [ %p_18_23, %edge_25 ]
  %p_19_24 = phi i8 [ %p_18_24, %edge_25 ]
  %p_19_25 = phi %hia.buffer [ %p_18_25, %edge_25 ]
  %p_19_26 = phi i8 [ %p_18_26, %edge_25 ]
  %p_19_27 = phi i8 [ %p_18_27, %edge_25 ]
  %p_19_28 = phi i1 [ %p_18_28, %edge_25 ]
  %p_19_29 = phi i1 [ %p_18_29, %edge_25 ]
  %p_19_30 = phi i8 [ 16, %edge_25 ]
  %p_19_31 = phi i8 [ 32, %edge_25 ]
  %p_19_32 = phi %hia.buffer [ %t24, %edge_25 ]
  %p_19_33 = phi i8 [ %p_18_0, %edge_25 ]
  %p_19_34 = phi i8 [ 0, %edge_25 ]
  %p_19_35 = phi i1 [ %t25, %edge_25 ]
  %p_19_36 = phi i1 [ %t25, %edge_25 ]
  %t26 = call i1 @__hia_fn_0(i64 8)
  br label %edge_26
b20:
  %p_20_0 = phi i8 [ %p_18_0, %edge_24 ]
  %p_20_1 = phi %hia.buffer [ %p_18_1, %edge_24 ]
  %p_20_2 = phi i8 [ %p_18_2, %edge_24 ]
  %p_20_3 = phi i8 [ %p_18_3, %edge_24 ]
  %p_20_4 = phi i1 [ %p_18_4, %edge_24 ]
  %p_20_5 = phi i1 [ %p_18_5, %edge_24 ]
  %p_20_6 = phi i8 [ %p_18_6, %edge_24 ]
  %p_20_7 = phi i8 [ %p_18_7, %edge_24 ]
  %p_20_8 = phi i1 [ %p_18_8, %edge_24 ]
  %p_20_9 = phi i1 [ %p_18_9, %edge_24 ]
  %p_20_10 = phi i8 [ %p_18_10, %edge_24 ]
  %p_20_11 = phi i8 [ %p_18_11, %edge_24 ]
  %p_20_12 = phi i1 [ %p_18_12, %edge_24 ]
  %p_20_13 = phi i1 [ %p_18_13, %edge_24 ]
  %p_20_14 = phi i8 [ %p_18_14, %edge_24 ]
  %p_20_15 = phi i8 [ %p_18_15, %edge_24 ]
  %p_20_16 = phi i1 [ %p_18_16, %edge_24 ]
  %p_20_17 = phi i1 [ %p_18_17, %edge_24 ]
  %p_20_18 = phi %hia.buffer [ %p_18_18, %edge_24 ]
  %p_20_19 = phi i8 [ %p_18_19, %edge_24 ]
  %p_20_20 = phi i8 [ %p_18_20, %edge_24 ]
  %p_20_21 = phi i1 [ %p_18_21, %edge_24 ]
  %p_20_22 = phi i1 [ %p_18_22, %edge_24 ]
  %p_20_23 = phi i8 [ %p_18_23, %edge_24 ]
  %p_20_24 = phi i8 [ %p_18_24, %edge_24 ]
  %p_20_25 = phi %hia.buffer [ %p_18_25, %edge_24 ]
  %p_20_26 = phi i8 [ %p_18_26, %edge_24 ]
  %p_20_27 = phi i8 [ %p_18_27, %edge_24 ]
  %p_20_28 = phi i1 [ %p_18_28, %edge_24 ]
  %p_20_29 = phi i1 [ %p_18_29, %edge_24 ]
  %p_20_30 = phi i8 [ 16, %edge_24 ]
  %p_20_31 = phi i8 [ 32, %edge_24 ]
  %p_20_32 = phi %hia.buffer [ %t24, %edge_24 ]
  %p_20_33 = phi i8 [ %p_18_0, %edge_24 ]
  %p_20_34 = phi i8 [ 0, %edge_24 ]
  %p_20_35 = phi i1 [ %t25, %edge_24 ]
  %p_20_36 = phi i1 [ %t25, %edge_24 ]
  br label %edge_27
b21:
  %p_21_0 = phi i8 [ %p_19_0, %edge_26 ], [ %p_20_0, %edge_27 ]
  %p_21_1 = phi %hia.buffer [ %p_19_1, %edge_26 ], [ %p_20_1, %edge_27 ]
  %p_21_2 = phi i8 [ %p_19_2, %edge_26 ], [ %p_20_2, %edge_27 ]
  %p_21_3 = phi i8 [ %p_19_3, %edge_26 ], [ %p_20_3, %edge_27 ]
  %p_21_4 = phi i1 [ %p_19_4, %edge_26 ], [ %p_20_4, %edge_27 ]
  %p_21_5 = phi i1 [ %p_19_5, %edge_26 ], [ %p_20_5, %edge_27 ]
  %p_21_6 = phi i8 [ %p_19_6, %edge_26 ], [ %p_20_6, %edge_27 ]
  %p_21_7 = phi i8 [ %p_19_7, %edge_26 ], [ %p_20_7, %edge_27 ]
  %p_21_8 = phi i1 [ %p_19_8, %edge_26 ], [ %p_20_8, %edge_27 ]
  %p_21_9 = phi i1 [ %p_19_9, %edge_26 ], [ %p_20_9, %edge_27 ]
  %p_21_10 = phi i8 [ %p_19_10, %edge_26 ], [ %p_20_10, %edge_27 ]
  %p_21_11 = phi i8 [ %p_19_11, %edge_26 ], [ %p_20_11, %edge_27 ]
  %p_21_12 = phi i1 [ %p_19_12, %edge_26 ], [ %p_20_12, %edge_27 ]
  %p_21_13 = phi i1 [ %p_19_13, %edge_26 ], [ %p_20_13, %edge_27 ]
  %p_21_14 = phi i8 [ %p_19_14, %edge_26 ], [ %p_20_14, %edge_27 ]
  %p_21_15 = phi i8 [ %p_19_15, %edge_26 ], [ %p_20_15, %edge_27 ]
  %p_21_16 = phi i1 [ %p_19_16, %edge_26 ], [ %p_20_16, %edge_27 ]
  %p_21_17 = phi i1 [ %p_19_17, %edge_26 ], [ %p_20_17, %edge_27 ]
  %p_21_18 = phi %hia.buffer [ %p_19_18, %edge_26 ], [ %p_20_18, %edge_27 ]
  %p_21_19 = phi i8 [ %p_19_19, %edge_26 ], [ %p_20_19, %edge_27 ]
  %p_21_20 = phi i8 [ %p_19_20, %edge_26 ], [ %p_20_20, %edge_27 ]
  %p_21_21 = phi i1 [ %p_19_21, %edge_26 ], [ %p_20_21, %edge_27 ]
  %p_21_22 = phi i1 [ %p_19_22, %edge_26 ], [ %p_20_22, %edge_27 ]
  %p_21_23 = phi i8 [ %p_19_23, %edge_26 ], [ %p_20_23, %edge_27 ]
  %p_21_24 = phi i8 [ %p_19_24, %edge_26 ], [ %p_20_24, %edge_27 ]
  %p_21_25 = phi %hia.buffer [ %p_19_25, %edge_26 ], [ %p_20_25, %edge_27 ]
  %p_21_26 = phi i8 [ %p_19_26, %edge_26 ], [ %p_20_26, %edge_27 ]
  %p_21_27 = phi i8 [ %p_19_27, %edge_26 ], [ %p_20_27, %edge_27 ]
  %p_21_28 = phi i1 [ %p_19_28, %edge_26 ], [ %p_20_28, %edge_27 ]
  %p_21_29 = phi i1 [ %p_19_29, %edge_26 ], [ %p_20_29, %edge_27 ]
  %p_21_30 = phi i8 [ %p_19_30, %edge_26 ], [ %p_20_30, %edge_27 ]
  %p_21_31 = phi i8 [ %p_19_31, %edge_26 ], [ %p_20_31, %edge_27 ]
  %p_21_32 = phi %hia.buffer [ %p_19_32, %edge_26 ], [ %p_20_32, %edge_27 ]
  %p_21_33 = phi i8 [ %p_19_33, %edge_26 ], [ %p_20_33, %edge_27 ]
  %p_21_34 = phi i8 [ %p_19_34, %edge_26 ], [ %p_20_34, %edge_27 ]
  %p_21_35 = phi i1 [ %p_19_35, %edge_26 ], [ %p_20_35, %edge_27 ]
  %p_21_36 = phi i1 [ %t26, %edge_26 ], [ %p_20_35, %edge_27 ]
  %t27 = call %hia.buffer @__hia_fn_1(i1 %p_21_9, %hia.buffer %p_21_32, i1 %p_21_36, i8 4, i8 8)
  %t28 = icmp eq i8 %p_21_0, 0
  br i1 %t28, label %edge_28, label %edge_29
b22:
  %p_22_0 = phi i8 [ %p_21_0, %edge_29 ]
  %p_22_1 = phi %hia.buffer [ %p_21_1, %edge_29 ]
  %p_22_2 = phi i8 [ %p_21_2, %edge_29 ]
  %p_22_3 = phi i8 [ %p_21_3, %edge_29 ]
  %p_22_4 = phi i1 [ %p_21_4, %edge_29 ]
  %p_22_5 = phi i1 [ %p_21_5, %edge_29 ]
  %p_22_6 = phi i8 [ %p_21_6, %edge_29 ]
  %p_22_7 = phi i8 [ %p_21_7, %edge_29 ]
  %p_22_8 = phi i1 [ %p_21_8, %edge_29 ]
  %p_22_9 = phi i1 [ %p_21_9, %edge_29 ]
  %p_22_10 = phi i8 [ %p_21_10, %edge_29 ]
  %p_22_11 = phi i8 [ %p_21_11, %edge_29 ]
  %p_22_12 = phi i1 [ %p_21_12, %edge_29 ]
  %p_22_13 = phi i1 [ %p_21_13, %edge_29 ]
  %p_22_14 = phi i8 [ %p_21_14, %edge_29 ]
  %p_22_15 = phi i8 [ %p_21_15, %edge_29 ]
  %p_22_16 = phi i1 [ %p_21_16, %edge_29 ]
  %p_22_17 = phi i1 [ %p_21_17, %edge_29 ]
  %p_22_18 = phi %hia.buffer [ %p_21_18, %edge_29 ]
  %p_22_19 = phi i8 [ %p_21_19, %edge_29 ]
  %p_22_20 = phi i8 [ %p_21_20, %edge_29 ]
  %p_22_21 = phi i1 [ %p_21_21, %edge_29 ]
  %p_22_22 = phi i1 [ %p_21_22, %edge_29 ]
  %p_22_23 = phi i8 [ %p_21_23, %edge_29 ]
  %p_22_24 = phi i8 [ %p_21_24, %edge_29 ]
  %p_22_25 = phi %hia.buffer [ %p_21_25, %edge_29 ]
  %p_22_26 = phi i8 [ %p_21_26, %edge_29 ]
  %p_22_27 = phi i8 [ %p_21_27, %edge_29 ]
  %p_22_28 = phi i1 [ %p_21_28, %edge_29 ]
  %p_22_29 = phi i1 [ %p_21_29, %edge_29 ]
  %p_22_30 = phi i8 [ %p_21_30, %edge_29 ]
  %p_22_31 = phi i8 [ %p_21_31, %edge_29 ]
  %p_22_32 = phi %hia.buffer [ %p_21_32, %edge_29 ]
  %p_22_33 = phi i8 [ %p_21_33, %edge_29 ]
  %p_22_34 = phi i8 [ %p_21_34, %edge_29 ]
  %p_22_35 = phi i1 [ %p_21_35, %edge_29 ]
  %p_22_36 = phi i1 [ %p_21_36, %edge_29 ]
  %p_22_37 = phi i8 [ 4, %edge_29 ]
  %p_22_38 = phi i8 [ 8, %edge_29 ]
  %p_22_39 = phi %hia.buffer [ %t27, %edge_29 ]
  %p_22_40 = phi i8 [ %p_21_0, %edge_29 ]
  %p_22_41 = phi i8 [ 0, %edge_29 ]
  %p_22_42 = phi i1 [ %t28, %edge_29 ]
  %p_22_43 = phi i1 [ %t28, %edge_29 ]
  %t29 = call i1 @__hia_fn_0(i64 9)
  br label %edge_30
b23:
  %p_23_0 = phi i8 [ %p_21_0, %edge_28 ]
  %p_23_1 = phi %hia.buffer [ %p_21_1, %edge_28 ]
  %p_23_2 = phi i8 [ %p_21_2, %edge_28 ]
  %p_23_3 = phi i8 [ %p_21_3, %edge_28 ]
  %p_23_4 = phi i1 [ %p_21_4, %edge_28 ]
  %p_23_5 = phi i1 [ %p_21_5, %edge_28 ]
  %p_23_6 = phi i8 [ %p_21_6, %edge_28 ]
  %p_23_7 = phi i8 [ %p_21_7, %edge_28 ]
  %p_23_8 = phi i1 [ %p_21_8, %edge_28 ]
  %p_23_9 = phi i1 [ %p_21_9, %edge_28 ]
  %p_23_10 = phi i8 [ %p_21_10, %edge_28 ]
  %p_23_11 = phi i8 [ %p_21_11, %edge_28 ]
  %p_23_12 = phi i1 [ %p_21_12, %edge_28 ]
  %p_23_13 = phi i1 [ %p_21_13, %edge_28 ]
  %p_23_14 = phi i8 [ %p_21_14, %edge_28 ]
  %p_23_15 = phi i8 [ %p_21_15, %edge_28 ]
  %p_23_16 = phi i1 [ %p_21_16, %edge_28 ]
  %p_23_17 = phi i1 [ %p_21_17, %edge_28 ]
  %p_23_18 = phi %hia.buffer [ %p_21_18, %edge_28 ]
  %p_23_19 = phi i8 [ %p_21_19, %edge_28 ]
  %p_23_20 = phi i8 [ %p_21_20, %edge_28 ]
  %p_23_21 = phi i1 [ %p_21_21, %edge_28 ]
  %p_23_22 = phi i1 [ %p_21_22, %edge_28 ]
  %p_23_23 = phi i8 [ %p_21_23, %edge_28 ]
  %p_23_24 = phi i8 [ %p_21_24, %edge_28 ]
  %p_23_25 = phi %hia.buffer [ %p_21_25, %edge_28 ]
  %p_23_26 = phi i8 [ %p_21_26, %edge_28 ]
  %p_23_27 = phi i8 [ %p_21_27, %edge_28 ]
  %p_23_28 = phi i1 [ %p_21_28, %edge_28 ]
  %p_23_29 = phi i1 [ %p_21_29, %edge_28 ]
  %p_23_30 = phi i8 [ %p_21_30, %edge_28 ]
  %p_23_31 = phi i8 [ %p_21_31, %edge_28 ]
  %p_23_32 = phi %hia.buffer [ %p_21_32, %edge_28 ]
  %p_23_33 = phi i8 [ %p_21_33, %edge_28 ]
  %p_23_34 = phi i8 [ %p_21_34, %edge_28 ]
  %p_23_35 = phi i1 [ %p_21_35, %edge_28 ]
  %p_23_36 = phi i1 [ %p_21_36, %edge_28 ]
  %p_23_37 = phi i8 [ 4, %edge_28 ]
  %p_23_38 = phi i8 [ 8, %edge_28 ]
  %p_23_39 = phi %hia.buffer [ %t27, %edge_28 ]
  %p_23_40 = phi i8 [ %p_21_0, %edge_28 ]
  %p_23_41 = phi i8 [ 0, %edge_28 ]
  %p_23_42 = phi i1 [ %t28, %edge_28 ]
  %p_23_43 = phi i1 [ %t28, %edge_28 ]
  br label %edge_31
b24:
  %p_24_0 = phi i8 [ %p_22_0, %edge_30 ], [ %p_23_0, %edge_31 ]
  %p_24_1 = phi %hia.buffer [ %p_22_1, %edge_30 ], [ %p_23_1, %edge_31 ]
  %p_24_2 = phi i8 [ %p_22_2, %edge_30 ], [ %p_23_2, %edge_31 ]
  %p_24_3 = phi i8 [ %p_22_3, %edge_30 ], [ %p_23_3, %edge_31 ]
  %p_24_4 = phi i1 [ %p_22_4, %edge_30 ], [ %p_23_4, %edge_31 ]
  %p_24_5 = phi i1 [ %p_22_5, %edge_30 ], [ %p_23_5, %edge_31 ]
  %p_24_6 = phi i8 [ %p_22_6, %edge_30 ], [ %p_23_6, %edge_31 ]
  %p_24_7 = phi i8 [ %p_22_7, %edge_30 ], [ %p_23_7, %edge_31 ]
  %p_24_8 = phi i1 [ %p_22_8, %edge_30 ], [ %p_23_8, %edge_31 ]
  %p_24_9 = phi i1 [ %p_22_9, %edge_30 ], [ %p_23_9, %edge_31 ]
  %p_24_10 = phi i8 [ %p_22_10, %edge_30 ], [ %p_23_10, %edge_31 ]
  %p_24_11 = phi i8 [ %p_22_11, %edge_30 ], [ %p_23_11, %edge_31 ]
  %p_24_12 = phi i1 [ %p_22_12, %edge_30 ], [ %p_23_12, %edge_31 ]
  %p_24_13 = phi i1 [ %p_22_13, %edge_30 ], [ %p_23_13, %edge_31 ]
  %p_24_14 = phi i8 [ %p_22_14, %edge_30 ], [ %p_23_14, %edge_31 ]
  %p_24_15 = phi i8 [ %p_22_15, %edge_30 ], [ %p_23_15, %edge_31 ]
  %p_24_16 = phi i1 [ %p_22_16, %edge_30 ], [ %p_23_16, %edge_31 ]
  %p_24_17 = phi i1 [ %p_22_17, %edge_30 ], [ %p_23_17, %edge_31 ]
  %p_24_18 = phi %hia.buffer [ %p_22_18, %edge_30 ], [ %p_23_18, %edge_31 ]
  %p_24_19 = phi i8 [ %p_22_19, %edge_30 ], [ %p_23_19, %edge_31 ]
  %p_24_20 = phi i8 [ %p_22_20, %edge_30 ], [ %p_23_20, %edge_31 ]
  %p_24_21 = phi i1 [ %p_22_21, %edge_30 ], [ %p_23_21, %edge_31 ]
  %p_24_22 = phi i1 [ %p_22_22, %edge_30 ], [ %p_23_22, %edge_31 ]
  %p_24_23 = phi i8 [ %p_22_23, %edge_30 ], [ %p_23_23, %edge_31 ]
  %p_24_24 = phi i8 [ %p_22_24, %edge_30 ], [ %p_23_24, %edge_31 ]
  %p_24_25 = phi %hia.buffer [ %p_22_25, %edge_30 ], [ %p_23_25, %edge_31 ]
  %p_24_26 = phi i8 [ %p_22_26, %edge_30 ], [ %p_23_26, %edge_31 ]
  %p_24_27 = phi i8 [ %p_22_27, %edge_30 ], [ %p_23_27, %edge_31 ]
  %p_24_28 = phi i1 [ %p_22_28, %edge_30 ], [ %p_23_28, %edge_31 ]
  %p_24_29 = phi i1 [ %p_22_29, %edge_30 ], [ %p_23_29, %edge_31 ]
  %p_24_30 = phi i8 [ %p_22_30, %edge_30 ], [ %p_23_30, %edge_31 ]
  %p_24_31 = phi i8 [ %p_22_31, %edge_30 ], [ %p_23_31, %edge_31 ]
  %p_24_32 = phi %hia.buffer [ %p_22_32, %edge_30 ], [ %p_23_32, %edge_31 ]
  %p_24_33 = phi i8 [ %p_22_33, %edge_30 ], [ %p_23_33, %edge_31 ]
  %p_24_34 = phi i8 [ %p_22_34, %edge_30 ], [ %p_23_34, %edge_31 ]
  %p_24_35 = phi i1 [ %p_22_35, %edge_30 ], [ %p_23_35, %edge_31 ]
  %p_24_36 = phi i1 [ %p_22_36, %edge_30 ], [ %p_23_36, %edge_31 ]
  %p_24_37 = phi i8 [ %p_22_37, %edge_30 ], [ %p_23_37, %edge_31 ]
  %p_24_38 = phi i8 [ %p_22_38, %edge_30 ], [ %p_23_38, %edge_31 ]
  %p_24_39 = phi %hia.buffer [ %p_22_39, %edge_30 ], [ %p_23_39, %edge_31 ]
  %p_24_40 = phi i8 [ %p_22_40, %edge_30 ], [ %p_23_40, %edge_31 ]
  %p_24_41 = phi i8 [ %p_22_41, %edge_30 ], [ %p_23_41, %edge_31 ]
  %p_24_42 = phi i1 [ %p_22_42, %edge_30 ], [ %p_23_42, %edge_31 ]
  %p_24_43 = phi i1 [ %t29, %edge_30 ], [ %p_23_42, %edge_31 ]
  %t30 = call %hia.buffer @__hia_fn_1(i1 %p_24_5, %hia.buffer %p_24_39, i1 %p_24_43, i8 1, i8 2)
  %t31 = extractvalue %hia.buffer %t30, 0
  %t32 = extractvalue %hia.buffer %t30, 1
  %t33 = icmp ult i64 0, %t32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = getelementptr i8, ptr %t31, i64 0
  %t36 = load i8, ptr %t35, align 1
  %t37 = zext i8 %t36 to i64
  %t38 = extractvalue %hia.buffer %p_24_1, 0
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %drop_nonnull_40, label %drop_after_40
drop_nonnull_40:
  call void @free(ptr %t38) nobuiltin
  br label %drop_after_40
drop_after_40:
  ret i64 %t37
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b9
edge_11:
  br label %b9
edge_12:
  br label %b10
edge_13:
  br label %b11
edge_14:
  br label %b12
edge_15:
  br label %b12
edge_16:
  br label %b14
edge_17:
  br label %b13
edge_18:
  br label %b15
edge_19:
  br label %b15
edge_20:
  br label %b17
edge_21:
  br label %b16
edge_22:
  br label %b18
edge_23:
  br label %b18
edge_24:
  br label %b20
edge_25:
  br label %b19
edge_26:
  br label %b21
edge_27:
  br label %b21
edge_28:
  br label %b23
edge_29:
  br label %b22
edge_30:
  br label %b24
edge_31:
  br label %b24
}

define zeroext i1 @tick(i64 %a0) {
entry:
  %result = call i1 @__hia_fn_0(i64 %a0)
  ret i1 %result
}

define i64 @probe(i8 zeroext %a0) {
entry:
  %result = call i64 @__hia_fn_2(i8 %a0)
  ret i64 %result
}
