"""Freeze the independent static conclusions and separate additional controls."""
from __future__ import annotations
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

BASE=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
ROOT=BASE/'hepta-nested-returned-views'
HEAD='6b83eae0aef1cfbc9654510b55f5c35ed0bd55d5'
PARENT='a6cfb7e00a1c08276d27459bdcc5628aa7622079'

def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT),*args])
def read(path):return json.loads((OUT/path).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def methods(data):
    rows={}
    for node in ast.parse(data).body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            rows[node.name]=ast.dump(node,include_attributes=False)
        elif isinstance(node,ast.ClassDef):
            for child in node.body:
                if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    rows[node.name+'.'+child.name]=ast.dump(child,include_attributes=False)
    return rows
old=git('show',PARENT+':hepta/hia_program_source.py')
new=git('show',HEAD+':hepta/hia_program_source.py')
before,after=methods(old),methods(new)
changed=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k))
assert changed==['_Lower.call','_Lower.expr','_Lower.returned_view_field']
untouched=['hepta/checker.py','hepta/parser.py','hepta/resource_lowering.py','hepta/resource_ir.py',
           'hepta/hia_program.py','hepta/hia_program_runtime.py','hepta/hia_program_llvm.py']
bindings=[]
for name in untouched:
    left,right=git('show',PARENT+':'+name),git('show',HEAD+':'+name)
    assert left==right
    bindings.append({'path':name,'bytes':len(right),'sha256':hashlib.sha256(right).hexdigest(),'unchanged':True})
findings=[
 {'topic':'Only selected source adaptation changes','finding':'Exactly _Lower.returned_view_field, _Lower.expr and optional prepared arguments in _Lower.call change. Checker, Resource IR, Core verifier, Python Machine, LLVM backend and scalar export selection remain byte-identical to the parent.'},
 {'topic':'Admission at every nested level','finding':'Every recursive returned_view_field call rechecks a known non-extern function, matching read/mut return and borrow mode, one declared original borrowed formal, byte slice/Buffer type and scalar-only other value arguments. The terminal origin must remain one named byte place or ordinary owner-record field; stored local View and aggregate origins are rejected.'},
 {'topic':'No shape-only admission','finding':'A freshly checked constructor-field path records returned_fields; an arbitrary value with a similar loan-list shape cannot enter the returned-call View path. The final chain requires one immediate parent, matching one-atom types, parent last loan equal to its capability, exact parent-prefix plus child, and no repeated capability names.'},
 {'topic':'Argument evaluation order','finding':'The recursive path loops over the original call.children once in source order. Only the declared origin recursively adapts; every other argument uses the unchanged expr path. The completed keys are passed to the existing call once, preventing duplicate scalar evaluation. Independent four-level short-circuit controls additionally exercised branch-generated CFG interfaces before and after every origin.'},
 {'topic':'Complete parent retention through CFG','finding':'Existing call copies the parent loan stack and appends the actual returned child. Existing _State.prune follows borrow_parents transitively. new_block retains aliases under resource renaming; edge requires equal parent binding and alias relation. These unchanged functions carry all ancestors through branches, loops and early returns.'},
 {'topic':'Cleanup and ownership','finding':'Existing reverse loan ending plus consume removes each ended capability from all aliases. Shared lexical aliases retain obligations until the final alias; mutable whole-local move transfers them, and explicit drop ends descendants before ancestors. Existing source/ResourceIR and Core verification reject missing mutable drops, live-owner release and inconsistent joins.'},
 {'topic':'Error and stop boundary','finding':'Owner evidence covers allocation refusal with normal return, stopped budget ledgers and exact ancestor corruption refusals. Native C observers verify successful-return allocation/free balance only. Traps, cancellation, foreign lifetimes, general unwind cleanup and RSS are not established by this increment.'},
 {'topic':'Contract and compatibility','finding':'The 36-capability selector set is exactly old349 plus new10; other35 capabilities and all top-level contract authority/boundary claims are unchanged. A former same-mode nested-call exclusion is deliberately replaced with a still-forbidden permission-change control. Existing single-call Core outputs retain their old identities. The default v1 route does not gain nested stored-return support.'},
 {'topic':'Bounded input and authority','finding':'The unchanged source byte limit, parser depth limit, specialization limits and primitive Core verifier remain gates. Python remains the production authority, Rust remains a finite comparison Machine, public LLVM exports remain scalar and optimization remains no_change. No broad strict blocker is closed.'},
 {'topic':'Original collector review','finding':'The owner collector invokes the original unittest suite and records actual start/success/stop counts, all materialized source bytes/modes and tool hashes. Its bounded-compiler observer calls the original runner with unchanged arguments/options and returns the original completion or propagates its exception. It copies temporary IR/artifact bytes; it does not patch assertions or manufacture execution results.'}
]
static={'schema':'hepta.independent-nested-static-review.v1','ok':True,'head':HEAD,'parent':PARENT,
        'production_path':'hepta/hia_program_source.py','production_sha256':hashlib.sha256(new).hexdigest(),
        'changed_ast_methods':changed,'unchanged_components':bindings,'findings':findings,
        'reviewer_authored_implementation_or_owner_collector':False,'formal_refinement_claimed':False}
write('static-review.json',static)
parent=read('parent-red/report.json');semantic=read('candidate-green/report.json');native=read('native-continuation/report.json')
assert parent['ok'] and parent['source_checked'] and parent['resource_ir_verification']['ok']
assert parent['actual_parent_refusal']['type']=='HIAProgramSourceRejected'
assert semantic['exception']=={'type':'TypeError','message':'data must be str, not HIAProgramLLVM'} and not semantic['ok']
assert semantic['source_checked'] and semantic['resource_ir_verification']['ok']
assert native['ok'] and len(native['observations'])==5
cases=read('candidate-green/python-rust.json')
assert len(cases)==5 and [r['expected'] for r in cases]==[255,170,254,127,253]
for index,row in enumerate(cases):
    assert json.loads(row['rust_process']['stdout'])==row['rust'] and row['rust_process']['returncode']==0
    for key in ['status','values','steps','resources','function','program_sha256']:
        assert row['python'][key]==row['rust'][key]
    observation=native['observations'][index]
    assert json.loads(observation['stdout'])==observation['expected'] and observation['returncode']==0
    assert observation['expected']['value']==row['expected']
    assert row['python']['resources']['live_owners']==row['python']['resources']['live_local_loans']==row['python']['resources']['live_bytes']==0
compiler=read('native-continuation/compiler-processes.json')
assert len(compiler)==3 and all(r['returncode']==0 for r in compiler)
actual_inputs=[r for process in compiler for r in process['inputs']]
assert len(actual_inputs)==1
for row in actual_inputs:
    assert sha(OUT/'native-continuation'/row['retained_path'])==sha(OUT/'native-continuation/core.ll')==row['sha256']
assert (OUT/'controls-producer-used.py').read_bytes()==(OUT/'run_controls.py').read_bytes()
for relative in ['parent-red','candidate-green','native-continuation']:
    report=read(relative+'/report.json')
    assert report['source_stable'] and report['tools_stable'] and report['producer_stable']
controls={'schema':'hepta.independent-nested-controls-summary.v1','ok':True,
          'head':HEAD,'parent':PARENT,'source_sha256':sha(OUT/'four_level_control.hepta'),
          'core_sha256':semantic['core_sha256'],
          'risk':'Four nested same-mode returned calls, nonfirst origin at each level, eight scalar short-circuit expressions crossing CFG before and after origins, mutable move/drop and failure-position-sensitive order.',
          'old_parent_source_and_resource_legal':True,'old_parent_adapter_refuses':True,
          'python_executions':5,'original_rust_processes':5,'native_allocator_processes':5,
          'expected_values':[255,170,254,127,253],'full_python_rust_ledger_equal':True,
          'compile_commands':1,'observer_link_commands':1,'compiler_identity_probe_commands':2,
          'source_scope':{'parent_full_files':7699,'candidate_materialized_files':1459,'candidate_full_git_tree_files':7701},
          'producer_failure_preserved':{'path':'candidate-green/report.json','error':semantic['exception'],
                                       'stage':'after five successful Python/Rust comparisons; before any native compilation',
                                       'original_process_status':1,'successful_whole_original_wrapper_claimed':False},
          'continuation':'native-continuation/report.json completes only the never-executed native phase using the exact saved Core; no Python/Rust replay.',
          'readonly_audit_development_failure_preserved':'owner-audit-development1.stderr records a budget-report values-key assumption; fixed auditor checks explicit absent values and equal budget error codes, no runtime replay.',
          'crate_builds':0,'owner_methods_replayed':0,'existing_359_method_population_incremented':False,
          'controls_author':'independent evidence reviewer; these additional controls are original observations, not independently peer-reviewed controls',
          'whole_language_or_refinement_proved':False,'strict_blockers_closed':0}
write('controls-summary.json',controls)
owner=read('owner-review.json');rebuild=read('source-patch-reconstruction.json')
assert owner['ok'] and rebuild['ok']
review={'schema':'hepta.nested-returned-views-independent-review.v1','ok':True,
        'finished_utc':datetime.now(timezone.utc).isoformat(),'source_head':HEAD,'source_parent':PARENT,
        'source_tree':'0cac7421225a2f8bba1de07c08011d79410b8cdc','public_source':False,
        'owner_read_only_conditions':owner['read_only_checks'],'owner_distinct_method_successes':102,
        'owner_method_attempts':105,'original_regression_batch_status':'89 ordinary successes and three missing-input errors; original FAIL preserved',
        'exact_three_retry_pass':True,'static_review_sha256':sha(OUT/'static-review.json'),
        'owner_readback_sha256':sha(OUT/'owner-review.json'),'controls_summary_sha256':sha(OUT/'controls-summary.json'),
        'independent_patch_tree_reconstruction':True,'additional_original_controls':5,
        'registered_current_selectors':359,'entire359_executed_here':False,
        'source_materialization':'owner focused1456; precise existing-input restore1459; full immutable Git tree7701; sparse execution coverage explicitly limited',
        'role_boundary':'Reviewer did not author nested implementation or owner collector. Owner original evidence is independently read back. Reviewer-authored new controls are kept distinct and are not described as independent review of their own producer.',
        'finite_scope_accepted_for_next_integration':True,'python_production_authority':True,
        'rust_production_authority':False,'optimization_policy':'no_change','strict_blockers_closed':0,
        'whole_language_soundness_proved':False,'source_to_core_refinement_proved':False,'backend_refinement_proved':False}
write('review.json',review)
print(json.dumps({'ok':True,'owner_read_only_conditions':owner['read_only_checks'],'additional_controls':5,'production_ast_changes':changed}))
