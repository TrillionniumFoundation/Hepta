"""Independent, finite four-level argument-CFG controls; never runs owner methods."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--parent-red', action='store_true')
args = parser.parse_args()
ROOT, OUT = args.root.resolve(strict=True), args.output.resolve()
OUT.mkdir(parents=True, exist_ok=False)
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

def dig(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def file(path):
    return {**dig(path.read_bytes()), 'mode': '100755' if path.stat().st_mode & stat.S_IXUSR else '100644'}

def write(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def git(*argv):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(ROOT), *argv])

def source_state():
    files = {}
    rows = [row for row in git('ls-tree', '-rz', 'HEAD').split(b'\0') if row]
    for row in rows:
        meta, raw_path = row.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        path = ROOT / raw_path.decode()
        if not path.exists():
            continue
        assert kind == 'blob' and stat.S_ISREG(path.lstat().st_mode)
        actual = file(path)
        assert actual['mode'] == mode and actual['git_blob'] == blob, path
        files[raw_path.decode()] = actual
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git('status', '--porcelain', '--untracked-files=all').decode(),
            'full_git_tree_files': len(rows), 'materialized_source_files': len(files), 'files': files}

def tool_state():
    names = {'python': Path(sys.executable).resolve()}
    if not args.parent_red:
        names.update(clang=Path(os.environ['CLANG']).resolve(),
                     rust=Path(os.environ['HIA_RETURNED_VIEW_RUST_BIN']).resolve())
    return {key: {'path': str(path), **file(path)} for key, path in names.items()}

start = time.time()
source_before, tools_before = source_state(), tool_state()
producer_before = file(Path(__file__))
assert source_before['head'] == args.head and not source_before['status']
write('source-before.json', source_before)
write('tools-before.json', tools_before)
source = (HERE / 'four_level_control.hepta').read_text()
(OUT / 'source.hepta').write_text(source)
report = {'schema': 'hepta.independent-nested-four-level-control.v1', 'ok': False,
          'argv': sys.argv, 'cwd': str(Path.cwd()), 'started_unix': start,
          'source': dig(source.encode()), 'parent_red': args.parent_red,
          'owner_test_methods_rerun': 0, 'crate_builds': 0,
          'production_authority_changed': False, 'optimization_policy': 'no_change',
          'broad_blockers_closed': False}
write('started.json', report)
try:
    from hepta.parser import parse
    from hepta.checker import check
    from hepta.resource_lowering import lower_resource_ir
    from hepta.resource_ir import verify_resource_ir
    from hepta.hia_program_source import lower_source, HIAProgramSourceRejected
    from hepta.hia_schema import SCHEMA_V8
    checked = check(ast := parse(source))
    report['source_checked'] = checked.ok
    report['source_diagnostics'] = [str(d) for d in checked.diagnostics]
    assert checked.ok, report['source_diagnostics']
    resource = lower_resource_ir(ast, checked)
    write('resource-ir.json', resource)
    report['resource_ir_verification'] = verify_resource_ir(resource)
    assert report['resource_ir_verification']['ok']
    if args.parent_red:
        try:
            lower_source(source, core_schema=SCHEMA_V8)
        except HIAProgramSourceRejected as exc:
            report['actual_parent_refusal'] = {'type': type(exc).__name__, 'message': str(exc)}
        else:
            raise AssertionError('old parent unexpectedly admits nested origin')
        report['ok'] = True
    else:
        from hepta.hia_program_runtime import execute_program
        from hepta.hia_program_llvm import emit_program_llvm, compile_program_llvm
        core = lower_source(source, core_schema=SCHEMA_V8)
        (OUT / 'core.json').write_bytes(core.canonical_bytes)
        report['core_sha256'] = core.sha256
        cases = [(1, None, 255, 9, 9, 10), (0, None, 170, 1, 1, 1),
                 (1, 2, 254, 9, 8, 10), (1, 6, 127, 9, 8, 10),
                 (1, 9, 253, 9, 8, 9)]
        results = []
        report['python_rust_cases'] = results
        for enabled, failure, expected, attempts, allocations, peak in cases:
            py = execute_program(core, 'probe', [enabled], max_steps=2000,
                                 max_heap_bytes=1024, allocation_fail_at=failure)
            row = {'enabled': enabled, 'allocation_fail_at': failure, 'expected': expected,
                   'expected_attempts': attempts, 'expected_allocations': allocations,
                   'expected_peak_bytes': peak, 'python': py}
            results.append(row)
            assert py['values'] == [expected]
            resources = py['resources']
            for key in ['live_owners', 'live_local_loans', 'live_bytes']:
                assert resources[key] == 0
            assert (resources['allocation_attempts'], resources['allocations'], resources['frees'],
                    resources['peak_bytes']) == (attempts, allocations, allocations, peak)
            argv = [os.environ['HIA_RETURNED_VIEW_RUST_BIN'], '--owned-run', 'probe', json.dumps([enabled]),
                    '2000', '1024', 'none' if failure is None else str(failure)]
            actual = subprocess.run(argv, input=core.canonical_bytes, capture_output=True, timeout=20, cwd=ROOT)
            row['rust_process'] = {'argv': argv, 'cwd': str(ROOT), 'returncode': actual.returncode,
                                   'stdout': actual.stdout.decode(), 'stderr': actual.stderr.decode()}
            assert actual.returncode == 0, actual.stderr
            rust = json.loads(actual.stdout)
            row['rust'] = rust
            for key in ['program_sha256', 'function', 'status', 'values', 'steps', 'resources']:
                assert py[key] == rust[key], key
        write('python-rust.json', results)
        # Retain exact original emitted IR and object. One compiler invocation only.
        ir = emit_program_llvm(core)
        (OUT / 'core.ll').write_text(ir)
        artifact = OUT / 'core.o'
        receipt = compile_program_llvm(ir, program=core, output=artifact,
                                       clang=os.environ['CLANG'], kind='object')
        write('llvm-receipt.json', receipt)
        assert receipt['ok']
        observer = r'''
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
void *__real_malloc(size_t); void *__real_calloc(size_t,size_t); void __real_free(void*);
static void *addresses[16]; static size_t sizes[16], attempts, allocations, frees, live, peak, fail;
static void *remember(void *p,size_t n) {
  if (!p) return p; size_t i=0; while(i<16 && addresses[i]) ++i; if(i==16) exit(81);
  addresses[i]=p; sizes[i]=n; allocations++; live+=n; if(live>peak) peak=live; return p;
}
void *__wrap_malloc(size_t n) { attempts++; return attempts==fail?NULL:remember(__real_malloc(n),n); }
void *__wrap_calloc(size_t n,size_t s) { attempts++; return attempts==fail?NULL:remember(__real_calloc(n,s),n*s); }
void __wrap_free(void *p) {
  size_t i=0; while(i<16 && addresses[i]!=p) ++i; if(!p || i==16) exit(82);
  live-=sizes[i]; addresses[i]=NULL; frees++; __real_free(p);
}
extern uint64_t probe(uint8_t);
int main(int argc,char **argv) {
  if(argc!=3) return 83; fail=strtoull(argv[2],NULL,10);
  uint64_t value=probe((uint8_t)strtoul(argv[1],NULL,10));
  printf("{\"value\":%llu,\"attempts\":%zu,\"allocations\":%zu,\"frees\":%zu,\"live_bytes\":%zu,\"peak_bytes\":%zu}\n",
    (unsigned long long)value,attempts,allocations,frees,live,peak);
  return live?84:0;
}
'''
        (OUT / 'observer.c').write_text(observer)
        executable = OUT / 'observer'
        command = [os.environ['CLANG'], '-std=c11', '-O2', str(OUT / 'observer.c'), str(artifact),
                   '-Wl,--wrap=malloc', '-Wl,--wrap=calloc', '-Wl,--wrap=free', '-o', str(executable)]
        linked = subprocess.run(command, capture_output=True, text=True, timeout=60, cwd=ROOT)
        report['link'] = {'argv': command, 'returncode': linked.returncode,
                          'stdout': linked.stdout, 'stderr': linked.stderr}
        assert linked.returncode == 0, linked.stderr
        observations = []
        report['native_allocator_cases'] = observations
        for enabled, failure, expected, attempts, allocations, peak in cases:
            argv = [str(executable), str(enabled), str(failure or 0)]
            actual = subprocess.run(argv, capture_output=True, text=True, timeout=20, cwd=ROOT)
            row = {'argv': argv, 'returncode': actual.returncode, 'stdout': actual.stdout,
                   'stderr': actual.stderr, 'expected': {'value': expected, 'attempts': attempts,
                      'allocations': allocations, 'frees': allocations, 'live_bytes': 0, 'peak_bytes': peak}}
            observations.append(row)
            assert actual.returncode == 0 and json.loads(actual.stdout) == row['expected'], row
        write('native-allocator.json', observations)
        report['artifacts'] = {path.name: file(path) for path in [artifact, executable, OUT/'core.ll', OUT/'observer.c']}
        report['ok'] = True
except BaseException as exc:
    report['exception'] = {'type': type(exc).__name__, 'message': str(exc)}
    raise
finally:
    source_after, tools_after = source_state(), tool_state()
    write('source-after.json', source_after)
    write('tools-after.json', tools_after)
    report.update(source_stable=source_before == source_after, tools_stable=tools_before == tools_after,
                  producer_before=producer_before, producer_after=file(Path(__file__)),
                  finished_unix=time.time(), finished_utc=datetime.now(timezone.utc).isoformat())
    report['producer_stable'] = report['producer_before'] == report['producer_after']
    report['ok'] = report['ok'] and report['source_stable'] and report['tools_stable'] and report['producer_stable']
    write('report.json', report)
    print(json.dumps({k: report[k] for k in ['ok','parent_red','source_stable','tools_stable','producer_stable']}))
