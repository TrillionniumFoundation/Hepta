"""Read-only static integration review. No imports from the candidate, tests or native runs."""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile

WORK = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
OWNER = WORK / "nested-retention-integration-20261030"
ROOT = WORK / "hepta-core-rust-ci-guards"
HEAD = "4c96828de373b8a0e9edd05c2d91d8d405a505f1"
TREE = "d3fb9ae660d79219071f03bd21c30b84c2678602"
PUBLIC_PARENT = "a6cfb7e00a1c08276d27459bdcc5628aa7622079"
RETENTION = "2f4891ce7c5b92979ffb4c65575075367a1ecb15"
NESTED = "6b83eae0aef1cfbc9654510b55f5c35ed0bd55d5"
BRANCH = "codex/hia-nested-views-native-retention-20261030"
inputs = {}
checks = 0


def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)


def ident(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def raw(path):
    path = Path(path)
    data = path.read_bytes()
    inputs[str(path)] = {**ident(data), "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}
    return data


def read(path):
    return json.loads(raw(path))


def git(*args, env=None):
    return subprocess.check_output(["git", "--no-replace-objects", "-C", str(ROOT), *args], env=env)


def changed(head):
    return set(git("diff", "--name-only", PUBLIC_PARENT, head).decode().splitlines())


def source_snapshot():
    result = {}
    for item in git("ls-tree", "-rz", HEAD).split(b"\0"):
        if not item:
            continue
        metadata, name = item.split(b"\t", 1)
        mode, kind, blob = metadata.decode().split()
        name = name.decode()
        path = ROOT / name
        check(kind == "blob" and stat.S_ISREG(path.lstat().st_mode), "materialized ordinary source " + name)
        data = path.read_bytes()
        value = ident(data)
        check(value["git_blob"] == blob, "raw source Git blob " + name)
        check(("100755" if path.stat().st_mode & 0o111 else "100644") == mode, "source mode " + name)
        result[name] = {**value, "mode": mode}
    check(len(result) == 7702, "complete integrated tracked population")
    return result


def main():
    started = datetime.now(timezone.utc).isoformat()
    check(git("show", "-s", "--format=%H %T %P", "HEAD").decode().strip() == " ".join([HEAD, TREE, RETENTION]), "actual local ancestry")
    check(git("status", "--porcelain", "--untracked-files=all") == b"", "clean full source")
    before = source_snapshot()
    manifest = read(OWNER / "source-export/manifest.json")
    check(manifest["local_commit"] == HEAD and manifest["local_tree"] == TREE
          and manifest["local_parent"] == RETENTION and manifest["public_parent"] == PUBLIC_PARENT,
          "local parent versus intended public parent")
    check(manifest["public_candidate_commit"] is None and manifest["public_execution"] is False, "no public execution claim")
    check(hashlib.sha256(raw(OWNER / "export_common_candidate.py")).hexdigest() == manifest["producer_sha256"], "export producer identity")
    retention_files, nested_files = changed(RETENTION), changed(NESTED)
    allowlists = {".github/workflows/hepta-cpp-upstream-hosts.yml", ".github/workflows/hepta-native-hosts.yml", ".github/workflows/hepta-qualification.yml"}
    check(len(retention_files) == 5 and len(nested_files) == 10 and not retention_files.intersection(nested_files), "disjoint component scopes")
    check(changed(HEAD) == retention_files | nested_files | allowlists and len(changed(HEAD)) == 17, "exact cumulative 17 paths")
    check(set(row["repository_path"] for row in manifest["files"]) == changed(HEAD) and len(manifest["files"]) == 17, "exact export path population")
    for row in manifest["files"]:
        name = row["repository_path"]
        data = raw(Path(row["local_path"]))
        check(data.decode().encode() == data and data == git("show", HEAD + ":" + name) == raw(ROOT / name), "raw UTF8 export " + name)
        check(ident(data) == {key: row[key] for key in ("bytes", "sha256", "git_blob")}
              and row["mode"] == before[name]["mode"], "export identity/mode")
    for name in nested_files:
        check(git("show", NESTED + ":" + name) == raw(ROOT / name), "nested original peer bytes " + name)
    for name in retention_files - allowlists:
        check(git("show", RETENTION + ":" + name) == raw(ROOT / name), "retention original peer bytes " + name)
    for name in allowlists:
        old, current = git("show", RETENTION + ":" + name), raw(ROOT / name)
        token = ("      - " + BRANCH + "\n").encode() if name.endswith("hepta-qualification.yml") else (BRANCH + ", ").encode()
        check(current.count(token) == 1 and current.replace(token, b"") == old, "sole branch allowlist addition " + name)
    prior = read(OWNER / "static-union-before-freeze.json")
    peers = {}
    for item in prior["both_original_peer_review_inputs"]:
        path = Path(item["path"])
        review = read(path)
        check(hashlib.sha256(raw(path)).hexdigest() == item["sha256"] and review["ok"] is True, "original peer result bound")
        source = review.get("source", {}).get("head", review.get("source_head"))
        check(source == (NESTED if item["component"] == "nested" else RETENTION), "original peer source identity")
        peers[item["component"]] = {"path": str(path), "sha256": item["sha256"], "source": source}
    check(set(peers) == {"nested", "retention"}, "both distinct peer scopes")
    patch = OWNER / "source-export/source.patch"
    patch_bytes = raw(patch)
    check(len(patch_bytes) == manifest["patch_bytes"] == 106130
          and hashlib.sha256(patch_bytes).hexdigest() == manifest["patch_sha256"], "whole cumulative patch")
    with tempfile.TemporaryDirectory(prefix="hepta-integration-review-index-") as temporary:
        environment = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / "index"))
        git("read-tree", PUBLIC_PARENT, env=environment)
        git("apply", "--cached", "--check", str(patch), env=environment)
        git("apply", "--cached", str(patch), env=environment)
        check(git("write-tree", env=environment).decode().strip() == TREE, "independent intended-public-parent tree reconstruction")
    contract_bytes = raw(ROOT / "docs/HIA_SAFETY_CONTRACT.json")
    check(contract_bytes == git("show", NESTED + ":docs/HIA_SAFETY_CONTRACT.json"), "nested 359 contract exact bytes")
    contract = json.loads(contract_bytes)
    canonical = [selector for capability in contract["capabilities"] for selector in capability["regression_selectors"]]
    check(len(canonical) == len(set(canonical)) == 359 and len(contract["capabilities"]) == 36, "359 distinct canonical methods and 36 capabilities")
    check(all(value is False for value in contract["unproved_claims"].values()), "all unproved claims remain false")
    plan = read(OWNER / "selection-plan.json")
    check(plan["canonical_methods"] == sorted(canonical) and plan["public_parent"] == PUBLIC_PARENT, "plan canonical/source identity")
    originals = {}
    for name, item in plan["inputs"].items():
        path = Path(item["path"])
        value = read(path)
        check(hashlib.sha256(raw(path)).hexdigest() == item["sha256"], "original selector input " + name)
        original = value["selectors"] if name == "source92" else value["additional_selection"] if name == "env19" else value
        check(len(original) == len(set(original)) == {"source92": 92, "env19": 19, "native25": 25}[name], "original unique population " + name)
        originals[name] = set(original)
    for left, right in itertools.combinations(originals, 2):
        check(not originals[left].intersection(originals[right]), "no duplicate extra-source populations")
    scheduled = set(canonical)
    for name in ("source92", "native25", "env19"):
        group = plan["groups"][name]
        overlap = originals[name].intersection(scheduled)
        difference = originals[name] - scheduled
        check(group["original"] == len(originals[name]) and set(group["already_scheduled"]) == overlap
              and set(group["difference"]) == difference and group["difference_count"] == len(difference), "exact sequential difference " + name)
        check(set(group["in_canonical359"]) == originals[name].intersection(canonical), "exact canonical overlap " + name)
        scheduled.update(difference)
    check(len(scheduled) == plan["union_count"] == 471, "exact distinct 471-method plan")
    extras = scheduled - set(canonical)
    check(plan["extra_methods"] == sorted(extras) and len(extras) == plan["extra_count"] == 112, "exact extras112")
    ndu = set(plan["native_graph_methods"])
    check(len(ndu) == 2 and ndu <= originals["env19"] and all(".ConvergedNativeGraphTests." in name for name in ndu), "two original NDU methods")
    light = read(OWNER / "light-difference-selected.json")["selectors"]
    check(light == plan["light_extra_methods"] == sorted(extras - ndu) and len(light) == 110, "exact difference110 without NDU method replay")
    modules, inherited = {}, []
    def module_classes(module):
        if module not in modules:
            document = ast.parse(raw(ROOT / (module.replace(".", "/") + ".py")))
            modules[module] = (document, {node.name: node for node in document.body if isinstance(node, ast.ClassDef)})
        return modules[module]
    for identifier in sorted(scheduled):
        module, classname, method = identifier.rsplit(".", 2)
        document, classes = module_classes(module)
        check(classname in classes, "declared selected class " + identifier)
        cls = classes[classname]
        direct = {node.name for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        if method not in direct:
            check(module == "tests.test_hia_composite_returned_loans" and len(cls.bases) == 1, "known preserved inherited selector")
            base = cls.bases[0]
            check(isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name) and base.value.id == "_primitive_return_tests"
                  and base.attr == classname, "exact preserved base class")
            imports = [node for node in document.body if isinstance(node, ast.ImportFrom) and node.module == "tests"]
            check(any(alias.name == "hia_composite_primitive_returns" and alias.asname == "_primitive_return_tests"
                      for node in imports for alias in node.names), "exact preserved helper import")
            _, support = module_classes("tests.hia_composite_primitive_returns")
            direct = {node.name for node in support[classname].body if isinstance(node, ast.FunctionDef)}
            inherited.append(identifier)
        check(method in direct, "statically declared selected method " + identifier)
    check(len(inherited) == 13, "original thirteen inherited selector identities retained")
    after = source_snapshot()
    check(before == after and git("status", "--porcelain", "--untracked-files=all") == b"", "full source unchanged during static review")
    for path, row in inputs.items():
        check(ident(Path(path).read_bytes()) == {key: row[key] for key in ("bytes", "sha256", "git_blob")}, "review input stable " + path)
    result = {"schema": "hepta.nested-retention-static-integration-review.v1", "ok": True,
              "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
              "local_source": {"head": HEAD, "tree": TREE, "parent": RETENTION},
              "intended_public_parent": PUBLIC_PARENT, "public_commit_or_execution_claim": False,
              "read_only_checks": checks, "blocking_findings": [], "original_peer_inputs": peers,
              "cumulative_changed_files": 17, "component_files": {"retention": 5, "nested": 10},
              "component_source_sets_disjoint": True, "branch_only_allowlist_files": sorted(allowlists),
              "independent_public_parent_patch_reconstructed_tree": TREE,
              "all_7702_full_checkout_raw_git_bytes_modes_before_after_verified": True,
              "canonical_methods": 359, "capabilities": 36,
              "exact_differences": {"source92_outside359": 68, "native_protocol25": 25, "environment_protocol17": 17, "NDU_methods": 2},
              "distinct_method_union": 471, "light_difference_methods": 110,
              "statically_declared_method_ids": 471, "preserved_inherited_method_ids": inherited,
              "NDU_method_count_is_not_graph_invocation_count": True,
              "actual_host_matrices_are_separate_from_method_counts": True,
              "new_test_native_compiler_checker_or_oracle_executions": 0,
              "reviewer": "review_resume; independent of integration assembly and nested implementation",
              "retention_protocol_test_authorship_previously_disclosed": True,
              "python_production_authority": True, "optimization_policy": "no_change", "all_27_strict_blockers_open": True,
              "limits": ["Static composition preserves the independently reviewed component bytes; it is not an execution qualification of this integrated tree.",
                         "The intended public commit must receive its own actual source-bound qualification.",
                         "Earlier component results and corrected historical failures retain their original source identities."]}
    for name, value in [("source-inventory.json", before), ("input-manifest.json", {"files": inputs}), ("review.json", result)]:
        with (OUT / name).open("x") as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.write("\n")
    print(json.dumps({"ok": True, "read_only_checks": checks, "tree": TREE, "source_files": 7702, "static_method_union": 471, "new_executions": 0}))


if __name__ == "__main__":
    main()
