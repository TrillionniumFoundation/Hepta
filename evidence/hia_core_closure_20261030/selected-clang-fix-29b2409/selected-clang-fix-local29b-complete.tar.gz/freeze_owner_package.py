#!/usr/bin/env python3
"""Freeze owner originals and the separately authored independent review."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "full-release-clang-fix-package-20261030"
PREFIX = "evidence/hia_core_closure_20261030/selected-clang-fix-29b2409/"


def record(path, name=None):
    raw = path.read_bytes()
    return {"path": name or path.name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "git_blob_sha1": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
            "mode": "100644"}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2); stream.write("\n")


def main():
    peer_map = Path(sys.argv[1]).resolve()
    peer = json.loads(peer_map.read_text())
    OUT.mkdir(exist_ok=False)
    copied = HERE / "peer"
    copied.mkdir(exist_ok=False)
    payloads = peer.get("files", peer.get("payloads"))
    assert isinstance(payloads, list)
    readbacks = []
    for row in payloads:
        source = Path(row.get("local_path", row.get("source_path", row.get("path", ""))))
        if not source.is_absolute(): source = peer_map.parent / source
        name = Path(row.get("repository_path", row.get("path", source.name))).name
        destination = copied / name
        assert not destination.exists()
        shutil.copyfile(source, destination)
        observed = record(destination)
        assert observed["bytes"] == row["bytes"] and observed["sha256"] == row["sha256"]
        expected_blob = row.get("git_blob_sha1", row.get("git_blob"))
        if expected_blob: assert observed["git_blob_sha1"] == expected_blob
        readbacks.append({"source": str(source), "copy": str(destination), **observed})
    shutil.copyfile(peer_map, copied / "original-publication-files.json")
    save(copied / "copy-readback.json", {"all_peer_payload_bytes_match_original": True, "files": readbacks,
                                       "original_map": record(peer_map)})
    inputs = [p for p in sorted(HERE.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
    records = {p.relative_to(HERE).as_posix(): record(p, p.relative_to(HERE).as_posix()) for p in inputs}
    save(OUT / "retention.json", {"schema": "hepta.selected-clang-owner-retention.v1", "files": list(records.values()),
         "private_transport_included": False, "prior_official_failure_package_separately_retained": True})
    archive = OUT / "selected-clang-fix-local29b-complete.tar.gz"
    with archive.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
            with tarfile.open(fileobj=gz, mode="w|") as tar:
                for path in inputs:
                    name = path.relative_to(HERE).as_posix(); data = path.read_bytes()
                    member = tarfile.TarInfo(name)
                    member.size, member.mode, member.mtime = len(data), 0o644, 0
                    tar.addfile(member, io.BytesIO(data))
    actual = {}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            assert member.isfile() and member.name not in actual
            data = tar.extractfile(member).read()
            actual[member.name] = {"path": member.name, "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(), "mode": "100644"}
    assert actual == records
    with gzip.open(archive, "rb") as stream:
        while stream.read(1024 * 1024): pass
    for path in inputs:
        name = path.relative_to(HERE).as_posix(); assert record(path, name) == records[name]
    receipt = {"schema": "hepta.selected-clang-owner-archive.v1", "archive": record(archive), "members": len(actual),
         "all_members_exact_readback": True, "complete_gzip_crc_checked": True, "all_packaged_inputs_unchanged": True}
    save(OUT / "archive-receipt.json", receipt)
    payloads = [(archive, archive.name), (HERE / "README.md", "README.md"), (HERE / "summary.json", "summary.json"),
                (HERE / "source-export/manifest.json", "source-export/manifest.json"),
                (HERE / "source-export/source-change.patch", "source-export/source-change.patch"),
                (OUT / "retention.json", "retention.json"), (OUT / "archive-receipt.json", "archive-receipt.json")]
    entries = []
    for path, name in payloads:
        row = record(path, name); row.update(local_path=str(path), repository_path=PREFIX + name); entries.append(row)
    save(OUT / "publication-files.json", {"schema": "hepta.selected-clang-owner-publication.v1", "files": entries,
         "also_publish_this_map": True, "map_repository_path": PREFIX + "publication-files.json",
         "local_source": "29b2409a75c5f0df082c9ae64e993a0879f929c7", "public_parent": "5a0d1997b0bba8f8cb674b317ae1f56f0afcb22a",
         "root_only_remote_writer": True, "private_transport_excluded": True})
    print(json.dumps(receipt))


if __name__ == "__main__": main()
