"""Independently audit the minimal Clang-alias repair and its original records."""
from __future__ import annotations

import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

WORK = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
ROOT = WORK / "hepta-full-release-clang-env"
OWNER = WORK / "full-release-clang-fix-20261030"
TRIAGE = WORK / "full-release-failure-triage-20261030"
HEAD = "29b2409a75c5f0df082c9ae64e993a0879f929c7"
TREE = "a4f6eb52470fdce0601872be6e3814af9f83992c"
PARENT = "5a0d1997b0bba8f8cb674b317ae1f56f0afcb22a"
inputs = {}
checks = 0


def ident(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def raw(path):
    path = Path(path)
    data = path.read_bytes()
    inputs[str(path)] = {**ident(data), "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}
    return data


def read(path):
    return json.loads(raw(path))


def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)


def git(*args, env=None):
    return subprocess.check_output(["git", "--no-replace-objects", "-C", str(ROOT), *args], env=env)


def main():
    started = datetime.now(timezone.utc).isoformat()
    check(not (OUT / "review.json").exists(), "fresh audit")
    check(git("rev-parse", "HEAD").decode().strip() == HEAD, "head")
    check(git("rev-parse", "HEAD^{tree}").decode().strip() == TREE, "tree")
    check(git("rev-parse", "HEAD^").decode().strip() == PARENT, "public parent")
    check(git("status", "--porcelain=v1") == b"", "clean source")
    export = read(OWNER / "source-export/manifest.json")
    changed = git("diff", "--name-only", PARENT, HEAD).decode().splitlines()
    check(set(changed) == {r["path"] for r in export["files"]} and len(changed) == 4, "exact four-file export")
    for row in export["files"]:
        data = raw(Path(row["local_path"]))
        check(data.decode().encode() == data and row["content"].encode() == data, "UTF8 export " + row["path"])
        check(data == git("show", HEAD + ":" + row["path"]) == raw(ROOT / row["path"]), "raw Git/worktree " + row["path"])
        check(ident(data) == {"bytes": row["bytes"], "sha256": row["sha256"], "git_blob": row["git_blob_sha1"]}, "export identity")
        check(git("ls-tree", HEAD, "--", row["path"]).decode().split()[0] == row["mode"], "export Git mode")
    patch = OWNER / "source-export/source-change.patch"
    raw(patch)
    with tempfile.TemporaryDirectory(prefix="hepta-clang-review-index-") as temporary:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / "index"))
        git("read-tree", PARENT, env=env)
        git("apply", "--cached", "--check", str(patch), env=env)
        git("apply", "--cached", str(patch), env=env)
        check(git("write-tree", env=env).decode().strip() == TREE, "independent patch tree reconstruction")
    old = ast.parse(git("show", PARENT + ":tools/qualify_hia_unified.py"))
    new = ast.parse(raw(ROOT / "tools/qualify_hia_unified.py"))
    removed = 0
    for node in ast.walk(new):
        if isinstance(node, ast.Dict):
            for index in reversed(range(len(node.keys))):
                if isinstance(node.keys[index], ast.Constant) and node.keys[index].value == "HEPTA_CLANG":
                    check(isinstance(node.values[index], ast.Name) and node.values[index].id == "clang", "same explicit selected compiler")
                    del node.keys[index]
                    del node.values[index]
                    removed += 1
    check(removed == 1 and ast.dump(new) == ast.dump(old), "sole qualifier semantic delta is same-value alias")
    workflow = ".github/workflows/hepta-qualification.yml"
    old_w = git("show", PARENT + ":" + workflow).decode()
    new_w = raw(ROOT / workflow).decode()
    old_line = "printf 'LEAN=%s\\nCLANG=%s\\nCLANGXX=%s\\nCC=%s\\n' \"$hepta_lean\" /usr/lib/llvm-20/bin/clang /usr/lib/llvm-20/bin/clang++ /usr/bin/gcc"
    new_line = "printf 'LEAN=%s\\nCLANG=%s\\nHEPTA_CLANG=%s\\nCLANGXX=%s\\nCC=%s\\n' \"$hepta_lean\" /usr/lib/llvm-20/bin/clang /usr/lib/llvm-20/bin/clang /usr/lib/llvm-20/bin/clang++ /usr/bin/gcc"
    check(old_w.count(old_line) == 1 and old_w.replace(old_line, new_line) == new_w, "sole workflow delta same absolute compiler")
    unchanged = ["tests/test_hia_ndu_convergence.py", "tools/release_check.py",
                 "tools/qualify_hia_safety_contract.py", "docs/HIA_SAFETY_CONTRACT.json",
                 "hepta/hia_program_source.py"]
    for name in unchanged:
        check(git("show", PARENT + ":" + name) == git("show", HEAD + ":" + name), "unchanged gate/runtime/selector " + name)
    for name in ["tests/test_qualification_environment.py", "tests/test_hia_unified_qualification.py"]:
        def tests(data):
            return sorted(n.name for n in ast.walk(ast.parse(data)) if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"))
        check(tests(git("show", PARENT + ":" + name)) == tests(git("show", HEAD + ":" + name)), "same test method population " + name)

    scopes = []
    for label, head, skip, graph in [("parent5a0d-red", PARENT, 2, 0), ("local29b-green", HEAD, 0, 1)]:
        base = OWNER / label
        receipt = read(base / "receipt.json")
        worker = read(base / "actual-two-methods/worker-result.json")
        environment = read(base / "actual-two-methods/actual-environment.json")
        invocation = read(base / "actual-two-methods/graph-invocations.json")
        events = read(base / "actual-two-methods/method-events.json")
        qualifier = read(base / "selected-qualifier/qualification.json")
        before, after = read(base / "source-before.json"), read(base / "source-after.json")
        check(receipt["source"]["head"] == head and before["identity"] == after["identity"] == receipt["source"], "frozen source " + label)
        check(before["files"] == after["files"] and len(before["files"]) == 1024, "1024 actual materialized source " + label)
        check(before["tracked_tree_files"] == 7699 and len(before["unmaterialized_not_execution_coverage"]) == 6675, "honest sparse scope")
        for name, row in before["files"].items():
            data = git("show", head + ":" + name)
            check(ident(data) == {k: row[k] for k in ("bytes", "sha256", "git_blob")}, "snapshot raw Git " + name)
            check(git("ls-tree", head, "--", name).decode().split()[0] == row["mode"], "snapshot mode " + name)
        check(read(base / "external-before.json") == read(base / "external-after.json"), "same selected real tools " + label)
        expected = {"run": 2, "skipped": skip, "failures": 0, "errors": 0, "expected_failures": 0, "unexpected_successes": 0}
        check(worker == receipt["tests"] == expected, "actual two original methods " + label)
        check(len(invocation) == receipt["native_graph_invocations"] == graph, "original graph invocation count")
        check(environment["z3_available"] and environment["CLANG"], "other prerequisites available")
        check((environment["HEPTA_CLANG"] is None) if skip else (environment["HEPTA_CLANG"] == environment["CLANG"]), "actual inherited compiler names")
        check(environment["actual_class_skip_flag"] == bool(skip), "unchanged actual decorator outcome")
        check(qualifier["planned_gates"] == ["unit_regression"] and len(qualifier["gates"]) == 1, "explicit external narrow plan")
        check(qualifier["ok"] == receipt["original_qualifier_accepted_selected_population"] == (skip == 0), "original strict gate rejects skips")
        check(receipt["environment_restored"] and receipt["working_directory_restored"], "original environment restoration")
        starts = [r["method"] for r in events if r["event"] == "start"]
        outcomes = [r["method"] for r in events if r["event"] == ("skipped" if skip else "passed")]
        check(len(starts) == len(set(starts)) == 2 and Counter(starts) == Counter(outcomes), "original exact method events")
        check(receipt["full_37_gate_run"] is False and receipt["full_4335_population_replayed"] is False, "bounded gate scope")
        scopes.append({"source": head, "methods": worker, "graph_calls": graph})

    graph_root = OWNER / "local29b-green/actual-two-methods/original-graph"
    graph = read(graph_root / "RESULT.json")
    retained = read(OWNER / "local29b-green/actual-two-methods/graph-retention.json")
    for row in retained:
        data = raw(graph_root / row["path"])
        check(len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"], "retained graph original " + row["path"])
    expected_arms = {"fixed-base", "fixed-small", "fixed-wide", "fixed-best-plan", "light", "ndu", "q32-dp", "ndu-compact"}
    check({r["arm"] for r in graph["episodes"]} == expected_arms and len(graph["episodes"]) == 8, "actual eight arms")
    check(graph["all_episodes_completed"] and graph["all_outputs_correct"] and graph["all_actual_budgets_passed"], "actual graph gates")
    call = read(OWNER / "local29b-green/actual-two-methods/graph-invocations.json")[0]
    original_root = Path(call["output_argument"])
    observations = 0
    for episode in graph["episodes"]:
        check(episode["status"] == "completed", "episode completed")
        for row in episode["observations"]:
            observations += 1
            check(row["returncode"] == 0 and row["execution_attempted"] and row["status"] == "measured", "actual native sample")
            check(row["loaded_snapshot_sealed"] and row["loaded_mapping_verified"], "observed artifact custody")
            check(row["artifact_sha256"] == row["expected_artifact_sha256"], "selected artifact identity")
            artifact = graph_root / Path(row["artifact_source_path"]).relative_to(original_root)
            check(hashlib.sha256(raw(artifact)).hexdigest() == row["artifact_sha256"], "actual retained native bytes")
            value = json.loads(row["stdout"])
            check(value["checksum"] == row["checksum"] == row["expected_checksum"], "actual raw output correctness")
    check(observations == 32, "finite artifact observation count")
    check(set(graph["native_sessions"]) == {"ndu", "ndu-compact"}, "two native representations")
    pids = set()
    for name, session in graph["native_sessions"].items():
        pids.add(session["pid"])
        check(session["closed"] and session["cleanup_errors"] == [], "actual session closed " + name)
        check(session["image_check_profile"] == "sealed" and session["image_identity_checks"] == 13, "actual image checks")
        check(session["authority"] == "DENY_ALL" and session["safety_certificate"] is False, "no NDU admission authority")
    check(len(pids) == 2, "distinct native sessions")
    check(graph["authority"] == "DENY_ALL" and graph["statistical_superiority_established"] is False and graph["global_optimality_claim"] is False, "finite composition not performance promotion")
    protocols = read(OWNER / "local29b-protocols/receipt.json")
    method_ids = read(OWNER / "local29b-protocols/method-events.json")
    check(protocols["source"]["head"] == HEAD and protocols["tests"] == {"run": 17, "failures": 0, "errors": 0, "skipped": 0, "expected_failures": 0, "unexpected_successes": 0}, "17 actual related methods")
    log = raw(OWNER / "local29b-protocols/tests.log").decode()
    actual_ids = re.findall(r"(?m)^test_[^ ]+ \((tests\.[^)]+)\) \.\.\. ok$", log)
    check(Counter(method_ids) == Counter(actual_ids) and len(actual_ids) == len(set(actual_ids)) == 17, "actual protocol verbose events")
    red_log = raw(OWNER / "regression-red.stderr.log").decode()
    check("Ran 2 tests" in red_log and "FAILED (failures=2)" in red_log, "original enhanced-regression red preserved")
    check("/ambient/unused clang" in red_log and "/ambient/other-clang" in red_log, "red causal stale environment assertions")
    triage = read(TRIAGE / "triage.json")
    official = []
    for row, directory in zip(triage["rows"], ["e0-selected", "b121-selected"]):
        check(row["workflow_conclusion"] == "failure", "official failure retained")
        root = TRIAGE / directory / "members"
        logs = {"candidate": raw(root / "Hepta/Hepta/artifacts/candidate/unit_and_integration.log").decode(),
                "standalone": raw(root / "Hepta/Hepta/artifacts/hia-unified/unit_regression.stderr.log").decode()}
        integrated = read(root / "_temp/hepta-integrated/qualification.json")
        for label, log_original in logs.items():
            check(hashlib.sha256(log_original.encode()).hexdigest() == row["unit_logs"][label]["sha256_utf8"], "official original log identity")
            check(re.search(r"(?m)^Ran 4335 tests in ", log_original) is not None, "actual original denominator")
            check(row["unit_logs"][label]["terminal_outcomes"][0] in log_original, "actual original terminal outcome")
        check(len(row["unit_logs"]["candidate"]["actual_verbose_skip_headings"]) == 2, "verbose named skip evidence")
        check(row["unit_logs"]["standalone"]["actual_verbose_skip_headings"] == [], "quiet source attribution not verbatim method evidence")
        official.append({"source": row["source"], "run": row["run"], "status": "failure",
                         "candidate_terminal": row["unit_logs"]["candidate"]["terminal_outcomes"],
                         "standalone_terminal": row["unit_logs"]["standalone"]["terminal_outcomes"],
                         "integrated_terminal": row["unit_logs"]["integrated"]["terminal_outcomes"]})
    for name, row in inputs.items():
        check(ident(Path(name).read_bytes()) == {k: row[k] for k in ("bytes", "sha256", "git_blob")}, "input unchanged " + name)
    result = {"schema": "hepta.selected-clang-fix-independent-review.v1", "ok": True,
              "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
              "source": {"head": HEAD, "tree": TREE, "public_parent": PARENT},
              "blocking_findings": [], "read_only_checks": checks,
              "source_change": "Same explicitly selected Clang is exported as CLANG and HEPTA_CLANG; original finally restoration applies to both.",
              "sole_production_deltas": ["one workflow export line", "one unified environment dictionary entry"],
              "unchanged_decorator_zero_skip_protocol_source_admission_and_349_selection": True,
              "actual_red_green": scopes, "green_graph_arms": 8, "green_artifact_bound_observations": observations,
              "green_distinct_sealed_native_sessions": 2, "green_related_protocol_methods": 17,
              "actual_materialized_source_files": 1024, "full_git_tree_files": 7699,
              "unmaterialized_paths_not_execution_coverage": 6675,
              "original_failed_official_runs": official,
              "full_original_artifact_bytes_not_reacquired_by_this_review": True,
              "new_native_or_test_invocations_by_reviewer": 0,
              "source_patch_independently_reproduces_tree": True,
              "no_full_4335_or_full_37_gate_replay_claim": True,
              "public_same_tree_execution_still_requires_its_own_identity": True,
              "python_production_authority": True, "optimization_policy": "no_change", "all_27_strict_blockers_open": True}
    (OUT / "input-manifest.json").write_text(json.dumps({"files": inputs}, sort_keys=True, indent=2) + "\n")
    (OUT / "review.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"ok": True, "source": HEAD, "read_only_checks": checks, "graph_arms": 8,
                      "native_observations": observations, "protocol_methods": 17, "report": str(OUT / "review.json")}))


if __name__ == "__main__":
    main()
