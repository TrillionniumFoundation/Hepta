#!/usr/bin/env python3
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

WORK = Path(__file__).resolve().parent.parent
ROOT = WORK / "hepta-full-release-clang-env"
OUT = Path(__file__).resolve().parent / "local29b-protocols"
HEAD = "29b2409a75c5f0df082c9ae64e993a0879f929c7"


def git(*args): return subprocess.check_output(["git", "--no-replace-objects", "-C", str(ROOT), *args])
def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write("\n")
def identity():
    value = {"head": git("rev-parse", "HEAD").decode().strip(), "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
             "status": git("status", "--porcelain").decode(), "files": {}}
    for row in git("ls-tree", "-rz", "HEAD").split(b"\0"):
        if not row: continue
        meta, name = row.split(b"\t", 1); mode, kind, blob = meta.decode().split(); name = name.decode()
        path = ROOT / name
        if not path.exists(): continue
        data = path.read_bytes()
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == blob
        actual_mode = "100755" if path.stat().st_mode & 0o111 else "100644"
        assert actual_mode == mode and kind == "blob"
        value["files"][name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "mode": mode, "git_blob": blob}
    return value


OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT)); os.chdir(ROOT)
before = identity(); assert before["head"] == HEAD and before["status"] == ""
save("source-before.json", before)
started = datetime.now(timezone.utc).isoformat()
modules = ["tests.test_qualification_environment", "tests.test_hia_unified_qualification", "tests.test_hia_unified_workflow_cli"]
suite = unittest.defaultTestLoader.loadTestsFromNames(modules)
def flatten(items):
    for item in items:
        if isinstance(item, unittest.TestSuite): yield from flatten(item)
        else: yield item.id()
selected = list(flatten(suite)); assert len(selected) == len(set(selected))
save("selected-methods.json", selected)
events = []
class EventResult(unittest.TextTestResult):
    def startTest(self, test): events.append(test.id()); super().startTest(test)
with (OUT / "tests.log").open("x") as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=EventResult).run(suite)
summary = {"run": result.testsRun, "errors": len(result.errors), "failures": len(result.failures),
           "skipped": len(result.skipped), "expected_failures": len(result.expectedFailures), "unexpected_successes": len(result.unexpectedSuccesses)}
after = identity(); save("source-after.json", after)
save("method-events.json", events)
receipt = {"schema": "hepta.selected-clang-related-protocols.v1", "source": {k:v for k,v in before.items() if k != "files"},
           "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(), "tests": summary,
           "exact_once": events == selected, "source_unchanged": before == after,
           "materialized_source_files": len(before["files"]),
           "scope": "Existing collector/workflow protocol tests; native graph qualification is recorded separately.",
           "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
save("receipt.json", receipt)
print(json.dumps(receipt))
assert events == selected and before == after and result.testsRun == len(selected)
assert not any(summary[k] for k in summary if k != "run")
