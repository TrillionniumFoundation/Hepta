#!/usr/bin/env python3
"""Observe the existing selected-compiler environment with one explicit two-method plan.

The original unified qualifier and its real subprocess runner are used. Only
its external plan selection is narrowed; this is never a complete 37-gate run.
"""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import unittest
from unittest.mock import patch

WORK = Path(__file__).resolve().parent.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def worker(root, output):
    sys.path.insert(0, str(root))
    from tests import test_hia_ndu_convergence as module
    selected = unittest.defaultTestLoader.getTestCaseNames(module.ConvergedNativeGraphTests)
    assert len(selected) == 2
    save(output / "actual-environment.json", {
        "CLANG": os.environ.get("CLANG"), "HEPTA_CLANG": os.environ.get("HEPTA_CLANG"),
        "HEPTA_NDU_STREAM_IDENTITY": os.environ.get("HEPTA_NDU_STREAM_IDENTITY"),
        "z3_available": importlib.util.find_spec("z3") is not None,
        "module_sha256": sha(module.__file__), "selected_methods": selected,
        "actual_class_skip_flag": bool(getattr(module.ConvergedNativeGraphTests, "__unittest_skip__", False))})
    original = module.qualify
    invocations = []

    def observe(*args, **kwargs):
        row = {"output_argument": str(args[0]), "identity": kwargs["identity"],
               "clang": kwargs["clang"], "protocol": kwargs["protocol"],
               "decision_cache_entries": kwargs["decision_cache_entries"]}
        invocations.append(row)
        try:
            value = original(*args, **kwargs)
            row["returned_original_result"] = True
            return value
        except BaseException as error:
            row["exception"] = {"type": type(error).__name__, "message": str(error)}
            raise
        finally:
            original_output = Path(args[0])
            if original_output.exists():
                shutil.copytree(original_output, output / "original-graph")
                originals = []
                for path in sorted(original_output.rglob("*")):
                    if path.is_file():
                        copy = output / "original-graph" / path.relative_to(original_output)
                        assert copy.read_bytes() == path.read_bytes()
                        originals.append({"path": path.relative_to(original_output).as_posix(),
                                          "bytes": path.stat().st_size, "sha256": sha(path)})
                save(output / "graph-retention.json", originals)

    events = []
    class Events(unittest.TextTestResult):
        def startTest(self, test):
            events.append({"method": test.id(), "event": "start"})
            super().startTest(test)
        def addSuccess(self, test):
            events.append({"method": test.id(), "event": "passed"})
            super().addSuccess(test)
        def addSkip(self, test, reason):
            events.append({"method": test.id(), "event": "skipped", "reason": reason})
            super().addSkip(test, reason)
        def addFailure(self, test, error):
            events.append({"method": test.id(), "event": "failed"})
            super().addFailure(test, error)
        def addError(self, test, error):
            events.append({"method": test.id(), "event": "error"})
            super().addError(test, error)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.ConvergedNativeGraphTests)
    with patch.object(module, "qualify", side_effect=observe):
        result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2, resultclass=Events).run(suite)
    save(output / "method-events.json", events)
    save(output / "graph-invocations.json", invocations)
    summary = {"run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
               "skipped": len(result.skipped), "expected_failures": len(result.expectedFailures),
               "unexpected_successes": len(result.unexpectedSuccesses)}
    save(output / "worker-result.json", summary)
    return 0 if result.wasSuccessful() else 1


def main(root, output, expected_head, expected):
    root, output = root.resolve(), output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    environment = json.loads((WORK / "guard-fix-validation-20261030/public-b121-safety-environment.json").read_text())
    os.environ.update(environment)
    if expected == "red":
        os.environ.pop("HEPTA_CLANG", None)
    else:
        os.environ["HEPTA_CLANG"] = "/unexecuted/ambient-clang-must-not-win"
    os.environ["PYTHONPATH"] = str(root) + os.pathsep + environment["PYTHONPATH"]
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(WORK / "toolchains/z3-4.15.4"))
    helper_path = WORK / "integration-405-independent-review/review_f654_source.py"
    spec = importlib.util.spec_from_file_location("frozen_source_bytes_reader", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.ROOT, helper.HEAD = root, expected_head
    count = 0
    def check(label, actual, expected=True):
        nonlocal count
        count += 1
        if actual != expected: raise AssertionError(label)
    helper.check = check
    state = helper.state()
    assert state["head"] == expected_head and state["status"] == ""
    all_entries = helper.tree()
    present = {name: row for name, row in all_entries.items() if (root / name).exists() or (root / name).is_symlink()}
    source = helper.snapshot(present)
    save(output / "source-before.json", {"identity": state, "files": source,
         "tracked_tree_files": len(all_entries), "materialized_files": len(present),
         "unmaterialized_not_execution_coverage": sorted(set(all_entries) - set(present))})
    from tools import qualify_hia_unified as unified
    clang = environment["CLANG"]
    stream_identity = Path(environment["HEPTA_NDU_STREAM_IDENTITY"])
    stream_manifest = json.loads(stream_identity.read_text())
    external = [Path(clang), stream_identity, Path(stream_manifest["binary"]),
                WORK / "toolchains/z3-4.15.4/z3/lib/libz3.so"]
    before_external = {str(path): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in external}
    save(output / "external-before.json", before_external)
    actual = output / "actual-two-methods"
    actual.mkdir()
    plan = [("unit_regression", [sys.executable, str(Path(__file__).resolve()), "--worker", str(root), str(actual)], None)]
    selected = dict(clang=clang, cc=shutil.which("gcc"), rustc=environment["RUSTC"],
        cargo=str(WORK / "toolchains/rust-1.90.0/bin/cargo"), qemu_aarch64="/unexecuted/qemu-aarch64",
        qemu_riscv64="/unexecuted/qemu-riscv64", qemu_system_arm="/unexecuted/qemu-system-arm",
        linker=environment["HEPTA_LLD"], lean="/unexecuted/lean", cxx=shutil.which("g++"))
    ambient = dict(os.environ)
    cwd = Path.cwd()
    with patch.object(unified, "qualification_plan", return_value=plan):
        report = unified.qualify(output / "selected-qualifier", **selected)
    assert dict(os.environ) == ambient and Path.cwd() == cwd
    observed = json.loads((actual / "actual-environment.json").read_text())
    summary = json.loads((actual / "worker-result.json").read_text())
    assert summary["run"] == 2 and not any(summary[k] for k in ["failures", "errors", "expected_failures", "unexpected_successes"])
    assert observed["CLANG"] == clang and observed["z3_available"]
    calls = json.loads((actual / "graph-invocations.json").read_text())
    if expected == "red":
        assert summary["skipped"] == 2 and observed["HEPTA_CLANG"] is None and not calls and not report["ok"]
    else:
        assert summary["skipped"] == 0 and observed["HEPTA_CLANG"] == clang and len(calls) == 1 and report["ok"]
    assert report["planned_gates"] == ["unit_regression"] and report["unchanged_source"]
    after_external = {str(path): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in external}
    assert after_external == before_external
    save(output / "external-after.json", after_external)
    after = helper.snapshot(present)
    assert source == after and state == helper.state()
    save(output / "source-after.json", {"identity": helper.state(), "files": after})
    receipt = {"schema": "hepta.selected-clang-original-two-method-execution.v1", "expected": expected,
        "source": state, "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "producer_sha256": sha(__file__), "unified_source_sha256": sha(unified.__file__),
        "original_method_module_sha256": sha(root / "tests/test_hia_ndu_convergence.py"),
        "tests": summary, "original_qualifier_accepted_selected_population": report["ok"],
        "environment_restored": True, "working_directory_restored": True,
        "source_and_external_unchanged": True, "raw_git_checks": count,
        "materialized_source_files": len(present), "full_git_tree_files": len(all_entries),
        "native_graph_invocations": len(calls), "full_37_gate_run": False,
        "full_4335_population_replayed": False, "rust_crate_rebuilt": False,
        "narrow_plan_is_external_observation_only": True,
        "claims": {"whole_project_qualified": False, "performance_advantage_established": False,
                   "production_authority_switched": False},
        "limits": ["Only the existing two convergence methods execute in the selected plan. Production qualifier and subprocess implementation are unchanged except the reviewed environment-key fix.",
                   "The observer calls the original graph producer exactly once with its original arguments and returns the same result; it preserves graph artifacts before original test cleanup.",
                   "Other plan tool arguments marked /unexecuted are not required or qualified by this selected execution."]}
    save(output / "receipt.json", receipt)
    print(json.dumps({"expected": expected, "source": expected_head, "tests": summary,
                      "accepted": report["ok"], "graph_invocations": len(calls)}))


if __name__ == "__main__":
    if sys.argv[1] == "--worker":
        raise SystemExit(worker(Path(sys.argv[2]), Path(sys.argv[3])))
    main(Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], sys.argv[4])
