#!/usr/bin/env python3
"""Read exact ZIP ranges for selected original CI members; never retain signed URLs."""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import time
import urllib.request
import zipfile


class RemoteRanges(io.RawIOBase):
    def __init__(self, url, size):
        self.url, self.size, self.position = url, size, 0
        self.receipts = []
    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.position
    def seek(self, offset, whence=0):
        target = offset if whence == 0 else self.position + offset if whence == 1 else self.size + offset
        if target < 0: raise OSError("Negative ZIP seek")
        self.position = target
        return target
    def read(self, size=-1):
        amount = self.size - self.position if size < 0 else min(size, self.size - self.position)
        if amount <= 0: return b""
        if amount > 8 * 1024 * 1024: raise OSError("Selective ZIP read exceeds 8 MiB limit")
        start, end = self.position, self.position + amount - 1
        request = urllib.request.Request(self.url, headers={"Range": f"bytes={start}-{end}", "User-Agent": "Hepta-CI-selective-original-readback"})
        started = time.monotonic_ns()
        with urllib.request.urlopen(request, timeout=45) as response:
            if response.status != 206: raise OSError("Server did not honor selective byte range")
            if response.headers.get("Content-Range") != f"bytes {start}-{end}/{self.size}":
                raise OSError("Remote content-range identity mismatch")
            body = response.read(amount + 1)
            if len(body) != amount or response.read(1): raise OSError("Remote range byte-count mismatch")
            etag = response.headers.get("ETag")
        self.position += len(body)
        self.receipts.append({"start": start, "end": end, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(),
                              "http_status": 206, "etag": etag, "wall_ns": time.monotonic_ns() - started})
        return body


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=int, required=True)
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--select", action="append", default=[])
    args = parser.parse_args()
    private = Path(__file__).resolve().parent.parent / "full-release-failure-private-transport" / (str(args.artifact) + ".json")
    transport = json.loads(private.read_text())
    assert transport["artifact_id"] == args.artifact
    args.output.mkdir(parents=True, exist_ok=False)
    ranges = RemoteRanges(transport["download_url"], args.size)
    with zipfile.ZipFile(ranges) as archive:
        members = archive.infolist()
        inventory = [{"name": m.filename, "uncompressed_bytes": m.file_size, "compressed_bytes": m.compress_size,
                      "crc32": f"{m.CRC:08x}", "compression": m.compress_type, "local_header_offset": m.header_offset} for m in members]
        (args.output / "zip-directory.json").write_text(json.dumps(inventory, indent=2) + "\n")
        extracted = []
        for member in members:
            if not any(re.search(pattern, member.filename) for pattern in args.select): continue
            path = Path(member.filename)
            assert not path.is_absolute() and ".." not in path.parts and not member.is_dir()
            assert member.file_size <= 30 * 1024 * 1024 and member.compress_size <= 8 * 1024 * 1024
            body = archive.read(member)
            assert len(body) == member.file_size
            destination = args.output / "members" / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(body)
            extracted.append({"name": member.filename, "path": str(destination), "bytes": len(body),
                              "sha256": hashlib.sha256(body).hexdigest(), "crc32": f"{member.CRC:08x}",
                              "zip_member_crc_checked": True})
        receipt = {"schema": "hepta.selective-official-zip-readback.v1", "artifact_id": args.artifact,
                   "official_zip_bytes": args.size, "directory_members": len(members), "ranges": ranges.receipts,
                   "downloaded_range_bytes": sum(r["bytes"] for r in ranges.receipts), "members": extracted,
                   "whole_zip_downloaded_or_whole_zip_sha256_verified": False,
                   "signed_transport_published": False, "native_test_or_build_invocations": 0}
        (args.output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({"artifact": args.artifact, "directory_members": len(members),
                          "downloaded_bytes": receipt["downloaded_range_bytes"], "selected_members": len(extracted)}))
        if not args.select:
            for m in inventory:
                if re.search(r"(unit.*(?:log|json)|full.regression|(?:candidate|hia|integrated)/.*(?:summary|qualification|report|release).json)$", m["name"]):
                    print(json.dumps(m))


if __name__ == "__main__":
    main()
