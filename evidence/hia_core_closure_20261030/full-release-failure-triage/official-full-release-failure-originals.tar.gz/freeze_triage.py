#!/usr/bin/env python3
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "full-release-failure-triage-package-20261030"
PREFIX = "evidence/hia_core_closure_20261030/full-release-failure-triage/"


def row(path, name=None):
    b = path.read_bytes()
    return {"path": name or path.name, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(),
            "git_blob_sha1": hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest(), "mode": "100644"}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def main():
    OUT.mkdir(exist_ok=False)
    inputs = [p for p in sorted(HERE.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
    original = {p.relative_to(HERE).as_posix(): row(p, p.relative_to(HERE).as_posix()) for p in inputs}
    manifest = {"schema": "hepta.full-release-failure-retention.v1", "files": list(original.values()),
                "complete_selected_members_retained": True, "complete_official_zip_retained": False,
                "private_transport_retained": False, "native_tests_or_builds": 0}
    save(OUT / "retention.json", manifest)
    archive = OUT / "official-full-release-failure-originals.tar.gz"
    with archive.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
            with tarfile.open(fileobj=gz, mode="w|") as tar:
                for p in inputs:
                    name = p.relative_to(HERE).as_posix()
                    data = p.read_bytes()
                    item = tarfile.TarInfo(name)
                    item.size, item.mode, item.mtime = len(data), 0o644, 0
                    tar.addfile(item, io.BytesIO(data))
    restored = {}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            assert member.isfile() and member.name not in restored
            b = tar.extractfile(member).read()
            restored[member.name] = {"path": member.name, "bytes": len(b),
                "sha256": hashlib.sha256(b).hexdigest(),
                "git_blob_sha1": hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest(), "mode": "100644"}
    assert restored == original
    with gzip.open(archive, "rb") as stream:
        while stream.read(1024 * 1024): pass
    for p in inputs: assert row(p, p.relative_to(HERE).as_posix()) == original[p.relative_to(HERE).as_posix()]
    receipt = {"schema": "hepta.full-release-failure-package.v1", "archive": row(archive),
               "members": len(original), "all_members_exact_readback": True, "complete_gzip_crc_checked": True,
               "source_and_original_records_unchanged_during_packaging": True}
    save(OUT / "archive-receipt.json", receipt)
    items = [(archive, archive.name), (HERE / "README.md", "README.md"),
             (HERE / "triage.json", "triage.json"), (OUT / "retention.json", "retention.json"),
             (OUT / "archive-receipt.json", "archive-receipt.json")]
    files = []
    for p, name in items:
        item = row(p, name)
        item.update(local_path=str(p), repository_path=PREFIX + name)
        files.append(item)
    save(OUT / "publication-files.json", {"schema": "hepta.full-release-failure-publication.v1", "files": files,
         "also_publish_this_map": True, "map_repository_path": PREFIX + "publication-files.json",
         "both_official_workflows_remain_failed": True, "root_only_remote_writer": True,
         "private_transport_excluded": True})
    print(json.dumps(receipt))


if __name__ == "__main__": main()
