"""Independent read-only source and original-native-record audit; no oracle replay."""
from __future__ import annotations

import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile

WORK = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
OWNER = WORK / "native-abi-artifact-retention-20261030"
ROOT = WORK / "hepta-native-artifact-retention"
HEAD = "2f4891ce7c5b92979ffb4c65575075367a1ecb15"
TREE = "bc41b0509bd343821a985cae7f22bcb338897cef"
PARENT = "a6cfb7e00a1c08276d27459bdcc5628aa7622079"
ROLES = ["rust_object", "driver_O0", "driver_O2", "wrong_echo"]
inputs, tree_cache, blob_cache = {}, {}, {}
checks = 0


def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)


def ident(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def raw(path):
    path = Path(path)
    data = path.read_bytes()
    inputs[str(path)] = {**ident(data), "mode": stat.S_IMODE(path.stat().st_mode)}
    return data


def read(path):
    return json.loads(raw(path))


def git(*args, env=None):
    return subprocess.check_output(["git", "--no-replace-objects", "-C", str(ROOT), *args], env=env)


def tree(head):
    if head not in tree_cache:
        rows = {}
        for item in git("ls-tree", "-rz", head).split(b"\0"):
            if item:
                meta, name = item.split(b"\t", 1)
                mode, kind, blob = meta.decode().split()
                check(kind == "blob", "tracked blob kind")
                rows[name.decode()] = (mode, blob)
        tree_cache[head] = rows
    return tree_cache[head]


def load_blobs(blobs):
    missing = sorted(set(blobs) - blob_cache.keys())
    if not missing:
        return
    process = subprocess.run(["git", "--no-replace-objects", "-C", str(ROOT), "cat-file", "--batch"],
                             input=("\n".join(missing) + "\n").encode(), capture_output=True, check=True)
    position = 0
    for expected in missing:
        end = process.stdout.index(b"\n", position)
        actual, kind, count = process.stdout[position:end].decode().split()
        size = int(count)
        check(actual == expected and kind == "blob", "raw Git object header")
        data = process.stdout[end + 1:end + 1 + size]
        check(ident(data)["git_blob_sha1"] == expected and process.stdout[end + 1 + size:end + 2 + size] == b"\n",
              "raw Git object body")
        blob_cache[expected] = data
        position = end + 2 + size
    check(position == len(process.stdout), "complete Git batch framing")


def source_snapshot(before, after, head, count):
    check(before == after and before["head"] == head, "execution source snapshots stable")
    check(before["tree"] == git("rev-parse", head + "^{tree}").decode().strip(), "snapshot tree")
    tracked = tree(head)
    if "materialized_files" in before:
        entries = {row["path"]: row for row in before["materialized_files"]}
        check(len(entries) == len(before["materialized_files"]) == count, "exact materialized native source population")
        check(set(before["unmaterialized_sparse_paths"]) == set(tracked) - set(entries), "sparse paths explicitly excluded")
    else:
        entries = {name: {**row, "git_blob_sha1": row["git_blob"]} for name, row in before["files"].items()}
        check(before["status"] == "" and len(entries) == count, "clean protocol source population")
    check(set(entries) <= set(tracked), "materialized source belongs to tree")
    load_blobs(tracked[name][1] for name in entries)
    for name, row in entries.items():
        mode, blob = tracked[name]
        check(row["mode"] == mode and row["git_blob_sha1"] == blob, "source tree binding " + name)
        check({key: row[key] for key in ("bytes", "sha256", "git_blob_sha1")} == ident(blob_cache[blob]), "source raw bytes " + name)
        if head == HEAD:
            path = ROOT / name
            check(path.is_file() and not path.is_symlink(), "materialized ordinary source " + name)
            check(path.read_bytes() == blob_cache[blob] and ("100755" if path.stat().st_mode & 0o111 else "100644") == mode,
                  "current materialized bytes/mode " + name)


def native_record(base, head, family, retained_count):
    report, receipt, process = read(base / "native-host.json"), read(base / "receipt.json"), read(base / "process.json")
    before, after = read(base / "source-before.json"), read(base / "source-after.json")
    source_snapshot(before, after, head, 1426 if head == HEAD else 1425)
    check(receipt["source_head"] == head and receipt["source_tree"] == before["tree"], "native receipt source")
    check(process["returncode"] == 0 and process["cwd"] == str(ROOT), "actual native process completed")
    check(process["argv"][2] == str(ROOT / "tools/validate_native_host.py")
          and process["argv"][-1] == str(base / "native-host.json"), "actual unmodified CLI invocation")
    check(report["schema"] == "hepta.native-host.v2" and report["status"] == "passed", "original ABI schema and success")
    check(report["host"]["system"] == "Linux" and report["host"]["machine"] == "x86_64"
          and report["host"]["execution"] == "native_host_process", "finite actual host")
    check(report["c_compiler"]["family"] == family == receipt["actual_c_family"], "actual compiler family")
    claims = {"actual_reported_host_executed": True, "cross_host_results_inferred": False,
              "physical_board_executed": False, "gpu_device_executed": False, "all_abi_features_qualified": False}
    check(report["claims"] == claims, "unchanged finite claims")
    tools_before, tools_after = read(base / "tools-before.json"), read(base / "tools-after.json")
    check(tools_before == tools_after and len(tools_before) == 3, "native tool provenance stable")
    for tool in tools_before:
        path = Path(tool["path"])
        data = raw(path)
        check(len(data) == tool["bytes"] and hashlib.sha256(data).hexdigest() == tool["sha256"]
              and stat.S_IMODE(path.stat().st_mode) == tool["mode"], "native selected tool bytes/mode")
    compiler = report["c_compiler"]["path"]
    native = report["native_object"]
    check(report["c_compiler"]["binary_sha256"] == tools_before[1]["sha256"], "C tool report binding")
    check(native["ok"] is True and native["check_only"] is False and native["crate_type"] == "obj"
          and native["artifact_sha256"] == native["validation_artifact_sha256"]
          and native["toolchain"]["executable_sha256"] == tools_before[2]["sha256"], "original actual Rust build identity")
    check(report["frontend"]["ok"] is True and report["frontend"]["profile"]["crate_type"] == "obj"
          and all(value is False for value in report["frontend"]["claims"].values()), "frontend finite claims")
    commands = report["commands"]
    check(len(commands) == 12 and all(row["seconds"] >= 0 for row in commands), "all twelve original C host commands")
    directory = Path(native["artifact"]).parent
    check(Path(native["artifact"]).name == "matrix.o", "Linux original object name")
    check(commands[0]["argv"] == [compiler, "--version"] and commands[0]["returncode"] == 0
          and commands[0]["stdout"].strip() == report["c_compiler"]["version"], "actual C version")
    check(commands[1]["argv"] == [compiler, "-dumpmachine"] and commands[1]["returncode"] == 0
          and commands[1]["stdout"].strip() == report["c_compiler"]["target"], "actual target")
    check(commands[2]["argv"] == [compiler, "-std=c11", "-E", "-P", "-x", "c", str(directory / "compiler-identity.c")]
          and commands[2]["returncode"] == 0 and ("HEPTA_CC_FAMILY " + family) in commands[2]["stdout"], "actual macro family probe")
    def compile_command(profile, output, *, type_control=False):
        common = [compiler, "-std=c11", "-" + profile, "-Wall", "-Wextra", "-Werror", "-pedantic-errors", "-DABI_LAYOUT", str(directory / "matrix.c")]
        return common + (["-c"] if type_control else [native["artifact"]]) + ["-o", str(output)]
    check(len(report["executions"]) == 2 and report["matrix"]["expected_foreign_calls_per_run"] == 181, "original two-profile denominator")
    for index, profile in enumerate(("O0", "O2")):
        executable = directory / ("host-matrix-" + profile)
        built, executed = commands[3 + index * 2:5 + index * 2]
        check(built["argv"] == compile_command(profile, executable) and built["returncode"] == 0, "actual profile build")
        expected = {"status": "passed", "foreign_calls": 181}
        check(executed["argv"] == [str(executable)] and executed["returncode"] == 0
              and json.loads(executed["stdout"]) == expected, "actual raw 181-call observation")
        check(report["executions"][index] == {"optimization": "-" + profile, "layout_checked": True,
              "returncode": 0, "observed": expected}, "profile observation bound to raw process")
    names = ["function_parameter", "array_extent", "nested_pointer_const"]
    controls = report["type_negative_controls"]
    check([row["name"] for row in controls] == names, "three original type controls")
    for index, control in enumerate(controls):
        command = commands[7 + index]
        check(command["argv"] == compile_command("O2", directory / ("type-" + names[index] + ".o"), type_control=True)
              and command["returncode"] == control["returncode"] != 0
              and control["diagnostic_marker"] in command["stdout"] + command["stderr"]
              and control["status"] == "rejected_as_expected", "actual specific type refusal")
    negative = report["negative_control"]
    check(commands[10]["argv"] == compile_command("O2", directory / "wrong") and commands[10]["returncode"] == 0, "wrong echo really compiled")
    check(commands[11]["argv"] == [str(directory / "wrong")] and commands[11]["returncode"] == negative["returncode"] != 0
          and "v_scalar0_0" in commands[11]["stderr"] and negative["status"] == "rejected_as_expected", "wrong echo actual assertion failure")
    originals = [native["artifact"], str(directory / "host-matrix-O0"), str(directory / "host-matrix-O2"), str(directory / "wrong")]
    check(receipt["original_temporary_binary_paths"] == originals and all(not Path(path).exists() for path in originals), "temporary originals removed")
    if retained_count:
        retention = report["retained_binary_artifacts"]
        check(retention["complete"] is True and retention["directory"] == str((base / "native-host-artifacts").resolve()), "complete owned retained directory")
        check(len(retention["files"]) == len(receipt["retained_binaries"]) == 4, "four retained artifacts")
        hashes = [native["artifact_sha256"], *report["executable_sha256s"], negative["artifact_sha256"]]
        for index, (entry, role) in enumerate(zip(retention["files"], ROLES)):
            path = Path(retention["directory"]) / entry["name"]
            data = raw(path)
            check(entry["role"] == role and entry["original_path"] == originals[index]
                  and entry["name"] == Path(originals[index]).name and entry["sha256"] == hashes[index], "retained role/origin/hash")
            check(path.is_file() and not path.is_symlink() and 0 < len(data) <= 16 * 1024 * 1024
                  and len(data) == entry["bytes"] and hashlib.sha256(data).hexdigest() == entry["sha256"]
                  and stat.S_IMODE(path.stat().st_mode) == entry["mode"], "actual retained regular bytes/mode")
            check(receipt["retained_binaries"][index] == {"role": role, "path": str(path), "bytes": len(data),
                  "sha256": hashes[index], "mode": entry["mode"]}, "owner receipt retains actual identity")
        check(retention["files"][0]["bytes"] == native["artifact_bytes"], "original Rust object size")
    else:
        check("retained_binary_artifacts" not in report and receipt["retained_binaries"] == []
              and receipt["retention_requirement_satisfied"] is False, "original parent 0/4 gap preserved")
    raw(base / "stdout.log")
    raw(base / "stderr.log")
    return report


def main():
    started = datetime.now(timezone.utc).isoformat()
    check(not (OUT / "review.json").exists(), "new final audit")
    check(git("show", "-s", "--format=%H %T %P", "HEAD").decode().strip() == " ".join([HEAD, TREE, PARENT])
          and git("status", "--porcelain", "--untracked-files=all") == b"", "clean frozen candidate identity")
    export = read(OWNER / "source-export/manifest.json")
    changed = set(git("diff", "--name-only", PARENT, HEAD).decode().splitlines())
    check(len(changed) == 5 and changed == {row["repository_path"] for row in export["files"]}, "exact five-file source export")
    for row in export["files"]:
        name = row["repository_path"]
        data = raw(Path(row["local_path"]))
        check(data == git("show", HEAD + ":" + name) == raw(ROOT / name), "export raw source " + name)
        check(ident(data) == {key: row[key] for key in ("bytes", "sha256", "git_blob_sha1")}
              and row["mode"] == git("ls-tree", HEAD, "--", name).decode().split()[0], "export identity/mode")
    patch = Path(export["source_patch"]["path"])
    check(ident(raw(patch))["sha256"] == export["source_patch"]["sha256"], "source patch identity")
    with tempfile.TemporaryDirectory(prefix="hepta-retention-review-index-") as temporary:
        environment = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / "index"))
        git("read-tree", PARENT, env=environment)
        git("apply", "--cached", "--check", str(patch), env=environment)
        git("apply", "--cached", str(patch), env=environment)
        check(git("write-tree", env=environment).decode().strip() == TREE, "independent parent patch reconstruction")
    old, new = ast.parse(git("show", PARENT + ":tools/validate_native_host.py")), ast.parse(raw(ROOT / "tools/validate_native_host.py"))
    old_functions = {node.name: node for node in old.body if isinstance(node, ast.FunctionDef)}
    new_functions = {node.name: node for node in new.body if isinstance(node, ast.FunctionDef)}
    for name in set(old_functions) - {"run_host", "validate_report", "main"}:
        check(ast.dump(old_functions[name]) == ast.dump(new_functions[name]), "unchanged original compiler/matrix helper " + name)
    check([ast.dump(node) for node in old_functions["validate_report"].body]
          == [ast.dump(node) for node in new_functions["validate_report"].body[:-1]], "all original ABI validation gates unchanged")
    check(ast.unparse(new_functions["validate_report"].body[-1]) == "if 'retained_binary_artifacts' in report:\n    validate_retained_binaries(report)", "only additional report gate")
    old_return = next(node for node in old_functions["run_host"].body if isinstance(node, ast.Return)).value
    new_return = next(node for node in new_functions["run_host"].body if isinstance(node, ast.Return)).value
    old_pairs = [(ast.dump(k), ast.dump(v)) for k, v in zip(old_return.keys, old_return.values)]
    new_pairs = [(ast.dump(k), ast.dump(v)) for k, v in zip(new_return.keys, new_return.values) if k is not None]
    check(old_pairs == new_pairs, "all old success-report fields/claims preserved")
    for name in ["docs/HIA_SAFETY_CONTRACT.json", "tools/abi_fuzz.py", "hepta/hia_program_source.py"]:
        check(git("show", PARENT + ":" + name) == git("show", HEAD + ":" + name), "unchanged Core/contract/matrix " + name)
    protocol = read(OUT / "frozen25/receipt.json")
    selected, events = read(OUT / "frozen25/selected-methods.json"), read(OUT / "frozen25/method-events.json")
    verbose = raw(OUT / "frozen25/tests.log").decode()
    log_ids = re.findall(r"(?m)^test_[^ ]+ \((tests\.[^)]+)\) \.\.\. ok$", verbose)
    check(selected == events and Counter(selected) == Counter(log_ids) and len(selected) == len(set(selected)) == 25, "frozen 25 actual exact-once methods")
    check(protocol["tests"] == {"run": 25, "errors": 0, "failures": 0, "skipped": 0, "expected_failures": 0, "unexpected_successes": 0}, "ordinary protocol outcomes")
    source_snapshot(read(OUT / "frozen25/source-before.json"), read(OUT / "frozen25/source-after.json"), HEAD, 1426)
    check(protocol["full_git_tree_files"] == 7700 and protocol["materialized_source_files"] == 1426, "honest sparse execution scope")
    tools_before, tools_after = read(OUT / "frozen25-tools-before.json"), read(OUT / "frozen25-tools-after.json")
    check(tools_before == tools_after and read(OUT / "frozen25-process.json")["returncode"] == 0, "protocol process/tool stability")
    for name, row in tools_before["files"].items():
        data = raw(Path(name))
        check(len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
              and stat.S_IMODE(Path(name).stat().st_mode) == row["mode"], "protocol tool current bytes/mode")
    dirty = raw(OUT / "dirty-initial.stderr.log").decode()
    check("Ran 24 tests" in dirty and "FAILED (failures=2)" in dirty
          and "test_cli_exclusive_report_write_preserves_a_concurrent_output" in dirty
          and "test_cli_existing_success_report_and_artifacts_are_never_replaced" in dirty, "actual initial overwrite failures preserved")
    parent = native_record(OWNER / "parent-a6-gcc", PARENT, "gcc", 0)
    actual = {}
    for family in ["gcc", "clang"]:
        report = native_record(OWNER / "frozen2f-native" / family, HEAD, family, 4)
        for key in ["schema", "matrix", "claims", "source_sha256", "harness_sha256", "header_sha256", "layout_probes_sha256", "compiler_sha256", "limits"]:
            check(report[key] == parent[key], "same original matrix/claims " + key)
        actual[family] = {"profiles": 2, "foreign_calls_per_profile": [181, 181], "retained_binaries": 4,
                          "type_rejections": 3, "wrong_echo_returncode": report["negative_control"]["returncode"]}
    invocations = read(OWNER / "frozen2f-native/actual-invocations.json")
    check(len(invocations) == 2 and all(row["returncode"] == 0 for row in invocations), "actual two separate compiler processes")
    check(invocations[0]["finished_utc"] <= invocations[1]["started_utc"], "native populations executed serially")
    for name, row in inputs.items():
        check(ident(Path(name).read_bytes()) == {key: row[key] for key in ("bytes", "sha256", "git_blob_sha1")}, "original input stable " + name)
    result = {"schema": "hepta.native-abi-retention-independent-review.v1", "ok": True,
              "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
              "source": {"head": HEAD, "tree": TREE, "public_parent": PARENT},
              "source_export_files": 5, "independent_parent_patch_tree_rebuild": True,
              "read_only_check_count": checks, "blocking_findings": [],
              "roles": {"production_tool_workflow_docs_and_native_runner_author": "root",
                        "independent_production_source_and_native_originals_review": "review_resume",
                        "new_protocol_test_author_and_runner": "review_resume; own test authorship is disclosed",
                        "new_native_executions_by_reviewer": 0},
              "frozen_protocol_methods": 25, "protocol_new_plus_existing": [14, 11],
              "dirty_initial_24_with_two_actual_overwrite_failures_preserved": True,
              "materialized_source_files": 1426, "full_tree_files": 7700,
              "unmaterialized_source_paths_not_execution_coverage": 6274,
              "parent_gcc_original_retained_binaries": 0, "actual_linux_x86_64": actual,
              "other_hosts_or_broader_abi_qualification": False,
              "readback_extra_native_compiler_checker_or_oracle_executions": 0,
              "local_candidate_not_public_execution": True,
              "python_production_authority": True, "optimization_policy": "no_change", "all_27_strict_blockers_open": True,
              "limits": ["Protocol fake bytes and mocked compiler outcomes are not native execution evidence.",
                         "The actual Linux GCC and Clang matrices retain their original finite ABI scope.",
                         "The successful parent matrix still has no retained binary originals.",
                         "This closes a bounded binary-custody gap, not full semantic correspondence or refinement."]}
    for name, value in [("input-manifest.json", {"files": inputs, "count": len(inputs)}), ("review.json", result)]:
        with (OUT / name).open("x") as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.write("\n")
    print(json.dumps({"ok": True, "read_only_checks": checks, "actual_matrices": actual, "review": str(OUT / "review.json")}))


if __name__ == "__main__":
    main()
