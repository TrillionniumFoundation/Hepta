from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--cc', required=True)
parser.add_argument('--family', choices=['gcc', 'clang'], required=True)
parser.add_argument('--rustc', required=True)
parser.add_argument('--expected-retained', type=int, choices=[0, 4], required=True)
args = parser.parse_args()
root = args.repo.resolve(strict=True)
output = args.output.resolve()
assert not output.exists()
output.mkdir(parents=True)
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_NO_REPLACE_OBJECTS='1')

def git(*values):
    return subprocess.check_output(['git', '-C', str(root), *values], env=environment)

def write(name, value):
    (output / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def identity(path):
    path = Path(path).resolve(strict=True)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': stat.S_IMODE(path.stat().st_mode)}

def source():
    head = git('rev-parse', 'HEAD').decode().strip()
    assert head == args.head
    assert git('status', '--porcelain', '--untracked-files=no') == b''
    entries, absent = [], []
    for entry in git('ls-files', '--stage', '-z').split(b'\0'):
        if not entry:
            continue
        metadata, name = entry.split(b'\t', 1)
        mode, blob, stage = metadata.decode().split()
        assert stage == '0'
        path = root / os.fsdecode(name)
        if not path.exists() and not path.is_symlink():
            absent.append(os.fsdecode(name))
            continue
        if mode == '120000':
            assert path.is_symlink()
            data = os.fsencode(os.readlink(path))
            actual_mode = mode
        else:
            assert path.is_file() and not path.is_symlink()
            data = path.read_bytes()
            actual_mode = '100755' if path.stat().st_mode & 0o111 else '100644'
        actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual_blob == blob and actual_mode == mode
        entries.append({'path': os.fsdecode(name), 'mode': mode, 'bytes': len(data), 'git_blob_sha1': blob, 'sha256': hashlib.sha256(data).hexdigest()})
    return {'head': head, 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'materialized_files': entries, 'unmaterialized_sparse_paths': absent, 'scope': 'Every materialized tracked file matched its raw Git bytes and mode; absent sparse paths are not claimed as materialized coverage.'}

before = source()
tools_before = [identity(sys.executable), identity(args.cc), identity(args.rustc)]
write('source-before.json', before)
write('tools-before.json', tools_before)
command = [sys.executable, '-B', str(root / 'tools/validate_native_host.py'), '--cc', args.cc, '--cc-family', args.family, '--rustc', args.rustc, '--expected-system', 'Linux', '--expected-machine', 'x86_64', '--output', str(output / 'native-host.json')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd=root, env=environment, capture_output=True, timeout=300)
(output / 'stdout.log').write_bytes(result.stdout)
(output / 'stderr.log').write_bytes(result.stderr)
write('process.json', {'argv': command, 'cwd': str(root), 'returncode': result.returncode, 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
after = source()
tools_after = [identity(sys.executable), identity(args.cc), identity(args.rustc)]
write('source-after.json', after)
write('tools-after.json', tools_after)
assert before == after and tools_before == tools_after
report = json.loads((output / 'native-host.json').read_text())
assert result.returncode == 0 and report['status'] == 'passed'
probe_count = 1 if report['c_compiler']['family'] == 'msvc' else 3
temporary = [report['native_object']['artifact'], report['commands'][probe_count + 1]['argv'][0], report['commands'][probe_count + 3]['argv'][0], report['commands'][-1]['argv'][0]]
assert len(set(temporary)) == 4
assert all(not Path(path).exists() for path in temporary)
retention = report.get('retained_binary_artifacts', {})
files = retention.get('files', [])
assert len(files) == args.expected_retained
actual = []
for file in files:
    path = Path(retention['directory']) / file['name']
    found = identity(path)
    assert found['bytes'] == file['bytes'] and found['sha256'] == file['sha256']
    actual.append({'role': file['role'], **found})
receipt = {'schema': 'hepta.native-host-artifact-retention-execution.v1', 'source_head': args.head, 'source_tree': before['tree'], 'materialized_source_files': len(before['materialized_files']), 'source_and_selected_tools_unchanged': True, 'actual_c_family': report['c_compiler']['family'], 'actual_host': report['host'], 'actual_successful_profiles': len(report['executions']), 'foreign_calls_per_profile': [entry['observed']['foreign_calls'] for entry in report['executions']], 'type_counterexamples': len(report['type_negative_controls']), 'compiled_wrong_echo_rejected': report['negative_control']['status'] == 'rejected_as_expected', 'original_temporary_binary_paths': temporary, 'original_temporary_binaries_remaining': 0, 'retained_binaries': actual, 'expected_retained_binaries': args.expected_retained, 'native_matrix_execution_passed': True, 'retention_requirement_satisfied': args.expected_retained == 4, 'whole_abi_or_other_host_qualification_inferred': False}
write('receipt.json', receipt)
print(json.dumps({'native_matrix_execution': 'PASS', 'retained_binaries': len(actual), 'retention_requirement_satisfied': args.expected_retained == 4, 'output': str(output)}), flush=True)
