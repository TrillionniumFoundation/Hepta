import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/b484d4086829')
producer = Path(__file__).with_name('run_native_receipt.py')
assert not args.output.exists()
args.output.mkdir(parents=True)
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
environment['LD_LIBRARY_PATH'] = str(root / 'toolchains/llvm20-evening/usr/lib/x86_64-linux-gnu') + ':' + str(root / 'toolchains/llvm20-evening/usr/lib/llvm-20/lib')
inputs = {}
for path in [producer, Path(__file__)]:
    data = path.read_bytes()
    inputs[str(path)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(args.output / 'producer-inputs-before.json').write_text(json.dumps(inputs, indent=2) + '\n')
commands = []
for family, compiler in [('gcc', '/usr/bin/gcc'), ('clang', str(root / 'toolchains/llvm20-evening/usr/lib/llvm-20/bin/clang'))]:
    command = [sys.executable, '-B', str(producer), '--repo', args.repo, '--head', args.head,
               '--output', str(args.output / family), '--cc', compiler, '--family', family,
               '--rustc', str(root / 'toolchains/rust-1.90.0/bin/rustc'), '--expected-retained', '4']
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(command, env=environment, capture_output=True, timeout=360)
    (args.output / (family + '-collector.stdout.log')).write_bytes(result.stdout)
    (args.output / (family + '-collector.stderr.log')).write_bytes(result.stderr)
    commands.append({'argv': command, 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'returncode': result.returncode, 'explicit_library_path': environment['LD_LIBRARY_PATH']})
    (args.output / 'actual-invocations.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == 0, family + ' collector failed; original stdout/stderr retained'
    print(json.dumps({'family': family, 'actual_matrix_and_four_retained_binaries': 'PASS'}), flush=True)
after = {}
for path in [producer, Path(__file__)]:
    data = path.read_bytes()
    after[str(path)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(args.output / 'producer-inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
assert inputs == after
summary = {'schema': 'hepta.retained-native-matrices.v1', 'source_head': args.head, 'actual_compilers': ['gcc', 'clang'], 'ordinary_matrix_results': 2, 'retained_binary_count_per_compiler': 4, 'retained_binary_counts_are_not_new_test_counts': True, 'producer_inputs_unchanged': True, 'other_hosts_or_general_abi_qualified': False}
(args.output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
