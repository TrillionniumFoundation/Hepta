"""Real pre/post-repair behavior checks; no compiler-command mock or source rewrite."""
import ctypes
import json
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "hepta"))
from hepta.c_project import capture_project
from hepta.c_translation import CTranslator
from hepta.cpp_project_migrate import lower_cpp_project
from hepta.hia_program import execute_program
from hepta.hia_program_source import lower_source
from hepta.hia_program_llvm import build_program_native

CLANG = "/usr/bin/clang-20"
CLANGXX = "/usr/bin/clang++-20"

def command(argv, cwd):
    completed = subprocess.run(list(map(str, argv)), cwd=cwd, capture_output=True,
                               text=True, check=True, timeout=60)
    return completed.stdout

def observe(library, symbol):
    dll = ctypes.CDLL(str(library))
    function = getattr(dll, symbol)
    function.argtypes = [ctypes.c_uint32]
    function.restype = ctypes.c_uint32
    return function(7)

def function(delta):
    return f"unsigned probe(unsigned x) {{ return x + {delta}u; }}\n"

cases = [
    ("optimization", "c", ["-std=c11", "-O2"],
     "#ifdef __OPTIMIZE__\n" + function(1) + "#else\n" + function(2) + "#endif\n", False),
    ("pedantic_builtin", "c", ["-std=c99", "-pedantic-errors"],
     "#if __has_extension(c_static_assert)\n" + function(1) + "#else\n" + function(2) + "#endif\n", False),
    ("file_include", "c", ["-std=c11"],
     "#if __has_include(__FILE__)\n" + function(1) + "#else\n" + function(2) + "#endif\n", False),
    ("source_symlink", "c", ["-std=c11"],
     '#include "local.h"\nunsigned probe(unsigned x) { return x + OFFSET; }\n', True),
    ("template_file_identity", "c++", ["-std=c++20"],
     'template<unsigned N> unsigned selected(unsigned x) noexcept { return x + N; }\n'
     'extern "C" unsigned probe(unsigned x) noexcept { return selected<sizeof(__FILE__) + sizeof(__BASE_FILE__) + __LINE__ + sizeof(unsigned)>(x); }\n', False),
]
report = {"compiler": command([CLANG, "--version"], Path.cwd()).splitlines()[0], "cases": []}
with tempfile.TemporaryDirectory(prefix="hepta-capture-replay-") as temporary:
    for name, language, flags, body, symlink in cases:
        directory = Path(temporary) / name
        (directory / "sub").mkdir(parents=True)
        source = directory / "sub" / ("input.cpp" if language == "c++" else "input.c")
        source.write_text(body)
        operand = "sub/" + source.name
        if symlink:
            (directory / "alias").mkdir()
            (directory / "alias" / source.name).symlink_to(source)
            (directory / "sub/local.h").write_text("#define OFFSET 1u\n")
            (directory / "alias/local.h").write_text("#define OFFSET 2u\n")
            operand = "alias/" + source.name
        compiler = CLANGXX if language == "c++" else CLANG
        argv = [compiler, *flags, "-c", operand, "-o", "original.o"]
        database = directory / "compile_commands.json"
        database.write_text(json.dumps([{"directory": str(directory), "file": str(source), "arguments": argv}]))
        command(argv, directory)
        command([compiler, "-shared", "original.o", "-o", "original.so"], directory)
        original = observe(directory / "original.so", "probe")
        if language == "c++":
            migration = lower_cpp_project(database, clangxx=compiler)
            capture, program, symbol = migration["capture"], migration["program"], "probe"
        else:
            capture = capture_project(database, clang=compiler)
            generated, _, _ = CTranslator(capture).emit()
            program, symbol = lower_source(generated), "c_probe"
        interpreted = execute_program(program, symbol, [7])
        build_program_native(program, directory / "hia.o", clang=CLANG, kind="object")
        command([CLANG, "-shared", "hia.o", "-o", "hia.so"], directory)
        native = observe(directory / "hia.so", symbol)
        report["cases"].append({"name": name, "language": language,
            "flags": flags, "source_operand": operand,
            "original": original, "interpreter": interpreted,
            "native_hia": native, "equal": original == native == interpreted.get("result"),
            "captured_frontend_arguments": capture["configurations"][0]["frontend_arguments"],
            "omitted_arguments": capture["configurations"][0]["omitted_arguments"]})
print(json.dumps(report, indent=2))
