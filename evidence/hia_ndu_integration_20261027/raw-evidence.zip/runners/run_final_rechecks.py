#!/usr/bin/env python3
"""Source-frozen exact module rechecks after adding one locked Rust target."""
from __future__ import annotations
from pathlib import Path
from collections import Counter
import hashlib, json, os, runpy, shutil, subprocess, sys, tarfile, tempfile, threading, time, traceback, urllib.request
BASE=Path(__file__).resolve().parent
REPO=BASE/'hepta'
OUT=BASE/'validation-final-rechecks'
EXPECTED='34c5526ff87ec1208a88f8c86c806fde39505737'
PACKAGE='rust-std-1.90.0-thumbv7em-none-eabi'
EXPECTED_SHA='dde6d6e27729cddaaffc6b4b70ce947cd9ed19c2ec443c99d3157a3be24dee13'
SYSROOT=BASE/'toolchains/rustup/toolchains/1.90.0-x86_64-unknown-linux-gnu'
MODULES=('test_volatile','test_system_board','test_hia_native_postexit_group')
H=runpy.run_path(str(BASE/'run_final_suite.py'),run_name='recheck_helpers')
P=runpy.run_path(str(BASE/'run_partitioned_suite.py'),run_name='partition_helpers')
write=H['write_json']; digest=H['digest']; identity=H['file_identity']; utc=H['utc']

def sysroot_manifest(root):
 result=[]
 for p in sorted(root.rglob('*')):
  if p.is_file(): result.append({'path':str(p.relative_to(root)), 'bytes':p.stat().st_size,'sha256':digest(p)})
 return {'path':str(root),'files':result,'sha256':H['canonical_hash'](result)}

def save(report):write(OUT/'summary.json',report)

def main():
 OUT.mkdir(exist_ok=False)
 module_out=OUT/'modules';module_out.mkdir()
 env=H['make_environment']()
 src_before=H['source_snapshot']();write(OUT/'source-before.json',src_before)
 tools_before=H['tool_inventory'](env);write(OUT/'tools-before.json',tools_before)
 host_before=sysroot_manifest(SYSROOT/'lib/rustlib/x86_64-unknown-linux-gnu');write(OUT/'host-rust-std-before.json',host_before)
 compiler_before=identity(SYSROOT/'bin/rustc')
 component_path=SYSROOT/'lib/rustlib/components'
 components_before=component_path.read_text().splitlines()
 lock_path=REPO/'toolchain-lock.json'
 lock=json.loads(lock_path.read_text());record=next(x for x in lock if x['package']==PACKAGE)
 assert record['sha256']==EXPECTED_SHA
 original=json.loads((BASE/'validation-partitioned-suite/summary.json').read_text())
 prior=json.loads((BASE/'validation-final-suite/discovery.json').read_text())
 report={'schema':'hepta.local-frozen-module-rechecks.v1','status':'running','ok':False,
  'started_utc':utc(),'expected_git_commit':EXPECTED,'repository':str(REPO),'output_directory':str(OUT),
  'source_before_sha256':src_before['sha256'],'source_was_committed':False,
  'source_note':'All code is committed; the intentionally included ignored NDU build-provenance.json remains an independently hashed extra input.',
  'tool_inventory_before_sha256':tools_before['identity_sha256'],
  'runner':identity(__file__),'environment':{k:env[k] for k in H['ENVIRONMENT_KEYS'] if k in env},
  'original_partitioned_summary':identity(BASE/'validation-partitioned-suite/summary.json'),
  'original_partitioned_ok':original['ok'],'original_failed_modules':original['failed_modules'],
  'original_reports_modified':False,'module_workers':1,'modules_planned':list(MODULES),
  'modules':{},'target_installation':{'lock':record,'lock_file':identity(lock_path),
   'sysroot':str(SYSROOT),'components_before':components_before,'host_native_std_before_sha256':host_before['sha256'],
   'compiler_before':compiler_before,'disk_before':shutil.disk_usage(BASE)._asdict()},
  'timeouts_and_assertions_unchanged':True,'single_process_full_suite_passed':False,
  'full_35_gate_qualification_executed':False,'performance_qualification_executed':False,
  'production_admission_qualified':False,'whole_language_soundness_proved':False}
 save(report)
 if src_before['git_head']!=EXPECTED or src_before['sha256']!=original['source_after_sha256']:
  raise ValueError('Frozen source identity differs')
 if original['status']!='completed':raise ValueError('Partitioned suite must be completed')
 if PACKAGE in components_before:raise ValueError('Target already installed; require explicit review instead of pretending this installation happened')
 start=time.monotonic()
 try:
  with tempfile.TemporaryDirectory(prefix='locked-thumb-install-',dir=BASE) as tmp:
   tmp=Path(tmp);archive=tmp/(PACKAGE+'.tar.xz')
   download_start=time.monotonic()
   with urllib.request.urlopen(record['url'],timeout=60) as response,archive.open('xb') as dest:
    downloaded=0
    while True:
     block=response.read(1<<20)
     if not block:break
     downloaded+=len(block)
     if downloaded>150_000_000:raise ValueError('Target archive exceeds bounded download size')
     dest.write(block)
   actual_sha=digest(archive)
   report['target_installation'].update(download_seconds=time.monotonic()-download_start,
     download_bytes=downloaded,download_sha256=actual_sha,download_matches_lock=actual_sha==EXPECTED_SHA)
   save(report)
   if actual_sha!=EXPECTED_SHA:raise ValueError('Target archive checksum mismatch')
   with tarfile.open(archive,'r:xz') as tar:
    members=tar.getmembers();unpacked=sum(m.size for m in members)
    report['target_installation'].update(unpacked_regular_bytes=unpacked,archive_members=len(members))
    if unpacked>200_000_000:raise ValueError('Target archive unpacked size exceeds bounds')
    if any(not (m.name==PACKAGE or m.name.startswith(PACKAGE+'/')) for m in members):raise ValueError('Unexpected archive path prefix')
    tar.extractall(tmp,filter='data')
   install_argv=['sh',str(tmp/PACKAGE/'install.sh'),'--prefix='+str(SYSROOT),'--disable-ldconfig']
   report['target_installation']['install_argv']=install_argv;save(report)
   install_start=time.monotonic()
   with (OUT/'target-install.stdout.log').open('xb') as stdout,(OUT/'target-install.stderr.log').open('xb') as stderr:
    proc=subprocess.run(install_argv,cwd=tmp/PACKAGE,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,timeout=180)
   report['target_installation'].update(install_returncode=proc.returncode,install_seconds=time.monotonic()-install_start)
   save(report)
   if proc.returncode:raise ValueError('Locked target installer failed')
  report['target_installation']['temporary_download_removed']=True
  components_after=component_path.read_text().splitlines()
  host_after=sysroot_manifest(SYSROOT/'lib/rustlib/x86_64-unknown-linux-gnu');write(OUT/'host-rust-std-after.json',host_after)
  target_after=sysroot_manifest(SYSROOT/'lib/rustlib/thumbv7em-none-eabi');write(OUT/'thumb-rust-std-installed.json',target_after)
  compiler_after=identity(SYSROOT/'bin/rustc')
  report['target_installation'].update(components_after=components_after,
   added_components=sorted(set(components_after)-set(components_before)),
   removed_components=sorted(set(components_before)-set(components_after)),
   host_native_std_after_sha256=host_after['sha256'],host_native_std_unchanged=host_after['sha256']==host_before['sha256'],
   target_std_sha256=target_after['sha256'],target_std_file_count=len(target_after['files']),
   compiler_after=compiler_after,compiler_unchanged=compiler_before==compiler_after,
   disk_after=shutil.disk_usage(BASE)._asdict())
  if not report['target_installation']['host_native_std_unchanged'] or not report['target_installation']['compiler_unchanged']:
   raise ValueError('Host compiler/native std unexpectedly changed')
  if report['target_installation']['added_components']!=[PACKAGE.replace('rust-std-1.90.0','rust-std')] or report['target_installation']['removed_components']:
   raise ValueError('Unexpected component change')
  plan=[{'module':module,'expected_ids':sorted(x for x in prior['ids'] if x.startswith(module+'.')),
    'argv':[str(H['PYTHON']),'-m','unittest','discover','-s','tests','-p',module+'.py','-q'],
    'timeout_seconds':900} for module in MODULES]
  write(OUT/'plan.json',{'workers':1,'order':list(MODULES),'modules':plan})
  assert sum(len(p['expected_ids']) for p in plan)==17
  save(report)
  for item in plan:
   print(json.dumps({'status':'module_started','module':item['module'],'utc':utc()}),flush=True)
   result=P['execute_module'](item,env,module_out,{},threading.Lock())
   report['modules'][item['module']]=result;save(report)
   print(json.dumps({'status':'module_finished','module':item['module'],'passed':result['passed'],
    'outcome':result.get('outcome'),'seconds':result.get('execution',{}).get('seconds')}),flush=True)
 except BaseException as exc:
  report['runner_error']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
 finally:
  src_after=H['source_snapshot']();write(OUT/'source-after.json',src_after)
  tools_after=H['tool_inventory'](env);write(OUT/'tools-after.json',tools_after)
  rows=list(report['modules'].values());outcomes=[r.get('outcome',{}) for r in rows]
  complete=all(o.get('tests_run') is not None for o in outcomes)
  counts={k:sum((o.get(k) or 0) for o in outcomes) if complete else None for k in ('tests_run','failures','errors','skipped')}
  report.update(status='completed',finished_utc=utc(),seconds=time.monotonic()-start,
   source_after_sha256=src_after['sha256'],source_unchanged=src_before['sha256']==src_after['sha256'],
   git_head_unchanged=src_before['git_head']==src_after['git_head']==EXPECTED,
   tool_inventory_after_sha256=tools_after['identity_sha256'],
   existing_tool_inventory_unchanged=tools_before['identity_sha256']==tools_after['identity_sha256'],
   original_partitioned_report_unchanged=report['original_partitioned_summary']['sha256']==digest(BASE/'validation-partitioned-suite/summary.json'),
   modules_completed=len(rows),modules_passed=sum(r['passed'] for r in rows),counts=counts,
   failed_modules=[r['module'] for r in rows if not r['passed']],
   environment_change='Added the checksum-locked rust-std 1.90.0 thumbv7em-none-eabi target; host compiler and native target verified unchanged. Rechecks run serially instead of the previous four-worker partition.')
  report['ok']=(not report.get('runner_error') and len(rows)==3 and all(r['passed'] for r in rows)
   and counts['tests_run']==17 and report['source_unchanged'] and report['git_head_unchanged']
   and report['existing_tool_inventory_unchanged'] and report['original_partitioned_report_unchanged'])
  save(report)
  print(json.dumps({k:report.get(k) for k in ('status','ok','seconds','counts','failed_modules','runner_error')}),flush=True)
 return 0 if report['ok'] else 1

if __name__=='__main__':raise SystemExit(main())
