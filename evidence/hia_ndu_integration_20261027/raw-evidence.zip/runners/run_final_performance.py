#!/usr/bin/env python3
"""Three predeclared local performance observations; never repeat until green."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
REPO = BASE / "hepta"
OUTPUT = BASE / "validation-final-performance"
COMMIT = "34c5526ff87ec1208a88f8c86c806fde39505737"
BRIDGE = REPO / "rust/hia-ndu-bridge/target/release/hia-ndu-bridge"
BRIDGE_SHA = "ada753864ff3bcf03f56fbbc6cc0884259fdf513565bbf6499e19f1c6e93d3e8"
RUSTC = BASE / "toolchains/rustup/toolchains/1.90.0-x86_64-unknown-linux-gnu/bin/rustc"
PYTHON = "/usr/bin/python3"
CLANG = "/usr/bin/clang-20"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    initial_suite = json.loads((BASE / "validation-final-suite/summary.json").read_text())
    suite_path = BASE / ("validation-final-suite/summary.json" if initial_suite["ok"]
                        else "validation-partitioned-suite/summary.json")
    suite = json.loads(suite_path.read_text())
    if suite["status"] != "completed":
        raise SystemExit("Wait for the repository suite to finish before timing.")
    rechecks_path = BASE / "validation-final-rechecks/summary.json"
    rechecks = json.loads(rechecks_path.read_text())
    if rechecks.get("status") != "completed":
        raise SystemExit("Wait for the exact serial module rechecks before timing.")
    completion_path = BASE / "validation-final-rechecks/process-completion.json"
    completion = json.loads(completion_path.read_text())
    if (completion.get("observed_runner_exit_code") != 0
            or completion.get("summary", {}).get("sha256") != sha(rechecks_path)):
        raise SystemExit("Expected the completed recheck process receipt.")
    if git("rev-parse", "HEAD") != COMMIT or git("status", "--porcelain", "--untracked-files=no"):
        raise SystemExit("Expected the unchanged frozen source commit.")
    if sha(BRIDGE) != BRIDGE_SHA:
        raise SystemExit("Expected the source-bound rebuilt NDU executable.")
    OUTPUT.mkdir(exist_ok=False)
    negative = OUTPUT / "negative-cases.json"
    write(negative, [[4, 0, 3, 0], [5, 5, 0, 0], [5, 0, 5, 0], [5, 0, 4, 5], [0, 0, 0, 0]])
    common = [PYTHON, "tools/qualify_hia_ndu.py", "--program", "examples/hia_ndu/byte_swap.json",
              "--cases", "examples/hia_ndu/byte_swap_cases.json", "--negative-cases", str(negative),
              "--entry", "swap_candidate", "--bridge", str(BRIDGE), "--bridge-sha256", BRIDGE_SHA,
              "--clang", CLANG, "--samples", "31", "--iterations", "10000",
              "--horizon-calls", "100000000"]
    jobs = [{"name": "ndu-pair-1", "argv": [*common, "--output", str(OUTPUT / "ndu-pair-1.json")], "timeout": 180},
            {"name": "ndu-pair-2", "argv": [*common, "--output", str(OUTPUT / "ndu-pair-2.json")], "timeout": 180},
            {"name": "rust-comparison", "argv": [PYTHON, "tools/qualify_hia_program_perf.py",
                "--clang", CLANG, "--rustc", str(RUSTC), "--output", str(OUTPUT / "rust-comparison.json"),
                "--artifact-directory", str(OUTPUT / "rust-comparison-artifacts")], "timeout": 1800}]
    affinity = os.sched_getaffinity(0)
    plan = {"schema": "hepta.local-fixed-performance-plan.v1", "created_utc": utc(),
            "source_commit": COMMIT, "source_tree": git("rev-parse", "HEAD^{tree}"),
            "runner_sha256": sha(__file__), "bridge_sha256": BRIDGE_SHA,
            "ndu_build_provenance_sha256": sha(REPO / "rust/hia-ndu-bridge/build-provenance.json"),
            "prior_suite_complete": True, "prior_suite_ok": suite["ok"],
            "prior_suite_path": str(suite_path), "prior_suite_sha256": sha(suite_path),
            "serial_rechecks_path": str(rechecks_path),
            "serial_rechecks_sha256": sha(rechecks_path),
            "serial_rechecks_ok": rechecks.get("ok"),
            "serial_rechecks_replace_prior_failures": False,
            "serial_rechecks_process_completion_sha256": sha(completion_path),
            "serial_rechecks_target_installation": rechecks.get("target_installation"),
            "initial_monolithic_suite_ok": initial_suite["ok"],
            "initial_monolithic_report_retained": True,
            "ndu_observation_count": 2, "strict_rust_comparison_count": 1,
            "retries_or_selection_of_best_run": False, "thresholds_modified": False,
            "allowed_cpus_before": sorted(affinity), "selected_cpu": min(affinity),
            "exclusive_cpu_ownership": False, "jobs": jobs}
    write(OUTPUT / "plan.json", plan)
    summary = {"schema": "hepta.local-fixed-performance-execution.v1", "source_commit": COMMIT,
               "started_utc": utc(), "runs": [], "plan_sha256": sha(OUTPUT / "plan.json"),
               "claims": {"universal_rust_superiority_proved": False, "production_net_gain_proved": False,
                          "full_p0_p7_completed": False, "sample_trimming": False}}
    write(OUTPUT / "summary.json", summary)
    os.sched_setaffinity(0, {min(affinity)})
    try:
        for job in jobs:
            started = time.perf_counter()
            print(json.dumps({"stage": "started", "name": job["name"], "utc": utc()}), flush=True)
            row = {"name": job["name"], "started_utc": utc(), "argv": job["argv"], "timeout": job["timeout"]}
            with (OUTPUT / (job["name"] + ".stdout.log")).open("w") as out, (OUTPUT / (job["name"] + ".stderr.log")).open("w") as err:
                try:
                    process = subprocess.Popen(job["argv"], cwd=REPO, stdout=out, stderr=err,
                                               start_new_session=True)
                    row.update(returncode=process.wait(timeout=job["timeout"]), timed_out=False)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
                    row.update(returncode=None, timed_out=True)
                except OSError as error:
                    row.update(returncode=None, timed_out=False,
                               launch_error={"type": type(error).__name__, "message": str(error)})
            row.update(wall_seconds=time.perf_counter() - started, finished_utc=utc())
            path = OUTPUT / (job["name"] + ".json")
            if path.is_file():
                row["report_sha256"] = sha(path)
                try:
                    result = json.loads(path.read_text())
                    row.update(report_ok=result.get("ok"), status=result.get("status"),
                               decision=result.get("decision"))
                except (ValueError, UnicodeError) as error:
                    row["report_parse_error"] = str(error)
            summary["runs"].append(row)
            write(OUTPUT / "summary.json", summary)
            print(json.dumps({"stage": "finished", **row}), flush=True)
    finally:
        os.sched_setaffinity(0, affinity)
        summary.update(finished_utc=utc(), source_commit_after=git("rev-parse", "HEAD"),
                       source_tree_after=git("rev-parse", "HEAD^{tree}"),
                       tracked_source_unchanged=not git("status", "--porcelain", "--untracked-files=no"),
                       bridge_sha256_after=sha(BRIDGE),
                       completed_all_planned_runs=len(summary["runs"]) == len(jobs))
        write(OUTPUT / "summary.json", summary)


if __name__ == "__main__":
    main()
