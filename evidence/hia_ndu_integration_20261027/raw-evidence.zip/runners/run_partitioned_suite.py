#!/usr/bin/env python3
"""Run the exact original Python discovery set in four isolated module workers.

This is a separately identified partitioned regression, not a successful rerun
of the timed-out single-process suite and not a 35-gate qualification.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import threading
import time
import traceback


BASE = Path(__file__).resolve().parent
REPO = BASE / "hepta"
EXPECTED_COMMIT = "34c5526ff87ec1208a88f8c86c806fde39505737"
ORIGINAL = BASE / "validation-final-suite"
HELPERS = runpy.run_path(str(BASE / "run_final_suite.py"), run_name="partitioned_helpers")
utc = HELPERS["utc"]
write_json = HELPERS["write_json"]
digest = HELPERS["digest"]
snapshot = HELPERS["source_snapshot"]
inventory = HELPERS["tool_inventory"]
env_for_tests = HELPERS["make_environment"]
inspection = HELPERS["inspection"]
run_gate = HELPERS["run_gate"]
parse_outcome = HELPERS["unittest_outcome"]
file_identity = HELPERS["file_identity"]
canonical_hash = HELPERS["canonical_hash"]
PYTHON = HELPERS["PYTHON"]
WORKERS = 4
MODULE_TIMEOUT = 900


def original_finished():
    while True:
        report = json.loads((ORIGINAL / "summary.json").read_text())
        if report.get("status") == "completed":
            return report
        print(json.dumps({"status": "waiting_for_original_completion", "utc": utc()}), flush=True)
        time.sleep(30)


def module_discovery(module, env):
    code = '''
import json,sys,unittest
loader=unittest.TestLoader();suite=loader.discover("tests",pattern=sys.argv[1])
def flatten(node):
 for item in node:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item
cases=list(flatten(suite));skips=[]
for case in cases:
 method=getattr(case,case._testMethodName,None)
 if getattr(case,"__unittest_skip__",False):skips.append({"id":case.id(),"reason":getattr(case,"__unittest_skip_why__","")})
 elif getattr(method,"__unittest_skip__",False):skips.append({"id":case.id(),"reason":getattr(method,"__unittest_skip_why__","")})
print(json.dumps({"count":suite.countTestCases(),"ids":[case.id() for case in cases],"loader_errors":loader.errors,"decorator_skips":skips},sort_keys=True))
'''
    process = inspection([PYTHON, "-c", code, module + ".py"], env=env, timeout=120)
    if process.get("returncode") != 0:
        return {"ok": False, "process": process, "ids": []}
    try:
        result = json.loads(process["stdout"])
    except ValueError:
        return {"ok": False, "process": process, "ids": [], "error": "isolated discovery JSON parse failed"}
    return {**result, "process": process, "ok": not result["loader_errors"] and result["count"] > 0}


def execute_module(plan, env, output, active, lock):
    module = plan["module"]
    with lock:
        active[module] = {"started_utc": utc(), "started_monotonic": time.monotonic(), "phase": "discovery"}
    result = {"module": module, "passed": False, "expected_ids": plan["expected_ids"],
              "expected_test_count": len(plan["expected_ids"])}
    try:
        discovery = module_discovery(module, env)
        write_json(output / (module + ".discovery.json"), discovery)
        result["discovery_ids"] = discovery["ids"]
        result["isolated_discovery_ok"] = discovery["ok"]
        result["id_set_matches_original_partition"] = Counter(discovery["ids"]) == Counter(plan["expected_ids"])
        result["decorator_skips"] = discovery.get("decorator_skips", [])
        with lock:
            active[module]["phase"] = "tests"
        execution = run_gate(module, plan["argv"], output, env, MODULE_TIMEOUT)
        stderr_path = output / (module + ".stderr.log")
        text = stderr_path.read_text(errors="replace") if stderr_path.exists() else ""
        outcome = parse_outcome(text, execution["returncode"])
        outcome["count_matches_original_partition"] = outcome["tests_run"] == len(plan["expected_ids"])
        result.update(execution=execution, outcome=outcome)
        result["passed"] = (discovery["ok"] and result["id_set_matches_original_partition"]
                            and not result["decorator_skips"] and execution["completed"]
                            and outcome["passed"] and outcome["count_matches_original_partition"])
    except BaseException as exc:
        result["runner_error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
    finally:
        result["finished_utc"] = utc()
        write_json(output / (module + ".result.json"), result)
        with lock:
            active.pop(module, None)
    return result


def aggregate(results, expected_ids):
    rows = list(results.values())
    known = [row["outcome"] for row in rows if row.get("outcome", {}).get("tests_run") is not None]
    unknown = [row["module"] for row in rows if row.get("outcome", {}).get("tests_run") is None]
    discovered = [identifier for row in rows for identifier in row.get("discovery_ids", [])]
    counts = Counter(discovered)
    expected = Counter(expected_ids)
    passed_ids = [identifier for row in rows if row["passed"] for identifier in row["expected_ids"]]
    sums = {key: sum(item.get(key) or 0 for item in known) for key in ("tests_run", "skipped", "failures", "errors")}
    return {
        "modules_finished": len(rows), "modules_passed": sum(row["passed"] for row in rows),
        "failed_modules": sorted(row["module"] for row in rows if not row["passed"]),
        "timed_out_modules": sorted(row["module"] for row in rows if row.get("execution", {}).get("timed_out")),
        "modules_without_complete_count": sorted(unknown), "reported_count_sums": sums,
        "tests_run": sums["tests_run"] if not unknown else None,
        "skipped": sums["skipped"] if not unknown else None,
        "failures": sums["failures"] if not unknown else None,
        "errors": sums["errors"] if not unknown else None,
        "original_id_count": len(expected_ids), "original_unique_id_count": len(expected),
        "isolated_discovery_id_count": len(discovered),
        "isolated_discovery_unique_id_count": len(counts),
        "missing_ids": sorted((expected - counts).elements()),
        "unexpected_ids": sorted((counts - expected).elements()),
        "duplicate_ids": sorted(identifier for identifier, count in counts.items() if count > 1),
        "id_coverage_exact": counts == expected and len(discovered) == len(expected_ids),
        "test_ids_in_passed_modules": len(passed_ids),
        "coverage_basis": "Exact original ID inventory versus per-module isolated discovery, unchanged source, and actual complete unittest counts. CLI remains -q; there is no extra per-test runtime instrumentation.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=BASE / "validation-partitioned-suite")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        parser.error("output must be a new directory; previous evidence is never overwritten")
    if output == REPO or REPO in output.parents:
        parser.error("output must be outside the tested repository")
    original = original_finished()
    unit = next(gate for gate in original["gates"] if gate["name"] == "unit_regression")
    if unit.get("passed"):
        print(json.dumps({"status": "not_started_original_unit_succeeded", "original_summary": str(ORIGINAL / "summary.json")}), flush=True)
        return 0
    if unit.get("timed_out") is not True:
        print(json.dumps({"status": "not_started_original_did_not_timeout", "original_summary": str(ORIGINAL / "summary.json")}), flush=True)
        return 2
    output.mkdir(parents=True)
    module_output = output / "modules"
    module_output.mkdir()
    env = env_for_tests()
    original_discovery = json.loads((ORIGINAL / "discovery.json").read_text())
    expected_ids = original_discovery["ids"]
    groups = defaultdict(list)
    for identifier in expected_ids:
        module = identifier.split(".", 1)[0]
        if not re.fullmatch(r"test_[A-Za-z0-9_]+", module) or not (REPO / "tests" / (module + ".py")).is_file():
            raise ValueError("unsupported original discovery module " + module)
        groups[module].append(identifier)
    if len(expected_ids) != 2576 or len(set(expected_ids)) != 2576:
        raise ValueError("original frozen discovery must contain exactly 2576 unique IDs")
    plan = [{"module": module, "expected_ids": sorted(ids),
             "argv": [str(PYTHON), "-m", "unittest", "discover", "-s", "tests", "-p", module + ".py", "-q"],
             "timeout_seconds": MODULE_TIMEOUT}
            for module, ids in sorted(groups.items(), key=lambda item: (-len(item[1]), item[0]))]
    write_json(output / "plan.json", {"workers": WORKERS, "scheduling": "descending original case count; alphabetical ties", "modules": plan})
    before = snapshot()
    tools_before = inventory(env)
    runner_before = file_identity(__file__)
    write_json(output / "source-before.json", before)
    write_json(output / "tools-before.json", tools_before)
    identity_ok = (before["git_head"] == EXPECTED_COMMIT
                   and before["sha256"] == original["source_before_sha256"] == original["source_after_sha256"]
                   and tools_before["identity_sha256"] == original["tools_after_identity_sha256"]
                   and original["source_unchanged"] and original["tools_unchanged"])
    report = {
        "schema": "hepta.local-p7-module-partitioned-regression.v1", "status": "running", "ok": False,
        "started_utc": utc(), "repository": str(REPO), "output_directory": str(output),
        "workers": WORKERS, "module_timeout_seconds": MODULE_TIMEOUT, "planned_modules": len(plan),
        "original_discovery_count": len(expected_ids), "expected_git_commit": EXPECTED_COMMIT,
        "source_before_sha256": before["sha256"], "tools_before_identity_sha256": tools_before["identity_sha256"],
        "runner_before": runner_before, "same_source_and_tools_as_original": identity_ok,
        "source_was_committed": original["source_was_committed"],
        "original_run": {"summary": str(ORIGINAL / "summary.json"), "summary_sha256": digest(ORIGINAL / "summary.json"),
                         "discovery_sha256": digest(ORIGINAL / "discovery.json"), "status": original["status"],
                         "ok": original["ok"], "unit_timed_out": unit["timed_out"], "unit_seconds": unit["seconds"],
                         "reports_modified": False},
        "original_successful_cargo_gate": next(gate for gate in original["gates"] if gate["name"] == "rust_shadow_cargo"),
        "cargo_test_gate_rerun": False,
        "execution_mode": "Four concurrent workers, each module in a fresh unittest CLI process; this differs from single-process global discovery execution.",
        "independent_performance_qualification_executed": False,
        "single_process_full_suite_passed": False, "full_35_gate_qualification_executed": False,
        "full_seven_deliverables_complete": False, "production_admission_qualified": False,
        "whole_language_soundness_proved": False,
        "environment": {key: env[key] for key in HELPERS["ENVIRONMENT_KEYS"] if key in env},
        "disk_before": shutil.disk_usage(BASE)._asdict(), "module_results": {},
    }
    write_json(output / "summary.json", report)
    if not identity_ok:
        report.update(status="completed", finished_utc=utc(), blocked_reason="source/tool identity differs from the completed original run", modules_started=0)
        write_json(output / "summary.json", report)
        print(json.dumps({"status": "completed", "ok": False, "blocked_reason": report["blocked_reason"]}), flush=True)
        return 1
    active = {}
    lock = threading.Lock()
    results = {}
    start = time.monotonic()
    last_status = 0.0
    with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="module-test") as pool:
        pending = {pool.submit(execute_module, item, env, module_output, active, lock): item["module"] for item in plan}
        while pending:
            done, _ = wait(pending, timeout=30, return_when=FIRST_COMPLETED)
            for future in done:
                module = pending.pop(future)
                result = future.result()
                results[module] = result
            now = time.monotonic()
            if now - last_status >= 30 or not pending:
                totals = aggregate(results, expected_ids)
                with lock:
                    current = {module: {"started_utc": value["started_utc"], "phase": value["phase"],
                                       "elapsed_seconds": now - value["started_monotonic"]}
                               for module, value in active.items()}
                report.update(updated_utc=utc(), seconds=now-start, active_modules=current, **totals)
                report["module_results"] = {module: {"passed": row["passed"], "result_path": str(module_output / (module + ".result.json")),
                                                    "outcome": row.get("outcome"), "seconds": row.get("execution", {}).get("seconds")}
                                            for module, row in sorted(results.items())}
                write_json(output / "summary.json", report)
                print(json.dumps({"status": "running", "seconds": round(now-start, 1),
                                  "modules_finished": totals["modules_finished"], "planned_modules": len(plan),
                                  "modules_passed": totals["modules_passed"], "failed_modules": totals["failed_modules"],
                                  "reported_count_sums": totals["reported_count_sums"], "active_modules": current}), flush=True)
                last_status = now
    after = snapshot()
    tools_after = inventory(env)
    runner_after = file_identity(__file__)
    write_json(output / "source-after.json", after)
    write_json(output / "tools-after.json", tools_after)
    report.update(**aggregate(results, expected_ids), status="completed", finished_utc=utc(), seconds=time.monotonic()-start,
                  source_after_sha256=after["sha256"], tools_after_identity_sha256=tools_after["identity_sha256"],
                  source_unchanged=before["sha256"]==after["sha256"], git_head_unchanged=before["git_head"]==after["git_head"]==EXPECTED_COMMIT,
                  tools_unchanged=tools_before["identity_sha256"]==tools_after["identity_sha256"],
                  runner_after=runner_after, runner_unchanged=runner_before==runner_after,
                  disk_after=shutil.disk_usage(BASE)._asdict(), active_modules={})
    report["ok"] = (len(results)==len(plan) and all(row["passed"] for row in results.values())
                    and report["id_coverage_exact"] and report["tests_run"]==2576
                    and report["source_unchanged"] and report["git_head_unchanged"]
                    and report["tools_unchanged"] and report["runner_unchanged"])
    write_json(output / "summary.json", report)
    print(json.dumps({"status": "completed", "ok": report["ok"], "tests_run": report["tests_run"],
                      "skipped": report["skipped"], "failures": report["failures"], "errors": report["errors"],
                      "id_coverage_exact": report["id_coverage_exact"], "failed_modules": report["failed_modules"],
                      "summary": str(output / "summary.json")}), flush=True)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
