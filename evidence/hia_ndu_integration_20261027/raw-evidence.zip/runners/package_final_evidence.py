#!/usr/bin/env python3
"""Package immutable run records and derived summaries without altering history."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import zipfile

BASE = Path(__file__).resolve().parent
REPO = BASE / 'hepta'
DEST = REPO / 'evidence/hia_ndu_integration_20261027'
CODE = '34c5526ff87ec1208a88f8c86c806fde39505737'
CODE_TREE = 'dea92ece77c21509ec1690007a237902cbb7a682'
DOC = 'docs/HIA_NDU_CANDIDATE_PIPELINE.md'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def copy(source, relative):
    source = Path(source)
    if not stat.S_ISREG(source.lstat().st_mode):
        raise ValueError('Only regular evidence files may be copied: ' + str(source))
    destination = DEST / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    if sha(source) != sha(destination):
        raise ValueError('Copy identity mismatch: ' + str(source))
    return {'path': relative, 'original_path': str(source), 'bytes': source.stat().st_size,
            'sha256': sha(source), 'byte_for_byte_copy': True}


def main():
    if git('rev-parse', 'HEAD') != CODE or git('rev-parse', 'HEAD^{tree}') != CODE_TREE:
        raise SystemExit('The tested code commit must still be HEAD before evidence publication.')
    changed = git('diff', 'HEAD', '--name-only').splitlines()
    if changed != [DOC]:
        raise SystemExit('Only the reviewed post-measurement documentation clarification is allowed: ' + repr(changed))
    mono = read(BASE / 'validation-final-suite/summary.json')
    partition = read(BASE / 'validation-partitioned-suite/summary.json')
    rechecks = read(BASE / 'validation-final-rechecks/summary.json')
    completion = read(BASE / 'validation-final-rechecks/process-completion.json')
    perf = read(BASE / 'validation-final-performance/summary.json')
    perf_plan = read(BASE / 'validation-final-performance/plan.json')
    binding = read(BASE / 'supplemental-source-binding.json')
    build = read(REPO / 'rust/hia-ndu-bridge/build-provenance.json')
    rust = read(BASE / 'validation-final-performance/rust-comparison.json')
    if not (mono['status'] == partition['status'] == rechecks['status'] == 'completed'
            and completion['observed_runner_exit_code'] == 0 and rechecks['ok']
            and perf['completed_all_planned_runs'] and perf['tracked_source_unchanged']
            and perf['source_commit_after'] == CODE and perf['source_tree_after'] == CODE_TREE):
        raise SystemExit('Expected completed immutable run records; never synthesize completion.')
    if completion['summary']['sha256'] != sha(BASE / 'validation-final-rechecks/summary.json'):
        raise SystemExit('Recheck completion does not identify this report.')
    for run in perf['runs']:
        if run['report_sha256'] != sha(BASE / 'validation-final-performance' / (run['name'] + '.json')):
            raise SystemExit('Performance report changed after execution.')
    if not binding['tracked_source_binding_verified'] or not binding['source_binding_check_passed']:
        raise SystemExit('Independent committed source binding did not pass.')
    ids = read(BASE / 'validation-final-suite/discovery.json')['ids']
    passed = []
    for name, row in partition['module_results'].items():
        if row['passed']:
            passed.extend(read(BASE / 'validation-partitioned-suite/modules' / (name + '.result.json'))['expected_ids'])
    serial_ids = []
    for name in rechecks['modules']:
        result = read(BASE / 'validation-final-rechecks/modules' / (name + '.result.json'))
        if not result['passed']:
            raise SystemExit('Expected a complete passing serial module: ' + name)
        serial_ids.extend(result['expected_ids'])
    combined = passed + serial_ids
    if len(combined) != len(set(combined)) or sorted(combined) != sorted(ids):
        raise SystemExit('Combined complete-module pass IDs do not exactly cover original discovery.')
    rust_gate = next(row for row in mono['gates'] if row['name'] == 'rust_shadow_cargo')
    unit_gate = next(row for row in mono['gates'] if row['name'] == 'unit_regression')
    ndu_runs = []
    for job in perf['runs']:
        if not job['name'].startswith('ndu-pair-'):
            continue
        report = read(BASE / 'validation-final-performance' / (job['name'] + '.json'))
        a = report['assessment']
        n = a['calls_per_sample']
        native = report['measurement']['native']
        ndu_runs.append({
            'name': job['name'], 'report_sha256': job['report_sha256'],
            'status': report['status'], 'ok': report['ok'], 'decision': report['decision'],
            'activated': report['activated'], 'actual_ndu_evaluator_executed': report['claims']['real_ndu_evaluator_executed'],
            'ndu_advisory_recommendation': report['ndu']['response']['advisory_recommendation'],
            'core_sha256': {role: native[role]['core_sha256'] for role in ('baseline', 'candidate')},
            'artifact_sha256': {role: native[role]['artifact_sha256'] for role in ('baseline', 'candidate')},
            'identical_native_artifact_bytes_by_recorded_sha256': native['baseline']['artifact_sha256'] == native['candidate']['artifact_sha256'],
            'baseline_median_ns_per_call': a['baseline_median_ns'] / n,
            'candidate_median_ns_per_call': a['candidate_median_ns'] / n,
            'paired_saving_median_ns_per_call': a['paired_saving_median_ns'] / n,
            'baseline_relative_mad': a['baseline_mad_ns'] / a['baseline_median_ns'],
            'candidate_relative_mad': a['candidate_mad_ns'] / a['candidate_median_ns'],
            'host_admission_eligible': a['eligible'], 'host_rejection_reasons': a['reasons'],
            'measurement_counts': report['measurement']['counts'],
            'semantic_observation_pairs': len(report['semantic_validation']['observations']),
            'semantic_observations_ok': report['semantic_validation']['ok'],
            'semantic_scope_exclusions': report['semantic_validation']['excluded'],
            'observed_peak_core_live_bytes': report['semantic_validation']['peak_live_bytes'],
            'qualify_internal_wall_seconds': report['costs']['total_paid_wall_ns'] / 1e9,
            'complete_cli_wall_seconds': job['wall_seconds'],
            'search_before_decision_seconds': report['costs']['search_before_decision_ns'] / 1e9,
            'actual_selection_seconds': report['costs']['selection_wall_ns'] / 1e9,
            'decision_reserve_seconds': a['decision_reserve_ns'] / 1e9,
            'horizon_calls': report['plan']['objective']['horizon_calls'],
            'projected_baseline_total_seconds': a['projected_baseline_total_ns'] / 1e9,
            'projected_candidate_total_seconds': a['projected_candidate_total_ns'] / 1e9,
            'projection_is_workload_assumption': True, 'production_gain_proved': False,
        })
    r_eval = rust['evaluation']
    relative_mads = [impl['relative_mad'] for kernel in r_eval['summary'].values() for impl in kernel['implementations'].values()]
    rust_run = next(row for row in perf['runs'] if row['name'] == 'rust-comparison')
    summary = {
        'schema': 'hepta.hia.ndu-integration-evidence.v1',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'repository': 'TrillionniumFoundation/Hepta', 'pull_request': 326,
        'stacked_on_pull_request': 323,
        'stacked_base_commit': '3db07aa877ab1a5fc00560d7037e6efbc884fc1f',
        'tested_code_commit': CODE, 'tested_code_tree': CODE_TREE,
        'post_measurement_change': {'executable_code_changed': False, 'test_code_changed': False,
            'only_preexisting_tracked_file_changed': DOC, 'documentation_sha256_after': sha(REPO / DOC),
            'purpose': 'Clarify the single Python VM, independently checked versus trusted NDU digests, and qualify versus CLI cost scope.'},
        'upstream_ndu_commit': build['upstream_commit'], 'ndu_binary_sha256': build['binary_sha256'],
        'ndu_build_provenance_sha256': sha(REPO / 'rust/hia-ndu-bridge/build-provenance.json'),
        'source_binding': {'tracked_regular_files_verified': len(binding['tracked_files']),
            'tracked_files_match_code_commit': binding['tracked_source_binding_verified'],
            'original_source_was_committed_flag': mono['source_was_committed'],
            'original_flag_not_overwritten': True,
            'reason': 'The original complete input set also hashes one ignored, untracked NDU build-provenance.json; committed code and that metadata have separate identities.'},
        'tests': {
            'rust_frozen_source': rust_gate['outcome'],
            'single_process_python': {'status': 'timed_out', 'timeout_seconds': unit_gate['timeout_seconds'],
                'actual_wall_seconds': unit_gate['seconds'], 'final_tests_run': None, 'passed': False,
                'original_summary_ok': mono['ok'], 'historical_log_preserved': True},
            'four_worker_partition': {key: partition[key] for key in ['planned_modules', 'modules_finished', 'modules_passed',
                'tests_run', 'failures', 'errors', 'skipped', 'failed_modules', 'timed_out_modules', 'id_coverage_exact', 'seconds', 'ok']},
            'exact_serial_rechecks': {'modules': 3, **rechecks['counts'], 'ok': rechecks['ok'],
                'source_unchanged': rechecks['source_unchanged'],
                'original_thresholds_unchanged': rechecks['timeouts_and_assertions_unchanged'],
                'host_compiler_and_native_std_unchanged': rechecks['target_installation']['host_native_std_unchanged'] and rechecks['target_installation']['compiler_unchanged'],
                'added_component': 'rust-std-1.90.0-thumbv7em-none-eabi',
                'component_archive_sha256': rechecks['target_installation']['download_sha256'],
                'earlier_sigsys_control_timeout_root_cause_proved': False},
            'complete_module_pass_id_coverage': {'initial_passing_modules': 260, 'initial_passing_ids': len(passed),
                'rechecked_modules': 3, 'rechecked_ids': len(serial_ids), 'combined_unique_pass_ids': len(set(combined)),
                'original_unique_discovery_ids': len(set(ids)), 'exact_id_set_coverage_verified': True,
                'single_green_full_run': False,
                'partition_plus_recheck_execution_observations': partition['tests_run'] + rechecks['counts']['tests_run'],
                'repeated_execution_observations': partition['tests_run'] + rechecks['counts']['tests_run'] - len(set(ids))},
            'full_35_gate_qualification_executed': False,
        },
        'ndu_performance': ndu_runs,
        'strict_rust_comparison': {
            'report_sha256': rust_run['report_sha256'], 'status': rust['status'], 'ok': rust['ok'],
            'protocol': rust['protocol']['id'], 'samples_planned': 63, 'samples_collected': len(rust['raw_samples']),
            'paired_groups': rust['protocol']['paired_groups'], 'source_rust_version': '1.90.0',
            'complete_cli_wall_seconds': rust_run['wall_seconds'],
            'finite_correctness_status': rust['correctness']['status'],
            'finite_native_result_calls': rust['correctness']['native_calls'],
            'resource_status': rust['resource_observation']['status'],
            'positive_allocator_observation': json.loads(rust['resource_observation']['positive']['stdout']),
            'negative_missing_free_observation': json.loads(rust['resource_observation']['negative']['stdout']),
            'negative_missing_free_returncode': rust['resource_observation']['negative']['returncode'],
            'quality_failures': r_eval['measurement_quality_failures'],
            'performance_threshold_failures': r_eval['performance_threshold_failures'],
            'relative_mad_minimum': min(relative_mads), 'relative_mad_maximum': max(relative_mads),
            'fixed_maximum_relative_mad': rust['protocol']['maximum_relative_mad'],
            'geometric_mean_paired_time_ratios_descriptive_only': r_eval['geometric_mean_paired_time_ratios'],
            'kernel_median_paired_time_ratios_descriptive_only': {
                name: {backend: comparison['median_paired_time_ratio'] for backend, comparison in row['comparisons'].items()}
                for name, row in r_eval['summary'].items()},
            'claims': rust['claims'], 'retained_artifact_files': len(rust['artifact_retention']['files']),
            'artifact_retention_status': rust['artifact_retention']['status'],
            'compile_wall_seconds': rust['compile_wall_seconds'], 'interference_observations': rust['interference_observations'],
        },
        'historical_scoped_evidence': {
            'reports_relabelled_as_frozen_commit_runs': False,
            'p2_python_tests': 59, 'p2_full_ledger_observations': {'previous_byte_owner': 124, 'cfg_call': 105, 'total': 229},
            'p2_dynamic_rust_vm_executes_swap': False,
            'p5_reproduced_and_corrected_capture_mismatches': 5,
            'p5_original_and_translated_native_result_executions': {'c_matrix': 816, 'cpp_matrix': 816, 'cpp_template_project': 454, 'total': 2086},
            'p5_configuration_and_result_comparisons': 1043,
            'p5_independently_audited_reference_commands': 10,
            'p5_arbitrary_cpp_translated': False, 'p5_human_labor_and_maintenance_cost_qualified': False,
        },
        'acceptance': {
            'P0': {'status': 'scoped_semantic_convergence_and_wire_hardening', 'broad_stage_closed': False},
            'P1': {'status': 'finite_owner_loan_and_call_model_extended', 'broad_stage_closed': False},
            'P2': {'status': 'independent_finite_vm_and_native_controls', 'broad_stage_closed': False},
            'P3': {'status': 'actual_finite_candidate_to_ndu_no_change_loop_executed', 'broad_stage_closed': False},
            'P4': {'status': 'not_accepted_no_repeatable_net_gain', 'broad_stage_closed': False},
            'P5': {'status': 'finite_capture_semantics_corrected_cost_obligations_open', 'broad_stage_closed': False},
            'P6': {'status': 'bounded_interpreter_dispatch_only', 'broad_stage_closed': False},
            'P7': {'status': 'one_host_regression_evidence_broad_system_qualification_open', 'broad_stage_closed': False},
        },
        'trust_and_cost_limits': {
            'ndu_baseline_and_candidate_interpreted_by': 'The same Python VM, separately for each Core; no independent Rust execution of swap.',
            'host_independently_recomputes': ['candidate support digest'],
            'host_digest_format_checks_only': ['evaluation_sha256', 'evaluation_policy_sha256', 'utility_profile_sha256'],
            'digest_authenticity_basis': 'Pinned Rust evaluator binary checked before/after invocation plus trusted host/toolchain, not remote attestation.',
            'memory_metric': 'Observed Core live payload bytes for the finite corpus, not total compiler or native process RSS.',
            'search_budget': 'Measured admission ceiling, not preemptive whole-call deadline.',
            'qualify_wall_excludes': ['CLI input reads/prevalidation', 'Python process startup', 'final report serialization'],
            'full_project_cost_accounting_completed': False,
            'costs_not_fully_accounted': ['initial toolchain installation', 'NDU evaluator build', 'engineering labor', 'model tokens', 'energy', 'long-term migration maintenance'],
            'runtime_dispatch': 'Interpreter-only pinning, explicit CAS activation, drain and rollback; no native hot swap or external-state migration.',
            'all_input_equivalence_proved': False, 'backend_refinement_proved': False,
            'global_optimum_proved': False, 'universal_rust_superiority_proved': False,
            'production_net_gain_proved': False, 'physical_platform_qualification_completed': False,
            'independent_agent_productivity_qualified': False, 'full_p0_p7_complete': False,
        },
    }
    scope_path = BASE / 'p5-scope-counts.json'
    if not scope_path.is_file():
        raise SystemExit('Wait for P5 denominator audit before packaging.')
    summary['p5_denominator_audit'] = {'file': 'migration/scope-counts.json', 'sha256': sha(scope_path)}
    if not (BASE / 'final-status.md').is_file():
        raise SystemExit('Wait for reviewed final status document.')
    DEST.mkdir(exist_ok=False)
    copies = []
    readable = {
        'README.md': BASE / 'final-status.md',
        'tests/monolithic-summary.json': BASE / 'validation-final-suite/summary.json',
        'tests/partitioned-summary.json': BASE / 'validation-partitioned-suite/summary.json',
        'tests/serial-rechecks-summary.json': BASE / 'validation-final-rechecks/summary.json',
        'tests/recheck-process-completion.json': BASE / 'validation-final-rechecks/process-completion.json',
        'performance/plan.json': BASE / 'validation-final-performance/plan.json',
        'performance/execution-summary.json': BASE / 'validation-final-performance/summary.json',
        'performance/ndu-pair-1.json': BASE / 'validation-final-performance/ndu-pair-1.json',
        'performance/ndu-pair-2.json': BASE / 'validation-final-performance/ndu-pair-2.json',
        'performance/rust-comparison.json': BASE / 'validation-final-performance/rust-comparison.json',
        'provenance/ndu-build-provenance.json': REPO / 'rust/hia-ndu-bridge/build-provenance.json',
        'provenance/source-binding.json': BASE / 'supplemental-source-binding.json',
        'migration/capture-before.json': BASE / 'evidence-staging/p5/migration-capture-before.json',
        'migration/capture-after.json': BASE / 'evidence-staging/p5/migration-capture-after.json',
        'migration/reference-command-audit.json': BASE / 'evidence-staging/p5/migration-reference-command-audit.json',
        'migration/scope-counts.json': scope_path,
    }
    for relative, source in readable.items():
        copies.append(copy(source, relative))
    write(DEST / 'integration-summary.json', summary)
    write(DEST / 'tests/combined-pass-id-coverage.json', {
        'schema': 'hepta.complete-module-pass-id-coverage.v1', 'tested_code_commit': CODE,
        'initial_passing_module_ids': sorted(passed), 'serial_recheck_module_ids': sorted(serial_ids),
        'combined_exact_original_id_set': True, 'combined_unique_id_count': len(set(combined)),
        'single_green_full_run': False, 'prior_failures_and_timeout_preserved': True,
    })
    roots = {
        'runs/monolithic': BASE / 'validation-final-suite',
        'runs/partitioned': BASE / 'validation-partitioned-suite',
        'runs/rechecks': BASE / 'validation-final-rechecks',
        'runs/performance': BASE / 'validation-final-performance',
        'historical/p2-owned-cfg': BASE / 'validation-p2-owned-cfg',
        'historical/p4-p5': BASE / 'evidence-staging',
    }
    entries = []
    for prefix, root in roots.items():
        for source in sorted(root.rglob('*')):
            if source.is_dir():
                continue
            if not stat.S_ISREG(source.lstat().st_mode):
                raise ValueError('Raw evidence includes a nonregular file: ' + str(source))
            entries.append((prefix + '/' + source.relative_to(root).as_posix(), source))
    individual = {
        'provenance/source-binding.json': BASE / 'supplemental-source-binding.json',
        'provenance/ndu-build-provenance.json': REPO / 'rust/hia-ndu-bridge/build-provenance.json',
        'audit/pre-final-evidence-audit.json': BASE / 'final-evidence-audit.json',
        'audit/p5-scope-counts.json': scope_path,
        'runners/cargo-wrapper': BASE / 'p7-suite-bin/cargo',
    }
    for name in ['run_final_suite.py', 'run_partitioned_suite.py', 'run_final_rechecks.py', 'run_final_performance.py', 'package_final_evidence.py']:
        individual['runners/' + name] = BASE / name
    entries.extend(individual.items())
    entries.sort(key=lambda row: row[0])
    names = [name for name, _ in entries]
    if len(names) != len(set(names)):
        raise ValueError('Duplicate raw archive members')
    inventory = []
    zip_path = DEST / 'raw-evidence.zip'
    with zipfile.ZipFile(zip_path, mode='x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, source in entries:
            raw = source.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | stat.S_IMODE(source.stat().st_mode)) << 16
            archive.writestr(info, raw)
            inventory.append({'path': name, 'original_path': str(source), 'bytes': len(raw), 'sha256': digest})
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip() is not None or sorted(archive.namelist()) != names:
            raise ValueError('Raw archive integrity failed')
        for row in inventory:
            raw = archive.read(row['path'])
            if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('Raw member identity mismatch')
    public_inventory = []
    for source in sorted(DEST.rglob('*')):
        if source.is_file():
            public_inventory.append({'path': source.relative_to(DEST).as_posix(), 'bytes': source.stat().st_size, 'sha256': sha(source)})
    manifest = {'schema': 'hepta.hia.ndu-evidence-manifest.v1', 'tested_code_commit': CODE,
        'raw_archive': {'path': 'raw-evidence.zip', 'bytes': zip_path.stat().st_size, 'sha256': sha(zip_path),
            'members': len(inventory), 'uncompressed_bytes': sum(row['bytes'] for row in inventory), 'all_members_reopened_and_sha256_verified': True},
        'raw_members': inventory, 'public_files_before_manifest': public_inventory,
        'readable_original_byte_copies': copies,
        'historical_records_modified': False,
        'historical_absolute_paths_preserved': True,
        'archive_binaries_are_retained_benchmark_and_negative_control_artifacts': True,
        'manifest_self_hash_location': 'SHA256SUMS',
        'notes': ['Raw snapshots keep original false flags, local paths, tool versions, failures and timeouts.',
            'The pre-final read-only audit correctly records performance/rechecks as pending at its own observation time.',
            'The package runner records the specific local execution paths; use the committed tools with equivalent pinned installations on another host.',
            'Exact executable bytes are retained for the strict Rust benchmark; NDU measure_pair retains artifact identities and emitted sources but removes its temporary libraries.']}
    write(DEST / 'evidence-manifest.json', manifest)
    lines = []
    for source in sorted(DEST.rglob('*')):
        if source.is_file():
            lines.append(sha(source) + '  ' + source.relative_to(DEST).as_posix())
    (DEST / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'output': str(DEST), 'raw_archive_sha256': sha(zip_path),
        'raw_archive_bytes': zip_path.stat().st_size, 'raw_members': len(inventory),
        'public_files': len(lines) + 1, 'unique_pass_id_coverage': len(set(combined)),
        'rust_performance_status': rust['status'], 'ndu_decisions': [row['decision'] for row in ndu_runs]}, sort_keys=True))


if __name__ == '__main__':
    main()
