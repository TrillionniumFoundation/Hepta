; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal %hia.buffer @__hia_fn_0(%hia.buffer %p_0_0) {
b0:
  ret %hia.buffer %p_0_0
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  ; intentionally removed actual free
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t25, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i64 %p_4_4 to i32
  %t17 = add i32 %t16, %p_4_1
  %t18 = trunc i32 %t17 to i8
  %t19 = extractvalue %hia.buffer %p_4_2, 0
  %t20 = extractvalue %hia.buffer %p_4_2, 1
  %t21 = icmp ult i64 %p_4_4, %t20
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  %t23 = getelementptr i8, ptr %t19, i64 %p_4_4
  store i8 %t18, ptr %t23, align 1
  %t24 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t25 = extractvalue { i64, i1 } %t24, 0
  %t26 = extractvalue { i64, i1 } %t24, 1
  %t27 = xor i1 %t26, true
  br i1 %t27, label %ok_28, label %trap_28
trap_28:
  call void @abort()
  unreachable
ok_28:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %t29 = call %hia.buffer @__hia_fn_0(%hia.buffer %p_5_2)
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %t29, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t39, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t44, %edge_9 ]
  %t30 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t30, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t31 = extractvalue %hia.buffer %p_7_2, 0
  %t32 = extractvalue %hia.buffer %p_7_2, 1
  %t33 = icmp ult i64 %p_7_5, %t32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = getelementptr i8, ptr %t31, i64 %p_7_5
  %t36 = load i8, ptr %t35, align 1
  %t37 = zext i8 %t36 to i64
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_3, i64 %t37)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_5, i64 1)
  %t44 = extractvalue { i64, i1 } %t43, 0
  %t45 = extractvalue { i64, i1 } %t43, 1
  %t46 = xor i1 %t45, true
  br i1 %t46, label %ok_47, label %trap_47
trap_47:
  call void @abort()
  unreachable
ok_47:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t48 = extractvalue %hia.buffer %p_8_2, 0
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %drop_nonnull_50, label %drop_after_50
drop_nonnull_50:
  ; intentionally removed actual free
  br label %drop_after_50
drop_after_50:
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  %t6 = extractvalue %hia.buffer %p_1_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  ; intentionally removed actual free
  br label %drop_after_8
drop_after_8:
  %t9 = zext i32 %p_1_1 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1002, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t15 = extractvalue %hia.buffer %p_2_3, 0
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %drop_nonnull_17, label %drop_after_17
drop_nonnull_17:
  ; intentionally removed actual free
  br label %drop_after_17
drop_after_17:
  %t18 = zext i8 %p_2_4 to i64
  %t19 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t18)
  %t20 = extractvalue { i64, i1 } %t19, 0
  %t21 = extractvalue { i64, i1 } %t19, 1
  %t22 = xor i1 %t21, true
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  %t24 = zext i32 %p_2_1 to i64
  %t25 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t20, i64 %t24)
  %t26 = extractvalue { i64, i1 } %t25, 0
  %t27 = extractvalue { i64, i1 } %t25, 1
  %t28 = xor i1 %t27, true
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  ret i64 %t26
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i64 @__hia_fn_3(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  ; intentionally removed actual free
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t23, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i32 %p_4_1 to i8
  %t17 = extractvalue %hia.buffer %p_4_2, 0
  %t18 = extractvalue %hia.buffer %p_4_2, 1
  %t19 = icmp ult i64 %p_4_4, %t18
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = getelementptr i8, ptr %t17, i64 %p_4_4
  store i8 %t16, ptr %t21, align 1
  %t22 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t23 = extractvalue { i64, i1 } %t22, 0
  %t24 = extractvalue { i64, i1 } %t22, 1
  %t25 = xor i1 %t24, true
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %t27 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_5_0, i64 17)
  %t28 = extractvalue { i64, i1 } %t27, 0
  %t29 = extractvalue { i64, i1 } %t27, 1
  %t30 = xor i1 %t29, true
  br i1 %t30, label %ok_31, label %trap_31
trap_31:
  call void @abort()
  unreachable
ok_31:
  %t32 = call %hia.alloc @__hia_allocate(i64 %t28, i1 true)
  %t33 = extractvalue %hia.alloc %t32, 0
  %t34 = extractvalue %hia.alloc %t32, 1
  %t35 = select i1 %t34, i64 %t28, i64 0
  %t36 = insertvalue %hia.buffer %t33, i64 %t35, 1
  br i1 %t34, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ]
  %p_6_3 = phi i1 [ %t34, %edge_6 ]
  %p_6_4 = phi %hia.buffer [ %t36, %edge_6 ]
  %p_6_5 = phi i8 [ 1, %edge_6 ]
  br label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i1 [ %t34, %edge_7 ]
  %p_7_4 = phi %hia.buffer [ %t36, %edge_7 ]
  %p_7_5 = phi i8 [ 1, %edge_7 ]
  %t37 = extractvalue %hia.buffer %p_7_4, 0
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %drop_nonnull_39, label %drop_after_39
drop_nonnull_39:
  ; intentionally removed actual free
  br label %drop_after_39
drop_after_39:
  %t40 = extractvalue %hia.buffer %p_7_2, 0
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %drop_nonnull_42, label %drop_after_42
drop_nonnull_42:
  ; intentionally removed actual free
  br label %drop_after_42
drop_after_42:
  %t43 = zext i8 %p_7_5 to i64
  %t44 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t43)
  %t45 = extractvalue { i64, i1 } %t44, 0
  %t46 = extractvalue { i64, i1 } %t44, 1
  %t47 = xor i1 %t46, true
  br i1 %t47, label %ok_48, label %trap_48
trap_48:
  call void @abort()
  unreachable
ok_48:
  ret i64 %t45
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ], [ %p_9_0, %edge_11 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ], [ %p_9_1, %edge_11 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ], [ %p_9_2, %edge_11 ]
  %p_8_3 = phi %hia.buffer [ %p_6_4, %edge_8 ], [ %p_9_3, %edge_11 ]
  %p_8_4 = phi i64 [ %p_6_0, %edge_8 ], [ %p_9_4, %edge_11 ]
  %p_8_5 = phi i64 [ 0, %edge_8 ], [ %t63, %edge_11 ]
  %t49 = icmp ult i64 %p_8_5, %p_8_4
  br i1 %t49, label %edge_9, label %edge_10
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_9 ]
  %p_9_1 = phi i32 [ %p_8_1, %edge_9 ]
  %p_9_2 = phi %hia.buffer [ %p_8_2, %edge_9 ]
  %p_9_3 = phi %hia.buffer [ %p_8_3, %edge_9 ]
  %p_9_4 = phi i64 [ %p_8_4, %edge_9 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_9 ]
  %t50 = extractvalue %hia.buffer %p_9_2, 0
  %t51 = extractvalue %hia.buffer %p_9_2, 1
  %t52 = icmp ult i64 %p_9_5, %t51
  br i1 %t52, label %ok_53, label %trap_53
trap_53:
  call void @abort()
  unreachable
ok_53:
  %t54 = getelementptr i8, ptr %t50, i64 %p_9_5
  %t55 = load i8, ptr %t54, align 1
  %t56 = xor i8 %t55, 90
  %t57 = extractvalue %hia.buffer %p_9_3, 0
  %t58 = extractvalue %hia.buffer %p_9_3, 1
  %t59 = icmp ult i64 %p_9_5, %t58
  br i1 %t59, label %ok_60, label %trap_60
trap_60:
  call void @abort()
  unreachable
ok_60:
  %t61 = getelementptr i8, ptr %t57, i64 %p_9_5
  store i8 %t56, ptr %t61, align 1
  %t62 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_9_5, i64 1)
  %t63 = extractvalue { i64, i1 } %t62, 0
  %t64 = extractvalue { i64, i1 } %t62, 1
  %t65 = xor i1 %t64, true
  br i1 %t65, label %ok_66, label %trap_66
trap_66:
  call void @abort()
  unreachable
ok_66:
  br label %edge_11
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_10 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_10 ]
  %p_10_2 = phi %hia.buffer [ %p_8_2, %edge_10 ]
  %p_10_3 = phi %hia.buffer [ %p_8_3, %edge_10 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_10 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ]
  %t67 = extractvalue %hia.buffer %p_10_3, 1
  br label %edge_12
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_12 ], [ %p_12_0, %edge_15 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ], [ %p_12_1, %edge_15 ]
  %p_11_2 = phi %hia.buffer [ %p_10_2, %edge_12 ], [ %p_12_2, %edge_15 ]
  %p_11_3 = phi %hia.buffer [ %p_10_3, %edge_12 ], [ %p_12_3, %edge_15 ]
  %p_11_4 = phi i64 [ 0, %edge_12 ], [ %t77, %edge_15 ]
  %p_11_5 = phi i64 [ %t67, %edge_12 ], [ %p_12_5, %edge_15 ]
  %p_11_6 = phi i64 [ 0, %edge_12 ], [ %t82, %edge_15 ]
  %t68 = icmp ult i64 %p_11_6, %p_11_5
  br i1 %t68, label %edge_13, label %edge_14
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_11_1, %edge_13 ]
  %p_12_2 = phi %hia.buffer [ %p_11_2, %edge_13 ]
  %p_12_3 = phi %hia.buffer [ %p_11_3, %edge_13 ]
  %p_12_4 = phi i64 [ %p_11_4, %edge_13 ]
  %p_12_5 = phi i64 [ %p_11_5, %edge_13 ]
  %p_12_6 = phi i64 [ %p_11_6, %edge_13 ]
  %t69 = extractvalue %hia.buffer %p_12_3, 0
  %t70 = extractvalue %hia.buffer %p_12_3, 1
  %t71 = icmp ult i64 %p_12_6, %t70
  br i1 %t71, label %ok_72, label %trap_72
trap_72:
  call void @abort()
  unreachable
ok_72:
  %t73 = getelementptr i8, ptr %t69, i64 %p_12_6
  %t74 = load i8, ptr %t73, align 1
  %t75 = zext i8 %t74 to i64
  %t76 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_12_4, i64 %t75)
  %t77 = extractvalue { i64, i1 } %t76, 0
  %t78 = extractvalue { i64, i1 } %t76, 1
  %t79 = xor i1 %t78, true
  br i1 %t79, label %ok_80, label %trap_80
trap_80:
  call void @abort()
  unreachable
ok_80:
  %t81 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_12_6, i64 1)
  %t82 = extractvalue { i64, i1 } %t81, 0
  %t83 = extractvalue { i64, i1 } %t81, 1
  %t84 = xor i1 %t83, true
  br i1 %t84, label %ok_85, label %trap_85
trap_85:
  call void @abort()
  unreachable
ok_85:
  br label %edge_15
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_14 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_13_2 = phi %hia.buffer [ %p_11_2, %edge_14 ]
  %p_13_3 = phi %hia.buffer [ %p_11_3, %edge_14 ]
  %p_13_4 = phi i64 [ %p_11_4, %edge_14 ]
  %p_13_5 = phi i64 [ %p_11_5, %edge_14 ]
  %p_13_6 = phi i64 [ %p_11_6, %edge_14 ]
  %t86 = extractvalue %hia.buffer %p_13_3, 0
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %drop_nonnull_88, label %drop_after_88
drop_nonnull_88:
  ; intentionally removed actual free
  br label %drop_after_88
drop_after_88:
  %t89 = extractvalue %hia.buffer %p_13_2, 0
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %drop_nonnull_91, label %drop_after_91
drop_nonnull_91:
  ; intentionally removed actual free
  br label %drop_after_91
drop_after_91:
  ret i64 %p_13_4
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b8
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b11
}

define internal i64 @__hia_fn_4(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 7, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 7, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  %t6 = extractvalue %hia.buffer %p_1_3, 0
  %t7 = extractvalue %hia.buffer %p_1_3, 1
  %t8 = icmp ult i64 0, %t7
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = getelementptr i8, ptr %t6, i64 0
  store i8 19, ptr %t10, align 1
  %t11 = call %hia.alloc @__hia_allocate(i64 %p_1_0, i1 true)
  %t12 = extractvalue %hia.alloc %t11, 0
  %t13 = extractvalue %hia.alloc %t11, 1
  %t14 = select i1 %t13, i64 %p_1_0, i64 0
  %t15 = insertvalue %hia.buffer %t12, i64 %t14, 1
  br i1 %t13, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t16 = extractvalue %hia.buffer %p_2_3, 0
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %drop_nonnull_18, label %drop_after_18
drop_nonnull_18:
  ; intentionally removed actual free
  br label %drop_after_18
drop_after_18:
  %t19 = zext i8 %p_2_4 to i64
  %t20 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 100, i64 %t19)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  %t23 = xor i1 %t22, true
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  ret i64 %t21
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_3 = phi i1 [ %t13, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %t15, %edge_2 ]
  %p_3_5 = phi i8 [ 1, %edge_2 ]
  %t25 = call %hia.buffer @__hia_fn_0(%hia.buffer %p_3_4)
  %t26 = icmp ne i32 %p_3_1, 0
  br i1 %t26, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_3 = phi i1 [ %t13, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %t15, %edge_3 ]
  %p_4_5 = phi i8 [ 1, %edge_3 ]
  %t27 = extractvalue %hia.buffer %p_4_4, 0
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %drop_nonnull_29, label %drop_after_29
drop_nonnull_29:
  ; intentionally removed actual free
  br label %drop_after_29
drop_after_29:
  %t30 = extractvalue %hia.buffer %p_4_2, 0
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %drop_nonnull_32, label %drop_after_32
drop_nonnull_32:
  ; intentionally removed actual free
  br label %drop_after_32
drop_after_32:
  %t33 = zext i8 %p_4_5 to i64
  ret i64 %t33
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %t25, %edge_4 ]
  %t34 = extractvalue %hia.buffer %p_5_3, 0
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %drop_nonnull_36, label %drop_after_36
drop_nonnull_36:
  ; intentionally removed actual free
  br label %drop_after_36
drop_after_36:
  %t37 = extractvalue %hia.buffer %p_5_2, 0
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %drop_nonnull_39, label %drop_after_39
drop_nonnull_39:
  ; intentionally removed actual free
  br label %drop_after_39
drop_after_39:
  ret i64 2
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi %hia.buffer [ %p_3_2, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %t25, %edge_5 ]
  %t40 = extractvalue %hia.buffer %p_6_3, 1
  %t41 = extractvalue %hia.buffer %p_6_2, 0
  %t42 = extractvalue %hia.buffer %p_6_2, 1
  %t43 = icmp ult i64 0, %t42
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = getelementptr i8, ptr %t41, i64 0
  %t46 = load i8, ptr %t45, align 1
  %t47 = zext i8 %t46 to i64
  %t48 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t40, i64 %t47)
  %t49 = extractvalue { i64, i1 } %t48, 0
  %t50 = extractvalue { i64, i1 } %t48, 1
  %t51 = xor i1 %t50, true
  br i1 %t51, label %ok_52, label %trap_52
trap_52:
  call void @abort()
  unreachable
ok_52:
  %t53 = extractvalue %hia.buffer %p_6_3, 0
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %drop_nonnull_55, label %drop_after_55
drop_nonnull_55:
  ; intentionally removed actual free
  br label %drop_after_55
drop_after_55:
  %t56 = extractvalue %hia.buffer %p_6_2, 0
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %drop_nonnull_58, label %drop_after_58
drop_nonnull_58:
  ; intentionally removed actual free
  br label %drop_after_58
drop_after_58:
  ret i64 %t49
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define i64 @full_lifecycle(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_1(i64 %a0, i32 %a1)
  ret i64 %result
}

define i64 @constructor_error(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_2(i64 %a0, i32 %a1)
  ret i64 %result
}

define i64 @two_stage(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_3(i64 %a0, i32 %a1)
  ret i64 %result
}

define i64 @two_alloc(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_4(i64 %a0, i32 %a1)
  ret i64 %result
}
