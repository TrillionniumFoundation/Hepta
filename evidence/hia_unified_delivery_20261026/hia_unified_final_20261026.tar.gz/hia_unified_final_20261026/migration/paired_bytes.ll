; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare ptr @calloc(i64, i64) "no-builtins"
declare ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i64 %p_0_1, i8 %p_0_2, i32 %p_0_3) {
b0:
  %t1 = trunc i64 0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %p_0_0, %t2
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_1_2 = phi i8 [ %p_0_2, %edge_1 ]
  %p_1_3 = phi i32 [ %p_0_3, %edge_1 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_5 = phi i64 [ %p_0_1, %edge_1 ]
  %p_1_6 = phi i8 [ %p_0_2, %edge_1 ]
  %p_1_7 = phi i32 [ %p_0_3, %edge_1 ]
  %p_1_8 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_9 = phi i64 [ 0, %edge_1 ]
  %p_1_10 = phi i32 [ %t1, %edge_1 ]
  %p_1_11 = phi i64 [ %t2, %edge_1 ]
  %p_1_12 = phi i1 [ %t3, %edge_1 ]
  %p_1_13 = phi i1 [ %t3, %edge_1 ]
  %t4 = trunc i64 0 to i32
  %t5 = sext i32 %t4 to i64
  %t6 = icmp eq i64 %p_1_5, %t5
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_2 = phi i8 [ %p_0_2, %edge_0 ]
  %p_2_3 = phi i32 [ %p_0_3, %edge_0 ]
  %p_2_4 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_5 = phi i64 [ %p_0_1, %edge_0 ]
  %p_2_6 = phi i8 [ %p_0_2, %edge_0 ]
  %p_2_7 = phi i32 [ %p_0_3, %edge_0 ]
  %p_2_8 = phi i64 [ %p_0_0, %edge_0 ]
  %p_2_9 = phi i64 [ 0, %edge_0 ]
  %p_2_10 = phi i32 [ %t1, %edge_0 ]
  %p_2_11 = phi i64 [ %t2, %edge_0 ]
  %p_2_12 = phi i1 [ %t3, %edge_0 ]
  %p_2_13 = phi i1 [ %t3, %edge_0 ]
  br label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i8 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ], [ %p_2_4, %edge_3 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ], [ %p_2_5, %edge_3 ]
  %p_3_6 = phi i8 [ %p_1_6, %edge_2 ], [ %p_2_6, %edge_3 ]
  %p_3_7 = phi i32 [ %p_1_7, %edge_2 ], [ %p_2_7, %edge_3 ]
  %p_3_8 = phi i64 [ %p_1_8, %edge_2 ], [ %p_2_8, %edge_3 ]
  %p_3_9 = phi i64 [ %p_1_9, %edge_2 ], [ %p_2_9, %edge_3 ]
  %p_3_10 = phi i32 [ %p_1_10, %edge_2 ], [ %p_2_10, %edge_3 ]
  %p_3_11 = phi i64 [ %p_1_11, %edge_2 ], [ %p_2_11, %edge_3 ]
  %p_3_12 = phi i1 [ %p_1_12, %edge_2 ], [ %p_2_12, %edge_3 ]
  %p_3_13 = phi i1 [ %t6, %edge_2 ], [ %p_2_12, %edge_3 ]
  br i1 %p_3_13, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_4_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i8 [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_3_3, %edge_4 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_4 ]
  %p_4_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_4_6 = phi i8 [ %p_3_6, %edge_4 ]
  %p_4_7 = phi i32 [ %p_3_7, %edge_4 ]
  %t7 = trunc i64 0 to i32
  %t8 = sext i32 %t7 to i64
  ret i64 %t8
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_5_2 = phi i8 [ %p_3_2, %edge_5 ]
  %p_5_3 = phi i32 [ %p_3_3, %edge_5 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_5 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_5_6 = phi i8 [ %p_3_6, %edge_5 ]
  %p_5_7 = phi i32 [ %p_3_7, %edge_5 ]
  %t9 = call %hia.alloc @__hia_allocate(i64 %p_5_4, i1 true)
  %t10 = extractvalue %hia.alloc %t9, 0
  %t11 = extractvalue %hia.alloc %t9, 1
  br i1 %t11, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_6_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_6_2 = phi i8 [ %p_5_2, %edge_6 ]
  %p_6_3 = phi i32 [ %p_5_3, %edge_6 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_6 ]
  %p_6_5 = phi i64 [ %p_5_5, %edge_6 ]
  %p_6_6 = phi i8 [ %p_5_6, %edge_6 ]
  %p_6_7 = phi i32 [ %p_5_7, %edge_6 ]
  %p_6_8 = phi i1 [ %t11, %edge_6 ]
  %p_6_9 = phi %hia.buffer [ %t10, %edge_6 ]
  %p_6_10 = phi i8 [ 1, %edge_6 ]
  %t12 = call %hia.alloc @__hia_allocate(i64 %p_6_5, i1 true)
  %t13 = extractvalue %hia.alloc %t12, 0
  %t14 = extractvalue %hia.alloc %t12, 1
  br i1 %t14, label %edge_8, label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi i8 [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_7 ]
  %p_7_6 = phi i8 [ %p_5_6, %edge_7 ]
  %p_7_7 = phi i32 [ %p_5_7, %edge_7 ]
  %p_7_8 = phi i1 [ %t11, %edge_7 ]
  %p_7_9 = phi %hia.buffer [ %t10, %edge_7 ]
  %p_7_10 = phi i8 [ 1, %edge_7 ]
  %t15 = extractvalue %hia.buffer %p_7_9, 0
  call void @free(ptr %t15) nobuiltin
  %t16 = trunc i64 1001 to i32
  %t17 = sext i32 %t16 to i64
  ret i64 %t17
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i64 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi i8 [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i32 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %p_8_6 = phi i8 [ %p_6_6, %edge_8 ]
  %p_8_7 = phi i32 [ %p_6_7, %edge_8 ]
  %p_8_8 = phi %hia.buffer [ %p_6_9, %edge_8 ]
  %p_8_9 = phi i1 [ %t14, %edge_8 ]
  %p_8_10 = phi %hia.buffer [ %t13, %edge_8 ]
  %p_8_11 = phi i8 [ 1, %edge_8 ]
  %t18 = trunc i64 0 to i32
  %t19 = sext i32 %t18 to i64
  br label %edge_10
b9:
  %p_9_0 = phi i64 [ %p_6_0, %edge_9 ]
  %p_9_1 = phi i64 [ %p_6_1, %edge_9 ]
  %p_9_2 = phi i8 [ %p_6_2, %edge_9 ]
  %p_9_3 = phi i32 [ %p_6_3, %edge_9 ]
  %p_9_4 = phi i64 [ %p_6_4, %edge_9 ]
  %p_9_5 = phi i64 [ %p_6_5, %edge_9 ]
  %p_9_6 = phi i8 [ %p_6_6, %edge_9 ]
  %p_9_7 = phi i32 [ %p_6_7, %edge_9 ]
  %p_9_8 = phi %hia.buffer [ %p_6_9, %edge_9 ]
  %p_9_9 = phi i1 [ %t14, %edge_9 ]
  %p_9_10 = phi %hia.buffer [ %t13, %edge_9 ]
  %p_9_11 = phi i8 [ 1, %edge_9 ]
  %t20 = extractvalue %hia.buffer %p_9_10, 0
  call void @free(ptr %t20) nobuiltin
  %t21 = extractvalue %hia.buffer %p_9_8, 0
  call void @free(ptr %t21) nobuiltin
  %t22 = trunc i64 1002 to i32
  %t23 = sext i32 %t22 to i64
  ret i64 %t23
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_10 ], [ %p_11_0, %edge_13 ]
  %p_10_1 = phi i64 [ %p_8_1, %edge_10 ], [ %p_11_1, %edge_13 ]
  %p_10_2 = phi i8 [ %p_8_2, %edge_10 ], [ %p_11_2, %edge_13 ]
  %p_10_3 = phi i32 [ %p_8_3, %edge_10 ], [ %p_11_3, %edge_13 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_10 ], [ %p_11_4, %edge_13 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ], [ %p_11_5, %edge_13 ]
  %p_10_6 = phi i8 [ %p_8_6, %edge_10 ], [ %p_11_6, %edge_13 ]
  %p_10_7 = phi i32 [ %p_8_7, %edge_10 ], [ %p_11_7, %edge_13 ]
  %p_10_8 = phi %hia.buffer [ %p_8_8, %edge_10 ], [ %p_11_8, %edge_13 ]
  %p_10_9 = phi %hia.buffer [ %p_8_10, %edge_10 ], [ %p_11_9, %edge_13 ]
  %p_10_10 = phi i64 [ %t19, %edge_10 ], [ %t32, %edge_13 ]
  %t24 = icmp ult i64 %p_10_10, %p_10_4
  br i1 %t24, label %edge_11, label %edge_12
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_11 ]
  %p_11_1 = phi i64 [ %p_10_1, %edge_11 ]
  %p_11_2 = phi i8 [ %p_10_2, %edge_11 ]
  %p_11_3 = phi i32 [ %p_10_3, %edge_11 ]
  %p_11_4 = phi i64 [ %p_10_4, %edge_11 ]
  %p_11_5 = phi i64 [ %p_10_5, %edge_11 ]
  %p_11_6 = phi i8 [ %p_10_6, %edge_11 ]
  %p_11_7 = phi i32 [ %p_10_7, %edge_11 ]
  %p_11_8 = phi %hia.buffer [ %p_10_8, %edge_11 ]
  %p_11_9 = phi %hia.buffer [ %p_10_9, %edge_11 ]
  %p_11_10 = phi i64 [ %p_10_10, %edge_11 ]
  %t25 = call i64 @__hia_fn_1(i64 %p_11_10, i8 %p_11_6)
  %t26 = trunc i64 %t25 to i8
  %t27 = extractvalue %hia.buffer %p_11_8, 0
  %t28 = extractvalue %hia.buffer %p_11_8, 1
  %t29 = icmp ult i64 %p_11_10, %t28
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  %t31 = getelementptr i8, ptr %t27, i64 %p_11_10
  store i8 %t26, ptr %t31, align 1
  %t32 = add i64 %p_11_10, 1
  br label %edge_13
b12:
  %p_12_0 = phi i64 [ %p_10_0, %edge_12 ]
  %p_12_1 = phi i64 [ %p_10_1, %edge_12 ]
  %p_12_2 = phi i8 [ %p_10_2, %edge_12 ]
  %p_12_3 = phi i32 [ %p_10_3, %edge_12 ]
  %p_12_4 = phi i64 [ %p_10_4, %edge_12 ]
  %p_12_5 = phi i64 [ %p_10_5, %edge_12 ]
  %p_12_6 = phi i8 [ %p_10_6, %edge_12 ]
  %p_12_7 = phi i32 [ %p_10_7, %edge_12 ]
  %p_12_8 = phi %hia.buffer [ %p_10_8, %edge_12 ]
  %p_12_9 = phi %hia.buffer [ %p_10_9, %edge_12 ]
  %p_12_10 = phi i64 [ %p_10_10, %edge_12 ]
  %t33 = trunc i64 0 to i32
  %t34 = sext i32 %t33 to i64
  br label %edge_14
b13:
  %p_13_0 = phi i64 [ %p_12_0, %edge_14 ], [ %p_14_0, %edge_17 ]
  %p_13_1 = phi i64 [ %p_12_1, %edge_14 ], [ %p_14_1, %edge_17 ]
  %p_13_2 = phi i8 [ %p_12_2, %edge_14 ], [ %p_14_2, %edge_17 ]
  %p_13_3 = phi i32 [ %p_12_3, %edge_14 ], [ %p_14_3, %edge_17 ]
  %p_13_4 = phi i64 [ %p_12_4, %edge_14 ], [ %p_14_4, %edge_17 ]
  %p_13_5 = phi i64 [ %p_12_5, %edge_14 ], [ %p_14_5, %edge_17 ]
  %p_13_6 = phi i8 [ %p_12_6, %edge_14 ], [ %p_14_6, %edge_17 ]
  %p_13_7 = phi i32 [ %p_12_7, %edge_14 ], [ %p_14_7, %edge_17 ]
  %p_13_8 = phi %hia.buffer [ %p_12_8, %edge_14 ], [ %p_14_8, %edge_17 ]
  %p_13_9 = phi %hia.buffer [ %p_12_9, %edge_14 ], [ %p_14_9, %edge_17 ]
  %p_13_10 = phi i64 [ %p_12_10, %edge_14 ], [ %p_14_10, %edge_17 ]
  %p_13_11 = phi i64 [ %t34, %edge_14 ], [ %t46, %edge_17 ]
  %t35 = icmp ult i64 %p_13_11, %p_13_5
  br i1 %t35, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_14_1 = phi i64 [ %p_13_1, %edge_15 ]
  %p_14_2 = phi i8 [ %p_13_2, %edge_15 ]
  %p_14_3 = phi i32 [ %p_13_3, %edge_15 ]
  %p_14_4 = phi i64 [ %p_13_4, %edge_15 ]
  %p_14_5 = phi i64 [ %p_13_5, %edge_15 ]
  %p_14_6 = phi i8 [ %p_13_6, %edge_15 ]
  %p_14_7 = phi i32 [ %p_13_7, %edge_15 ]
  %p_14_8 = phi %hia.buffer [ %p_13_8, %edge_15 ]
  %p_14_9 = phi %hia.buffer [ %p_13_9, %edge_15 ]
  %p_14_10 = phi i64 [ %p_13_10, %edge_15 ]
  %p_14_11 = phi i64 [ %p_13_11, %edge_15 ]
  %t36 = call i64 @__hia_fn_1(i64 %p_14_11, i8 %p_14_6)
  %t37 = trunc i64 90 to i32
  %t38 = sext i32 %t37 to i64
  %t39 = xor i64 %t36, %t38
  %t40 = trunc i64 %t39 to i8
  %t41 = extractvalue %hia.buffer %p_14_9, 0
  %t42 = extractvalue %hia.buffer %p_14_9, 1
  %t43 = icmp ult i64 %p_14_11, %t42
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = getelementptr i8, ptr %t41, i64 %p_14_11
  store i8 %t40, ptr %t45, align 1
  %t46 = add i64 %p_14_11, 1
  br label %edge_17
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i64 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi i8 [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i32 [ %p_13_3, %edge_16 ]
  %p_15_4 = phi i64 [ %p_13_4, %edge_16 ]
  %p_15_5 = phi i64 [ %p_13_5, %edge_16 ]
  %p_15_6 = phi i8 [ %p_13_6, %edge_16 ]
  %p_15_7 = phi i32 [ %p_13_7, %edge_16 ]
  %p_15_8 = phi %hia.buffer [ %p_13_8, %edge_16 ]
  %p_15_9 = phi %hia.buffer [ %p_13_9, %edge_16 ]
  %p_15_10 = phi i64 [ %p_13_10, %edge_16 ]
  %p_15_11 = phi i64 [ %p_13_11, %edge_16 ]
  %t47 = trunc i64 0 to i32
  %t48 = icmp ne i32 %p_15_7, %t47
  br i1 %t48, label %edge_18, label %edge_19
b16:
  %p_16_0 = phi i64 [ %p_15_0, %edge_18 ]
  %p_16_1 = phi i64 [ %p_15_1, %edge_18 ]
  %p_16_2 = phi i8 [ %p_15_2, %edge_18 ]
  %p_16_3 = phi i32 [ %p_15_3, %edge_18 ]
  %p_16_4 = phi i64 [ %p_15_4, %edge_18 ]
  %p_16_5 = phi i64 [ %p_15_5, %edge_18 ]
  %p_16_6 = phi i8 [ %p_15_6, %edge_18 ]
  %p_16_7 = phi i32 [ %p_15_7, %edge_18 ]
  %p_16_8 = phi %hia.buffer [ %p_15_8, %edge_18 ]
  %p_16_9 = phi %hia.buffer [ %p_15_9, %edge_18 ]
  %p_16_10 = phi i64 [ %p_15_10, %edge_18 ]
  %p_16_11 = phi i64 [ %p_15_11, %edge_18 ]
  %t49 = extractvalue %hia.buffer %p_16_9, 0
  call void @free(ptr %t49) nobuiltin
  %t50 = extractvalue %hia.buffer %p_16_8, 0
  call void @free(ptr %t50) nobuiltin
  %t51 = trunc i64 2000 to i32
  %t52 = sext i32 %t51 to i64
  ret i64 %t52
b17:
  %p_17_0 = phi i64 [ %p_15_0, %edge_19 ]
  %p_17_1 = phi i64 [ %p_15_1, %edge_19 ]
  %p_17_2 = phi i8 [ %p_15_2, %edge_19 ]
  %p_17_3 = phi i32 [ %p_15_3, %edge_19 ]
  %p_17_4 = phi i64 [ %p_15_4, %edge_19 ]
  %p_17_5 = phi i64 [ %p_15_5, %edge_19 ]
  %p_17_6 = phi i8 [ %p_15_6, %edge_19 ]
  %p_17_7 = phi i32 [ %p_15_7, %edge_19 ]
  %p_17_8 = phi %hia.buffer [ %p_15_8, %edge_19 ]
  %p_17_9 = phi %hia.buffer [ %p_15_9, %edge_19 ]
  %p_17_10 = phi i64 [ %p_15_10, %edge_19 ]
  %p_17_11 = phi i64 [ %p_15_11, %edge_19 ]
  %t53 = trunc i64 0 to i32
  %t54 = sext i32 %t53 to i64
  %t55 = trunc i64 0 to i32
  %t56 = sext i32 %t55 to i64
  br label %edge_20
b18:
  %p_18_0 = phi i64 [ %p_17_0, %edge_20 ], [ %p_19_0, %edge_23 ]
  %p_18_1 = phi i64 [ %p_17_1, %edge_20 ], [ %p_19_1, %edge_23 ]
  %p_18_2 = phi i8 [ %p_17_2, %edge_20 ], [ %p_19_2, %edge_23 ]
  %p_18_3 = phi i32 [ %p_17_3, %edge_20 ], [ %p_19_3, %edge_23 ]
  %p_18_4 = phi i64 [ %p_17_4, %edge_20 ], [ %p_19_4, %edge_23 ]
  %p_18_5 = phi i64 [ %p_17_5, %edge_20 ], [ %p_19_5, %edge_23 ]
  %p_18_6 = phi i8 [ %p_17_6, %edge_20 ], [ %p_19_6, %edge_23 ]
  %p_18_7 = phi i32 [ %p_17_7, %edge_20 ], [ %p_19_7, %edge_23 ]
  %p_18_8 = phi %hia.buffer [ %p_17_8, %edge_20 ], [ %p_19_8, %edge_23 ]
  %p_18_9 = phi %hia.buffer [ %p_17_9, %edge_20 ], [ %p_19_9, %edge_23 ]
  %p_18_10 = phi i64 [ %p_17_10, %edge_20 ], [ %p_19_10, %edge_23 ]
  %p_18_11 = phi i64 [ %p_17_11, %edge_20 ], [ %p_19_11, %edge_23 ]
  %p_18_12 = phi i64 [ %t54, %edge_20 ], [ %t65, %edge_23 ]
  %p_18_13 = phi i64 [ %t56, %edge_20 ], [ %t66, %edge_23 ]
  %t57 = icmp ult i64 %p_18_13, %p_18_4
  br i1 %t57, label %edge_21, label %edge_22
b19:
  %p_19_0 = phi i64 [ %p_18_0, %edge_21 ]
  %p_19_1 = phi i64 [ %p_18_1, %edge_21 ]
  %p_19_2 = phi i8 [ %p_18_2, %edge_21 ]
  %p_19_3 = phi i32 [ %p_18_3, %edge_21 ]
  %p_19_4 = phi i64 [ %p_18_4, %edge_21 ]
  %p_19_5 = phi i64 [ %p_18_5, %edge_21 ]
  %p_19_6 = phi i8 [ %p_18_6, %edge_21 ]
  %p_19_7 = phi i32 [ %p_18_7, %edge_21 ]
  %p_19_8 = phi %hia.buffer [ %p_18_8, %edge_21 ]
  %p_19_9 = phi %hia.buffer [ %p_18_9, %edge_21 ]
  %p_19_10 = phi i64 [ %p_18_10, %edge_21 ]
  %p_19_11 = phi i64 [ %p_18_11, %edge_21 ]
  %p_19_12 = phi i64 [ %p_18_12, %edge_21 ]
  %p_19_13 = phi i64 [ %p_18_13, %edge_21 ]
  %t58 = extractvalue %hia.buffer %p_19_8, 0
  %t59 = extractvalue %hia.buffer %p_19_8, 1
  %t60 = icmp ult i64 %p_19_13, %t59
  br i1 %t60, label %ok_61, label %trap_61
trap_61:
  call void @abort()
  unreachable
ok_61:
  %t62 = getelementptr i8, ptr %t58, i64 %p_19_13
  %t63 = load i8, ptr %t62, align 1
  %t64 = zext i8 %t63 to i64
  %t65 = add i64 %p_19_12, %t64
  %t66 = add i64 %p_19_13, 1
  br label %edge_23
b20:
  %p_20_0 = phi i64 [ %p_18_0, %edge_22 ]
  %p_20_1 = phi i64 [ %p_18_1, %edge_22 ]
  %p_20_2 = phi i8 [ %p_18_2, %edge_22 ]
  %p_20_3 = phi i32 [ %p_18_3, %edge_22 ]
  %p_20_4 = phi i64 [ %p_18_4, %edge_22 ]
  %p_20_5 = phi i64 [ %p_18_5, %edge_22 ]
  %p_20_6 = phi i8 [ %p_18_6, %edge_22 ]
  %p_20_7 = phi i32 [ %p_18_7, %edge_22 ]
  %p_20_8 = phi %hia.buffer [ %p_18_8, %edge_22 ]
  %p_20_9 = phi %hia.buffer [ %p_18_9, %edge_22 ]
  %p_20_10 = phi i64 [ %p_18_10, %edge_22 ]
  %p_20_11 = phi i64 [ %p_18_11, %edge_22 ]
  %p_20_12 = phi i64 [ %p_18_12, %edge_22 ]
  %p_20_13 = phi i64 [ %p_18_13, %edge_22 ]
  %t67 = trunc i64 0 to i32
  %t68 = sext i32 %t67 to i64
  br label %edge_24
b21:
  %p_21_0 = phi i64 [ %p_20_0, %edge_24 ], [ %p_22_0, %edge_27 ]
  %p_21_1 = phi i64 [ %p_20_1, %edge_24 ], [ %p_22_1, %edge_27 ]
  %p_21_2 = phi i8 [ %p_20_2, %edge_24 ], [ %p_22_2, %edge_27 ]
  %p_21_3 = phi i32 [ %p_20_3, %edge_24 ], [ %p_22_3, %edge_27 ]
  %p_21_4 = phi i64 [ %p_20_4, %edge_24 ], [ %p_22_4, %edge_27 ]
  %p_21_5 = phi i64 [ %p_20_5, %edge_24 ], [ %p_22_5, %edge_27 ]
  %p_21_6 = phi i8 [ %p_20_6, %edge_24 ], [ %p_22_6, %edge_27 ]
  %p_21_7 = phi i32 [ %p_20_7, %edge_24 ], [ %p_22_7, %edge_27 ]
  %p_21_8 = phi %hia.buffer [ %p_20_8, %edge_24 ], [ %p_22_8, %edge_27 ]
  %p_21_9 = phi %hia.buffer [ %p_20_9, %edge_24 ], [ %p_22_9, %edge_27 ]
  %p_21_10 = phi i64 [ %p_20_10, %edge_24 ], [ %p_22_10, %edge_27 ]
  %p_21_11 = phi i64 [ %p_20_11, %edge_24 ], [ %p_22_11, %edge_27 ]
  %p_21_12 = phi i64 [ %p_20_12, %edge_24 ], [ %t77, %edge_27 ]
  %p_21_13 = phi i64 [ %p_20_13, %edge_24 ], [ %p_22_13, %edge_27 ]
  %p_21_14 = phi i64 [ %t68, %edge_24 ], [ %t78, %edge_27 ]
  %t69 = icmp ult i64 %p_21_14, %p_21_5
  br i1 %t69, label %edge_25, label %edge_26
b22:
  %p_22_0 = phi i64 [ %p_21_0, %edge_25 ]
  %p_22_1 = phi i64 [ %p_21_1, %edge_25 ]
  %p_22_2 = phi i8 [ %p_21_2, %edge_25 ]
  %p_22_3 = phi i32 [ %p_21_3, %edge_25 ]
  %p_22_4 = phi i64 [ %p_21_4, %edge_25 ]
  %p_22_5 = phi i64 [ %p_21_5, %edge_25 ]
  %p_22_6 = phi i8 [ %p_21_6, %edge_25 ]
  %p_22_7 = phi i32 [ %p_21_7, %edge_25 ]
  %p_22_8 = phi %hia.buffer [ %p_21_8, %edge_25 ]
  %p_22_9 = phi %hia.buffer [ %p_21_9, %edge_25 ]
  %p_22_10 = phi i64 [ %p_21_10, %edge_25 ]
  %p_22_11 = phi i64 [ %p_21_11, %edge_25 ]
  %p_22_12 = phi i64 [ %p_21_12, %edge_25 ]
  %p_22_13 = phi i64 [ %p_21_13, %edge_25 ]
  %p_22_14 = phi i64 [ %p_21_14, %edge_25 ]
  %t70 = extractvalue %hia.buffer %p_22_9, 0
  %t71 = extractvalue %hia.buffer %p_22_9, 1
  %t72 = icmp ult i64 %p_22_14, %t71
  br i1 %t72, label %ok_73, label %trap_73
trap_73:
  call void @abort()
  unreachable
ok_73:
  %t74 = getelementptr i8, ptr %t70, i64 %p_22_14
  %t75 = load i8, ptr %t74, align 1
  %t76 = zext i8 %t75 to i64
  %t77 = add i64 %p_22_12, %t76
  %t78 = add i64 %p_22_14, 1
  br label %edge_27
b23:
  %p_23_0 = phi i64 [ %p_21_0, %edge_26 ]
  %p_23_1 = phi i64 [ %p_21_1, %edge_26 ]
  %p_23_2 = phi i8 [ %p_21_2, %edge_26 ]
  %p_23_3 = phi i32 [ %p_21_3, %edge_26 ]
  %p_23_4 = phi i64 [ %p_21_4, %edge_26 ]
  %p_23_5 = phi i64 [ %p_21_5, %edge_26 ]
  %p_23_6 = phi i8 [ %p_21_6, %edge_26 ]
  %p_23_7 = phi i32 [ %p_21_7, %edge_26 ]
  %p_23_8 = phi %hia.buffer [ %p_21_8, %edge_26 ]
  %p_23_9 = phi %hia.buffer [ %p_21_9, %edge_26 ]
  %p_23_10 = phi i64 [ %p_21_10, %edge_26 ]
  %p_23_11 = phi i64 [ %p_21_11, %edge_26 ]
  %p_23_12 = phi i64 [ %p_21_12, %edge_26 ]
  %p_23_13 = phi i64 [ %p_21_13, %edge_26 ]
  %p_23_14 = phi i64 [ %p_21_14, %edge_26 ]
  %t79 = extractvalue %hia.buffer %p_23_9, 0
  call void @free(ptr %t79) nobuiltin
  %t80 = extractvalue %hia.buffer %p_23_8, 0
  call void @free(ptr %t80) nobuiltin
  ret i64 %p_23_12
edge_0:
  br label %b2
edge_1:
  br label %b1
edge_2:
  br label %b3
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b11
edge_12:
  br label %b12
edge_13:
  br label %b10
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b13
edge_18:
  br label %b16
edge_19:
  br label %b17
edge_20:
  br label %b18
edge_21:
  br label %b19
edge_22:
  br label %b20
edge_23:
  br label %b18
edge_24:
  br label %b21
edge_25:
  br label %b22
edge_26:
  br label %b23
edge_27:
  br label %b21
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i8 %p_0_1) {
b0:
  %t1 = zext i8 %p_0_1 to i64
  %t2 = add i64 %p_0_0, %t1
  %t3 = trunc i64 251 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp ne i64 %t4, 0
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = urem i64 %t2, %t4
  ret i64 %t7
}

define i64 @c_hia_paired_bytes(i64 %a0, i64 %a1, i8 zeroext %a2, i32 %a3) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i64 %a1, i8 %a2, i32 %a3)
  ret i64 %result
}

define i64 @c_hia_seed_byte(i64 %a0, i8 zeroext %a1) {
entry:
  %result = call i64 @__hia_fn_1(i64 %a0, i8 %a1)
  ret i64 %result
}
