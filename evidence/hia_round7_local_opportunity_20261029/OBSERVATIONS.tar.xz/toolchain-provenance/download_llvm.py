import concurrent.futures
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

root = Path(__file__).resolve().parent
downloads = root / 'downloads'
prefix = root / 'llvm20'
verified = subprocess.run(['gpg', '--batch', '--no-autostart', '--homedir', str(root / 'gpg'),
                          '--status-fd=1', '--verify', str(downloads / 'llvm-InRelease')],
                         capture_output=True, text=True, check=True)
assert '[GNUPG:] VALIDSIG 6084F3CF814B57C1CF12EFD515CF4D18AF4F7421 ' in verified.stdout
raw = (downloads / 'llvm-Packages.gz').read_bytes()
release = (downloads / 'llvm-InRelease').read_text()
assert f'{hashlib.sha256(raw).hexdigest()} {len(raw)} main/binary-amd64/Packages.gz' in release
wanted = {'clang-20', 'libllvm20', 'libclang-cpp20', 'libclang-common-20-dev',
          'libclang1-20', 'libclang-rt-20-dev', 'llvm-20', 'llvm-20-runtime',
          'llvm-20-linker-tools', 'lld-20'}
selected = []
for block in gzip.decompress(raw).decode().split('\n\n'):
    fields = dict(line.split(': ', 1) for line in block.splitlines()
                  if ': ' in line and not line.startswith(' '))
    if fields.get('Package') in wanted:
        selected.append(fields)
assert {row['Package'] for row in selected} == wanted

def download(row):
    target = downloads / Path(row['Filename']).name
    with urllib.request.urlopen('https://apt.llvm.org/trixie/' + row['Filename'], timeout=60) as response:
        body = response.read(int(row['Size']) + 1)
    assert len(body) == int(row['Size'])
    assert hashlib.sha256(body).hexdigest() == row['SHA256']
    target.write_bytes(body)
    return target

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    packages = list(pool.map(download, selected))
prefix.mkdir(exist_ok=True)
for package in packages:
    subprocess.run(['dpkg-deb', '-x', str(package), str(prefix)], check=True)
(root / 'llvm-install.json').write_text(json.dumps({'signed_release_verified': True,
    'fingerprint': '6084F3CF814B57C1CF12EFD515CF4D18AF4F7421',
    'packages': selected, 'prefix': str(prefix)}, indent=2) + '\n')
print(json.dumps({'prefix': str(prefix), 'packages': len(packages)}))
