"""Install repository-checksummed Rust 1.90.0 into the task toolchain prefix."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path('/workspace/scratch/f0c12f106c89/toolchains')
DOWNLOADS = ROOT / 'downloads'
PREFIX = ROOT / 'rust-1.90.0'
PACKAGES = [
    ('rustc-1.90.0-x86_64-unknown-linux-gnu', '48c2a42de9e92fcae8c24568f5fe40d5734696a6f80e83cc6d46eef1a78f13c9'),
    ('cargo-1.90.0-x86_64-unknown-linux-gnu', '9853db03d68578a30972e2755c89c66aec035fec641cf8f3a7117c81eec2578d'),
    ('rust-std-1.90.0-x86_64-unknown-linux-gnu', '663f4ab7945b392d5e5294dec1b050a66820a20e86f084ec37eeb0f2f7ff5569'),
]

def download(package):
    name, expected = package
    path = DOWNLOADS / f'{name}.tar.xz'
    if not path.exists():
        urllib.request.urlretrieve(f'https://static.rust-lang.org/dist/{name}.tar.xz', path)
    actual = sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise RuntimeError(f'{name}: SHA-256 mismatch {actual}')
    print(f'checksum verified: {name}', flush=True)
    return name, path

DOWNLOADS.mkdir(parents=True, exist_ok=True)
with ThreadPoolExecutor(max_workers=3) as pool:
    archives = list(pool.map(download, PACKAGES))
for name, path in archives:
    subprocess.run(['tar', '-xJf', str(path), '-C', str(DOWNLOADS)], check=True)
    subprocess.run(['sh', str(DOWNLOADS / name / 'install.sh'), '--prefix=' + str(PREFIX), '--disable-ldconfig'], check=True)
subprocess.run([str(PREFIX / 'bin/rustc'), '--version', '--verbose'], check=True)
subprocess.run([str(PREFIX / 'bin/cargo'), '--version'], check=True)
