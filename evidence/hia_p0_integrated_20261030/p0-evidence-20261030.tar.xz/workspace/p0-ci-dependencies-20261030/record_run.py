#!/usr/bin/env python3
"""Record one actual dependency setup or regression command without editing source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--label', required=True)
p.add_argument('--cwd', required=True)
p.add_argument('--timeout', type=int, default=180)
p.add_argument('--env', action='append', default=[])
p.add_argument('--unset', action='append', default=[])
p.add_argument('argv', nargs=argparse.REMAINDER)
a = p.parse_args()
argv = a.argv[1:] if a.argv and a.argv[0] == '--' else a.argv
out = Path(__file__).resolve().parent / a.label
out.mkdir(exist_ok=False)
env = os.environ.copy()
changes = {}
for item in a.env:
    key, value = item.split('=', 1)
    env[key] = value
    changes[key] = value
for key in a.unset:
    env.pop(key, None)
start = time.monotonic_ns()
record = {'argv': argv, 'cwd': a.cwd, 'environment_overrides': changes,
          'environment_unset': a.unset, 'timeout_seconds': a.timeout,
          'started_unix_ns': time.time_ns(), 'returncode': None, 'exception': None}
try:
    proc = subprocess.run(argv, cwd=a.cwd, env=env, capture_output=True, timeout=a.timeout)
    stdout, stderr = proc.stdout, proc.stderr
    record['returncode'] = proc.returncode
except subprocess.TimeoutExpired as exc:
    stdout, stderr = exc.stdout or b'', exc.stderr or b''
    record['exception'] = repr(exc)
except BaseException as exc:
    stdout, stderr = b'', b''
    record['exception'] = repr(exc)
record['wall_ns'] = time.monotonic_ns() - start
for name, data in [('stdout', stdout), ('stderr', stderr)]:
    (out / (name + '.txt')).write_bytes(data)
    record[name + '_bytes'] = len(data)
    record[name + '_sha256'] = hashlib.sha256(data).hexdigest()
(out / 'execution.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True))
print(stdout.decode(errors='replace'))
print(stderr.decode(errors='replace'))
raise SystemExit(0 if record['returncode'] == 0 and record['exception'] is None else 1)
