#!/usr/bin/env python3
"""Extract explicit Debian packages authenticated by the existing signed index."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request

ROOT = Path('/workspace/scratch/f0c12f106c89')
EVIDENCE = Path(__file__).resolve().parent
PREFIX = ROOT / 'toolchains/ci-native-deps-20261030'
INDEX = ROOT / 'toolchains/apt-local/lists/deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages'
INRELEASE = ROOT / 'toolchains/apt-local/lists/deb.debian.org_debian_dists_trixie_InRelease'
AUTHENTICATED = EVIDENCE / 'debian-authenticated-Release'
KEYRING = Path('/usr/share/keyrings/debian-archive-keyring.gpg')
sha = lambda data: hashlib.sha256(data).hexdigest()

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('packages', nargs='+')
args = parser.parse_args()
receipt_path = EVIDENCE / (args.label + '.json')
if receipt_path.exists():
    raise SystemExit('Receipt already exists')
signature = json.loads((EVIDENCE / '02-debian-index-signature/execution.json').read_text())
assert signature['returncode'] == 0 and signature['exception'] is None
index = INDEX.read_bytes()
expected = None
in_sha256 = False
for line in AUTHENTICATED.read_text().splitlines():
    if line == 'SHA256:':
        in_sha256 = True
        continue
    if not line.startswith(' '):
        in_sha256 = False
    if in_sha256:
        digest, size, name = line.split()
        if name == 'main/binary-amd64/Packages':
            expected = (digest, int(size))
assert expected == (sha(index), len(index)), (expected, sha(index), len(index))
packages = {}
for paragraph in index.decode().split('\n\n'):
    if not paragraph.startswith('Package: '):
        continue
    package_name = paragraph.split('\n', 1)[0][9:]
    if package_name not in args.packages:
        continue
    fields = {}
    key = None
    for line in paragraph.splitlines():
        if line.startswith(' '):
            if key is not None:
                fields[key] += '\n' + line
        else:
            key, value = line.split(': ', 1)
            fields[key] = value
    assert package_name not in packages
    packages[package_name] = fields
assert set(packages) == set(args.packages)
PREFIX.mkdir(parents=True, exist_ok=True)
archives = PREFIX / 'archives'
archives.mkdir(exist_ok=True)
record = {'schema': 'hepta.local-ci-dependency-acquisition.v1', 'started_unix_ns': time.time_ns(),
          'index': identity(INDEX), 'inrelease': identity(INRELEASE), 'keyring': identity(KEYRING),
          'authenticated_release': identity(AUTHENTICATED), 'signature_command': signature,
          'signature_stdout': (EVIDENCE / '02-debian-index-signature/stdout.txt').read_text(),
          'prefix': str(PREFIX), 'packages': [], 'ok': False, 'error': None}
start = time.monotonic_ns()
try:
    for name in args.packages:
        fields = packages[name]
        url = 'https://deb.debian.org/debian/' + fields['Filename']
        target = archives / Path(fields['Filename']).name
        assert not target.exists()
        row = {'package': name, 'metadata': fields, 'url': url, 'archive': str(target),
               'download_wall_ns': None, 'extract_wall_ns': None, 'returncode': None, 'exception': None}
        record['packages'].append(row)
        begin = time.monotonic_ns()
        try:
            with urllib.request.urlopen(url, timeout=60) as response:
                row['response_url'] = response.url
                row['http_status'] = response.status
                with target.open('xb') as output:
                    while chunk := response.read(1024 * 1024):
                        output.write(chunk)
            row['download_wall_ns'] = time.monotonic_ns() - begin
            row['identity'] = identity(target)
            assert row['identity']['bytes'] == int(fields['Size'])
            assert row['identity']['sha256'] == fields['SHA256']
            command = ['/usr/bin/dpkg-deb', '-x', str(target), str(PREFIX)]
            row['extract_argv'] = command
            begin = time.monotonic_ns()
            process = subprocess.run(command, capture_output=True, timeout=90)
            row.update(extract_wall_ns=time.monotonic_ns() - begin, returncode=process.returncode,
                       stdout=process.stdout.decode(errors='replace'), stderr=process.stderr.decode(errors='replace'))
            assert process.returncode == 0
        except BaseException as exc:
            row['exception'] = repr(exc)
            if row['download_wall_ns'] is None:
                row['download_wall_ns'] = time.monotonic_ns() - begin
            raise
    record['ok'] = True
except BaseException as exc:
    record['error'] = repr(exc)
finally:
    record['wall_ns'] = time.monotonic_ns() - start
    receipt_path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'receipt': str(receipt_path), 'ok': record['ok'], 'error': record['error'],
                  'wall_ns': record['wall_ns'], 'packages': [{'name': x['package'], 'identity': x.get('identity'),
                  'returncode': x['returncode']} for x in record['packages']]}, sort_keys=True))
raise SystemExit(0 if record['ok'] else 1)
