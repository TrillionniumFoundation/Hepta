"""Read the owned bounded unittest capture without changing its file offset."""
import json
import os
from pathlib import Path
import re
import stat
import sys

pid = int(sys.argv[1])
expected = [b'/workspace/scratch/f0c12f106c89/hepta-native-venv/bin/python',
            b'-m', b'unittest', b'discover', b'-s', b'tests', b'-v', b'']
if Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') != expected:
    raise SystemExit('refuse to inspect an unrelated process')
if Path(f'/proc/{pid}/cwd').resolve() != Path('/workspace/scratch/f0c12f106c89/hepta-integration'):
    raise SystemExit('refuse to inspect another worktree')
fd = os.open(f'/proc/{pid}/fd/2', os.O_RDONLY)
try:
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_size > 8 * 1024 * 1024:
        raise SystemExit('expected bounded regular-file stderr capture')
    raw = os.pread(fd, info.st_size, 0)
finally:
    os.close(fd)
lines = raw.decode('utf-8', errors='replace').splitlines()
methods = [line for line in lines if re.match(r'^test_.* \.\.\. ', line)]
print(json.dumps({'capture_bytes': len(raw), 'observed_method_lines': len(methods),
                  'observed_ok_lines': sum(line.endswith(' ... ok') for line in methods),
                  'failures_errors_skips': [line for line in methods if re.search(r'\.\.\. (FAIL|ERROR|skipped)', line)],
                  'recent_methods': methods[-3:], 'completed_qualification': False}))
