#!/usr/bin/env python3
"""One frozen finite JSON checkpoint collector; all output stays external."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PLAN = HERE / "PLAN.json"


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": sha256(data).hexdigest()}


def save(path, value):
    data = json.dumps(value, sort_keys=True, indent=2, allow_nan=False).encode() + b"\n"
    temporary = path.with_name(path.name + ".pending")
    temporary.write_bytes(data)
    temporary.replace(path)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def persistence_error(row, where, error):
    row["persistence_errors"].append({"where": where, "type": type(error).__name__, "message": str(error)})
    row["qualified"] = False


def command(stage, directory, repo, env, run_bounded, CaptureRejected, row):
    started = time.monotonic_ns()
    row.update({"id": stage["id"], "argv": stage["argv"], "cwd": str(repo),
           "timeout_seconds": stage["timeout_seconds"], "started_utc": utc(),
           "status": "started", "returncode": None, "raw_capture_complete": False,
           "raw_streams_persisted_complete": False,
           "cleanup_scope": "existing run_bounded process-budget ownership; escaped child sessions and full descendant completion are not proved",
           "all_descendant_completion_proved": False, "escaped_descendant_work_ns": None})
    stdout = stderr = b""
    created = False
    try:
        directory.mkdir(exist_ok=False)
        created = True
        try:
            save(directory / "execution.json", row)
        except BaseException as error:
            persistence_error(row, "initial_execution_receipt", error)
            raise
        result = run_bounded(stage["argv"], cwd=repo, env=env,
                             timeout=stage["timeout_seconds"], stdin_limit=0,
                             stdout_limit=8 * 1024 * 1024, stderr_limit=8 * 1024 * 1024)
        require(result.raw_stdout is not None and result.raw_stderr is not None,
                "exact raw command capture required")
        stdout, stderr = result.raw_stdout, result.raw_stderr
        row.update(status="completed", returncode=result.returncode, raw_capture_complete=True)
    except CaptureRejected as error:
        row.update(status="capture_failed", error={"type": type(error).__name__,
                   "message": str(error), "code": error.code, "capture_error": error.capture_error})
        if error.capture is not None:
            value = error.capture
            stdout, stderr = value.stdout, value.stderr
            row.update(returncode=value.returncode, partial_capture={
                "stdout_total_bytes": value.stdout_total_bytes, "stderr_total_bytes": value.stderr_total_bytes,
                "stdout_retained_bytes": len(stdout), "stderr_retained_bytes": len(stderr)})
    except BaseException as error:
        row.update(status="failed", error={"type": type(error).__name__, "message": str(error)},
                   traceback=traceback.format_exc())
    finally:
        if created:
            for name, data in (("stdout", stdout), ("stderr", stderr)):
                try:
                    (directory / name).write_bytes(data)
                    observed = identity(directory / name)
                    require(observed["bytes"] == len(data) and observed["sha256"] == sha256(data).hexdigest(),
                            "persisted raw stream differs from captured bytes")
                    row[name] = observed
                except BaseException as error:
                    persistence_error(row, name, error)
        row["raw_streams_persisted_complete"] = (row["raw_capture_complete"] and
            all(name in row for name in ("stdout", "stderr")) and not row["persistence_errors"])
        row["wall_ns"] = time.monotonic_ns() - started
        row["wall_scope"] = "initial receipt, capture including failures/cleanup and raw-stream persistence; terminal execution receipt excluded"
        row["finished_utc"] = utc()
        if created:
            try:
                save(directory / "execution.json", row)
            except BaseException as error:
                persistence_error(row, "terminal_execution_receipt", error)
                row["raw_streams_persisted_complete"] = False
    return row


def main():
    require(len(sys.argv) == 1, "Execute the frozen external PLAN without runtime overrides")
    started = time.monotonic_ns()
    output = HERE / "run"
    output.mkdir(exist_ok=False)
    receipt = {"schema": "hepta.cpp-json-checkpoint.integrated-attempt.v1", "status": "started",
               "started_utc": utc(), "stages": [], "errors": [], "new_holdout": False,
               "historical_qualifications_relabelled": False,
               "whole_language_safety_proved": False, "full_environment_closure_proved": False,
               "foreign_library_rewritten": False, "foreign_failure_recovered_in_process": False,
               "core_or_native_publication_authority_granted": False, "automatic_retry_performed": False,
               "cpu_performance_qualification": False, "external_side_effects_rolled_back": False,
               "human_development_cost_ns": None, "human_development_cost_status": "unknown, not zero"}
    plan = source_state = tools_state = before = None
    try:
        save(output / "RECEIPT.json", receipt)
        plan = json.loads(PLAN.read_bytes())
        receipt.update(plan=identity(PLAN), launcher=identity(Path(__file__)),
                       expected_source_head=plan["source_head"], expected_source_tree=plan["source_tree"],
                       environment=plan["environment"], historical_references=plan["historical_references"])
        require(receipt["launcher"]["sha256"] == plan["launcher_sha256"], "launcher differs from PLAN")
        repo = Path(plan["repository"])
        require([(stage["id"], stage["kind"]) for stage in plan["stages"]] == [("checkpoint", "cpp_json_checkpoint")],
                "exact single checkpoint stage required")
        p3 = plan["stages"][0]
        require(Path(p3["qualification_directory"]) == output / "checkpoint" / "qualification"
                and p3["argv"][p3["argv"].index("--output-directory") + 1] == p3["qualification_directory"]
                and p3["argv"][p3["argv"].index("--expected-head") + 1] == plan["source_head"],
                "formal checkpoint output/source must match the frozen retained plan")
        for name, expected in plan["imported_helper_sha256"].items():
            require(identity(repo / name)["sha256"] == expected, "imported helper differs: " + name)
        removed = []
        for name in list(os.environ):
            if name.startswith(("CARGO_", "RUST", "HEPTA_")) or name in {
                    "CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "LIBRARY_PATH", "LD_PRELOAD",
                    "LD_AUDIT", "PYTHONPATH", "PYTHONHOME"}:
                removed.append(name)
                del os.environ[name]
        os.environ.update(plan["environment"])
        receipt["removed_environment_keys"] = sorted(removed)
        sys.path.insert(0, str(repo))
        from hepta.clang_capture import CaptureRejected, run_bounded
        from tools.qualify_hia_integrated import _source_state
        from tools.qualify_cpp_json_checkpoint import validate_report
        source_state = _source_state
        tools_state = lambda: {name: identity(path) for name, path in plan["tools"].items()}
        before = source_state()
        save(output / "source-before.json", before)
        require(before["head"] == plan["source_head"] and before["tree"] == plan["source_tree"]
                and not before["status"], "exact clean frozen source required")
        receipt["tools_before"] = tools_state()
        require(receipt["tools_before"] == plan["tools_before"], "observed tools differ from frozen plan")
        for stage in plan["stages"]:
            row = {"id": stage["id"], "status": "registered", "qualified": False, "persistence_errors": []}
            receipt["stages"].append(row)
            save(output / "RECEIPT.json", receipt)
            command(stage, output / stage["id"], repo, dict(os.environ), run_bounded, CaptureRejected, row)
            try:
                current = source_state()
                save(output / stage["id"] / "source-after.json", current)
                row["source_unchanged"] = current == before
                require(row["source_unchanged"], "source changed during stage")
                require(row["status"] == "completed" and row["raw_capture_complete"]
                        and row["raw_streams_persisted_complete"] and not row["persistence_errors"]
                        and row["returncode"] == 0, "stage did not complete successfully")
                report_path = Path(stage["qualification_directory"]) / "qualification.json"
                report = json.loads(report_path.read_bytes())
                row["qualification_file"] = identity(report_path)
                row["qualification"] = {key: report.get(key) for key in (
                    "ok", "status", "expected_head", "development_only", "claims", "wall_ns")}
                require(report["expected_head"] == plan["source_head"]
                        and report["development_only"] is False, "formal checkpoint source qualification differs")
                row["readback"] = validate_report(report)
                require(all(row["readback"][key] == value for key, value in plan["expected_observed_counts"].items()),
                        "actual calibration/worker/failure denominator differs from frozen expectation")
                row["actual_version_counts"] = {version["version"]: version["counts"] for version in report["versions"]}
                row["qualified"] = True
            except BaseException as error:
                row.update(qualified=False, gate_error={"type": type(error).__name__, "message": str(error)})
            try:
                save(output / stage["id"] / "execution.json", row)
            except BaseException as error:
                persistence_error(row, "qualified_execution_receipt", error)
            save(output / "RECEIPT.json", receipt)
            if not row.get("source_unchanged"):
                raise ValueError("source identity unavailable or changed; remaining stage not launched")
        receipt["status"] = "completed" if all(row.get("qualified") for row in receipt["stages"]) else "failed"
    except BaseException as error:
        receipt.update(status="failed")
        receipt["errors"].append({"where": "main", "type": type(error).__name__, "message": str(error),
                                  "traceback": traceback.format_exc()})
    finally:
        checks = {}
        if source_state is not None:
            checks["source_after"] = source_state
        if tools_state is not None:
            checks["tools_after"] = tools_state
        if plan is not None:
            checks.update(plan_after=lambda: identity(PLAN), launcher_after=lambda: identity(Path(__file__)))
        for name, action in checks.items():
            try:
                value = action()
                if name == "source_after":
                    save(output / "source-after.json", value)
                    receipt["source_unchanged"] = before is not None and before == value
                else:
                    receipt[name] = value
            except BaseException as error:
                receipt["errors"].append({"where": name, "type": type(error).__name__, "message": str(error)})
        for name in ("tools", "plan", "launcher"):
            first = name + "_before" if name == "tools" else name
            receipt[name + "_unchanged"] = first in receipt and receipt.get(name + "_after") == receipt[first]
        try:
            require(not any(path.is_symlink() for path in output.rglob("*")), "retained run contains a symlink")
            receipt["retained_files"] = {str(path.relative_to(output)): identity(path)
                for path in sorted(output.rglob("*")) if path.is_file() and path != output / "RECEIPT.json"}
        except BaseException as error:
            receipt["errors"].append({"where": "inventory", "type": type(error).__name__, "message": str(error)})
        if receipt["errors"] or not all(receipt.get(name + "_unchanged") for name in ("source", "tools", "plan", "launcher")):
            receipt["status"] = "failed"
        receipt["outer_wall_ns"] = time.monotonic_ns() - started
        receipt["outer_wall_scope"] = "main entry, source/tool identities, the collector command including failures, readback and output hashing; final receipt serialization and shell startup excluded"
        receipt["nested_cost_policy"] = "child/collector/stage costs overlap outer wall and must not be added to it"
        receipt["finished_utc"] = utc()
        try:
            save(output / "RECEIPT.json", receipt)
        except BaseException as error:
            receipt["status"] = "failed"
            receipt["errors"].append({"where": "terminal_receipt", "type": type(error).__name__, "message": str(error)})
            receipt["wall_ns_through_failed_terminal_write"] = time.monotonic_ns() - started
            print(json.dumps({"terminal_receipt_write_failed": receipt}, sort_keys=True), file=sys.stderr)
        print(json.dumps({key: receipt.get(key) for key in ("status", "source_unchanged", "tools_unchanged", "outer_wall_ns")}, sort_keys=True))
    return 0 if receipt["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
