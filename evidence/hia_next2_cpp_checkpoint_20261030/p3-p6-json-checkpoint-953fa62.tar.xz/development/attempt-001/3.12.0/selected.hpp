#pragma once
#include "/workspace/scratch/f0c12f106c89/hepta-next-migration/tests/fixtures/cpp_upgrade/3.12.0/json.hpp"
#include "/workspace/scratch/f0c12f106c89/hepta-next-migration/examples/cpp/upgrade/adapter.hpp"
