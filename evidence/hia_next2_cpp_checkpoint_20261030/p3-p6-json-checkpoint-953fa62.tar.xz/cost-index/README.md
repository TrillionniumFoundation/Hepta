# Partial observed P3/P6 cost index

This index keeps development overlays, the successful formal 3533 run, the fresh formal 953fa62 run, and the failed/fixed offline reader attempts separate. It rehashes only the listed small metadata files; it does not rerun native code, compress archives or read every payload during the model window.

Each observed elapsed interval retains its original scope. Nested times must not be added. The 23-method and 3-method development runs overlap by one method. Formal worker denominators remain per source-specific run. Foreign SIGABRT outcomes remain failed foreign invocations; explicit new-request parent reconstruction is a different observation.

The measured intervals are not a complete development bill. Human authoring/review/integration time, complete agent usage and financial cost remain unknown, not zero. The failed offline verifier and its repair costs remain visible and do not alter the native qualification.
