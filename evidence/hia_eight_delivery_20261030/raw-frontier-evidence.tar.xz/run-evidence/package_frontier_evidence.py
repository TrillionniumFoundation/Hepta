"""Seal the new pilot and late observations without rewriting the first archive."""
from pathlib import Path
import hashlib
import io
import json
import stat
import tarfile
import time

ROOT = Path('/workspace/scratch/8245a7ab856a')
OUT = ROOT / 'delivery-stage/evidence/hia_eight_delivery_20261030'
core = json.loads((OUT / 'ARCHIVE_MANIFEST.json').read_text())
old = {row['source_path']: row for row in core['files']}
inputs = []
for directory in [ROOT / 'agent-frontier-study', ROOT / 'run-evidence']:
    for path in sorted(directory.rglob('*')):
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        if path.is_dir():
            continue
        assert path.is_file() and not path.is_symlink(), path
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        prior = old.get(str(path))
        if prior is not None and digest == prior['sha256']:
            continue
        row = {
            'source_path': str(path),
            'archive_path': path.relative_to(ROOT).as_posix(),
            'bytes': len(data),
            'sha256': digest,
        }
        if prior is not None:
            row['earlier_core_archive_sha256'] = prior['sha256']
            row['earlier_bytes_remain_preserved_in_core_archive'] = True
        inputs.append(row)

archive = OUT / 'raw-frontier-evidence.tar.xz'
assert not archive.exists(), 'Refuse to overwrite a previously sealed archive'
with tarfile.open(archive, 'w:xz', preset=6) as tf:
    for row in inputs:
        path = Path(row['source_path'])
        data = path.read_bytes()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256'], path
        st = path.stat()
        member = tarfile.TarInfo(row['archive_path'])
        member.size = len(data)
        member.mode = stat.S_IMODE(st.st_mode)
        member.mtime = int(st.st_mtime)
        member.uid = member.gid = 0
        tf.addfile(member, io.BytesIO(data))

expected = {row['archive_path']: row for row in inputs}
assert len(expected) == len(inputs)
seen = set()
with tarfile.open(archive, 'r:xz') as tf:
    for member in tf:
        assert member.isfile() and member.name in expected
        assert member.name not in seen
        seen.add(member.name)
        row = expected[member.name]
        data = tf.extractfile(member).read()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
assert seen == set(expected)
data = archive.read_bytes()
manifest = {
    'schema': 'hepta.hia.raw-frontier-evidence-archive.v1',
    'archive': archive.name,
    'bytes': len(data),
    'sha256': hashlib.sha256(data).hexdigest(),
    'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    'created_unix_ns': time.time_ns(),
    'file_count': len(inputs),
    'uncompressed_bytes': sum(row['bytes'] for row in inputs),
    'all_archive_members_reopened_and_hash_verified': True,
    'source_scope': 'All regular non-pycache pilot files, actual run and superseded pre-generation controls; late or changed observations not present at the first archive seal. Earlier bytes remain in raw-core-evidence.tar.xz. No model weights or external toolchain binaries are asserted to be sealed here.',
    'prior_archive_sha256': core['sha256'],
    'files': inputs,
}
(OUT / 'FRONTIER_ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps({key: value for key, value in manifest.items() if key != 'files'}, ensure_ascii=False))
