#include <stdio.h>
#include "checksum.h"
int main(void) { unsigned int s,b,p; while(scanf("%u %u %u",&s,&b,&p)==3) { if(b>255) return 2; printf("%u\n",checksum_byte(s,(unsigned char)b,p)); } return ferror(stdin)?3:0; }
