; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i32 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = and i32 %p_0_0, 1
  %t2 = icmp ne i32 %t1, 0
  %t3 = icmp ult i32 1, 32
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = lshr i32 %p_0_0, 1
  %t6 = xor i32 %t5, %p_0_1
  %t7 = select i1 %t2, i32 %t6, i32 %t5
  %t8 = and i32 %t7, 1
  %t9 = icmp ne i32 %t8, 0
  %t10 = icmp ult i32 1, 32
  br i1 %t10, label %ok_11, label %trap_11
trap_11:
  call void @abort()
  unreachable
ok_11:
  %t12 = lshr i32 %t7, 1
  %t13 = xor i32 %t12, %p_0_1
  %t14 = select i1 %t9, i32 %t13, i32 %t12
  %t15 = and i32 %t14, 1
  %t16 = icmp ne i32 %t15, 0
  %t17 = icmp ult i32 1, 32
  br i1 %t17, label %ok_18, label %trap_18
trap_18:
  call void @abort()
  unreachable
ok_18:
  %t19 = lshr i32 %t14, 1
  %t20 = xor i32 %t19, %p_0_1
  %t21 = select i1 %t16, i32 %t20, i32 %t19
  %t22 = and i32 %t21, 1
  %t23 = icmp ne i32 %t22, 0
  %t24 = icmp ult i32 1, 32
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = lshr i32 %t21, 1
  %t27 = xor i32 %t26, %p_0_1
  %t28 = select i1 %t23, i32 %t27, i32 %t26
  %t29 = and i32 %t28, 1
  %t30 = icmp ne i32 %t29, 0
  %t31 = icmp ult i32 1, 32
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  %t33 = lshr i32 %t28, 1
  %t34 = xor i32 %t33, %p_0_1
  %t35 = select i1 %t30, i32 %t34, i32 %t33
  %t36 = and i32 %t35, 1
  %t37 = icmp ne i32 %t36, 0
  %t38 = icmp ult i32 1, 32
  br i1 %t38, label %ok_39, label %trap_39
trap_39:
  call void @abort()
  unreachable
ok_39:
  %t40 = lshr i32 %t35, 1
  %t41 = xor i32 %t40, %p_0_1
  %t42 = select i1 %t37, i32 %t41, i32 %t40
  %t43 = and i32 %t42, 1
  %t44 = icmp ne i32 %t43, 0
  %t45 = icmp ult i32 1, 32
  br i1 %t45, label %ok_46, label %trap_46
trap_46:
  call void @abort()
  unreachable
ok_46:
  %t47 = lshr i32 %t42, 1
  %t48 = xor i32 %t47, %p_0_1
  %t49 = select i1 %t44, i32 %t48, i32 %t47
  %t50 = and i32 %t49, 1
  %t51 = icmp ne i32 %t50, 0
  %t52 = icmp ult i32 1, 32
  br i1 %t52, label %ok_53, label %trap_53
trap_53:
  call void @abort()
  unreachable
ok_53:
  %t54 = lshr i32 %t49, 1
  %t55 = xor i32 %t54, %p_0_1
  %t56 = select i1 %t51, i32 %t55, i32 %t54
  ret i32 %t56
}

define i32 @calculate(i32 %a0, i32 %a1) {
entry:
  %result = call i32 @__hia_fn_0(i32 %a0, i32 %a1)
  ret i32 %result
}
