#!/usr/bin/env python3
"""Post-run audit from raw evidence, without importing Hepta controller code.

This is a finite allocation audit and accounting check. It does not turn a
calibration model optimum into a claim about unseen code or whole-program cost.
"""
from collections import Counter
from hashlib import sha256
from itertools import product
import argparse
import json
from pathlib import Path
import statistics

Q32 = 1 << 32


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return sha256(wire(value)).hexdigest()


def q32_ns(value):
    # Independent exact integer rounding to nearest, ties to even.
    whole, part = divmod(value * Q32, 1000000)
    return whole + int(2 * part > 1000000 or (2 * part == 1000000 and whole % 2 == 1))


def allocations(model):
    rows = []
    for choices in product(*model["modules"]):
        targets = [c["target"] for c in choices]
        rows.append({"targets": targets, "cost_ns": sum(c["cost_ns"] for c in choices),
                     "credits": sum(c["credits"] for c in choices),
                     "verified": all(c["verified"] for c in choices),
                     "id": "allocation-" + digest(targets)[:20]})
    return rows


def rank(row):
    return row["cost_ns"], row["credits"], tuple(row["targets"])


def independent_dp(model):
    # Bottom-up dynamic programming keyed by exactly consumed credit. This does
    # not use the harness's memoized suffix solver or any Hepta module.
    states = {0: {"targets": [], "cost_ns": 0, "credits": 0, "verified": True}}
    for choices in model["modules"]:
        following = {}
        for used, prefix in states.items():
            for choice in choices:
                total = used + choice["credits"]
                if not choice["verified"] or total > model["remaining_credits"]:
                    continue
                row = {"targets": prefix["targets"] + [choice["target"]],
                       "cost_ns": prefix["cost_ns"] + choice["cost_ns"],
                       "credits": total, "verified": True}
                if total not in following or rank(row) < rank(following[total]):
                    following[total] = row
        states = following
    if not states:
        return None
    result = min(states.values(), key=rank)
    return dict(result, id="allocation-" + digest(result["targets"])[:20])


def reconstruct_model(bank, modules, trace, epoch, prior, images, remaining, targets):
    horizon = trace[epoch:]
    choices = []
    for module in modules:
        options = []
        for target in targets:
            entry = bank["modules"][module][target]
            costs = []
            for n in horizon:
                completed = [r["delivery_cost_ns"] for r in prior if r["module"] == module
                             and r["target"] == target and r["n"] == n and r["status"] == "measured"]
                costs.append(round(statistics.median(completed)) if completed else entry["latency_ns"][str(n)])
            missing = (module, target) not in images
            options.append({"target": target, "credits": int(missing),
                            "cost_ns": sum(costs) + (entry["setup_ns"] if missing else 0),
                            "verified": entry["receipt"]["verification"]["status"] == "verified"})
        choices.append(options)
    return {"modules": choices, "remaining_credits": remaining, "modeled_horizon": horizon,
            "support": digest({"bank": bank["bank_sha256"], "modules": modules,
                               "epoch": epoch, "horizon": horizon,
                               "observations": prior, "artifacts": sorted(images)})}


def audit(folder):
    folder = Path(folder).resolve()
    raw = (folder / "RESULT.json").read_bytes()
    result = json.loads(raw)
    registration = json.loads((folder / "REGISTRATION.json").read_bytes())
    bank = json.loads((folder / "calibration/BANK.json").read_bytes())
    protocol = registration["protocol"]
    rows, errors = [], []
    def check(condition, label):
        if not condition:
            errors.append(label)
    episodes = result["policy_episodes"]
    check(len(episodes) == protocol["groups"] * len(protocol["arms"]), "policy episode count")
    expected_limits = {"entries": protocol["session_limits"]["max_entries"],
                       "bytes": protocol["session_limits"]["max_retained_bytes"],
                       "artifact": protocol["session_limits"]["max_artifact_bytes"],
                       "metadata": protocol["session_limits"]["max_metadata_bytes"],
                       "leases": protocol["session_limits"]["max_leases"],
                       "executions": protocol["session_limits"]["max_executions"]}
    for episode in episodes:
        prefix = str(episode["group"]) + ":" + episode["arm"]
        check(episode["same_initial_information"] == bank["bank_sha256"], prefix + " common bank")
        check(episode["future_timing_access"] is False, prefix + " future timing flag")
        check(episode["credits"]["limit"] == protocol["compile_credits"], prefix + " shared compile limit")
        check(episode["credits"]["used"] == len(episode["credits"]["attempts"]), prefix + " attempt ledger")
        check(episode["credits"]["used"] <= episode["credits"]["limit"], prefix + " compile budget")
        check(episode["artifact_session"]["limits"] == expected_limits, prefix + " prepared limits")
        check(episode["artifact_session"]["execution_attempts"] == len(episode["observations"]), prefix + " execution counter")
        check(episode["artifact_session"]["owned_native_release_complete"] is True, prefix + " release")
        check(episode["wall_ns"] <= protocol["episode_budget_ns"], prefix + " wall budget")
        if episode["arm"] != "native-stream-sealed":
            continue
        if episode.get("native_session") is None:
            check(False, prefix + " native session unavailable: " + episode.get("error", "unknown"))
            check(not episode["decisions"] and not episode["observations"], prefix + " failed start has no executed decisions")
            continue
        check(episode["native_session"]["image_check_profile"] == "sealed", prefix + " sealed image")
        check(episode["native_session"]["requests"] == len(episode["decisions"]), prefix + " no decision caching")
        images = {(module, "base") for module in episode["modules"]}
        consumed = 0
        for index, decision in enumerate(episode["decisions"]):
            epoch, model = decision["epoch"], decision["model"]
            tag = prefix + ":" + str(epoch)
            prior = [r for r in episode["observations"] if r["epoch"] < epoch]
            rebuilt = reconstruct_model(bank, episode["modules"], protocol["trace"], epoch,
                                        prior, images, protocol["compile_credits"] - consumed,
                                        protocol["targets"])
            check(rebuilt == model, tag + " model uses only common bank and own prior outputs")
            dynamic = independent_dp(model)
            all_plans = allocations(model)
            feasible = [r for r in all_plans if r["verified"] and r["credits"] <= model["remaining_credits"]]
            exhaustive = min(feasible, key=rank) if feasible else None
            check(dynamic == exhaustive, tag + " independent DP versus exhaustive enumeration")
            chosen, evidence = decision["selected"], decision["evidence"]
            check(evidence["reuse"] is None, tag + " no response cache")
            stem = folder / f"policy-{episode['group']}-{episode['arm']}" / "native" / f"{index + 2:04d}"
            sent, received = stem.with_suffix(".stdin").read_bytes(), stem.with_suffix(".stdout").read_bytes()
            command = json.loads(stem.with_suffix(".json").read_bytes())
            request, envelope = json.loads(sent), json.loads(received)
            response = envelope["response"]
            check(sha256(sent).hexdigest() == command["stdin_sha256"], tag + " input frame hash")
            check(sha256(received).hexdigest() == command["stdout_sha256"], tag + " output frame hash")
            check(request == evidence["request"] and response == evidence["response"], tag + " recorded native frames")
            check(envelope["sequence"] == index + 1, tag + " stream sequence")
            check(request["resource_budget_q32"] == model["remaining_credits"] * Q32, tag + " native credit budget")
            check(request["generation"] == episode["group"] * 1000 + epoch + 1, tag + " generation")
            check(response["authority"] == "DENY_ALL" and response["safety_certificate"] is False, tag + " advisory authority")
            supplied = {c["id"]: c for c in request["candidates"]}
            check(len(supplied) == len(all_plans) + 2, tag + " complete supplied finite allocation set")
            for plan in all_plans:
                candidate = supplied.get(plan["id"], {})
                check(candidate.get("verified") == plan["verified"], tag + " candidate verification")
                check(candidate.get("resource_cost_q32") == plan["credits"] * Q32, tag + " candidate credits")
                check(candidate.get("terminal_q32") == q32_ns(protocol["completion_value_ns"]), tag + " completion value")
                events = candidate.get("events", [])
                check(len(events) == 1 and events[0]["instant_q32"] == -q32_ns(plan["cost_ns"])
                      and events[0]["discount_q32"] == Q32, tag + " supplied modeled cost")
            check(supplied.get("known-refused", {}).get("verified") is False, tag + " known refused candidate")
            selected_id = response["advisory_candidate_id"]
            if selected_id is None:
                frontier = [p for p in all_plans if p["id"] in response["pareto_candidate_ids"]]
                selected_id = min(frontier, key=rank)["id"] if frontier else None
            check(selected_id == chosen["id"], tag + " returned plan matches native advice or registered tie rule")
            contested = 0
            for choices in model["modules"]:
                incumbent = min((c["cost_ns"] for c in choices if c["verified"] and c["credits"] == 0), default=None)
                if incumbent is not None and any(c["verified"] and c["credits"] == 1 and c["cost_ns"] < incumbent for c in choices):
                    contested += 1
            rows.append({"group": episode["group"], "epoch": epoch,
                         "selected": chosen, "independent_dp": dynamic,
                         "same_exact_dp_plan": chosen == dynamic,
                         "modeled_regret_ns": chosen["cost_ns"] - dynamic["cost_ns"],
                         "profitable_module_count_in_supplied_model": contested,
                         "two_profitable_modules_compete_for_one_credit": model["remaining_credits"] == 1 and contested >= 2,
                         "recorded_frame_prefix": str(stem),
                         "request_sha256": sha256(sent).hexdigest(),
                         "response_sha256": sha256(received).hexdigest()})
            for module, target in zip(episode["modules"], chosen["targets"]):
                if (module, target) not in images:
                    images.add((module, target))
                    consumed += 1
        check(consumed == episode["credits"]["used"], prefix + " reconstructed credit consumption")
    calibration = [json.loads(path.read_bytes()) for path in sorted((folder / "calibration").glob("sample-*.json"))]
    policy = [r for e in episodes for r in e["observations"]]
    controls = [r for e in result["opportunity_controls"] for r in e["observations"]]
    def outputs(rows):
        return {"recorded": len(rows), "measured": sum(r["status"] == "measured" for r in rows),
                "correct_checksum": sum(r.get("output", {}).get("checksum") == r.get("expected_checksum")
                                        and "expected_checksum" in r for r in rows),
                "fresh_solver_calls": sum(r.get("new_solver_call") is not False for r in rows)}
    counts = {"calibration": outputs(calibration), "policy": outputs(policy), "post_policy_controls": outputs(controls),
              "total": outputs(calibration + policy + controls)}
    sessions = [e["artifact_session"] for e in episodes + result["opportunity_controls"]]
    sessions.append(bank["session_closed"])
    check(sum(s["execution_attempts"] for s in sessions) == counts["total"]["recorded"], "total actual execution attempts")
    return {"schema": "hepta.hia.ndu.independent-four-arm-audit.v1",
            "result_path": str(folder / "RESULT.json"), "result_sha256": sha256(raw).hexdigest(),
            "source_commit": result["source_commit"], "audit_script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
            "audit_uses_hepta_controller_imports": False, "audit_passed": not errors, "errors": errors,
            "ndu_decisions": len(rows), "same_exact_dp_plan_count": sum(r["same_exact_dp_plan"] for r in rows),
            "native_decision_audit_available": len(rows) > 0,
            "native_decision_audit_complete": len(rows) == protocol["groups"] * len(protocol["trace"]),
            "functional_gate_from_frozen_harness": result["functional_gate"],
            "max_modeled_regret_ns": max((r["modeled_regret_ns"] for r in rows), default=None),
            "contested_profitable_shared_credit_decisions": sum(r["two_profitable_modules_compete_for_one_credit"] for r in rows),
            "observations": counts, "actual_execution_attempts": sum(s["execution_attempts"] for s in sessions),
            "actual_prepare_calls": sum(s["proof_attempts"] for s in sessions),
            "candidate_builds_by_arm": {a: sum(e["credits"]["used"] for e in episodes if e["arm"] == a) for a in protocol["arms"]},
            "policy_targets_by_arm": {a: dict(Counter(r["target"] for e in episodes if e["arm"] == a for r in e["observations"])) for a in protocol["arms"]},
            "same_eligible_initial_information": len({e["same_initial_information"] for e in episodes}) == 1,
            "future_timing_allowed": False, "exact_remaining_sizes_allowed": True,
            "own_completed_observations_can_differ_between_arms": True,
            "decision_response_cache_enabled": False, "same_prepared_artifact_limits": all(s["limits"] == expected_limits for s in sessions),
            "same_candidate_compilation_budget": protocol["compile_credits"],
            "all_owned_native_releases_complete": all(s["owned_native_release_complete"] for s in sessions),
            "decisions": rows, "claim_scope": "Exact optimum of each supplied stationary suffix allocation model, not all possible program schedules or future measured execution cost.",
            "unseen_workload_qualification": False, "complete_lifecycle_qualification": False,
            "statistical_superiority_established": False, "global_optimality_established": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = audit(args.directory)
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
    print(json.dumps({k: report[k] for k in ("audit_passed", "ndu_decisions", "same_exact_dp_plan_count", "max_modeled_regret_ns", "contested_profitable_shared_credit_decisions", "observations", "candidate_builds_by_arm", "errors")}, indent=2))
    return 0 if report["audit_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
