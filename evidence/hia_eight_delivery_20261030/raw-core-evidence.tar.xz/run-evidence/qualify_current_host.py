"""Retain actual Linux host ABI/lifecycle controls; no physical-device claim."""
from pathlib import Path
import hashlib
import io
import json
import os
import platform
import subprocess
import sys
import time
import unittest

ROOT = Path('/workspace/scratch/8245a7ab856a/Hepta')
OUT = Path('/workspace/scratch/8245a7ab856a/run-evidence/host')
EXPECTED = '60dfedc626b7ce3feaaa87ac16d711fe0cc8e9d3'
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_safety_contract import RecordedResult, environment_identity, source_inventory

MODULES = (
    'tests.test_scalar_host_abi',
    'tests.test_elf_shared_abi_native',
    'tests.test_hia_native_cleanup',
    'tests.test_hia_native_side_effects',
    'tests.test_hia_native_mapping_identity',
    'tests.test_hia_stateful',
)

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, text=True).strip()

def main():
    OUT.mkdir(exist_ok=False)
    start = time.perf_counter_ns()
    before = source_inventory()
    assert git('rev-parse', 'HEAD') == EXPECTED
    assert not git('status', '--porcelain', '--untracked-files=all')
    environment = environment_identity()
    suite = unittest.defaultTestLoader.loadTestsFromNames(MODULES)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=RecordedResult).run(suite)
    after = source_inventory()
    stable = before == after and git('rev-parse', 'HEAD') == EXPECTED and not git('status', '--porcelain', '--untracked-files=all')
    passed = stable and result.wasSuccessful() and not result.skipped
    report = {
        'schema': 'hepta.hia.current-host-controls.v1', 'source_commit': EXPECTED,
        'git_tree_sha1': git('rev-parse', 'HEAD^{tree}'), 'modules': list(MODULES),
        'environment': environment, 'source_before': before, 'source_after': after,
        'source_stable': stable, 'tests_run': result.testsRun, 'skipped': len(result.skipped),
        'failures': len(result.failures), 'errors': len(result.errors),
        'tests': result.records, 'passed': passed, 'wall_ns': time.perf_counter_ns()-start,
        'host_scope': 'Available Linux x86_64 development host; actual native ELF/C callers, process isolation, mapped images, concurrency and owned state controls.',
        'claims': {'physical_target_device_qualified': False, 'aarch64_or_riscv_board_executed': False,
            'mmio_dma_interrupts_qualified': False, 'whole_process_rss_bound_proved': False,
            'crash_durable_application_recovery_qualified': False,
            'general_thread_memory_model_qualified': False, 'performance_advantage_measured': False},
    }
    (OUT/'tests.log').write_text(stream.getvalue())
    (OUT/'RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps({key: report[key] for key in ('source_commit','tests_run','skipped','failures','errors','passed','wall_ns')}))
    return 0 if passed else 1

if __name__ == '__main__':
    raise SystemExit(main())
