#pragma once
#include "/workspace/scratch/8245a7ab856a/Hepta/tests/fixtures/cpp_upgrade/3.11.3/json.hpp"
#include "/workspace/scratch/8245a7ab856a/Hepta/examples/cpp/upgrade/adapter.hpp"
